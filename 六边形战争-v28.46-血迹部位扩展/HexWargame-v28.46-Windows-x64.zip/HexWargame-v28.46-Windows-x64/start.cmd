@echo off
setlocal
cd /d "%~dp0"
echo Open http://127.0.0.1:8800/ancient/ in your browser after the server starts.
hex_wargame_web3d.exe --host 127.0.0.1 --port 8800 --static web3d
if errorlevel 1 pause
