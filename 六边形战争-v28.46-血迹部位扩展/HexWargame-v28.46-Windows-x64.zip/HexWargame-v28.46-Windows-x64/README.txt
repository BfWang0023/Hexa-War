六边形战争 v28.46 · Windows-x64

完整解压后，双击 start.cmd。
服务启动后，在支持 WebGL 2 的浏览器中打开 http://127.0.0.1:8800/ancient/ 。
游戏过程中请保持启动窗口打开，退出时按 Ctrl+C。
