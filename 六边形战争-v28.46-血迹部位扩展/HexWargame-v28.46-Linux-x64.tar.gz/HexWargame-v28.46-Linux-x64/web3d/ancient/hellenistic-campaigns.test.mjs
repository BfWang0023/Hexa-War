import {campaignContract,bundledContract,bundledCount} from '../../tools/visibility-v28.37/map-contract.mjs';
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
import {HELLENISTIC_CAMPAIGNS as battles,hellenisticKinds} from './hellenistic-data.mjs';
import {makeHellenisticMap} from './hellenistic-maps.mjs';
import {CAMPAIGN_CATALOG} from './campaign-catalog.mjs';import {loadCampaign} from './campaign-loader.mjs';
import {STATS,TERRAIN as T,startGame,exportMap,importMap,checkVictory,endSide,aiTurn,canPlaceKind,isShip,isRouted,neighbors,tile,inBounds,reachable,move,setPhalanxMode} from './engine.mjs';
import {createSave,restoreSave,SAVE_FORMAT} from './save.mjs';import {classicalHelp} from './classical-ui.mjs';import {classicalFighter} from './classical-rules.mjs';
import {mapFor,seededRandom} from '../../tools/ai-training/maps.mjs';
const combat=(s,t)=>s.map.units.filter(u=>u.team===t&&classicalFighter(u));
const sha=data=>crypto.createHash('sha256').update(data).digest('hex');
const read=name=>JSON.parse(fs.readFileSync(new URL('../../docs/hellenistic-expansion/'+name,import.meta.url)));
const expected={granicus:[50,40],hydaspes:[34,48],ipsus:[48,60],heraclea:[44,48],raphia:[44,42],cynoscephalae:[55,51],magnesia:[31,77]};
for(const b of battles){
 test(`${b.id}: catalog, both loaders, source notes, legal deployment and exact tactical roster`,()=>{
  const m=makeHellenisticMap(b.id),s=startGame(m);assert.equal(CAMPAIGN_CATALOG.filter(c=>c.id===b.id).length,1);assert.equal(s.over,false);assert.equal(m.recruitment,null);assert.deepEqual(['egypt','coalition'].map(t=>combat(s,t).length),expected[b.id]);
  assert.deepEqual(exportMap(m),exportMap(loadCampaign(b.id)));assert.deepEqual(exportMap(m),exportMap(mapFor(b.id)));assert.deepEqual(exportMap(m),exportMap(importMap(exportMap(m))));
  for(const u of m.units.filter(u=>u.kind!=='fort')){assert.ok(hellenisticKinds(b.id,u.team).includes(u.kind));assert.ok(canPlaceKind(u.kind,u.team,b.id));assert.ok(!(tile(m,u.c,u.r).terrain&T.SEA));}
  const living=s.map.units.filter(u=>u.kind!=='fort');assert.equal(new Set(living.map(u=>`${u.c},${u.r}`)).size,living.length);assert.ok(b.sources.every(([n,u])=>n&&u.startsWith('https://')));assert.match(classicalHelp(m),/兵力与缩放/);assert.ok(classicalHelp(m).includes(b.sources[0][1]));
 });
 test(`${b.id}: real move spends one action and survives slot-save roundtrip`,()=>{
  const m=makeHellenisticMap(b.id),s=startGame(m);let result;
  for(const u of combat(s,'egypt')){const to=[...reachable(s,u).values()].find(p=>p.c!==u.c||p.r!==u.r);if(!to)continue;const before=u.actionsLeft;result=move(s,u.id,to.c,to.r);assert.ok(result.ok);assert.equal(u.actionsLeft,before-1);break;}
  assert.ok(result);const data=createSave(m,s,'egypt'),restored=restoreSave(JSON.parse(JSON.stringify(data)));assert.equal(data.format,SAVE_FORMAT);assert.deepEqual(restored.game.map.victory,s.map.victory);assert.deepEqual(exportMap(restored.game.map),exportMap(s.map));
 });
 for(const team of ['egypt','coalition'])test(`${b.id}: ${team} can win without scripted historical result`,()=>{
  const s=startGame(makeHellenisticMap(b.id)),foe=team==='egypt'?'coalition':'egypt';for(const u of combat(s,foe).slice(0,s.map.victory.losses[foe]))u.hp=0;checkVictory(s);assert.equal(s.winner,team);assert.equal(s.victoryReason,'classical_rout');
 });
 test(`${b.id}: deadline follows both sides, casualty fractions decide and no-loss draw is honest`,()=>{
  let s=startGame(makeHellenisticMap(b.id));s.turn=s.map.victory.turnLimit;endSide(s);assert.equal(s.over,false);endSide(s);assert.equal(s.over,true);assert.equal(s.winner,null);
  s=startGame(makeHellenisticMap(b.id));combat(s,'coalition')[0].hp=0;s.turn=s.map.victory.turnLimit;s.side='coalition';endSide(s);assert.equal(s.winner,'egypt');assert.equal(s.victoryReason,'classical_attrition');
 });
 test(`${b.id}: each AI side advances legally without overlap or negative actions`,()=>{
  for(const team of ['egypt','coalition']){const s=startGame(makeHellenisticMap(b.id));s.side=team;const actions=aiTurn(s,seededRandom(3));assert.ok(actions.some(a=>a.type==='move'),team);const living=s.map.units.filter(u=>u.kind!=='fort'&&u.hp>0&&!u.aboard);assert.equal(new Set(living.map(u=>`${u.c},${u.r}`)).size,living.length);assert.ok(living.every(u=>u.actionsLeft>=0));assert.ok(restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,team)))));}
 });
}
test('all existing 78 default maps including rosters and victory data are byte-equivalent after normalized export',()=>{const records=read('before-existing-maps.json');assert.equal(records.length,78);for(const r of records)campaignContract(r.id,sha(JSON.stringify(exportMap(mapFor(r.id)))),r.sha256);});
test('all 42 original bundled map files and every global unit attribute remain unchanged',()=>{const rows=read('before-bundled-maps.json');assert.equal(rows.length,42);assert.equal(fs.readdirSync(new URL('./bundled-maps/',import.meta.url)).filter(f=>f.endsWith('.json')).length,bundledCount);for(const r of rows)bundledContract(r.file,fs.readFileSync(new URL('./bundled-maps/'+r.file,import.meta.url)));assert.deepEqual(Object.fromEntries(Object.entries(STATS).filter(([k])=>k!=='scout').map(([k,{chargeClass,mountedRole,...v}])=>[k,v])),read('before-stats.json'));assert.ok(Object.values(STATS).every(v=>v.mountedRole===undefined||['shock','skirmisher','maneuver'].includes(v.mountedRole)));assert.ok(Object.values(STATS).every(v=>v.chargeClass===undefined||['cavalry','heavyChariot'].includes(v.chargeClass))); });
test('rivers are a single connected edge-to-edge water system and fords remain land-passable without fabricated bridges',()=>{
 for(const id of ['granicus','hydaspes','heraclea','magnesia']){const m=makeHellenisticMap(id),water=[];for(let r=0;r<m.rows;r++)for(let c=0;c<m.cols;c++)if(tile(m,c,r).terrain&T.RIVER)water.push({c,r});const seen=new Set(),queue=[water[0]];while(queue.length){const p=queue.pop(),k=`${p.c},${p.r}`;if(seen.has(k))continue;seen.add(k);for(const n of neighbors(p.c,p.r))if(inBounds(m,n.c,n.r)&&tile(m,n.c,n.r).terrain&T.RIVER&&!seen.has(`${n.c},${n.r}`))queue.push(n);}assert.equal(seen.size,water.length,id);assert.ok(water.some(p=>p.c===0||p.r===0));assert.ok(water.some(p=>p.c===m.cols-1||p.r===m.rows-1));assert.ok(water.some(p=>tile(m,p.c,p.r).terrain&T.ROAD));assert.equal(m.bridges.length,0);}
});
test('new elephant placement permissions are scoped to historical roster and do not leak into older scenarios',()=>{
 for(const id of ['ipsus','raphia','cynoscephalae','magnesia'])assert.equal(canPlaceKind('warElephant','egypt',id),true);
 for(const id of ['granicus','hydaspes','heraclea','gaugamela','marathon','pydna'])assert.equal(canPlaceKind('warElephant','egypt',id),false,id);
 assert.equal(canPlaceKind('scythedChariot','egypt','ipsus'),false);assert.equal(canPlaceKind('romanHastati','coalition','heraclea'),false);
});
test('untrusted victory variants and invalid turns are rejected on new map import',()=>{for(const b of battles)for(const mutate of [d=>d.victory.variant='megiddo',d=>d.victory.turnLimit=0,d=>d.victory.losses.egypt=9999]){const d=exportMap(makeHellenisticMap(b.id));mutate(d);assert.throws(()=>importMap(d));}});
test('cavalry screens, elephant reserves, Roman river flank and uneven Macedonian deployment match the chosen historical slice',()=>{
 const g=makeHellenisticMap('granicus');assert.ok(g.units.every(u=>u.c>21));assert.ok(g.units.filter(u=>u.team==='coalition'&&u.kind==='cavalry').every(u=>u.c<g.units.find(x=>x.kind==='greekHoplite').c));
 const h=makeHellenisticMap('hydaspes');assert.ok(h.units.filter(u=>u.team==='egypt').every(u=>u.c>8));assert.equal(h.units.filter(u=>u.kind==='warElephant').length,10);
 const i=makeHellenisticMap('ipsus');assert.equal(i.units.filter(u=>u.team==='coalition'&&u.kind==='warElephant').length,16);
 const c=makeHellenisticMap('cynoscephalae');assert.ok(c.units.some(u=>u.formation==='腓力已登高右翼'&&tile(c,u.c,u.r).terrain&T.MOUNTAIN));assert.ok(c.units.filter(u=>u.formation==='尚在展开的马其顿左翼').every(u=>u.c>=44));
 const m=makeHellenisticMap('magnesia');assert.equal(m.units.filter(u=>u.team==='coalition'&&u.kind==='phalangite').length,16);assert.equal(m.units.filter(u=>u.team==='egypt'&&u.kind==='warElephant').length,1);assert.ok(m.units.find(u=>u.customName?.includes('欧迈尼斯')).r>30);
});
test('new field battles still allow legal phalanx formation and retain it through saves',()=>{for(const b of battles){const s=startGame(makeHellenisticMap(b.id)),u=combat(s,'egypt').find(u=>u.kind==='phalangite'||u.kind==='romanHastati');assert.ok(setPhalanxMode(s,u.id,true,0).ok,b.id);const r=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,'egypt'))));assert.equal(r.game.map.units.find(x=>x.id===u.id).formed,true);}});
