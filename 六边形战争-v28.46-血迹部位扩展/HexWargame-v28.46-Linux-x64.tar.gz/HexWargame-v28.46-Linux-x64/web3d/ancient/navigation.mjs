import {CAMPAIGN_SERIES,campaignSeries} from './campaign-series.mjs';
import {TUTORIALS} from './tutorial-content.mjs';
// One persistent renderer/editor; navigation owns visibility and execution permission.
export const PAGES=['MainMenu','CampaignSelection','TutorialSelection','Tutorial','MapEditor','Settings','Battle','PauseMenu'];
export function bindNavigation(h){
 const $=id=>document.getElementById(id),root=document.createElement('section');root.id='navigation';document.body.append(root);let page='MainMenu',returnPage='MainMenu',session=false,tutorial=false,busy=false,revision=0;
 const button=(text,fn)=>{const b=document.createElement('button');b.textContent=text;b.onclick=async()=>{if(b.disabled)return;try{b.disabled=true;await fn();}catch(e){alert(e.message);}finally{b.disabled=false;}};return b;};
 const menu=button('菜单 · Esc',()=>go('PauseMenu'));menu.id='battle-menu';document.querySelector('header .actions').append(menu);
 const editorHome=button('返回主菜单',()=>leave());document.querySelector('.editor-head').append(editorHome);
 const importLabel=document.createElement('label');importLabel.textContent='导入战役地图 ';const importSelect=document.createElement('select');importSelect.id='editor-campaign-import';importLabel.append(importSelect);const importButton=button('导入所选战役',async()=>{if(!confirm('导入会替换当前编辑地图，请先保存未保存的修改。'))return;await h.start(importSelect.value,{mode:'human-human'});await h.edit();session=true;tutorial=false;h.stopTutorial();go('MapEditor');});importButton.id='editor-import-campaign';const importRow=document.createElement('div');importRow.className='row';importRow.style.cssText='display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0';importRow.append(importLabel,importButton);document.querySelector('.editor-head').after(importRow);
 function syncEditorCampaigns(){const value=importSelect.value;importSelect.replaceChildren(...[...$('scenario-select').options].map(o=>o.cloneNode(true)));if([...importSelect.options].some(o=>o.value===value))importSelect.value=value;}
 // Move original controls, retaining their listeners and persisted values.
 const staging=document.createElement('div');staging.hidden=true;document.body.append(staging);
 for(const id of ['scenario-select','battle-mode','side-select','editor','restart'])staging.append($(id).closest('label')||$(id));
 const titleLink=document.querySelector('header .title a');titleLink.onclick=e=>{e.preventDefault();leave();};
 function leave(){if(!confirm('返回主菜单？请先保存需要保留的对局或地图；当前战局可在本次会话继续。'))return;go('MainMenu');}
 function go(next){if(!PAGES.includes(next))throw Error('未知页面');for(const id of ['battle-mode','side-select','ai-difficulty']){const node=$(id);if(node)staging.append(node.closest('label')||node);}page=next;if(next==='MapEditor')syncEditorCampaigns();revision++;if(next==='MainMenu')for(const d of document.querySelectorAll('dialog[open]'))d.close();document.body.dataset.page=next;document.querySelector('main').inert=!['Battle','Tutorial','MapEditor'].includes(next);document.querySelector('header').inert=!['Battle','Tutorial','MapEditor'].includes(next);h.pause(!['Battle','Tutorial'].includes(next));root.hidden=['Battle','Tutorial','MapEditor','Settings'].includes(next);root.replaceChildren();if(root.hidden)return;
 const brand=document.createElement('div');brand.className='menu-brand';brand.innerHTML='<small>ANCIENT BATTLES · HISTORICAL STRATEGY</small><h1>六边形战争</h1><p>山河为局 · 运筹千年</p>';root.append(brand);const panel=document.createElement('div');panel.className='menu-panel';root.append(panel);
 if(next==='MainMenu'){panel.append(button('战役选择',()=>go('CampaignSelection')),button('教学模式',()=>go('TutorialSelection')),button('兵种图鉴',()=>h.encyclopedia()),button('规则手册',()=>h.manual('controls')),button('地图编辑器',async()=>{await h.edit();go('MapEditor');}),button('游戏设置',()=>settings()));if(session)panel.prepend(button('继续当前战局',()=>go(h.editing()?'MapEditor':tutorial?'Tutorial':'Battle')));fetch('/api/ancient/saves').then(r=>r.json()).then(rows=>{if(page===next&&rows.some(r=>r.scenarioName))panel.append(button('读取存档',()=>{$('saves').click();}));}).catch(()=>{});}
 if(next==='PauseMenu'){panel.append(button('继续战斗',()=>go(tutorial?'Tutorial':'Battle')),button('游戏设置',settings),button('保存 / 读取对局',()=>{$('saves').click();}),button('重新开始当前战役',()=>{if(confirm('放弃未保存进度并重新开始当前战役？')){if(tutorial)startTutorial(h.tutorialId());else{h.restart();go('Battle');}}}),button('返回主菜单',leave));}
 if(next==='CampaignSelection')campaigns(panel);
 if(next==='TutorialSelection'){panel.append(button('← 返回主菜单',()=>go('MainMenu')));const intro=document.createElement('p');intro.textContent='建议先完成基础操作和移动攻击，其余练习可独立选择。自动检查真实操作；可跳过或重试。';panel.append(intro);for(const t of TUTORIALS){const b=button(t.name+' · '+t.summary,()=>startTutorial(t.id));b.dataset.tutorial=t.id;panel.append(b);}}
 }
 function settings(){returnPage=page;go('Settings');$('settings').click();}
 $('close-settings').textContent='返回';$('settings-dialog').addEventListener('close',()=>{if(page==='Settings')go(returnPage);});
 $('save-dialog').addEventListener('close',()=>{if(h.loaded()){session=true;tutorial=false;h.stopTutorial();go('Battle');}});
 function campaigns(panel,series=null){
  if(!series){panel.append(button('← 返回主菜单',()=>go('MainMenu')));const grid=document.createElement('div');grid.className='series-grid';for(const entry of CAMPAIGN_SERIES){const b=button('',()=>{panel.replaceChildren();campaigns(panel,entry);});b.dataset.series=entry.id;b.className='series-card';b.style.backgroundImage=`linear-gradient(0deg,#0a1818ed,transparent 85%),url(./assets/series/${entry.cover})`;const title=document.createElement('strong'),subtitle=document.createElement('span');title.textContent=entry.name;subtitle.textContent=entry.period;b.append(title,subtitle);grid.append(b);}const custom=button('自定义战役',()=>{panel.replaceChildren();campaigns(panel,{id:null,name:'自定义战役',period:'玩家地图'});});panel.append(grid,custom);return;}
  panel.append(button('← 返回系列',()=>{panel.replaceChildren();campaigns(panel);}));const heading=document.createElement('h2');heading.textContent=series.name+' · '+series.period;panel.append(heading);
  panel.append(button('← 返回主菜单',()=>go('MainMenu')));
  const controls=document.createElement('div');controls.className='campaign-options';
  const clone=(source,id,label)=>{const el=$(source).cloneNode(true);el.id=id;el.disabled=false;const l=document.createElement('label');l.textContent=label+' ';l.append(el);controls.append(l);return el;};
  const mode=clone('battle-mode','campaign-mode','对抗方式'),side=clone('side-select','campaign-side','玩家阵营'),difficulty=clone('ai-difficulty','campaign-difficulty','电脑强度');
  mode.value='human-ai';side.replaceChildren();side.disabled=true;difficulty.value='normal';
  mode.onchange=()=>{side.disabled=mode.value!=='human-ai'||!side.options.length;};
  panel.append(controls);const search=document.createElement('input');search.placeholder='搜索战役 / 年代';panel.append(search);
  const list=document.createElement('div');list.className='campaign-list';panel.append(list);let selection=0;
  const draw=()=>{selection++;side.replaceChildren();side.disabled=true;list.replaceChildren();for(const o of $('scenario-select').options){
    if(campaignSeries(o.value)!==series.id||!o.textContent.includes(search.value))continue;
    const card=document.createElement('article'),detail=document.createElement('div');card.dataset.scenario=o.value;
    const b=button(o.textContent,async()=>{
      const request=++selection,view=revision;side.disabled=true;side.replaceChildren();
      for(const d of list.querySelectorAll('.campaign-detail'))d.replaceChildren();
      const map=await h.describe(o.value);if(request!==selection||view!==revision)return;
      for(const team of ['egypt','coalition']){const opt=document.createElement('option');opt.value=team;opt.textContent=map.factions[team];side.append(opt);}
      side.value='egypt';mode.onchange();
      const p=document.createElement('p');p.textContent=`${map.factions.egypt} 对 ${map.factions.coalition}\n${o.value==='china_maling'?'齐军伏击魏军。双方歼敌75%获胜，仅阵亡计入；占领马陵道不判胜。':map.intro||map.name}\n推荐：标准；新玩家可选择休闲。`;
      const enter=async()=>{if(busy)return;busy=true;try{const config={mode:mode.value,team:side.value,difficulty:difficulty.value};await h.start(o.value,config,()=>view===revision&&request===selection);if(view!==revision||request!==selection)return;session=true;tutorial=false;h.stopTutorial();go('Battle');}finally{busy=false;}};
      detail.append(p,button('进入战役',()=>enter()));
    });
    if(series.id){
      b.classList.add('campaign-cover');
      const artwork=document.createElement('img');
      artwork.src=new URL(`./assets/campaign-covers/${o.value}.svg`,import.meta.url).href;
      artwork.alt='';artwork.loading='lazy';artwork.decoding='async';
      const caption=document.createElement('span');
      caption.textContent=o.textContent;
      b.replaceChildren(artwork,caption);
    }
    detail.className='campaign-detail';card.append(b,detail);list.append(card);
  }};search.oninput=draw;draw();
 }

 async function startTutorial(id='basics'){await h.tutorial(id);session=true;tutorial=true;go('Tutorial');}
 window.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]'))return;if(e.key!=='Escape'){if(!['Battle','Tutorial','MapEditor'].includes(page))e.stopImmediatePropagation();return;}e.preventDefault();e.stopImmediatePropagation();if(['Battle','Tutorial'].includes(page))go('PauseMenu');else if(page==='PauseMenu')go(tutorial?'Tutorial':'Battle');else if(page==='MapEditor')leave();else go('MainMenu');},true);
 $('exit-editor').addEventListener('click',()=>{const wait=setInterval(()=>{if(!h.editing()){clearInterval(wait);session=true;go('Battle');}else if(!$('exit-editor').disabled)clearInterval(wait);},100);});
 go('MainMenu');return {go,startTutorial,finishTutorial(destination='MainMenu'){h.stopTutorial();tutorial=false;session=false;go(destination);},get page(){return page}};
}
