import {DAWN_IDS} from './dawn-data.mjs';
import {makeDawnMap} from './dawn-maps.mjs';
import {HELLENISTIC_IDS} from './hellenistic-data.mjs';
import {makeHellenisticMap} from './hellenistic-maps.mjs';
import {CLASSICAL_IDS} from './classical-data.mjs';
import {makeClassicalMap} from './classical-maps.mjs';
import * as E from './engine.mjs';
import { CHINA_CAMPAIGN_IDS, makeChinaMap } from './china-campaigns.mjs';
import { IMPERIAL_CAMPAIGN_IDS, makeImperialMap } from './imperial-campaigns.mjs';
import { mantineaMap, aegospotamiMap } from './greek-campaigns.mjs';
export function loadCampaign(id){if(DAWN_IDS.has(id))return makeDawnMap(id);if(HELLENISTIC_IDS.has(id))return makeHellenisticMap(id);if(CLASSICAL_IDS.has(id))return makeClassicalMap(id);if(CHINA_CAMPAIGN_IDS.has(id))return makeChinaMap(id);if(IMPERIAL_CAMPAIGN_IDS.has(id))return makeImperialMap(id);if(id==='mantinea')return mantineaMap();if(id==='aegospotami')return aegospotamiMap();const fn=E[id+'Map'];if(!fn)throw Error('Unknown campaign '+id);return fn();}
