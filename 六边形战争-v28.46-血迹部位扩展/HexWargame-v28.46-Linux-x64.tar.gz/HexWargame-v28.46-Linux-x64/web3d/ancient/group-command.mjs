import {orderLocked} from './order-lock.mjs';
import {planningState,knownMap} from './fog-policy.mjs';
// UI convenience only: preview on a clone, commit through the existing move API.
import { reachable, move, distance, mobileAt, inBounds, index, isRouted } from './engine.mjs';
export const axial = p => ({ q: p.c - (p.r - (p.r & 1)) / 2, r: p.r });
export const offset = p => ({ c: p.q + (p.r - (p.r & 1)) / 2, r: p.r });
export function selectable(u, team) {
  return u && !u.mutinous && u.team === team && u.hp > 0 && !u.aboard && !isRouted(u) &&
    !['fort', 'defenseTower', 'captive'].includes(u.kind);
}
export function toggleSelection(ids, u, team) {
  const next = new Set(ids);
  if (selectable(u, team)) next.has(u.id) ? next.delete(u.id) : next.add(u.id);
  return next;
}
export function rectangleSelection(units, team, rect, project, initial = []) {
  const result = new Set(initial);
  const left = Math.min(rect.x1, rect.x2), right = Math.max(rect.x1, rect.x2);
  const top = Math.min(rect.y1, rect.y2), bottom = Math.max(rect.y1, rect.y2);
  for (const u of units) {
    if (!selectable(u, team)) continue;
    const p = project(u);
    if (p && p.visible !== false && p.x >= left && p.x <= right && p.y >= top && p.y <= bottom) result.add(u.id);
  }
  return result;
}
export function gestureMode({ button, editing, space, shift, box, canSelect }) {
  if (button===1&&!space) return 'rotate';
  if(space)return 'pan';
  if(button===2)return 'pan-pending';
  if (editing) return 'paint';
  return canSelect ? 'select-pending' : 'pending';
}
export function planGroupMove(state, ids, target, {strict=false}={}) {state=planningState(state,state.side);
  const units = [...new Set(ids)].map(id => state.map.units.find(u => u.id === id)).filter(u => selectable(u,state.side));
  const plan = { target: { ...target }, team: state.side, strict, entries: [], order: [] };
  if (!units.length || !inBounds(state.map,target.c,target.r)) return plan;
  const coords = units.map(axial), center = coords.reduce((s,p)=>({q:s.q+p.q/units.length,r:s.r+p.r/units.length}),{q:0,r:0});
  const anchor = units.reduce((a,u)=>{
    const metric = v => {const p=axial(v);return (p.q-center.q)**2+(p.r-center.r)**2;};
    return metric(u)<metric(a)?u:a;
  });
  const a = axial(anchor), t = axial(target), delta = {q:t.q-a.q,r:t.r-a.r};
  const shadow = structuredClone(state), pending = [];shadow.observationSimulation=true;
  // Front ranks vacate before rear ranks; parity-safe translation preserves hex formation.
  const projection = u => {const p=axial(u);return p.q*delta.q+p.r*delta.r+(p.q+p.r)*(delta.q+delta.r);};
  for (const u of [...units].sort((a,b)=>projection(b)-projection(a)||a.id.localeCompare(b.id))) {
    const p=axial(u), desired=offset({q:p.q+delta.q,r:p.r+delta.r});
    const entry={id:u.id,from:{c:u.c,r:u.r},desired,to:{c:u.c,r:u.r},path:[],status:'blocked',reason:'无合法前进位置',changedFormation:false};
    plan.entries.push(entry);pending.push(entry);
  }
  // Revisit blocked units after another selected unit has vacated its starting cell.
  for (let pass=0; pass<units.length && pending.length; pass++) {
    let progress=false;
    for (let i=0;i<pending.length;) {
      const entry=pending[i],u=shadow.map.units.find(x=>x.id===entry.id);
      if (shadow.over || shadow.deploying || !u.actionsLeft || orderLocked(shadow,u.id)) {entry.reason=shadow.over?'战局已结束':shadow.deploying?'部署阶段不可批量行军':'行动点不足';pending.splice(i,1);continue;}
      if (distance(u,entry.desired)===0) {entry.reason='已在目标位置';pending.splice(i,1);continue;}
      const candidates=[...reachable(shadow,u).values()].filter(p=>!mobileAt(shadow.map,p.c,p.r) && !p.path.some(cell=>mobileAt(shadow.map,cell.c,cell.r)) && (strict ? !shadow.map.unknown?.[index(shadow.map,p.c,p.r)] && distance(p,entry.desired)===0 && p.steps===distance(u,p) : distance(p,entry.desired)<distance(u,entry.desired)));
      candidates.sort((a,b)=>distance(a,entry.desired)-distance(b,entry.desired)||a.cost-b.cost||a.steps-b.steps||a.r-b.r||a.c-b.c);
      const best=candidates[0];
      if (!best) {i++;continue;}
      const result=strict?{ok:true,path:best.path}:move(shadow,u.id,best.c,best.r);
      if(strict){u.c=best.c;u.r=best.r;for(const v of shadow.map.units)if(v.aboard===u.id){v.c=u.c;v.r=u.r;}}
      if (!result.ok) {entry.reason=result.reason;i++;continue;}
      Object.assign(entry,{status:'move',reason:'',to:{c:best.c,r:best.r},path:result.path,changedFormation:distance(best,entry.desired)>0});
      plan.order.push(entry.id);pending.splice(i,1);progress=true;
    }
    if(!progress)break;
  }
  if(strict&&plan.order.length!==units.length)plan.order=[];
  return plan;
}
// Translate the whole group by one axial vector. Only the anchor destination is clickable.
export function formationMoveRange(state,ids) {
 const view=planningState(state,state.side),units=view.map.units.filter(u=>ids.has(u.id)&&selectable(u,state.side));
 if(units.length!==ids.size||units.length<2||units.some(u=>!u.actionsLeft||orderLocked(view,u.id)))return new Map();
 const coords=units.map(axial),center=coords.reduce((a,p)=>({q:a.q+p.q/units.length,r:a.r+p.r/units.length}),{q:0,r:0});
 const metric=u=>{const p=axial(u);return (p.q-center.q)**2+(p.r-center.r)**2;};
 // Keep the same tie order as the planner.
 const ordered=[...ids].map(id=>units.find(u=>u.id===id)),anchor=ordered.reduce((a,u)=>metric(u)<metric(a)?u:a);
 const isolated=structuredClone(view);isolated.observationSimulation=true;isolated.map.units=isolated.map.units.filter(u=>u.id===anchor.id||!ids.has(u.id));
 const range=new Map();
 for(const [key,p] of reachable(isolated,anchor)){
   const plan=planGroupMove(view,ids,p,{strict:true});if(plan.order.length===units.length)range.set(key,plan);
 }
 return range;
}
export function executeGroupMove(state, plan, mover = move) {
  const results=[];
  if (state.side!==plan.team || state.over || state.deploying) return {success:0,failed:plan.entries.length,results};
  if(plan.strict){
    const trial=structuredClone(state);
    for(const id of plan.order){const e=plan.entries.find(x=>x.id===id),u=trial.map.units.find(x=>x.id===id);
      if(!u||u.c!==e.from.c||u.r!==e.from.r)return {success:0,failed:plan.entries.length,results};
      const result=move(trial,id,e.to.c,e.to.r);
      if(!result.ok||result.path.length!==distance(e.from,e.to))return {success:0,failed:plan.entries.length,results};
    }
    for(const id of plan.order){const e=plan.entries.find(x=>x.id===id);results.push({id,...mover(state,id,e.to.c,e.to.r)});}
    const success=results.filter(x=>x.ok).length;return {success,failed:plan.entries.length-success,results};
  }
  for (const id of plan.order) {
    const entry=plan.entries.find(x=>x.id===id),u=state.map.units.find(x=>x.id===id);
    if (!selectable(u,state.side) || u.c!==entry.from.c || u.r!==entry.from.r) {results.push({id,ok:false,reason:'预览已失效，请重新指定目标'});continue;}
    // Revalidate the exact previewed path, including visibility and newly occupied cells.
    const current=reachable(state,u).get(`${entry.to.c},${entry.to.r}`);
    if(!current || current.path.some(p=>mobileAt(knownMap(state,state.side),p.c,p.r)?.team!==undefined)) {results.push({id,ok:false,reason:'路径已被占据或不可达'});continue;}
    results.push({id,...mover(state,id,entry.to.c,entry.to.r)});
  }
  const success=results.filter(x=>x.ok).length;
  return {success,failed:plan.entries.length-success,results};
}
