// Every tactical cell outline is derived from the terrain's world-space footprint.
// No XY RingGeometry rotation or independently chosen tactical radius.
import * as THREE from '../vendor/three/three.module.js';
import {HEX_R,hexCorners,offsetToWorld} from '../js/core/hex.js';
export function cellOutline(c,r,{sample=()=>0,width=.18,inset=0,lift=.065,segments=8}={}){
 const center=offsetToWorld(c,r),outer=hexCorners(center.x,center.z,HEX_R-inset),inner=hexCorners(center.x,center.z,HEX_R-inset-width),positions=[],indices=[];
 for(let edge=0;edge<6;edge++)for(let step=0;step<=segments;step++){
  const t=step/segments,next=(edge+1)%6;
  for(const ring of [outer,inner]){const x=ring[edge][0]*(1-t)+ring[next][0]*t,z=ring[edge][1]*(1-t)+ring[next][1]*t;positions.push(x,sample(x,z)+lift,z);}
  if(step<segments){const a=(edge*(segments+1)+step)*2;indices.push(a,a+2,a+1,a+1,a+2,a+3);}
 }
 return {positions,indices};
}
export function createCellOutline(c,r,options){const data=cellOutline(c,r,options),g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3));g.setIndex(data.indices);return g;}
