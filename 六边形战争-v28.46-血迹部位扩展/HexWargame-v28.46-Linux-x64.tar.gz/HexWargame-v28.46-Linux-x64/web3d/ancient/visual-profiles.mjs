import {heroType} from './hero-types.mjs';
import {CHINA_CAMPAIGNS} from './china-campaigns.mjs';
import {IMPERIAL_CAMPAIGNS} from './imperial-campaigns.mjs';
import { STATS, unitName, unitStats, isTrireme, isFormableInfantry } from './engine.mjs';
// Visual choices, never a source of attack permission. Capability comes from unitStats;
// the performed action comes ONLY from attack().visual.melee / .ram.
const chineseCampaigns=new Map([...CHINA_CAMPAIGNS,...IMPERIAL_CAMPAIGNS].filter(c=>c.id.startsWith('china_')).map(c=>[c.id,c]));
const profiles={};
function add(ids,family,weapon='spear',rangedWeapon=null,extra={}){for(const id of ids.split(' '))profiles[id]=Object.freeze({family,weapon,rangedWeapon,...extra});}
add('scout','cavalry','spear');
add('light heavy phalangite greekHoplite romanTriarii africanInfantry','infantry');
add('guard chinaGeneral moraleGuard hittiteKing hero romanHastati romanPrincipes romanLegion caesarReserve pompeyLegion gaulInfantry iberianInfantry zamaVeteran hannibal paullus varro scipio','infantry','sword');
add('archer romanArcher','infantry','sword','bow');
add('chinaCrossbow','infantry','sword','crossbow');
add('romanVelites','infantry','spear','javelin');
add('punicSkirmisher','infantry','sword','sling');
profiles.hero=Object.freeze({...profiles.hero,weapon:'spear',rangedWeapon:'javelin'});
add('cavalry companionCavalry parthianCataphract romanHorse romanAlliedHorse pompeyHorse punicHeavyHorse zamaPunicHorse','cavalry');
add('numidianHorse masinissa masinissaHorse','cavalry','spear','javelin');
add('parthianHorseArcher','cavalry','sword','bow');
add('chariot pharaoh','chariot','spear','bow',{horses:2});
add('hittiteChariot','chariot','spear','javelin',{horses:2});
add('chinaHeavyChariot','chariot','spear','bow',{horses:4});
add('scythedChariot','chariot','spear',null,{horses:2,scythes:true});
add('warship athenianTrireme alliedTrireme phoenicianTrireme imperialTrireme octavianLiburnian antonyHeavyGalley cleopatraGalley moraleFlagship','ship','boarding','bow');
add('siegeGalley','ship','boarding','ballista');
add('transport','ship','none');
add('siegeRam','ram','ram');add('romanOnager','onager','none','stone');
add('siegeTower','siegeTower','none','bow');add('defenseTower','defenseTower','none','ballista');
add('warElephant','elephant','trample');add('chinaFireOx','ox','charge');
add('arrowCamel','camel','none');add('supplyWagon','wagon','none');
add('engineer captive','infantry','none');add('trojanHorse','trojanHorse','ram');add('fort','fort','none');
export const VISUAL_PROFILES=Object.freeze(profiles);
export function visualProfile(unit,scenario,map){
 const base=profiles[unit.kind];if(!base)return null;
 const stats=unitStats(map,unit),p={...base};
 p.character=heroType(unit,scenario,map,unitName(map||{},unit));
 if(unit.kind==='pharaoh'&&['gaugamela','issus','tyre'].includes(scenario))p.family='cavalry';
 if(unit.kind==='pharaoh'&&scenario==='troy')p.family='infantry';
 if(unit.kind==='hittiteKing'&&['gaugamela','issus','tyre'].includes(scenario)){p.family='chariot';p.horses=2;}
 if(unit.onFoot&&['chariot','cavalry'].includes(p.family))p.family='infantry';
 p.era=scenario?.startsWith('china_')?'china':['megiddo','kadesh','troy'].includes(scenario)?'bronze':'iron';
 const c=chineseCampaigns.get(scenario),faction=map?.factions?.[unit.team]||(unit.team==='egypt'?c?.attacker:c?.defender)||'';
 p.culture=p.era==='china'?(/匈奴|大宛/.test(faction)?'steppe':'china'):'mediterranean';
 p.period=c?.year>=-206?'han':c?.year>=-453?'qin':'early';
 // The internal pharaoh ID is reused for several historical rulers.
 if(['pharaoh','hittiteKing'].includes(unit.kind)){
  p.royalStyle=p.era==='china'?'china':scenario==='troy'?'aegean':scenario==='qarqar'?'assyria':scenario==='babylon'?'persia':['gaugamela','issus','tyre'].includes(scenario)?(unit.kind==='pharaoh'?'macedon':'persia'):unit.kind==='pharaoh'?'egypt':'hittite';
 }
 if(['hannibal','paullus','varro','scipio','masinissa'].includes(unit.kind))p.royalStyle='mediterranean';
 p.egyptianChariot=p.family==='chariot'&&(['megiddo','kadesh',undefined].includes(scenario))&&(unit.kind==='pharaoh'||unit.kind==='chariot'&&unit.team==='egypt');
 p.canMelee=stats.melee>0;p.canRanged=stats.ranged>0&&stats.range>0;
 p.formed=isFormableInfantry(unit)&&!!unit.formed;
 p.ruleFacing=isTrireme(unit)||(isFormableInfantry(unit)&&!!unit.formed);
 p.commander=['pharaoh','hittiteKing','hero','chinaGeneral','hannibal','paullus','varro','scipio','masinissa','moraleGuard','moraleFlagship'].includes(unit.kind);
 if(unit.kind==='hero')p.royalStyle='aegean';
 p.heroicRegalia=['hero','pharaoh','hittiteKing','chinaGeneral','hannibal','paullus','varro','scipio','masinissa'].includes(unit.kind)&&p.royalStyle!=='egypt';
 p.armor=stats.armor;p.shieldShape=/^roman|Legion|caesarReserve/.test(unit.kind)?'rect':'round';
 if(p.culture==='china')p.shieldShape='chinese';
 p.pike=unit.kind==='phalangite';p.cataphract=unit.kind==='parthianCataphract';
 p.meleeAction=p.canMelee?({spear:'thrust',sword:'slash',boarding:'boarding',ram:'ram',trample:'trample',charge:'charge'}[p.weapon]||'none'):'none';
 p.rangedAction=p.canRanged?({bow:'bow',crossbow:'crossbow',javelin:'throw',sling:'sling',stone:'catapult',ballista:'ballista'}[p.rangedWeapon]||'generic-projectile'):'none';
 return p;
}
export function actionFor(profile,visual){
 if(!profile||!visual)return 'none';
 if(visual.ram)return 'ram';
 // Validated attack result is authoritative even for custom map overrides.
 return visual.melee?(profile.meleeAction==='none'?'bash':profile.meleeAction):(profile.rangedAction==='none'?'generic-projectile':profile.rangedAction);
}
export function catalogEntry(kind,contexts=[]){const s=STATS[kind],p=visualProfile({kind},contexts[0]?.scenarioId);return {id:kind,name:s.name,civilizations:[...new Set(contexts.map(c=>c.factions).flat())],eras:[...new Set(contexts.map(c=>c.era))],weapon:p.weapon,rangedWeapon:p.rangedWeapon,meleeAction:p.meleeAction,rangedAction:p.rangedAction,movement:s.move>0?({infantry:'march',ship:'row',cavalry:'trot',chariot:'harness-trot',elephant:'heavy-walk',camel:'camel-walk',ox:'run'}[p.family]||'wheel-roll'):'stationary',rout:s.move>0?'follow-actual-retreat-path':'stationary',model:p.family,special:!['infantry','cavalry'].includes(p.family),upgraded:kind!=='fort',status:kind==='fort'?'preserved-terrain-owned':'implemented',reason:kind==='fort'?'城墙由地形渲染管理，保持旧接口，避免覆盖地形任务。':null,ruleEvidence:{source:'engine.mjs: STATS, unitName, unitStats, attackPreview, attack.visual',melee:s.melee,ranged:s.ranged,range:s.range,ammo:s.ammo},contexts};}
