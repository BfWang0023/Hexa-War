#!/bin/sh
set -eu
cd "$(dirname "$0")"
echo 'Open http://127.0.0.1:8800/ancient/ in your browser after the server starts.'
exec ./hex_wargame_web3d --host 127.0.0.1 --port 8800 --static web3d
