import {addCharacterModel} from './character-models.mjs';
import {applyHitFlash} from './hit-feedback.mjs';
import {prepareFormationModel,applyFormationPose} from './formation-pose.mjs';
import * as T from '../vendor/three/three.module.js';
import {materials as M,part,oval,box,rod,joint,human,horse,wheel,bake,setModelDetail,poseHumanArm,poseSegment} from './models-v02.mjs';
import {visualProfile} from './visual-profiles.mjs';
import {buildCamel,buildElephant,buildTrojanHorse,buildEgyptianChariot,decorateChineseChariot,addAxleScythes} from './historical-models.mjs';
import {buildFireOx} from './fire-ox.mjs';
import {buildSupplyWagon,buildDefenseTower} from './support-models.mjs';
const templates=new Map();
function person(parent,team,p,position=[0,0,0],scale=1,options={}){
 const g=joint(parent,options.rider?'rider':'soldier',position);human(g,team,p.era,{profile:p,...options});g.rotation.y=Math.PI/2;g.scale.setScalar(scale);if(p.family==='infantry'&&p.armor>=2){const shield=g.getObjectByName('shield');if(shield)shield.scale.setScalar(1.12);}g.userData.characterLead=!options.crew&&(options.crewRole!=='driver');g.userData.passenger=!!options.rider||!!options.crew||!!options.crewRole||p.family==='chariot';if(options.crewRole)g.traverse(o=>{o.userData.crewRole=options.crewRole;});return g;
}
function wagon(g,team,p){
 const zs=p.horses===4?[-1.83,-.61,.61,1.83]:[-.65,.65];zs.forEach((z,i)=>horse(g,z,i,true));
 box(g,M.wood,[-1.3,1.13,0],[1.52,.18,1.60]);rod(g,M.iron,[-1.22,.92,-1.04],[-1.22,.92,1.04],.09);wheel(g,-.96);wheel(g,.96);
 for(const z of [-.8,.8]){box(g,M.wood,[-1.28,1.48,z],[1.5,.6,.09]);rod(g,M.bronze,[-2,1.82,z],[-.55,1.82,z],.045);}
 box(g,team==='egypt'?M.blue:M.red,[-.56,1.48,0],[.09,.6,1.60]);
 rod(g,M.wood,[-1.2,1.16,0],[1.4,1.16,0],.07);rod(g,M.wood,[1.3,1.35,zs[0]-.2],[1.3,1.35,zs.at(-1)+.2],.06);
 for(const z of zs){rod(g,M.leather,[1.3,1.35,z],[1.28,1.67,z],.04);for(const dz of [-.16,.16])rod(g,M.leather,[2.12,2.15,z+dz],[p.culture==='china'?-.73:-.9,2.2,p.culture==='china'?Math.sign(dz)*.277:dz],.014);}
 if(p.culture==='china'){
  const driver=person(g,team,{...p,commander:false,weapon:'none',rangedWeapon:null},[-.95,.98,0],.59,{crew:true,crewRole:'driver'});driver.userData.crewRole='driver';
  const archer=person(g,team,{...p,commander:false,weapon:'none',rangedWeapon:'bow'},[-1.40,.98,-.50],.59,{crewRole:'archer'});archer.userData.crewRole='archer';
  const halberdier=person(g,team,{...p,commander:false,weapon:'spear',rangedWeapon:null,polearm:'ji'},[-1.40,.98,.50],.59,{crewRole:'halberdier'});halberdier.userData.crewRole='halberdier';
 }else {person(g,team,p,[-1.3,.98,-.43],.64,{crew:true});person(g,team,p,[-1.3,.98,.43],.64);}
 if(p.scythes)addAxleScythes(g);
}
function ship(g,team,p,kind,low){
 const shape=new T.Shape();[[-3,-.25],[-2.4,-.85],[1.7,-.85],[3,0],[1.7,.85],[-2.4,.85]].forEach(([x,z],i)=>i?shape.lineTo(x,z):shape.moveTo(x,z));shape.closePath();
 const hull=part(g,new T.ExtrudeGeometry(shape,{depth:.65,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:.1,bevelThickness:.1}),M.wood,[0,1.12,0]);hull.rotation.x=Math.PI/2;
 box(g,M.darkWood,[0,1.16,0],[4.5,.12,1.5]);for(const z of [-.78,.78])rod(g,M.wood,[-2.4,1.4,z],[1.8,1.4,z],.08);
 rod(g,M.bronze,[2.3,.65,0],[3.4,.65,0],.13,.035);
 for(const side of [-1,1])for(let i=0;i<(low?4:8);i++){const x=-1.9+i*(low?1.1:.53);const oar=joint(g,'oar',[x,.88,side*.7]);rod(oar,M.wood,[0,0,0],[-.5,-.3,side*1.4],.028);box(oar,M.wood,[-.5,-.3,side*1.4],[.15,.065,.37]);}
 if(kind==='transport'){box(g,M.linen,[-.4,1.55,0],[1.8,.65,1.1]);rod(g,M.wood,[.6,1.2,0],[.6,3.7,0],.055);box(g,M.linen,[.6,2.9,0],[.06,1.2,2]);}
 else {
  const count=kind==='antonyHeavyGalley'?3:2;for(let i=0;i<count;i++)person(g,team,{...p,weapon:'sword',rangedWeapon:p.rangedWeapon==='ballista'?null:'bow'},[-1.5+i*1.2,1,0],.44);
  if(p.rangedWeapon==='ballista')ballista(g,[1,1.2,0]);
  if(p.commander){rod(g,M.wood,[-1.9,1.3,0],[-1.9,3.3,0],.04);box(g,team==='egypt'?M.blue:M.red,[-1.9,2.9,.35],[.05,.6,.7]);}
 }
}
function rollingBase(g,length=3,width=1.8){box(g,M.darkWood,[0,.68,0],[length,.22,width]);for(const x of [-length*.32,length*.32])for(const z of [-width*.53,width*.53]){const w=joint(g,'wheel',[x,.5,z]);part(w,new T.TorusGeometry(.38,.09,5,12),M.wood,[0,0,0]);for(let i=0;i<6;i++){const a=i*Math.PI/3;rod(w,M.wood,[0,0,0],[.36*Math.cos(a),.36*Math.sin(a),0],.03);}oval(w,M.bronze,[0,0,0],[.08,.08,.1]);}}
function ballista(g,position){const frame=joint(g,'siege-aim',position);box(frame,M.wood,[0,.3,0],[1.6,.16,.5]);const bow=joint(frame,'ballista-bow',[.45,.3,0]);for(const side of [-1,1]){rod(bow,M.wood,[0,0,0],[.2,0,side*.75],.06);rod(bow,M.linen,[.2,0,side*.75],[-.55,0,0],.015);}const bolt=joint(frame,'loaded-arrow',[0,.43,0]);rod(bolt,M.wood,[-.5,0,0],[1,0,0],.035);joint(frame,'muzzle',[1.05,.43,0]);}
function siege(g,team,p){
 if(p.family!=='defenseTower')rollingBase(g,p.family==='siegeTower'?3.5:3,p.family==='siegeTower'?2.5:1.8);
 if(p.family==='wagon'){box(g,M.wood,[0,1.1,0],[2.8,.8,1.7]);for(const x of [-.9,0,.9])oval(g,M.linen,[x,1.7,0],[.4,.3,.65]);rod(g,M.wood,[1.3,.8,0],[2.6,.8,0],.07);return;}
 if(p.family==='ram'){for(const x of [-1,1])for(const z of [-.7,.7])rod(g,M.wood,[x,.7,z],[x,2.3,z],.09);box(g,M.leather,[0,2.4,0],[3.3,.22,2.1]);const ram=joint(g,'ram-head',[0,1.3,0]);rod(ram,M.wood,[-1.4,0,0],[1.7,0,0],.2);oval(ram,M.bronze,[1.72,0,0],[.25,.24,.27]);for(const x of [-.8,.8])rod(g,M.leather,[x,2.3,0],[x,1.3,0],.025);}
 if(p.family==='onager'){for(const z of [-.65,.65]){rod(g,M.wood,[-1,.8,z],[0,2,z],.11);rod(g,M.wood,[0,2,z],[1,.8,z],.11);}rod(g,M.linen,[0,1.3,-.8],[0,1.3,.8],.18);const arm=joint(g,'catapult-arm',[0,1.3,0]);rod(arm,M.wood,[0,0,0],[-1.1,1.5,0],.11);oval(arm,M.leather,[-1.1,1.5,0],[.3,.15,.3]);const stone=joint(arm,'loaded-arrow',[-1.1,1.65,0]);oval(stone,M.iron,[0,0,0],[.24,.24,.24]);joint(arm,'muzzle',[-1.1,1.65,0]);}
 if(['siegeTower','defenseTower'].includes(p.family)){const fixed=p.family==='defenseTower';if(fixed)box(g,M.iron,[0,1.6,0],[2.2,3.2,2.2]);else for(const x of [-1.3,1.3])for(const z of [-1,1])rod(g,M.wood,[x,.8,z],[x,5,z],.12);
 const top=fixed?3.3:5;for(const y of fixed?[top]:[2.5,top]){box(g,M.wood,[0,y,0],[2.9,.2,2.4]);for(const z of [-1.15,1.15])box(g,M.leather,[0,y+.4,z],[2.9,.7,.1]);}
 if(fixed)ballista(g,[0,top,0]);else {person(g,team,{...p,weapon:'sword',rangedWeapon:'bow'},[.3,top,0],.6);const bridge=joint(g,'siege-bridge',[1.4,top,0]);box(bridge,M.wood,[.65,0,0],[1.3,.15,1.5]);}}
}
function beast(g,team,p){
 const family=p.family,elephant=family==='elephant',camel=family==='camel',wood=family==='trojanHorse';const coat=wood?M.wood:elephant?M.iron:camel?M.pale:M.bay;
 const y=elephant?2:camel?1.8:1.4,scale=elephant?1.5:1;
 if(wood)rollingBase(g,4,2.2);
 const body=joint(g,'beast-body',[0,wood?.6:0,0]);oval(body,coat,[0,y,0],[1.15*scale,.68*scale,.55*scale]);
 for(const side of [-1,1])for(const x of [-.8,.8]){const leg=joint(body,'beastleg:'+x+':'+side,[x,y-.25,side*.4*scale]);rod(leg,coat,[0,0,0],[x*.1,-(y-.5),0],elephant?.23:.1);oval(leg,M.hoof,[x*.1,-(y-.5),0],[elephant?.24:.14,.12,elephant?.24:.12]);}
 const head=joint(body,'beast-head',[1.1,y+.35,0]);
 if(elephant){oval(head,coat,[.35,.05,0],[.62,.6,.6]);for(const side of [-1,1]){oval(head,coat,[.15,.05,side*.57],[.18,.6,.4]);rod(head,M.linen,[.65,-.15,side*.3],[1.1,-.45,side*.4],.08,.02);}const trunk=joint(head,'trunk',[.8,0,0]);rod(trunk,coat,[0,0,0],[.1,-1,0],.16,.24);rod(trunk,coat,[.1,-1,0],[.4,-1.3,0],.10,.16);box(body,M.leather,[-.2,3,0],[1.6,.15,1.4]);person(body,team,{...p,weapon:'spear',rangedWeapon:null},[-.2,2.2,0],.65);}
 else {const neck=oval(head,coat,[.2,.3,0],[.24,.65,.3]);neck.rotation.z=-.3;oval(head,coat,[.5,.8,0],[.45,.2,.25]);for(const side of [-1,1])oval(head,coat,[.28,1.02,side*.16],[.055,.11,.055]);if(camel){for(const x of [-.5,.4])oval(body,coat,[x,y+.65,0],[.35,.5,.4]);for(const side of [-1,1])box(body,M.wood,[0,y,side*.7],[.9,.7,.4]);}else if(family==='ox'){for(const side of [-1,1])rod(head,M.linen,[.4,.9,side*.2],[.65,1.2,side*.55],.06,.015);const flame=joint(body,'fire-tail',[-1.2,y,0]);part(flame,new T.ConeGeometry(.17,.6,5),M.red,[0,0,0]);}else{for(const x of [-.8,-.4,0,.4,.8])box(body,M.darkWood,[x,y,0],[.055,1.1,1.15]);}}
 rod(body,wood?M.darkWood:M.mane,[-1.1,y+.1,0],[-1.45,y-.7,0],.09);
}
function build(unit,p,low){setModelDetail(low);const root=new T.Group(),g=joint(root,'visual',[0,0,0]);const team=unit.team;
 switch(p.family){
 case 'infantry':{const squad=!p.character&&!['captive','engineer'].includes(unit.kind),positions=squad?[[-.65,0,-.65],[.65,0,-.65],[-.65,0,.65],[.65,0,.65]]:[[0,0,0]];for(const pos of positions)person(g,team,p,pos,.69);if(unit.kind==='captive')box(g,M.leather,[0,1.4,.3],[.6,.035,.035]);if(unit.kind==='engineer')rod(g,M.wood,[0,.4,.3],[0,2,.3],.04);break;}
 case 'cavalry':horse(g,0,team==='egypt'?0:1);person(g,team,p,[.66,.78,0],.69,{rider:true});if(p.cataphract)oval(g,M.bronze,[.6,1.5,0],[.8,.4,.36]);for(const z of [-.2,.2])rod(g,M.leather,[1.95,2.17,z],[.95,2.4,z],.018);break;
 case 'chariot':if(p.egyptianChariot)buildEgyptianChariot(g,team,p,low,person);else {wagon(g,team,p);if(p.culture==='china')decorateChineseChariot(g,team,p,low);}break;
 case 'ship':ship(g,team,p,unit.kind,low);break;
 case 'elephant':buildElephant(g,team,p,low,person);break;
 case 'camel':buildCamel(g,team,p,low);break;
 case 'trojanHorse':buildTrojanHorse(g,team,p,low);break;
 case 'ox':buildFireOx(g,low);break;
 case 'wagon':buildSupplyWagon(g,team,p,low,person);break;
 case 'defenseTower':buildDefenseTower(g,team,p,low,person);break;
 default:siege(g,team,p);
 }
 if(p.family==='chariot')g.traverse(o=>{if(o.name==='soldier'||o.name==='rider'){o.scale.setScalar(.76);o.userData.passenger=true;}});
 if(p.character)addCharacterModel(g,p,{M,box,oval,rod,joint},low);
 prepareFormationModel(root,p,low);
 bake(root);if(low)flattenDistant(root,p);return root;
}
export function createFullModel(unit,scenario,map){const p=visualProfile(unit,scenario,map);if(!p||p.family==='fort')return null;const root=new T.Group();root.userData.fullUnit=true;root.userData.profile=p;root.userData.kind=unit.kind;
 for(const low of [false,true]){const key=JSON.stringify([unit.kind,unit.team,p,low]);if(!templates.has(key))templates.set(key,build(unit,p,low));const child=templates.get(key).clone(true);child.name=low?'far':'near';child.visible=!low;root.add(child);}
 root.rotation.y=unit.team==='egypt'?0:Math.PI;
 root.userData.rig=[];root.traverse(o=>{if(o.isGroup&&o!==root)root.userData.rig.push({o,position:o.position.clone(),rotation:o.rotation.clone(),scale:o.scale.clone(),visible:o.visible});});
 return root;
}
export function resetFullPose(root){for(const r of root.userData.rig||[]){r.o.position.copy(r.position);r.o.rotation.copy(r.rotation);r.o.scale.copy(r.scale);r.o.visible=r.visible;}}
export function animateFullModel(root,time,{moving=false,routed=false,action='none',progress=0,hit=0,distance=0,complex=true}={}){
 if(!root.userData.fullUnit)return;resetFullPose(root);const far=distance>115;root.getObjectByName('near').visible=!far;root.getObjectByName('far').visible=far;
 const t=time/1000,phase=t*(routed?12:8),p=Math.max(0,Math.min(1,progress));const active=action!=='none'&&p>0&&p<1;
 const wind=p<.28?p/.28:p<.52?1-(p-.28)/.24:0;const thrust=p<.25?-.16*p/.25:p<.45?-.16+(p-.25)/.2*.95:p<.7?.79*(1-(p-.45)/.25):0;
 const release=.55,draw=p<.25?0:p<release?(p-.25)/(release-.25):Math.max(0,1-(p-release)/.1);
 const ranged=['bow','crossbow','throw','sling','catapult','ballista','generic-projectile'].includes(action);
 const requestedAction=action,requestedActive=active;
 for(const r of root.userData.rig){const o=r.o,action=crewCanAct(o.userData.crewRole,requestedAction)?requestedAction:'none',active=requestedActive&&action!=='none';
  if(o.name==='melee-tool'){o.visible=active?!ranged:!(o.userData.hasRangedWeapon??root.userData.profile.rangedWeapon);if(active&&action==='thrust')o.rotation.x=Math.PI/2;}
  if(o.name==='ranged-tool')o.visible=!active||ranged;
  if(o.name==='loaded-arrow')o.visible=!active||p<release||p>.93;
  if(o.name==='visual'){o.position.y+=moving?.035*Math.abs(Math.sin(phase)):0;if(active&&['ram','charge','trample'].includes(action))o.position.x+=Math.max(0,thrust)*.55;}
  if(o.name==='wheel'&&moving)o.rotation.z=-phase;
  if(o.name==='weapon'&&active){if(action==='thrust'){o.rotation.x=0;}if(action==='slash'||action==='boarding'){o.rotation.x=-1.1*wind+1.2*Math.max(0,Math.sin((p-.28)*Math.PI));o.rotation.z=.45*Math.sin(p*Math.PI);}if(action==='throw'){o.rotation.x=p<release?-1.7*wind:1.25*Math.sin((p-release)/(1-release)*Math.PI);}if(action==='bash')o.position.z+=Math.max(0,thrust)*.4;}
  
  if(o.name==='bow-string'){for(const half of o.children.filter(x=>x.isGroup)){const sign=half.name.endsWith('-1')?-1:1;poseSegment(half,new T.Vector3(0,sign*.76,-.03),new T.Vector3(0,0,-.12-(active&&action==='bow'?draw*.36:0)));}}
  if(o.name==='loaded-arrow'&&active&&action==='bow')o.position.z-=draw*.36;
  if(o.name==='ranged-tool'&&active&&action==='throw'){o.rotation.x=p<release?-.45:Math.PI/2;o.visible=p<release||p>.93;}
  if(o.name==='sling'&&active)o.rotation.x=p<release?time*.03:0;
  if(o.name==='catapult-arm'&&active&&action==='catapult')o.rotation.z=-.8*wind+1.15*Math.max(0,Math.sin((p-.28)*Math.PI));
  if(o.name==='ram-head'&&active&&action==='ram')o.position.x+=thrust;
  if(o.name==='ballista-bow'&&active&&action==='ballista')o.scale.x=1-.25*draw;
  if(!complex||far)continue;
  if(o.name.startsWith('horseleg')&&moving)o.rotation.z+=.32*Math.sin(phase+(o.name.includes('-1')?Math.PI:0)+(o.name.includes('-0.59')?Math.PI:0));
  if(o.name.startsWith('beastleg')&&moving)o.rotation.z+=.23*Math.sin(phase+(o.name.endsWith('-1')?Math.PI:0)+(o.name.includes('-0.8')?Math.PI:0));
  if(o.name.startsWith('leg')&&o.parent.name==='soldier'&&!o.parent.userData.passenger&&moving)o.rotation.x=.38*Math.sin(phase+(o.name==='leg-1'?Math.PI:0));
  if(o.name==='oar'&&moving)o.rotation.y=.3*Math.sin(phase*.6);
  if(o.name==='breath'){o.position.y+=.012*Math.sin(t*2.3);if(active&&action==='thrust')o.rotation.x=.1*Math.max(0,thrust);}
  if(o.name==='tail')o.rotation.x=.08*Math.sin(t*3);
  if(o.name==='trunk'&&active)o.rotation.z=.2*Math.sin(p*Math.PI);
  if(o.name==='fire-tail')o.scale.setScalar(1+.1*Math.sin(t*12));
 }
 for(const {o} of root.userData.rig){const action=crewCanAct(o.userData.crewRole,requestedAction)?requestedAction:'none',active=requestedActive&&action!=='none';if(!complex||far)continue;if(o.name!=='weapon'&&o.name!=='shield')continue;
  const side=o.userData.armSide;if(!side)continue;let wrist=new T.Vector3(side*.13,-.43,.37);
  if(active&&action==='thrust'&&side===1)wrist.set(.13,-.3,.37+thrust*.36);
  if(active&&action==='bow')wrist=side===-1?new T.Vector3(.24,-.15,.62):new T.Vector3(-.44,-.15,.50-draw*.36);
  if(active&&action==='crossbow')wrist=side===-1?new T.Vector3(.24,-.24,.55):new T.Vector3(-.43,-.22,p<.25?.05:.17);
  poseHumanArm(o,wrist);
 }
 applyFormationPose(root,root.userData.profile,{action:requestedAction,progress:p});
 applyHitFlash(root,hit>0);
}


function crewCanAct(role,action){return !role||role==='archer'&&action==='bow'||role==='halberdier'&&['thrust','bash'].includes(action);}

// At map distance retain silhouette/materials and a launch anchor, but collapse the
// complete articulated hierarchy to one draw per material. Only the near rig animates.
function flattenDistant(root,p){
 root.traverse(o=>{if(o.name==='melee-tool'&&(o.userData.hasRangedWeapon??p.rangedWeapon))o.visible=false;});root.updateMatrixWorld(true);
 const g=root.getObjectByName('visual'),anchor=root.getObjectByName('muzzle')?.getWorldPosition(new T.Vector3()),parts=[],old=new Set();
 root.traverseVisible(o=>{if(o.isMesh){const geo=o.geometry.clone();geo.applyMatrix4(o.matrixWorld);parts.push(new T.Mesh(geo,o.material));}});
 root.traverse(o=>{if(o.geometry)old.add(o.geometry);});g.clear();for(const m of parts)g.add(m);for(const geo of old)geo.dispose();bake(g);
 if(anchor)joint(g,'muzzle',anchor.toArray());
}
