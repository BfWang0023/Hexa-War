// Local hex cross-section. Banks must be actual known dry land on BOTH sides;
// map edges, sea and unexplored cells never count as a bank. No render heights.
const axes=[[1,0],[1,-1],[0,-1]];
export function riverWidthClass(m,c,r){
 const at=(q,y)=>{const x=q+Math.floor(y/2);if(x<0||y<0||x>=m.cols||y>=m.rows||m.unknown?.[y*m.cols+x])return null;return m.terrain[y*m.cols+x];};
 const q=c-Math.floor(r/2);if(!(at(q,r)&4))return null;
 for(const [dq,dr]of axes){let count=1,banks=0;for(const sign of [-1,1]){for(let step=1;step<=3;step++){const t=at(q+sign*dq*step,r+sign*dr*step);if(t===null||t&8)break;if(!(t&4)){banks++;break;}count++;if(count>2)break;}if(count>2)break;}if(banks===2&&count<=2)return count;}
 return 3; // Three or more, or insufficient known banks: no natural ford.
}
export const naturalFord=(m,c,r)=>m.riverCrossing===1&&((w)=>w===1||w===2)(riverWidthClass(m,c,r));
// Feed the exact existing ford branches without altering stored terrain/roads.
export const crossingTerrain=(m,c,r)=>{const t=m.terrain[r*m.cols+c];return naturalFord(m,c,r)?t|1:t;};
