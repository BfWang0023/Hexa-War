import {unifiedCores} from './fortress-cores.mjs';
// Ownership topology is authored or derived from an explicit city identity, never wall adjacency alone.
import {neighbors,distance,inBounds,isRouted,isShip,unitStats,fortAt,mobileAt,recomputeFog,checkVictory} from './engine.mjs';
import {authoritativeState,planningState,unitKnown,isObservation} from './fog-policy.mjs';
const key=p=>p.c+','+p.r,copy=p=>({c:p.c,r:p.r}),teams=['egypt','coalition'];
export const usesCapture=s=>s.rulesVersion>=18;
// Even low-morale, routed, exhausted and uncontrollable living soldiers still guard their fortress.
export function effectiveGarrison(u){return !!u&&u.hp>0&&!u.escaped&&!['fort','captive','supplyWagon'].includes(u.kind);}
export function canCaptureUnit(m,u){return effectiveGarrison(u)&&!u.aboard&&!isRouted(u)&&!isShip(u)&&!['defenseTower','siegeRam','siegeTower','romanOnager','trojanHorse','chinaFireOx'].includes(u.kind)&&(unitStats(m,u).melee>0||unitStats(m,u).ranged>0);}
export function validateCaptureDefinitions(m){
 if(m.controlCores!==undefined){if(!Array.isArray(m.controlCores))throw Error('人工核心数据无效');const bound=new Set();for(const record of m.controlCores){if(!record||!Number.isInteger(record.c)||!Number.isInteger(record.r)||!inBounds(m,record.c,record.r)||!Array.isArray(record.walls)||!record.walls.length)throw Error('人工核心数据无效');for(const p of record.walls){if(!p||!m.units.some(u=>u.kind==='fort'&&u.c===p.c&&u.r===p.r)||bound.has(key(p)))throw Error('每段工事只能绑定一个核心');bound.add(key(p));}}}
 const defs=m?.fortificationSites;if(defs===undefined)return;if(!Array.isArray(defs)||defs.length>256)throw Error('工事控制区配置无效');const ids=new Set(),used=new Set();
 for(const d of defs){if(!d||typeof d.id!=='string'||!d.id.length||d.id.length>80||ids.has(d.id)||typeof d.name!=='string'||!d.name.length||d.name.length>80||!['fortress','line'].includes(d.kind)||!Array.isArray(d.walls)||!d.walls.length)throw Error('工事控制区配置无效');ids.add(d.id);
  for(const p of d.walls){if(!p||!Number.isInteger(p.c)||!Number.isInteger(p.r)||!inBounds(m,p.c,p.r)||!m.units.some(u=>u.kind==='fort'&&key(u)===key(p))||used.has(key(p)))throw Error('工事归属重复或墙段不存在');used.add(key(p));}
  if(d.kind==='fortress'){if(!Array.isArray(d.area)||!d.area.length)throw Error('堡垒须配置内部区域');const area=new Set();for(const p of d.area){if(!p||!Number.isInteger(p.c)||!Number.isInteger(p.r)||!inBounds(m,p.c,p.r)||d.walls.some(w=>key(w)===key(p))||area.has(key(p)))throw Error('堡垒内部区域无效');area.add(key(p));}}
 }
}
export function deriveCaptureSites(m){
 validateCaptureDefinitions(m);const forts=m.units.filter(u=>u.kind==='fort'),taken=new Set(),sites=[];
 for(const d of m.fortificationSites||[]){for(const p of d.walls)taken.add(key(p));if(d.kind==='fortress')sites.push({id:'authored:'+d.id,name:d.name,kind:'fortress',fortIds:d.walls.map(p=>forts.find(f=>key(f)===key(p)).id),area:d.area.map(copy),owner:forts.find(f=>key(f)===key(d.walls[0])).team});}
 const labels=[...new Set(forts.filter(f=>f.cityId&&!taken.has(key(f))).map(f=>f.cityId))].sort();
 for(const label of labels){const ws=forts.filter(f=>f.cityId===label&&!taken.has(key(f))),barrier=new Set(ws.map(key));if(ws.length<3)continue;
  const minC=Math.max(0,Math.min(...ws.map(f=>f.c))-1),maxC=Math.min(m.cols-1,Math.max(...ws.map(f=>f.c))+1),minR=Math.max(0,Math.min(...ws.map(f=>f.r))-1),maxR=Math.min(m.rows-1,Math.max(...ws.map(f=>f.r))+1),inside=p=>p.c>=minC&&p.c<=maxC&&p.r>=minR&&p.r<=maxR,visited=new Set();
  for(let r=minR;r<=maxR;r++)for(let c=minC;c<=maxC;c++){const start={c,r};if(barrier.has(key(start))||visited.has(key(start)))continue;const cells=[start];visited.add(key(start));let open=false;for(let i=0;i<cells.length;i++)for(const p of neighbors(cells[i].c,cells[i].r)){if(!inside(p)){open=true;continue;}if(!barrier.has(key(p))&&!visited.has(key(p))){visited.add(key(p));cells.push(p);}}
   if(open)continue;const areaSet=new Set(cells.map(key)),boundary=ws.filter(f=>neighbors(f.c,f.r).some(p=>areaSet.has(key(p))));if(boundary.length<3||new Set(boundary.map(f=>f.team)).size!==1||boundary.some(f=>taken.has(key(f))))continue;
   const anchor=cells.slice().sort((a,b)=>a.r-b.r||a.c-b.c)[0],id='city:'+label+':'+key(anchor);sites.push({id,name:label,kind:'fortress',fortIds:boundary.map(f=>f.id),area:cells.map(copy),owner:boundary[0].team});for(const f of boundary)taken.add(key(f));
  }
 }
 return sites;
}
export function initializeCapture(s){if(!usesCapture(s))return;s.captureControl={version:s.rulesVersion>=22?3:1,holdTurns:1,sites:s.rulesVersion>=22?unifiedCores(s.map,completeCaptureSites(s.map)):deriveCaptureSites(s.map),knownWalls:{egypt:[],coalition:[]},history:[]};revealCaptureTopology(s);}
export function revealCaptureTopology(s){if(!usesCapture(s)||!s.captureControl||isObservation(s))return;for(const team of teams){const seen=new Set(s.captureControl.knownWalls[team]);for(const f of s.map.units)if(f.kind==='fort'&&(f.team===team||!s.fogPolicy?.unitFog||s.fog[team].visible.has(key(f))))seen.add(f.id);s.captureControl.knownWalls[team]=[...seen].sort();}}
export function captureObservation(s,team){const data=s.captureControl;if(!data)return null;const known=new Set(data.knownWalls[team]);return {version:data.version,sites:data.sites.filter(site=>site.fortIds.every(id=>known.has(id))).map(({owner,claim,controlState,...site})=>structuredClone(site)),knownWalls:{[team]:[...known]},history:data.history.filter(e=>e.team===team).map(e=>({...e}))};}
function targets(view,u){const sites=view.captureControl?.sites||[],known=view.map.units.filter(f=>f.kind==='fort'&&f.hp>0&&f.team!==u.team&&unitKnown(view,u.team,f)&&(!view.fogPolicy?.unitFog||view.fog[u.team].visible.has(key(f)))),result=[];for(const site of sites){const fs=known.filter(f=>site.fortIds.includes(f.id));if(fs.length)result.push({...site,target:copy(fs[0]),owner:fs[0].team});}for(const f of known)if(!sites.some(site=>site.fortIds.includes(f.id)))result.push({id:'segment:'+f.id,name:f.cityId||'独立墙段',kind:'segment',fortIds:[f.id],area:[],target:copy(f),owner:f.team});return result;}
export function contactPoints(target,m){const fs=m.units.filter(f=>target.fortIds.includes(f.id)),inside=new Set([...target.area,...fs].map(key)),result=new Map();for(const f of fs)for(const p of neighbors(f.c,f.r))if(inBounds(m,p.c,p.r)&&!inside.has(key(p)))result.set(key(p),p);return [...result.values()];}
function contact(target,u,m){return contactPoints(target,m).some(p=>key(p)===key(u));}
function defenders(m,target,team){const fs=m.units.filter(f=>target.fortIds.includes(f.id)),zone=new Set([...target.area,...fs].map(key));return m.units.filter(v=>v.team!==team&&effectiveGarrison(v)&&(target.kind==='fortress'?zone.has(key(v)):fs.some(f=>distance(v,f)<=1)));}
export function captureOptions(s,u){if(!usesCapture(s)||!canCaptureUnit(s.map,u))return [];const view=planningState(s,u.team);return targets(view,u).map(t=>({...t,inContact:contact(t,u,view.map),status:defenders(view.map,t,u.team).length?'known-guarded':'not-known-guarded'}));}
// Only the authoritative successful-movement path calls this settlement. No public preflight reveals real guards.
export function resolveFortificationContact(s,u,movement){
 if(isObservation(s)||!usesCapture(s)||!canCaptureUnit(s.map,u)||s.over||s.deploying||u.team!==s.side||!movement?.path?.length||key(movement.path.at(-1))!==key(u))return [];
 if(s.captureControl.version>=3)return settleFortressControl(s);
 const sites=s.captureControl.sites,grouped=new Set(sites.flatMap(t=>t.fortIds)),forts=s.map.units.filter(f=>f.kind==='fort'),candidates=[...sites,...forts.filter(f=>!grouped.has(f.id)).map(f=>({id:'segment:'+f.id,name:f.cityId||'独立墙段',kind:'segment',fortIds:[f.id],area:[],owner:f.team}))],captured=s.captureControl.version>=2?settleFortressControl(s):[];
 for(const target of candidates){if(s.captureControl.version>=2&&target.kind==='fortress')continue;const walls=forts.filter(f=>target.fortIds.includes(f.id));if(!walls.some(f=>f.hp>0&&f.team!==u.team)||!contact(target,u,s.map)||defenders(s.map,target,u.team).length)continue;
  const former=new Set(walls.map(f=>f.team));for(const fort of walls)fort.team=u.team;if(target.kind==='fortress')target.owner=u.team;
  const zone=new Set(target.area.map(key));for(const p of s.map.supplyPoints||[])if(former.has(p.team)&&zone.has(key(p))&&walls.some(f=>f.cityId===p.cityId))p.team=u.team;
  const event={siteId:target.id,team:u.team,turn:s.turn,unitId:u.id};s.captureControl.history.push(event);captured.push(target.id);s.log.push(`${s.map.factions[u.team]}抵近夺取${target.kind==='fortress'?'空堡垒':'墙段'}：${target.name}（无额外行动消耗，保留原耐久）`);
 }
 if(captured.length)recomputeFog(s);return captured;
}
export function captureGoal(s,u,target){const view=planningState(s,u.team),t=captureOptions(view,u).find(t=>t.id===target.id);if(!t||s.captureControl?.version===4&&!t.core)return null;return (s.captureControl?.version>=2&&t.kind==='fortress'?[t.core||t.area[0]]:contactPoints(t,view.map)).filter(p=>!fortAt(view.map,p.c,p.r)&&(!mobileAt(view.map,p.c,p.r)||key(p)===key(u))).sort((a,b)=>distance(u,a)-distance(u,b)||a.r-b.r||a.c-b.c)[0]||null;}
export function validateCaptureState(s){if(!usesCapture(s))return;const d=s.captureControl;if(!d||![1,2,3,4].includes(d.version)||!Array.isArray(d.sites)||!d.knownWalls||!Array.isArray(d.history))throw Error('工事控制状态无效');if(d.version===3&&(!Number.isInteger(d.holdTurns)||d.holdTurns<1||d.holdTurns>20))throw Error('核心控制回合配置无效');const ids=new Set(),walls=new Set();for(const site of d.sites){if(!site||typeof site.id!=='string'||ids.has(site.id)||site.kind!=='fortress'||typeof site.name!=='string'||!teams.includes(site.owner)||!Array.isArray(site.fortIds)||!site.fortIds.length||!Array.isArray(site.area)||!site.area.length)throw Error('堡垒控制关系无效');if(d.version===3&&(!site.core||!site.area.some(p=>key(p)===key(site.core))||site.claim&&(!teams.includes(site.claim.team)||!Number.isInteger(site.claim.turn)||site.claim.turn<1||site.claim.turn>s.turn)))throw Error('核心控制状态无效');ids.add(site.id);for(const id of site.fortIds){if(walls.has(id)||!s.map.units.some(u=>u.id===id&&u.kind==='fort'))throw Error('堡垒墙段归属无效');walls.add(id);}for(const p of site.area)if(!p||!Number.isInteger(p.c)||!Number.isInteger(p.r)||!inBounds(s.map,p.c,p.r))throw Error('堡垒控制区域无效');}for(const team of teams)if(!Array.isArray(d.knownWalls[team])||d.knownWalls[team].some(id=>!s.map.units.some(u=>u.kind==='fort'&&u.id===id)))throw Error('工事侦察状态无效');for(const e of d.history)if(!e||!teams.includes(e.team)||typeof e.siteId!=='string'||!Number.isInteger(e.turn)||e.turn<1)throw Error('工事占领记录无效');}

// Group a connected city's partitions as one defensive system. Authored IDs remain independent.
function completeCaptureSites(m){const sites=deriveCaptureSites(m),forts=m.units.filter(u=>u.kind==='fort'),used=new Set(),out=[];
 for(const site of sites){if(used.has(site.id))continue;const merged={...site,area:[...site.area],fortIds:[...site.fortIds]};used.add(site.id);
 if(!site.id.startsWith('authored:')){let changed=true;while(changed){changed=false;for(const f of forts.filter(f=>f.cityId===site.name)){if(merged.fortIds.includes(f.id))continue;if(forts.some(w=>merged.fortIds.includes(w.id)&&distance(w,f)===1)){merged.fortIds.push(f.id);changed=true;}}for(const other of sites){if(used.has(other.id)||other.id.startsWith('authored:'))continue;if(other.fortIds.some(id=>merged.fortIds.includes(id))){used.add(other.id);merged.fortIds=[...new Set([...merged.fortIds,...other.fortIds])];merged.area.push(...other.area);changed=true;}}}}
 merged.area=[...new Map(merged.area.map(p=>[key(p),p])).values()];const walls=forts.filter(f=>merged.fortIds.includes(f.id));merged.core=merged.area.slice().sort((a,b)=>Math.min(...walls.map(w=>distance(b,w)))-Math.min(...walls.map(w=>distance(a,w)))||a.r-b.r||a.c-b.c)[0];merged.controlState='defender';out.push(merged);
 }return out;}
export function settleFortressControl(s){if(isObservation(s)||!(s.captureControl?.version>=2)||s.over||s.deploying)return [];const captured=[];
 for(const site of s.captureControl.sites){if(s.captureControl.version===4&&!site.core)continue;const walls=s.map.units.filter(f=>site.fortIds.includes(f.id)),inside=new Set(site.area.map(key)),core=site.core||site.area[0],attacker=s.map.units.find(u=>inside.has(key(u))&&u.team!==site.owner&&canCaptureUnit(s.map,u));
 const guards=defenders(s.map,site,site.owner==='egypt'?'coalition':'egypt');
 const occupant=s.map.units.find(u=>key(u)===key(core)&&u.team!==site.owner&&canCaptureUnit(s.map,u));
 if(!attacker){site.controlState='defender';delete site.claim;continue;}
 site.controlState='contested';let winner=null;
 if(!guards.length&&s.captureControl.version===2)winner=attacker.team;
 else if(occupant&&!guards.some(g=>distance(g,core)<=1)){if(!site.claim||site.claim.team!==occupant.team)site.claim={team:occupant.team,turn:s.turn};if(s.side===occupant.team&&s.turn-site.claim.turn>=(s.captureControl.holdTurns??1))winner=occupant.team;}else delete site.claim;
 if(!winner)continue;const former=site.owner;site.owner=winner;site.controlState='defender';delete site.claim;for(const wall of walls)wall.team=winner;for(const p of s.map.supplyPoints||[])if(p.team===former&&inside.has(key(p)))p.team=winner;
 s.captureControl.history.push({siteId:site.id,team:winner,turn:s.turn,unitId:(occupant||attacker).id});s.log.push(`${s.map.factions[winner]}占领${site.name}：所属工事统一易主，耐久与残余部队保留`);captured.push(site.id);
 }if(captured.length)recomputeFog(s);return captured;}

export const editorDefenseSites=m=>unifiedCores(m,completeCaptureSites(m));
export function applyManualCores(s){if(!usesCapture(s))return;s.captureControl.version=4;for(const site of s.captureControl.sites){const coordinates=site.fortIds.map(id=>s.map.units.find(f=>f.id===id)),record=(s.map.controlCores||[]).find(r=>r.walls.length===coordinates.length&&coordinates.every(w=>r.walls.some(p=>key(p)===key(w))));site.core=record?copy(record):null;if(record&&!site.area.some(p=>key(p)===key(record)))site.area.push(copy(record));delete site.claim;}}
