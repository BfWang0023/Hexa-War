// Gate properties derive from wall configuration. No open/close state exists.
export function gateMaxHp(wallHp,level){if(!Number.isInteger(level)||level<1||level>3)throw Error('城门等级无效');return Math.round(wallHp[level]*.7);}
export function gatePassable(gate,unit){return gate.hp<=0||gate.team===unit.team;}
export function validateGate(gate,wallHp){if(!gate||gate.kind!=='fort'||gate.gate!==true||!['egypt','coalition'].includes(gate.team)||!Number.isInteger(gate.hp)||gate.hp<0||gate.hp>gateMaxHp(wallHp,gate.level))throw Error('城门数据无效');if('open' in gate||'gateOpen' in gate)throw Error('城门使用阵营通行，不支持开关状态');}
