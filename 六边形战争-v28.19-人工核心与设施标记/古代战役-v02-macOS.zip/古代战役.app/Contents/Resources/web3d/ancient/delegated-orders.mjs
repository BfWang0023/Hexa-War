import {committedTask,LOCK_REASON} from './order-lock.mjs';
// Reserved contract: future recon jobs must retain ordinary movement/AP and team observation.
export const RECON_TASK_CONTRACT=Object.freeze({type:'recon',target:'zero-based c,r',radius:'integer hex radius',completion:'target region currently observed',authority:'team knowledge only'});
import {planningState} from './fog-policy.mjs';
import {canTransitGarrison,neighbors,inBounds,key,distance,moveCost,reachable,mobileAt,fortAt,canPassFort,isRouted} from './engine.mjs';
import {resolveUnits,commandFrame} from './tactical-units.mjs';
import {parseLocalOrder} from './order-parser.mjs';
import {selectable} from './group-command.mjs';
const active=t=>['active','blocked'].includes(t.status);
export function parseDelegation(text,context){
 if(!/(回合|托管|委托)/.test(text))return null;
 const coord=text.match(/(?:零基)?(?:坐标)?\s*[（(]?\s*(\d+)\s*[,，]\s*(\d+)/),time=text.match(/([0-9]+|[一二三四五六七八九十])\s*(?:个)?回合/),radius=text.match(/(?:半径|允许距离)\s*(\d+)/);
 if(!coord||!time)throw Error('请写明期限和零基坐标，例如“选中部队在5回合内抵达坐标(12,8)附近”。');
 const turns=Number(time[1])||({一:1,二:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9,十:10}[time[1]]);if(turns<1||turns>100)throw Error('托管期限须为1—100回合');
 let subject=text.replace(time[0],'').split(/在|于|抵达|到达|移动|前往/)[0].replace(/请|命令|要求|让|将|托管|委托|内/g,'').trim();if(!subject||/选中|已选|这支军队|这支部队|这群士兵|这些士兵|他们/.test(subject))subject='选中部队';
 let ids;
 if(/^(?:当前)?(?:选中|已选)(?:的)?(?:全部)?(?:部队|单位|士兵|军队)$/.test(subject)){
  ids=[...new Set(context.selectedIds||[])].filter(id=>selectable(context.state.map.units.find(u=>u.id===id),context.team));
  if(!ids.length)throw Error('请先左键选中需要委托的部队');
 }else{
  const parsed=parseLocalOrder(subject+'向东移动一格',context);if(parsed.status!=='local'||parsed.command.clarification||parsed.command.orders.length!==1)throw Error(parsed.command?.clarification||'请明确托管部队');
  ids=resolveUnits(context.state,parsed.command.orders[0].select,context).filter(u=>selectable(u,context.team)).map(u=>u.id);
  if(!ids.length)throw Error('未找到符合条件的己方部队');
 }

 return {ids,target:{c:+coord[1],r:+coord[2]},turns,radius:radius?+radius[1]:/附近/.test(text)?1:0};
}
// A* reads only the faction observation. Each returned destination is also checked
// by reachable(), then committed through the existing Tactical Command API.
export function delegatedDestination(state,unit,target,radius){const view=planningState(state,unit.team),m=view.map,start={c:unit.c,r:unit.r};if(distance(start,target)<=radius)return {arrived:true};
 const heap=[],push=v=>{heap.push(v);let i=heap.length-1;while(i){const p=(i-1)>>1;if(heap[p].f<=v.f)break;heap[i]=heap[p];i=p;}heap[i]=v;},pop=()=>{const v=heap[0],last=heap.pop();if(heap.length){let i=0;while(i*2+1<heap.length){let j=i*2+1;if(j+1<heap.length&&heap[j+1].f<heap[j].f)j++;if(heap[j].f>=last.f)break;heap[i]=heap[j];i=j;}heap[i]=last;}return v;};
 const costs=new Map([[key(start.c,start.r),0]]),parents=new Map();push({...start,g:0,f:distance(start,target)});let end=null,visited=0;
 while(heap.length&&visited++<m.cols*m.rows*4){const p=pop(),pk=key(p.c,p.r);if(p.g!==costs.get(pk))continue;if(distance(p,target)<=radius&&!canTransitGarrison(m,unit,p.c,p.r)){end=p;break;}
  for(const n of neighbors(p.c,p.r)){if(!inBounds(m,n.c,n.r))continue;const occupied=mobileAt(m,n.c,n.r);if(occupied&&occupied.id!==unit.id&&!canTransitGarrison(m,unit,n.c,n.r))continue;if(!canPassFort(unit,fortAt(m,n.c,n.r)))continue;const cost=moveCost(view,{...unit,c:p.c,r:p.r},n.c,n.r);if(!Number.isFinite(cost))continue;const nk=key(n.c,n.r),g=p.g+cost;if(g>=(costs.get(nk)??Infinity))continue;costs.set(nk,g);parents.set(nk,p);push({...n,g,f:g+Math.max(0,distance(n,target)-radius)});}
 }
 if(!end)return {reason:'已知路径暂时受阻；等待下次本方回合重新规划'};
 const path=[];for(let p=end;parents.has(key(p.c,p.r));p=parents.get(key(p.c,p.r)))path.unshift({c:p.c,r:p.r});const legal=reachable(view,unit);let destination=null;for(const p of path){const option=legal.get(key(p.c,p.r));if(option)destination=option;}
 return destination?{destination,path}:{reason:unit.actionsLeft<=0?'本回合行动力已耗尽':'本回合没有可合法到达的路径节点'};
}
export function createDelegatedOrders({getState,api,canAct=()=>true,onChange=()=>{},yieldFrame=()=>new Promise(r=>setTimeout(r,0))}){let running=false;
 const tasks=()=>getState().delegatedOrders??(getState().delegatedOrders=[]);
 function submit({ids,target,turns,radius=1},team){const s=getState();if(!canAct(team)||s.side!==team||s.over||s.deploying)throw Error('现在不能委托本方行动');if(!Number.isInteger(turns)||turns<1||turns>100||!Number.isInteger(radius)||radius<0||radius>20||!Number.isInteger(target.c)||!Number.isInteger(target.r)||!inBounds(s.map,target.c,target.r))throw Error('期限、距离或目标坐标无效');const selected=[...new Set(ids)].filter(id=>selectable(s.map.units.find(u=>u.id===id),team));if(!selected.length)throw Error('没有符合条件的己方地面或舰船部队');if(selected.some(id=>committedTask(s,id)))throw Error(LOCK_REASON);cancelUnits(selected,'新委托覆盖旧任务');const task={id:'task'+((s.orderTaskSerial=(s.orderTaskSerial||0)+1)),team,irrevocable:true,ids:selected,originalIds:[...selected],target:{...target},radius,createdTurn:s.turn,deadlineTurn:s.turn+turns-1,status:'active',progress:{},attempted:{},reason:'已接收'};tasks().push(task);onChange();void tick();return task;}
 function cancelUnits(ids,reason='手动命令优先'){const set=new Set(ids);for(const t of tasks())if(!t.irrevocable&&['active','blocked','paused'].includes(t.status)){const removed=t.ids.filter(id=>set.has(id));if(!removed.length)continue;api.cancel(removed);t.ids=t.ids.filter(id=>!set.has(id));for(const id of removed)t.progress[id]='cancelled';if(!t.ids.length)t.status='cancelled';t.reason=reason;}onChange();}
 function control(id,action,team){const t=tasks().find(t=>t.id===id&&t.team===team);if(t?.irrevocable)return false;if(!t||!['pause','resume','cancel'].includes(action)||!['active','blocked','paused'].includes(t.status))return false;api.cancel(t.ids);t.status=action==='pause'?'paused':action==='cancel'?'cancelled':'active';t.attempted={};t.reason=action==='pause'?'玩家暂停；截止回合仍按原期限计算':action==='cancel'?'玩家取消':'继续执行';onChange();if(action==='resume')void tick();return true;}
 async function tick(){if(running)return;running=true;const s=getState();try{for(const t of tasks()){if(getState()!==s||!active(t)||s.over||s.deploying)continue;if(s.turn>t.deadlineTurn){t.status='failed';t.reason='超过截止回合；未增加行动力或改变目标';onChange();continue;}if(s.side!==t.team||!canAct(t.team))continue;
  for(const id of t.ids){if(!t.ids.includes(id))continue;if(!active(t)||getState()!==s||s.side!==t.team)break;let u=s.map.units.find(u=>u.id===id);if(!selectable(u,t.team)){t.progress[id]='unavailable';continue;}if(distance(u,t.target)<=t.radius){t.progress[id]='arrived';continue;}t.progress[id]='marching';const stamp=`${s.turn}:${u.actionsLeft}:${u.c}:${u.r}`;if(t.attempted[id]===stamp)continue;t.attempted[id]=stamp;
   let steps=0;while(u.actionsLeft>0&&active(t)&&t.ids.includes(id)&&canAct(t.team)&&s.side===t.team&&!s.over&&getState()===s&&steps++<4){const plan=delegatedDestination(s,u,t.target,t.radius);if(plan.arrived){t.progress[id]='arrived';break;}if(!plan.destination){t.reason=plan.reason;break;}const before=u.actionsLeft,record=api.submit({v:1,confidence:1,clarification:'',orders:[{select:{scope:'all',ids:[id]},steps:[{type:'move',position:{c:plan.destination.c,r:plan.destination.r}}]}]},{team:t.team,actor:'delegate'});await record.promise;if(getState()!==s||!active(t)||!t.ids.includes(id))break;if(distance(u,t.target)<=t.radius){t.progress[id]='arrived';break;}if(before===u.actionsLeft){const contact=plan.path[0];if(contact&&distance(u,contact)===1){const probe=api.submit({v:1,confidence:1,clarification:'',orders:[{select:{scope:'all',ids:[id]},steps:[{type:'move',position:contact}]}]},{team:t.team,actor:'delegate'});await probe.promise;}if(before===u.actionsLeft){t.reason='实际行军受阻；根据新情报下回合重规划';break;}}await yieldFrame();}
   t.attempted[id]=`${s.turn}:${u.actionsLeft}:${u.c}:${u.r}`;await yieldFrame();
  }
  if(active(t)){if(t.ids.every(id=>t.progress[id]==='arrived')){t.status='completed';t.reason='当前受托部队已抵达允许范围'+(Object.values(t.progress).includes('cancelled')?'；其他部队已由玩家接管':'');}else if(t.ids.every(id=>t.progress[id]==='unavailable')){t.status='failed';t.reason='受托部队已阵亡、溃逃或失去控制';}else t.reason=t.reason==='已接收'?'等待下一本方回合继续行军':t.reason;}onChange();
 }}finally{running=false;}}
 return {submit,tick,control,cancelUnits,get tasks(){return tasks()},get running(){return running}};
}
export function validateDelegatedOrders(s){if(s.delegatedOrders===undefined)return;if(!Array.isArray(s.delegatedOrders)||s.delegatedOrders.length>10000)throw Error('委托任务存档无效');for(const t of s.delegatedOrders)if(!t||typeof t.id!=='string'||!t.progress||!t.attempted||typeof t.progress!=='object'||typeof t.attempted!=='object'||!Number.isInteger(t.createdTurn)||t.createdTurn<1||!['egypt','coalition'].includes(t.team)||!Array.isArray(t.ids)||t.ids.some(id=>!s.map.units.some(u=>u.id===id&&u.team===t.team))||!Number.isInteger(t.target?.c)||!Number.isInteger(t.target?.r)||!inBounds(s.map,t.target?.c,t.target?.r)||!Number.isInteger(t.deadlineTurn)||t.deadlineTurn<t.createdTurn||!Number.isInteger(t.radius)||t.radius<0||t.radius>20||!['active','blocked','paused','failed','completed','cancelled'].includes(t.status))throw Error('委托任务数据无效');}
