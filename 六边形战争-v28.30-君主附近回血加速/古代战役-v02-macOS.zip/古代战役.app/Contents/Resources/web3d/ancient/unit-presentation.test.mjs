import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as T from '../vendor/three/three.module.js';
import {createUnitModel as authored} from './models.mjs';
import {createUnitModel,applyUnitProportions,UNIT_PROPORTIONS,unitBaseScale} from './unit-presentation.mjs';
import {visualProfile} from './visual-profiles.mjs';
import {animateFullModel} from './full-models.mjs';
import {animateV02} from './models-v02.mjs';
import {createUnitAnimator} from './unit-animation.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {neighbors} from './engine.mjs';
const catalog=JSON.parse(fs.readFileSync(new URL('./unit_animation_catalog.json',import.meta.url))).units.filter(x=>x.id!=='fort'&&x.id!=='scout');
const unit=(kind,team='egypt',extra={})=>({id:'u1',kind,team,c:3,r:4,hp:100,morale:1,...extra});
const meshes=root=>{const out=[];root.traverse(o=>{if(o.isMesh)out.push(o)});return out;};
const close=(a,b,label='')=>assert.ok(Math.abs(a-b)<1e-7,`${label}: ${a} vs ${b}`);
const base=m=>m.children.filter(c=>c.userData.unitBase);
const levels=m=>m.children.filter(c=>['near','far','unit-body'].includes(c.name));

test('all 67 troop bases use their displayed role size, retaining thickness and faction materials',()=>{
 assert.equal(catalog.length,67);
 for(const entry of catalog)for(const team of ['egypt','coalition']){
  const u=unit(entry.id,team),scenario=entry.contexts[0]?.scenarioId,m=authored(u,scenario),parts=base(m),original=parts.map(o=>({scale:o.scale.clone(),pos:o.position.clone(),material:o.material}));assert.equal(parts.length,5,entry.id);
  const profile=visualProfile(u,scenario),scale=unitBaseScale(profile);applyUnitProportions(m,profile);
  parts.forEach((o,i)=>{const b=original[i];close(o.scale.x,b.scale.x*scale);close(o.scale.z,b.scale.z*scale);close(o.scale.y,b.scale.y);close(o.position.x,b.pos.x*scale);close(o.position.z,b.pos.z*scale);close(o.position.y,b.pos.y);assert.equal(o.material,b.material);});
 }
});
test('infantry and cavalry retain earlier proportions plus a further 20 percent in both LODs around the unchanged standing plane',()=>{
 for(const [kind,scenario]of [['heavy','china_changping'],['archer','troy'],['romanLegion','cannae'],['cavalry','china_longxi'],['pharaoh','gaugamela']]){
  const u=unit(kind),m=authored(u,scenario),bounds=levels(m).map(l=>new T.Box3().setFromObject(l).getSize(new T.Vector3()));applyUnitProportions(m,visualProfile(u,scenario));
  levels(m).forEach((l,i)=>{const size=new T.Box3().setFromObject(l).getSize(new T.Vector3());for(const k of ['x','y','z'])close(size[k],bounds[i][k]*UNIT_PROPORTIONS.soldier,kind);close(l.scale.y,UNIT_PROPORTIONS.soldier);close(l.position.y+l.scale.y*.24,.24,'ground anchor');});
 }
});
test('large models keep height growth, bounded horizontal fit and enlarged family bases',()=>{
 for(const [kind,scenario]of [['chinaHeavyChariot','china_chengpu'],['warship','troy'],['warElephant','gaugamela'],['chinaFireOx','china_tian_dan'],['siegeRam','china_changping'],['defenseTower','carthage'],['supplyWagon','china_longxi']]){
  const m=createUnitModel(unit(kind),scenario);for(const l of levels(m)){assert.equal(l.scale.y,1.2);assert.ok(l.scale.x>0&&l.scale.x<=1.2);assert.equal(l.scale.x,l.scale.z);assert.equal(l.position.y,0);}assert.ok(base(m).every(o=>o.scale.x===unitBaseScale(visualProfile(unit(kind),scenario))));
 }
});
test('proportion adjustment is idempotent and allocates no meshes, geometry or materials',()=>{
 for(const kind of ['heavy','cavalry','chinaHeavyChariot']){
  const u=unit(kind),before=JSON.stringify(u),m=authored(u,'china_changping'),items=meshes(m),resources=items.map(o=>[o.geometry,o.material]),profile=visualProfile(u,'china_changping');applyUnitProportions(m,profile);const state=JSON.stringify(levels(m).map(o=>[o.position.toArray(),o.scale.toArray()]));applyUnitProportions(m,profile);assert.equal(JSON.stringify(levels(m).map(o=>[o.position.toArray(),o.scale.toArray()])),state);assert.deepEqual(meshes(m),items);items.forEach((o,i)=>{assert.equal(o.geometry,resources[i][0]);assert.equal(o.material,resources[i][1]);});assert.equal(JSON.stringify(u),before);
 }
 const a=createUnitModel(unit('heavy'),'china_changping'),b=createUnitModel(unit('heavy'),'china_changping');assert.equal(meshes(a.getObjectByName('near'))[0].geometry,meshes(b.getObjectByName('near'))[0].geometry);
});
test('pose resets, movement, attacks, rout and LOD transitions preserve the new full-model proportions',()=>{
 for(const [kind,scenario]of [['heavy','china_changping'],['archer','troy'],['cavalry','china_longxi'],['greekHoplite','mantinea']]){
  const m=createUnitModel(unit(kind),scenario);
  for(const distance of [30,150,30])for(const action of ['none','thrust','bow'])for(const progress of [0,.3,.6,1]){
   animateFullModel(m,progress*1000,{moving:true,routed:true,distance,action,progress});for(const l of levels(m)){close(l.scale.x,UNIT_PROPORTIONS.soldier);close(l.position.y,.24*(1-UNIT_PROPORTIONS.soldier));}m.updateMatrixWorld(true);m.traverse(o=>assert.ok(o.matrixWorld.elements.every(Number.isFinite)));
  }
 }
});
test('phase-one and legacy display variants retain the same base/body proportions',()=>{
 for(const options of [{phase1:true},{legacy:true}])for(const kind of ['heavy','cavalry']){
  const m=createUnitModel(unit(kind),'china_chengpu',options);assert.ok(base(m).every(o=>o.scale.x===unitBaseScale(visualProfile(unit(kind),'china_chengpu'))));for(const distance of [20,150,20]){if(options.phase1)animateV02(m,300,{moving:true,hit:1,distance});for(const l of levels(m)){close(l.scale.x,UNIT_PROPORTIONS.soldier);close(l.position.y,.24*(1-UNIT_PROPORTIONS.soldier));}assert.ok(levels(m).length>0);}
 }
});
test('resized pieces keep base and body on the same interpolated movement path',()=>{
 for(const [kind,options] of [['heavy',{}],['cavalry',{}],['chinaHeavyChariot',{}],['siegeRam',{}],['supplyWagon',{}],['heavy',{phase1:true}],['cavalry',{phase1:true}]]){
  const u=unit(kind),m=createUnitModel(u,'china_chengpu',options),scene=new T.Group(),camera=new T.PerspectiveCamera(),anim=createUnitAnimator(),height=p=>p.c*.15+p.r*.08;
  const world=p=>{const w=offsetToWorld(p.c,p.r);return new T.Vector3(w.x,height(p)+.08,w.z);};m.userData.unitId=u.id;m.scale.setScalar(1.16);m.position.copy(world(u));scene.add(m);anim.setHeightResolver(height);anim.observe([u],0,{scenarioId:'china_chengpu'});const next=neighbors(u.c,u.r)[0];anim.move(u.id,u,[next],0);anim.observe([{...u,...next}],1);m.position.copy(world(next));
  for(const time of [0,45,90,200,339,340,500]){camera.position.set(time>200?200:0,20,30);anim.update(scene,camera,time);m.updateMatrixWorld(true);const blend=Math.max(0,Math.min(1,(time-90)/250)),expected=world(u).lerp(world(next),blend);assert.ok(m.position.distanceTo(expected)<1e-7);const foot=base(m)[0].getWorldPosition(new T.Vector3()),body=levels(m)[0].getWorldPosition(new T.Vector3());close(foot.x,body.x);close(foot.z,body.z);close(levels(m)[0].scale.x,['infantry','cavalry'].includes(visualProfile(u,'china_chengpu').family)?UNIT_PROPORTIONS.soldier:UNIT_PROPORTIONS.body);}
 }
});
test('scaled formations keep horizontal spears and raised shields, and gray hit feedback restores materials',()=>{
 const u=unit('romanLegion','egypt',{formed:true,facing:3}),saved=JSON.stringify(u),m=createUnitModel(u,'cannae'),parts=meshes(m),original=parts.map(o=>o.material);
 animateFullModel(m,300,{moving:true,hit:1});assert.ok(parts.every(o=>o.material.userData.hitFlash));const soldier=m.getObjectByName('near').getObjectByName('soldier');assert.ok(soldier.getObjectByName('shield').position.y>2.65);const tool=soldier.getObjectByName('formation-spear');assert.ok(tool);close(tool.rotation.x,Math.PI/2);animateFullModel(m,300,{moving:true,hit:0});parts.forEach((o,i)=>assert.equal(o.material,original[i]));assert.equal(JSON.stringify(u),saved);close(m.getObjectByName('near').scale.y,UNIT_PROPORTIONS.soldier);
});


test('infantry, cavalry and heavy equipment have visibly different physical footprints within one hex',()=>{
 const expected=[['heavy','china_changping',1],['archer','troy',1],['greekHoplite','mantinea',1],['cavalry','china_longxi',1.04],['chinaHeavyChariot','china_chengpu',1.08],['siegeRam','china_changping',1.08],['romanOnager','carthage',1.08],['siegeTower','carthage',1.08],['supplyWagon','china_longxi',1.08],['warship','troy',1.08]];
 const widths=[];
 for(const [kind,scenario,scale]of expected){const u=unit(kind),saved=JSON.stringify(u),m=createUnitModel(u,scenario),disk=base(m)[0],bounds=new T.Box3().setFromObject(disk),width=bounds.max.x-bounds.min.x;assert.ok(Math.abs(width-4.84*scale)<1e-6,kind+' Float32 footprint');close(disk.scale.y,1);assert.ok(width<=4.84*1.08+1e-6);widths.push(width);assert.equal(JSON.stringify(u),saved);}
 assert.ok(widths[0]<widths[3]&&widths[3]<widths[4]);
});
test('dismounted commanders and riders use infantry bases without changing rule state',()=>{
 for(const [kind,scenario] of [['cavalry','china_longxi'],['pharaoh','gaugamela'],['chariot','troy']]){
  const u=unit(kind),mounted=createUnitModel(u,scenario),foot={...u,onFoot:true},saved=JSON.stringify(foot),dismounted=createUnitModel(foot,scenario);assert.ok(base(mounted)[0].scale.x>1);assert.equal(base(dismounted)[0].scale.x,1);assert.equal(dismounted.getObjectByName('near').scale.y,UNIT_PROPORTIONS.soldier);assert.equal(JSON.stringify(foot),saved);
 }
});
