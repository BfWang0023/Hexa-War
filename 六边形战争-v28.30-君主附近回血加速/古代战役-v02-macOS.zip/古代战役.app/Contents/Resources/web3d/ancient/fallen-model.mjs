// Static, volumetric, authored body silhouettes. No animation/physics or simulation mutation.
import * as T from '../vendor/three/three.module.js';
// A static, genuinely three-dimensional distance LOD. Cluster only the baked corpse,
// never the live model. Degenerate faces disappear while silhouette/colour remain.
export function simplifyFallenModel(source,cell=.24){
 const p=source.attributes.position,c=source.attributes.color,clusters=new Map(),keys=[];
 for(let i=0;i<p.count;i++){const key=[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v/cell)).join(',');keys.push(key);let a=clusters.get(key);if(!a)clusters.set(key,a=[0,0,0,0]);a[0]+=p.getX(i);a[1]+=p.getY(i);a[2]+=p.getZ(i);a[3]++;}
 for(const a of clusters.values())for(let j=0;j<3;j++)a[j]/=a[3];
 const pos=[],colors=[],faces=new Set();
 for(let i=0;i<p.count;i+=3){const ks=keys.slice(i,i+3);if(new Set(ks).size!==3)continue;const face=[...ks].sort().join('/');if(faces.has(face))continue;faces.add(face);for(let j=0;j<3;j++){pos.push(...clusters.get(ks[j]).slice(0,3));colors.push(c.getX(i+j),c.getY(i+j),c.getZ(i+j));}}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function bakeSunkMarker(){
 const pieces=[],color=[];for(const angle of [Math.PI/4,-Math.PI/4]){const g=new T.BoxGeometry(2.2,.045,.22).toNonIndexed();g.rotateY(angle);const a=g.attributes.position;for(let i=0;i<a.count;i++){pieces.push(a.getX(i),.06+a.getY(i),a.getZ(i));color.push(.35,.24,.17);}g.dispose();}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pieces,3));g.setAttribute('color',new T.Float32BufferAttribute(color,3));g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function bakeFallenModel(model,pose=0){
 const level=model.getObjectByName('near')||model,visual=level.getObjectByName('visual')||level;
 model.rotation.set(0,0,0);for(const child of model.children)if(child!==level)child.visible=false;level.visible=true;
 model.traverse(o=>{if(o.userData.unitBase||o.name==='casualty-rein')o.visible=false;});model.updateMatrixWorld(true);
 const persons=[];visual.traverse(o=>{if(['soldier','rider'].includes(o.name))persons.push(o);});
 // Detach riders before laying mounts down. Keep their authored dimensions.
 for(const o of persons)if(o.parent!==visual)visual.attach(o);
 const bodies=[...visual.children].filter(o=>['horse','beast-body','supply-assembly'].includes(o.name));
 const rand=i=>{const x=Math.sin((i+1)*127.1+(pose+1)*311.7)*43758.5453;return x-Math.floor(x);};
 const ground=o=>{model.updateMatrixWorld(true);const b=new T.Box3().setFromObject(o),sc=new T.Vector3();o.parent.getWorldScale(sc);o.position.y-=(b.min.y-.04)/sc.y;};
 const dropped=[];
 for(const [i,person] of persons.entries()){
  const arm=person.getObjectByName('shield');let looseShield=null;
  if(arm){const parts=arm.children.filter(o=>o.isMesh||o.name==='chinese-shield');if(parts.length){looseShield=new T.Group();looseShield.name='fallen-shield';arm.add(looseShield);model.updateMatrixWorld(true);for(const part of parts)looseShield.attach(part);}}
  const tools=looseShield?[looseShield]:[];person.traverse(o=>{if(['melee-tool','ranged-tool'].includes(o.name))tools.push(o);});
  for(const [j,tool]of tools.entries()){visual.attach(tool);tool.visible=true;tool.rotation.order='YXZ';tool.rotation.set(Math.PI/2,rand(i*7+j+20)*Math.PI*2,0);tool.position.x+=(rand(i*3+j+40)-.5)*2.8;tool.position.z+=(rand(i*3+j+50)-.5)*2.8;ground(tool);dropped.push(tool);}
  person.position.x+=(rand(i*3)-.5)*2;person.position.z+=(rand(i*3+1)-.5)*2;
  person.rotation.set((rand(i*3+2)>.5?1:-1)*Math.PI/2,0,rand(i*3+3)*Math.PI*2);ground(person);
 }
 for(const o of bodies){if(o.name==='supply-assembly')continue;o.rotation.x+=pose?Math.PI/2:-Math.PI/2;ground(o);}
 const family=model.userData.profile?.family;
 const wreck=['siege','wagon','defenseTower','trojanHorse'].includes(family)||['siegeRam','siegeTower','romanOnager'].includes(model.userData.kind);
 if(wreck){const fragments=[];visual.traverse(o=>{if(!o.isMesh||!o.visible||o.userData.unitBase)return;let p=o.parent;while(p&&p!==visual){if(persons.includes(p)||dropped.includes(p))return;p=p.parent;}fragments.push(o);});for(const [i,o]of fragments.entries()){visual.attach(o);o.position.x+=(rand(i+91)-.5)*2.8;o.position.z+=(rand(i+121)-.5)*2.8;o.rotation.set(rand(i+161)*2,rand(i+191)*6.28,rand(i+221)*2);o.scale.y*=.45;ground(o);}}
 model.updateMatrixWorld(true);const reinKeys=new Set(visual.userData.casualtyReins||[]),visualInverse=visual.matrixWorld.clone().invert();const pos=[],norm=[],colors=[],normalMatrix=new T.Matrix3(),v=new T.Vector3(),n=new T.Vector3();
 level.traverseVisible(o=>{if(!o.isMesh||o.userData.unitBase)return;let g=o.geometry.index?o.geometry.toNonIndexed():o.geometry;const p=g.attributes.position,no=g.attributes.normal,co=g.attributes.color,mat=Array.isArray(o.material)?o.material:[o.material];normalMatrix.getNormalMatrix(o.matrixWorld);
  for(let i=0;i<p.count;i++){if(reinKeys.size){const base=i-i%3,points=[];for(let j=0;j<3;j++){const q=new T.Vector3().fromBufferAttribute(p,base+j).applyMatrix4(o.matrixWorld).applyMatrix4(visualInverse);points.push(q.toArray().map(x=>Math.round(x*10000)).join(','));}if(reinKeys.has(points.sort().join('/')))continue;}v.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld);pos.push(v.x,v.y,v.z);n.fromBufferAttribute(no,i).applyMatrix3(normalMatrix).normalize();norm.push(n.x,n.y,n.z);const material=mat[g.groups.find(x=>i>=x.start&&i<x.start+x.count)?.materialIndex||0],c=(material.color||new T.Color(0xffffff)).clone();if(co)c.multiply(new T.Color().fromBufferAttribute(co,i));c.multiplyScalar(.88);colors.push(c.r,c.g,c.b);}if(g!==o.geometry)g.dispose();});
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(pos,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(norm,3));geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));if(wreck)geometry.scale(1,.5,1);geometry.computeBoundingBox();geometry.translate(0,.035-geometry.boundingBox.min.y,0);geometry.computeBoundingBox();geometry.computeBoundingSphere();
 return geometry;
}
