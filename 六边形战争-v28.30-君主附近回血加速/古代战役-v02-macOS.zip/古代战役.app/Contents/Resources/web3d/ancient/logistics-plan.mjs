import {roadPriority} from './road-priority.mjs';
import {authoritativeState,planningState} from './fog-policy.mjs';
import {delegatedDestination} from './known-route.mjs';
import {distance,inBounds,tile,TERRAIN,move,replenishConvoy,SUPPLY_WAGON_CAPACITY,SATIETY_PER_SUPPLY,isRouted,fortAt,mobileAt,logisticsSoldier,isWagonWater,feedSupply,carriedRationCapacity} from './engine.mjs';
import {committedTask} from './order-lock.mjs';
const key=p=>`${p.c},${p.r}`,food=u=>(u.supplyStock||0)*SATIETY_PER_SUPPLY+(u.supplyCredit||0);
function setFood(u,n){u.supplyStock=Math.floor(n/SATIETY_PER_SUPPLY);u.supplyCredit=n%SATIETY_PER_SUPPLY;}
export function managedTransport(s,id){const p=s.logisticsPlan;return p?.status!=='cancelled'&&p?.carts?.some(c=>c.id===id&&c.phase!=='lost');}
export function planView(s,team){const p=s.logisticsPlan;return p?.team===team?structuredClone(p):null;}
export function updateLogisticsPlan(state,team,change){const s=authoritativeState(state);if(!s.map.logistics)throw Error('本战役没有粮草运输机制');if(!['egypt','coalition'].includes(team))throw Error('阵营无效');if(!change||typeof change!=='object')throw Error('请明确运输修改');const old=s.logisticsPlan;if(old&&old.team!==team)throw Error('已有另一阵营的有效运输总指令');
 const p=old?structuredClone(old):{version:0,team,status:'active',source:null,nodes:[],carts:[],serial:0,purchased:0,delivered:0};const view=planningState(s,team).map;
 if(change.source){if(!s.map.logistics.depots[team]?.some(d=>key(d)===key(change.source)))throw Error('请选择己方粮仓');p.source={c:change.source.c,r:change.source.r};}
 p.source??=s.map.logistics.depots[team]?.[0];if(!p.source)throw Error('没有可用粮仓');
 for(const q of change.points||[]){if(!Number.isInteger(q.c)||!Number.isInteger(q.r)||!inBounds(view,q.c,q.r))throw Error('交付坐标不在地图内');if(view.unknown?.[q.r*view.cols+q.c])throw Error('请先侦察交付位置');const t=tile(view,q.c,q.r);if(t.terrain===TERRAIN.SEA)throw Error('交付点须位于可供粮车抵达的陆地或河岸');const wall=fortAt(view,q.c,q.r);if(wall?.hp>0&&wall.team!==team)throw Error('不能在已知敌方工事上设置交付点');let n=p.nodes.find(n=>key(n)===key(q));if(!n){n={c:q.c,r:q.r,arrivals:0,active:true,interval:1,priority:1,safety:3,returnThreshold:0,nextDispatch:s.turn};p.nodes.push(n);}n.active=true;for(const f of ['interval','priority','safety','returnThreshold'])if(q[f]!==undefined){if(!Number.isFinite(q[f])||q[f]<0||q[f]>100||f==='interval'&&q[f]<1)throw Error('频率、优先级或阈值无效');n[f]=q[f];}}
 if(change.safety!==undefined){if(!Number.isInteger(change.safety)||change.safety<0||change.safety>100)throw Error('安全储备回合无效');for(const n of p.nodes)if(n.active)n.safety=change.safety;}
 if(change.remove)for(const n of p.nodes)if(change.remove.some(q=>key(q)===key(n)))n.active=false;
 if(change.status){if(!['active','paused','returning','cancelled'].includes(change.status))throw Error('运输状态无效');p.status=change.status;}
 if(change.doubleFrequency){const n=p.nodes.find(n=>key(n)===key(change.doubleFrequency)&&n.active);if(!n)throw Error('未找到该交付点');if(n.interval>1)n.interval=Math.max(1,n.interval/2);else n.burst=Math.min(10,(n.burst||1)*2);}
 // Identical resubmission is idempotent, including the version number.
 if(old&&JSON.stringify({...p,version:0})===JSON.stringify({...old,version:0}))return old;
 p.version++;s.logisticsPlan=p;return p;
}
export function parseLogisticsOrder(text){if(!/运粮|运输粮|运送粮|交付点|驻留点|驻留补给|运输计划|所有运输|运输频率|补给频率|补给线|粮草储备/.test(text))return null;const points=[...text.matchAll(/[（(]?\s*(\d+)\s*[,，]\s*(\d+)\s*[）)]?/g)].map(m=>({c:+m[1],r:+m[2]}));if(/停止|暂停/.test(text))return {status:'paused'};if(/恢复/.test(text))return {status:'active'};if(/所有.*返|全部.*返/.test(text))return {status:'returning'};if(/取消|删除/.test(text)&&points.length)return {remove:points};if(/频率.*(?:一倍|两倍|2倍)/.test(text)&&points[0])return {doubleFrequency:points[0]};const interval=text.match(/每\s*(\d+)\s*回合/),safety=text.match(/(?:至少|保持).*?(\d+)\s*回合/);if(!points.length&&safety)return {safety:+safety[1]};if(!points.length)throw Error('请给出交付坐标，例如“从后方粮仓向(12,8)、(18,11)持续运输粮食”');const source=text.match(/从[^（(\d]*[（(]?\s*(\d+)\s*[,，]\s*(\d+)\s*[）)]?\s*(?:向|到)/);if(source)points.shift();return {...(source?{source:{c:+source[1],r:+source[2]}}:{}),points:points.map(p=>({...p,...(interval?{interval:+interval[1]}:{}),...(safety?{safety:+safety[1]}:{})}))};}
function reserveFor(s,u,path=[]){const m=planningState(s,u.team).map;const travel=path.reduce((n,p)=>n+(isWagonWater(m,u,p.c,p.r)?0:(tile(m,p.c,p.r)?.terrain&TERRAIN.MOUNTAIN)?2:1),0);return Math.floor(((u.supplyTravel||0)+travel)/6)*SATIETY_PER_SUPPLY;}
// Stationary physical carts continue to supply soldiers even when movement is paused.
export function supplyLogisticsPlan(state,team,supplied=new Set(),onlyCart=null){
 const s=authoritativeState(state),p=s.logisticsPlan;if(!p||!s.map.logistics||p.team!==team)return supplied;

 for(const c of p.carts){if(onlyCart&&c.id!==onlyCart)continue;const u=s.map.units.find(u=>u.id===c.id&&u.team===team&&u.hp>0&&!u.aboard&&!isRouted(u));if(!u||!managedTransport(s,u.id)||food(u)<=0)continue;
 if(!s.map.units.some(v=>v.team===team&&logisticsSoldier(v)&&!isRouted(v)&&distance(u,v)<=2&&((v.hunger||0)>0||(v.fedTurns||0)<carriedRationCapacity(v))))continue;
 feedSupply(s,team,u,requested=>{const amount=Math.min(Math.max(0,food(u)),Math.max(0,requested));setFood(u,food(u)-amount);c.supplied=(c.supplied||0)+amount;p.supplied=(p.supplied||0)+amount;return amount;},supplied,true);
 }
 return supplied;
}
export function tickLogistics(state){const s=authoritativeState(state),p=s.logisticsPlan;if(!p||!s.map.logistics||p.team!==s.side||s.over||s.deploying||p.status==='cancelled')return [];const events=[];
 // One transport cycle per own actionable turn; repeated UI timers cannot double unload.
 const stamp=`${s.turn}:${s.side}:${p.version}`;if(p.lastTick===stamp)return events;p.lastTick=stamp;
 const known=planningState(s,p.team).map,sourceValid=s.map.logistics.depots[p.team]?.some(d=>key(d)===key(p.source));if(!sourceValid){p.reason='指定粮仓失效，请修改来源';return events;}
 const available=s.map.units.filter(u=>u.team===p.team&&u.kind==='supplyWagon'&&u.hp>0&&!u.aboard&&!isRouted(u)&&!committedTask(s,u.id));
 for(const c of [...p.carts].sort((a,b)=>roadPriority(s,available.find(u=>u.id===b.id))-roadPriority(s,available.find(u=>u.id===a.id)))){const u=available.find(u=>u.id===c.id);if(!u)c.phase='lost';}
 const occupied=new Set(p.carts.filter(c=>c.phase!=='lost').map(c=>c.id));
 if(p.status==='active')for(const u of available)if(!occupied.has(u.id)){p.initialCargo=(p.initialCargo||0)+food(u);const prior=p.carts.find(c=>c.id===u.id),node=food(u)>0&&distance(u,p.source)>1?p.nodes.filter(n=>n.active).sort((a,b)=>p.carts.filter(c=>c.node===key(a)&&['outbound','supplying'].includes(c.phase)).length-p.carts.filter(c=>c.node===key(b)&&['outbound','supplying'].includes(c.phase)).length||b.priority-a.priority||distance(u,a)-distance(u,b))[0]:null,assignment={phase:node?'outbound':'returning',node:node?key(node):null};if(prior)Object.assign(prior,assignment);else p.carts.push({id:u.id,...assignment});}
 for(const n of p.nodes)if(n.dispatchTurn!==s.turn){n.dispatchTurn=s.turn;n.dispatched=0;}
 const nodes=p.nodes.filter(n=>n.active).sort((a,b)=>b.priority-a.priority||a.nextDispatch-b.nextDispatch);
 for(const c of [...p.carts].sort((a,b)=>roadPriority(s,available.find(u=>u.id===b.id))-roadPriority(s,available.find(u=>u.id===a.id)))){const u=available.find(u=>u.id===c.id);if(!u)continue;let n=p.nodes.find(n=>key(n)===c.node);if(p.status==='active'&&n?.active&&food(u)>0&&c.phase==='returning'&&c.reason==='可交付余粮不足，返回粮仓'){c.phase=distance(u,n)<=1?'supplying':'outbound';c.reason='仍有车载粮食，继续补给';}if(p.status==='returning'||n&&!n.active){c.phase='returning';c.reason='按更新指令返回粮仓';}if(p.status==='paused')continue;
  if(c.phase==='waiting'||c.phase==='returning'){
   if(distance(u,p.source)<=1){c.phase='waiting';if(p.status==='returning')continue;n=nodes.find(n=>{if(n.nextDispatch>s.turn||(n.dispatched||0)>=(n.burst||1))return false;const stationed=p.carts.filter(c=>c.node===key(n)&&['outbound','supplying'].includes(c.phase));const meals=stationed.reduce((sum,c)=>sum+food(available.find(u=>u.id===c.id)),0);return !stationed.length||n.estimatedConsumption>0&&meals<n.estimatedConsumption*n.safety;});if(!n)continue;const route=delegatedDestination(s,u,n,1,{transport:true});if(!route.path&&!route.arrived){c.reason='已知路线受阻';continue;}const before=food(u);if(before<SUPPLY_WAGON_CAPACITY*SATIETY_PER_SUPPLY){const r=replenishConvoy(s,u.id);if(r.ok)p.purchased+=food(u)-before;}if(food(u)<=reserveFor(s,u,route.path)*2){c.reason='返程保障粮或采购资金不足';continue;}c.node=key(n);c.phase='outbound';n.dispatched=(n.dispatched||0)+1;if(n.dispatched>=(n.burst||1))n.nextDispatch=s.turn+n.interval;c.departure=s.turn;c.reason='前送';}
  }
  supplyLogisticsPlan(s,p.team,new Set(),u.id);
  if(['outbound','supplying'].includes(c.phase)&&food(u)<=0&&!(n?.stock>0&&distance(u,n)<=1)){c.phase='returning';c.reason='车载粮食已耗尽，返回粮仓';}
  const goal=['outbound','supplying'].includes(c.phase)?n:p.source;if(!goal)continue;
  for(let step=0;u.actionsLeft>0&&step<2&&distance(u,goal)>1;step++){const plan=delegatedDestination(s,u,goal,1,{transport:true});c.route=plan.path||[];if(!plan.destination){c.reason='已知路线受阻或行动力不足';break;}const cargoBefore=food(u),suppliedBefore=c.supplied||0;const result=move(s,u.id,plan.destination.c,plan.destination.r);p.travelLoss=(p.travelLoss||0)+Math.max(0,cargoBefore-food(u)-((c.supplied||0)-suppliedBefore));if(!result.ok){c.reason='实际运输受阻，下一本方回合重规划';break;}events.push({type:'move',id:u.id,path:result.path});supplyLogisticsPlan(s,p.team,new Set(),u.id);if(['outbound','supplying'].includes(c.phase)&&food(u)<=0)break;}
  if((c.phase==='outbound'||c.phase==='supplying')&&distance(u,n)<=1){
   if(c.phase==='outbound'){c.phase='supplying';n.arrivals=(n.arrivals||0)+1;c.reason='驻留补给：粮食保留在车上';events.push({type:'station',id:u.id});}
   // Compatibility only: recover old v28.21 depot cargo into a real nearby cart.
   // New plans never create ground inventories.
   if(n.stock>0){const amount=Math.min(n.stock,SUPPLY_WAGON_CAPACITY*SATIETY_PER_SUPPLY-food(u));n.stock-=amount;setFood(u,food(u)+amount);p.recoveredLegacy=(p.recoveredLegacy||0)+amount;}
   supplyLogisticsPlan(s,p.team,new Set(),u.id);
   if(food(u)<=0){c.phase='returning';c.reason='车载粮食已耗尽，返回粮仓';}
  }
 }
 supplyLogisticsPlan(s,p.team,new Set());
 for(const c of p.carts)if(['outbound','supplying'].includes(c.phase)&&food(available.find(u=>u.id===c.id))<=0){c.phase='returning';c.reason='车载粮食已耗尽，返回粮仓';}
 for(const n of p.nodes){const carts=p.carts.filter(c=>c.node===key(n)&&c.phase!=='lost');n.inTransit=carts.filter(c=>c.phase==='outbound').reduce((a,c)=>a+food(available.find(u=>u.id===c.id)),0);const demand=s.map.units.filter(u=>u.team===p.team&&logisticsSoldier(u)&&!isRouted(u)&&distance(u,n)<=3).length;n.estimatedConsumption=demand;n.stationedFood=carts.filter(c=>c.phase==='supplying').reduce((sum,c)=>sum+food(available.find(u=>u.id===c.id)),0);n.sustainableTurns=demand?n.stationedFood/demand:null;const route=available[0]?delegatedDestination(s,available[0],n,1,{transport:true}):null;n.estimatedOneWayTurns=route?.path?Math.max(1,Math.ceil(route.path.length/4)):null;n.minimumVehicles=demand&&n.estimatedOneWayTurns?Math.ceil(demand*(n.estimatedOneWayTurns*2+1)/Math.max(1,120)):0;n.vehicleGap=Math.max(0,n.minimumVehicles-carts.length);}
 p.reason=available.length?'粮车优先补给士兵；到指定位置驻留，车载粮食为0才自动返程':'缺少可调度的己方粮车';return events;
}
export function validateLogisticsPlan(s){const p=s.logisticsPlan;if(p===undefined)return;if(!s.map.logistics||!p||!['egypt','coalition'].includes(p.team)||!Number.isInteger(p.version)||p.version<1||!['active','paused','returning','cancelled'].includes(p.status)||!Array.isArray(p.nodes)||p.nodes.length>100||!Array.isArray(p.carts)||p.carts.length>1000)throw Error('运输计划存档无效');if(!p.source||!Number.isInteger(p.source.c)||!Number.isInteger(p.source.r)||!inBounds(s.map,p.source.c,p.source.r)||!Number.isInteger(p.purchased)||p.purchased<0||!Number.isInteger(p.delivered)||p.delivered<0)throw Error('运输来源或账目无效');const coords=new Set(),ids=new Set();for(const n of p.nodes){if(!inBounds(s.map,n.c,n.r)||!Number.isInteger(n.c)||!Number.isInteger(n.r)||(n.stock!==undefined&&(!Number.isInteger(n.stock)||n.stock<0))||coords.has(key(n))||!Number.isFinite(n.interval)||n.interval<1||!Number.isFinite(n.returnThreshold)||n.returnThreshold<0)throw Error('驻留位置或旧版库存无效');coords.add(key(n));}for(const c of p.carts){if(ids.has(c.id)||!s.map.units.some(u=>u.id===c.id&&u.kind==='supplyWagon')||!['outbound','supplying','returning','waiting','lost'].includes(c.phase))throw Error('运输车辆状态无效');ids.add(c.id);}}
