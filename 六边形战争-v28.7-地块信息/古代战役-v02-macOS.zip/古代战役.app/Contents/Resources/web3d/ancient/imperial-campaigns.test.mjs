import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { CAMPAIGN_CATALOG } from './campaign-catalog.mjs';
import { IMPERIAL_CAMPAIGNS, makeImperialMap } from './imperial-campaigns.mjs';
import { makeChinaMap } from './china-campaigns.mjs';
import { TERRAIN, KUNYANG_METEORS, KUNYANG_CITY_OBJECTIVE, CAMPAIGN_FINANCES, aiTurn, attack, attackPreview, bridgeAt, checkVictory, destroyBridge, distance, endSide, exportMap, fallKunyangMeteors,
  importMap, index, isFord, isRouted, logisticsRouteCut, mobileAt, move, reachable, recomputeFog,
  recruitLogistics, replenishConvoy, setUnitStats, setBridge, setTerrain, startGame, tile } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

test('fourteen Qin, Chu, Western and Eastern Han episodes have playable distinct maps', () => {
  assert.equal(IMPERIAL_CAMPAIGNS.length, 14);
  for (const { id } of IMPERIAL_CAMPAIGNS) {
    const m = makeImperialMap(id);
    assert.equal(CAMPAIGN_CATALOG.filter(x => x.id === id).length, 1);
    assert.ok(m.units.filter(u => u.team === 'egypt' && u.kind !== 'fort').length > 10);
    assert.ok(m.units.filter(u => u.team === 'coalition' && u.kind !== 'fort').length > 10);
    assert.equal(importMap(exportMap(m)).scenarioId, id);
    assert.equal(startGame(m).map.victory.mode, 'china');
  }
  for (const id of ['china_hexi', 'china_mobei']) {
    const m = makeImperialMap(id);
    assert.ok(m.units.filter(u => u.kind === 'cavalry').length >
      m.units.filter(u => u.kind === 'heavy').length);
  }
  const seven = makeImperialMap('china_seven_states');
  assert.ok(seven.units.some(u => u.kind === 'fort' && u.cityId === '睢阳'));
  assert.ok(seven.units.some(u => u.formation === '周亚夫断粮骑兵'));
  assert.equal(seven.victory.objective.c, 7);
});

test('only the specified four large campaigns use fiscal logistics', () => {
  for (const id of ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi']) {
    const map = id === 'china_changping' || id === 'china_qin_chu' ? null : makeImperialMap(id);
    if (map) assert.ok(map.logistics && map.logistics.depots.egypt.length && map.logistics.musters.coalition.length);
  }
  assert.equal(makeImperialMap('china_mobei').logistics, null);
  assert.ok(makeImperialMap('china_longxi').logistics.income.egypt >
    makeImperialMap('china_longxi').logistics.income.coalition);
});

test('Qin and Han maps show their separate tactical routes, camps and river crossings', () => {
  const maps = Object.fromEntries(IMPERIAL_CAMPAIGNS.map(x => [x.id, makeImperialMap(x.id)]));
  assert.equal(new Set(Object.values(maps).map(m =>
    JSON.stringify([...m.terrain, ...m.units.filter(u => u.kind === 'fort').map(u => [u.c, u.r])]))).size, 14);
  assert.ok(maps.china_dingtao.units.some(u => u.kind === 'fort' && u.cityId === '定陶楚营'));
  assert.ok(tile(maps.china_julu, 34, 20).terrain & TERRAIN.RIVER);
  assert.equal(maps.china_julu.victory.objective.c, 48);
  assert.ok(maps.china_three_qin.units.some(u => u.kind === 'fort' && u.cityId === '关中秦营'));
  assert.equal(tile(maps.china_puban, 34, 33).terrain, TERRAIN.ROAD | TERRAIN.RIVER);
  assert.ok(maps.china_pengcheng.units.some(u => u.kind === 'fort' && u.cityId === '彭城'));
  assert.equal(maps.china_pengcheng.victory.objective.c, 52);
  assert.ok(maps.china_pengcheng.units.filter(u => u.team === 'egypt' && u.kind === 'cavalry')
    .every(u => u.c < 30));
  assert.ok(tile(maps.china_pengcheng, 63, 20).terrain & TERRAIN.RIVER);
  assert.ok(tile(maps.china_jingxing, 10, 26).terrain & TERRAIN.RIVER);
  assert.equal(maps.china_jingxing.units.filter(u => u.formation === '汉军赤帜绕后奇兵').length, 2);
  assert.ok(maps.china_gaixia.units.some(u => u.kind === 'fort' && u.cityId === '垓下楚营'));
  assert.equal(maps.china_mayi.landmarks.some(p => p.label.includes('南翼伏兵')), true);
  assert.ok(tile(maps.china_hexi, 6, 8).terrain & TERRAIN.MOUNTAIN);
  assert.ok(tile(maps.china_mobei, 39, 33).terrain & TERRAIN.MOUNTAIN);
  assert.ok(maps.china_dayuan.units.some(u => u.kind === 'fort' && u.cityId === '贵山城'));
  assert.equal(maps.china_kunyang.units.filter(u => u.team === 'coalition' && u.kind === 'siegeRam').length, 2);
  assert.ok(tile(maps.china_longxi, 44, 23).terrain & TERRAIN.RIVER);
});

test('Kunyang expands Wang Yi’s army while keeping Liu Xiu’s relief and city garrison', () => {
  const map = makeImperialMap('china_kunyang');
  const troops = team => map.units.filter(u => u.team === team &&
    !['fort', 'chinaGeneral', 'moraleGuard'].includes(u.kind));
  assert.equal(troops('egypt').length, 23);
  assert.equal(troops('coalition').length, 54);
  assert.ok(map.units.some(u => u.formation === '刘秀西水援军'));
  assert.ok(map.units.some(u => u.formation === '昆阳城内守军'));
  assert.equal(map.victory.losses.coalition, Math.ceil(54 * 0.8));
});

test('Kunyang meteors fall every second round at thirty unique sites and damage Wang siege engines 1.5 times', () => {
  const map = makeImperialMap('china_kunyang'), game = startGame(map);
  const wang = game.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  const liu = game.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  const ram = game.map.units.find(u => u.team === 'coalition' && u.kind === 'siegeRam');
  Object.assign(wang, { c: 12, r: 7 });
  Object.assign(liu, { c: 11, r: 7 });
  Object.assign(ram, { c: 12, r: 8 });
  const wangHp = wang.hp, liuHp = liu.hp, ramHp = ram.hp;
  assert.equal(fallKunyangMeteors(game, () => 0), null);
  endSide(game, () => 0);
  assert.equal(game.kunyangMeteor, undefined);
  endSide(game, () => 0);
  const event = game.kunyangMeteor;
  assert.equal(game.turn, 2);
  assert.equal(event.turn, 2);
  assert.equal(event.strikes.length, KUNYANG_METEORS.count);
  assert.equal(new Set(event.strikes.map(p => `${p.c},${p.r}`)).size, KUNYANG_METEORS.count);
  const hits = event.strikes.filter(p => distance(p, wang) <= 1).length;
  const ramHits = event.strikes.filter(p => distance(p, ram) <= 1).length;
  assert.ok(hits > 0);
  assert.ok(ramHits > 0);
  assert.equal(wang.hp, wangHp - hits * KUNYANG_METEORS.damage);
  assert.equal(liu.hp, liuHp);
  assert.equal(ram.hp, ramHp - ramHits * KUNYANG_METEORS.damage * KUNYANG_METEORS.siegeMultiplier);
  assert.equal(fallKunyangMeteors(game, () => 0), null);
  const restored = restoreSave(createSave(map, game, 'egypt')).game;
  assert.deepEqual(restored.kunyangMeteor, event);
  assert.equal(fallKunyangMeteors(restored, () => 0), null);
  endSide(game, () => 0); endSide(game, () => 0);
  assert.equal(game.turn, 3);
  assert.equal(game.kunyangMeteor.turn, 2);
  endSide(game, () => 0); endSide(game, () => 0);
  assert.equal(game.turn, 4);
  assert.equal(game.kunyangMeteor.turn, 4);
  assert.equal(game.log.filter(line => line.includes('天降陨石')).length, 2);
});

test('Kunyang city uses level-three walls while the surrounding Wang camps stay level one', () => {
  const map = makeImperialMap('china_kunyang');
  const walls = map.units.filter(u => u.kind === 'fort' && u.cityId === '昆阳');
  const camps = map.units.filter(u => u.kind === 'fort' && u.cityId === '新军围城营');
  assert.ok(walls.length > 20);
  assert.ok(walls.every(u => u.level === 3 && u.hp === 1000));
  assert.equal(camps.length, 3);
  assert.ok(camps.every(u => u.level === 1));
});

test('Kunyang, Changping and Qin versus Chu do not end on camp capture, commander death, or deadline', () => {
  for (const id of ['china_kunyang', 'china_changping', 'china_qin_chu']) {
    const map = id === 'china_kunyang' ? makeImperialMap(id) : makeChinaMap(id);
    const game = startGame(map), goal = game.map.victory.objective;
    const blocker = mobileAt(game.map, goal.c, goal.r);
    if (blocker) blocker.hp = 0;
    const attacker = game.map.units.find(u => u.team === game.map.victory.attacker && u.kind === 'heavy');
    attacker.c = goal.c; attacker.r = goal.r;
    assert.equal(checkVictory(game), null, `${id}: camp occupation`);
    const leader = game.map.units.find(u => u.team === game.map.victory.attacker && u.kind === 'chinaGeneral');
    leader.hp = 0;
    assert.equal(checkVictory(game), null, `${id}: commander death`);
    const deadline = startGame(map);
    deadline.side = 'coalition'; deadline.turn = deadline.map.victory.turnLimit;
    endSide(deadline, () => 0.99);
    assert.equal(deadline.over, false, `${id}: old turn limit`);
  }
});

test('Wang Mang wins Kunyang by occupying the city on generated and edited maps', () => {
  const edited = importMap(JSON.parse(readFileSync(new URL('./bundled-maps/china_kunyang.json', import.meta.url))));
  for (const map of [makeImperialMap('china_kunyang'), edited]) {
    const game = startGame(map);
    const { c, r } = KUNYANG_CITY_OBJECTIVE;
    const blocker = mobileAt(game.map, c, r);
    if (blocker) blocker.hp = 0;
    const wang = game.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
    wang.c = c; wang.r = r;
    assert.equal(checkVictory(game), 'coalition');
    assert.equal(game.victoryReason, 'kunyang_capture');
  }
});

test('central treasury leads in the four logistics campaigns, including edited maps and old saves', () => {
  for (const id of ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi']) {
    const expected = CAMPAIGN_FINANCES[id];
    const central = id === 'china_seven_states' ? 'coalition' : 'egypt';
    const rival = central === 'egypt' ? 'coalition' : 'egypt';
    const generated = ['china_changping', 'china_qin_chu'].includes(id) ? makeChinaMap(id) : makeImperialMap(id);
    const edited = JSON.parse(readFileSync(new URL(`./bundled-maps/${id}.json`, import.meta.url)));
    assert.deepEqual(generated.logistics.income, expected.income, `${id}: generated`);
    assert.deepEqual(edited.logistics.income, expected.income, `${id}: packaged edit`);
    assert.ok(expected.income[central] >= expected.income[rival] * 2, `${id}: income lead`);
    edited.logistics.income = { egypt: 1, coalition: 1 };
    edited.logistics.startingMoney = { egypt: 1, coalition: 1 };
    const loaded = importMap(edited);
    assert.deepEqual(loaded.logistics.income, expected.income, `${id}: old personal map`);
    assert.deepEqual(startGame(loaded).money, expected.startingMoney, `${id}: new game`);
    const old = createSave(loaded, startGame(loaded), central);
    old.rulesVersion = 9;
    old.game.map.logistics.income = { egypt: 1, coalition: 1 };
    assert.deepEqual(restoreSave(old).game.map.logistics.income, expected.income, `${id}: old save`);
  }
});

test('edited Changping and Qin versus Chu maps cannot win by holding out to the old deadline', () => {
  for (const id of ['china_changping', 'china_qin_chu']) {
    const map = importMap(JSON.parse(readFileSync(new URL(`./bundled-maps/${id}.json`, import.meta.url))));
    const game = startGame(map);
    game.side = 'coalition'; game.turn = map.victory.turnLimit;
    endSide(game, () => 0.99);
    assert.equal(game.over, false, id);
  }
});

test('all Qin and Han river battles include fast bridges over fords and a separate slow crossing', () => {
  for (const id of ['china_julu', 'china_pengcheng', 'china_puban', 'china_jingxing',
    'china_seven_states', 'china_dayuan', 'china_kunyang', 'china_longxi',
    'china_changping', 'china_qin_chu']) {
    const m = ['china_changping', 'china_qin_chu'].includes(id) ? makeChinaMap(id) : makeImperialMap(id);
    assert.equal(m.bridges.length, 2, id);
    for (const { c, r } of m.bridges) {
      assert.equal(tile(m, c, r).terrain, TERRAIN.RIVER | TERRAIN.ROAD, id);
      assert.equal(isFord(m, c, r), false, id);
    }
    assert.ok(m.terrain.some((t, i) => (t & (TERRAIN.RIVER | TERRAIN.ROAD)) ===
      (TERRAIN.RIVER | TERRAIN.ROAD) && !bridgeAt(m, i % m.cols, Math.floor(i / m.cols))), id);
    assert.deepEqual(importMap(exportMap(m)).bridges, m.bridges);
  }
  const scenario = makeImperialMap('china_julu');
  const s = startGame(scenario);
  const chu = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  const qin = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  chu.c = 33; chu.r = 23;
  recomputeFog(s);
  assert.equal(move(s, chu.id, 35, 23).riverMove, false);
  assert.equal(destroyBridge(s, chu.id, 34, 23).ok, true);
  assert.equal(isFord(s.map, 34, 23), true);
  qin.c = 36; qin.r = 23;
  endSide(s);
  assert.equal(destroyBridge(s, qin.id, 35, 23).ok, true);
  assert.equal(isFord(s.map, 35, 23), true);
  assert.equal(tile(s.map, 35, 23).terrain, TERRAIN.RIVER | TERRAIN.ROAD);
  const restored = restoreSave(JSON.parse(JSON.stringify(createSave(scenario, s, 'egypt'))));
  assert.equal(bridgeAt(restored.scenario, 34, 23), true);
  assert.equal(isFord(restored.game.map, 34, 23), true);
});

test('supply wagon clears hunger and refills three turns for an ordinary soldier', () => {
  const s = startGame(makeImperialMap('china_longxi'));
  const wagon = s.map.units.find(u => u.team === 'egypt' && u.kind === 'supplyWagon');
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  soldier.c = wagon.c + 1; soldier.r = wagon.r; soldier.hunger = 4; soldier.fedTurns = 0;
  const before = wagon.supplyStock;
  endSide(s); endSide(s);
  assert.equal(soldier.hunger, 0);
  assert.equal(soldier.fedTurns, 3);
  assert.ok(wagon.supplyStock < before);
  wagon.supplyStock = 3;
  const money = s.money.egypt;
  const filled = replenishConvoy(s, wagon.id);
  assert.equal(filled.ok, true);
  assert.equal(wagon.supplyStock, 24);
  assert.equal(s.money.egypt, money - filled.cost);
  assert.equal(restoreSave(JSON.parse(JSON.stringify(createSave(s.map, s, 'egypt')))).game.map.units
    .find(u => u.id === soldier.id).fedTurns, 3);
});

test('five full hunger turns rout soldiers; a raid cuts recruitment until the route is safe', () => {
  const s = startGame(makeImperialMap('china_seven_states'));
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  soldier.c = 32; soldier.r = 3; soldier.hunger = 5; soldier.fedTurns = 0; soldier.maxHungerTurns = 4;
  endSide(s); endSide(s);
  assert.equal(isRouted(soldier), true);
  assert.ok(s.money.egypt < s.map.logistics.startingMoney.egypt + s.map.logistics.income.egypt);
  const raider = s.map.units.find(u => u.team === 'coalition' && u.kind === 'cavalry');
  Object.assign(raider, s.map.logistics.routes.egypt[1]);
  assert.equal(logisticsRouteCut(s, 'egypt'), true);
  assert.match(recruitLogistics(s, 'heavy').reason, /补给线/);
  for (const unit of s.map.units.filter(u => u.team === 'coalition' && u.kind !== 'fort')) {
    unit.c = 2; unit.r = 2;
  }
  assert.equal(logisticsRouteCut(s, 'egypt'), false);
  assert.equal(recruitLogistics(s, 'heavy').ok, true);
});

test('starting convoy relays reach most formations and one ration feeds four soldiers', () => {
  for (const id of ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi']) {
    const m = id === 'china_changping' || id === 'china_qin_chu' ? makeChinaMap(id) : makeImperialMap(id);
    for (const team of ['egypt', 'coalition']) {
      const wagons = m.units.filter(u => u.team === team && u.kind === 'supplyWagon');
      const soldiers = m.units.filter(u => u.team === team && !['fort', 'supplyWagon'].includes(u.kind));
      const reached = new Set();
      const queue = soldiers.filter(u => wagons.some(w => distance(u, w) <= 2));
      for (const u of queue) reached.add(u.id);
      for (let i = 0; i < queue.length; i++) for (const u of soldiers)
        if (!reached.has(u.id) && distance(queue[i], u) === 1) { reached.add(u.id); queue.push(u); }
      assert.ok(reached.size >= soldiers.length - 1, `${id}:${team}`);
      assert.ok(m.logistics.income[team] >= soldiers.length);
    }
  }
  const s = startGame(makeImperialMap('china_longxi'));
  const wagon = s.map.units.find(u => u.team === 'egypt' && u.kind === 'supplyWagon');
  for (const u of s.map.units.filter(u => u.team === 'egypt' && u.kind === 'supplyWagon' && u !== wagon)) u.hp = 0;
  const troops = s.map.units.filter(u => u.team === 'egypt' && u.kind === 'heavy');
  for (const u of s.map.units.filter(u => u.team === 'egypt' && u.kind !== 'supplyWagon')) u.fedTurns = 100;
  for (const u of troops.slice(0, 5)) {
    u.c = wagon.c + 1; u.r = wagon.r; u.fedTurns = 0; u.hunger = 2;
  }
  endSide(s); endSide(s);
  assert.equal(wagon.supplyStock, 19);
  assert.ok(troops.slice(0, 5).every(u => u.hunger === 0 && u.fedTurns === 3));
});

test('food relays beyond two hexes through adjacent soldiers and stops at gaps or empty carts', () => {
  const setup = stock => {
    const s = startGame(makeImperialMap('china_longxi'));
    const wagon = s.map.units.find(u => u.team === 'egypt' && u.kind === 'supplyWagon');
    const soldiers = s.map.units.filter(u => u.team === 'egypt' && u.kind === 'heavy').slice(0, 6);
    for (const u of s.map.units.filter(u => u.team === 'egypt')) {
      if (u.kind === 'supplyWagon' && u !== wagon) u.hp = 0;
      else if (u.kind !== 'fort' && u.kind !== 'supplyWagon' && !soldiers.includes(u)) {
        u.c = 70; u.r = 0; u.fedTurns = 100;
      }
    }
    soldiers.forEach((u, i) => {
      u.c = wagon.c + i + 1; u.r = wagon.r; u.hunger = 4; u.fedTurns = 0;
    });
    wagon.supplyStock = stock;
    return { s, wagon, soldiers };
  };
  {
    const { s, wagon, soldiers } = setup(9);
    assert.ok(distance(wagon, soldiers.at(-1)) > 2);
    endSide(s); endSide(s);
    assert.ok(soldiers.every(u => u.hunger === 0 && u.fedTurns === 3));
    assert.equal(wagon.supplyStock, 0);
    assert.equal(wagon.supplyCredit, 3);
  }
  {
    const { s, wagon, soldiers } = setup(1);
    soldiers[0].fedTurns = 2;
    endSide(s); endSide(s);
    assert.equal(soldiers[1].hunger, 0);
    assert.equal(soldiers[1].fedTurns, 1);
    assert.ok(soldiers.slice(2).every(u => u.hunger === 4));
    assert.equal(wagon.supplyStock, 0);
  }
  {
    const { s, soldiers } = setup(24);
    soldiers[2].c = 70; soldiers[2].r = 0;
    endSide(s); endSide(s);
    assert.ok(soldiers.slice(0, 2).every(u => u.hunger === 0));
    assert.ok(soldiers.slice(3).every(u => u.hunger === 4));
  }
});

test('unfed soldiers gain one hunger only every two own turns', () => {
  const s = startGame(makeImperialMap('china_longxi'));
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  soldier.fedTurns = 0;
  for (const wagon of s.map.units.filter(u => u.team === 'egypt' && u.kind === 'supplyWagon')) wagon.hp = 0;
  for (const u of s.map.units.filter(u => u !== soldier && u.kind !== 'fort' && u.kind !== 'supplyWagon')) u.fedTurns = 100;
  endSide(s); endSide(s);
  assert.equal(soldier.hunger, 0); assert.equal(soldier.hungerClock, 1);
  endSide(s); endSide(s);
  assert.equal(soldier.hunger, 1); assert.equal(soldier.hungerClock, 0);
  for (let i = 0; i < 8; i++) { endSide(s); endSide(s); }
  assert.equal(soldier.hunger, 5);
  assert.equal(isRouted(soldier), false);
  for (let i = 0; i < 4; i++) { endSide(s); endSide(s); }
  assert.equal(soldier.maxHungerTurns, 5);
  assert.equal(isRouted(soldier), true);
});

test('an ordinary soldier carries three full turns of food before hunger starts', () => {
  const s = startGame(makeImperialMap('china_longxi'));
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  for (const wagon of s.map.units.filter(u => u.team === 'egypt' && u.kind === 'supplyWagon')) wagon.hp = 0;
  for (const u of s.map.units.filter(u => u !== soldier && u.kind !== 'fort' && u.kind !== 'supplyWagon')) u.fedTurns = 100;
  assert.equal(soldier.fedTurns, 3);
  for (let i = 0; i < 3; i++) { endSide(s); endSide(s); }
  assert.equal(soldier.fedTurns, 0);
  assert.equal(soldier.hunger, 0);
  endSide(s); endSide(s);
  assert.equal(soldier.hunger, 0);
  endSide(s); endSide(s);
  assert.equal(soldier.hunger, 1);
});

test('only designated elite rear raiders carry and refill ten turns of food', () => {
  const changping = startGame(makeChinaMap('china_changping'));
  const qinRaiders = changping.map.units.filter(u => u.deepRaider);
  assert.equal(qinRaiders.length, 4);
  assert.ok(qinRaiders.every(u => u.kind === 'cavalry' && u.fedTurns === 10));
  const seven = startGame(makeImperialMap('china_seven_states'));
  const raiders = seven.map.units.filter(u => u.deepRaider);
  assert.equal(raiders.length, 7);
  assert.ok(raiders.every(u => u.team === 'coalition' && u.kind === 'cavalry' && u.fedTurns === 10));
  assert.ok(seven.map.units.filter(u => u.kind === 'guard').every(u => u.fedTurns === 3));
  const wagon = seven.map.units.find(u => u.team === 'coalition' && u.kind === 'supplyWagon');
  const raider = raiders[0];
  raider.c = wagon.c + 1; raider.r = wagon.r; raider.fedTurns = 0; raider.hunger = 3;
  endSide(seven);
  assert.equal(raider.hunger, 0);
  assert.equal(raider.fedTurns, 10);
  assert.equal(restoreSave(JSON.parse(JSON.stringify(createSave(seven.map, seven, 'egypt')))).game.map.units
    .find(u => u.id === raider.id).deepRaider, true);
});

test('version-three supply saves receive extra wagons and recovery rations', () => {
  const m = makeImperialMap('china_seven_states'), s = startGame(m);
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  soldier.hunger = 5; soldier.starvedRouted = true; soldier.morale = 0.2;
  s.money.egypt = -50;
  const save = JSON.parse(JSON.stringify(createSave(m, s, 'egypt')));
  save.rulesVersion = 3;
  save.game.map.units = save.game.map.units.filter(u => u.kind !== 'supplyWagon' || u.c >= 65);
  const restored = restoreSave(save).game;
  const revived = restored.map.units.find(u => u.id === soldier.id);
  assert.equal(revived.hunger, 0);
  assert.equal(revived.fedTurns, 3);
  assert.equal(isRouted(revived), false);
  assert.ok(restored.map.units.filter(u => u.team === 'egypt' && u.kind === 'supplyWagon').length > 1);
  assert.ok(restored.money.egypt >= 125);
});

test('version-four supply saves receive current three-turn rations', () => {
  const m = makeImperialMap('china_longxi'), s = startGame(m);
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  soldier.hunger = 5; soldier.hungerClock = 1; soldier.fedTurns = 0;
  soldier.maxHungerTurns = 4; soldier.starvedRouted = true; soldier.morale = 0.2;
  const save = JSON.parse(JSON.stringify(createSave(m, s, 'egypt')));
  save.rulesVersion = 4;
  const restored = restoreSave(save).game;
  const revived = restored.map.units.find(u => u.id === soldier.id);
  assert.equal(revived.hunger, 0);
  assert.equal(revived.hungerClock, 0);
  assert.equal(revived.fedTurns, 3);
  assert.equal(revived.maxHungerTurns, 0);
  assert.equal(isRouted(revived), false);
  assert.ok(restored.log.some(line => /三回合/.test(line)));
});

test('version-five saves clamp regular food and restore designated rear raiders', () => {
  const m = makeImperialMap('china_seven_states'), s = startGame(m);
  const regular = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  const raider = s.map.units.find(u => u.deepRaider);
  regular.fedTurns = 9; raider.fedTurns = 2;
  const save = JSON.parse(JSON.stringify(createSave(m, s, 'egypt')));
  save.rulesVersion = 5;
  for (const map of [save.scenario, save.game.map]) for (const u of map.units) delete u.deepRaider;
  const restored = restoreSave(save).game;
  assert.equal(restored.map.units.find(u => u.id === regular.id).fedTurns, 3);
  assert.equal(restored.map.units.find(u => u.id === raider.id).fedTurns, 10);
  assert.equal(restored.map.units.find(u => u.id === raider.id).deepRaider, true);
});

test('melee and ranged takedowns both capture enemy wagon and its remaining food', () => {
  for (const [kind, offset] of [['heavy', { c: -1, r: 0 }],
    ['chinaCrossbow', { c: -1, r: -1 }]]) {
    const s = startGame(makeImperialMap('china_longxi'));
    const attacker = s.map.units.find(u => u.team === 'egypt' && u.kind === kind);
    const wagon = s.map.units.find(u => u.team === 'coalition' && u.kind === 'supplyWagon' && u.c === 53);
    attacker.c = wagon.c + offset.c; attacker.r = wagon.r + offset.r;
    wagon.hp = 1; wagon.supplyStock = 17;
    setUnitStats(s.map, kind, { melee: 30, ranged: 30 });
    recomputeFog(s);
    const preview = attackPreview(s, attacker, wagon.c, wagon.r);
    assert.ok(preview);
    assert.equal(preview.melee, kind === 'heavy');
    const result = attack(s, attacker.id, wagon.c, wagon.r, 0);
    assert.equal(result.capturedWagon, true);
    assert.equal(wagon.team, 'egypt');
    assert.equal(wagon.supplyStock, 17);
    assert.equal(wagon.hp, 50);
    assert.match(s.log.join('\n'), /缴获.*17 点粮秣/);
  }
});

test('computer soldiers and convoys join a nearby fast road while advancing', () => {
  for (const kind of ['heavy', 'supplyWagon']) {
    const s = startGame(makeImperialMap('china_longxi'));
    const unit = s.map.units.find(u => u.team === 'egypt' && u.kind === kind);
    const soldier = kind === 'supplyWagon' ?
      s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy') : unit;
    const enemy = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
    s.map.units = kind === 'supplyWagon' ? [unit, soldier, enemy] : [unit, enemy];
    s.map.terrain.fill(0); s.map.houses.fill(0);
    unit.c = 10; unit.r = 20; unit.actionsLeft = 2;
    enemy.c = 50; enemy.r = 20;
    for (let c = 10; c <= 20; c++) s.map.terrain[index(s.map, c, 19)] = TERRAIN.ROAD;
    if (kind === 'supplyWagon') {
      soldier.c = 20; soldier.r = 20; soldier.hunger = 2; soldier.fedTurns = 0; soldier.actionsLeft = 0;
    }
    s.map.victory.objective = { c: 20, r: 20 };
    recomputeFog(s);
    const actions = aiTurn(s, () => 0.5);
    assert.ok(actions.some(a => a.type === 'move' && a.id === unit.id));
    assert.equal(unit.r, 19);
  }
});

test('supply wagons travel slowly on river and sea without spending travel grain', () => {
  const s = startGame(makeImperialMap('china_longxi'));
  const wagon = s.map.units.find(u => u.team === 'egypt' && u.kind === 'supplyWagon' && u.c === 7 && u.r === 23);
  assert.ok(wagon);
  setTerrain(s.map, 8, 22, TERRAIN.RIVER);
  setTerrain(s.map, 9, 22, TERRAIN.SEA);
  recomputeFog(s);
  wagon.supplyTravel = 5;
  const stock = wagon.supplyStock;
  assert.equal(move(s, wagon.id, 8, 22).ok, true);
  assert.equal(wagon.actionsLeft, 0);
  assert.equal(wagon.supplyTravel, 5);
  assert.equal(wagon.supplyStock, stock);
  wagon.actionsLeft = 2;
  assert.equal(move(s, wagon.id, 9, 22).ok, true);
  assert.equal(wagon.actionsLeft, 0);
  assert.equal(wagon.supplyTravel, 5);
  assert.equal(wagon.supplyStock, stock);
  assert.equal(importMap(exportMap(s.map)).units.some(u => u.kind === 'supplyWagon' && u.c === 9 && u.r === 22), true);
  setTerrain(s.map, 10, 22, TERRAIN.MOUNTAIN);
  recomputeFog(s);
  wagon.actionsLeft = 2;
  assert.equal(reachable(s, wagon).has('10,22'), false);
  assert.equal(move(s, wagon.id, 9, 23).ok, true);
  assert.equal(wagon.supplyStock, stock - 1);
});

test('supply wagons cross fords and bridges at normal road speed', () => {
  for (const bridge of [false, true]) {
    const s = startGame(makeImperialMap('china_longxi'));
    const wagon = s.map.units.find(u => u.team === 'egypt' && u.kind === 'supplyWagon' && u.c === 7 && u.r === 23);
    setTerrain(s.map, 8, 23, TERRAIN.ROAD | TERRAIN.RIVER);
    if (bridge) assert.equal(setBridge(s.map, 8, 23, true), true);
    recomputeFog(s);
    assert.equal(reachable(s, wagon).has('9,23'), true, bridge ? 'bridge' : 'ford');
    assert.equal(move(s, wagon.id, 9, 23).ok, true);
    assert.equal(wagon.actionsLeft, 1);
    assert.equal(wagon.supplyTravel, 2);
  }
});

test('wagon movement beyond five cells consumes supplies', () => {
  const s = startGame(makeImperialMap('china_longxi'));
  const wagon = s.map.units.find(u => u.team === 'egypt' && u.kind === 'supplyWagon');
  wagon.supplyTravel = 5;
  const step = [...reachable(s, wagon).values()].find(p => p.steps >= 1 && distance(p, wagon) >= 1);
  assert.ok(step);
  const before = wagon.supplyStock;
  assert.equal(move(s, wagon.id, step.c, step.r).ok, true);
  assert.equal(wagon.supplyStock, before - 1);
});

test('older Changping saves gain logistics without replaying iron-age health migration', () => {
  const m = makeChinaMap('china_changping'), s = startGame(m);
  const soldier = s.map.units.find(u => u.kind === 'heavy' && u.team === 'egypt');
  soldier.hp -= 30;
  const oldHp = soldier.hp;
  const save = JSON.parse(JSON.stringify(createSave(m, s, 'egypt')));
  save.rulesVersion = 2;
  delete save.scenario.logistics; delete save.game.map.logistics;
  save.scenario.units = save.scenario.units.filter(u => u.kind !== 'supplyWagon');
  save.game.map.units = save.game.map.units.filter(u => u.kind !== 'supplyWagon');
  save.game.money = null;
  const restored = restoreSave(save);
  assert.ok(restored.scenario.logistics && restored.game.map.logistics);
  assert.ok(restored.game.map.units.some(u => u.kind === 'supplyWagon' && u.supplyStock === 24));
  assert.equal(restored.game.map.units.find(u => u.id === soldier.id).hp, oldHp);
});
