// Put panels in normal document flow: no timer-based or pixel-estimated positioning.
export function bindBattleLayout(document){
 const sidebar=document.querySelector('main>aside'),stage=document.getElementById('stage');
 if(!sidebar||!stage||sidebar.id==='battle-sidebar')return;
 sidebar.id='battle-sidebar';sidebar.setAttribute('aria-label','战场信息与行动');
 const scroll=document.createElement('div');scroll.id='battle-sidebar-scroll';scroll.tabIndex=0;scroll.setAttribute('aria-label','部队属性与行动（可滚动）');
 for(const child of [...sidebar.children])scroll.append(child);
 for(const card of scroll.querySelectorAll('.roster,.log')){const fold=document.createElement('details'),summary=document.createElement('summary'),heading=card.querySelector('h2');if(heading)summary.append(heading);fold.append(summary);while(card.firstChild)fold.append(card.firstChild);card.append(fold);}
 const guide=document.getElementById('tutorial-guide');if(guide)sidebar.append(guide);
 sidebar.append(scroll);
 const formation=document.getElementById('batch-phalanx');if(formation)scroll.prepend(formation);
 const dock=document.createElement('div');dock.id='battle-command-dock';dock.setAttribute('aria-label','战场指挥工具');
 for(const id of ['order-officer','group-controls','map-coordinate','hint']){const el=document.getElementById(id);if(el)dock.append(el);}
 const help=document.createElement('div');help.id='battle-help-links';
 for(const id of ['terrain-rules-link','failure-rules-link']){const el=document.getElementById(id);if(el)help.append(el);}
 sidebar.append(help);
 stage.append(dock);
 bindMinimizers(document);
}

// Keep each panel's real content and handlers alive when minimizing.
function bindMinimizers(document){
 const view=document.defaultView;
 for(const [id,title] of [['selected-card','士兵属性'],['recruit-card','军费与召集'],['group-controls','批量指挥'],['batch-phalanx','方阵指挥'],['tutorial-guide','教学提示'],['follow-controls','跟随视角']]){
  const panel=document.getElementById(id);if(!panel)continue;
  let minimized=false;try{minimized=view.localStorage.getItem('battle-panel:'+id)==='min';}catch{}
  const bar=document.createElement('button');bar.type='button';bar.className='panel-minimize';bar.dataset.panel=id;
  const render=()=>{panel.classList.toggle('panel-minimized',minimized);bar.textContent=`${title}　${minimized?'＋ 展开':'− 最小化'}`;bar.setAttribute('aria-expanded',String(!minimized));bar.setAttribute('aria-label',`${minimized?'展开':'最小化'}${title}`);};
  bar.onclick=e=>{e.stopPropagation();minimized=!minimized;render();try{view.localStorage.setItem('battle-panel:'+id,minimized?'min':'open');}catch{}};
  bar.onpointerdown=e=>e.stopPropagation();
  const attach=()=>{if(bar.parentNode!==panel)panel.prepend(bar);};attach();render();
  // Attribute refreshes are frequent; only listen to direct content replacement.
  new view.MutationObserver(attach).observe(panel,{childList:true});
 }
 const report=document.getElementById('turn-report');
 if(report){
  const min=document.createElement('button');min.type='button';min.className='report-minimize';min.textContent='− 最小化战报';
  const restore=document.getElementById('turn-report-open');report.prepend(min);
  min.onclick=()=>{report.close();if(restore)restore.textContent='回合战报 · 展开';};
  new view.MutationObserver(()=>{if(report.open&&restore)restore.textContent='回合战报';}).observe(report,{attributes:true,attributeFilter:['open']});
 }
 // Existing minimap/officer/editor folding controls remain their single source of truth.
 for(const [id,label] of [['recon-toggle','地形侦察小地图：点击最小化或展开'],['order-toggle','AI传令官：点击最小化或展开'],['collapse-editor','地图编辑工具：点击最小化或展开']]){const el=document.getElementById(id);if(el)el.title=label;}
}
