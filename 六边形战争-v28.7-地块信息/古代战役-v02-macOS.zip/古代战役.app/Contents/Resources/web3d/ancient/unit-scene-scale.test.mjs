import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as T from '../vendor/three/three.module.js';
import {createUnitModel,UNIT_SCENE_SCALE} from './unit-presentation.mjs';
import {visualProfile} from './visual-profiles.mjs';
import {animateFullModel} from './full-models.mjs';
import {HEX_R} from '../js/core/hex.js';
const entries=JSON.parse(fs.readFileSync(new URL('./unit_animation_catalog.json',import.meta.url))).units.filter(u=>u.id!=='fort'&&u.id!=='scout');
test('all 67 unit types and both factions enlarge body and every base uniformly by 20%',()=>{
 assert.equal(entries.length,67);assert.equal(UNIT_SCENE_SCALE,1.16*1.2);
 for(const entry of entries)for(const team of ['egypt','coalition']){const u={id:'u1',kind:entry.id,team,hp:100,c:3,r:4,morale:1},saved=JSON.stringify(u),m=createUnitModel(u,entry.contexts[0].scenarioId),meshes=[];m.scale.setScalar(1.16);m.updateMatrixWorld(true);m.traverse(o=>{if(o.isMesh)meshes.push({o,size:new T.Box3().setFromObject(o).getSize(new T.Vector3()),geometry:o.geometry,material:o.material});});m.scale.setScalar(UNIT_SCENE_SCALE);m.updateMatrixWorld(true);
 for(const {o,size,geometry,material} of meshes){const current=new T.Box3().setFromObject(o).getSize(new T.Vector3());assert.ok(current.distanceTo(size.multiplyScalar(1.2))<1e-5,entry.id);assert.equal(o.geometry,geometry);assert.equal(o.material,material);}assert.equal(JSON.stringify(u),saved);}
});
test('all enlarged colored bases fit between neighboring hex centers and retain role differences',()=>{
 const widths=[];for(const kind of ['heavy','cavalry','chinaHeavyChariot','siegeRam']){const m=createUnitModel({id:1,kind,team:'egypt',hp:100},'china_changping');m.scale.setScalar(UNIT_SCENE_SCALE);const disk=m.children.find(o=>o.userData.unitBase),width=new T.Box3().setFromObject(disk).getSize(new T.Vector3()).x;widths.push(width);assert.ok(width<Math.sqrt(3)*HEX_R);}
 assert.ok(widths[0]<widths[1]&&widths[1]<widths[2]);assert.ok(Math.abs(widths[2]-widths[3])<1e-6);
});
test('LOD and walking/formation animation preserve overall scale and equal-sized paired infantry',()=>{
 for(const kind of ['heavy','guard','greekHoplite','phalangite','romanLegion']){const m=createUnitModel({id:1,kind,team:'egypt',hp:100,formed:true,facing:0},'mantinea');m.scale.setScalar(UNIT_SCENE_SCALE);for(const distance of [10,150,10]){animateFullModel(m,250,{moving:true,distance});assert.ok(m.scale.toArray().every(n=>n===UNIT_SCENE_SCALE));const people=[];m.getObjectByName('near').traverse(o=>{if(o.name==='soldier')people.push(o);});assert.equal(people.length,2);assert.deepEqual(people[0].scale.toArray(),people[1].scale.toArray());}}
});
