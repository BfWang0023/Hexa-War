// Battlefield proportions are presentation only; authored meshes and rule data stay reusable.
import * as THREE from '../vendor/three/three.module.js';
import { createUnitModel as createAuthoredModel } from './models.mjs';
import { visualProfile } from './visual-profiles.mjs';
export { createFortModel } from './models.mjs';

// Apply uniformly at battlefield placement, including bases and every LOD.
export const UNIT_SCENE_SCALE = 1.16 * 1.20;

export const UNIT_PROPORTIONS = Object.freeze({
  baseXZ: .85, soldier: 1.10 * 1.20, body: 1.20, groundY: .24,
  baseByFamily: Object.freeze({
    infantry: .76, cavalry: .92,
    chariot: 1, ram: 1, onager: 1, siegeTower: 1, defenseTower: 1,
    wagon: 1, trojanHorse: 1, ship: 1,
    elephant: .95, camel: .95, ox: .95,
  }),
});
// Derive from the displayed role, so dismounted riders receive infantry bases.
export const unitBaseScale = profile => UNIT_PROPORTIONS.baseByFamily[profile?.family] ?? UNIT_PROPORTIONS.baseXZ;

export function applyUnitProportions(model, profile) {
  if (model.userData.unitProportions) return model;
  const baseScale = unitBaseScale(profile);
  for (const child of model.children) if (child.userData.unitBase) {
    child.scale.x *= baseScale;
    child.scale.z *= baseScale;
    child.position.x *= baseScale;
    child.position.z *= baseScale;
  }
  {
    let levels = model.children.filter(c => c.name === 'near' || c.name === 'far');
    if (!levels.length) {
      const body = new THREE.Group();
      body.name = 'unit-body';
      for (const child of [...model.children]) if (!child.userData.unitBase) body.add(child);
      model.add(body);
      levels = [body];
    }
    for (const level of levels) {
      const person = ['infantry', 'cavalry'].includes(profile?.family);
      const bodyScale = person ? UNIT_PROPORTIONS.soldier : UNIT_PROPORTIONS.body;
      const groundY = person ? UNIT_PROPORTIONS.groundY : 0;
      // Grow bodies around their standing/waterline anchor; plinths are siblings.
      level.scale.multiplyScalar(bodyScale);
      level.position.y = groundY + (level.position.y - groundY) * bodyScale;
      // Pose resets must preserve the display transform in both animation generations.
      for (const entry of model.userData.rig || []) if (entry.o === level) {
        entry.position?.copy(level.position);
        entry.scale?.copy(level.scale);
        if ('y' in entry) entry.y = level.position.y;
      }
    }
  }
  model.userData.unitProportions = UNIT_PROPORTIONS;
  return model;
}

export function createUnitModel(unit, scenarioId = null, options = {}) {
  const model = createAuthoredModel(unit, scenarioId, options);
  return applyUnitProportions(model, model.userData.profile || visualProfile(unit, scenarioId, options.map));
}
