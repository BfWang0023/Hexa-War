import {beforeInteraction} from '../../tools/interaction-v19/integrity.mjs';
import {assertChargeFeedbackOnly} from '../../tools/charge-bonus/effects-integrity.mjs';
import {assertCameraOnlyAppChange} from '../../tools/spectator-follow/app-integrity.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {createUnitModel} from './models.mjs';
import {animateFullModel} from './full-models.mjs';
import {visualProfile} from './visual-profiles.mjs';
import {signature} from '../../tools/hero-geometry-signature.mjs';
const root=new URL('../../',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,root)));
const cases=[['hero','troy'],['chinaGeneral','china_chengpu'],['hittiteKing','kadesh'],['hittiteKing','gaugamela'],['pharaoh','gaugamela'],['scipio','zama'],['hannibal','cannae'],['paullus','cannae'],['varro','cannae'],['masinissa','zama']];
const unit=(kind)=>({id:1,kind,team:'egypt',hp:100});
test('Egyptian pharaoh in both campaigns, both teams and mounted/on-foot forms stays byte-identical in rendered geometry; ordinary units unchanged',()=>{
 for(const x of read('docs/hero-regalia/unchanged-geometry.json'))assert.equal(signature(createUnitModel(x.u,x.scenario)),x.signature,JSON.stringify(x.u));
});
test('approved animation implementation and integration remain unchanged',()=>{
 const baseline=fs.readFileSync(new URL('docs/support-refinement/before/full-models.mjs',root),'utf8');const current=fs.readFileSync(new URL('web3d/ancient/full-models.mjs',root),'utf8');const hook='\n applyFormationPose(root,root.userData.profile,{action:requestedAction,progress:p});';assert.ok(current.includes(hook));const flash='\n applyHitFlash(root,hit>0);';assert.ok(current.includes(flash));assert.ok(!current.includes('o.rotation.z=hit*'));assert.equal(current.slice(current.indexOf('export function resetFullPose')).replace(hook,'').replace(flash,''),baseline.slice(baseline.indexOf('export function resetFullPose')).replace('o.rotation.z=hit*Math.sin(t*55)*.08;',''));
 const hashes=read('docs/hero-regalia/baseline.json');for(const p of ['unit-animation.mjs','weapon-effects.mjs','app.mjs']){const rel='web3d/ancient/'+p;if(p==='weapon-effects.mjs'){assertChargeFeedbackOnly(hashes[rel]);continue;}if(p==='app.mjs'){assertCameraOnlyAppChange(hashes[rel]);continue;}assert.equal(crypto.createHash('sha256').update(beforeInteraction(p,fs.readFileSync(new URL(rel,root),'utf8'))).digest('hex'),hashes[rel]);}
});
test('hero and ruler armor includes full equipment attached to moving joints, excluding Egyptian pharaoh and ordinary officers',()=>{
 for(const [kind,s] of cases){const m=createUnitModel(unit(kind),s);for(const name of ['hero-regalia','hero-cuirass','hero-pauldron','hero-vambrace','hero-greave','hero-helmet','hero-mantle'])assert.ok(m.getObjectByName(name),kind+':'+name);assert.equal(m.getObjectByName('hero-pauldron').parent.name,'upper-arm');assert.equal(m.getObjectByName('hero-vambrace').parent.name,'lower-arm');}
 for(const [kind,s]of [['pharaoh','megiddo'],['pharaoh','kadesh'],['moraleGuard','megiddo'],['heavy','troy']])assert.equal(createUnitModel(unit(kind),s).getObjectByName('hero-regalia'),undefined);
});
test('repeated supported actions keep state immutable and transforms finite; rest posture resets consistently',()=>{
 for(const [kind,s] of cases){const u=unit(kind),saved=JSON.stringify(u),m=createUnitModel(u,s),p=visualProfile(u,s);animateFullModel(m,0,{});const rest=signature(m);
 for(let repeat=0;repeat<3;repeat++)for(const action of [p.meleeAction,p.rangedAction].filter(a=>a&&a!=='none'))for(const progress of [0,.25,.5,.75,1]){animateFullModel(m,progress*1000,{action,progress});m.updateMatrixWorld(true);m.traverse(o=>assert.ok(o.matrixWorld.elements.every(Number.isFinite),kind+':'+o.name));}
 animateFullModel(m,0,{});assert.equal(signature(m),rest,kind);assert.equal(JSON.stringify(u),saved);
 }
});
test('ornate models retain shared geometry and bounded far-LOD draw calls',()=>{
 for(const [kind,s] of cases){const a=createUnitModel(unit(kind),s),b=createUnitModel(unit(kind),s),meshes=m=>{const out=[];m.traverse(o=>{if(o.isMesh)out.push(o);});return out;};const am=meshes(a.getObjectByName('near')),bm=meshes(b.getObjectByName('near'));assert.equal(am.length,bm.length);am.forEach((m,i)=>{assert.equal(m.geometry,bm[i].geometry);assert.equal(m.material,bm[i].material);});animateFullModel(a,500,{moving:true,distance:150});assert.equal(a.getObjectByName('near').visible,false);assert.ok(meshes(a.getObjectByName('far')).length<=18);}
});
