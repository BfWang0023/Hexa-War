// Visual-only world-space mask built exclusively from an already permitted map.
// Unknown geometry is supplied by fog-policy's safe replacement, never the real map.
import * as T from '../vendor/three/three.module.js';
import {offsetToWorld,worldToOffset} from '../js/core/hex.js';
export const MIST_REVEAL_MS=350;
export const MIST_COLOR=0x353c2d;
const controllers=new WeakMap();
function boxBlur(src,w,h,r,axis){const dst=new Float32Array(src.length),outer=axis?h:w,inner=axis?w:h,stride=axis?1:w,baseStep=axis?w:1;for(let a=0;a<outer;a++){const base=a*baseStep;let sum=0;for(let k=-r;k<=r;k++)sum+=src[base+Math.max(0,Math.min(inner-1,k))*stride];for(let b=0;b<inner;b++){dst[base+b*stride]=sum/(r*2+1);sum+=src[base+Math.min(inner-1,b+r+1)*stride]-src[base+Math.max(0,b-r)*stride];}}return dst;}
export function createMistPixels(m,density=4){const far=offsetToWorld(m.cols-1,m.rows-1),bounds=[-6,-6,far.x+24,far.z+12],width=m.cols*density+8,height=m.rows*density+8,unknown=new Float32Array(width*height),stale=new Float32Array(width*height);
for(let y=0;y<height;y++)for(let x=0;x<width;x++){const p=worldToOffset(bounds[0]+x/(width-1)*bounds[2],bounds[1]+y/(height-1)*bounds[3]),c=Math.max(0,Math.min(m.cols-1,p.col)),r=Math.max(0,Math.min(m.rows-1,p.row)),i=r*m.cols+c,j=y*width+x;unknown[j]=m.unknown?.[i]?1:0;stale[j]=m.staleMask?.[i]?1:0;}
let u=unknown,s=stale;for(const r of (density===2?[1,2]:[2,3])){u=boxBlur(boxBlur(u,width,height,r,true),width,height,r,false);s=boxBlur(boxBlur(s,width,height,r,true),width,height,r,false);}
const pixels=new Uint8Array(width*height*4);for(let i=0;i<u.length;i++){pixels[i*4]=Math.round(u[i]*255);pixels[i*4+1]=Math.round(s[i]*255);pixels[i*4+3]=255;}return {pixels,width,height,bounds};}
function texture(data,w,h){const t=new T.DataTexture(data,w,h,T.RGBAFormat);t.minFilter=t.magFilter=T.LinearFilter;t.wrapS=t.wrapT=T.ClampToEdgeWrapping;t.generateMipmaps=false;t.needsUpdate=true;return t;}
export function refreshKnowledgeMist(m,now=performance.now()){
let hash=2166136261;for(let i=0;i<m.cols*m.rows;i++)hash=Math.imul(hash^((m.unknown?.[i]?1:0)|(m.staleMask?.[i]?2:0)),16777619);
let c=controllers.get(m);if(c&&c.hash===hash&&c.width===m.cols*4+8&&c.height===m.rows*4+8)return c;
const data=createMistPixels(m);if(!c){c={hash,width:data.width,height:data.height,bounds:data.bounds,current:texture(data.pixels,data.width,data.height),previous:texture(data.pixels.slice(),data.width,data.height),started:now-MIST_REVEAL_MS,builds:1,active:!!(m.unknown?.some(Boolean)||m.staleMask?.some(Boolean))};controllers.set(m,c);return c;}
if(c.width!==data.width||c.height!==data.height){c.current.dispose();c.previous.dispose();controllers.delete(m);return refreshKnowledgeMist(m,now);}
// Blend from the currently displayed mask if edits arrive during an earlier reveal.
const t=c.pending?0:Math.max(0,Math.min(1,(now-c.started)/MIST_REVEAL_MS)),old=c.previous.image.data,current=c.current.image.data;for(let i=0;i<old.length;i++)old[i]=Math.round(old[i]*(1-t)+current[i]*t);
c.previous.needsUpdate=true;c.current.image.data=data.pixels;c.current.needsUpdate=true;c.started=now;c.pending=true;c.hash=hash;c.bounds=data.bounds;c.builds++;c.active=true;return c;
}
export function mistProgress(c,now=performance.now()){if(c.pending){c.started=now;c.pending=false;}return Math.max(0,Math.min(1,(now-c.started)/MIST_REVEAL_MS));}
export const mistController=m=>controllers.get(m)||refreshKnowledgeMist(m);
export function releaseKnowledgeMist(m){const c=controllers.get(m);c?.current.dispose();c?.previous.dispose();controllers.delete(m);}
export function attachKnowledgeMist(object,m,grid=false){const material=object.material;if(!material.userData.mistUniforms){const uniforms={mistCurrent:{value:null},mistPrevious:{value:null},mistBounds:{value:new T.Vector4()},mistBlend:{value:1},mistTime:{value:0},mistEnabled:{value:0}};material.userData.mistUniforms=uniforms;const original=material.onBeforeCompile;material.onBeforeCompile=shader=>{original?.(shader);Object.assign(shader.uniforms,uniforms);shader.vertexShader='varying vec2 mistWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvec4 mistP=vec4(position,1.0);\n#ifdef USE_INSTANCING\nmistP=instanceMatrix*mistP;\n#endif\nmistWorld=(modelMatrix*mistP).xz;');shader.fragmentShader=`varying vec2 mistWorld;uniform sampler2D mistCurrent;uniform sampler2D mistPrevious;uniform vec4 mistBounds;uniform float mistBlend;uniform float mistTime;uniform float mistEnabled;\n`+shader.fragmentShader;
const effect=`if(mistEnabled>.5){vec2 muv=(mistWorld-mistBounds.xy)/mistBounds.zw;vec2 mask=mix(texture2D(mistPrevious,muv).rg,texture2D(mistCurrent,muv).rg,mistBlend);float wave=sin(mistWorld.x*.023+sin(mistWorld.y*.017))*sin(mistWorld.y*.031-mistWorld.x*.009);float fog=smoothstep(.025+wave*.009,.63,mask.r);float memory=mask.g*(1.0-fog);`;
shader.fragmentShader=shader.fragmentShader.replace('#include <dithering_fragment>',effect+(grid?`gl_FragColor.a*=mix(1.0,.018,fog);gl_FragColor.rgb=mix(gl_FragColor.rgb,vec3(.24,.27,.20),fog);`:`float luminance=dot(gl_FragColor.rgb,vec3(.30,.59,.11));gl_FragColor.rgb=mix(gl_FragColor.rgb,mix(vec3(luminance),gl_FragColor.rgb,.6)*.70,memory*.68);vec3 fogColor=vec3(.197,.221,.166)+(wave*.009+sin(mistWorld.x*.009+mistWorld.y*.013)*.006);gl_FragColor.rgb=mix(gl_FragColor.rgb,fogColor,fog);`)+ '}\n#include <dithering_fragment>');};const key=material.customProgramCacheKey.bind(material);material.customProgramCacheKey=()=>key()+(grid?'-mist-grid-v3':'-mist-earth-v3');material.needsUpdate=true;}
object.onBeforeRender=()=>{const c=mistController(m),u=material.userData.mistUniforms;u.mistEnabled.value=c.active?1:0;u.mistCurrent.value=c.current;u.mistPrevious.value=c.previous;u.mistBounds.value.set(...c.bounds);u.mistBlend.value=mistProgress(c);u.mistTime.value=performance.now()*.001;};}
// Compatibility facade: the mist is now in the terrain/grid shader, with no floating mesh.
export function createKnowledgeMist(m){refreshKnowledgeMist(m);return {group:new T.Group(),update(){}};}
