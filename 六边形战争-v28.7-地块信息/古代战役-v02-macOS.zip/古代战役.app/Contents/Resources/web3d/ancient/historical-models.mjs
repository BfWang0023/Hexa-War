import * as T from '../vendor/three/three.module.js';
import {materials as M,part,oval,box,rod,joint,horse} from './models-v02.mjs';
import {loft,sweep,panel,cloth} from './historical-geometry.mjs';
const eye=(g,x,y,z,size=.035)=>{oval(g,M.mane,[x,y,z],[size,size*.8,size*.45]);};
function beastLeg(body,x,z,height,coat,elephant,low){
 const leg=joint(body,`beastleg:${x<0?-.8:.8}:${z<0?-1:1}`,[x,height,z]);
 const sign=x<0?-1:1,knee=elephant?[.03,-height*.50,0]:[sign*.11,-height*.48,0],foot=[elephant?.08:.04,-height+.43,.02];
 sweep(leg,coat,[[0,0,0],knee,foot],elephant?[.31,.23,.25]:[.15,.09,.085],{steps:low?5:10,sides:low?6:10});
 if(elephant){loft(leg,coat,[[foot[0],foot[1]-.15,0,.28,.25],[foot[0],foot[1]+.02,0,.26,.24]],{axis:'y',sides:10});for(const dz of [-.14,0,.14])oval(leg,M.ivory,[foot[0]+.24,foot[1]-.10,dz],[.035,.06,.055]);}
 else {for(const dz of [-.065,.065])oval(leg,M.camelHide,[foot[0]+.07,foot[1]-.13,dz],[.18,.09,.085]);oval(leg,M.leather,knee,[.11,.11,.10]);}
 return leg;
}
export function buildCamel(g,team,p,low){
 const body=joint(g,'beast-body',[0,0,0]);body.userData.anatomy='bactrian-pack-camel';
 loft(body,M.camelHide,[[-1.24,2.03,0,.08,.12],[-1.03,2.11,0,.43,.40],[-.55,2.15,0,.50,.53],[.10,2.16,0,.48,.52],[.75,2.11,0,.47,.39],[1.02,2.03,0,.28,.30]],{sides:low?8:16});
 for(const x of [-.91,.73])for(const z of [-.32,.32])beastLeg(body,x,z,1.97,M.camelHide,false,low);
 for(const x of [-.55,.46]){const hump=joint(body,'camel-hump',[x,0,0]);loft(hump,M.camelHide,[[0,2.37,0,.45,.42],[0,2.65,0,.34,.34],[-.04,2.91,0,.21,.22],[-.09,3.11,0,.055,.07]],{axis:'y',sides:low?7:12});}
 const head=joint(body,'beast-head',[0,0,0]);
 sweep(head,M.camelHide,[[.77,2.22,0],[1.22,1.98,0],[1.55,2.18,0],[1.65,2.73,0],[1.92,3.22,0]],[.30,.25,.19,.18],{steps:low?10:24,sides:low?7:12});
 loft(head,M.camelHide,[[1.78,3.22,0,.13,.15],[1.98,3.29,0,.23,.20],[2.23,3.22,0,.17,.18],[2.49,3.12,0,.13,.17],[2.57,3.10,0,.10,.12]],{sides:12});
 for(const side of [-1,1]){eye(head,2.09,3.34,side*.178);oval(head,M.mane,[2.46,3.17,side*.14],[.03,.018,.013]);const ear=oval(head,M.camelHide,[1.86,3.48,side*.19],[.085,.16,.055]);ear.rotation.x=side*.4;
  sweep(head,M.leather,[[1.9,3.43,side*.2],[2.15,3.20,side*.2],[2.47,3.09,side*.17]],[.019,.019],{steps:10,sides:5});
  const saddle=joint(body,'arrow-pannier',[0,2.07,side*.56]);box(saddle,M.leather,[0,0,0],[1.12,.67,.40]);box(saddle,M.linen,[0,.06,side*.21],[.93,.46,.035]);
  for(const x of [-.4,.4])rod(saddle,M.leather,[x,-.32,side*.22],[x,.35,side*.22],.027);
  for(let i=0;i<(low?4:9);i++){const x=-.42+i*(low?.27:.105),z=side*.1;rod(saddle,M.wood,[x,-.12,z],[x-.10,.93,z],.014);const f=box(saddle,M.linen,[x-.09,.84,z],[.065,.16,.018]);f.rotation.z=-.1;}
 }
 sweep(body,M.leather,[[-.7,2.58,-.53],[-.65,2.72,0],[-.7,2.58,.53]],[.035,.035],{steps:12});
 const tail=joint(body,'tail',[-1.17,2.21,0]);sweep(tail,M.camelHide,[[0,0,0],[-.12,-.48,0],[-.07,-.83,.06]],[.055,.025],{steps:8});oval(tail,M.mane,[-.07,-.83,.06],[.07,.15,.08]);
}
export function buildElephant(g,team,p,low,person){
 const body=joint(g,'beast-body',[0,0,0]);body.userData.anatomy='asian-elephant';
 loft(body,M.elephantHide,[[-1.73,2.18,0,.18,.23],[-1.42,2.29,0,.72,.73],[-.8,2.35,0,.93,.85],[.10,2.39,0,.96,.86],[.78,2.42,0,.83,.73],[1.17,2.46,0,.57,.54]],{sides:low?10:20});
 for(const x of [-1.05,.78])for(const z of [-.53,.53])beastLeg(body,x,z,2.05,M.elephantHide,true,low);
 const head=joint(body,'beast-head',[1.16,2.61,0]);
 loft(head,M.elephantHide,[[-.36,.04,0,.49,.48],[0,.14,0,.64,.57],[.39,.12,0,.58,.48],[.62,-.03,0,.37,.32]],{sides:low?10:16});
 // Double-domed forehead and small, scalloped Asian ears, not a metallic box.
 for(const side of [-1,1]){oval(head,M.elephantHide,[.09,.57,side*.22],[.31,.23,.27]);const ear=joint(head,'elephant-ear',[.02,.18,side*.46]);
  const e=panel(ear,M.elephantHide,[[-.15,.45],[.24,.42],[.42,.18],[.35,-.21],[.15,-.65],[-.08,-.76],[-.30,-.42],[-.32,.02]],.045);e.rotation.y=side*1.05;e.scale.x=1.25;
  eye(head,.45,.18,side*.405,.055);
  sweep(head,M.ivory,[[.55,-.30,side*.30],[.97,-.42,side*.43],[1.35,-.29,side*.46],[1.48,-.08,side*.44]],[.105,.07,.012],{steps:low?8:18,sides:8});
 }
 const trunk=joint(head,'trunk',[.62,-.09,0]);sweep(trunk,M.elephantHide,[[0,0,0],[.22,-.45,0],[.24,-1.10,0],[.35,-1.73,0],[.67,-1.89,0],[.82,-1.70,0]],[.28,.22,.15,.07],{steps:low?12:30,sides:low?7:12});
 
 const blanket=joint(body,'elephant-saddlecloth',[0,0,0]);
 cloth(blanket,team==='egypt'?M.indigo:M.cinnabar,[[[-.95,2.52,-.87],[-.95,3.19,-.49],[-.95,3.32,0],[-.95,3.19,.49],[-.95,2.52,.87]],[[0,2.42,-.91],[0,3.24,-.5],[0,3.40,0],[0,3.24,.5],[0,2.42,.91]],[[.65,2.52,-.76],[.65,3.16,-.44],[.65,3.28,0],[.65,3.16,.44],[.65,2.52,.76]]]);
 for(const side of [-1,1]){rod(blanket,M.gold,[-.95,2.52,side*.88],[.65,2.52,side*.77],.025);for(const x of [-.7,-.3,.1,.5]){const medal=panel(blanket,M.gold,[[0,.13],[.09,0],[0,-.13],[-.09,0]],.025);medal.position.set(x,2.70,side*.84);}}
 // Driver only; engine has trample, no invented turret archers or ranged weapon.
 person(body,team,{...p,culture:'mediterranean',royalStyle:null,weapon:'none',rangedWeapon:null,commander:false},[.95,2.38,0],.52,{rider:true});
 const tail=joint(body,'tail',[-1.55,2.49,0]);sweep(tail,M.elephantHide,[[0,0,0],[-.19,-.71,0],[-.1,-1.21,.1]],[.055,.027],{steps:10});oval(tail,M.mane,[-.1,-1.23,.1],[.07,.17,.065]);
}
function timberWheel(parent,x,z,low){const w=joint(parent,'wheel',[x,.58,z]);part(w,new T.CylinderGeometry(.46,.46,.17,low?10:16),M.darkWood,[0,0,0]).rotation.x=Math.PI/2;for(let i=0;i<3;i++){const a=i*Math.PI/3;rod(w,M.wood,[-.39*Math.cos(a),-.39*Math.sin(a),.1],[.39*Math.cos(a),.39*Math.sin(a),.1],.04);}oval(w,M.bronze,[0,0,.13],[.10,.10,.05]);}
export function buildTrojanHorse(g,team,p,low){
 const base=joint(g,'wooden-horse-platform',[0,0,0]);box(base,M.darkWood,[0,.78,0],[3.6,.20,1.9]);for(const x of [-1.12,1.12]){rod(base,M.wood,[x,.59,-1.13],[x,.59,1.13],.09);for(const z of [-1.04,1.04])timberWheel(base,x,z,low);}
 // Fixed wooden legs belong to the chassis, never to the living-animal gait rig.
 for(const x of [-1.07,.92])for(const z of [-.56,.56]){box(g,M.wood,[x,1.53,z],[.26,1.45,.28]);box(g,M.darkWood,[x+.04,.94,z],[.39,.19,.38]);for(const y of [1.12,1.75])box(g,M.darkWood,[x,y,z],[.29,.07,.30]);}
 const body=joint(g,'timber-hull',[0,0,0]);loft(body,M.wood,[[-1.5,2.58,0,.28,.33],[-1.25,2.65,0,.64,.66],[-.6,2.70,0,.73,.76],[.2,2.72,0,.73,.76],[.95,2.79,0,.65,.63],[1.2,2.88,0,.42,.43]],{sides:8});
 const neck=loft(body,M.wood,[[.80,2.85,0,.55,.51],[1.03,3.35,0,.47,.42],[1.11,3.91,0,.34,.33],[1.06,4.46,0,.28,.27],[1.18,4.75,0,.30,.25]],{axis:'y',sides:8});
 loft(body,M.wood,[[.96,4.65,0,.27,.26],[1.30,4.70,0,.34,.28],[1.63,4.51,0,.26,.23],[2.00,4.26,0,.19,.19],[2.19,4.22,0,.17,.17]],{sides:8});
 for(const side of [-1,1]){const e=panel(body,M.wood,[[.94,4.83],[.94,5.20],[1.10,4.91]],.12);e.position.z=side*.18;eye(body,1.46,4.75,side*.267,.08);
  for(const y of [2.30,2.53,2.77,3.0])rod(body,M.darkWood,[-1.15,y,side*.68],[.90,y,side*.64],.016);
  for(const x of [-1.16,-.55,.1,.74]){box(body,M.darkWood,[x,2.68,side*.72],[.075,1.05,.07]);for(const y of [2.22,3.06])oval(body,M.bronze,[x,y,side*.76],[.025,.025,.015]);}
  for(const x of [-.82,-.18,.47]){box(body,M.mane,[x,2.83,side*.77],[.28,.32,.035]);for(const dx of [-.16,.16])box(body,M.wood,[x+dx,2.83,side*.80],[.04,.39,.06]);box(body,M.wood,[x,3.02,side*.80],[.36,.04,.06]);}

 }
 for(const [y,x,rx,rz] of [[3.35,1.03,.47,.42],[3.62,1.07,.41,.38],[3.91,1.11,.34,.33],[4.18,1.08,.31,.30],[4.46,1.06,.28,.27]]){const pts=[];for(let j=0;j<=8;j++){const a=j/8*Math.PI*2;pts.push([x+(rx+.006)*Math.cos(a),y,(rz+.006)*Math.sin(a)]);}sweep(body,M.darkWood,pts,[.009,.009],{steps:16,sides:4});}
 for(let i=0;i<6;i++)box(body,M.darkWood,[.74,3.43+i*.21,0],[.18,.12,.62]);
 sweep(body,M.darkWood,[[-1.37,2.90,0],[-1.82,2.60,0],[-1.95,1.90,0]],[.11,.07],{steps:6,sides:5});
 // Side access ladder makes the hollow siege device legible at map scale.
 for(const x of [-.28,.1])rod(g,M.wood,[x,.88,1.05],[x,2.59,.79],.035);for(let i=0;i<7;i++)rod(g,M.wood,[-.28,1.04+i*.22,1.02-i*.032],[.1,1.04+i*.22,1.02-i*.032],.025);
}
export function buildEgyptianChariot(g,team,p,low,person){
 const royal=!!p.royalStyle,zs=[-.60,.60];zs.forEach((z,i)=>{const h=horse(g,z,i,true);if(royal){for(const side of [-1,1]){rod(h,M.gold,[.87,2.48,side*.23],[1.4,2.10,side*.19],.025);}}});
 const chassis=joint(g,'egyptian-open-chassis',[0,0,0]);
 const outline=[[-1.88,-.68],[-1.88,.68],[-.82,.72],[-.48,.49],[-.36,0],[-.48,-.49],[-.82,-.72]];
 const floor=new T.Shape();outline.forEach(([x,z],i)=>i?floor.lineTo(x,z):floor.moveTo(x,z));floor.closePath();const deck=part(chassis,new T.ExtrudeGeometry(floor,{depth:.10,bevelEnabled:false}),M.wood,[0,1.10,0]);deck.rotation.x=Math.PI/2;
 // Rear axle and open back; curved D-frame rather than a closed rectangular cart.
 rod(chassis,M.wood,[-1.68,.86,-1.04],[-1.68,.86,1.04],.075);
 for(const z of [-.94,.94]){const w=joint(g,'wheel',[-1.68,.86,z]);part(w,new T.TorusGeometry(.60,.055,5,low?14:24),M.wood,[0,0,0]);if(royal)part(w,new T.TorusGeometry(.60,.018,4,20),M.gold,[0,0,0]);for(let i=0;i<6;i++){const a=i*Math.PI/3;rod(w,M.wood,[0,0,0],[.56*Math.cos(a),.56*Math.sin(a),0],.027);}oval(w,M.bronze,[0,0,0],[.12,.12,.14]);}
 const rim=[[-1.82,1.78,-.70],[-.87,1.78,-.74],[-.40,1.78,-.43],[-.31,1.78,0],[-.40,1.78,.43],[-.87,1.78,.74],[-1.82,1.78,.70]];
 sweep(chassis,royal?M.gold:M.wood,rim,[.045,.045],{steps:low?14:30,sides:6});
 for(let i=0;i<rim.length;i++){const [x,y,z]=rim[i];rod(chassis,M.wood,[x,1.10,z],[x,y,z],.028);}
 for(const side of [-1,1]){const cover=cloth(chassis,royal?M.royalBlue:M.leather,[[[-1.72,1.15,side*.69],[-1.1,1.15,side*.74],[-.56,1.15,side*.55]],[[-1.72,1.64,side*.69],[-1.1,1.70,side*.74],[-.56,1.68,side*.55]]]);
  for(const x of [-1.6,-1.28,-.96]){rod(chassis,M.gold,[x,1.20,side*.75],[x+.14,1.62,side*.75],.012);rod(chassis,M.gold,[x,1.62,side*.75],[x+.14,1.20,side*.75],.012);}
  const q=joint(chassis,'chariot-quiver',[-.72,1.25,side*.76]);q.rotation.z=-.25;part(q,new T.CylinderGeometry(.10,.09,.65,8),M.leather,[0,.2,0]);for(let i=0;i<4;i++)rod(q,M.wood,[-.06+i*.04,.1,0],[-.06+i*.04,.74,0],.012);
 }
 sweep(chassis,M.wood,[[-1.57,1.08,0],[-.3,1.01,0],[.70,1.15,0],[1.30,1.35,0]],[.065,.05],{steps:14});
 sweep(chassis,M.wood,[[1.30,1.38,-.94],[1.30,1.52,-.60],[1.30,1.39,0],[1.30,1.52,.60],[1.30,1.38,.94]],[.045,.045],{steps:18});
 for(const z of zs)for(const dz of [-.14,.14])sweep(g,M.leather,[[2.10,2.17,z+dz],[.9,2.03,z*.85],[-.60,2.12,dz],[-1.21,2.25,-.29+dz*.3]],[.012,.012],{steps:10,sides:4});
 person(g,team,{...p,commander:false,royalStyle:null},[-1.27,1.01,-.35],.66,{crew:true});person(g,team,p,[-1.26,1.01,.36],.66);
}
export function decorateChineseChariot(g,team,p,low){
 const trim=joint(g,'chinese-lacquer-chariot',[0,0,0]),paint=team==='egypt'?M.indigo:M.cinnabar;
 for(const side of [-1,1]){box(trim,M.lacquer,[-1.28,1.48,side*.85],[1.50,.61,.04]);box(trim,paint,[-1.28,1.49,side*.88],[1.35,.44,.025]);
  for(const x of [-1.84,-1.51,-1.18,-.85]){box(trim,M.gold,[x,1.48,side*.91],[.035,.44,.025]);if(!low){rod(trim,M.gold,[x,1.35,side*.92],[x+.18,1.35,side*.92],.012);rod(trim,M.gold,[x+.18,1.35,side*.92],[x+.18,1.57,side*.92],.012);}}
 }
 const banner=joint(trim,'chariot-standard',[-1.92,1.15,-.76]);rod(banner,M.wood,[0,0,0],[0,2.6,0],.035);cloth(banner,paint,[[[0,2.5,0],[.38,2.48,.04],[.72,2.44,.02]],[[0,1.83,0],[.38,1.85,.07],[.72,1.78,.02]]]);for(const y of [1.9,2.11,2.32])rod(banner,M.gold,[.2,y,.065],[.5,y,.065],.012);
}

export function addAxleScythes(g){
 for(const side of [-1,1]){
  const hub=joint(g,'axle-scythe',[-1.22,.92,side*1.02]);hub.userData.side=side;
  rod(hub,M.iron,[0,0,0],[0,0,side*.27],.09);oval(hub,M.bronze,[0,0,side*.05],[.12,.12,.07]);
  // A broad, tapered, forward-hooking blade in the axle plane. The concave
  // cutting edge reads as a sickle even in the far silhouette.
  const blade=panel(hub,M.iron,[[-.09,.18],[-.11,.49],[-.02,.77],[.18,.99],[.42,1.09],[.20,.83],[.11,.58],[.10,.20]],.045);
  blade.rotation.x=side*Math.PI/2;blade.position.y=.022;
  sweep(hub,M.ivory,[[.10,0,side*.23],[.11,0,side*.58],[.20,0,side*.83],[.42,0,side*1.09]],[.012,.003],{steps:12,sides:4});
 }
}
