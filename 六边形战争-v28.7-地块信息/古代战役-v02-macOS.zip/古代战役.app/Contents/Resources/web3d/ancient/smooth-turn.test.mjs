import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {neighbors} from './engine.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {createUnitModel} from './models.mjs';
import {createUnitAnimator,headingBetween,angleDelta} from './unit-animation.mjs';
import {createSoldierCamera} from './soldier-camera.mjs';

function fixture(kind='heavy',options={}) {
 const u={id:1,kind,team:'egypt',hp:100,c:4,r:4,facing:0,formed:false,...options};
 const model=createUnitModel(u,'mantinea'),group=new T.Group(),camera=new T.PerspectiveCamera(),anim=createUnitAnimator();
 model.userData.unitId=u.id;const p=offsetToWorld(u.c,u.r);model.position.set(p.x,0,p.z);group.add(model);camera.position.set(0,20,30);anim.observe([u],0,{scenarioId:'mantinea'});
 function sample(time){anim.update(group,camera,time);model.updateMatrixWorld(true);return model.rotation.y;}
 function move(path,time=0){anim.move(u.id,u,path,time);anim.observe([{...u,...path.at(-1)}],time,{scenarioId:'mantinea'});const p=offsetToWorld(path.at(-1).c,path.at(-1).r);model.position.set(p.x,0,p.z);}
 return {u,model,group,camera,anim,sample,move};
}
for(const kind of ['heavy','cavalry','chinaHeavyChariot','supplyWagon'])test(`${kind}: marching turn eases in/out, arrives on time and follows shortest arc`,()=>{
 const f=fixture(kind),to=neighbors(f.u.c,f.u.r)[1],target=headingBetween(f.u,to);f.move([to]);const before=JSON.stringify(f.u),yaw=[];
 for(let t=0;t<=200;t+=10)yaw.push(f.sample(t));
 const travel=yaw.map(x=>angleDelta(yaw[0],x));assert.ok(Math.abs(travel[1])<Math.abs(target)*.04,'first step eases in');
 assert.ok(Math.abs(travel.at(-1)-travel.at(-2))<Math.abs(target)*.04,'last step eases out');
 assert.ok(travel.every((x,i)=>i===0||Math.abs(x)>=Math.abs(travel[i-1])-1e-9));
 assert.ok(Math.abs(angleDelta(yaw.at(-1),target))<1e-9);assert.ok(Math.abs(angleDelta(f.sample(340),target))<1e-9);assert.equal(JSON.stringify(f.u),before);
});
test('every path corner is continuous and angular velocity settles before the next segment',()=>{
 const f=fixture(),a=neighbors(f.u.c,f.u.r)[2],b=neighbors(a.c,a.r)[4];f.move([a,b]);
 for(const t of [0,340]){const start=f.sample(t),tiny=f.sample(t+.1);assert.ok(Math.abs(angleDelta(start,tiny))<1e-5);}
 assert.ok(Math.abs(angleDelta(f.sample(540),headingBetween(a,b)))<1e-9);assert.ok(Math.abs(angleDelta(f.sample(680),headingBetween(a,b)))<1e-9);
});
test('wrap across ±pi uses the short arc; opposite heading remains finite and monotonic',()=>{
 const f=fixture('heavy',{team:'coalition'}),to=neighbors(f.u.c,f.u.r)[2];f.move([to]);let old=f.sample(0),total=0;
 for(let t=5;t<=200;t+=5){const next=f.sample(t);total+=Math.abs(angleDelta(old,next));old=next;}
 assert.ok(total<Math.PI/2);assert.ok(Math.abs(angleDelta(old,headingBetween(f.u,to)))<1e-9);
 const opposite=fixture(),back=neighbors(opposite.u.c,opposite.u.r)[3];opposite.move([back]);for(let t=0;t<=200;t+=10)assert.ok(Number.isFinite(opposite.sample(t)));assert.ok(Math.abs(angleDelta(opposite.sample(200),Math.PI))<1e-9);
});
test('frame cadence and model rebuild do not restart a turn',()=>{
 const a=fixture(),b=fixture(),to=neighbors(a.u.c,a.u.r)[2];a.move([to]);b.move([to]);for(let t=0;t<125;t+=7)a.sample(t);assert.ok(Math.abs(angleDelta(a.sample(125),b.sample(125)))<1e-9);
 const model=createUnitModel({...a.u,...to},'mantinea');model.userData.unitId=a.u.id;const p=offsetToWorld(to.c,to.r);model.position.set(p.x,0,p.z);a.group.clear();a.group.add(model);a.anim.update(a.group,a.camera,125);assert.ok(Math.abs(angleDelta(model.rotation.y,b.model.rotation.y))<1e-9);
});
test('formed infantry retain shield/spear direction when moving sideways',()=>{
 const f=fixture('greekHoplite',{formed:true,facing:2}),to=neighbors(f.u.c,f.u.r)[0];f.move([to]);for(const t of [0,20,100,180,340])assert.ok(Math.abs(angleDelta(f.sample(t),headingBetween(f.u,neighbors(f.u.c,f.u.r)[2])))<1e-9);
});
test('direct follow camera rotates with the eased model, with no extra lag or rule change',()=>{
 const f=fixture(),to=neighbors(f.u.c,f.u.r)[1],camera=new T.PerspectiveCamera(),view=createSoldierCamera(camera);view.setStabilized(false);f.move([to]);f.sample(0);view.start(f.u,f.model);
 for(let t=0;t<=200;t+=10){const yaw=f.sample(t);view.update({...f.u,...to},f.model);const direction=viewCameraDirection();assert.ok(Math.abs(angleDelta(yaw,-Math.atan2(direction.z,direction.x)))<1e-9);}
 function viewCameraDirection(){const p=f.model.getObjectByName('near').getObjectByName('soldier').localToWorld(new T.Vector3(0,3.25,0));assert.ok(Number.isFinite(p.x));return camera.getWorldDirection(new T.Vector3());}
});
