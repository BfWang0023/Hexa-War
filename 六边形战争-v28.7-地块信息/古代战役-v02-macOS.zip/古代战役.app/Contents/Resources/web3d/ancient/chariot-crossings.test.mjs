import test from 'node:test';
import assert from 'node:assert/strict';
import {TERRAIN,newMap,setTerrain,setBridge,addUnit,startGame,mobileAt,reachable,move,endSide,destroyBridge,tile,exportMap,importMap,recomputeFog,attackPreview,deployUnit} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
function setup(bridge=false){
 const m=newMap(14,8);m.scenarioId='china_muye';
 for(let r=0;r<m.rows;r++)for(const c of [5,6])setTerrain(m,c,r,TERRAIN.RIVER);
 for(const c of [5,6]){setTerrain(m,c,3,TERRAIN.RIVER|TERRAIN.ROAD);if(bridge)setBridge(m,c,3);}
 setTerrain(m,4,3,TERRAIN.ROAD);addUnit(m,'pharaoh','egypt',0,0);addUnit(m,'chinaHeavyChariot','egypt',4,3);addUnit(m,'light','coalition',12,7);
 const s=startGame(m);return {s,u:mobileAt(s.map,4,3)};
}
test('Chinese heavy chariots cross fords step by step with existing river action costs',()=>{
 const {s,u}=setup();
 for(const c of [5,6,7]){
  assert.ok(reachable(s,u).has(`${c},3`));assert.equal(reachable(s,u).has(`${c+1},3`),false);
  const result=move(s,u.id,c,3);assert.ok(result.ok);assert.equal(result.riverMove,true);assert.equal(u.actionsLeft,0);
  endSide(s);endSide(s);
 }
 assert.equal(u.actionsLeft,2);
});
test('Chinese heavy chariots cross intact two-cell bridges at road speed',()=>{
 const {s,u}=setup(true);assert.ok(reachable(s,u).has('7,3'));assert.equal(reachable(s,u).has('5,2'),false);
 assert.equal(move(s,u.id,7,3).riverMove,false);assert.equal(u.actionsLeft,1);
});
test('demolishing a bridge under a chariot leaves a usable ford and saveable unit',()=>{
 const {s,u}=setup(true);assert.ok(move(s,u.id,5,3).ok);assert.ok(destroyBridge(s,u.id,5,3).ok);
 assert.equal(tile(s.map,5,3).terrain,TERRAIN.RIVER|TERRAIN.ROAD);
 const restored=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,'egypt'))));
 const g=restored.game,v=g.map.units.find(x=>x.id===u.id);assert.ok(importMap(exportMap(g.map)));
 endSide(g);endSide(g);assert.equal(v.actionsLeft,1);assert.ok(reachable(g,v).has('4,3'));assert.ok(move(g,v.id,4,3).ok);assert.equal(v.actionsLeft,0);
});
test('editing and deployment retain heavy chariots on a ford while blocking rough terrain',()=>{
 const {s,u}=setup();
 assert.ok(addUnit(s.map,'chinaHeavyChariot','egypt',5,3));
 setTerrain(s.map,5,3,TERRAIN.RIVER|TERRAIN.ROAD);assert.ok(mobileAt(s.map,5,3));
 for(const t of [TERRAIN.MOUNTAIN,TERRAIN.RIVER,TERRAIN.SEA,TERRAIN.BEACH]){
  setTerrain(s.map,9,3,t);assert.equal(addUnit(s.map,'chinaHeavyChariot','egypt',9,3),false);
 }
 setTerrain(s.map,9,3,TERRAIN.MOUNTAIN|TERRAIN.ROAD);assert.equal(addUnit(s.map,'chinaHeavyChariot','egypt',9,3),true);
 s.map.units=s.map.units.filter(x=>x.c!==5||x.r!==3);
 s.deploying=true;s.map.deployment={team:'egypt',cMin:1,cMax:7,rMin:1,rMax:5};assert.ok(deployUnit(s,u.id,5,3));
});
test('a chariot standing at a ford can still use its existing attack rules',()=>{
 const {s,u}=setup();assert.ok(move(s,u.id,5,3).ok);endSide(s);endSide(s);
 const foe=s.map.units.find(x=>x.team==='coalition');foe.c=6;foe.r=3;recomputeFog(s);assert.ok(attackPreview(s,u,6,3));
});
