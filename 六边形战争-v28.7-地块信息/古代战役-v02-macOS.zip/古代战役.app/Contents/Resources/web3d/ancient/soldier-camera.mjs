import * as THREE from '../vendor/three/three.module.js';

export const SOLDIER_CAMERA = Object.freeze({ height: 8, minHeight: 2, maxHeight: 24,
  pitch: 25, minPitch: 8, maxPitch: 75, fov: 60, near: .2,
  turnRate: THREE.MathUtils.degToRad(75), responseSeconds: .22, maxFrameSeconds: .05 });
export const canFollowSoldier = (unit, team, spectator = false) => !!unit && unit.hp > 0 &&
  unit.kind !== 'fort' && !unit.aboard && (spectator || unit.team === team);

// Presentation state only. The head anchor is cached per model instance; a scene
// rebuild gets a new anchor without retaining disposed models or rule objects.
export function createSoldierCamera(camera, onLost = () => {}) {
  let id = null, lens = null, height = SOLDIER_CAMERA.height, pitch = SOLDIER_CAMERA.pitch, yaw = 0;
  let stabilized = true, followHeading = 0, lastTime = null, holding = false;
  let pointerFollow = false, pointerYaw = 0, pointerPitch = 0, aimYaw = 0, aimPitch = 0;
  const anchors = new WeakMap(), anchor = new THREE.Vector3(), look = new THREE.Vector3();
  const clamp = THREE.MathUtils.clamp;
  function headAnchor(model) {
    let cached = anchors.get(model);
    if (!cached) {
      const human = model.getObjectByName('near')?.getObjectByName('soldier') ||
        model.getObjectByName('near')?.getObjectByName('rider');
      if (human) cached = { node: human, point: new THREE.Vector3(0, 3.25, 0) };
      else {
        const box = new THREE.Box3().setFromObject(model);
        const top = new THREE.Vector3(model.position.x, box.isEmpty() ? model.position.y + 3.25 : box.max.y, model.position.z);
        cached = { node: model, point: model.worldToLocal(top) };
      }
      // Bind a stable height to the piece root. Animated limbs/upper-body offsets
      // must not shake the gimbal, or orbit it around the piece during yaw.
      cached.stable = model.worldToLocal(cached.node.localToWorld(cached.point.clone()));
      cached.stable.x = 0; cached.stable.z = 0;
      anchors.set(model, cached);
    }
    return stabilized ? model.localToWorld(anchor.copy(cached.stable)) :
      cached.node.localToWorld(anchor.copy(cached.point));
  }
  function stop() {
    id = null; lastTime = null; holding = false;
    if (lens) { Object.assign(camera, lens); camera.updateProjectionMatrix(); lens = null; }
  }
  const api = {
    get id() { return id; }, get active() { return id !== null; },
    get holding() { return holding; }, get engaged() { return id !== null || holding; },
    get stabilized() { return stabilized; },
    get pointerFollow() { return pointerFollow; },
    setPointerFollow(value) {
      if (pointerFollow && !value) { yaw += pointerYaw; api.setPitch(pitch + pointerPitch); }
      pointerFollow = !!value; pointerYaw = pointerPitch = aimYaw = aimPitch = 0;
    },
    pointPointer(x, y) {
      if (!pointerFollow || !api.active || !Number.isFinite(x) || !Number.isFinite(y)) return;
      const tan = Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2);
      aimYaw = -Math.atan(clamp(x, -1, 1) * tan * camera.aspect);
      aimPitch = clamp(pitch + THREE.MathUtils.radToDeg(Math.atan(clamp(y, -1, 1) * tan)), SOLDIER_CAMERA.minPitch, SOLDIER_CAMERA.maxPitch) - pitch;
    },
    setStabilized(value) { stabilized = !!value; lastTime = null; },
    get height() { return height; }, get pitch() { return pitch; }, get anchor() { return anchor; },
    start(unit, model) {
      if (!unit || unit.id == null || unit.hp <= 0 || unit.aboard || unit.kind === 'fort' || !model) return false;
      if (!lens) lens = { fov: camera.fov, near: camera.near };
      id = unit.id; holding = false; yaw = 0; followHeading = model.rotation.y; lastTime = null;
      pointerYaw = pointerPitch = aimYaw = aimPitch = 0;
      camera.fov = SOLDIER_CAMERA.fov; camera.near = SOLDIER_CAMERA.near; camera.updateProjectionMatrix();
      return api.update(unit, model);
    },
    stop,
    setHeight(value) { if (Number.isFinite(value)) height = clamp(value, SOLDIER_CAMERA.minHeight, SOLDIER_CAMERA.maxHeight); },
    setPitch(value) { if (Number.isFinite(value)) pitch = clamp(value, SOLDIER_CAMERA.minPitch, SOLDIER_CAMERA.maxPitch); },
    rotate(dx, dy) {
      if (Number.isFinite(dx)) yaw = (yaw - dx * .006) % (Math.PI * 2);
      if (Number.isFinite(dy)) api.setPitch(pitch + dy * .15);
    },
    forward() { yaw = 0; pointerYaw = pointerPitch = aimYaw = aimPitch = 0; api.setPitch(SOLDIER_CAMERA.pitch); },
    update(unit, model, allowed = true, now = performance.now()) {
      if (!api.active) return false;
      let reason = null;
      if (!unit || unit.hp <= 0) reason = '跟随的部队已阵亡，请重新选择摄像头视角。';
      else if (unit.id !== id || !allowed || unit.aboard) reason = '该部队当前无法跟随，请重新选择摄像头视角。';
      if (reason) {
        // Keep the last rendered pose and lens until the player chooses another
        // target or explicitly returns to the map. Never recenter on loss.
        id = null; holding = true; lastTime = null; onLost(reason); return false;
      }
      // A render rebuild may temporarily replace the mesh. The authoritative
      // living target is still valid; wait without discarding its identity.
      if (!model) { lastTime = null; return false; }
      headAnchor(model);
      const time = Number.isFinite(now) ? now : performance.now();
      const dt = lastTime === null ? 0 : clamp((time - lastTime) / 1000, 0, SOLDIER_CAMERA.maxFrameSeconds);
      lastTime = time;
      if (stabilized) {
        const delta = Math.atan2(Math.sin(model.rotation.y - followHeading), Math.cos(model.rotation.y - followHeading));
        const eased = delta * (1 - Math.exp(-dt / SOLDIER_CAMERA.responseSeconds));
        followHeading += clamp(eased, -SOLDIER_CAMERA.turnRate * dt, SOLDIER_CAMERA.turnRate * dt);
        followHeading = Math.atan2(Math.sin(followHeading), Math.cos(followHeading));
      } else followHeading = model.rotation.y;
      // Mouse look is an independent offset, so deliberate input stays immediate.
      if (pointerFollow) {
        const blend = 1 - Math.exp(-dt / .12), cap = THREE.MathUtils.degToRad(120) * dt;
        pointerYaw += clamp((aimYaw - pointerYaw) * blend, -cap, cap);
        pointerPitch += clamp((aimPitch - pointerPitch) * blend, -120 * dt, 120 * dt);
      }
      const heading = followHeading + yaw + pointerYaw, down = THREE.MathUtils.degToRad(clamp(pitch + pointerPitch, 2, 85));
      camera.position.copy(anchor); camera.position.y += height;
      look.set(Math.cos(heading) * Math.cos(down), -Math.sin(down), -Math.sin(heading) * Math.cos(down));
      camera.lookAt(look.add(camera.position)); camera.updateMatrixWorld();
      return true;
    },
  };
  return api;
}

export function bindSoldierCamera(view, { document, candidates, getSelected, getModel, nameOf,
  overview, selected, isEditing }) {
  const $ = id => document.getElementById(id), dialog = $('camera-dialog');
  let pending = '', signature = '';
  try { view.setStabilized(document.defaultView?.localStorage?.getItem('ancient-camera-stabilized') !== 'off'); } catch {}
  try { view.setPointerFollow(document.defaultView?.localStorage?.getItem('ancient-camera-pointer') === 'on'); } catch {}
  function otherDialogOpen() { return [...document.querySelectorAll('dialog[open]')].some(d => d !== dialog); }
  function sync() {
    const units = dialog.open ? candidates() : [];
    const next = JSON.stringify(units.map(u => [u.id, nameOf(u), u.c, u.r]));
    if (dialog.open && next !== signature) {
      const choice = $('camera-unit').value; $('camera-unit').replaceChildren();
      const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = '请选择部队'; $('camera-unit').append(placeholder);
      for (const u of units) { const o = document.createElement('option'); o.value = u.id; o.textContent = `${nameOf(u)} · ${u.c + 1},${u.r + 1}`; $('camera-unit').append(o); }
      $('camera-unit').value = units.some(u => u.id === choice) ? choice : ''; signature = next;
    }
    $('camera-stabilized').checked = view.stabilized;
    $('camera-pointer').checked = view.pointerFollow;
    $('camera-confirm').disabled = !$('camera-unit').value;
    $('soldier-view').disabled = isEditing();
    const controls=$('follow-controls'),stage=controls.parentElement;
    controls.classList.toggle('hidden', !view.engaged);
    stage.classList.toggle('following-soldier',view.engaged);
    if(view.engaged)stage.style.setProperty('--follow-camera-bottom',`${controls.offsetTop+controls.offsetHeight+8}px`);
    $('camera-height').value = String(view.height); $('camera-height-value').textContent = view.height.toFixed(1);
    $('camera-pitch').value = String(view.pitch); $('camera-pitch-value').textContent = Math.round(view.pitch) + '°';
  }
  function reset() {
    pending = ''; view.stop(); if (dialog.open) dialog.close();
    signature = ''; sync(); overview();
  }
  function open(reason = '') {
    if (isEditing()) return;
    if (otherDialogOpen()) { pending = reason || '选择一支部队进入头顶跟随视角。'; return; }
    pending = ''; $('camera-message').textContent = reason || '镜头位于部队头顶上方，跟随其移动。请选择己方部队；观战模式可选择双方。';
    if (!dialog.open) { dialog.showModal(); signature = ''; }
    sync();
    const choice = reason ? '' : getSelected();
    if (choice && candidates().some(u => u.id === choice)) $('camera-unit').value = choice;
    else if (reason) $('camera-unit').value = '';
    $('camera-confirm').disabled = !$('camera-unit').value;
  }
  function lost(reason) { sync(); open(reason); }
  $('soldier-view').onclick = () => open();
  $('camera-unit').onchange = sync;
  $('camera-confirm').onclick = () => {
    const u = candidates().find(u => u.id === $('camera-unit').value);
    if (!u || !view.start(u, getModel(u.id))) { open('该部队当前无法跟随，请重新选择。'); return; }
    $('follow-unit-name').textContent = nameOf(u); dialog.close(); selected(u.id); sync();
  };
  $('camera-overview').onclick = reset; $('follow-exit').onclick = reset;
  $('follow-change').onclick = () => open(); $('follow-forward').onclick = () => { view.forward(); sync(); };
  $('camera-height').oninput = () => { view.setHeight(Number($('camera-height').value)); sync(); };
  $('camera-stabilized').onchange = () => {
    view.setStabilized($('camera-stabilized').checked);
    try { document.defaultView?.localStorage?.setItem('ancient-camera-stabilized', view.stabilized ? 'on' : 'off'); } catch {}
    sync();
  };
  $('camera-pitch').oninput = () => { view.setPitch(Number($('camera-pitch').value)); sync(); };
  $('camera-pointer').onchange = () => {
    view.setPointerFollow($('camera-pointer').checked);
    try { document.defaultView?.localStorage?.setItem('ancient-camera-pointer', view.pointerFollow ? 'on' : 'off'); } catch {}
    sync();
  };
  dialog.addEventListener('cancel', ev => { ev.preventDefault(); reset(); });
  document.defaultView?.addEventListener?.('resize',sync);
  return { reset, open, lost, sync, tick() { if (pending && !isEditing() && !otherDialogOpen()) open(pending); } };
}
