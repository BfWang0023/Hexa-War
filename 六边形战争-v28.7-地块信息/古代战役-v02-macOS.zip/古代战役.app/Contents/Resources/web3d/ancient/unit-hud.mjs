import {actionBadge,drawActionBadge,hudPlacement} from './action-badge.mjs';
import * as T from '../vendor/three/three.module.js';
import {unitMaxHp,FORT_HP,moraleOf,usesMorale,isRouted} from './engine.mjs';
import {unitSymbol,SYMBOL_SHAPES} from './unit-symbols.mjs';
export function statusValues(map,u){const hp=Math.max(0,Math.min(1,u.hp/(u.kind==='fort'?FORT_HP[u.level]:unitMaxHp(map,u)))),morale=moraleOf(u),routed=isRouted(u);return {hp,morale:Math.max(0,Math.min(1,morale/1.5)),usesMorale:usesMorale(u),routed,hpColor:hp>.6?'#78d39a':hp>.3?'#edca70':'#f47769',moraleColor:routed?'#a5a9ad':morale<.5?'#e3a655':'#71bdec',shaken:morale<.5&&!routed};}
export const hudDetail=(distance,selected=false)=>selected||distance<130?'full':distance<270?'compact':'far';
export function createUnitHUD(canvas){
 const ctx=canvas.getContext('2d',{alpha:true}),project=new T.Vector3(),box=new T.Box3(),size=new T.Vector3(),heights=new Map(),paths=new Map();let entries=[],hitboxes=[],map=null,models=new Map(),width=0,height=0,dpr=1;
 const stats={units:0,drawn:0,full:0,compact:0,far:0,aggregated:0,elapsedMs:0};
 function sync(units,m,modelMap,heightOf){map=m;models=modelMap;entries=units.map(u=>{const model=models.get(u.id),key=JSON.stringify([u.kind,u.team,u.formed,u.onFoot,m.scenarioId]),fallback=heightOf(u)+6;let y=heights.get(key);if(model&&y===undefined){box.setFromObject(model);y=box.max.y-model.position.y+.8;heights.set(key,y);}return {u,anchor:model?y:fallback,c:(u.c+(u.r&1)*.5)*Math.sqrt(3)*6,z:u.r*9};});}
 function render(camera,{w,h,selectedId,selectedIds=new Set(),following=false}={}){
  const start=performance.now(),ratio=Math.min(globalThis.devicePixelRatio||1,2);if(w!==width||h!==height||ratio!==dpr){width=w;height=h;dpr=ratio;canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);canvas.style.width=w+'px';canvas.style.height=h+'px';ctx.setTransform(dpr,0,0,dpr,0,0);}
  ctx.clearRect(0,0,w,h);hitboxes=[];Object.assign(stats,{units:entries.length,drawn:0,full:0,compact:0,far:0,aggregated:0});const buckets=new Set(),place=hudPlacement();
  // Selected and damaged troops get priority when far view is decluttered.
  let density='auto';try{density=localStorage.getItem('ancient-ap-density')||'auto';}catch{}
  const chosen=e=>e.u.id===selectedId||selectedIds.has(e.u.id);const ordered=[...entries.filter(chosen),...entries.filter(e=>!chosen(e))];for(const e of ordered){const u=e.u,model=models.get(u.id),selected=u.id===selectedId||selectedIds.has(u.id);if(u.hp<=0||model&&!model.visible)continue;
   const x=model?model.position.x:e.c,y=model?model.position.y+e.anchor:e.anchor,z=model?model.position.z:e.z;
   project.set(x,y,z);const dist=project.distanceTo(camera.position);project.project(camera);if(project.z<-1||project.z>1)continue;const sx=(project.x+1)*w/2,sy=(1-project.y)*h/2;if(sx<0||sx>w||sy<4||sy>h-4)continue;
   const mode=hudDetail(dist,selected),v=statusValues(map,u),bucket=Math.floor(sx/17)+','+Math.floor(sy/17);
   if(mode==='far'&&!selected&&buckets.has(bucket)){stats.aggregated++;continue;}buckets.add(bucket);
   const color=v.routed?'#a6aaac':u.team==='egypt'?'#78c9f1':'#ef9986',bw=mode==='full'?36:mode==='compact'?25:11,bh=mode==='full'?3:2,iconSize=mode==='full'?12:mode==='compact'?10:8,left=sx-bw/2;let top=sy-iconSize-10;const showAP=density!=='off',badge=actionBadge(u.actionsLeft,mode),extra=showAP?badge.radius*2+6:3;const lift=place({x:left-extra,y:top-3,w:bw+extra+3,h:iconSize+19});if(lift===null){stats.aggregated++;continue;}top-=lift;if(lift){ctx.save();ctx.strokeStyle="rgba(202,215,199,.38)";ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(sx,top+iconSize+12);ctx.lineTo(sx,sy+2);ctx.stroke();ctx.restore();}
   // Transparent badge: only the symbol, bars and selected outline cover the battlefield.
   ctx.globalAlpha=mode==='far'?.88:1;if(selected){ctx.strokeStyle='#f1d78c';ctx.lineWidth=1.5;ctx.strokeRect(left-3,top-2,bw+6,iconSize+12);}
   const icon=unitSymbol(u);if(!paths.has(icon.id))paths.set(icon.id,new Path2D(icon.path));ctx.save();ctx.translate(sx-iconSize/2,top);ctx.scale(iconSize/16,iconSize/16);ctx.strokeStyle=color;ctx.lineWidth=1.8;ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke(paths.get(icon.id));ctx.restore();
   if(mode!=='far'||selected){const by=top+iconSize+2;ctx.fillStyle='#33413c';ctx.fillRect(left,by,bw,bh);ctx.fillStyle=v.hpColor;ctx.fillRect(left,by,bw*v.hp,bh);ctx.fillStyle='#2a3943';ctx.fillRect(left,by+bh+2,bw,bh);ctx.fillStyle=v.moraleColor;if(v.usesMorale)ctx.fillRect(left,by+bh+2,bw*v.morale,bh);else {ctx.globalAlpha=.45;ctx.fillRect(left,by+bh+2,bw,bh);ctx.globalAlpha=1;}if(v.routed||v.shaken){ctx.strokeStyle=v.moraleColor;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,by+bh+1);ctx.lineTo(left+bw,by+bh+1);ctx.stroke();}}
   else {ctx.fillStyle=v.hpColor;ctx.fillRect(left,top+iconSize+2,bw*v.hp,1);}
   if(showAP)drawActionBadge(ctx,u.actionsLeft,mode,left,top+iconSize+2,mode==='far'?1:bh);
   hitboxes.push({id:u.id,x:left-extra,y:top-3,w:bw+extra+3,h:iconSize+19});stats.drawn++;stats[mode]++;
  }ctx.globalAlpha=1;stats.elapsedMs=performance.now()-start;return stats;
 }
 return {sync,render,pick(x,y){return [...hitboxes].reverse().find(b=>x>=b.x&&x<=b.x+b.w&&y>=b.y&&y<=b.y+b.h)?.id||null;},get hitboxes(){return hitboxes.map(x=>({...x}))},clear(){entries=[];hitboxes=[];heights.clear();ctx.clearRect(0,0,width,height);},stats};
}
export function symbolLegend(){return Object.values(SYMBOL_SHAPES).map(s=>`<span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="${s.path}"/></svg>${s.label}</span>`).join('');}
