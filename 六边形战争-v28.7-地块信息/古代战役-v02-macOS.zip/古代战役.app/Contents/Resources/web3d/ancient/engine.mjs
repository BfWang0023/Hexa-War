import {orderLocked,LOCK_REASON} from './order-lock.mjs';
import {phalanxTacticalAction} from './phalanx-tactics.mjs';
import {formationFront} from './phalanx-geometry.mjs';
import {lightMobileAction} from './light-mobile-ai.mjs';
import {ramConfig,ramEffect,ramText,recordSailing,sailingRun,sailingDirection,canRam} from './naval-ram.mjs';
import {seedScouts} from './scouts.mjs';
import {validFacing,facingName,inFront,facingDelta,clockToward} from './directions12.mjs';
import {recordBattleEvent,observeCasualties,combatActor,withCombatActor} from './turn-report.mjs';
import {validateCaptureDefinitions,initializeCapture,revealCaptureTopology,resolveFortificationContact,captureOptions,contactPoints} from './fortification-capture.mjs';
import {captureOutcome,endingSync,pursuitComplete} from './battle-ending.mjs';
import {usesChargeRules,chargeConfig,chargeCriticalConfig,resolveChargeCritical,chargeClass,chargeEffect,chargeText,recordChargeMove,interruptCharge,movementRun,runMatches} from './charge-rules.mjs';
import {initializeKnowledge,updateKnowledge,planningState,authoritativeState,isObservation,unitKnown} from './fog-policy.mjs';
import {captureRecon} from './reconnaissance.mjs';
import {ensureAutoElevation,regenerateElevation,validateAutoElevation} from './auto-elevation.mjs';
import { RULES_VERSION, ruleConfig, usesElevationRules, usesMountainMarchRules, materializeElevations, validateElevations, elevationEffect, elevationText } from './elevation-rules.mjs';
import {HELLENISTIC_IDS,hellenisticKinds} from './hellenistic-data.mjs';
// Ancient scenario engine. All hit points are integer tenths; display and JSON use one decimal.
import { TACTICAL_IDS as CLASSICAL_IDS, tacticalApproach as classicalApproach } from './classical-data.mjs';
import { validateClassical, importClassical, checkClassical, inClassicalArea, classicalFighter } from './classical-rules.mjs';
import { isChinaIronAgeScenario } from './china-era.mjs';
export const MAX_COLS = 160;
export const MAX_ROWS = 100;
export const TERRAIN = Object.freeze({ PLAIN: 0, ROAD: 1, MOUNTAIN: 2, RIVER: 4, SEA: 8, BEACH: 16 });
export const FORT_HP = Object.freeze([0, 200, 400, 1000]);
export const FORT_SHARE = Object.freeze([0, 4, 6, 8]);
export const FORT_ARMOR = Object.freeze([0, 1, 2, 3]);
export const MORALE_ROUT_THRESHOLD = 0.2;
export const ARMY_ROUT_FRACTION = 0.75;
const ELIMINATION_CAMPAIGNS = new Set(['china_kunyang', 'china_changping', 'china_qin_chu']);
export const KUNYANG_CITY_OBJECTIVE = Object.freeze({ c: 52, r: 24 });
export const CAMPAIGN_FINANCES = Object.freeze({
  china_changping: { startingMoney: { egypt: 800, coalition: 340 }, income: { egypt: 360, coalition: 155 } },
  china_qin_chu: { startingMoney: { egypt: 850, coalition: 330 }, income: { egypt: 400, coalition: 165 } },
  china_seven_states: { startingMoney: { egypt: 250, coalition: 650 }, income: { egypt: 75, coalition: 220 } },
  china_longxi: { startingMoney: { egypt: 650, coalition: 180 }, income: { egypt: 240, coalition: 70 } },
});
export function applyCampaignFinances(m) {
  const finance = CAMPAIGN_FINANCES[m?.scenarioId];
  if (finance && m.logistics) {
    m.logistics.startingMoney = { ...finance.startingMoney };
    m.logistics.income = { ...finance.income };
  }
  return m;
}
export const isChinaEliminationCampaign = m => ELIMINATION_CAMPAIGNS.has(m.scenarioId);
// Handan is relieved by defeating the besieging army, not by occupying its camp.
export const hasChinaCaptureObjective = m => m.victory?.mode === 'china' &&
  !isChinaEliminationCampaign(m) && m.scenarioId !== 'china_handan';
export const armyRoutFraction = m => isChinaEliminationCampaign(m) ? 0.8 : ARMY_ROUT_FRACTION;
export const KUNYANG_METEORS = Object.freeze({ interval: 2, count: 30, damage: 50, siegeMultiplier: 1.5,
  cMin: 12, cMax: 61, rMin: 7, rMax: 39 });
const TRIREMES = new Set(['athenianTrireme', 'alliedTrireme', 'phoenicianTrireme', 'imperialTrireme', 'siegeGalley',
  'octavianLiburnian', 'antonyHeavyGalley', 'cleopatraGalley', 'moraleFlagship']);
export const isTrireme = u => !!u && TRIREMES.has(u.kind);
export const isPhalangite = u => !!u && ['phalangite', 'greekHoplite'].includes(u.kind);
export const WIND_NAMES = Object.freeze(['东', '东北', '西北', '西', '西南', '东南']);
const commandKinds = new Set(['pharaoh', 'hittiteKing', 'hannibal', 'paullus', 'varro', 'scipio', 'masinissa', 'chinaGeneral']);
export const MORALE_GUARD_SCENARIOS = new Set(['china_changping', 'china_qin_chu',
  'china_seven_states', 'china_longxi']);
const veteranKinds = new Set(['guard', 'romanTriarii', 'romanLegion', 'romanPrincipes',
  'caesarReserve', 'pompeyLegion', 'zamaVeteran', 'africanInfantry', 'phalangite',
  'greekHoplite', 'companionCavalry', 'parthianCataphract']);
const ROMAN_LINE = new Set(['romanHastati', 'romanPrincipes', 'romanTriarii', 'romanLegion', 'caesarReserve', 'pompeyLegion']);
const PUNIC_CENTER = new Set(['gaulInfantry', 'iberianInfantry']);
export const isRomanLine = u => !!u && ROMAN_LINE.has(u.kind);
export const isFormableInfantry = u => isPhalangite(u) || isRomanLine(u);
export const usesMorale = u => !!u && !u.commander && !commandKinds.has(u.kind) &&
  !['moraleGuard', 'moraleFlagship'].includes(u.kind) &&
  (isTrireme(u) || !['fort', 'defenseTower', 'captive', 'hero', 'warship', 'transport', 'siegeRam', 'siegeTower', 'trojanHorse', 'warElephant', 'arrowCamel', 'supplyWagon'].includes(u.kind));
export const moraleOf = u => usesMorale(u) ? Math.min(u.cloudCovered ? 0.9 : 1.5,
  roundedMorale((u.morale ?? 1) + (u.commandAura || 0) + (u.moraleBoosts || []).reduce((sum, boost) => sum + boost.amount, 0))) : 1;
export const isRouted = u => !!u && (u.routed || u.uncontrolled || u.starvedRouted ||
  (usesMorale(u) && moraleOf(u) < MORALE_ROUT_THRESHOLD));
const isFleeingSoldier = u => !!u && (u.routed || u.starvedRouted ||
  (usesMorale(u) && moraleOf(u) < MORALE_ROUT_THRESHOLD));
const roundedMorale = value => Math.round(Math.min(1.5, Math.max(0, value)) * 100) / 100;
export const moraleLossFactor = u => veteranKinds.has(u.kind) ? 0.6 :
  ['heavy', 'chinaHeavyChariot', 'romanHastati', 'hittiteChariot'].includes(u.kind) ? 0.8 : 1;
function changeMorale(s, u, delta, reason) {
  if (!usesMorale(u) || u.hp <= 0 || u.routed) return;
  const before = moraleOf(u);
  u.morale = roundedMorale((u.morale ?? 1) + (delta < 0 ? delta * moraleLossFactor(u) : delta));
  if (before !== moraleOf(u)) s.log.push(`${unitName(s.map, u)}${reason}：士气 ${before.toFixed(2)}→${moraleOf(u).toFixed(2)}`);
  if (isRouted(u)) markRouted(s, u);
}
function markRouted(s, u) {
  if (u.routed || u.hp <= 0 || !usesMorale(u) && !u.starvedRouted) return;
  recordBattleEvent(s,'rout',u,combatActor(s));
  u.routed = true;
  u.hp = 10;
  u.ammo = 0;
  u.actionsLeft = 0;
  if (isFormableInfantry(u)) u.formed = false;
  s.log.push(`${unitName(s.map, u)}溃逃：移动力 1，无法攻防，生命值降至 1.0`);
}
function grantMoraleBoost(u, amount) {
  if (!usesMorale(u) || u.hp <= 0) return;
  (u.moraleBoosts ||= []).push({ amount, remaining: 3 });
}
export const TROY_COSTS = Object.freeze({ light: 8, heavy: 12, archer: 10, guard: 16,
  chariot: 150, hittiteChariot: 150, transport: 12, warship: 30, trojanHorse: 600 });
export const TROY_HORSE_UNLOCK_TURN = 61;
export const STATS = Object.freeze({
  scout: {name:'斥候', hp:40, armor:0, move:4, vision:8, melee:1, meleeHit:60, ranged:0, rangedHit:0, range:0, ammo:0},
  chariot: { mountedRole: 'skirmisher', name: '战车弓兵', hp: 60, armor: 1, move: 3, vision: 6, melee: 2, meleeHit: 60, ranged: 3, rangedHit: 80, range: 2, ammo: 999 },
  chinaHeavyChariot: { mountedRole: 'shock', chargeClass: 'heavyChariot', name: '先秦四马重战车', hp: 115, armor: 3, move: 3, vision: 6, melee: 6.5, meleeHit: 82, ranged: 5.5, rangedHit: 82, range: 2, ammo: 10 },
  hittiteChariot: { mountedRole: 'shock', chargeClass: 'heavyChariot', name: '赫梯重战车', hp: 90, armor: 2, move: 3, vision: 5, melee: 4.5, meleeHit: 80, ranged: 3, rangedHit: 70, range: 2, ammo: 1 },
  light: { name: '轻步兵', hp: 70, armor: 0, move: 2, vision: 4, melee: 2.5, meleeHit: 75, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  heavy: { name: '重步兵', hp: 100, armor: 2, move: 1, vision: 3, melee: 3, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  archer: { name: '弓箭手', hp: 60, armor: 0, move: 1, vision: 5, melee: 2, meleeHit: 55, ranged: 4, rangedHit: 75, range: 3, ammo: 999 },
  chinaCrossbow: { name: '先秦弩兵', hp: 55, armor: 0, move: 1, vision: 5, melee: 1, meleeHit: 55, ranged: 5.5, rangedHit: 78, range: 3, ammo: 999 },
  chinaGeneral: { name: '先秦统帅', hp: 155, armor: 2, move: 2, vision: 6, melee: 3.5, meleeHit: 78, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  moraleGuard: { name: '督战队', hp: 85, armor: 2, move: 2, vision: 5, melee: 2.5, meleeHit: 75, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  moraleFlagship: { name: '督战舰', hp: 190, armor: 2, move: 2, vision: 6, melee: 2.5, meleeHit: 72, ranged: 1.5, rangedHit: 70, range: 2, ammo: 999 },
  chinaFireOx: { name: '火牛阵', hp: 150, armor: 1, move: 3, vision: 4, melee: 5, meleeHit: 72, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  supplyWagon: { name: '粮秣运输队', hp: 90, armor: 0, move: 2, vision: 4, melee: 0, meleeHit: 0, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  guard: { name: '君主精锐卫队', hp: 90, armor: 2, move: 2, vision: 4, melee: 5, meleeHit: 85, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  pharaoh: { name: '法老', hp: 60, armor: 1, move: 2, vision: 5, melee: 2, meleeHit: 60, ranged: 3, rangedHit: 70, range: 2, ammo: 999 },
  hittiteKing: { name: '穆瓦塔利二世', hp: 80, armor: 2, move: 1, vision: 5, melee: 2, meleeHit: 60, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  warship: { name: '桨帆战船', hp: 300, armor: 2, move: 2, vision: 6, melee: 7.5, meleeHit: 80, ranged: 7, rangedHit: 75, range: 2, ammo: 999 },
  transport: { name: '运兵船', hp: 200, armor: 1, move: 1, vision: 4, melee: 0, meleeHit: 0, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  hero: { name: '英雄', hp: 400, armor: 5, move: 2, vision: 5, melee: 6, meleeHit: 85, ranged: 6, rangedHit: 75, range: 2, ammo: 10 },
  trojanHorse: { name: '特洛伊木马', hp: 400, armor: 30, move: 1, vision: 4, melee: 8, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  cavalry: { mountedRole: 'maneuver', name: '骑兵', hp: 80, armor: 1, move: 3, vision: 5, melee: 3, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  siegeRam: { name: '覆顶攻城槌车', hp: 180, armor: 2, move: 1, vision: 3, melee: 12, meleeHit: 85, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  captive: { name: '犹大流亡者', hp: 800, armor: 0, move: 0, vision: 0, melee: 0, meleeHit: 0, ranged: 0, range: 0, ammo: 0 },
  athenianTrireme: { name: '雅典三列桨战船', hp: 200, armor: 2, move: 3, vision: 5, melee: 4.5, meleeHit: 82, ranged: 2.5, rangedHit: 70, range: 2, ammo: 999 },
  alliedTrireme: { name: '希腊盟邦战船', hp: 220, armor: 3, move: 2, vision: 4, melee: 5.5, meleeHit: 82, ranged: 2.5, rangedHit: 70, range: 1, ammo: 999 },
  phoenicianTrireme: { name: '腓尼基战船', hp: 200, armor: 2, move: 3, vision: 5, melee: 4.5, meleeHit: 82, ranged: 3, rangedHit: 72, range: 2, ammo: 999 },
  imperialTrireme: { name: '波斯盟邦战船', hp: 200, armor: 2, move: 3, vision: 5, melee: 5, meleeHit: 80, ranged: 3, rangedHit: 72, range: 2, ammo: 999 },
  octavianLiburnian: { name: '屋大维舰队轻型战船', hp: 210, armor: 2, move: 3, vision: 6, melee: 5, meleeHit: 82, ranged: 3.5, rangedHit: 76, range: 2, ammo: 999 },
  antonyHeavyGalley: { name: '安东尼舰队重型战船', hp: 300, armor: 4, move: 2, vision: 5, melee: 6.5, meleeHit: 79, ranged: 4, rangedHit: 74, range: 2, ammo: 999 },
  cleopatraGalley: { name: '克娄巴特拉埃及战船', hp: 210, armor: 2, move: 3, vision: 6, melee: 4.5, meleeHit: 78, ranged: 3.5, rangedHit: 75, range: 2, ammo: 999 },
  phalangite: { name: '马其顿方阵重步兵', hp: 100, armor: 0, move: 2, vision: 4, melee: 2.5, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  greekHoplite: { name: '希腊重装步兵', hp: 150, armor: 2, move: 2, vision: 4, melee: 3.2, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  companionCavalry: { mountedRole: 'shock', chargeClass: 'cavalry', name: '马其顿伙伴骑兵', hp: 90, armor: 2, move: 3, vision: 5, melee: 4.5, meleeHit: 82, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  scythedChariot: { mountedRole: 'shock', chargeClass: 'heavyChariot', name: '波斯镰刀战车', hp: 90, armor: 1, move: 3, vision: 4, melee: 3.5, meleeHit: 72, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  warElephant: { name: '印度战象', hp: 320, armor: 4, move: 2, vision: 4, melee: 8, meleeHit: 78, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  engineer: { name: '攻城工程队', hp: 60, armor: 0, move: 2, vision: 4, melee: 0, meleeHit: 0, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  siegeGalley: { name: '舰载攻城器械船', hp: 230, armor: 3, move: 2, vision: 5, melee: 5, meleeHit: 75, ranged: 13, rangedHit: 72, range: 5, ammo: 999 },
  defenseTower: { name: '军港防御塔', hp: 240, armor: 4, move: 0, vision: 6, melee: 0, meleeHit: 0, ranged: 5, rangedHit: 80, range: 4, ammo: 999 },
  romanOnager: { name: '罗马扭力抛石机', hp: 120, armor: 2, move: 1, vision: 6, melee: 0, meleeHit: 0, ranged: 16, rangedHit: 72, range: 5, ammo: 16 },
  siegeTower: { name: '罗马大型攻城塔', hp: 260, armor: 5, move: 1, vision: 6, melee: 0, meleeHit: 0, ranged: 7, rangedHit: 78, range: 4, ammo: 999 },
  parthianHorseArcher: { mountedRole: 'skirmisher', name: '帕提亚骑射手', hp: 95, armor: 1, move: 4, vision: 6, melee: 1.5, meleeHit: 65, ranged: 4, rangedHit: 79, range: 3, ammo: 6 },
  parthianCataphract: { mountedRole: 'shock', chargeClass: 'cavalry', name: '帕提亚具装骑兵', hp: 155, armor: 4, move: 3, vision: 5, melee: 6, meleeHit: 84, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  arrowCamel: { name: '帕提亚驮箭骆驼', hp: 110, armor: 0, move: 2, vision: 4, melee: 0, meleeHit: 0, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  romanArcher: { name: '罗马弓箭手', hp: 80, armor: 1, move: 1, vision: 5, melee: 1.5, meleeHit: 65, ranged: 5, rangedHit: 78, range: 4, ammo: 999 },
  romanVelites: { name: '罗马投枪轻兵', hp: 80, armor: 0, move: 2, vision: 5, melee: 1.5, meleeHit: 72, ranged: 3, rangedHit: 75, range: 2, ammo: 6 },
  romanHastati: { name: '罗马青年兵', hp: 120, armor: 2, move: 1, vision: 4, melee: 4, meleeHit: 82, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  romanPrincipes: { name: '罗马壮年兵', hp: 140, armor: 3, move: 1, vision: 4, melee: 4.5, meleeHit: 84, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  romanTriarii: { name: '罗马后备枪兵', hp: 150, armor: 3, move: 1, vision: 4, melee: 4, meleeHit: 83, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  romanLegion: { name: '罗马军团重步兵', hp: 140, armor: 3, move: 1, vision: 4, melee: 4.5, meleeHit: 84, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  caesarReserve: { name: '恺撒第四线预备队', hp: 150, armor: 3, move: 1, vision: 4, melee: 5, meleeHit: 85, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  pompeyLegion: { name: '庞培军团重步兵', hp: 140, armor: 3, move: 1, vision: 4, melee: 4.5, meleeHit: 83, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  pompeyHorse: { mountedRole: 'shock', chargeClass: 'cavalry', name: '庞培同盟骑兵', hp: 140, armor: 2, move: 3, vision: 5, melee: 4.5, meleeHit: 81, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  romanHorse: { mountedRole: 'shock', chargeClass: 'cavalry', name: '罗马骑兵', hp: 120, armor: 2, move: 3, vision: 5, melee: 3.5, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  romanAlliedHorse: { mountedRole: 'maneuver', name: '罗马同盟骑兵', hp: 110, armor: 1, move: 3, vision: 5, melee: 3, meleeHit: 78, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  gaulInfantry: { name: '高卢步兵', hp: 110, armor: 1, move: 2, vision: 4, melee: 3.5, meleeHit: 78, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  iberianInfantry: { name: '伊比利亚步兵', hp: 120, armor: 2, move: 2, vision: 4, melee: 4, meleeHit: 80, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  africanInfantry: { name: '非洲重步兵', hp: 140, armor: 3, move: 1, vision: 4, melee: 4.5, meleeHit: 84, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  punicSkirmisher: { name: '迦太基投射轻兵', hp: 90, armor: 0, move: 2, vision: 5, melee: 1.5, meleeHit: 70, ranged: 3.5, rangedHit: 76, range: 3, ammo: 999 },
  punicHeavyHorse: { mountedRole: 'shock', chargeClass: 'cavalry', name: '伊比利亚·高卢骑兵', hp: 160, armor: 3, move: 3, vision: 5, melee: 5.5, meleeHit: 83, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  numidianHorse: { mountedRole: 'skirmisher', name: '努米底亚骑兵', hp: 100, armor: 1, move: 4, vision: 6, melee: 2.5, meleeHit: 76, ranged: 3.5, rangedHit: 78, range: 2, ammo: 8 },
  hannibal: { name: '汉尼拔', hp: 180, armor: 2, move: 2, vision: 6, melee: 2.5, meleeHit: 75, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  paullus: { name: '保卢斯', hp: 160, armor: 2, move: 2, vision: 5, melee: 2.5, meleeHit: 74, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  varro: { name: '瓦罗', hp: 160, armor: 2, move: 2, vision: 5, melee: 2.5, meleeHit: 74, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  scipio: { name: '西庇阿', hp: 170, armor: 3, move: 2, vision: 6, melee: 3, meleeHit: 78, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  masinissa: { mountedRole: 'skirmisher', name: '马西尼萨', hp: 160, armor: 2, move: 4, vision: 6, melee: 3.5, meleeHit: 80, ranged: 3, rangedHit: 77, range: 2, ammo: 8 },
  masinissaHorse: { mountedRole: 'skirmisher', name: '努米底亚盟军骑兵', hp: 110, armor: 1, move: 4, vision: 6, melee: 3, meleeHit: 79, ranged: 3.5, rangedHit: 78, range: 2, ammo: 8 },
  zamaPunicHorse: { mountedRole: 'maneuver', name: '迦太基本土骑兵', hp: 110, armor: 1, move: 3, vision: 5, melee: 3.5, meleeHit: 78, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  zamaVeteran: { name: '汉尼拔意大利老兵', hp: 160, armor: 3, move: 1, vision: 4, melee: 5, meleeHit: 86, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
  fort: { name: '城墙', hp: 0, armor: 0, move: 0, vision: 4, melee: 0, meleeHit: 0, ranged: 0, rangedHit: 0, range: 0, ammo: 0 },
});
export const EDITABLE_UNIT_STATS = Object.freeze({ hp: [1, 2000], armor: [0, 30], move: [0, 12],
  vision: [0, 20], melee: [0, 30], meleeHit: [0, 100], ranged: [0, 30],
  rangedHit: [0, 100], range: [0, 12], ammo: [0, 999] });
export const unitStats = (m, u) => ({ ...STATS[u.kind], ...(m?.unitStats?.[u.kind] || {}) });
export function setUnitStats(m, kind, values) {
  if (!STATS[kind] || kind === 'fort' || !values || typeof values !== 'object' || Array.isArray(values))
    throw new Error('兵种无效');
  const clean = {};
  for (const [field, value] of Object.entries(values)) {
    const limits = EDITABLE_UNIT_STATS[field];
    if (!limits || !Number.isFinite(value) || value < limits[0] || value > limits[1] ||
        (['hp', 'armor', 'move', 'vision', 'meleeHit', 'rangedHit', 'range', 'ammo'].includes(field) && !Number.isInteger(value)))
      throw new Error(`兵种数值无效：${field}`);
    if (value !== STATS[kind][field]) clean[field] = value;
  }
  const oldMax = unitMaxHp(m, { kind });
  const oldAmmo = unitStats(m, { kind }).ammo;
  m.unitStats ||= {};
  if (Object.keys(clean).length) m.unitStats[kind] = clean;
  else delete m.unitStats[kind];
  for (const u of m.units.filter(u => u.kind === kind && u.hp > 0)) {
    if (u.kind === 'supplyWagon' && u.wagonCaptureLoss) u.wagonCaptureLoss = Math.min(u.wagonCaptureLoss, unitStats(m, u).hp);
    u.hp = unitMaxHp(m, u) === 0 ? 0 : Math.max(1, Math.min(unitMaxHp(m, u), u.hp + unitMaxHp(m, u) - oldMax));
    u.ammo = Math.max(0, Math.min(unitStats(m, u).ammo, u.ammo + unitStats(m, u).ammo - oldAmmo));
  }
  return unitStats(m, { kind });
}
export const TROY_UNIT_NAMES = Object.freeze({
  'egypt:scout':'斥候', 'coalition:scout':'斥候',
  'egypt:pharaoh': '阿伽门农', 'coalition:hittiteKing': '普里阿摩斯',
  'egypt:captive': '阿开亚平民',
  'egypt:guard': '阿开亚近卫', 'coalition:guard': '特洛伊王家卫队',
  'egypt:chariot': '阿开亚弓战车', 'coalition:chariot': '特洛伊弓战车',
  'coalition:hittiteChariot': '特洛伊重战车',
  'egypt:heavy': '阿开亚重装步兵', 'coalition:heavy': '特洛伊重装步兵',
  'egypt:light': '阿开亚轻步兵', 'coalition:light': '特洛伊轻步兵',
  'egypt:archer': '阿开亚弓手', 'coalition:archer': '特洛伊弓手',
  'egypt:warship': '阿开亚桨帆战船', 'coalition:warship': '特洛伊桨帆战船',
  'egypt:transport': '阿开亚运兵船', 'coalition:transport': '特洛伊运兵船',
  'egypt:hero': '阿喀琉斯', 'coalition:hero': '赫克托',
  'egypt:trojanHorse': '特洛伊木马',
  'egypt:cavalry': '阿开亚骑兵', 'coalition:cavalry': '特洛伊骑兵',
  'egypt:siegeRam': '阿开亚攻城槌车',
  'egypt:engineer': '阿开亚工匠队', 'egypt:siegeGalley': '阿开亚攻城器械船',
});
export const QARQAR_UNIT_NAMES = Object.freeze({
  'egypt:pharaoh': '撒缦以色三世', 'coalition:hittiteKing': '哈达德埃泽尔',
  'egypt:captive': '亚述平民',
  'egypt:guard': '亚述王家卫队', 'coalition:guard': '诸王近卫',
  'egypt:heavy': '亚述重步兵', 'coalition:heavy': '联军重步兵',
  'egypt:light': '亚述轻步兵', 'coalition:light': '联军轻步兵',
  'egypt:archer': '亚述弓手', 'coalition:archer': '联军弓手',
  'egypt:chariot': '亚述战车', 'coalition:chariot': '联军战车',
  'egypt:cavalry': '亚述骑兵', 'coalition:cavalry': '联军骑兵',
  'egypt:siegeRam': '亚述覆顶攻城槌车',
});
export const BABYLON_UNIT_NAMES = Object.freeze({
  'egypt:pharaoh': '居鲁士', 'coalition:hittiteKing': '巴比伦城防官',
  'egypt:captive': '犹大流亡者',
  'egypt:guard': '波斯王家卫队', 'coalition:guard': '巴比伦宫廷卫队',
  'egypt:heavy': '波斯重步兵', 'coalition:heavy': '巴比伦重步兵',
  'egypt:light': '波斯轻步兵', 'coalition:light': '巴比伦轻步兵',
  'egypt:archer': '波斯弓手', 'coalition:archer': '巴比伦弓手',
  'egypt:chariot': '波斯战车', 'coalition:chariot': '巴比伦战车',
  'egypt:cavalry': '波斯骑兵', 'coalition:cavalry': '巴比伦骑兵',
  'egypt:siegeRam': '波斯攻城槌车',
});
export const SALAMIS_UNIT_NAMES = Object.freeze({
  'egypt:athenianTrireme': '雅典三列桨战船', 'egypt:alliedTrireme': '希腊盟邦战船',
  'coalition:phoenicianTrireme': '腓尼基战船', 'coalition:imperialTrireme': '波斯盟邦战船',
});
export const GAUGAMELA_UNIT_NAMES = Object.freeze({
  'egypt:pharaoh': '亚历山大', 'coalition:hittiteKing': '大流士三世',
  'egypt:phalangite': '马其顿萨里沙方阵', 'egypt:companionCavalry': '伙伴骑兵',
  'egypt:guard': '持盾卫队', 'egypt:light': '阿格里安投枪兵', 'egypt:archer': '马其顿弓手',
  'egypt:cavalry': '色萨利骑兵', 'coalition:cavalry': '波斯骑兵',
  'coalition:scythedChariot': '波斯镰刀战车', 'coalition:warElephant': '印度战象',
  'coalition:guard': '大流士王家卫队', 'coalition:heavy': '波斯军希腊雇佣兵',
  'coalition:light': '波斯轻步兵', 'coalition:archer': '波斯弓手',
});
export const ISSUS_UNIT_NAMES = Object.freeze({
  'egypt:pharaoh': '亚历山大', 'coalition:hittiteKing': '大流士三世',
  'egypt:phalangite': '马其顿萨里沙方阵', 'egypt:companionCavalry': '伙伴骑兵',
  'egypt:guard': '马其顿持盾卫队', 'egypt:light': '阿格里安轻步兵',
  'egypt:archer': '马其顿弓手', 'egypt:cavalry': '色萨利骑兵',
  'coalition:guard': '大流士王家卫队', 'coalition:heavy': '波斯军希腊雇佣重步兵',
  'coalition:light': '波斯轻步兵', 'coalition:archer': '波斯弓手',
  'coalition:cavalry': '波斯骑兵',
});
export const TYRE_UNIT_NAMES = Object.freeze({
  'egypt:pharaoh': '亚历山大', 'coalition:hittiteKing': '推罗城防统帅',
  'egypt:phalangite': '马其顿萨里沙方阵', 'egypt:companionCavalry': '伙伴骑兵',
  'egypt:guard': '马其顿持盾卫队', 'egypt:light': '马其顿轻步兵',
  'egypt:engineer': '马其顿攻城工程队', 'egypt:siegeRam': '马其顿攻城槌车',
  'egypt:archer': '马其顿弓手', 'egypt:heavy': '马其顿重步兵', 'egypt:alliedTrireme': '马其顿盟邦战船',
  'egypt:siegeGalley': '马其顿舰载攻城器械船', 'egypt:transport': '马其顿运兵船',
  'coalition:guard': '推罗精锐卫队', 'coalition:heavy': '推罗重步兵',
  'coalition:light': '推罗轻步兵', 'coalition:archer': '推罗弓手',
  'coalition:phoenicianTrireme': '推罗战船', 'coalition:imperialTrireme': '推罗快船',
});
export const fmt = hp => (hp / 10).toFixed(1);
export const unitName = (m, u) => u.customName || (u.commander ? `${u.commander}座舰` : m.unitNames?.[`${u.team}:${u.kind}`] || m.unitNames?.[u.kind] ||
  (m.scenarioId === 'troy' && TROY_UNIT_NAMES[`${u.team}:${u.kind}`]) ||
  (m.scenarioId === 'qarqar' && QARQAR_UNIT_NAMES[`${u.team}:${u.kind}`]) ||
  (m.scenarioId === 'babylon' && BABYLON_UNIT_NAMES[`${u.team}:${u.kind}`]) ||
  (m.scenarioId === 'gaugamela' && GAUGAMELA_UNIT_NAMES[`${u.team}:${u.kind}`]) ||
  (m.scenarioId === 'issus' && ISSUS_UNIT_NAMES[`${u.team}:${u.kind}`]) ||
  (m.scenarioId === 'tyre' && TYRE_UNIT_NAMES[`${u.team}:${u.kind}`]) ||
  (m.scenarioId === 'salamis' && SALAMIS_UNIT_NAMES[`${u.team}:${u.kind}`]) || STATS[u.kind].name);
export function heroPower(roll) {
  const cutoffs = [0.30, 0.54, 0.72, 0.84, 0.92, 0.97, 1];
  return 6 + cutoffs.findIndex(cutoff => Math.min(0.999999, Math.max(0, roll)) < cutoff);
}
const isIronAgeSoldier = (m, u) =>
  (['qarqar', 'babylon', 'gaugamela', 'issus', 'tyre'].includes(m?.scenarioId) ||
    isChinaIronAgeScenario(m?.scenarioId)) &&
  !['fort', 'captive', 'siegeRam', 'warElephant', 'engineer', 'chinaFireOx', 'supplyWagon'].includes(u.kind) && !isShip(u);
export const unitMaxHp = (m, u) => Math.max(0, unitStats(m, u).hp + (isIronAgeSoldier(m, u) ? 60 : 0) -
  (u.kind === 'supplyWagon' ? u.wagonCaptureLoss || 0 : 0));
export const unitArmor = (m, u) => isRouted(u) ? 0 :
  (isRomanLine(u) && !u.formed ? 1 : isPhalangite(u) && u.formed ? 2 : STATS[u.kind].armor) +
  (unitStats(m, u).armor - STATS[u.kind].armor) +
  (isIronAgeSoldier(m, u) ? 1 : 0);
export const rangedPower = (m, u) => isFleeingSoldier(u) ? 0 : unitStats(m, u).ranged && isIronAgeSoldier(m, u) ?
  unitStats(m, u).ranged + 1.5 : unitStats(m, u).ranged;
export const meleeHitChance = (u, m = null) => isFleeingSoldier(u) ? 0 :
  (isFormableInfantry(u) && !u.formed ? STATS.light.meleeHit : STATS[u.kind].meleeHit) +
  (unitStats(m, u).meleeHit - STATS[u.kind].meleeHit);
export const meleePower = (u, m = null) => {
  if (isFleeingSoldier(u)) return 0;
  const base = u.kind === 'warElephant' && u.uncontrolled ? 3 :
    isRomanLine(u) && !u.formed ? STATS.light.melee :
    u.alexander ? 4.5 : u.kind === 'greekHoplite' && u.formed ? 5 : isPhalangite(u) && u.formed ? 3.5 :
      u.kind === 'guard' && u.team === 'egypt' && !m?.scenarioId?.startsWith('china_') ?
        isIronAgeSoldier(m, u) ? 5 : 3.5 :
        STATS[u.kind].melee;
  return base + (unitStats(m, u).melee - STATS[u.kind].melee) + (isIronAgeSoldier(m, u) ? 1.5 : 0);
};
export function elephantPanicChance(m, attacker, elephant) {
  if (elephant.kind !== 'warElephant' || elephant.hp <= 0 || elephant.uncontrolled) return 0;
  const maxHp = unitMaxHp(m, elephant);
  const base = elephant.hp * 4 <= maxHp ? 0.55 : elephant.hp * 2 <= maxHp ? 0.15 : 0.05;
  return Math.round((base + (m.scenarioId === 'zama' && attacker.kind === 'romanVelites' ? 0.10 : 0)) * 100) / 100;
}
export const isShip = u => u.kind === 'warship' || u.kind === 'transport' || u.kind === 'siegeGalley' || isTrireme(u);
const canEmbark = u => ['light', 'heavy', 'archer', 'guard', 'engineer', 'chariot', 'hittiteChariot',
  'romanVelites', 'romanHastati', 'romanPrincipes', 'romanTriarii', 'romanLegion', 'romanArcher'].includes(u.kind);
export const carthageSeaSecured = s => s.map.scenarioId === 'carthage' &&
  !s.map.units.some(u => u.team === 'coalition' && u.hp > 0 && !isRouted(u) &&
    (isShip(u) && u.kind !== 'transport' || u.kind === 'defenseTower'));
const cargoSlots = u => ['chariot', 'hittiteChariot'].includes(u.kind) ? 2 : 1;
export const key = (c, r) => `${c},${r}`;
export const inBounds = (m, c, r) => Number.isInteger(c) && Number.isInteger(r) && c >= 0 && r >= 0 && c < m.cols && r < m.rows;
export const index = (m, c, r) => r * m.cols + c;
export const axial = (c, r) => [c - Math.floor(r / 2), r];
export function distance(a, b) {
  const [aq, ar] = axial(a.c, a.r), [bq, br] = axial(b.c, b.r);
  return (Math.abs(aq - bq) + Math.abs(ar - br) + Math.abs(aq + ar - bq - br)) / 2;
}
export function neighbors(c, r) {
  const [q, y] = axial(c, r);
  return [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]]
    .map(([dq, dr]) => ({ c: q + dq + Math.floor((y + dr) / 2), r: y + dr }));
}
export function crossbowAttackLimit(m, u) {
  if (u?.kind !== 'chinaCrossbow') return 0;
  if ((u.movesUsed || 0) >= 2) return 0;
  if ((u.movesUsed || 0) === 1) return 1;
  const support = neighbors(u.c, u.r).filter(p => {
    const ally = mobileAt(m, p.c, p.r);
    return ally?.team === u.team && ally.kind === 'chinaCrossbow' && !isRouted(ally);
  }).length;
  return Math.min(3, 1 + support);
}
const crossbowBonusShot = (s, u) => u?.kind === 'chinaCrossbow' && u.actionsLeft === 0 &&
  (u.attacksUsed || 0) === 2 && (u.movesUsed || 0) === 0 &&
  crossbowAttackLimit(s.map, u) === 3;
const validTeam = team => team === 'egypt' || team === 'coalition';
export const canPlaceKind = (kind, team, scenarioId = null) => !!STATS[kind] && kind !== 'fort' && validTeam(team) &&
  (!['moraleGuard', 'moraleFlagship'].includes(kind) || !!scenarioId) &&
  (scenarioId?.startsWith('custom_') ||
  (!['chinaGeneral', 'chinaCrossbow', 'chinaFireOx', 'chinaHeavyChariot'].includes(kind) || scenarioId?.startsWith('china_')) &&
  (kind !== 'supplyWagon' || ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi'].includes(scenarioId)) &&
  (kind !== 'greekHoplite' || scenarioId === 'mantinea' || CLASSICAL_IDS.has(scenarioId)) &&
  (!['romanVelites', 'romanHastati', 'romanPrincipes', 'romanTriarii', 'romanLegion', 'caesarReserve', 'romanHorse', 'romanAlliedHorse', 'romanOnager', 'siegeTower', 'romanArcher', 'paullus', 'varro', 'scipio', 'masinissa', 'masinissaHorse'].includes(kind) || team === 'egypt') &&
  (!['gaulInfantry', 'iberianInfantry', 'africanInfantry', 'punicSkirmisher', 'punicHeavyHorse', 'pompeyLegion', 'pompeyHorse', 'numidianHorse', 'hannibal', 'zamaPunicHorse', 'zamaVeteran', 'parthianHorseArcher', 'parthianCataphract', 'arrowCamel'].includes(kind) || team === 'coalition') &&
  (!isTrireme({ kind }) || kind === 'moraleFlagship' || (team === 'egypt' ? ['athenianTrireme', 'alliedTrireme', 'siegeGalley', 'octavianLiburnian'].includes(kind) :
    ['phoenicianTrireme', 'imperialTrireme', 'antonyHeavyGalley', 'cleopatraGalley'].includes(kind))) &&
  (kind !== 'octavianLiburnian' || team === 'egypt') &&
  (!['antonyHeavyGalley', 'cleopatraGalley'].includes(kind) || team === 'coalition') &&
  !(kind === 'pharaoh' && team !== 'egypt') &&
  !(kind === 'captive' && team !== 'egypt') &&
  !(kind === 'siegeRam' && team !== 'egypt' && scenarioId !== 'china_kunyang' && !Object.hasOwn(CAMPAIGN_FINANCES, scenarioId)) &&
  !(kind === 'defenseTower' && team !== 'coalition') &&
  !(kind === 'trojanHorse' && team !== 'egypt') &&
  !(['scythedChariot', 'warElephant'].includes(kind) && team !== 'coalition' &&
    !(HELLENISTIC_IDS.has(scenarioId) && hellenisticKinds(scenarioId, team).includes(kind))) &&
  !(kind === 'engineer' && team !== 'egypt') &&
  !(kind === 'siegeGalley' && team !== 'egypt') &&
  !(['hittiteChariot', 'hittiteKing'].includes(kind) && team !== 'coalition'));
const initialActions = (kind, terrain = TERRAIN.PLAIN, onBridge = false) => ['fort', 'captive'].includes(kind) ? 0 :
  kind === 'defenseTower' ? 3 : (terrain & TERRAIN.RIVER) && !onBridge ? 1 : 2;
export function newMap(cols = 80, rows = 48) {
  if (!Number.isInteger(cols) || !Number.isInteger(rows) || cols < 8 || rows < 4 || cols > MAX_COLS || rows > MAX_ROWS) {
    throw new Error(`地图尺寸须在 8×4 至 ${MAX_COLS}×${MAX_ROWS} 之间`);
  }
  return { scenarioId: null, name: '古代战役地图', factions: { egypt: '埃及', coalition: '对手' }, unitNames: null,
    victory: { leaderKind: 'pharaoh', leaderSide: 'egypt', leaderDeathWinner: 'coalition', annihilateSide: 'coalition', annihilationWinner: 'egypt' },
    intro: '固定兵力战斗开始。', cols, rows, terrain: new Uint8Array(cols * rows), landmarks: [], supplyPoints: [], deployment: null,
    reinforcements: [], recruitment: null, logistics: null, heroRelease: null, hectorSortieTurn: null, weather: null,
    houses: new Uint8Array(cols * rows), bridges: [], garden: null, units: [], unitStats: {} };
}
export function tile(m, c, r) { return inBounds(m, c, r) ? { terrain: m.terrain[index(m, c, r)] } : null; }
export const bridgeAt = (m, c, r) => !!m.bridges?.some(p => p.c === c && p.r === r);
export const isFord = (m, c, r) => !!(tile(m, c, r)?.terrain & TERRAIN.RIVER) && !bridgeAt(m, c, r);
const isWagonWater = (m, u, c, r) => u.kind === 'supplyWagon' &&
  (tile(m, c, r)?.terrain === TERRAIN.SEA ||
    !!(tile(m, c, r)?.terrain & TERRAIN.RIVER) && !(tile(m, c, r)?.terrain & TERRAIN.ROAD));
const wagonLanding = terrain => terrain === TERRAIN.PLAIN || !!(terrain & TERRAIN.ROAD);
export function setBridge(m, c, r, present = true) {
  if (!inBounds(m, c, r) || (present &&
      (m.terrain[index(m, c, r)] & (TERRAIN.ROAD | TERRAIN.RIVER)) !== (TERRAIN.ROAD | TERRAIN.RIVER))) return false;
  m.bridges ||= [];
  m.bridges = m.bridges.filter(p => p.c !== c || p.r !== r);
  if (present) m.bridges.push({ c, r });
  return true;
}
export function fortAt(m, c, r) { return m.units.find(u => u.kind === 'fort' && u.hp > 0 && u.c === c && u.r === r) || null; }
export function mobileAt(m, c, r) { return m.units.find(u => u.kind !== 'fort' && !u.aboard && u.hp > 0 && u.c === c && u.r === r) || null; }
export const houseAt = (m, c, r) => inBounds(m, c, r) && !!m.houses?.[index(m, c, r)];
export function setHouse(m, c, r, present = true) {
  if (!inBounds(m, c, r) || !m.houses) return false;
  if (present && (tile(m, c, r).terrain !== TERRAIN.PLAIN || fortAt(m, c, r) ||
      m.supplyPoints.some(p => p.c === c && p.r === r) ||
      (mobileAt(m, c, r) && (isChariot(mobileAt(m, c, r)) || mobileAt(m, c, r).kind === 'captive')))) return false;
  m.houses[index(m, c, r)] = present ? 1 : 0;
  return true;
}
function isChariot(u) { return !u.onFoot && ['chariot', 'chinaHeavyChariot', 'pharaoh', 'hittiteChariot', 'cavalry', 'siegeRam', 'romanOnager', 'siegeTower', 'trojanHorse', 'chinaFireOx',
  'companionCavalry', 'scythedChariot', 'warElephant', 'romanHorse', 'romanAlliedHorse',
  'punicHeavyHorse', 'numidianHorse', 'masinissa', 'masinissaHorse', 'zamaPunicHorse', 'pompeyHorse', 'parthianHorseArcher', 'parthianCataphract', 'arrowCamel'].includes(u.kind); }
function canEnterFort(u, fort) { return !fort || (u.kind !== 'chinaHeavyChariot' && !['siegeRam', 'romanOnager', 'siegeTower', 'warElephant', 'trojanHorse'].includes(u.kind) &&
  fort.team === u.team && (!isChariot(u) || fort.level >= 2)); }
// Crossing an empty allied low wall is distinct from mounting it to stay there.
export function canPassFort(u, fort) { return canEnterFort(u, fort) ||
  (!isShip(u) && fort?.team === u.team && fort.level === 1); }
// A road through a river is a ford; an intact bridge overlays that same terrain.
const chinaChariotBlocked = (kind, terrain, legacy = false) => kind === 'chinaHeavyChariot' &&
  (!!(terrain & (TERRAIN.SEA | TERRAIN.BEACH)) ||
    !!(terrain & TERRAIN.MOUNTAIN) && (legacy || !(terrain & TERRAIN.ROAD)) ||
    !!(terrain & TERRAIN.RIVER) && !(terrain & TERRAIN.ROAD));
export function setTerrain(m, c, r, terrain) {
  if (!inBounds(m, c, r) || !Number.isInteger(terrain) || !(terrain >= 0 && terrain <= 7 || terrain === 8 || terrain === 16)) return false;
  if (!m.autoElevation && m.elevations && ((m.terrain[index(m,c,r)] ^ terrain) & TERRAIN.MOUNTAIN)) m.elevations[index(m,c,r)] = (terrain & TERRAIN.MOUNTAIN) ? 1 : 0;
  m.terrain[index(m, c, r)] = terrain;
  if (m.autoElevation) regenerateElevation(m,[{c,r}]);
  if ((terrain & (TERRAIN.ROAD | TERRAIN.RIVER)) !== (TERRAIN.ROAD | TERRAIN.RIVER)) setBridge(m, c, r, false);
  if (terrain !== TERRAIN.PLAIN && m.houses) m.houses[index(m, c, r)] = 0;
  if ((terrain & TERRAIN.RIVER && !(terrain & TERRAIN.ROAD)) || terrain === TERRAIN.SEA) {
    m.units = m.units.filter(u => u.c !== c || u.r !== r || u.kind === 'supplyWagon' ||
      (terrain === TERRAIN.SEA && isShip(u)));
  } else m.units = m.units.filter(u => u.c !== c || u.r !== r || !isShip(u));
  if (chinaChariotBlocked('chinaHeavyChariot', terrain))
    m.units = m.units.filter(u => u.c !== c || u.r !== r || u.kind !== 'chinaHeavyChariot');
  if (terrain & TERRAIN.RIVER || terrain === TERRAIN.SEA) m.supplyPoints = m.supplyPoints.filter(p => p.c !== c || p.r !== r);
  m.supplyPoints = m.supplyPoints.filter(p => hasSupplyWalls(m, p));
  m.units = m.units.filter(u => !u.aboard || m.units.some(ship => ship.id === u.aboard));
  return true;
}
function drawRoad(m, points) {
  let current = null;
  for (const target of points) {
    if (!inBounds(m, target.c, target.r)) throw new Error('道路越界');
    if (!current) current = { ...target };
    while (distance(current, target) > 0) {
      m.terrain[index(m, current.c, current.r)] |= TERRAIN.ROAD;
      const next = neighbors(current.c, current.r)
        .filter(p => inBounds(m, p.c, p.r))
        .sort((a, b) => distance(a, target) - distance(b, target))[0];
      if (distance(next, target) >= distance(current, target)) throw new Error('道路连接失败');
      current = next;
    }
    m.terrain[index(m, current.c, current.r)] |= TERRAIN.ROAD;
  }
}
export function setFort(m, c, r, level, team = 'coalition', cityId = null) {
  if (!inBounds(m, c, r) || !Number.isInteger(level) || level < 0 || level > 3 || !validTeam(team)) return false;
  if (level && ((m.terrain[index(m, c, r)] & (TERRAIN.RIVER | TERRAIN.SEA)) || houseAt(m, c, r))) return false;
  const occupant = mobileAt(m, c, r);
  if (level && occupant && !canEnterFort(occupant, { team, level })) return false;
  m.units = m.units.filter(u => u.kind !== 'fort' || u.c !== c || u.r !== r);
  if (!level) {
    m.units = m.units.filter(u => u.kind !== 'defenseTower' || u.c !== c || u.r !== r);
    m.supplyPoints = m.supplyPoints.filter(p => hasSupplyWalls(m, p));
    return true;
  }
  m.supplyPoints = m.supplyPoints.filter(p => p.c !== c || p.r !== r);
  const id = `u${1 + Math.max(0, ...m.units.map(u => Number(u.id?.slice(1)) || 0))}`;
  m.units.push({ id, kind: 'fort', team, c, r, level, cityId, hp: FORT_HP[level], ammo: 0,
    actionsLeft: 0, movedSteps: 0, movesUsed: 0, interceptUsed: false });
  return true;
}
export function setSupplyPoint(m, c, r, team, cityId = null) {
  if (!inBounds(m, c, r) || !validTeam(team) ||
      (cityId !== null && (typeof cityId !== 'string' || !cityId.length)) ||
      (tile(m, c, r).terrain & (TERRAIN.RIVER | TERRAIN.SEA)) || fortAt(m, c, r)) return false;
  const walls = m.units.filter(u => u.kind === 'fort' && u.hp > 0 && u.team === team);
  if (!walls.some(u => cityId ? u.cityId === cityId : distance(u, { c, r }) <= 4)) return false;
  m.supplyPoints = m.supplyPoints.filter(p => p.c !== c || p.r !== r);
  m.supplyPoints.push({ c, r, team, cityId });
  return true;
}
function activeSupplyPoint(m, p) {
  return hasSupplyWalls(m, p, true);
}
function hasSupplyWalls(m, p, alive = false) {
  return m.units.some(u => u.kind === 'fort' && (!alive || u.hp > 0) && u.team === p.team &&
    (p.cityId ? u.cityId === p.cityId : distance(u, p) <= 4));
}
export function addUnit(m, kind, team, c, r) {
  if (!canPlaceKind(kind, team, m.scenarioId) || !inBounds(m, c, r)) return false;
  if (kind === 'defenseTower' && fortAt(m, c, r)?.team !== team) return false;
  const terrain = m.terrain[index(m, c, r)];
  if (chinaChariotBlocked(kind, terrain)) return false;
  if (isShip({ kind }) ? terrain !== TERRAIN.SEA : terrain === TERRAIN.SEA && kind !== 'supplyWagon') return false;
  if ((terrain & TERRAIN.RIVER) && !(terrain & TERRAIN.ROAD) && kind !== 'supplyWagon') return false;
  if (houseAt(m, c, r) && (['chariot', 'chinaHeavyChariot', 'hittiteChariot', 'cavalry', 'siegeRam', 'romanOnager', 'siegeTower', 'trojanHorse', 'captive',
      'companionCavalry', 'scythedChariot', 'warElephant', 'masinissa', 'masinissaHorse', 'zamaPunicHorse', 'chinaFireOx'].includes(kind) ||
      (kind === 'pharaoh' && !['troy', 'qarqar', 'babylon'].includes(m.scenarioId)))) return false;
  if ((['chariot', 'chinaHeavyChariot', 'hittiteChariot', 'cavalry', 'siegeRam', 'romanOnager', 'siegeTower', 'trojanHorse', 'companionCavalry', 'scythedChariot', 'warElephant', 'masinissa', 'masinissaHorse', 'zamaPunicHorse', 'chinaFireOx'].includes(kind) ||
      (kind === 'pharaoh' && !['troy', 'qarqar', 'babylon'].includes(m.scenarioId))) &&
      (terrain & TERRAIN.MOUNTAIN) && !(terrain & TERRAIN.ROAD)) return false;
  if (!canEnterFort({ kind, team, onFoot: ['troy', 'qarqar', 'babylon'].includes(m.scenarioId) && kind === 'pharaoh' }, fortAt(m, c, r))) return false;
  m.units = m.units.filter(u => u.kind === 'fort' || u.aboard || u.c !== c || u.r !== r);
  if (commandKinds.has(kind)) m.units = m.units.filter(u => u.kind !== kind ||
    (kind === 'chinaGeneral' && u.team !== team));
  const id = `u${1 + Math.max(0, ...m.units.map(u => Number(u.id?.slice(1)) || 0))}`;
  m.units.push({ id, kind, team, c, r, onFoot: ['troy', 'qarqar', 'babylon'].includes(m.scenarioId) && kind === 'pharaoh',
    alexander: ['gaugamela', 'issus'].includes(m.scenarioId) && kind === 'pharaoh',
    hp: unitMaxHp(m, { kind }), ammo: ['gaugamela', 'issus'].includes(m.scenarioId) && kind === 'pharaoh' ? 0 : unitStats(m, { kind }).ammo,
    morale: 1,
    ...(isTrireme({ kind }) || kind === 'siegeGalley' ? { facing: team === 'egypt' ? 3 : 2 } : {}),
    ...(isPhalangite({ kind }) ? { facing: team === 'egypt' ? 0 : 3 } : {}),
    ...(isPhalangite({ kind }) ? { formed: false, formationSteps: 0 } : {}),
    ...(isRomanLine({ kind }) ? { facing: 4, formed: false, formationSteps: 0 } : {}),
    ...(kind === 'warElephant' ? { uncontrolled: false } : {}),
    actionsLeft: initialActions(kind, terrain, bridgeAt(m, c, r)), movedSteps: 0, movesUsed: 0, attacksUsed: 0, interceptUsed: false });
  return true;
}
export function cargoOf(m, ship) { return m.units.filter(u => u.aboard === ship.id && u.hp > 0); }
export const cargoLoad = (m, ship) => cargoOf(m, ship).reduce((slots, u) => slots + cargoSlots(u), 0);
function addEmbarkedUnit(m, kind, team, ship) {
  if (!ship || ship.kind !== 'transport' || ship.team !== team || !canEmbark({ kind }) ||
      cargoLoad(m, ship) + cargoSlots({ kind }) > 2) return false;
  const id = `u${1 + Math.max(0, ...m.units.map(u => Number(u.id?.slice(1)) || 0))}`;
  m.units.push({ id, kind, team, c: ship.c, r: ship.r, aboard: ship.id,
    hp: unitMaxHp(m, { kind }), ammo: unitStats(m, { kind }).ammo, morale: 1, actionsLeft: 2, movedSteps: 0,
    movesUsed: 0, attacksUsed: 0, interceptUsed: false,
    ...(isRomanLine({ kind }) ? { facing: 4, formed: false, formationSteps: 0 } : {}) });
  return true;
}
export function embark(s, soldierId, shipId) {
  const soldier = s.map.units.find(u => u.id === soldierId && u.hp > 0);
  const ship = s.map.units.find(u => u.id === shipId && u.hp > 0);
  if (s.over || s.deploying || !soldier || !ship || soldier.team !== s.side || ship.team !== s.side ||
      ship.kind !== 'transport' || !canEmbark(soldier) || soldier.aboard || isRouted(soldier) || soldier.actionsLeft < 1 ||
      distance(soldier, ship) !== 1 || !(tile(s.map, soldier.c, soldier.r).terrain & TERRAIN.BEACH) ||
      cargoLoad(s.map, ship) + cargoSlots(soldier) > 2) return false;
  soldier.aboard = ship.id; soldier.c = ship.c; soldier.r = ship.r; interruptCharge(s,soldier.id); soldier.actionsLeft--;
  s.log.push(`${unitName(s.map, soldier)}登上${s.map.factions[ship.team]}运兵船`);
  recomputeFog(s); checkVictory(s); return true;
}
export function disembark(s, shipId, c, r, passengerId = null) {
  s=authoritativeState(s);
  const ship = s.map.units.find(u => u.id === shipId && u.hp > 0);
  const passenger = ship && (passengerId ? cargoOf(s.map, ship).find(u => u.id === passengerId) : cargoOf(s.map, ship)[0]);
  if (s.over || s.deploying || !ship || ship.team !== s.side || !passenger || isRouted(passenger) || passenger.actionsLeft < 1 ||
      distance(ship, { c, r }) !== 1 || !inBounds(s.map, c, r) ||
      !(tile(s.map, c, r).terrain & TERRAIN.BEACH) || mobileAt(s.map, c, r) ||
          !canEnterFort(passenger, fortAt(s.map, c, r))) return false;
  passenger.aboard = null; passenger.c = c; passenger.r = r; interruptCharge(s,passenger.id); passenger.actionsLeft--;
  s.log.push(`${unitName(s.map, passenger)}从运兵船登陆 ${c + 1},${r + 1}`);
  recomputeFog(s); checkVictory(s); return true;
}
function routRoster(m, team) {
  const mode = m.victory?.mode;
  return m.units.filter(u => u.team === team && !['fort', 'moraleFlagship'].includes(u.kind) &&
    (mode === 'salamis' || mode === 'actium' || m.scenarioId === 'aegospotami' ? isTrireme(u) && u.kind !== 'moraleFlagship' :
      mode === 'china' ? !['chinaGeneral', 'supplyWagon', 'moraleGuard'].includes(u.kind) :
      mode === 'syracuse' && team === 'egypt' ? !commandKinds.has(u.kind) && u.kind !== 'siegeGalley' :
      !commandKinds.has(u.kind) && !['captive', 'transport', 'engineer', 'arrowCamel', 'defenseTower', 'supplyWagon', 'moraleGuard'].includes(u.kind)));
}
export function armyRoutThreshold(m, team) {
  const deployed = routRoster(m, team).length;
  const planned = (m.reinforcements || []).filter(w => w.team === team && !w.repeatEvery)
    .reduce((n, w) => n + w.units.filter(u => !['transport', 'engineer', 'arrowCamel', 'supplyWagon', 'moraleGuard', 'moraleFlagship'].includes(u.kind)).length, 0);
  return Math.max(1, Math.ceil((deployed + planned) * armyRoutFraction(m)));
}
export function ensureMoraleGuards(m) {
  const added = [];
  for (const team of ['egypt', 'coalition']) {
    const ships = m.units.filter(u => u.team === team && u.hp > 0 && isShip(u) && usesMorale(u));
    if (ships.length >= 2 && !m.units.some(u => u.kind === 'moraleFlagship' && u.team === team)) {
      const anchor = ships.find(u => u.commander) || ships[Math.floor(ships.length / 2)];
      const enemies = m.units.filter(u => u.team !== team && u.hp > 0 && isShip(u));
      let placed = false;
      for (let radius = 1; radius <= 9 && !placed; radius++) {
        const candidates = [];
        for (let dr = -radius; dr <= radius; dr++) for (let dc = -radius; dc <= radius; dc++) {
          const c = anchor.c + dc, r = anchor.r + dr;
          if (Math.max(Math.abs(dc), Math.abs(dr)) !== radius || !inBounds(m, c, r) ||
              mobileAt(m, c, r) || tile(m, c, r).terrain !== TERRAIN.SEA) continue;
          const p = { c, r };
          candidates.push({ ...p, danger: enemies.length ? Math.min(...enemies.map(e => distance(p, e))) : 9 });
        }
        candidates.sort((a, b) => b.danger - a.danger);
        for (const p of candidates) if (p.danger >= 2 && addUnit(m, 'moraleFlagship', team, p.c, p.r)) {
          const flagship = m.units.at(-1);
          flagship.formation = `${m.factions[team]}督战舰`;
          added.push(flagship); placed = true; break;
        }
      }
    }
    if (m.units.some(u => u.kind === 'moraleGuard' && u.team === team)) continue;
    const fighters = routRoster(m, team);
    const planned = (m.reinforcements || []).filter(w => w.team === team && !w.repeatEvery)
      .flatMap(w => w.units).filter(u => !['fort', 'transport', 'engineer', 'arrowCamel',
        'supplyWagon', 'moraleGuard'].includes(u.kind) && !commandKinds.has(u.kind));
    if (fighters.length + planned.length <= 30 || !fighters.some(u => !isShip(u))) continue;
    const leader = m.units.find(u => u.team === team && u.hp > 0 &&
      (commandKinds.has(u.kind) || u.commander) && !isShip(u));
    const anchor = leader || fighters.find(u => u.hp > 0 && !isShip(u));
    if (!anchor) continue;
    const enemies = m.units.filter(u => u.team !== team && u.hp > 0 && !u.aboard &&
      u.kind !== 'fort' && !isShip(u));
    for (let radius = 1; radius <= 9 && !added.some(u => u.team === team && u.kind === 'moraleGuard'); radius++) {
      const candidates = [];
      for (let dr = -radius; dr <= radius; dr++) for (let dc = -radius; dc <= radius; dc++) {
        const c = anchor.c + dc, r = anchor.r + dr;
        if (Math.max(Math.abs(dc), Math.abs(dr)) !== radius || !inBounds(m, c, r) || mobileAt(m, c, r)) continue;
        const p = { c, r };
        const danger = enemies.length ? Math.min(...enemies.map(enemy => distance(p, enemy))) : 9;
        candidates.push({ ...p, danger });
      }
      candidates.sort((a, b) => b.danger - a.danger || distance(anchor, a) - distance(anchor, b));
      for (const p of candidates) if (p.danger >= 2 && addUnit(m, 'moraleGuard', team, p.c, p.r)) {
        const guard = m.units.at(-1);
        guard.formation = `${m.factions[team]}后方督战队`;
        added.push(guard);
        break;
      }
    }
  }
  return added;
}
function configureRoutThresholds(m) {
  const v = m.victory;
  if (!v || !m.scenarioId) return;
  const egypt = armyRoutThreshold(m, 'egypt'), coalition = armyRoutThreshold(m, 'coalition');
  v.routLosses = { egypt, coalition };
  if (['china', 'peloponnesian', 'classical'].includes(v.mode)) v.losses = { egypt, coalition };
  if (v.mode === 'salamis') { v.greekLosses = egypt; v.persianLosses = coalition; }
  if (v.mode === 'actium') { v.octavianLosses = egypt; v.antonyLosses = coalition; }
  if (v.mode === 'teutoburg') { v.romanLosses = egypt; v.germanLosses = coalition; }
  if (v.mode === 'carrhae') { v.romanLosses = egypt; v.parthianLosses = coalition; }
  if (['jerusalem', 'syracuse'].includes(v.mode)) v.romanLosses = egypt;
  if (v.mode === 'pydna') { v.romanLosses = egypt; v.macedonianLosses = coalition; }
  if (['cannae', 'zama'].includes(v.mode)) { v.romanLosses = egypt; v.punicLosses = coalition; }
  if (v.mode === 'pharsalus') { v.caesarLosses = egypt; v.pompeyLosses = coalition; }
  if (['gaugamela', 'issus'].includes(v.mode)) v.phalanxLosses = Math.ceil(
    m.units.filter(u => u.team === 'egypt' && u.kind === 'phalangite').length * ARMY_ROUT_FRACTION);
}
export function validateMap(m) {
  validateCaptureDefinitions(m);
  if (!m || !Number.isInteger(m.cols) || !Number.isInteger(m.rows) || m.cols < 8 || m.rows < 4 || m.cols > MAX_COLS || m.rows > MAX_ROWS || m.terrain?.length !== m.cols * m.rows || m.houses?.length !== m.cols * m.rows) throw new Error('地图尺寸无效');
  if (m.unitStats !== undefined && (!m.unitStats || typeof m.unitStats !== 'object' || Array.isArray(m.unitStats)))
    throw new Error('兵种数值无效');
  for (const [kind, values] of Object.entries(m.unitStats || {})) {
    if (!STATS[kind] || kind === 'fort' || !values || typeof values !== 'object' || Array.isArray(values))
      throw new Error('兵种数值无效');
    for (const [field, value] of Object.entries(values)) {
      const limits = EDITABLE_UNIT_STATS[field];
      if (!limits || !Number.isFinite(value) || value < limits[0] || value > limits[1] ||
          (['hp', 'armor', 'move', 'vision', 'meleeHit', 'rangedHit', 'range', 'ammo'].includes(field) && !Number.isInteger(value)))
        throw new Error(`兵种数值无效：${kind}.${field}`);
    }
  }
  if (!Array.isArray(m.bridges) || m.bridges.some((p, i) => !inBounds(m, p?.c, p?.r) ||
      (m.terrain[index(m, p.c, p.r)] & (TERRAIN.ROAD | TERRAIN.RIVER)) !== (TERRAIN.ROAD | TERRAIN.RIVER) ||
      m.bridges.findIndex(q => q.c === p.c && q.r === p.r) !== i)) throw new Error('桥梁数据无效');
  const v = m.victory;
  if (v?.mode === 'classical') {
    validateClassical(m, inBounds);
  } else if (v?.mode === 'china') {
    if (!m.scenarioId?.startsWith('china_') || !inBounds(m, v.objective?.c, v.objective?.r) ||
        !['egypt', 'coalition'].includes(v.attacker) ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 3 ||
        !['egypt', 'coalition'].every(team => Number.isInteger(v.losses?.[team]) && v.losses[team] >= 1 &&
          m.units.filter(u => u.team === team && u.kind === 'chinaGeneral').length === 1 &&
          m.units.filter(u => u.team === team && !['chinaGeneral', 'fort'].includes(u.kind)).length >= v.losses[team]) ||
        typeof v.breach !== 'boolean' || typeof v.objectiveName !== 'string' || v.objectiveName.length > 32)
      throw new Error('先秦战役兵力或目标无效');
  } else if (v?.mode === 'peloponnesian') {
    const naval = m.scenarioId === 'aegospotami';
    if (!['mantinea', 'aegospotami'].includes(m.scenarioId) ||
        v.variant !== m.scenarioId || !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        !['egypt', 'coalition'].every(team => Number.isInteger(v.losses?.[team]) &&
          v.losses[team] >= 1 && m.units.filter(u => u.team === team &&
            (naval ? isTrireme(u) : u.kind === 'greekHoplite')).length >= v.losses[team]) ||
        (naval && (!Number.isInteger(v.escapeShips) || v.escapeShips < 1 ||
          !inBounds(m, v.escape?.cMax, v.escape?.rMin) ||
          !inBounds(m, v.escape?.cMax, v.escape?.rMax) ||
          v.escape.rMin > v.escape.rMax)))
      throw new Error('伯罗奔尼撒战役兵力或目标无效');
  } else if (v?.mode === 'babylon') {
    if (!inBounds(m, v.rescue?.c, v.rescue?.r) || !inBounds(m, v.outer?.cMin, v.outer?.rMin) ||
        !inBounds(m, v.outer?.cMax, v.outer?.rMax) || v.outer.cMin >= v.outer.cMax || v.outer.rMin >= v.outer.rMax ||
        m.units.filter(u => u.kind === 'pharaoh' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'captive' && u.team === 'egypt' && u.c === v.rescue.c && u.r === v.rescue.r).length !== 1)
      throw new Error('巴比伦剧本目标或居鲁士无效');
  } else if (v?.mode === 'salamis') {
    if (m.scenarioId !== 'salamis' || !inBounds(m, v.bay?.cMin, v.bay?.rMin) ||
        !inBounds(m, v.bay?.cMax, v.bay?.rMax) || v.bay.cMin > v.bay.cMax ||
        v.bay.rMin > v.bay.rMax || !Number.isInteger(v.greekLosses) || v.greekLosses < 1 ||
        !Number.isInteger(v.persianLosses) || v.persianLosses < 1 ||
        !Number.isInteger(v.bayShips) || v.bayShips < 1 ||
        !m.units.some(u => u.team === 'egypt' && isTrireme(u)) ||
        !m.units.some(u => u.team === 'coalition' && isTrireme(u)))
      throw new Error('萨拉米斯海战目标或舰队无效');
  } else if (v?.mode === 'actium') {
    if (m.scenarioId !== 'actium' || !Number.isInteger(v.escape?.cMax) ||
        !Number.isInteger(v.escape?.rMin) || !Number.isInteger(v.escape?.rMax) ||
        !inBounds(m, v.escape.cMax, v.escape.rMin) || !inBounds(m, v.escape.cMax, v.escape.rMax) ||
        v.escape.rMin >= v.escape.rMax || !Number.isInteger(v.escortShips) || v.escortShips < 1 ||
        !Number.isInteger(v.octavianLosses) || v.octavianLosses < 1 ||
        !Number.isInteger(v.antonyLosses) || v.antonyLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        m.units.filter(u => u.team === 'coalition' && u.commander === '安东尼').length !== 1 ||
        m.units.filter(u => u.team === 'coalition' && u.commander === '克娄巴特拉').length !== 1 ||
        m.units.filter(u => u.team === 'egypt' && isTrireme(u)).length < v.octavianLosses ||
        m.units.filter(u => u.team === 'coalition' && isTrireme(u)).length < v.antonyLosses)
      throw new Error('亚克兴角海战目标或舰队无效');
  } else if (v?.mode === 'teutoburg') {
    if (m.scenarioId !== 'teutoburg' || !Number.isInteger(v.escape?.cMax) ||
        !Number.isInteger(v.escape?.rMin) || !Number.isInteger(v.escape?.rMax) ||
        !inBounds(m, v.escape.cMax, v.escape.rMin) || !inBounds(m, v.escape.cMax, v.escape.rMax) ||
        v.escape.rMin >= v.escape.rMax || !Number.isInteger(v.escapeUnits) || v.escapeUnits < 1 ||
        !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.germanLosses) || v.germanLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        m.units.filter(u => u.kind === 'scipio' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hannibal' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.team === 'egypt' && u.kind !== 'scipio').length < v.romanLosses ||
        m.units.filter(u => u.team === 'coalition' && u.kind !== 'hannibal').length < v.germanLosses)
      throw new Error('条顿森林剧本兵力或突围目标无效');
  } else if (v?.mode === 'carrhae') {
    if (m.scenarioId !== 'carrhae' || !Number.isInteger(v.escape?.cMax) ||
        !Number.isInteger(v.escape?.rMin) || !Number.isInteger(v.escape?.rMax) ||
        !inBounds(m,v.escape.cMax,v.escape.rMin) || !inBounds(m,v.escape.cMax,v.escape.rMax) ||
        v.escape.rMin >= v.escape.rMax ||
        !Number.isInteger(v.escapeUnits) || v.escapeUnits < 1 ||
        !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.parthianLosses) || v.parthianLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        m.units.filter(u => u.kind === 'scipio' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hannibal' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.kind === 'arrowCamel' && u.team === 'coalition').length < 1 ||
        m.units.filter(u => u.team === 'coalition' && ['parthianHorseArcher', 'parthianCataphract'].includes(u.kind)).length < v.parthianLosses ||
        m.units.filter(u => u.team === 'egypt' && !commandKinds.has(u.kind)).length < v.romanLosses)
      throw new Error('卡莱剧本部队、补给或突围目标无效');
  } else if (v?.mode === 'jerusalem') {
    if (m.scenarioId !== 'jerusalem' || !Array.isArray(v.stages) || v.stages.length !== 5 ||
        v.stages.some(stage => !inBounds(m, stage.c, stage.r) || typeof stage.name !== 'string' ||
          !Array.isArray(stage.walls) || !stage.walls.length ||
          stage.walls.some(wall => typeof wall !== 'string' ||
            !m.units.some(u => u.kind === 'fort' && u.cityId === wall && u.team === 'coalition'))) ||
        !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        m.units.filter(u => u.kind === 'scipio' && u.team === 'egypt').length !== 1 ||
        !m.units.some(u => u.kind === 'hannibal' && u.team === 'coalition') ||
        !m.units.some(u => u.kind === 'siegeTower' && u.team === 'egypt') ||
        !m.units.some(u => u.kind === 'romanOnager' && u.team === 'egypt') ||
        !m.units.some(u => u.kind === 'siegeRam' && u.team === 'egypt'))
      throw new Error('耶路撒冷围城目标、城墙或攻城器械无效');
  } else if (v?.mode === 'syracuse') {
    if (m.scenarioId !== 'syracuse' || !inBounds(m, v.capture?.c, v.capture?.r) ||
        !Array.isArray(v.walls) || v.walls.length !== 2 ||
        v.walls.some(id => !m.units.some(u => u.kind === 'fort' && u.cityId === id && u.team === 'coalition')) ||
        !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        !m.units.some(u => u.team === 'egypt' && u.kind === 'siegeGalley') ||
        !m.units.some(u => u.team === 'coalition' && u.kind === 'defenseTower'))
      throw new Error('叙拉古围城目标或陆海攻城部队无效');
  } else if (v?.mode === 'pydna') {
    if (m.scenarioId !== 'pydna' || !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.macedonianLosses) || v.macedonianLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        m.units.filter(u => u.team === 'egypt' && u.kind === 'scipio').length !== 1 ||
        m.units.filter(u => u.team === 'coalition' && u.kind === 'hannibal').length !== 1 ||
        m.units.filter(u => u.team === 'coalition' && u.kind === 'phalangite').length < 8 ||
        m.units.filter(u => u.team === 'egypt' && !commandKinds.has(u.kind)).length < v.romanLosses ||
        m.units.filter(u => u.team === 'coalition' && !commandKinds.has(u.kind)).length < v.macedonianLosses)
      throw new Error('彼得那会战兵力或胜负规则无效');
  } else if (v?.mode === 'cannae') {
    if (m.scenarioId !== 'cannae' || !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.punicLosses) || v.punicLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        ['paullus', 'varro'].some(kind => m.units.filter(u => u.kind === kind && u.team === 'egypt').length !== 1) ||
        m.units.filter(u => u.kind === 'hannibal' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.team === 'egypt' && !commandKinds.has(u.kind) && u.kind !== 'fort').length < v.romanLosses ||
        m.units.filter(u => u.team === 'coalition' && !commandKinds.has(u.kind) && u.kind !== 'fort').length < v.punicLosses)
      throw new Error('坎尼剧本兵力或胜负规则无效');
  } else if (v?.mode === 'zama') {
    if (m.scenarioId !== 'zama' || !Number.isInteger(v.romanLosses) || v.romanLosses < 1 ||
        !Number.isInteger(v.punicLosses) || v.punicLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        ['scipio', 'masinissa'].some(kind => m.units.filter(u => u.kind === kind && u.team === 'egypt').length !== 1) ||
        m.units.filter(u => u.kind === 'hannibal' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.team === 'egypt' && !commandKinds.has(u.kind) && u.kind !== 'fort').length < v.romanLosses ||
        m.units.filter(u => u.team === 'coalition' && !commandKinds.has(u.kind) && u.kind !== 'fort').length < v.punicLosses)
      throw new Error('扎马剧本兵力或胜负规则无效');
  } else if (v?.mode === 'pharsalus') {
    if (m.scenarioId !== 'pharsalus' || !Number.isInteger(v.caesarLosses) || v.caesarLosses < 1 ||
        !Number.isInteger(v.pompeyLosses) || v.pompeyLosses < 1 ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 2 ||
        m.units.filter(u => u.kind === 'scipio' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hannibal' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.kind === 'caesarReserve' && u.team === 'egypt').length < 4 ||
        m.units.filter(u => u.team === 'egypt' && !commandKinds.has(u.kind) && u.kind !== 'fort').length < v.caesarLosses ||
        m.units.filter(u => u.team === 'coalition' && !commandKinds.has(u.kind) && u.kind !== 'fort').length < v.pompeyLosses)
      throw new Error('法萨卢斯剧本兵力或胜负规则无效');
  } else if (v?.mode === 'gaugamela' || v?.mode === 'issus') {
    if (m.scenarioId !== v.mode || !Number.isInteger(v.phalanxLosses) || v.phalanxLosses < 1 ||
        m.units.filter(u => u.kind === 'pharaoh' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hittiteKing' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.kind === 'phalangite' && u.team === 'egypt').length < v.phalanxLosses)
      throw new Error('马其顿剧本指挥官或方阵目标无效');
  } else if (v?.mode === 'tyre') {
    const lanes = moleLanes(m);
    if (m.scenarioId !== 'tyre' || !inBounds(m, v.capture?.c, v.capture?.r) ||
        tile(m, v.capture.c, v.capture.r).terrain === TERRAIN.SEA ||
        !Number.isInteger(v.turnLimit) || v.turnLimit < 3 || !lanes.length || lanes.length > 3 ||
        lanes.some(lane => !Array.isArray(lane) || !lane.length || lane.some((cell, i) =>
          !Array.isArray(cell) || cell.length !== 2 || !inBounds(m, cell[0], cell[1]) ||
          ![TERRAIN.SEA, TERRAIN.ROAD].includes(tile(m, cell[0], cell[1]).terrain) ||
          (i > 0 && distance({ c: cell[0], r: cell[1] },
            { c: lane[i - 1][0], r: lane[i - 1][1] }) !== 1))) ||
        m.units.filter(u => u.kind === 'pharaoh' && u.team === 'egypt').length !== 1 ||
        !m.units.some(u => u.kind === 'engineer' && u.team === 'egypt') ||
        !m.units.some(u => u.team === 'coalition' && isShip(u)))
      throw new Error('推罗剧本城池、堤道或攻城军无效');
  } else if (v?.mode === 'carthage') {
    if (m.scenarioId !== 'carthage' || !Number.isInteger(v.turnLimit) || v.turnLimit < 3 ||
        ![v.harbor, v.byrsa].every(p => inBounds(m, p?.c, p?.r) &&
          tile(m, p.c, p.r).terrain !== TERRAIN.SEA) ||
        v.harbor.c === v.byrsa.c && v.harbor.r === v.byrsa.r ||
        m.units.filter(u => u.kind === 'scipio' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hannibal' && u.team === 'coalition').length !== 1 ||
        !m.units.some(u => u.kind === 'siegeRam' && u.team === 'egypt') ||
        !m.units.some(u => u.kind === 'romanOnager' && u.team === 'egypt') ||
        !m.units.some(u => u.kind === 'romanArcher' && u.team === 'egypt') ||
        !m.units.some(u => u.kind === 'romanLegion' && u.team === 'egypt') ||
        !m.units.some(u => u.kind === 'fort' && u.team === 'coalition' && u.hp > 0) ||
        m.units.filter(u => u.kind === 'defenseTower' && u.team === 'coalition').length < 2 ||
        m.units.filter(u => u.kind === 'transport' && u.team === 'egypt' &&
          m.units.some(p => p.aboard === u.id && p.hp > 0)).length < 2)
      throw new Error('迦太基围城剧本目标、城墙或攻城军无效');
  } else if (v?.mode === 'alesia') {
    const rings = [v.inner, v.outer];
    if (m.scenarioId !== 'alesia' || v.turnLimit !== 24 || !inBounds(m, v.center?.c, v.center?.r) ||
        rings.some(ring => !Array.isArray(ring) || ring.length < 24 || ring.some(cell =>
          !Array.isArray(cell) || cell.length !== 2 || !inBounds(m, cell[0], cell[1]) ||
          tile(m, cell[0], cell[1]).terrain === TERRAIN.SEA)) ||
        !m.units.some(u => u.kind === 'engineer' && u.team === 'egypt') ||
        !m.units.some(u => u.alesiaOrigin === 'inner' && u.team === 'coalition') ||
        !m.reinforcements.some(w => w.turn === 8 && w.team === 'coalition'))
      throw new Error('阿莱西亚剧本工事、守军或援军无效');
  } else if (v?.mode === 'qarqar') {
    if (!inBounds(m, v.objective?.c, v.objective?.r) || !Number.isInteger(v.turnLimit) || v.turnLimit < 3 ||
        !Number.isInteger(v.holdTurns) || v.holdTurns < 1 ||
        m.units.filter(u => u.kind === 'pharaoh' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hittiteKing' && u.team === 'coalition').length !== 1)
      throw new Error('卡尔卡尔剧本目标或指挥官无效');
  } else if (v?.mode === 'troy') {
    if (!v.capture || !inBounds(m, v.capture.c, v.capture.r) || (tile(m, v.capture.c, v.capture.r).terrain & TERRAIN.SEA) ||
        !Number.isInteger(v.horseUnlockTurn) || v.horseUnlockTurn < 2 ||
        m.units.filter(u => u.kind === 'pharaoh' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hittiteKing' && u.team === 'coalition').length !== 1 ||
        m.units.filter(u => u.kind === 'hero' && u.team === 'egypt').length !== 1 ||
        m.units.filter(u => u.kind === 'hero' && u.team === 'coalition').length !== 1)
      throw new Error('特洛伊剧本需城内目标、双方君主与双方英雄各一枚');
  } else if (v?.mode === 'leader_duel') {
    if (!v.leaders || v.leaders.egypt !== 'pharaoh' || v.leaders.coalition !== 'hittiteKing' ||
        ['egypt', 'coalition'].some(team => m.units.filter(u => u.kind === v.leaders[team] && u.team === team).length !== 1))
      throw new Error('双方必须各有一枚君主棋子');
  } else {
    if (!v || !STATS[v.leaderKind] || v.leaderKind === 'fort' || !validTeam(v.leaderSide) ||
        !validTeam(v.leaderDeathWinner) || !validTeam(v.annihilateSide) || !validTeam(v.annihilationWinner) ||
        v.leaderSide === v.annihilateSide) throw new Error('胜负规则无效');
    if (m.units.filter(u => u.kind === v.leaderKind && u.team === v.leaderSide).length !== 1) throw new Error('必须恰有一枚君主棋子');
    if (!m.units.some(u => u.team === v.annihilateSide)) throw new Error('必须有敌方棋子');
  }
  if (m.deployment) {
    const d = m.deployment;
    if (d.team !== 'egypt' || !inBounds(m, d.cMin, d.rMin) || !inBounds(m, d.cMax, d.rMax) ||
        d.cMax < d.cMin || d.rMax < d.rMin) throw new Error('部署区域无效');
    if (m.units.some(u => u.team === d.team && u.kind !== 'fort' && !inDeployment(m, u.c, u.r))) throw new Error('埃及棋子须放在部署区域内');
  }
  if (m.heroRelease && (!validTeam(m.heroRelease.team) || !Number.isInteger(m.heroRelease.turn) ||
      m.heroRelease.turn < 2 || m.units.filter(u => u.kind === 'hero' && u.team === m.heroRelease.team).length !== 1))
    throw new Error('英雄出战回合无效');
  if (m.hectorSortieTurn !== null && (!Number.isInteger(m.hectorSortieTurn) || m.hectorSortieTurn < 2 ||
      m.scenarioId !== 'troy')) throw new Error('赫克托出城回合无效');
  if (m.weather && (!Number.isInteger(m.weather.windDir) || m.weather.windDir < 0 || m.weather.windDir > 5 ||
      !Array.isArray(m.weather.clouds) || m.weather.clouds.some(p =>
        !inBounds(m, p.c, p.r) || !Number.isInteger(p.radius) || p.radius < 1 || p.radius > 4)))
    throw new Error('天气设置无效');
  if (m.recruitment) {
    const r = m.recruitment;
    if (m.scenarioId !== 'troy' || !r.startingMoney || !r.income || !r.muster || !r.costs ||
        ['egypt', 'coalition'].some(team => !Number.isInteger(r.startingMoney[team]) || r.startingMoney[team] < 0 ||
          !Number.isInteger(r.income[team]) || r.income[team] < 0 ||
          !inBounds(m, r.muster[team]?.sea?.c, r.muster[team]?.sea?.r) ||
          tile(m, r.muster[team].sea.c, r.muster[team].sea.r).terrain !== TERRAIN.SEA) ||
        !inBounds(m, r.muster.coalition?.land?.c, r.muster.coalition?.land?.r) ||
        (tile(m, r.muster.coalition.land.c, r.muster.coalition.land.r).terrain & (TERRAIN.SEA | TERRAIN.RIVER)) ||
        !inBounds(m, r.muster.egypt?.land?.c, r.muster.egypt?.land?.r) ||
        (tile(m, r.muster.egypt.land.c, r.muster.egypt.land.r).terrain & (TERRAIN.SEA | TERRAIN.RIVER)) ||
        Object.keys(TROY_COSTS).some(kind => !Number.isInteger(r.costs[kind]) || r.costs[kind] < 1))
      throw new Error('特洛伊召集点或军费数据无效');
  }
  if (m.logistics) {
    const l = m.logistics;
    if (!['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi'].includes(m.scenarioId) ||
        m.victory.mode !== 'china' ||
        ['egypt', 'coalition'].some(team =>
          !Number.isInteger(l.startingMoney?.[team]) || l.startingMoney[team] < 0 ||
          !Number.isInteger(l.income?.[team]) || l.income[team] < 0 ||
          !Array.isArray(l.depots?.[team]) || !l.depots[team].length ||
          !Array.isArray(l.musters?.[team]) || !l.musters[team].length ||
          !Array.isArray(l.routes?.[team]) || !l.routes[team].length ||
          [...l.depots[team], ...l.musters[team], ...l.routes[team]].some(p =>
            !inBounds(m, p.c, p.r) || (tile(m, p.c, p.r).terrain & (TERRAIN.RIVER | TERRAIN.SEA)) &&
              !(tile(m, p.c, p.r).terrain & TERRAIN.ROAD))))
      throw new Error('财政、召集点或补给线数据无效');
  }
  if (!Array.isArray(m.supplyPoints) || new Set(m.supplyPoints.map(p => key(p.c, p.r))).size !== m.supplyPoints.length ||
      m.supplyPoints.some(p => !inBounds(m, p.c, p.r) || !validTeam(p.team) ||
        (p.cityId !== null && (typeof p.cityId !== 'string' || !p.cityId.length)) ||
        (tile(m, p.c, p.r).terrain & (TERRAIN.RIVER | TERRAIN.SEA)) ||
        m.units.some(u => u.kind === 'fort' && u.c === p.c && u.r === p.r) ||
        !hasSupplyWalls(m, p)))
    throw new Error('堡垒补给点数据无效');
  for (let i = 0; i < m.houses.length; i++) if (m.houses[i] &&
      (m.houses[i] !== 1 || m.terrain[i] !== TERRAIN.PLAIN ||
        m.units.some(u => u.kind === 'fort' && index(m, u.c, u.r) === i)))
    throw new Error('房屋数据无效');
  const slots = new Map();
  for (const u of m.units) {
    if (!STATS[u.kind] || !validTeam(u.team) || !inBounds(m, u.c, u.r)) throw new Error('棋子数据无效');
    if (u.morale !== undefined && (!Number.isFinite(u.morale) || u.morale < 0 || u.morale > 1.5 ||
        Math.abs(u.morale * 100 - Math.round(u.morale * 100)) > 1e-8 ||
        (!usesMorale(u) && u.morale !== 1))) throw new Error('士气数据无效');
    if (isTrireme(u) && (!validFacing(u.facing)))
      throw new Error('战船朝向无效');
    if (isPhalangite(u) && (!validFacing(u.facing) ||
        typeof u.formed !== 'boolean' || !Number.isInteger(u.formationSteps) ||
        u.formationSteps < 0 || u.formationSteps > 1)) throw new Error('方阵状态或朝向无效');
    if (isRomanLine(u) && (!validFacing(u.facing) ||
        typeof u.formed !== 'boolean' || !Number.isInteger(u.formationSteps) ||
        u.formationSteps < 0 || u.formationSteps > 1))
      throw new Error('罗马军团状态或朝向无效');
    if (u.kind === 'warElephant' && typeof u.uncontrolled !== 'boolean') throw new Error('战象状态无效');
    if (u.commander && (!isTrireme(u) || typeof u.commander !== 'string' || u.commander.length > 32))
      throw new Error('舰队指挥官无效');
    if (u.formation !== undefined && (typeof u.formation !== 'string' || u.formation.length > 40))
      throw new Error('战役编组名称无效');
    if (u.customName !== undefined && (typeof u.customName !== 'string' || !u.customName.trim() || u.customName.length > 32))
      throw new Error('部队名称无效');
    if (u.wagonCaptureLoss !== undefined && (u.kind !== 'supplyWagon' || !Number.isInteger(u.wagonCaptureLoss) ||
        u.wagonCaptureLoss < 0 || u.wagonCaptureLoss > unitStats(m, u).hp)) throw new Error('粮车争夺损耗无效');
    const t = tile(m, u.c, u.r).terrain;
    if ((t & TERRAIN.RIVER) && !(t & TERRAIN.ROAD) && u.kind !== 'supplyWagon') throw new Error('棋子不能放在无渡口的河流中');
    if (u.aboard) {
      const ship = m.units.find(v => v.id === u.aboard && v.hp > 0);
      if (!canEmbark(u) || !ship || ship.kind !== 'transport' || ship.team !== u.team ||
          ship.c !== u.c || ship.r !== u.r || cargoLoad(m, ship) > 2) throw new Error('运兵船载员无效');
      continue;
    }
    if (isShip(u) ? t !== TERRAIN.SEA : t === TERRAIN.SEA && u.kind !== 'supplyWagon')
      throw new Error('舰船只能在海域，普通陆军不能进入海域');
    if (u.kind === 'fort') {
      if (!Number.isInteger(u.level) || u.level < 1 || u.level > 3 || (t & (TERRAIN.RIVER | TERRAIN.SEA)) ||
          !Number.isInteger(u.hp) || u.hp < 0 || u.hp > FORT_HP[u.level]) throw new Error('堡垒棋子数据无效');
    } else {
      if (u.kind === 'defenseTower' && fortAt(m, u.c, u.r)?.team !== u.team)
        throw new Error('防御塔必须建在己方城墙上');
      if (isChariot(u) && (t & TERRAIN.MOUNTAIN) && !(t & TERRAIN.ROAD)) throw new Error('战车不能放在无道路的山地');
      if (chinaChariotBlocked(u.kind, t)) throw new Error('先秦重战车只能位于平原、平原道路、山区道路、渡口或桥梁');
      if (houseAt(m, u.c, u.r) && (isChariot(u) || u.kind === 'captive')) throw new Error('机动兵种不能进入房屋');
      if (!canEnterFort(u, fortAt(m, u.c, u.r))) throw new Error('城墙守军阵营或等级无效');
    }
    const slot = key(u.c, u.r), present = slots.get(slot) || {};
    const field = u.kind === 'fort' ? 'fort' : 'mobile';
    if (present[field] || (present.team && present.team !== u.team)) throw new Error('同一格只能有同阵营的守军与堡垒各一枚');
    present[field] = true; present.team = u.team; slots.set(slot, present);
  }
  if (m.terrain.some(t => t > 7 && t !== TERRAIN.SEA && t !== TERRAIN.BEACH)) throw new Error('地形数据无效');
  if (!Array.isArray(m.reinforcements) || m.reinforcements.some(e =>
    !Number.isInteger(e.turn) || e.turn < 2 || (e.repeatEvery !== undefined &&
      (!Number.isInteger(e.repeatEvery) || e.repeatEvery < 1)) || !validTeam(e.team) || !Array.isArray(e.units) ||
    e.units.some(u => !STATS[u.kind] || u.kind === 'fort' || u.kind === 'pharaoh' || u.kind === 'hittiteKing' ||
      !inBounds(m, u.c, u.r) || (u.cargo && (u.kind !== 'transport' || !Array.isArray(u.cargo) ||
        u.cargo.reduce((slots, kind) => slots + cargoSlots({ kind }), 0) > 2 ||
        u.cargo.some(kind => !canEmbark({ kind }))))))) throw new Error('援军数据无效');
  configureRoutThresholds(m);
  return true;
}
export function exportMap(m) {
  validateMap(m);
  const terrain = [], houses = [];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    const t = m.terrain[index(m, c, r)]; if (t) terrain.push([c, r, t]);
    if (houseAt(m, c, r)) houses.push([c, r]);
  }
  return { ...(m.fortificationSites?{fortificationSites:structuredClone(m.fortificationSites)}:{}), ...(m.autoElevation ? {autoElevation:structuredClone(m.autoElevation)} : {}), ...(m.elevations ? { elevations: Array.from(m.elevations) } : {}), format: 'hex_wargame.ancient.v2', scenarioId: m.scenarioId, name: m.name, factions: m.factions, unitNames: m.unitNames, unitStats: m.unitStats || {}, victory: m.victory,
    intro: m.intro, cols: m.cols, rows: m.rows, terrain, houses, bridges: m.bridges.map(p => [p.c, p.r]), garden: m.garden || null,
    landmarks: m.landmarks || [], supplyPoints: m.supplyPoints, deployment: m.deployment || null,
    reinforcements: m.reinforcements || [], recruitment: m.recruitment || null, logistics: m.logistics || null, heroRelease: m.heroRelease || null,
    hectorSortieTurn: m.hectorSortieTurn || null,
    weather: m.weather || null,
    units: m.units.map(u => u.kind === 'fort' ?
      { kind: 'fort', team: u.team, c: u.c, r: u.r, level: u.level, cityId: u.cityId || null, hp: Number(fmt(u.hp)) } :
      { kind: u.kind, team: u.team, c: u.c, r: u.r, scout: !!u.scout, pursuer: !!u.pursuer, morale: u.morale ?? 1,
        ...(u.customName ? { customName: u.customName } : {}),
        ...(u.formation ? { formation: u.formation } : {}),
        ...(u.deepRaider === true ? { deepRaider: true } : {}),
        ...(u.kind === 'supplyWagon' && u.wagonCaptureLoss ? { wagonCaptureLoss: u.wagonCaptureLoss } : {}),
        ...(isTrireme(u) ? { facing: u.facing, ...(u.commander ? { commander: u.commander } : {}) } : {}),
        ...(isPhalangite(u) ? { facing: u.facing, formed: u.formed } : {}),
        ...(isRomanLine(u) ? { facing: u.facing, formed: u.formed } : {}),
        ...(u.kind === 'warElephant' ? { uncontrolled: !!u.uncontrolled } : {}),
        ...(u.alesiaOrigin ? { alesiaOrigin: u.alesiaOrigin } : {}),
        ...(u.aboard ? { aboard: [u.c, u.r], hp: Number(fmt(u.hp)), ammo: u.ammo } : {}) }) };
}
export function importMap(data) {
  if (!['hex_wargame.ancient.v1', 'hex_wargame.ancient.v2'].includes(data?.format)) throw new Error('不是古代战役剧本地图文件');
  const m = newMap(data.cols, data.rows);
  if(data.fortificationSites!==undefined)m.fortificationSites=structuredClone(data.fortificationSites);
  m.scenarioId = typeof data.scenarioId === 'string' ? data.scenarioId.slice(0, 40) : null;
  const legacyTroy = m.scenarioId === 'troy' && data.victory?.horseTurn !== undefined &&
    data.victory?.horseUnlockTurn === undefined;
  m.name = String(data.name || m.name).slice(0, 80);
  m.factions = { egypt: String(data.factions?.egypt || '埃及').slice(0, 32), coalition: String(data.factions?.coalition || '对手').slice(0, 32) };
  m.unitNames = data.unitNames && typeof data.unitNames === 'object' ? Object.fromEntries(Object.entries(data.unitNames)
    .filter(([kind, name]) => STATS[kind.split(':').at(-1)] && typeof name === 'string').map(([kind, name]) => [kind, name.slice(0, 32)])) : null;
  if (data.unitStats !== undefined && (!data.unitStats || typeof data.unitStats !== 'object' || Array.isArray(data.unitStats)))
    throw new Error('兵种数值无效');
  for (const [kind, values] of Object.entries(data.unitStats || {})) {
    // Retire Yique's bundled unlimited-arrow override without rewriting its map file.
    const current = m.scenarioId === 'china_yique' && kind === 'chinaHeavyChariot' && values?.ammo === 999 ?
      { ...values, ammo: STATS.chinaHeavyChariot.ammo } : values;
    setUnitStats(m, kind, current);
  }
  m.intro = String(data.intro || m.intro).slice(0, 200);
  if (legacyTroy || m.scenarioId === 'troy' && data.victory?.horseUnlockTurn === 41)
    m.intro = '特洛伊城墙为 2 级；赫克托第 21 回合出城，阿喀琉斯第 25 回合参战。第 61 回合起可花 600 金购买一次木马；不再有第 40 回合自动胜利。';
  m.landmarks = Array.isArray(data.landmarks) ? data.landmarks.filter(x => inBounds(m, x.c, x.r) && typeof x.label === 'string').map(x => ({ c: x.c, r: x.r, label: x.label.slice(0, 40) })) : [];
  m.garden = data.garden && inBounds(m, data.garden.cMin, data.garden.rMin) &&
    inBounds(m, data.garden.cMax, data.garden.rMax) ? { cMin: data.garden.cMin, rMin: data.garden.rMin,
      cMax: data.garden.cMax, rMax: data.garden.rMax } : null;
  m.deployment = data.deployment || null;
  m.reinforcements = Array.isArray(data.reinforcements) ? data.reinforcements.map(e => ({ turn: e.turn, team: e.team,
    ...(e.repeatEvery === undefined ? {} : { repeatEvery: e.repeatEvery }),
    label: String(e.label || '援军抵达').slice(0, 80), units: Array.isArray(e.units) ? e.units.map(u =>
      ({ kind: u.kind, c: u.c, r: u.r, ...(u.cargo ? { cargo: [...u.cargo] } : {}),
        ...(u.alesiaOrigin ? { alesiaOrigin: u.alesiaOrigin } : {}) })) : null })) : [];
  m.recruitment = data.recruitment ? structuredClone(data.recruitment) : null;
  m.logistics = data.logistics ? structuredClone(data.logistics) : null;
  applyCampaignFinances(m);
  if (m.scenarioId === 'troy' && m.recruitment) {
    m.recruitment.costs.trojanHorse = TROY_COSTS.trojanHorse;
    m.recruitment.muster.egypt.land ??= { c: 18, r: 20 };
  }
  m.hectorSortieTurn = data.hectorSortieTurn ?? (m.scenarioId === 'troy' ? 21 : null);
  m.heroRelease = legacyTroy ? { team: 'egypt', turn: 25 } :
    data.heroRelease ? { team: data.heroRelease.team, turn: data.heroRelease.turn } : null;
  m.weather = data.weather ? structuredClone(data.weather) : null;
  if (data.victory?.mode === 'china') m.victory = { mode: 'china', attacker: data.victory.attacker,
    objective: { ...data.victory.objective }, objectiveName: data.victory.objectiveName,
    losses: { ...data.victory.losses }, turnLimit: data.victory.turnLimit, breach: data.victory.breach };
  else if (data.victory?.mode === 'classical') m.victory = importClassical(data.victory);
  else if (data.victory?.mode === 'peloponnesian') m.victory = { mode: 'peloponnesian',
    variant: data.victory.variant, losses: { ...data.victory.losses },
    turnLimit: data.victory.turnLimit,
    ...(data.victory.escape ? { escape: { ...data.victory.escape }, escapeShips: data.victory.escapeShips } : {}) };
  else if (data.victory?.mode === 'babylon') m.victory = { mode: 'babylon', rescue: { ...data.victory.rescue },
    outer: { ...data.victory.outer } };
  else if (data.victory?.mode === 'salamis') m.victory = { mode: 'salamis',
    bay: { ...data.victory.bay }, greekLosses: data.victory.greekLosses,
    persianLosses: data.victory.persianLosses, bayShips: data.victory.bayShips };
  else if (data.victory?.mode === 'actium') m.victory = { mode: 'actium',
    escape: { ...data.victory.escape }, escortShips: data.victory.escortShips,
    octavianLosses: data.victory.octavianLosses, antonyLosses: data.victory.antonyLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'teutoburg') m.victory = { mode: 'teutoburg',
    escape: { ...data.victory.escape }, escapeUnits: data.victory.escapeUnits,
    romanLosses: data.victory.romanLosses, germanLosses: data.victory.germanLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'carrhae') m.victory = { mode: 'carrhae',
    escape: { ...data.victory.escape }, escapeUnits: data.victory.escapeUnits,
    romanLosses: data.victory.romanLosses, parthianLosses: data.victory.parthianLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'jerusalem') m.victory = { mode: 'jerusalem',
    stages: data.victory.stages.map(stage => ({ name: stage.name, c: stage.c, r: stage.r,
      walls: [...stage.walls] })), romanLosses: data.victory.romanLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'syracuse') m.victory = { mode: 'syracuse',
    capture: { ...data.victory.capture }, walls: [...data.victory.walls],
    romanLosses: data.victory.romanLosses, turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'pydna') m.victory = { mode: 'pydna',
    romanLosses: data.victory.romanLosses, macedonianLosses: data.victory.macedonianLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'cannae') m.victory = { mode: 'cannae',
    romanLosses: data.victory.romanLosses, punicLosses: data.victory.punicLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'zama') m.victory = { mode: 'zama',
    romanLosses: data.victory.romanLosses, punicLosses: data.victory.punicLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'pharsalus') m.victory = { mode: 'pharsalus',
    caesarLosses: data.victory.caesarLosses, pompeyLosses: data.victory.pompeyLosses,
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'carthage') m.victory = { mode: 'carthage',
    harbor: { ...data.victory.harbor }, byrsa: { ...data.victory.byrsa },
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'alesia') m.victory = { mode: 'alesia',
    center: { ...data.victory.center }, turnLimit: data.victory.turnLimit,
    inner: data.victory.inner?.map(cell => [...cell]),
    outer: data.victory.outer?.map(cell => [...cell]) };
  else if (['gaugamela', 'issus'].includes(data.victory?.mode)) m.victory = { mode: data.victory.mode,
    phalanxLosses: data.victory.phalanxLosses };
  else if (data.victory?.mode === 'tyre') m.victory = { mode: 'tyre', capture: { ...data.victory.capture },
    ...(Array.isArray(data.victory.moles) ? { moles: data.victory.moles.map(lane =>
      Array.isArray(lane) ? lane.map(cell => Array.isArray(cell) ? [...cell] : cell) : lane) } :
      { mole: data.victory.mole?.map(cell => Array.isArray(cell) ? [...cell] : cell) }),
    turnLimit: data.victory.turnLimit };
  else if (data.victory?.mode === 'qarqar') m.victory = { mode: 'qarqar', objective: { ...data.victory.objective },
    turnLimit: data.victory.turnLimit, holdTurns: data.victory.holdTurns };
  else if (data.victory?.mode === 'troy') m.victory = { mode: 'troy', capture: { ...data.victory.capture },
    horseUnlockTurn: TROY_HORSE_UNLOCK_TURN };
  else if (data.victory?.mode === 'leader_duel') m.victory = { mode: 'leader_duel', leaders: { ...data.victory.leaders } };
  else if (data.victory) m.victory = { leaderKind: data.victory.leaderKind, leaderSide: data.victory.leaderSide,
    leaderDeathWinner: data.victory.leaderDeathWinner, annihilateSide: data.victory.annihilateSide,
    annihilationWinner: data.victory.annihilationWinner };
  for (const [c, r, t] of data.terrain || []) if (!setTerrain(m, c, r, t)) throw new Error('地形数据无效');
  if (data.bridges !== undefined && !Array.isArray(data.bridges)) throw new Error('桥梁数据无效');
  for (const entry of data.bridges || []) {
    if (!Array.isArray(entry) || entry.length !== 2 || bridgeAt(m, entry[0], entry[1]) ||
        !setBridge(m, entry[0], entry[1])) throw new Error('桥梁数据无效');
  }
  if (data.houses !== undefined && !Array.isArray(data.houses)) throw new Error('房屋数据无效');
  for (const [c, r] of data.houses || []) if (!setHouse(m, c, r)) throw new Error('房屋数据无效');
  const forts = data.format.endsWith('v1') ? (data.forts || []).map(([c, r, level, hp]) => ({ kind: 'fort', team: 'coalition', c, r, level, hp })) : (data.units || []).filter(u => u.kind === 'fort');
  for (const f of forts) {
    const level = legacyTroy && f.level === 3 ? 2 : f.level;
    const hp = legacyTroy && f.level === 3 ? Math.round(f.hp * 4) / 10 : f.hp;
    if (!setFort(m, f.c, f.r, level, f.team, f.cityId || null)) throw new Error('堡垒棋子数据无效');
    const unit = fortAt(m, f.c, f.r);
    if (!Number.isFinite(hp) || Math.abs(hp * 10 - Math.round(hp * 10)) > 1e-8 || hp < 0 || hp > FORT_HP[level] / 10) throw new Error('堡垒耐久须为一位小数');
    unit.hp = Math.round(hp * 10);
  }
  for (const u of data.units || []) if (u.kind !== 'fort' && !u.aboard) {
    if (mobileAt(m, u.c, u.r) || !addUnit(m, u.kind, u.team, u.c, u.r)) throw new Error('棋子数据无效');
    if (u.scout) mobileAt(m, u.c, u.r).scout = true;
    if (u.customName !== undefined) {
      if (typeof u.customName !== 'string' || !u.customName.trim() || u.customName.length > 32) throw new Error('部队名称无效');
      mobileAt(m, u.c, u.r).customName = u.customName.trim();
    }
    if (typeof u.formation === 'string') mobileAt(m, u.c, u.r).formation = u.formation.slice(0, 40);
    if (u.deepRaider === true) mobileAt(m, u.c, u.r).deepRaider = true;
    if (u.pursuer) mobileAt(m, u.c, u.r).pursuer = true;
    if (u.alesiaOrigin === 'inner' || u.alesiaOrigin === 'outer') mobileAt(m, u.c, u.r).alesiaOrigin = u.alesiaOrigin;
    if (u.morale !== undefined) mobileAt(m, u.c, u.r).morale = u.morale;
    if (isTrireme(u) && validFacing(u.facing)) mobileAt(m, u.c, u.r).facing = u.facing;
    if (isPhalangite(u)) {
      const phalanx = mobileAt(m, u.c, u.r);
      if (validFacing(u.facing)) phalanx.facing = u.facing;
      if (typeof u.formed === 'boolean') phalanx.formed = u.formed;
    }
    if (isRomanLine(u)) {
      const roman = mobileAt(m, u.c, u.r);
      if (validFacing(u.facing)) roman.facing = u.facing;
      if (typeof u.formed === 'boolean') roman.formed = u.formed;
    }
    if (u.kind === 'warElephant' && u.uncontrolled === true) mobileAt(m, u.c, u.r).uncontrolled = true;
    if (isTrireme(u) && typeof u.commander === 'string') mobileAt(m, u.c, u.r).commander = u.commander;
    if (u.wagonCaptureLoss !== undefined) {
      if (u.kind !== 'supplyWagon' || !Number.isInteger(u.wagonCaptureLoss) || u.wagonCaptureLoss < 0 ||
          u.wagonCaptureLoss > unitStats(m, u).hp) throw new Error('粮车争夺损耗无效');
      const wagon = mobileAt(m, u.c, u.r);
      wagon.wagonCaptureLoss = u.wagonCaptureLoss; wagon.hp = unitMaxHp(m, wagon);
    }
  }
  for (const u of data.units || []) if (u.aboard) {
    const ship = mobileAt(m, u.aboard[0], u.aboard[1]);
    if (!addEmbarkedUnit(m, u.kind, u.team, ship)) throw new Error('登船棋子数据无效');
    const passenger = m.units.at(-1);
    if (Number.isFinite(u.hp) && u.hp > 0 && u.hp <= unitMaxHp(m, u) / 10) passenger.hp = Math.round(u.hp * 10);
    if (Number.isInteger(u.ammo) && u.ammo >= 0 && u.ammo <= unitStats(m, u).ammo) passenger.ammo = u.ammo;
    if (u.morale !== undefined) passenger.morale = u.morale;
    if (u.customName !== undefined) {
      if (typeof u.customName !== 'string' || !u.customName.trim() || u.customName.length > 32) throw new Error('部队名称无效');
      passenger.customName = u.customName.trim();
    }
  }
  if (data.supplyPoints !== undefined) {
    if (!Array.isArray(data.supplyPoints)) throw new Error('堡垒补给点数据无效');
    for (const p of data.supplyPoints) {
      if (!setSupplyPoint(m, p.c, p.r, p.team, p.cityId ?? null)) throw new Error('堡垒补给点数据无效');
    }
    if (m.supplyPoints.length !== data.supplyPoints.length) throw new Error('堡垒补给点重复');
  }
  if (data.autoElevation !== undefined) m.autoElevation = structuredClone(data.autoElevation);
  if (data.elevations !== undefined) { m.elevations = structuredClone(data.elevations); validateElevations(m); }
  validateAutoElevation(m);
  validateMap(m); return m;
}
export function startGame(map, options = {}) {
  const rulesVersion = options.rulesVersion ?? RULES_VERSION;
  if (![10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, RULES_VERSION].includes(rulesVersion)) throw Error("不支持的战斗规则版本");
  validateMap(map);
  if(rulesVersion<19&&map.units.some(u=>u.facing!==undefined&&!Number.isInteger(u.facing)))throw Error('旧规则不支持30度朝向');
  const battleMap = importMap(exportMap(map));
  ensureMoraleGuards(battleMap);
  const scoutDeployment=options.addScouts?seedScouts(battleMap,{isShip,distance,tile,TERRAIN,fortAt,mobileAt,inDeployment,addUnit}):null;
  for(const u of battleMap.units)u.heading12=u.facing!==undefined?((3-2*u.facing+12)%12):u.team==='egypt'?3:9;
  if (rulesVersion >= 13) ensureAutoElevation(battleMap);
  else if (rulesVersion >= 11) materializeElevations(battleMap);
  const s = { reserveResponses:options.reserveResponses===true, scoutDetectionRadius:3, scoutDeployment, rulesVersion, elevationRules: ruleConfig(options.elevationRules), map: battleMap, turn: 1, side: 'egypt', deploying: !!map.deployment,
    qarqarHold: 0, babylonAlarm: false, salamisBayThreat: false, carthageHarborTaken: false,
    jerusalemStage: 0, aiDifficulty: 'normal',
    weather: map.weather ? structuredClone(map.weather) : null,
    arrivedReinforcements: [],
    pendingSupply: { egypt: [], coalition: [] },
    money: battleMap.recruitment ? { ...battleMap.recruitment.startingMoney } :
      battleMap.logistics ? { ...battleMap.logistics.startingMoney } : null,
    trojanHorsePurchased: false,
    over: false, winner: null, fog: { egypt: { visible: new Set(), explored: new Set() }, coalition: { visible: new Set(), explored: new Set() } },
    log: [map.intro || '固定兵力战斗开始。'] };
  if(usesChargeRules(s)){s.chargeRules=chargeConfig(options.chargeRules);s.chargeRuns={};}
  if(rulesVersion>=20){s.ramRules=ramConfig(options.ramRules);s.ramRuns={};}
  if(rulesVersion>=17)s.chargeCriticalRules=chargeCriticalConfig(options.chargeCriticalRules);
  for (const u of s.map.units) if (isFormableInfantry(u)) { u.formed = false; u.formationSteps = 0; }
  if (s.map.logistics) for (const u of s.map.units) {
    if (u.kind === 'supplyWagon') { u.supplyStock = SUPPLY_WAGON_CAPACITY; u.supplyTravel = 0; }
    else if (!['fort','scout'].includes(u.kind)) { u.hunger = 0; u.hungerClock = 0; u.fedTurns = carriedRationCapacity(u); u.maxHungerTurns = 0; }
  }
  for (const u of s.map.units) if (heroWaiting(s, u) || hectorWaiting(s, u)) u.actionsLeft = 0;
  recomputeFog(s);
  if(rulesVersion>=14||options.fogPolicy)initializeKnowledge(s,options.fogPolicy);
  if (!s.deploying) resolveRouts(s);
  initializeCapture(s);
  return s;
}
export function startTroyTurn65(map = troyMap()) {
  if (map.scenarioId !== 'troy') throw new Error('第 65 回合体验仅适用于特洛伊之战');
  const s = startGame(map);
  s.turn = 65;
  s.money.egypt = 1000;
  for (const hero of s.map.units.filter(u => u.kind === 'hero' && u.hp > 0)) hero.actionsLeft = 2;
  const hector = s.map.units.find(u => u.kind === 'hero' && u.team === 'coalition');
  if (hector && !mobileAt(s.map, 30, 20) && !fortAt(s.map, 30, 20)) {
    hector.c = 30; hector.r = 20;
  }
  recomputeFog(s);
  s.log.push('临时体验：直接进入第 65 回合，阿开亚军费 1000 金；此前 64 回合的战斗未逐回合模拟。');
  return s;
}
function heroWaiting(s, u) {
  const release = s.map.heroRelease;
  return !!release && u.kind === 'hero' && u.team === release.team && s.turn < release.turn;
}
function hectorWaiting(s, u) {
  return s.map.scenarioId === 'troy' && u.kind === 'hero' && u.team === 'coalition' &&
    s.turn < s.map.hectorSortieTurn;
}
export const EQUIPMENT_RECRUIT_INTERVAL = 3;
const recruitmentClass = kind => ['chariot', 'hittiteChariot', 'chinaHeavyChariot', 'scythedChariot'].includes(kind) ?
  'chariot' : kind === 'siegeRam' ? 'siegeRam' : null;
// Fixed equipment prices also apply to older maps and battle saves.
export const recruitmentCost = (s, kind) => recruitmentClass(kind) === 'chariot' ? 150 :
  kind === 'siegeRam' ? 120 : s.map.logistics ? LOGISTICS_COSTS[kind] : s.map.recruitment?.costs[kind];
export const recruitmentWait = (s, kind, team = s.side) => {
  const group = recruitmentClass(kind);
  return group ? Math.max(0, (s.recruitmentReadyTurn?.[team]?.[group] ?? 0) - s.turn) : 0;
};
function recordRecruitment(s, kind, team) {
  const group = recruitmentClass(kind);
  if (!group) return;
  s.recruitmentReadyTurn ??= {};
  s.recruitmentReadyTurn[team] ??= {};
  s.recruitmentReadyTurn[team][group] = s.turn + EQUIPMENT_RECRUIT_INTERVAL;
}
// Recruitment never extends credit, including when a malformed runtime balance is present.
export const canAffordRecruitment = (s, team, cost) => validTeam(team) &&
  Number.isSafeInteger(cost) && cost > 0 && Number.isSafeInteger(s.money?.[team]) &&
  s.money[team] >= cost;
export function recruit(s, kind) {
  s=authoritativeState(s);
  const r = s.map.recruitment, team = s.side;
  if (!r || s.over || s.deploying) return { ok: false, reason: '当前剧本不能召集兵源' };
  const cost = recruitmentCost(s, kind);
  if (!Object.hasOwn(r.costs, kind) || !Number.isSafeInteger(cost) || cost <= 0 || !canPlaceKind(kind, team)) return { ok: false, reason: '此阵营不能召集该棋子' };
  if (recruitmentWait(s, kind, team)) return { ok: false, reason: `该类装备还需 ${recruitmentWait(s, kind, team)} 回合才能再次召集` };
  if (kind === 'trojanHorse') {
    if (s.map.scenarioId !== 'troy' || s.turn < s.map.victory.horseUnlockTurn)
      return { ok: false, reason: `第 ${s.map.victory.horseUnlockTurn} 回合起才能购买特洛伊木马` };
    if (s.trojanHorsePurchased) return { ok: false, reason: '特洛伊木马每局只能购买一次' };
  }
  if (!canAffordRecruitment(s, team, cost)) return { ok: false, reason: `军费不足，需要 ${cost} 金` };
  let unit;
  if (kind === 'trojanHorse') {
    const muster = r.muster.egypt.land;
    const cells = [];
    for (let row = Math.max(0, muster.r - 2); row <= Math.min(s.map.rows - 1, muster.r + 2); row++)
      for (let col = Math.max(0, muster.c - 2); col <= Math.min(s.map.cols - 1, muster.c + 2); col++)
        if (distance({ c: col, r: row }, muster) <= 2) cells.push({ c: col, r: row });
    cells.sort((a, b) => distance(a, muster) - distance(b, muster));
    const at = cells.find(p => !mobileAt(s.map, p.c, p.r) && addUnit(s.map, kind, team, p.c, p.r));
    if (!at) return { ok: false, reason: '海边木马工坊附近没有可放置的空地' };
    unit = mobileAt(s.map, at.c, at.r);
  } else if (isShip({ kind })) {
    const at = r.muster[team].sea;
    if (mobileAt(s.map, at.c, at.r)) return { ok: false, reason: '海上召集点已有船只，需先驶离' };
    if (!addUnit(s.map, kind, team, at.c, at.r)) return { ok: false, reason: '海上召集点无法放置船只' };
    unit = mobileAt(s.map, at.c, at.r);
  } else if (team === 'egypt') {
    const at = r.muster.egypt.sea, ship = mobileAt(s.map, at.c, at.r);
    if (ship?.kind !== 'transport' || ship.team !== team)
      return { ok: false, reason: '阿开亚海上召集点须停靠己方运兵船' };
    if (cargoLoad(s.map, ship) + cargoSlots({ kind }) > 2)
      return { ok: false, reason: '运兵船已满；战车独占一艘船' };
    if (!addEmbarkedUnit(s.map, kind, team, ship)) return { ok: false, reason: '无法登上召集点运兵船' };
    unit = s.map.units.at(-1);
  } else {
    const at = r.muster.coalition.land;
    if (mobileAt(s.map, at.c, at.r)) return { ok: false, reason: '特洛伊城内召集点已有士兵，需先移开' };
    if (!addUnit(s.map, kind, team, at.c, at.r)) return { ok: false, reason: '城内召集点无法放置该士兵' };
    unit = mobileAt(s.map, at.c, at.r);
  }
  interruptCharge(s,null);
  recordBattleEvent(s,'expense',{team},null,cost);
  s.money[team] -= cost;
  recordRecruitment(s, kind, team);
  if (kind === 'trojanHorse') s.trojanHorsePurchased = true;
  unit.actionsLeft = 0;
  s.log.push(`${s.map.factions[team]}花费 ${cost} 金召集${unitName(s.map, unit)}${unit.aboard ? '，已登上运兵船' : ''}`);
  recomputeFog(s);
  return { ok: true, unit, cost };
}
export const LOGISTICS_COSTS = Object.freeze({ light: 12, heavy: 18, archer: 16,
  chinaCrossbow: 20, cavalry: 25, guard: 30, supplyWagon: 32, moraleGuard: 40, chinaHeavyChariot: 150, siegeRam: 120 });
export const SUPPLY_WAGON_CAPACITY = 24;
// HP is stored in tenths: each successful wagon takeover costs 4.0 durability.
export const SUPPLY_WAGON_CAPTURE_DAMAGE = 40;
export const SATIETY_PER_SUPPLY = 5;
const wagonFood = u => Math.max(0, u.supplyStock || 0) * SATIETY_PER_SUPPLY + Math.max(0, u.supplyCredit || 0);
const setWagonFood = (u, food) => {
  u.supplyStock = Math.floor(food / SATIETY_PER_SUPPLY);
  u.supplyCredit = food % SATIETY_PER_SUPPLY;
};
const takeWagonFood = (u, requested) => {
  const taken = Math.min(wagonFood(u), requested);
  setWagonFood(u, wagonFood(u) - taken);
  return taken;
};
export const CARRIED_RATION_CAPACITY = 3;
export const DEEP_RAID_RATION_CAPACITY = 10;
export const carriedRationCapacity = u => u.deepRaider === true ?
  DEEP_RAID_RATION_CAPACITY : CARRIED_RATION_CAPACITY;
export const logisticsRouteCut = (s, team) => !!s.map.logistics?.routes?.[team]?.some(p =>
  s.map.units.some(u => u.team !== team && u.hp > 0 && !u.aboard && !isRouted(u) &&
    !['fort', 'supplyWagon'].includes(u.kind) && distance(u, p) <= 2));
export function recruitLogistics(s, kind, team = s.side) {
  const l = s.map.logistics, cost = recruitmentCost(s, kind);
  if (!l || s.over || s.deploying || team !== s.side || !Object.hasOwn(LOGISTICS_COSTS, kind) ||
      !canPlaceKind(kind, team, s.map.scenarioId)) return { ok: false, reason: '当前不能在此召集' };
  if (recruitmentWait(s, kind, team)) return { ok: false, reason: `该类装备还需 ${recruitmentWait(s, kind, team)} 回合才能再次召集` };
  if (logisticsRouteCut(s, team)) return { ok: false, reason: '补给线被切断，暂时不能召集' };
  if (!canAffordRecruitment(s, team, cost)) return { ok: false, reason: `财政不足，需要 ${cost} 金` };
  for (const muster of l.musters[team]) {
    const cells = [muster, ...neighbors(muster.c, muster.r)].filter(p =>
      inBounds(s.map, p.c, p.r) && !mobileAt(s.map, p.c, p.r));
    for (const p of cells) if (addUnit(s.map, kind, team, p.c, p.r)) {
      const unit = s.map.units.at(-1); unit.actionsLeft = 0;
      if (kind === 'supplyWagon') { unit.supplyStock = SUPPLY_WAGON_CAPACITY; unit.supplyTravel = 0; }
      else if(unit.kind!=='scout') { unit.hunger = 0; unit.hungerClock = 0; unit.fedTurns = carriedRationCapacity(unit); unit.maxHungerTurns = 0; }
      interruptCharge(s,null);
      recordBattleEvent(s,'expense',{team},null,cost);
  s.money[team] -= cost;
      recordRecruitment(s, kind, team);
      s.log.push(`${s.map.factions[team]}在召集点花费 ${cost} 金，召集${unitName(s.map, unit)}`);
      recomputeFog(s); return { ok: true, unit, cost };
    }
  }
  return { ok: false, reason: '召集点及附近无空位' };
}
export function replenishConvoy(s, id) {
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0), l = s.map.logistics;
  if (!l || !u || u.kind !== 'supplyWagon' || u.team !== s.side || s.over ||
      !l.depots[u.team].some(p => distance(p, u) <= 1))
    return { ok: false, reason: '运输队须返回己方后方补给点' };
  if (logisticsRouteCut(s, u.team)) return { ok: false, reason: '补给线被切断' };
  const amount = Math.min(Math.ceil((SUPPLY_WAGON_CAPACITY * SATIETY_PER_SUPPLY - wagonFood(u)) / SATIETY_PER_SUPPLY),
    Math.floor(Math.max(0, s.money[u.team]) / 2));
  if (amount <= 0) return { ok: false, reason: '补给已满或财政不足' };
  setWagonFood(u, Math.min(SUPPLY_WAGON_CAPACITY * SATIETY_PER_SUPPLY,
    wagonFood(u) + amount * SATIETY_PER_SUPPLY));
  interruptCharge(s,u.id);
  recordBattleEvent(s,'expense',u,null,amount*2);
  s.money[u.team] -= amount * 2;
  s.log.push(`${s.map.factions[u.team]}运输队花费 ${amount * 2} 金，补充 ${amount} 点粮秣`);
  return { ok: true, amount, cost: amount * 2 };
}
const logisticsSoldier = u => u.hp > 0 && !u.aboard && !isShip(u) &&
  !['fort', 'defenseTower', 'captive', 'supplyWagon', 'siegeRam', 'siegeTower', 'romanOnager',
    'engineer', 'arrowCamel', 'trojanHorse','scout'].includes(u.kind);
// Place support carts near the starting formations. Soldiers can relay food
// beyond these initial positions once the battle begins.
export function expandLogisticsConvoys(m) {
  if (!m.logistics) return 0;
  let added = 0;
  for (const team of ['egypt', 'coalition']) {
    const soldiers = m.units.filter(u => u.team === team && logisticsSoldier(u) && !isRouted(u));
    const wagons = m.units.filter(u => u.team === team && u.kind === 'supplyWagon' && u.hp > 0);
    const covered = u => wagons.some(w => distance(w, u) <= 2);
    for (let count = 0; count < 24; count++) {
      const uncovered = soldiers.filter(u => !covered(u));
      if (!uncovered.length) break;
      const candidates = new Map();
      for (const u of uncovered) for (let dc = -2; dc <= 2; dc++) for (let dr = -2; dr <= 2; dr++) {
        const p = { c: u.c + dc, r: u.r + dr };
        if (!inBounds(m, p.c, p.r) || distance(p, u) > 2 || mobileAt(m, p.c, p.r)) continue;
        const key = `${p.c},${p.r}`;
        if (!candidates.has(key)) candidates.set(key, p);
      }
      const ranked = [...candidates.values()].sort((a, b) =>
        uncovered.filter(u => distance(b, u) <= 2).length -
        uncovered.filter(u => distance(a, u) <= 2).length);
      let placed = false;
      for (const p of ranked) if (addUnit(m, 'supplyWagon', team, p.c, p.r)) {
        const wagon = m.units.at(-1);
        wagon.supplyStock = SUPPLY_WAGON_CAPACITY; wagon.supplyTravel = 0;
        wagons.push(wagon); added++; placed = true; break;
      }
      if (!placed) break;
    }
  }
  return added;
}
function advanceLogistics(s, team) {
  const l = s.map.logistics;
  if (!l) return;
  for(const u of s.map.units)if(u.kind==='scout')for(const k of ['hunger','hungerClock','fedTurns','maxHungerTurns'])delete u[k];
  const living = s.map.units.filter(u => u.team === team && logisticsSoldier(u));
  const upkeep = [...living,...s.map.units.filter(u=>u.team===team&&u.kind==='scout'&&u.hp>0&&!u.aboard)].filter(u => !isRouted(u)).reduce((sum, u) => sum +
    (['cavalry', 'chinaHeavyChariot', 'guard', 'chinaGeneral', 'moraleGuard'].includes(u.kind) ? 3 :
      ['heavy', 'chinaCrossbow'].includes(u.kind) ? 2 : 1), 0);
  recordBattleEvent(s,'income',{team},null,l.income[team]);recordBattleEvent(s,'expense',{team},null,upkeep);
  s.money[team] += l.income[team] - upkeep;
  s.log.push(`${s.map.factions[team]}财政 +${l.income[team]}、军费 −${upkeep}，结余 ${s.money[team]} 金${logisticsRouteCut(s, team) ? '；补给线被切断' : ''}`);
  const wagons = s.map.units.filter(u => u.team === team && u.kind === 'supplyWagon' && u.hp > 0);
  const active = living.filter(u => !isRouted(u));
  const at = new Map();
  for (const u of active) {
    const cell = key(u.c, u.r), group = at.get(cell) || [];
    group.push(u); at.set(cell, group);
  }
  const supplied = new Set();
  // Each cart starts a breadth-first relay. A soldier may pass food onward
  // only after this cart feeds them, or while their previous ration is active.
  for (const wagon of wagons) {
    if (wagonFood(wagon) <= 0) continue;
    const queue = active.filter(u => distance(u, wagon) <= 2);
    const visited = new Set();
    for (let head = 0; head < queue.length; head++) {
      const u = queue[head];
      if (visited.has(u.id)) continue;
      visited.add(u.id);
      if (u.fedTurns <= 0 || (supplied.has(u.id) &&
          (u.hunger > 0 || u.fedTurns < carriedRationCapacity(u)))) {
        const food = takeWagonFood(wagon,
          (u.hunger || 0) + carriedRationCapacity(u) - Math.max(0, u.fedTurns || 0));
        if (food > 0) {
          const hungerRemoved = Math.min(u.hunger || 0, food);
          u.hunger -= hungerRemoved;
          u.fedTurns = Math.min(carriedRationCapacity(u), (u.fedTurns || 0) + food - hungerRemoved);
          if (u.hunger === 0) { u.hungerClock = 0; u.maxHungerTurns = 0; }
          supplied.add(u.id);
        }
      }
      if (u.hunger > 0 || u.fedTurns <= 0) continue;
      for (const p of neighbors(u.c, u.r))
        for (const next of at.get(key(p.c, p.r)) || [])
          if (!visited.has(next.id)) queue.push(next);
    }
  }
  const starve = u => {
    u.hungerClock = (u.hungerClock || 0) + 1;
    if (u.hungerClock >= 2) {
      u.hunger = Math.min(5, (u.hunger || 0) + 1);
      u.hungerClock = 0;
    }
    u.maxHungerTurns = u.hunger === 5 ? (u.maxHungerTurns || 0) + 1 : 0;
    if (u.hunger >= 3) {
      u.hp = Math.max(0, u.hp - (u.hunger === 5 ? 10 : 5));
      changeMorale(s, u, u.hunger === 5 ? -0.08 : -0.04, '饥饿');
    }
    if (u.maxHungerTurns >= 5) { u.starvedRouted = true; s.log.push(`${unitName(s.map, u)}长期断粮，部队溃逃`); markRouted(s, u); }
  };
  for (const u of living) {
    if (isRouted(u)) continue;
    if (supplied.has(u.id)) continue;
    if (u.fedTurns > 0) { u.fedTurns--; u.hunger = 0; u.hungerClock = 0; u.maxHungerTurns = 0; continue; }
    starve(u);
  }
  checkVictory(s);
}
export const unitAt = (s, c, r) => mobileAt(s.map, c, r) || fortAt(s.map, c, r);
export const knownTo = (s, team, u) => !!u && (s.fogPolicy ? unitKnown(s,team,u) : (u.kind === 'fort' || u.team === team ||
  (!u.aboard && visibleTo(s, team, u.c, u.r))));
export const knownUnitAt = (s, team, c, r) => {
  const soldier = mobileAt(s.map, c, r);
  if (knownTo(s, team, soldier)) return soldier;
  const fort = fortAt(s.map, c, r);
  return knownTo(s, team, fort) ? fort : null;
};
export function inDeployment(m, c, r) {
  const d = m.deployment;
  return !!d && c >= d.cMin && c <= d.cMax && r >= d.rMin && r <= d.rMax;
}
export function deployUnit(s, id, c, r) {
  const u = s.map.units.find(x => x.id === id);
  if (!s.deploying || !u || u.team !== s.map.deployment?.team || u.kind === 'fort' ||
      !inDeployment(s.map, c, r) || mobileAt(s.map, c, r) || fortAt(s.map, c, r)) return false;
  const t = tile(s.map, c, r)?.terrain;
  if (t === undefined || ((t & TERRAIN.RIVER) && !(t & TERRAIN.ROAD)) ||
      chinaChariotBlocked(u.kind, t, !usesMountainMarchRules(s)) ||
      (isChariot(u) && (t & TERRAIN.MOUNTAIN) && !(t & TERRAIN.ROAD))) return false;
  interruptCharge(s,u.id);
  u.c = c; u.r = r; u.actionsLeft = initialActions(u.kind, t, bridgeAt(s.map, c, r)); recomputeFog(s); return true;
}
export function beginBattle(s) { if (!s.deploying) return false; s.deploying = false; s.log.push('部署完成，埃及军开始穿越阿鲁纳山口。'); return true; }
export const cloudAt = (s, c, r) => !!s.weather?.clouds.some(p => distance(p, { c, r }) <= p.radius);
export function advanceWeather(s, rng = Math.random) {
  if (!s.weather) return null;
  s.weather.windDir = Math.min(5, Math.max(0, Math.floor(rng() * 6)));
  s.weather.clouds = s.weather.clouds.map(p => {
    const next = neighbors(p.c, p.r)[s.weather.windDir];
    return inBounds(s.map, next.c, next.r) ? { ...p, c: next.c, r: next.r } : p;
  });
  recomputeFog(s);
  s.log.push(`风向转为${WIND_NAMES[s.weather.windDir]}，云团随风移动。`);
  return s.weather;
}
export function fallKunyangMeteors(s, rng = Math.random) {
  if (s.map.scenarioId !== 'china_kunyang' || s.over || s.deploying ||
      s.side !== 'egypt' || s.turn % KUNYANG_METEORS.interval !== 0 ||
      s.lastMeteorTurn === s.turn) return null;
  const cells = [];
  for (let r = KUNYANG_METEORS.rMin; r <= KUNYANG_METEORS.rMax; r++)
    for (let c = KUNYANG_METEORS.cMin; c <= KUNYANG_METEORS.cMax; c++)
      if (inBounds(s.map, c, r) && tile(s.map, c, r).terrain !== TERRAIN.SEA)
        cells.push({ c, r });
  const strikes = [], damaged = new Map();
  for (let i = 0; i < Math.min(KUNYANG_METEORS.count, cells.length); i++) {
    const roll = rng(), sample = Number.isFinite(roll) ? roll : 0;
    const chosen = Math.min(cells.length - 1, Math.max(0, Math.floor(sample * cells.length)));
    const impact = cells.splice(chosen, 1)[0];
    strikes.push(impact);
    for (const p of [impact, ...neighbors(impact.c, impact.r)]) {
      if (!inBounds(s.map, p.c, p.r)) continue;
      const unit = mobileAt(s.map, p.c, p.r);
      const siegeWeapon = unit && ['siegeRam', 'siegeTower', 'romanOnager'].includes(unit.kind);
      if (!unit || unit.team !== 'coalition' || (!usesMorale(unit) && !siegeWeapon)) continue;
      const damage = Math.min(unit.hp, Math.round(KUNYANG_METEORS.damage *
        (siegeWeapon ? KUNYANG_METEORS.siegeMultiplier : 1)));
      unit.hp -= damage;
      const hit = damaged.get(unit.id) || { id: unit.id, damage: 0, destroyed: false };
      hit.damage += damage;
      hit.destroyed = unit.hp === 0;
      damaged.set(unit.id, hit);
    }
  }
  const hits = [...damaged.values()];
  s.lastMeteorTurn = s.turn;
  s.kunyangMeteor = { turn: s.turn, strikes, hits };
  s.log.push(`第 ${s.turn} 回合天降陨石：${strikes.length} 颗落入昆阳战场，击中 ${hits.length} 支新军部队或攻城器械，击毁 ${hits.filter(x => x.destroyed).length} 支。`);
  if (hits.length) { recomputeFog(s); checkVictory(s); }
  return s.kunyangMeteor;
}
export function recomputeFog(s) {
  if(usesChargeRules(s))for(const [id,run] of Object.entries(s.chargeRuns||{})){const u=s.map.units.find(u=>u.id===id);if(!u||!chargeClass(s.map,u,s.rulesVersion)||!runMatches(s,u,run))interruptCharge(s,id);}
  s=authoritativeState(s);
  for (const u of s.map.units) u.cloudCovered = !!s.weather && u.hp > 0 && cloudAt(s, u.c, u.r);
  for (const u of s.map.units) u.commandAura = isTrireme(u) && !u.commander &&
    s.map.units.some(v => v.team === u.team && v.commander && v.hp > 0 && distance(u, v) <= 2) ? 0.1 : 0;
  for (const team of ['egypt', 'coalition']) {
    const fog = s.fog[team]; fog.visible.clear(); fog.scoutVisible = new Set();
    for (const u of s.map.units) if (u.team === team && u.hp > 0 && !u.aboard) {
      const sight = Math.max(1, unitStats(s.map, u).vision + (u.scout ? 2 : 0) + (u.commander ? 1 : 0) - (u.cloudCovered ? 2 : 0));
      for (let r = Math.max(0, u.r - sight); r <= Math.min(s.map.rows - 1, u.r + sight); r++)
        for (let c = Math.max(0, u.c - sight); c <= Math.min(s.map.cols - 1, u.c + sight); c++) {
          const d = distance(u, { c, r });
          if (d <= sight && (!cloudAt(s, c, r) || d <= 1) &&
              (elevatedArcher(s.map, u) || !mountainBetween(s.map, u, { c, r }))) {fog.visible.add(key(c, r));if(d <= s.scoutDetectionRadius)fog.scoutVisible.add(key(c,r));}
        }
    }
    for (const k of fog.visible) fog.explored.add(k);
    if(s.rulesVersion>=13)captureRecon(s,team);
  }
  if(s.fogPolicy)updateKnowledge(s);
  revealCaptureTopology(s);
  observeCasualties(s);
}
export const visibleTo = (s, team, c, r) => s.fogPolicy?.unitFog===false || s.fog[team].visible.has(key(c, r));
const highFriendlyWall = (m, u, c, r) => {
  const wall = fortAt(m, c, r);
  return wall?.team === u.team && wall.level >= 2;
};
export function movementAllowance(s,u) {
  const startingTerrain = tile(s.map, u.c, u.r).terrain;
  const inRiver = u.kind === 'supplyWagon' ? isWagonWater(s.map, u, u.c, u.r) : isFord(s.map, u.c, u.r);
  if(u.kind==='scout'&&!inRiver)return {startingTerrain,inRiver:false,roadBonus:0,wallBonus:0,baseSteps:5,maxSteps:5,cloudyMaxSteps:4,perAction:20,budget:20};
  const roadBonus = u.kind !== 'trojanHorse' && !isShip(u) && !inRiver && (startingTerrain & TERRAIN.ROAD) &&
    (!usesMountainMarchRules(s) || !(startingTerrain & TERRAIN.MOUNTAIN)) ? 1 : 0;
  const wallBonus = !roadBonus && highFriendlyWall(s.map, u, u.c, u.r) ? 1 : 0;
  const baseSteps = isFormableInfantry(u) && u.formed ? Math.max(0, 1 - (u.formationSteps || 0)) :
    inRiver ? 1 : (u.alexander ? 3 : isRomanLine(u) ? STATS.light.move : STATS[u.kind].move) +
      (unitStats(s.map, u).move - STATS[u.kind].move) + roadBonus;
  const maxSteps = baseSteps + wallBonus;
  const cloudyMaxSteps = Math.max(1, maxSteps - 1);
  const perAction = Math.max(1, maxSteps);
  const budget = usesMountainMarchRules(s) ? Math.max(perAction,inRiver?2:1) : usesElevationRules(s) ? perAction * u.actionsLeft : Math.max(maxSteps, isChariot(u) ? 3 : 2);
  return {startingTerrain,inRiver,roadBonus,wallBonus,baseSteps,maxSteps,cloudyMaxSteps,perAction,budget};
}
export function moveCost(s,u,c,r){return moveCostActual(planningState(s,u?.team),u,c,r);}
function moveCostActual(s, u, c, r) {
  const t = tile(s.map, c, r); if (!t) return Infinity;
  if (chinaChariotBlocked(u.kind, t.terrain, !usesMountainMarchRules(s))) return Infinity;
  if (houseAt(s.map, c, r) && (isChariot(u) || u.kind === 'captive')) return Infinity;
  if (isShip(u)) return t.terrain === TERRAIN.SEA ? 1 : Infinity;
  if (t.terrain === TERRAIN.SEA) return u.kind === 'supplyWagon' ? 2 : Infinity;
  if (t.terrain & TERRAIN.RIVER) return t.terrain & TERRAIN.ROAD ? 1 :
    u.kind === 'supplyWagon' ? 2 : Infinity;
  if(u.kind==='scout')return t.terrain&TERRAIN.MOUNTAIN?(t.terrain&TERRAIN.ROAD?5:10):(t.terrain&TERRAIN.ROAD?4:5);
  if (usesMountainMarchRules(s)) {
    const rough = terrain => !!(terrain & TERRAIN.MOUNTAIN) && !(terrain & TERRAIN.ROAD);
    if (rough(t.terrain) && (isChariot(u) || (isFormableInfantry(u) && u.formed))) return Infinity;
    // A rough mountain step consumes one whole movement allowance, never two AP.
    if (rough(t.terrain) || rough(tile(s.map,u.c,u.r).terrain)) return movementAllowance(s,u).perAction;
    return 1;
  }
  if (t.terrain & TERRAIN.MOUNTAIN) return isChariot(u) && !(t.terrain & TERRAIN.ROAD) ? Infinity : (t.terrain & TERRAIN.ROAD && !isChariot(u) ? 1 : 2);
  return 1;
}
function surrounded(s, u) {
  const cells = neighbors(u.c, u.r);
  const adjacent = cells.map(p => mobileAt(s.map, p.c, p.r)).filter(Boolean);
  // Fleeing soldiers occupy cells, but cannot exert the pressure of a fighting unit.
  const attackers = adjacent.filter(v => v.team !== u.team && !isRouted(v));
  if (s.map.scenarioId === 'cannae' && u.team === 'egypt') {
    const rear = cells.filter(p => p.r < u.r);
    return attackers.length >= 3 &&
      rear.every(p => !inBounds(s.map, p.c, p.r) || !!mobileAt(s.map, p.c, p.r));
  }
  return attackers.length >= 3 &&
    adjacent.filter(v => v.team === u.team && !isFleeingSoldier(v)).length <= 1;
}
export function resolveRouts(s) {
  if (s.over || s.deploying) return [];
  const fled = [];
  for (const u of s.map.units.filter(x => x.team === s.side && usesMorale(x) && x.hp > 0 && !x.aboard)) {
    const encircled = surrounded(s, u);
    if (!isRouted(u) && encircled && !u.encirclementMoraleApplied)
      changeMorale(s, u, -0.12, '遭到包围');
    u.encirclementMoraleApplied = encircled;
    if (!isRouted(u)) continue;
    markRouted(s, u);
    const enemies = s.map.units.filter(x => x.team !== u.team && x.kind !== 'fort' && x.hp > 0 && !x.aboard && !isRouted(x));
    if (!enemies.length) { u.actionsLeft = 0; continue; }
    u.actionsLeft = 1;
    while (u.actionsLeft > 0) {
      const nearest = p => Math.min(...enemies.map(e => distance(p, e)));
      const anchor = s.map.units.find(x => x.team === u.team && commandKinds.has(x.kind) && x.hp > 0) ||
        { c: u.team === 'egypt' ? s.map.cols - 1 : 0, r: Math.floor(s.map.rows / 2) };
      const score = p => nearest(p) * 100 - distance(p, anchor);
      const before = score(u);
      const options = neighbors(u.c, u.r).filter(p => inBounds(s.map, p.c, p.r) && !mobileAt(s.map, p.c, p.r) &&
        canEnterFort(u, fortAt(s.map, p.c, p.r)) && Number.isFinite(moveCost(s, u, p.c, p.r)));
      options.sort((a, b) => score(b) - score(a));
      if (!options.length || score(options[0]) <= before) break;
      const from = { c: u.c, r: u.r }, dest = options[0];
      const riverMove = isFord(s.map, u.c, u.r) || isFord(s.map, dest.c, dest.r);
      u.c = dest.c; u.r = dest.r; u.actionsLeft = riverMove ? 0 : u.actionsLeft - 1;
      fled.push({ id: u.id, from, to: { ...dest } });
      s.log.push(`${unitName(s.map, u)}士气 ${moraleOf(u).toFixed(2)}，失控溃逃至 ${u.c + 1},${u.r + 1}`);
    }
    u.actionsLeft = 0;
  }
  if (fled.length) { recomputeFog(s); checkVictory(s); }
  return fled;
}
export function applyNearbyRoutMorale(s, team) {
  const routed = s.map.units.filter(u => u.hp > 0 && !u.aboard && u.routed);
  for (const u of s.map.units.filter(u => u.team === team && u.hp > 0 && !u.aboard && !isRouted(u) && usesMorale(u))) {
    const near = routed.filter(v => distance(u, v) === 1);
    const friendlyCluster = near.filter(v => v.team === team).length > 2;
    const enemyCluster = near.filter(v => v.team !== team).length > 2;
    if (friendlyCluster && !u.friendlyRoutClusterApplied)
      changeMorale(s, u, -0.05, '近旁三支以上己方溃兵');
    if (enemyCluster && !u.enemyRoutClusterApplied)
      changeMorale(s, u, 0.1, '近旁三支以上敌方溃兵');
    u.friendlyRoutClusterApplied = friendlyCluster;
    u.enemyRoutClusterApplied = enemyCluster;
  }
}
export function rallyRoutedSoldiers(s, team) {
  if (s.over || s.deploying) return [];
  const rallied = [];
  const enemies = s.map.units.filter(u => u.team !== team && u.hp > 0 && !u.aboard &&
    u.kind !== 'fort' && !isRouted(u));
  for (const guard of s.map.units.filter(u => u.team === team && ['moraleGuard', 'moraleFlagship'].includes(u.kind) &&
      u.hp > 0 && !u.aboard && !isRouted(u) && (u.hunger || 0) < 3 &&
      u.lastRallyTurn !== s.turn)) {
    const candidates = s.map.units.filter(u => u.team === team && u.hp > 0 && !u.aboard &&
      isFleeingSoldier(u) && isShip(u) === isShip(guard) && !u.uncontrolled && (u.hunger || 0) < 3 &&
      distance(u, guard) <= 2 && !enemies.some(enemy => distance(enemy, u) <= 1))
      .sort((a, b) => distance(a, guard) - distance(b, guard) || a.id.localeCompare(b.id));
    if (candidates.length) guard.lastRallyTurn = s.turn;
    for (const u of candidates.slice(0, 2)) {
      u.routed = false;
      u.starvedRouted = false;
      u.morale = Math.max(0.7, u.morale ?? 0);
      u.hp = Math.ceil(unitMaxHp(s.map, u) / 2);
      u.ammo = Math.max(u.ammo || 0, Math.ceil(unitStats(s.map, u).ammo / 2));
      u.actionsLeft = 0;
      u.movesUsed = 0; u.attacksUsed = 0; u.movedSteps = 0;
      u.encirclementMoraleApplied = false;
      rallied.push(u.id);
      s.log.push(`${unitName(s.map, guard)}收拢${unitName(s.map, u)}：恢复战斗状态，耐久 ${fmt(u.hp)}/${fmt(unitMaxHp(s.map, u))}`);
    }
  }
  if (rallied.length) recomputeFog(s);
  return rallied;
}
export function reachable(s,u){const view=planningState(s,u?.team);return reachableActual(view,u);}
function reachableActual(s, u) {
  if (!u || ['fort', 'defenseTower', 'captive'].includes(u.kind) || u.aboard || isRouted(u) || u.actionsLeft <= 0 || heroWaiting(s, u) ||
      (u.kind === 'trojanHorse' && u.movesUsed >= 1) ||
      s.over || s.deploying || s.side !== u.team) return new Map();
  const start = key(u.c, u.r);
  const {startingTerrain,inRiver,roadBonus,wallBonus,baseSteps,maxSteps,cloudyMaxSteps,perAction,budget}=movementAllowance(s,u);
  const origin = { c: u.c, r: u.r, cost: 0, steps: 0, path: [], cloudTouched: cloudAt(s, u.c, u.r),
    wallTravel: !!wallBonus, mountainRoad: usesMountainMarchRules(s) && !!(startingTerrain & TERRAIN.MOUNTAIN) };
  const stateKey = state => `${key(state.c, state.r)}:${state.steps}:${state.cloudTouched ? 1 : 0}:${state.wallTravel ? 1 : 0}:${state.mountainRoad?1:0}`;
  const bestBySteps = new Map([[stateKey(origin), origin]]);
  const destinations = new Map();
  const queue = [origin];
  while (queue.length) {
    queue.sort((a, b) => a.cost - b.cost);
    const cur = queue.shift();
    if (cur !== bestBySteps.get(stateKey(cur)) ||
        cur.steps >= (cur.cloudTouched ? cloudyMaxSteps : maxSteps) ||
        (cur.steps > 0 && (u.kind === 'supplyWagon' ? isWagonWater(s.map, u, cur.c, cur.r) :
          isFord(s.map, cur.c, cur.r)))) continue;
    for (const next of neighbors(cur.c, cur.r)) {
      const occupant = mobileAt(s.map, next.c, next.r);
      if (!inBounds(s.map, next.c, next.r) ||
          (!s.fogPolicy && !visibleTo(s, u.team, next.c, next.r) && !cloudAt(s, next.c, next.r)) ||
          (occupant && (u.kind !== 'trojanHorse' || occupant.team === u.team)) ||
          !canPassFort(u, fortAt(s.map, next.c, next.r))) continue;
      if (u.kind === 'supplyWagon' && isWagonWater(s.map, u, cur.c, cur.r) &&
          !isWagonWater(s.map, u, next.c, next.r) && !wagonLanding(tile(s.map, next.c, next.r).terrain)) continue;
      if (cur.steps > 0 && (u.kind === 'supplyWagon' ? isWagonWater(s.map, u, next.c, next.r) :
          isFord(s.map, next.c, next.r))) continue;
      const wallTravel = cur.wallTravel && highFriendlyWall(s.map, u, next.c, next.r);
      const stepCost = moveCostActual(s,u,next.c,next.r);
      if(!Number.isFinite(stepCost)) continue;
      const cost = cur.cost + (wallTravel && !usesMountainMarchRules(s) ? 1 : stepCost);
      const mountainRoad = cur.mountainRoad || (usesMountainMarchRules(s) && (tile(s.map,next.c,next.r).terrain & (TERRAIN.MOUNTAIN|TERRAIN.ROAD)) === (TERRAIN.MOUNTAIN|TERRAIN.ROAD));
      if (cost > budget - (mountainRoad ? roadBonus : 0)) continue;
      const k = key(next.c, next.r);
      const cloudTouched = cur.cloudTouched || cloudAt(s, next.c, next.r);
      const state = { ...next, cost, actionCost: usesElevationRules(s) && !usesMountainMarchRules(s) ? Math.ceil(cost / perAction) : 1, mountainRoad, steps: cur.steps + 1, path: [...cur.path, next], cloudTouched, wallTravel };
      const stepLimit = wallTravel ? maxSteps : baseSteps;
      if (state.steps > (cloudTouched ? Math.max(1, stepLimit - 1) : stepLimit)) continue;
      const stepKey = stateKey(state);
      if (bestBySteps.has(stepKey) && cost >= bestBySteps.get(stepKey).cost) continue;
      bestBySteps.set(stepKey, state); queue.push(state);
      if (!canEnterFort(u, fortAt(s.map, next.c, next.r))) continue;
      const best = destinations.get(k);
      if (!best || cost < best.cost || (cost === best.cost && state.steps < best.steps)) destinations.set(k, state);
    }
  }
  destinations.delete(start); return destinations;
}
export function move(s, id, c, r) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (!u || ['fort', 'defenseTower', 'captive'].includes(u.kind) || u.aboard || u.team !== s.side || u.actionsLeft <= 0 || s.over || isRouted(u))
    return { ok: false, reason: isRouted(u) ? '该部队已溃逃，不接受指令' : '现在不能移动这枚棋子' };
  const dest = reachableActual(s, u).get(key(c, r));
  if (!dest) {
    // A real, otherwise legal adjacent attempt may discover contact. Merely asking
    // for a path never enters this branch; distant failed orders reveal nothing.
    if(s.fogPolicy&&distance(u,{c,r})===1&&reachable(s,u).has(key(c,r))){
      s.fog[u.team].visible.add(key(c,r));s.fog[u.team].explored.add(key(c,r));updateKnowledge(s);
    }
    const fort = fortAt(s.map, c, r);
    return { ok: false, reason: fort?.team === u.team && fort.level === 1 && !canEnterFort(u, fort) ?
      '不能在己方一级城墙上停驻，请选择墙另一侧的可达地格' : '目标格不可到达' };
  }
  const riverMove = u.kind === 'supplyWagon' ?
    isWagonWater(s.map, u, u.c, u.r) || isWagonWater(s.map, u, c, r) :
    isFord(s.map, u.c, u.r) || isFord(s.map, c, r);
  const retreatingFrom = u.kind === 'parthianHorseArcher' && s.map.scenarioId === 'carrhae' ?
    s.map.units.filter(e => e.team === 'egypt' && e.kind !== 'fort' && e.hp > 0 &&
      distance(u,e) === 1) : [];
  const feignedRetreat = retreatingFrom.some(e => distance({c,r},e) >= 2);
  const sailingBefore={...u};
  if (isTrireme(u)) {
    const path = [{ c: u.c, r: u.r }, ...dest.path];
    const directions = path.slice(1).map((p, i) => neighbors(path[i].c, path[i].r)
      .findIndex(n => n.c === p.c && n.r === p.r));
    u.facing = directions.at(-1);
  }
  const crushed = u.kind === 'trojanHorse' ? mobileAt(s.map, c, r) : null;
  if (crushed) {
    crushed.hp = 0;
    s.log.push(`特洛伊木马碾过${unitName(s.map, crushed)}，敌军被消灭`);
    recordUnitKill(s, u, crushed, 1);
  }
  const chargeBefore={...u},chargeFrom={c:u.c,r:u.r};
  const segmentFrom=dest.path.length>1?dest.path.at(-2):chargeFrom,last=dest.path.at(-1),lastDir=neighbors(segmentFrom.c,segmentFrom.r).findIndex(p=>p.c===last.c&&p.r===last.r);if(lastDir>=0)u.heading12=(3-2*lastDir+12)%12;
  u.c = c; u.r = r; u.actionsLeft = riverMove ? 0 : u.actionsLeft - dest.actionCost; u.movesUsed++; u.movedSteps = dest.steps;
  recordChargeMove(s,u,chargeFrom,dest.path,chargeBefore);
  recordSailing(s,u,sailingBefore,dest.path);
  if (u.kind === 'supplyWagon' && s.map.logistics) {
    u.supplyTravel = (u.supplyTravel || 0) + dest.path.filter(p => !isWagonWater(s.map, u, p.c, p.r)).reduce((sum,p)=>sum+(usesMountainMarchRules(s)&&(tile(s.map,p.c,p.r).terrain&TERRAIN.MOUNTAIN)?2:1),0);
    while (u.supplyTravel > 5) { u.supplyTravel -= 6; takeWagonFood(u, SATIETY_PER_SUPPLY); }
  }
  if (feignedRetreat) u.feignedRetreat = true;
  if (isFormableInfantry(u) && u.formed) u.formationSteps = (u.formationSteps || 0) + dest.steps;
  if (s.map.victory.mode === 'babylon' && u.team === 'egypt' && !s.babylonAlarm) {
    const outer = s.map.victory.outer;
    if (c > outer.cMin && c < outer.cMax && r > outer.rMin && r < outer.rMax) triggerBabylonAlarm(s);
  }
  if (u.kind === 'transport') for (const passenger of cargoOf(s.map, u)) { passenger.c = c; passenger.r = r; }
  recomputeFog(s);
  const captures=resolveFortificationContact(s,u,dest);
  checkVictory(s);
  s.log.push(`${s.map.factions[u.team]}${unitName(s.map, u)}移动到 ${c + 1},${r + 1}（剩余行动 ${u.actionsLeft}${riverMove ? u.kind === 'supplyWagon' ? '；水路慢行耗尽本回合行动' : '；渡口通行耗尽本回合行动' : ''}）`);
  return { ok: true, captures, path: dest.path, actionCost: riverMove ? null : dest.actionCost, movementCost: dest.cost, riverMove, crushedId: crushed?.id ?? null };
}
// Bridges have binary intact/destroyed state in existing saves; ordinary combat
// never targets this structure. Only the explicit demolition action mutates it.
export function canDestroyBridge(s, u, c, r) {
  return !!u && u.hp>0 && s.map.units.includes(u) && u.team===s.side &&
    !['fort','captive','defenseTower'].includes(u.kind) && !isShip(u) &&
    !u.aboard && !isRouted(u) && u.actionsLeft>=1 && !s.over && !s.deploying &&
    distance(u,{c,r})<=1 && bridgeAt(s.map,c,r);
}
export function destroyBridge(s, id, c, r) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u=s.map.units.find(x=>x.id===id && x.hp>0);
  if(!canDestroyBridge(s,u,c,r))
    return {ok:false,reason:'需由当前阵营的相邻陆军消耗一次行动摧毁桥梁'};
  setBridge(s.map, c, r, false);
  interruptCharge(s,u.id); u.actionsLeft--;
  s.log.push(`${s.map.factions[u.team]}${unitName(s.map, u)}摧毁 ${c + 1},${r + 1} 的桥梁，原址留下渡口`);
  return { ok: true, c, r };
}
export function moleLanes(m) {
  if (m.victory?.mode !== 'tyre') return [];
  return Array.isArray(m.victory.moles) ? m.victory.moles :
    Array.isArray(m.victory.mole) ? [m.victory.mole] : [];
}
export function nextMoleCells(m) {
  return moleLanes(m).map((lane, laneIndex) => {
    const cell = Array.isArray(lane) && lane.find(p => Array.isArray(p) && tile(m, p[0], p[1])?.terrain === TERRAIN.SEA);
    return cell ? { c: cell[0], r: cell[1], laneIndex } : null;
  }).filter(Boolean);
}
export function nextMoleCell(m) { return nextMoleCells(m)[0] || null; }
export function buildMole(s, id, c, r) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  const targets = nextMoleCells(s.map);
  const next = c === undefined && r === undefined ?
    targets.find(p => u && distance(u, p) === 1 && !mobileAt(s.map, p.c, p.r)) :
    targets.find(p => p.c === c && p.r === r);
  if (!next || s.over || s.deploying || s.side !== 'egypt' || u?.team !== 'egypt' ||
      u.kind !== 'engineer' || u.actionsLeft < 1 || isRouted(u) || u.aboard ||
      distance(u, next) !== 1 || mobileAt(s.map, next.c, next.r))
    return { ok: false, reason: '工程队须紧邻未完工堤道，且目标海格不能有舰船' };
  if (!setTerrain(s.map, next.c, next.r, TERRAIN.ROAD))
    return { ok: false, reason: '无法在此延长堤道' };
  interruptCharge(s,u.id); u.actionsLeft--;
  s.log.push(`${unitName(s.map, u)}将通往推罗的宽堤道第 ${next.laneIndex + 1} 列延长至 ${next.c + 1},${next.r + 1}（剩余行动 ${u.actionsLeft}）`);
  recomputeFog(s);
  return { ok: true, cell: next };
}
export function alesiaWorkOptions(s, u) {
  if (s.map.victory.mode !== 'alesia' || !u || u.team !== 'egypt' ||
      !(u.kind === 'engineer' || isRomanLine(u) || ['romanVelites', 'romanArcher', 'romanHorse', 'romanAlliedHorse'].includes(u.kind)) ||
      isRomanLine(u) && u.formed) return [];
  const works = [];
  for (const [ringName, ring] of [['内环', s.map.victory.inner], ['外环', s.map.victory.outer]])
    for (const [c, r] of ring) {
      const workDistance = distance(u, { c, r });
      if (workDistance > 1) continue;
      const fort = fortAt(s.map, c, r);
      const build = !fort;
      if (build && workDistance !== 1) continue;
      if ((build && u.kind !== 'engineer') || !build && fort.team !== 'egypt' ||
          !build && fort.hp >= FORT_HP[fort.level]) continue;
      const occupant = mobileAt(s.map, c, r);
      const blocked = !!occupant && occupant.team !== 'egypt';
      works.push({ c, r, ringName, build, blocked });
    }
  return works;
}
export function buildAlesiaWork(s, id, c, r) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (s.over || s.deploying || s.side !== 'egypt' || !u || u.team !== 'egypt' ||
      u.actionsLeft < 1 || isRouted(u) || u.aboard)
    return { ok: false, reason: '这支罗马部队现在不能修筑工事' };
  const option = alesiaWorkOptions(s, u).find(p => p.c === c && p.r === r);
  if (!option) return { ok: false, reason: '工兵可新建或修复；解除列阵的罗马士兵只能修复尚存的受损工事' };
  if (option.blocked) return { ok: false, reason: '敌军占据施工点' };
  if (option.build) {
    if (!setFort(s.map, c, r, 1, 'egypt', `阿莱西亚${option.ringName}`))
      return { ok: false, reason: '此处无法新建工事' };
  } else {
    const fort = fortAt(s.map, c, r);
    fort.hp = Math.min(FORT_HP[fort.level], fort.hp + (u.kind === 'engineer' ? 80 : 30));
  }
  interruptCharge(s,u.id); u.actionsLeft--;
  s.log.push(`${unitName(s.map, u)}${option.build ? '修建' : '修复'}${option.ringName}工事 ${c + 1},${r + 1}`);
  recomputeFog(s);
  return { ok: true, ...option };
}
export function turnShip(s, id, facing) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (!u || !isTrireme(u) || u.aboard || u.team !== s.side || s.over || s.deploying ||
      u.actionsLeft < 1 || isRouted(u) || (!validFacing(facing)||(s.rulesVersion<19&&!Number.isInteger(facing))) ||
      u.facing === facing) return { ok: false, reason: '这艘战船现在不能按指定方向转向' };
  u.facing = facing;u.heading12=(3-2*facing+12)%12;
  interruptCharge(s,u.id); u.actionsLeft--;
  s.log.push(`${unitName(s.map, u)}转向${facingName(facing)}（剩余行动 ${u.actionsLeft}）`);
  return { ok: true, facing };
}
export function turnRomanLine(s, id, facing) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (!u || !['cannae', 'zama', 'carthage'].includes(s.map.scenarioId) || !isRomanLine(u) || u.team !== s.side ||
      s.over || s.deploying || isRouted(u) || u.aboard || u.uncontrolled || !u.formed || u.actionsLeft < 1 ||
      (!validFacing(facing)||(s.rulesVersion<19&&!Number.isInteger(facing))) || u.facing === facing)
    return { ok: false, reason: '这支军团现在不能转向' };
  u.facing = facing; interruptCharge(s,u.id); u.actionsLeft--;
  s.log.push(`${unitName(s.map, u)}整队转向${facingName(facing)}（剩余行动 ${u.actionsLeft}）`);
  return { ok: true, facing };
}
export function withdrawCenter(s, id) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (!u || s.map.scenarioId !== 'cannae' || !PUNIC_CENTER.has(u.kind) ||
      u.team !== s.side || s.over || s.deploying || isRouted(u) || u.actionsLeft < 1 ||
      u.lastWithdrawalTurn === s.turn || u.r >= 42)
    return { ok: false, reason: '中央步兵本回合不能有序后撤' };
  const options = neighbors(u.c, u.r).filter(p => p.r > u.r &&
    inBounds(s.map, p.c, p.r) && !mobileAt(s.map, p.c, p.r) &&
    !(tile(s.map, p.c, p.r).terrain & (TERRAIN.RIVER | TERRAIN.SEA | TERRAIN.MOUNTAIN)) &&
    !fortAt(s.map, p.c, p.r));
  options.sort((a, b) => Math.abs(a.c - 47) - Math.abs(b.c - 47));
  const dest = options[0];
  if (!dest) return { ok: false, reason: '后方没有可退入的空格' };
  const from = { c: u.c, r: u.r };
  u.c = dest.c; u.r = dest.r; interruptCharge(s,u.id); u.actionsLeft--; u.movesUsed++;
  u.lastWithdrawalTurn = s.turn; u.withdrawalGuard = true;
  recomputeFog(s); checkVictory(s);
  s.log.push(`${unitName(s.map, u)}有序后撤至 ${dest.c + 1},${dest.r + 1}，本轮首次承受近战伤害减少 20%`);
  return { ok: true, from, to: dest };
}
export function setPhalanxMode(s, id, formed, facing = undefined) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (!u || !isFormableInfantry(u) || u.team !== s.side || s.over || s.deploying || isRouted(u) || u.aboard || u.uncontrolled ||
      u.actionsLeft < 1 || u.formed === formed || typeof formed !== 'boolean' ||
      (formed && facing !== undefined && ((!validFacing(facing)||(s.rulesVersion<19&&!Number.isInteger(facing))))) ||
      (formed && (((tile(s.map, u.c, u.r).terrain & TERRAIN.MOUNTAIN) && (!usesMountainMarchRules(s) || !(tile(s.map,u.c,u.r).terrain & TERRAIN.ROAD)) || isFord(s.map, u.c, u.r)) ||
        houseAt(s.map, u.c, u.r) || fortAt(s.map, u.c, u.r))))
    return { ok: false, reason: !u?'未找到存活部队':u.actionsLeft<1?'行动力不足，等待下一本方回合':isRouted(u)?'溃逃部队不能列阵':formed&&(tile(s.map,u.c,u.r).terrain&TERRAIN.MOUNTAIN)&&!(tile(s.map,u.c,u.r).terrain&TERRAIN.ROAD)?'无路山地不能列阵，请先离开山地或进入道路':formed&&(isFord(s.map,u.c,u.r)||houseAt(s.map,u.c,u.r)||fortAt(s.map,u.c,u.r))?'渡口、房屋或城墙上不能列阵，请先移动至合法地格':'现在不能切换方阵状态' };
  u.formed = formed; interruptCharge(s,u.id); u.actionsLeft--; u.formationSteps = 0;
  if (formed && facing !== undefined) u.facing = facing;
  s.log.push(`${unitName(s.map, u)}${formed ? `朝${facingName(u.facing)}列阵` : '改为行动队形'}（剩余行动 ${u.actionsLeft}）`);
  return { ok: true, formed, facing: u.facing };
}
export function turnPhalanx(s, id, facing) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0);
  if (!u || !isFormableInfantry(u) || !u.formed || u.team !== s.side || s.over || s.deploying ||
      isRouted(u) || u.aboard || u.uncontrolled || u.actionsLeft < 1 || (!validFacing(facing)||(s.rulesVersion<19&&!Number.isInteger(facing))) ||
      u.facing === facing) return { ok: false, reason: '现在不能让方阵转向' };
  u.facing = facing; interruptCharge(s,u.id); u.actionsLeft--;
  s.log.push(`${unitName(s.map, u)}转向${facingName(facing)}（剩余行动 ${u.actionsLeft}）`);
  return { ok: true, facing };
}
function hexesBetween(a, b) {
  const n = distance(a, b), cells = [];
  if (n <= 1) return cells;
  const reversed = a.r > b.r || (a.r === b.r && a.c > b.c);
  if (reversed) [a, b] = [b, a];
  const [aq, ar] = axial(a.c, a.r), [bq, br] = axial(b.c, b.r);
  for (let i = 1; i < n; i++) {
    const t = i / n, q = aq + (bq - aq) * t, r = ar + (br - ar) * t;
    let x = Math.round(q), z = Math.round(r), y = Math.round(-q - r);
    const dx = Math.abs(x - q), dy = Math.abs(y + q + r), dz = Math.abs(z - r);
    if (dx > dy && dx > dz) x = -y - z;
    else if (dz > dy) z = -x - y;
    const c = x + Math.floor(z / 2);
    cells.push({ c, r: z });
  }
  return reversed ? cells.reverse() : cells;
}
function mountainBetween(m, a, b) {
  return hexesBetween(a, b).some(p => inBounds(m, p.c, p.r) &&
    ((tile(m, p.c, p.r).terrain & TERRAIN.MOUNTAIN) || houseAt(m, p.c, p.r)));
}
const isFootArcher = u => ['archer', 'chinaCrossbow', 'romanArcher'].includes(u.kind);
function elevatedArcher(m, u) {
  return isFootArcher(u) && !!(tile(m, u.c, u.r).terrain & TERRAIN.MOUNTAIN);
}
function rangedElevationDamage(m, attacker, defender, melee) {
  if (melee || !isFootArcher(attacker)) return 0;
  const high = !!(tile(m, attacker.c, attacker.r).terrain & TERRAIN.MOUNTAIN);
  const low = !!(tile(m, defender.c, defender.r).terrain & TERRAIN.MOUNTAIN);
  return high === low ? 0 : high ? 5 : -10; // 0.5 / -1.0 HP, stored in tenths.
}
function rangedBlocker(s, attacker, target) {
  for (const p of hexesBetween(attacker, target)) {
    if (!inBounds(s.map, p.c, p.r)) continue;
    const soldier = mobileAt(s.map, p.c, p.r);
    if (soldier && (soldier.team !== attacker.team || isFleeingSoldier(soldier))) return { type: 'enemy', unit: soldier };
    const wall = fortAt(s.map, p.c, p.r);
    // Archers and crossbowmen can shoot over their own parapet. Enemy walls
    // still shield units behind them.
    if (wall && (wall.team !== attacker.team || !isFootArcher(attacker)))
      return { type: wall.team === attacker.team ? 'wall' : 'enemy', unit: wall };
    if ((tile(s.map, p.c, p.r).terrain & TERRAIN.MOUNTAIN) &&
        !elevatedArcher(s.map, attacker)) return { type: 'terrain' };
    if (houseAt(s.map, p.c, p.r)) return { type: 'building' };
  }
  return null;
}
function engaged(s, u) { return neighbors(u.c, u.r).some(p => { const v = unitAt(s, p.c, p.r); return v && (v.team !== u.team || isFleeingSoldier(v)); }); }
const adjacentDirection = (from, to) => neighbors(from.c, from.r)
  .findIndex(p => p.c === to.c && p.r === to.r);
const directionToward = (from, to) => adjacentDirection(from, to) >= 0 ? adjacentDirection(from, to) :
  neighbors(from.c, from.r).map((p, direction) => ({ direction, d: distance(p, to) }))
    .sort((a, b) => a.d - b.d)[0].direction;
const inPhalanxFront = (u, direction) => direction >= 0 &&
  inFront(u.facing,direction);
export const effectiveFormation=u=>!!u&&isFormableInfantry(u)&&u.formed&&u.hp>0&&!isRouted(u)&&!u.aboard&&!u.uncontrolled&&validFacing(u.facing);
export function formationSupport(s,u){if(!effectiveFormation(u))return [];return s.map.units.filter(a=>a.id!==u.id&&a.team===u.team&&effectiveFormation(a)&&distance(u,a)===1);}
export function formationStatus(s,u){const sources=effectiveFormation(u)?formationSupport(s,u):[],support=s.rulesVersion>=22&&sources.length>0;return {active:effectiveFormation(u),frontDegrees:s.rulesVersion>=22?180:120,sources:s.rulesVersion>=22?sources:[],attackBonus:Number(support),defenseBonus:Number(support),baseAttack:meleePower(u,s.map),baseDefense:unitArmor(s.map,u),zamaBonus:isRomanLine(u)&&u.formed&&s.map.scenarioId==='zama'?1:0};}
function formationFaces(s,u,target){return s.rulesVersion>=22?formationFront(u,target):inPhalanxFront(u,directionToward(u,target));}
function phalanxLinked(s, u) {
  if(s.rulesVersion>=22)return formationSupport(s,u).length>0;
  return isPhalangite(u) && u.formed && neighbors(u.c, u.r).some(p => {
    const ally = mobileAt(s.map, p.c, p.r);
    return ally?.team === u.team && isPhalangite(ally) && ally.formed && ally.facing === u.facing;
  });
}
function sideExposedTo(attacker, defender) {
  const incoming = adjacentDirection(defender, attacker);
  return incoming >= 0 && facingDelta(incoming,defender.facing)>.5 && facingDelta(incoming,defender.facing)<2.5;
}
function romanLineLinked(s, u) {
  if (s.map.scenarioId !== 'cannae' || !isRomanLine(u) || !u.formed) return false;
  return [-1, 1].every(dc => {
    const ally = mobileAt(s.map, u.c + dc, u.r);
    return ally?.team === u.team && isRomanLine(ally) && ally.formed && ally.facing === u.facing;
  });
}
function protectedByGuard(s, target) {
  if (!['pharaoh', 'hittiteKing'].includes(target.kind)) return null;
  return s.map.units.find(u => u.team === target.team && u.kind === 'guard' && u.hp > 0 && !u.interceptUsed && distance(u, target) === 1) || null;
}
function damageAgainst(s, attacker, defender, melee, flank, powerOverride = null, direct = true, chargeRecord = undefined, criticalMultiplier = null) {
  if (attacker.kind === 'trojanHorse' && defender.kind === 'fort') return { damage: usesElevationRules(s) ? Math.round(400 * elevationEffect(s,attacker,defender).multiplier) : 400, charge: false };
  const formedAttacker = melee && isFormableInfantry(attacker) && attacker.formed;
  const romanFrontAttack = melee && romanLineLinked(s, attacker) &&
    inPhalanxFront(attacker, directionToward(attacker, defender));
  const power = powerOverride ?? (formedAttacker ? meleePower(attacker, s.map) +
    (s.rulesVersion>=22 ? Number(formationFaces(s,attacker,defender)&&phalanxLinked(s,attacker))+(isRomanLine(attacker)&&s.map.scenarioId==='zama'?1:0) : isRomanLine(attacker) ? (s.map.scenarioId === 'zama' ? 1 : romanFrontAttack ? 0.5 : 0) :
      Number(phalanxLinked(s, attacker))) :
    melee ? meleePower(attacker, s.map) + (romanFrontAttack ? 0.5 : 0) : rangedPower(s.map, attacker));
  const front = isPhalangite(defender) && defender.formed &&
    formationFaces(s,defender,attacker);
  let armor = isPhalangite(defender) && defender.formed ?
    (front ? unitArmor(s.map, defender) + Number(phalanxLinked(s, defender)) : 0) :
    unitArmor(s.map, defender);
  if (isRomanLine(defender) && defender.formed && melee) {
    const facesAttacker = formationFaces(s,defender,attacker);
    armor = facesAttacker ? armor + (s.map.scenarioId === 'zama' || romanLineLinked(s, defender) ? 1 : 0) : 0;
    if (defender.kind === 'romanTriarii' && isChariot(attacker)) armor += 1.5;
  }
  if(s.rulesVersion>=22&&isFormableInfantry(defender)&&defender.formed){armor=formationFaces(s,defender,attacker)?unitArmor(s.map,defender)+Number(phalanxLinked(s,defender))+(isRomanLine(defender)&&s.map.scenarioId==='zama'?1:0)+(defender.kind==='romanTriarii'&&melee&&isChariot(attacker)?1.5:0):0;}
  const charge = !usesChargeRules(s) && melee && attacker.kind === 'hittiteChariot' && attacker.movedSteps >= 2 &&
    ['light', 'heavy', 'archer', 'guard'].includes(defender.kind);
  const scytheCharge = !usesChargeRules(s) && melee && attacker.kind === 'scythedChariot' && attacker.movedSteps >= 2 && !front;
  const cavalryCharge = !usesChargeRules(s) && melee && ['companionCavalry', 'punicHeavyHorse', 'pompeyHorse', 'parthianCataphract'].includes(attacker.kind) && attacker.movedSteps >= 2;
  const parthianShot = s.map.scenarioId === 'carrhae' && !melee &&
    attacker.kind === 'parthianHorseArcher' && attacker.feignedRetreat ? 1.5 : 0;
  const fourthLineBonus = s.map.scenarioId === 'pharsalus' && melee &&
    attacker.kind === 'caesarReserve' && defender.kind === 'pompeyHorse' ? 2.5 : 0;
  const forestAmbush = s.map.scenarioId === 'teutoburg' && s.turn <= 3 && melee &&
    attacker.team === 'coalition' && defender.team === 'egypt' &&
    !!(tile(s.map, attacker.c, attacker.r).terrain & TERRAIN.MOUNTAIN) ? 2 : 0;
  const zamaRearCharge = s.map.scenarioId === 'zama' && melee && attacker.team === 'egypt' &&
    ['romanHorse', 'romanAlliedHorse', 'masinissaHorse', 'masinissa'].includes(attacker.kind) &&
    defender.team === 'coalition' && defender.r < attacker.r;
  const antiShipBonus = attacker.kind === 'defenseTower' && isShip(defender) ? 2 : 0;
  const pydnaRoughGap = s.map.scenarioId === 'pydna' && melee && isRomanLine(attacker) &&
    isPhalangite(defender) && !!(tile(s.map, defender.c, defender.r).terrain & TERRAIN.MOUNTAIN) ? 2 : 0;
  const fireOxCharge = s.map.scenarioId === 'china_tian_dan' && melee &&
    attacker.kind === 'chinaFireOx' && attacker.movedSteps >= 2 ? 3 : 0;
  const chinaChariotCharge = !usesChargeRules(s) && attacker.kind === 'chinaHeavyChariot' && melee &&
    attacker.movedSteps >= 2 ? 2 : 0;
  const eyuDownhill = !usesElevationRules(s) && s.map.scenarioId === 'china_eyu' && melee &&
    attacker.team === 'egypt' && defender.team === 'coalition' &&
    !!(tile(s.map, attacker.c, attacker.r).terrain & TERRAIN.MOUNTAIN) &&
    !(tile(s.map, defender.c, defender.r).terrain & TERRAIN.MOUNTAIN) ? 2.5 : 0;
  const base = Math.min(['siegeGalley', 'romanOnager'].includes(attacker.kind) ? 16 :
    ['hero', 'siegeRam'].includes(attacker.kind) || isTrireme(attacker) ? 12 : 8,
    Math.max(1, power + antiShipBonus - armor) + (flank ? 1 : 0) + (charge ? 2 : 0) +
    (scytheCharge ? 3 : 0) + (cavalryCharge ? 1.5 : 0) + (zamaRearCharge ? 2 : 0) + fourthLineBonus + forestAmbush + parthianShot + pydnaRoughGap + fireOxCharge + chinaChariotCharge + eyuDownhill);
  const attackerInRiver = !isShip(attacker) && isFord(s.map, attacker.c, attacker.r);
  const defenderInRiver = !isShip(defender) && isFord(s.map, defender.c, defender.r);
  const highGround = !usesElevationRules(s) && fortAt(s.map, attacker.c, attacker.r)?.team === attacker.team &&
    !fortAt(s.map, defender.c, defender.r);
  // Every combat result, including open-field unit damage, is rounded once to 0.1 HP.
  const hungerFactor = s.map.logistics && attacker.kind!=='scout' ? 1 - Math.max(0, (attacker.hunger || 0) - 2) * 0.12 : 1;
  const rawDamage = Math.max(1, Math.round((base * hungerFactor * (attackerInRiver ? 0.9 : 1) *
    (defenderInRiver ? 1.1 : 1) * 10 + (highGround ? 10 : 0)) * moraleOf(attacker) *
    (melee && defender.withdrawalGuard ? 0.8 : 1)));
  const heroDamage = defender.kind === 'hero' && attacker.kind !== 'hero' && !fortAt(s.map, defender.c, defender.r) ?
    Math.max(1, Math.round(rawDamage / 2)) : rawDamage;
  const finalDamage = defender.kind !== 'fort' && houseAt(s.map, defender.c, defender.r) ?
    Math.max(1, Math.round(heroDamage * 0.6)) : heroDamage;
  const chargeBonus=chargeEffect(s,attacker,defender,melee&&direct,chargeRecord);
  const multiplier=(direct&&usesElevationRules(s)?elevationEffect(s,attacker,defender).multiplier:1)*(criticalMultiplier??chargeBonus.multiplier);
  return {damage:usesElevationRules(s)?Math.max(1,Math.round(finalDamage*multiplier)):Math.max(1,finalDamage+rangedElevationDamage(s.map,attacker,defender,melee)),charge:usesChargeRules(s)?chargeBonus.triggered:charge,chargeBonus,formation:{power,armor,attackerFront:!formedAttacker||formationFaces(s,attacker,defender),defenderFront:!defender.formed||formationFaces(s,defender,attacker),attackSupport:s.rulesVersion>=22&&formedAttacker?Number(phalanxLinked(s,attacker)):0,defenseSupport:s.rulesVersion>=22&&defender.formed&&formationFaces(s,defender,attacker)?Number(phalanxLinked(s,defender)):0}};
}
export function attackPreview(s,u,c,r){return attackPreviewActual(planningState(s,u?.team),u,c,r);}
function attackPreviewActual(s, u, c, r) {
  if (!u || u.hp <= 0 || ['fort', 'captive', 'transport', 'engineer', 'arrowCamel'].includes(u.kind) || u.aboard || isRouted(u) || heroWaiting(s, u) ||
      ((isShip(u) || ['romanOnager', 'siegeTower', 'parthianHorseArcher'].includes(u.kind)) && u.attacksUsed >= 1) ||
      (u.kind === 'defenseTower' && u.attacksUsed >= 3) ||
      (u.kind === 'chinaCrossbow' && (u.attacksUsed || 0) >= crossbowAttackLimit(s.map, u)) ||
      u.team !== s.side || (u.actionsLeft <= 0 && !crossbowBonusShot(s, u)) ||
      s.over || s.deploying || !visibleTo(s, u.team, c, r)) return null;
  const target = ['siegeRam', 'trojanHorse'].includes(u.kind) ? fortAt(s.map, c, r) : unitAt(s, c, r), t = tile(s.map, c, r);
  if (!t || !target || target.team === u.team && !isRouted(target) || s.fogPolicy && !unitKnown(s,u.team,target)) return null;
  if (target.kind === 'trojanHorse') return null;
  if (heroWaiting(s, target)) return null;
  if (target.kind === 'captive' && s.map.victory.mode === 'babylon' && !s.babylonAlarm) return null;
  if (target.kind === 'fort' && target.cityId === '犹大流亡者围院' &&
      s.map.victory.mode === 'babylon' && !s.babylonAlarm) return null;
  if (['siegeRam', 'trojanHorse'].includes(u.kind) && target.kind !== 'fort') return null;
  const d = distance(u, { c, r }), stat = unitStats(s.map, u);
  // A chariot bowman uses the bow even against an adjacent piece; other units use melee there.
  const melee = d === 1 && !(['chariot', 'defenseTower', 'parthianHorseArcher'].includes(u.kind) && u.ammo > 0) &&
    !(['warship', 'siegeGalley'].includes(u.kind) && !isShip(target) && u.ammo > 0);
  if (chinaChariotBlocked(u.kind, tile(s.map, u.c, u.r).terrain, !usesMountainMarchRules(s)) ||
      (u.kind === 'chinaHeavyChariot' && melee && chinaChariotBlocked(u.kind, t.terrain, !usesMountainMarchRules(s)))) return null;
  if (u.kind === 'romanOnager' && d < 2) return null;
  if (melee && isFormableInfantry(u) && u.formed && !formationFaces(s,u,target)) return null;
  // The bow-to-broadside bonus represents a physical ram, never arrow fire.
  const ramBonus=ramEffect(s,u,target,melee);
  const ram = s.rulesVersion>=20?ramBonus.triggered:melee && u.kind !== 'siegeGalley' && isTrireme(u) && isTrireme(target) &&
    adjacentDirection(u, target) === u.facing && sideExposedTo(u, target);
  if (d < 1) return null;
  if (!melee && (!stat.ranged || d > stat.range || u.ammo <= 0 ||
      (u.kind !== 'chariot' && u.kind !== 'defenseTower' && u.kind !== 'parthianHorseArcher' && !isShip(u) &&
        !elevatedArcher(s.map, u) && engaged(s, u)) || rangedBlocker(s, u, { c, r }))) return null;
  if (isFleeingSoldier(target)) return { target, melee, hit: 100, damage: Math.min(target.hp, 10), flank: false, charge: false, ram: false };
  const flank = melee && target.kind !== 'fort' && neighbors(c, r).filter(p => { const v = unitAt(s, p.c, p.r); return v && v.team === u.team; }).length >= 2;
  let hit = melee ? meleeHitChance(u, s.map) : stat.rangedHit;
  if (!melee && u.movesUsed) hit -= 10;
  if (!melee && (t.terrain & TERRAIN.MOUNTAIN)) hit -= 15;
  if (flank) hit += 10;
  if (u.team === 'egypt' && u.kind !== 'pharaoh' && s.map.units.some(v => v.kind === 'pharaoh' && v.hp > 0 && distance(u, v) <= 2)) hit += 10;
  hit = u.kind === 'trojanHorse' ? 100 : Math.min(95, Math.max(20, hit));
  const { damage, charge, chargeBonus, formation } = damageAgainst(s, u, target, melee, flank);
  return { formation, elevation: usesElevationRules(s) ? elevationEffect(s,u,target) : null, target, melee, hit, damage: damage*(s.rulesVersion>=20?ramBonus.multiplier:ram?3:1), flank, charge, chargeBonus, ram, ramBonus };
}
// Charge planning is advisory. Execution always calls move()/attack() again.
export function chargeOpportunities(s,u,targets){
 s=planningState(s,u?.team);if(!usesChargeRules(s)||!chargeClass(s.map,u,s.rulesVersion)||u.actionsLeft<2)return [];
 const adjacent=new Map();for(const t of targets.filter(t=>t.hp>0&&t.team!==u.team&&t.kind!=='fort'&&!isRouted(t)&&unitKnown(s,u.team,t)))for(const p of neighbors(t.c,t.r)){const k=key(p.c,p.r);if(!adjacent.has(k))adjacent.set(k,[]);adjacent.get(k).push(t);}
 const choices=[];for(const dest of reachableActual(s,u).values()){
  if(dest.actionCost>=u.actionsLeft||!adjacent.has(key(dest.c,dest.r)))continue;
  const actor={...u,c:dest.c,r:dest.r,actionsLeft:u.actionsLeft-dest.actionCost,movesUsed:(u.movesUsed||0)+1};
  const previous=runMatches(s,u,s.chargeRuns?.[u.id])?s.chargeRuns[u.id]:null,run=movementRun(s,actor,u,dest.path,previous);
  const trial={...s,map:{...s.map,units:s.map.units.map(v=>v.id===u.id?actor:v)},chargeRuns:{[u.id]:run}};
  for(const target of adjacent.get(key(dest.c,dest.r))){const preview=attackPreviewActual(trial,actor,target.c,target.r);if(preview?.chargeBonus?.triggered)choices.push({destination:dest,target,preview});}
 }
 return choices.sort((a,b)=>b.preview.damage*b.preview.hit-a.preview.damage*a.preview.hit||a.destination.cost-b.destination.cost||a.target.id.localeCompare(b.target.id));
}
// Search only the faction planning view. Actual movement/attack revalidates all rules.
export function ramOpportunities(s,u){
 s=planningState(s,u?.team);if(s.rulesVersion<20||!canRam(u)||u.actionsLeft<2)return [];
 const targets=s.map.units.filter(t=>t.team!==u.team&&t.hp>0&&isTrireme(t)&&unitKnown(s,u.team,t)),choices=[];
 for(const dest of reachableActual(s,u).values()){
  if(dest.path.length<2||dest.actionCost>=u.actionsLeft)continue;
  const from=dest.path.length>1?dest.path.at(-2):u,facing=sailingDirection(from,dest);
  const actor={...u,c:dest.c,r:dest.r,facing,actionsLeft:u.actionsLeft-dest.actionCost,movesUsed:(u.movesUsed||0)+1};
  const previous=runMatches(s,u,s.ramRuns?.[u.id])?s.ramRuns[u.id]:null;
  const run=sailingRun(s,actor,u,dest.path,previous),trial={...s,map:{...s.map,units:s.map.units.map(v=>v.id===u.id?actor:v)},ramRuns:{[u.id]:run}};
  for(const target of targets){if(distance(actor,target)!==1)continue;const preview=attackPreviewActual(trial,actor,target.c,target.r);if(preview?.ram)choices.push({destination:dest,target,preview});}
 }
 return choices.sort((a,b)=>b.preview.damage*b.preview.hit-a.preview.damage*a.preview.hit||a.destination.cost-b.destination.cost);
}
export function attack(s, id, c, r, roll = Math.random(), damageRoll = Math.random(), moraleRoll = Math.random(), criticalRoll = null) {if(orderLocked(s,id))return {ok:false,reason:LOCK_REASON};s=authoritativeState(s);return withCombatActor(s,id,()=>attackAndRespond(s,id,c,r,roll,damageRoll,moraleRoll,criticalRoll));}
function attackAndRespond(s,id,c,r,roll,damageRoll,moraleRoll,criticalRoll){
 const attacker=s.map.units.find(u=>u.id===id),defender=attacker&&unitAt(s,c,r);
 const result=attackWithReport(s,id,c,r,roll,damageRoll,moraleRoll,criticalRoll);
 if(!s.reserveResponses||!result.ok||!result.visual?.melee||s.over||!defender||defender.hp<=0||attacker.hp<=0||defender.team===attacker.team||defender.actionsLeft<=0||(defender.responsesUsed||0)>=2)return result;
 const side=s.side,ap=defender.actionsLeft,attacks=defender.attacksUsed;
 try{
  s.side=defender.team;
  const preview=attackPreviewActual(s,defender,attacker.c,attacker.r);
  if(!preview?.melee)return result;
  defender.responsesUsed=(defender.responsesUsed||0)+1;
  s.log.push(`${unitName(s.map,defender)}保留行动反击（${defender.responsesUsed}/2）`);
  result.response=attackWithReport(s,defender.id,attacker.c,attacker.r,Math.random(),Math.random(),Math.random(),1);
 }finally{s.side=side;defender.actionsLeft=ap;defender.attacksUsed=attacks;}
 checkVictory(s);return result;
}
function attackWithReport(s,id,c,r,roll,damageRoll,moraleRoll,criticalRoll) {
  s=authoritativeState(s);
  const u = s.map.units.find(x => x.id === id && x.hp > 0), p = attackPreviewActual(s, u, c, r);
  if (!p) {
    const target = u && unitAt(s, c, r);
    if(s.fogPolicy&&target&&!unitKnown(s,u.team,target))return {ok:false,reason:"目标不可攻击"};
    if(s.rulesVersion>=22&&u&&target&&target.team!==u.team&&distance(u,target)===1&&isFormableInfantry(u)&&u.formed&&!formationFaces(s,u,target))return {ok:false,reason:'目标位于列阵背面，请先调整阵型朝向'};
    if (target?.kind === 'trojanHorse' && target.team !== u?.team)
      return { ok: false, reason: '特洛伊木马不可破坏' };
    if (target && target.team !== u.team && heroWaiting(s, target))
      return { ok: false, reason: '阿喀琉斯尚未参战，攻击无效' };
    if (target?.kind === 'fort' && target.cityId === '犹大流亡者围院' &&
        s.map.victory.mode === 'babylon' && !s.babylonAlarm && u?.team === 'coalition')
      return { ok: false, reason: '波斯军攻入巴比伦前，守军不得攻击犹大围院' };
    const d = u && distance(u, { c, r });
    const blocker = target && target.team !== u.team && u.team === s.side && u.actionsLeft > 0 &&
      !s.over && !s.deploying && unitStats(s.map, u).ranged > 0 && u.ammo > 0 &&
      visibleTo(s, u.team, c, r) && d > 1 && d <= unitStats(s.map, u).range ?
      rangedBlocker(s, u, { c, r }) : null;
    return { ok: false, reason: blocker?.type === 'enemy' ? '前方有敌军，请先攻击前方目标' :
      blocker?.type === 'wall' ? '城墙挡住了远程攻击线路' :
      blocker?.type === 'building' ? '房屋挡住了远程攻击线路' :
      blocker?.type === 'terrain' ? '山地挡住了远程攻击线路' : '目标不在有效攻击范围内' };
  }
  if(!(s.rulesVersion>=22&&isFormableInfantry(u)&&u.formed))u.heading12=clockToward(u,{c,r});
  if (isFleeingSoldier(p.target)) {
    const defender = p.target;
    interruptCharge(s,u.id);
    markRouted(s, defender);
    const damage = defender.hp;
    u.actionsLeft = Math.max(0, u.actionsLeft - 1);
    if (isShip(u) || ['defenseTower', 'romanOnager', 'siegeTower', 'parthianHorseArcher', 'chinaCrossbow'].includes(u.kind))
      u.attacksUsed = (u.attacksUsed || 0) + 1;
    if (!p.melee) u.ammo--;
    defender.hp = 0;
    s.battleJoined = true;
    s.log.push(`${unitName(s.map, u)}消耗一次攻击击杀溃逃的${unitName(s.map, defender)}`);
    recordUnitKill(s, u, defender, moraleRoll);
    recomputeFog(s); checkVictory(s);
    return { ok: true, hit: true, fortDamage: 0, unitDamage: damage, defenderId: defender.id,
      actionRefunded: false, capturedWagon: false,
      visual: { from: { c: u.c, r: u.r }, to: { c, r }, attackerId: u.id,
        attackerKind: u.kind, attackerTeam: u.team, defenderKind: defender.kind, melee: p.melee, ram: false, killed: true } };
  }
  const chargeActor={...u},chargeRecord=s.chargeRuns?.[u.id];
  interruptCharge(s,u.id);
  s.battleJoined = true;
  u.actionsLeft = Math.max(0, u.actionsLeft - 1);
  if (isShip(u) || ['defenseTower', 'romanOnager', 'siegeTower', 'parthianHorseArcher', 'chinaCrossbow'].includes(u.kind)) u.attacksUsed = (u.attacksUsed || 0) + 1;
  const threwSpear = !p.melee && u.kind === 'hittiteChariot';
  const visual = { from: { c: u.c, r: u.r }, to: { c, r }, attackerId: u.id,
    attackerKind: u.kind, attackerTeam: u.team, defenderKind: p.target.kind, melee: p.melee, ram: p.ram, ramBonus:p.ramBonus, chargeBonus:p.chargeBonus };
  if (!p.melee) u.ammo--;
  const hit = roll * 100 < p.hit;
  if (!hit) { if(p.chargeBonus?.triggered)s.log.push(chargeText(p.chargeBonus)+'；未命中，本次冲锋已消耗'); s.log.push(`${unitName(s.map, u)}${threwSpear ? '投矛' : '攻击'}未命中（剩余行动 ${u.actionsLeft}）`); return { ok: true, hit: false, visual }; }
  let defender = p.target;
  if (defender.kind !== 'fort') {
    const guard = protectedByGuard(s, defender);
    if (guard) { defender = guard; guard.interceptUsed = true; s.log.push('精锐卫队替君主承受攻击'); }
  }
  visual.to = { c: defender.c, r: defender.r };
  visual.defenderKind = defender.kind;
  const resolvedFormation=defender===p.target?p.formation:damageAgainst(s,chargeActor,defender,p.melee,p.flank,null,true,chargeRecord).formation;
  if(s.rulesVersion>=22&&resolvedFormation&&(u.formed||defender.formed))s.log.push(`列阵结算：攻击 ${resolvedFormation.power}，目标有效防御 ${resolvedFormation.armor}（${resolvedFormation.defenderFront?'正面':'背面'}）；协同攻 +${resolvedFormation.attackSupport} / 防 +${resolvedFormation.defenseSupport}`);
  const resolvedElevation = usesElevationRules(s) ? elevationEffect(s,u,defender) : null;
  const sampledPower = u.kind === 'hero' ? heroPower(damageRoll) : null;
  visual.chargeBonus=chargeEffect(s,chargeActor,defender,p.melee,chargeRecord);
  visual.chargeCritical=resolveChargeCritical(s,visual.chargeBonus,s.rulesVersion>=17&&visual.chargeBonus.triggered?(criticalRoll??Math.random()):null);
  const damage = !visual.chargeCritical.triggered && sampledPower === null && defender === p.target ? p.damage :
    damageAgainst(s, chargeActor, defender, p.melee, p.flank, sampledPower,true,chargeRecord,visual.chargeCritical.triggered?visual.chargeCritical.multiplier:null).damage * (s.rulesVersion>=20?p.ramBonus?.multiplier||1:p.ram?3:1);
  if(visual.chargeCritical.triggered)s.log.push(`冲锋暴击！基础伤害 ×${visual.chargeCritical.multiplier.toFixed(2)}（替代普通冲锋倍率，高差另结算一次）`);
  else if(visual.chargeBonus.triggered)s.log.push(chargeText(visual.chargeBonus));
  if (p.melee && defender.withdrawalGuard) defender.withdrawalGuard = false;
  const fort = defender.kind === 'fort' ? defender : fortAt(s.map, defender.c, defender.r);
  let fortDamage = 0, unitDamage = 0, towerCollapsed = false;
  if (fort) {
    const share = defender.kind === 'fort' ? 10 : FORT_SHARE[fort.level];
    const allocatedFortDamage = Math.round(damage * share / 10);
    // The wall's own armor absorbs only its allocated share, never the garrison's.
    fortDamage = u.kind === 'trojanHorse' ? Math.min(fort.hp, usesElevationRules(s) ? damage : 400) :
      Math.min(fort.hp, Math.max(0, allocatedFortDamage - FORT_ARMOR[fort.level] * 10));
    unitDamage = defender.kind === 'fort' ? 0 : Math.min(defender.hp, damage - allocatedFortDamage);
    if (unitDamage && defender.kind === 'hero' && u.kind !== 'hero')
      unitDamage = Math.max(1, Math.round(unitDamage / 2));
    fort.hp -= fortDamage;
    if (!fort.hp) {
      s.log.push(`${fort.level} 级城墙 ${fort.c + 1},${fort.r + 1} 被摧毁，可从缺口进入`);
      const tower = mobileAt(s.map, fort.c, fort.r);
      if (tower?.kind === 'defenseTower') {
        tower.hp = 0; towerCollapsed = tower === defender;
        if (towerCollapsed) unitDamage = 0;
        s.log.push(`${unitName(s.map, tower)}随城墙坍塌被摧毁`);
      }
      if (s.map.victory.mode === 'babylon' && fort.cityId === '巴比伦外城') triggerBabylonAlarm(s);
    }
  } else unitDamage = Math.min(defender.hp, damage);
  let capturedWagon = false;
  if (defender.kind !== 'fort' && !towerCollapsed) {
    const previousHp = defender.hp;
    defender.hp -= unitDamage;
    if(s.rulesVersion>=16&&defender.hp>0&&unitDamage>0)changeMorale(s,defender,-unitDamage/unitMaxHp(s.map,defender),'战斗伤亡');
    if (defender.kind === 'warElephant' && unitDamage > 0 &&
        moraleRoll < elephantPanicChance(s.map, u, defender)) {
      defender.uncontrolled = true;
      defender.actionsLeft = 0;
      s.log.push(`${unitName(s.map, defender)}受惊失控，开始无差别踩踏并向战场外溃逃！`);
    }
    if (usesMorale(defender) && !defender.halfHealthShockUsed &&
        previousHp * 2 >= unitMaxHp(s.map, defender) &&
        defender.hp > 0 && defender.hp * 2 < unitMaxHp(s.map, defender)) {
      defender.halfHealthShockUsed = true;
      changeMorale(s, defender, s.rulesVersion>=16?-0.15:-0.1, '耐久跌破半数');
    }
    if (!defender.hp) {
      if (s.map.logistics && defender.kind === 'supplyWagon') {
        const formerTeam = defender.team;
        const formerLimit = unitMaxHp(s.map, defender);
        defender.wagonCaptureLoss = Math.min(unitStats(s.map, defender).hp,
          (defender.wagonCaptureLoss || 0) + SUPPLY_WAGON_CAPTURE_DAMAGE);
        defender.hp = unitMaxHp(s.map, defender);
        const captureDamage = formerLimit - defender.hp;
        defender.actionsLeft = 0;
        defender.supplyTravel = 0;
        if (defender.hp > 0) {
          defender.team = u.team;
          capturedWagon = true;
          s.log.push(`${s.map.factions[u.team]}缴获${s.map.factions[formerTeam]}粮车，取得 ${defender.supplyStock || 0} 点粮秣；争夺永久损失 ${fmt(captureDamage)} 耐久，剩余 ${fmt(defender.hp)}`);
        } else {
          s.log.push(`${s.map.factions[formerTeam]}粮车在争夺中损失 ${fmt(captureDamage)} 耐久，降至 0 被摧毁`);
          recordUnitKill(s, u, defender, moraleRoll);
        }
      } else {
        s.log.push(`${s.map.factions[defender.team]}${unitName(s.map, defender)}被击毁`);
        if (defender.kind === 'transport') for (const passenger of cargoOf(s.map, defender)) {
          passenger.hp = 0; passenger.aboard = null;
          s.log.push(`${unitName(s.map, passenger)}随船覆没`);
        }
        recordUnitKill(s, u, defender, moraleRoll);
      }
    }
  }
  const actionRefunded = u.kind === 'hero' && defender.kind !== 'fort' && unitDamage > 0 && defender.hp === 0;
  if (actionRefunded) u.actionsLeft++;
  if(p.ramBonus?.momentum){
    s.log.push(ramText(p.ramBonus));
    if(p.ramBonus.recoil){const recoil=Math.min(u.hp,Math.round(damage/p.ramBonus.multiplier*p.ramBonus.recoil));u.hp-=recoil;visual.recoilDamage=recoil;s.log.push(`正面撞击反作用：${unitName(s.map,u)} −${fmt(recoil)}`);if(!u.hp)recordUnitKill(s,defender,u,moraleRoll);}
  }
  if (resolvedElevation) s.log.push(elevationText(resolvedElevation));
  s.log.push(`${unitName(s.map, u)}${threwSpear ? '投矛' : ''}命中：堡垒 −${fmt(fortDamage)}，${isShip(defender) ? '目标' : '守军'} −${fmt(unitDamage)}（剩余行动 ${u.actionsLeft}）`);
  if (actionRefunded) s.log.push(`${unitName(s.map, u)}直接击杀目标，返还 1 点行动力，可继续攻击`);
  recomputeFog(s);
  checkVictory(s);
  return { ok: true, hit: true, fortDamage, unitDamage, defenderId: defender.id, actionRefunded,
    capturedWagon,
    visual: { ...visual, killed: defender.hp === 0 } };
}
function recordUnitKill(s, attacker, defender, moraleRoll) {
  recordBattleEvent(s,'death',defender,attacker);
  if (commandKinds.has(defender.kind) || defender.commander) {
    for (const ally of s.map.units) if (ally.team === defender.team && ally.hp > 0)
      changeMorale(s, ally, -0.25, '指挥官阵亡');
  } else for (const ally of s.map.units) if (ally.team === defender.team && ally.hp > 0 &&
      !ally.aboard && distance(ally, defender) <= 2 && ally.lastAllyDeathShockTurn !== s.turn) {
    ally.lastAllyDeathShockTurn = s.turn;
    changeMorale(s, ally, -0.03, '近旁友军覆灭');
  }
  if (commandKinds.has(defender.kind) || defender.commander || defender.kind === 'hero') {
    const amount = commandKinds.has(defender.kind) || defender.commander ? 0.3 : 0.2;
    for (const ally of s.map.units) if (attacker.team !== defender.team && ally.team === attacker.team)
      grantMoraleBoost(ally, amount);
    s.log.push(`${s.map.factions[attacker.team]}击杀敌方${commandKinds.has(defender.kind) || defender.commander ? '指挥官' : '英雄'}，全体普通单位士气 +${amount.toFixed(1)}，持续 3 回合`);
  } else if (attacker.team !== defender.team && moraleRoll < 0.5 && usesMorale(attacker) && usesMorale(defender)) {
    grantMoraleBoost(attacker, 0.2);
    s.log.push(`${unitName(s.map, attacker)}击杀敌军，士气 +0.2，持续 3 回合`);
  }
}
function triggerBabylonAlarm(s) {
  if (s.babylonAlarm) return;
  s.babylonAlarm = true;
  s.log.push('波斯军首次攻入巴比伦；城内强硬派开始向犹大流亡者围院推进！');
}
export function moveUncontrolledElephants(s, rng = Math.random) {
  if (s.over) return [];
  const events = [];
  for (const elephant of s.map.units.filter(u => u.kind === 'warElephant' && u.uncontrolled && u.hp > 0)) {
    for (const p of neighbors(elephant.c, elephant.r)) {
      const victim = mobileAt(s.map, p.c, p.r);
      if (!victim || victim.id === elephant.id || victim.kind === 'trojanHorse') continue;
      const damage = Math.min(victim.hp, damageAgainst(s, elephant, victim, true, false, 2, false).damage);
      victim.hp -= damage;
      s.log.push(`失控战象踩踏${unitName(s.map, victim)}，造成 ${fmt(damage)} 伤害`);
      events.push({ type: 'trample', elephantId: elephant.id, victimId: victim.id, damage });
      if (!victim.hp) s.log.push(`${unitName(s.map, victim)}被失控战象踩踏击毁`);
    }
    const others = s.map.units.filter(u => u.id !== elephant.id && u.hp > 0 && u.kind !== 'fort' && !u.aboard);
    const destinations = neighbors(elephant.c, elephant.r).filter(p => inBounds(s.map, p.c, p.r) &&
      !mobileAt(s.map, p.c, p.r) && !fortAt(s.map, p.c, p.r) &&
      !(tile(s.map, p.c, p.r).terrain & (TERRAIN.SEA | TERRAIN.RIVER)) &&
      (!(tile(s.map,p.c,p.r).terrain & TERRAIN.MOUNTAIN) || usesMountainMarchRules(s) && !!(tile(s.map,p.c,p.r).terrain & TERRAIN.ROAD)));
    if (!destinations.length) continue;
    const nearest = p => others.length ? Math.min(...others.map(u => distance(p, u))) : 0;
    destinations.sort((a, b) => nearest(b) - nearest(a) ||
      Math.min(a.c, s.map.cols - 1 - a.c, a.r, s.map.rows - 1 - a.r) -
      Math.min(b.c, s.map.cols - 1 - b.c, b.r, s.map.rows - 1 - b.r));
    const bestScore = nearest(destinations[0]);
    const tied = destinations.filter(p => nearest(p) === bestScore);
    const to = tied[Math.floor(Math.max(0, Math.min(0.999999, rng())) * tied.length)];
    elephant.c = to.c; elephant.r = to.r;
    events.push({ type: 'elephantFlee', elephantId: elephant.id, to });
    if (to.c === 0 || to.c === s.map.cols - 1 || to.r === 0 || to.r === s.map.rows - 1) {
      elephant.hp = 0;
      s.log.push('失控战象逃离战场');
    }
  }
  if (events.length) { recomputeFog(s); checkVictory(s); }
  return events;
}
export function checkVictory(s){if(s.battleOutcome){endingSync(s);return s.battleOutcome.winner;}const result=checkVictoryActual(s);captureOutcome(s);return result;}
function checkVictoryActual(s) {
  if(s.observationSimulation)return;
  const v = s.map.victory;
  if (s.over) return s.winner;
  if (v.mode === 'classical') return checkClassical(s, { isRouted, isShip });
  // Most campaigns retain their objectives and a 75% army-rout fallback.
  // The three Chinese elimination campaigns use their dedicated 80% rule below.
  // Siege works,
  // commanders and unarmed support do not pad this force total.
  const fallbackRout = new Set(['leader_duel', 'troy', 'qarqar', 'babylon', 'tyre',
    'carthage', 'alesia', 'gaugamela', 'issus', 'jerusalem', 'syracuse']);
  if (!v.mode || fallbackRout.has(v.mode)) {
    const eligible = team => fallbackRout.has(v.mode) &&
      ((v.mode === 'jerusalem' || v.mode === 'syracuse') && team === 'egypt' ||
        ['gaugamela', 'issus'].includes(v.mode) && team === 'egypt') ? false : true;
    const broken = team => eligible(team) && routRoster(s.map, team)
      .filter(u => u.hp <= 0 || isRouted(u)).length >=
        Math.max(v.routLosses?.[team] || Infinity,
          Math.ceil(routRoster(s.map, team).length * ARMY_ROUT_FRACTION));
    const egypt = broken('egypt'), coalition = broken('coalition');
    if (egypt || coalition) {
      s.over = true;
      s.winner = egypt && coalition ? null : egypt ? 'coalition' : 'egypt';
      s.victoryReason = 'army_rout';
      s.log.push(s.winner ? `${s.map.factions[s.winner]}击溃敌军四分之三，赢得${s.map.name}。` :
        `${s.map.name}双方军队均已崩溃。`);
      return s.winner;
    }
  }
  if (v.mode === 'peloponnesian') {
    const naval = v.variant === 'aegospotami';
    const fighters = team => s.map.units.filter(u => u.team === team &&
      (naval ? isTrireme(u) && u.kind !== 'moraleFlagship' : !['fort', 'moraleGuard'].includes(u.kind)));
    const lost = team => fighters(team).filter(u => u.hp <= 0 || isRouted(u)).length;
    const escaped = naval && fighters('coalition').filter(u => u.hp > 0 && !isRouted(u) &&
      u.c <= v.escape.cMax && u.r >= v.escape.rMin && u.r <= v.escape.rMax).length;
    if (naval && escaped >= v.escapeShips) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'aegospotami_escape';
    } else if (lost('coalition') >= v.losses.coalition || lost('egypt') >= v.losses.egypt) {
      s.over = true; s.winner = lost('coalition') >= v.losses.coalition ? 'egypt' : 'coalition';
      s.victoryReason = `${v.variant}_losses`;
    }
    if (s.over) s.log.push(`${s.map.factions[s.winner]}达成战役目标，${s.map.name}结束。`);
    return s.winner;
  }
  if (v.mode === 'china') {
    const defender = v.attacker === 'egypt' ? 'coalition' : 'egypt';
    const lost = team => s.map.units.filter(u => u.team === team &&
      !['chinaGeneral', 'fort', 'supplyWagon', 'moraleGuard'].includes(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    if (isChinaEliminationCampaign(s.map)) {
      if (s.map.scenarioId === 'china_kunyang') {
        const cityOccupier = mobileAt(s.map, KUNYANG_CITY_OBJECTIVE.c, KUNYANG_CITY_OBJECTIVE.r);
        if (cityOccupier?.team === defender && cityOccupier.hp > 0 && !isRouted(cityOccupier) &&
            !['supplyWagon', 'moraleGuard'].includes(cityOccupier.kind)) {
          s.over = true; s.winner = defender; s.victoryReason = 'kunyang_capture';
          s.log.push(`${s.map.factions[defender]}占领昆阳城，赢得${s.map.name}。`);
          return s.winner;
        }
      }
      if (lost(v.attacker) >= v.losses[v.attacker] || lost(defender) >= v.losses[defender]) {
        s.over = true;
        s.winner = lost(v.attacker) >= v.losses[v.attacker] ? defender : v.attacker;
        s.victoryReason = 'china_elimination';
        s.log.push(`${s.map.factions[s.winner]}击溃敌军至少 80%，赢得${s.map.name}。`);
      }
      return s.winner;
    }
    const occupier = mobileAt(s.map, v.objective.c, v.objective.r);
    const occupiedByAttacker = occupier?.team === v.attacker &&
      !['supplyWagon', 'moraleGuard'].includes(occupier.kind) && occupier.hp > 0 && !isRouted(occupier);
    const breached = !v.breach || s.map.units.some(u => u.kind === 'fort' &&
      u.team === defender && u.hp <= 0);
    if (lost(v.attacker) >= v.losses[v.attacker] ||
        !s.map.units.some(u => u.team === v.attacker && u.kind === 'chinaGeneral' && u.hp > 0)) {
      s.over = true; s.winner = defender; s.victoryReason = 'china_defense';
    } else if (lost(defender) >= v.losses[defender] || hasChinaCaptureObjective(s.map) && breached && occupiedByAttacker) {
      s.over = true; s.winner = v.attacker;
      s.victoryReason = hasChinaCaptureObjective(s.map) ? 'china_capture' : 'china_rout';
    }
    if (s.over) s.log.push(`${s.map.factions[s.winner]}控制战场，${s.map.name}结束。`);
    return s.winner;
  }
  if (v.mode === 'carrhae') {
    const crassus = s.map.units.find(u => u.team === 'egypt' && u.kind === 'scipio');
    const fighters = team => s.map.units.filter(u => u.team === team &&
      !['scipio','hannibal','fort','arrowCamel'].includes(u.kind));
    const lost = team => fighters(team).filter(u => u.hp <= 0 || isRouted(u)).length;
    const escaped = u => u?.hp > 0 && !isRouted(u) && u.c <= v.escape.cMax &&
      u.r >= v.escape.rMin && u.r <= v.escape.rMax;
    if (!crassus?.hp || lost('egypt') >= v.romanLosses) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'carrhae_encirclement';
      s.log.push('克拉苏阵亡或罗马军崩溃，帕提亚军获胜。');
    } else if (escaped(crassus) && fighters('egypt').filter(escaped).length >= v.escapeUnits) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'carrhae_escape';
      s.log.push('克拉苏率罗马主力抵达西侧撤退通道。');
    } else if (lost('coalition') >= v.parthianLosses) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'carrhae_rout';
      s.log.push('罗马军击退帕提亚骑兵，打开撤退通道。');
    }
    return s.winner;
  }
  if (v.mode === 'jerusalem') {
    const titus = s.map.units.find(u => u.team === 'egypt' && u.kind === 'scipio');
    const romanLost = routRoster(s.map, 'egypt').filter(u => u.hp <= 0 || isRouted(u)).length;
    if (!titus?.hp || romanLost >= v.romanLosses) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'jerusalem_defense';
      s.log.push('提图斯阵亡或罗马攻城军崩溃，耶路撒冷守军获胜。');
      return s.winner;
    }
    while (s.jerusalemStage < v.stages.length) {
      const goal = v.stages[s.jerusalemStage];
      const breached = goal.walls.every(id => s.map.units.some(u =>
        u.kind === 'fort' && u.cityId === id && u.hp <= 0));
      const occupied = s.map.units.some(u => u.team === 'egypt' && u.hp > 0 &&
        !isRouted(u) && u.kind !== 'scipio' && !['siegeRam', 'siegeTower', 'romanOnager', 'fort'].includes(u.kind) &&
        u.c === goal.c && u.r === goal.r);
      if (!breached || !occupied) break;
      s.jerusalemStage++;
      s.log.push(`罗马军占领${goal.name}，推进到下一道防线。`);
    }
    if (s.jerusalemStage === v.stages.length) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'jerusalem_capture';
      s.log.push('罗马军突破多道城墙，控制圣殿区与上城。');
    }
    return s.winner;
  }
  if (v.mode === 'syracuse') {
    const lost = s.map.units.filter(u => u.team === 'egypt' && !commandKinds.has(u.kind) &&
      !['fort', 'siegeGalley', 'moraleGuard'].includes(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    if (lost >= v.romanLosses) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'syracuse_defense';
    } else if (v.walls.every(id => s.map.units.some(u => u.kind === 'fort' && u.cityId === id && u.hp <= 0)) &&
        s.map.units.some(u => u.team === 'egypt' && u.hp > 0 && !isRouted(u) &&
          !['siegeRam','siegeTower','romanOnager','fort'].includes(u.kind) &&
          u.c === v.capture.c && u.r === v.capture.r)) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'syracuse_capture';
    }
    return s.winner;
  }
  if (v.mode === 'pydna') {
    const lost = team => s.map.units.filter(u => u.team === team && !commandKinds.has(u.kind) &&
      !['fort', 'moraleGuard'].includes(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    if (lost('egypt') >= v.romanLosses || lost('coalition') >= v.macedonianLosses) {
      s.over = true; s.winner = lost('egypt') >= v.romanLosses ? 'coalition' : 'egypt';
      s.victoryReason = 'pydna_losses';
    }
    return s.winner;
  }
  if (v.mode === 'teutoburg') {
    const fighters = team => s.map.units.filter(u => u.team === team &&
      !['scipio', 'hannibal', 'fort', 'moraleGuard'].includes(u.kind));
    const lost = team => fighters(team).filter(u => u.hp <= 0 || isRouted(u)).length;
    const varus = s.map.units.find(u => u.team === 'egypt' && u.kind === 'scipio');
    const escaped = u => u?.hp > 0 && !isRouted(u) && u.c <= v.escape.cMax &&
      u.r >= v.escape.rMin && u.r <= v.escape.rMax;
    if (!varus?.hp || lost('egypt') >= v.romanLosses) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'teutoburg_ambush';
      s.log.push('瓦卢斯阵亡或罗马纵队崩溃，阿尔米尼乌斯赢得伏击战。');
    } else if (escaped(varus) && fighters('egypt').filter(escaped).length >= v.escapeUnits) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'teutoburg_escape';
      s.log.push('瓦卢斯与罗马纵队突破林地，沿西侧道路撤离。');
    } else if (lost('coalition') >= v.germanLosses) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'teutoburg_rout';
      s.log.push('日耳曼伏击部队崩溃，罗马纵队赢得道路控制权。');
    }
    return s.winner;
  }
  if (v.mode === 'pharsalus') {
    const losses = team => s.map.units.filter(u => u.team === team && !['fort', 'moraleGuard'].includes(u.kind) &&
      !commandKinds.has(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    if (losses('egypt') >= v.caesarLosses || losses('coalition') >= v.pompeyLosses) {
      s.over = true;
      s.winner = losses('egypt') >= v.caesarLosses ? 'coalition' : 'egypt';
      s.victoryReason = 'pharsalus_losses';
      s.log.push(`${s.map.factions[s.winner]}击溃敌方主力，赢得法萨卢斯会战。`);
    }
    return s.winner;
  }
  if (v.mode === 'alesia') {
    const corridor = u => {
      const d = distance(u, v.center);
      return d > 8 && d < 12 && u.hp > 0 && !u.aboard && !isRouted(u);
    };
    const inner = s.map.units.filter(u => u.team === 'coalition' && u.alesiaOrigin === 'inner' && corridor(u));
    const outer = s.map.units.filter(u => u.team === 'coalition' && u.alesiaOrigin === 'outer' && corridor(u));
    if (inner.some(a => outer.some(b => distance(a, b) <= 1))) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'alesia_join';
      s.log.push('阿莱西亚城内外高卢军在罗马两道工事之间会合，高卢获胜。');
    }
    return s.winner;
  }
  if (v.mode === 'cannae' || v.mode === 'zama') {
    const losses = team => s.map.units.filter(u => u.team === team && !['fort', 'moraleGuard'].includes(u.kind) &&
      !commandKinds.has(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    if (losses('egypt') >= v.romanLosses || losses('coalition') >= v.punicLosses) {
      s.over = true;
      s.winner = losses('egypt') >= v.romanLosses ? 'coalition' : 'egypt';
      s.victoryReason = `${v.mode}_losses`;
      s.log.push(`${s.map.factions[s.winner]}击溃敌方主力，赢得${v.mode === 'zama' ? '扎马' : '坎尼'}会战。`);
    }
    return s.winner;
  }
  if (v.mode === 'tyre') {
    const alexander = s.map.units.find(u => u.kind === 'pharaoh' && u.team === 'egypt');
    const occupier = mobileAt(s.map, v.capture.c, v.capture.r);
    if (!alexander?.hp || occupier?.team === 'egypt' && !isRouted(occupier)) {
      s.over = true; s.winner = !alexander?.hp ? 'coalition' : 'egypt';
      s.victoryReason = !alexander?.hp ? 'tyre_alexander' : 'tyre_capture';
      s.log.push(!alexander?.hp ? '亚历山大阵亡，推罗守军获胜。' : '马其顿军占领推罗内城，围城战获胜。');
    }
    return s.winner;
  }
  if (v.mode === 'carthage') {
    const romanAt = p => {
      const u = mobileAt(s.map, p.c, p.r);
      return u?.team === 'egypt' && !isShip(u) && u.kind !== 'siegeRam' &&
        u.hp > 0 && !isRouted(u);
    };
    if (!s.carthageHarborTaken && romanAt(v.harbor)) {
      s.carthageHarborTaken = true;
      s.log.push('罗马军占领科通港区，进攻目标转为比尔萨城堡。');
    }
    if (s.carthageHarborTaken && romanAt(v.byrsa)) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'carthage_byrsa';
      s.log.push('罗马军攻占比尔萨，迦太基围城战获胜。');
    } else if (!s.map.units.some(u => u.team === 'egypt' && u.kind !== 'fort' &&
        u.kind !== 'siegeRam' && !isShip(u) && !u.aboard && u.hp > 0 && !isRouted(u))) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'carthage_clear';
      s.log.push('罗马陆上攻城部队全部丧失战斗力，迦太基守军获胜。');
    }
    return s.winner;
  }
  if (v.mode === 'gaugamela' || v.mode === 'issus') {
    const prefix = v.mode;
    const alexander = s.map.units.find(u => u.kind === 'pharaoh' && u.team === 'egypt');
    const darius = s.map.units.find(u => u.kind === 'hittiteKing' && u.team === 'coalition');
    const lostPhalanx = s.map.units.filter(u => u.kind === 'phalangite' && u.team === 'egypt' &&
      (u.hp <= 0 || isRouted(u))).length;
    const persianFighters = s.map.units.filter(u => u.team === 'coalition' &&
      !['hittiteKing', 'fort'].includes(u.kind) && u.hp > 0 && !isRouted(u));
    if (!alexander?.hp || lostPhalanx >= v.phalanxLosses) {
      s.over = true; s.winner = 'coalition';
      s.victoryReason = !alexander?.hp ? `${prefix}_alexander` : `${prefix}_phalanx`;
      s.log.push(!alexander?.hp ? '亚历山大阵亡，波斯获胜。' : '马其顿方阵主力崩溃，波斯获胜。');
    } else if (!darius?.hp || darius.hp <= unitMaxHp(s.map, darius) / 2 || !persianFighters.length) {
      s.over = true; s.winner = 'egypt';
      s.victoryReason = !darius?.hp ? `${prefix}_darius_killed` :
        darius.hp <= unitMaxHp(s.map, darius) / 2 ? `${prefix}_darius_retreat` : `${prefix}_persian_rout`;
      s.log.push(!darius?.hp ? '大流士三世阵亡，马其顿获胜。' :
        darius.hp <= unitMaxHp(s.map, darius) / 2 ? '大流士三世负伤退出战场，马其顿获胜。' :
          '波斯战斗部队全部击溃，马其顿获胜。');
    }
    return s.winner;
  }
  if (v.mode === 'actium') {
    const ships = team => s.map.units.filter(u => u.team === team && isTrireme(u) && u.kind !== 'moraleFlagship');
    const lost = team => ships(team).filter(u => u.hp <= 0 || isRouted(u)).length;
    const antony = ships('coalition').find(u => u.commander === '安东尼');
    const cleopatra = ships('coalition').find(u => u.commander === '克娄巴特拉');
    const inEscape = u => u?.hp > 0 && !isRouted(u) && u.c <= v.escape.cMax &&
      u.r >= v.escape.rMin && u.r <= v.escape.rMax;
    const escorts = ships('coalition').filter(u => !u.commander && inEscape(u)).length;
    if (!antony?.hp || !cleopatra?.hp || lost('coalition') >= v.antonyLosses) {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'actium_blockade';
      s.log.push('安东尼舰队的突围被截断，屋大维舰队赢得亚克兴角海战。');
    } else if (inEscape(antony) && inEscape(cleopatra) && escorts >= v.escortShips) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'actium_escape';
      s.log.push('安东尼、克娄巴特拉与护航舰队突入爱奥尼亚海，突破封锁。');
    } else if (lost('egypt') >= v.octavianLosses) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'actium_rout';
      s.log.push('屋大维舰队主力崩溃，安东尼与克娄巴特拉赢得海战。');
    }
    return s.winner;
  }
  if (v.mode === 'salamis') {
    const losses = team => s.map.units.filter(u => u.team === team && isTrireme(u) && u.kind !== 'moraleFlagship' &&
      (u.hp <= 0 || isRouted(u))).length;
    if (losses('coalition') >= v.persianLosses || losses('egypt') >= v.greekLosses) {
      s.over = true; s.winner = losses('coalition') >= v.persianLosses ? 'egypt' : 'coalition';
      s.victoryReason = s.winner === 'egypt' ? 'salamis_persian_rout' : 'salamis_greek_rout';
      s.log.push(`${s.map.factions[s.winner]}击溃敌方舰队，赢得萨拉米斯海战。`);
    }
    return s.winner;
  }
  if (v.mode === 'babylon') {
    const cyrus = s.map.units.find(u => u.kind === 'pharaoh' && u.team === 'egypt');
    const captive = s.map.units.find(u => u.kind === 'captive' && u.team === 'egypt');
    if (!cyrus?.hp || !captive?.hp) {
      s.over = true; s.winner = 'coalition';
      s.victoryReason = !cyrus?.hp ? 'babylon_cyrus' : 'babylon_captive';
      s.log.push(!cyrus?.hp ? '居鲁士阵亡，巴比伦守军获胜。' : '犹大流亡者被杀害，巴比伦守军获胜。');
    }
    return s.winner;
  }
  if (v.mode === 'qarqar') {
    for (const team of ['egypt', 'coalition']) if (!s.map.units.some(u => u.team === team && u.kind !== 'fort' &&
        u.kind !== 'siegeRam' && u.hp > 0)) {
      s.over = true; s.winner = team === 'egypt' ? 'coalition' : 'egypt';
      s.victoryReason = 'qarqar_annihilation';
      s.log.push(`${s.map.factions[team]}战斗部队全部损失，${s.map.factions[s.winner]}获胜。`);
      return s.winner;
    }
    return null;
  }
  if (v.mode === 'troy') {
    const captured = s.map.units.some(u => u.team === 'egypt' && u.kind !== 'fort' && !isShip(u) &&
      !u.aboard && u.hp > 0 && u.c === v.capture.c && u.r === v.capture.r);
    const ashore = s.map.units.some(u => u.team === 'egypt' && u.kind !== 'fort' && !isShip(u) &&
      !u.aboard && u.hp > 0 && !heroWaiting(s, u));
    if (captured || !ashore) {
      s.over = true; s.winner = captured ? 'egypt' : 'coalition';
      s.victoryReason = captured ? 'troy_capture' : 'troy_clear';
      s.log.push(captured ? '阿开亚军占领特洛伊城内目标，战役获胜。' :
        '阿开亚参战的陆上兵力全部被清除，特洛伊守军获胜。');
    }
    return s.winner;
  }
  if (v.mode === 'leader_duel') {
    for (const team of ['egypt', 'coalition']) {
      if (!s.map.units.some(u => u.kind === v.leaders[team] && u.team === team && u.hp > 0)) {
        s.over = true; s.winner = team === 'egypt' ? 'coalition' : 'egypt';
        s.log.push(`${s.map.factions[team]}君主阵亡，${s.map.factions[s.winner]}获胜。`);
        break;
      }
    }
    return s.winner;
  }
  if (!s.map.units.some(u => u.kind === v.leaderKind && u.team === v.leaderSide && u.hp > 0)) {
    s.over = true; s.winner = v.leaderDeathWinner; s.log.push('君主阵亡，战斗结束。');
  } else if (!s.map.units.some(u => u.team === v.annihilateSide && u.kind !== 'fort' && u.hp > 0)) {
    s.over = true; s.winner = v.annihilationWinner; s.log.push('目标方战斗棋子全部被击杀，战斗结束。');
  }
  return s.winner;
}
export function endSide(s,rng=Math.random){const result=endSideActual(s,rng);endingSync(s);return result;}
function endSideActual(s, rng = Math.random) {
  s=authoritativeState(s);
  if (s.over || s.deploying) return;
  if (!s.battleOutcome && s.map.victory.mode === 'classical' && s.side === 'coalition' && s.turn >= s.map.victory.turnLimit) {
    checkClassical(s, { isRouted, isShip }, true); return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'peloponnesian' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    const v = s.map.victory;
    if (v.variant === 'aegospotami') {
      s.over = true; s.winner = 'egypt'; s.victoryReason = 'aegospotami_blockade';
    } else {
      const rate = team => {
        const units = s.map.units.filter(u => u.team === team && !['fort', 'moraleGuard', 'moraleFlagship'].includes(u.kind));
        return units.filter(u => u.hp <= 0 || isRouted(u)).length / units.length;
      };
      const egypt = rate('egypt'), coalition = rate('coalition');
      s.over = true; s.winner = egypt === coalition ? null : egypt < coalition ? 'egypt' : 'coalition';
      s.victoryReason = s.winner ? 'mantinea_attrition' : 'mantinea_draw';
    }
    s.log.push(s.winner ? `${s.map.factions[s.winner]}赢得${s.map.name}。` : `${s.map.name}双方战平。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'china' && !isChinaEliminationCampaign(s.map) && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    s.over = true;
    s.winner = s.map.victory.attacker === 'egypt' ? 'coalition' : 'egypt';
    s.victoryReason = 'china_hold';
    s.log.push(`${s.map.factions[s.winner]}守住目标至第 ${s.turn} 回合。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'carrhae' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    s.over = true; s.winner = 'coalition'; s.victoryReason = 'carrhae_hold';
    s.log.push(`第 ${s.turn} 回合结束，罗马军未能突破包围。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'jerusalem' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    s.over = true; s.winner = 'coalition'; s.victoryReason = 'jerusalem_hold';
    s.log.push(`第 ${s.turn} 回合结束，罗马军未能攻占上城，耶路撒冷守军获胜。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'syracuse' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (!s.over) { s.over = true; s.winner = 'coalition'; s.victoryReason = 'syracuse_hold'; }
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'pydna' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    const fighters = team => s.map.units.filter(u => u.team === team && !commandKinds.has(u.kind) && u.kind !== 'fort');
    const rate = team => fighters(team).filter(u => u.hp <= 0 || isRouted(u)).length / fighters(team).length;
    const roman = rate('egypt'), macedonian = rate('coalition');
    s.over = true; s.winner = roman === macedonian ? null : roman < macedonian ? 'egypt' : 'coalition';
    s.victoryReason = s.winner ? 'pydna_attrition' : 'pydna_draw';
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'teutoburg' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    s.over = true; s.winner = 'coalition'; s.victoryReason = 'teutoburg_hold';
    s.log.push(`第 ${s.turn} 回合结束，罗马纵队未能突破林地，日耳曼联军获胜。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'actium' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    s.over = true; s.winner = 'egypt'; s.victoryReason = 'actium_hold';
    s.log.push(`第 ${s.turn} 回合结束，封锁线仍未被突破，屋大维舰队获胜。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'pharsalus' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    const total = team => s.map.units.filter(u => u.team === team && u.kind !== 'fort' &&
      !commandKinds.has(u.kind)).length;
    const lost = team => s.map.units.filter(u => u.team === team && u.kind !== 'fort' &&
      !commandKinds.has(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    const caesarLoss = lost('egypt') / total('egypt');
    const pompeyLoss = lost('coalition') / total('coalition');
    s.over = true;
    s.winner = caesarLoss === pompeyLoss ? null : caesarLoss < pompeyLoss ? 'egypt' : 'coalition';
    s.victoryReason = s.winner ? 'pharsalus_attrition' : 'pharsalus_draw';
    s.log.push(s.winner ? `${s.map.factions[s.winner]}以较低损失率赢得法萨卢斯会战。` :
      '法萨卢斯会战双方损失比例相同，战役平局。');
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'alesia' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    checkVictory(s);
    if (s.over) return;
    s.over = true; s.winner = 'egypt'; s.victoryReason = 'alesia_hold';
    s.log.push('罗马军坚守24回合，阻止城内外高卢军会合，罗马获胜。'); return;
  }
  if (['cannae', 'zama'].includes(s.map.victory.mode) && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    const total = team => s.map.units.filter(u => u.team === team && u.kind !== 'fort' &&
      !commandKinds.has(u.kind)).length;
    const lost = team => s.map.units.filter(u => u.team === team && u.kind !== 'fort' &&
      !commandKinds.has(u.kind) && (u.hp <= 0 || isRouted(u))).length;
    const romanLoss = lost('egypt') / total('egypt');
    const punicLoss = lost('coalition') / total('coalition');
    s.over = true;
    s.winner = romanLoss === punicLoss ? null : romanLoss > punicLoss ? 'coalition' : 'egypt';
    s.victoryReason = s.winner ? `${s.map.victory.mode}_attrition` : `${s.map.victory.mode}_draw`;
    s.log.push(s.winner ? `第 ${s.turn} 回合结束，${s.map.factions[s.winner]}损失比例较低，赢得${s.map.victory.mode === 'zama' ? '扎马' : '坎尼'}会战。` :
      `第 ${s.turn} 回合结束，双方损失比例相同，战役平局。`);
    return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'tyre' && s.side === 'coalition' && s.turn >= s.map.victory.turnLimit) {
    s.over = true; s.winner = 'coalition'; s.victoryReason = 'tyre_hold';
    s.log.push(`推罗守军坚守至第 ${s.turn} 回合，围城军撤退。`); return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'carthage' && s.side === 'coalition' &&
      s.turn >= s.map.victory.turnLimit) {
    s.over = true; s.winner = 'coalition'; s.victoryReason = 'carthage_hold';
    s.log.push(`迦太基守军坚守至第 ${s.turn} 回合，围城战获胜。`); return;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'salamis') {
    const v = s.map.victory;
    const insideBay = s.map.units.filter(u => u.team === 'coalition' && isTrireme(u) &&
      u.hp > 0 && !isRouted(u) && u.c >= v.bay.cMin && u.c <= v.bay.cMax &&
      u.r >= v.bay.rMin && u.r <= v.bay.rMax).length;
    if (s.side === 'egypt' && s.salamisBayThreat && insideBay >= v.bayShips) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'salamis_bay';
      s.log.push('波斯分舰队稳固占领安贝拉基湾，波斯获胜。'); return;
    }
    if (s.side === 'coalition') s.salamisBayThreat = insideBay >= v.bayShips;
  }
  if (!s.battleOutcome && s.map.victory.mode === 'babylon') {
    if (s.side === 'egypt') {
      const captive = s.map.units.find(u => u.kind === 'captive' && u.hp > 0);
      const rescuer = captive && s.map.units.find(u => u.team === 'egypt' && u.kind !== 'captive' &&
        u.kind !== 'fort' && !isChariot(u) && u.hp > 0 && !isRouted(u) && distance(u, captive) === 1);
      const guard = captive && s.map.units.find(u => u.team === 'coalition' && u.kind !== 'fort' &&
        u.hp > 0 && distance(u, captive) <= 1);
      if (rescuer && !guard) {
        s.over = true; s.winner = 'egypt'; s.victoryReason = 'babylon_rescue';
        s.log.push(`${unitName(s.map, rescuer)}进入围院，解救犹大流亡者，波斯获胜。`); return;
      }
    }
  }
  if (!s.battleOutcome && s.map.victory.mode === 'qarqar') {
    const v = s.map.victory;
    if (s.side === 'egypt') {
      const occupier = mobileAt(s.map, v.objective.c, v.objective.r);
      s.qarqarHold = occupier?.team === 'egypt' && !isRouted(occupier) ? s.qarqarHold + 1 : 0;
      if (s.qarqarHold >= v.holdTurns) {
        s.over = true; s.winner = 'egypt'; s.victoryReason = 'qarqar_road';
        s.log.push('亚述军连续控制南向道路，突破联军防线。'); return;
      }
    } else if (s.turn >= v.turnLimit) {
      s.over = true; s.winner = 'coalition'; s.victoryReason = 'qarqar_hold';
      s.log.push('诸王联军守住南向道路，阻止亚述军继续西进。'); return;
    }
  }
  for (const u of s.map.units) {
    if (u.team !== s.side || ['fort', 'captive'].includes(u.kind) || u.aboard || isShip(u) || u.hp <= 0 || isFleeingSoldier(u) ||
        (u.actionsLeft <= 0 && u.kind !== 'hero')) continue;
    const supply = s.map.supplyPoints.find(p => p.c === u.c && p.r === u.r && p.team === u.team && activeSupplyPoint(s.map, p));
    if (supply) {
      s.pendingSupply[u.team].push({ id: u.id, c: u.c, r: u.r });
      continue;
    }
    if (u.kind === 'hero') continue;
    const ownFort = fortAt(s.map, u.c, u.r)?.team === u.team;
    const terrain = tile(s.map, u.c, u.r).terrain;
    const recovery = s.map.logistics && (u.hunger || 0) >= 3 ? 0 :
      ownFort ? 20 : (terrain & TERRAIN.MOUNTAIN) || isFord(s.map, u.c, u.r) ? 0 : 10;
    const healed = Math.min(recovery, unitMaxHp(s.map, u) - u.hp);
    if (healed > 0) {
      u.hp += healed;
      s.log.push(`${s.map.factions[u.team]}${unitName(s.map, u)}休整，恢复 ${fmt(healed)} 耐久`);
    }
  }
  for (const u of s.map.units) if (u.team === s.side && u.hp > 0 && !u.aboard &&
      !isFleeingSoldier(u) && usesMorale(u) && u.actionsLeft > 0) {
    if ((u.movesUsed || 0) === 0 && (u.attacksUsed || 0) === 0 &&
        (u.hunger || 0) < 3 && !s.map.units.some(enemy => enemy.team !== u.team &&
          enemy.hp > 0 && !enemy.aboard && !isRouted(enemy) && enemy.kind !== 'fort' &&
          distance(enemy, u) <= 3) && (u.morale ?? 1) < 1) {
      const led = s.map.units.some(leader => leader.team === u.team && leader.hp > 0 &&
        !leader.aboard && (commandKinds.has(leader.kind) || leader.commander) && distance(leader, u) <= 4);
      changeMorale(s, u, Math.min(1 - (u.morale ?? 1), led ? 0.06 : 0.03), '脱离威胁休整');
    }
  }
  for (const u of s.map.units) if (u.team === s.side && u.moraleBoosts?.length) {
    for (const boost of u.moraleBoosts) boost.remaining--;
    u.moraleBoosts = u.moraleBoosts.filter(boost => boost.remaining > 0);
  }
  if(usesChargeRules(s))s.chargeRuns={};
  s.side = s.side === 'egypt' ? 'coalition' : 'egypt';
  if (s.side === 'egypt') {
    s.turn++;
    advanceWeather(s, rng);
    fallKunyangMeteors(s, rng);
  }
  if (s.over) return;
  moveUncontrolledElephants(s, rng);
  if (s.over) return;
  for (const u of s.map.units) if (u.team === s.side && u.kind === 'hero' && u.hp > 0 && !u.aboard) {
    const terrain = tile(s.map, u.c, u.r).terrain;
    const recovery = fortAt(s.map, u.c, u.r)?.team === u.team ? 40 :
      (terrain & TERRAIN.MOUNTAIN) || isFord(s.map, u.c, u.r) ? 0 : 30;
    const healed = Math.min(recovery, unitMaxHp(s.map, u) - u.hp);
    if (healed > 0) {
      u.hp += healed;
      s.log.push(`${s.map.factions[u.team]}${unitName(s.map, u)}恢复 ${fmt(healed)} 耐久`);
    }
  }
  for (const pending of s.pendingSupply[s.side]) {
    const u = s.map.units.find(unit => unit.id === pending.id && unit.hp > 0);
    const supply = s.map.supplyPoints.find(p => p.c === pending.c && p.r === pending.r && p.team === s.side && activeSupplyPoint(s.map, p));
    if (!u || !supply || u.c !== pending.c || u.r !== pending.r || u.aboard || isFleeingSoldier(u)) continue;
    if (usesMorale(u) && (u.morale ?? 1) < 1) changeMorale(s, u, Math.min(0.06, 1 - (u.morale ?? 1)), '补给点休整');
    const healed = Math.min(20, unitMaxHp(s.map, u) - u.hp);
    if (healed > 0) {
      u.hp += healed;
      s.log.push(`${s.map.factions[u.team]}${unitName(s.map, u)}在堡垒补给点恢复 ${fmt(healed)} 耐久`);
    }
  }
  s.pendingSupply[s.side] = [];
  if (s.map.recruitment) {
    const income = s.map.recruitment.income[s.side];
    recordBattleEvent(s,'income',{team:s.side},null,income);
    s.money[s.side] += income;
    s.log.push(`${s.map.factions[s.side]}获得 ${income} 金军费（现有 ${s.money[s.side]} 金）`);
  }
  advanceLogistics(s, s.side);
  if (s.over) return;
  for (const [i, wave] of s.map.reinforcements.entries()) {
    const recurring = Number.isInteger(wave.repeatEvery);
    const arrivalId = recurring ? `${i}:${s.turn}` : i;
    if (wave.team !== s.side || wave.turn > s.turn ||
        (recurring && (s.turn - wave.turn) % wave.repeatEvery !== 0) ||
        s.arrivedReinforcements.includes(arrivalId)) continue;
    let arrived = 0;
    for (const spec of wave.units) {
      const target = recurring && s.map.scenarioId === 'troy' ?
        { c: spec.c, r: (spec.r + 7 * (s.turn - wave.turn)) % s.map.rows } : spec;
      const candidates = [];
      for (let r = 0; r < s.map.rows; r++) for (let c = 0; c < s.map.cols; c++)
        if (distance({ c, r }, target) <= 3) candidates.push({ c, r });
      candidates.sort((a, b) => distance(a, target) - distance(b, target));
      const position = candidates.find(p => !mobileAt(s.map, p.c, p.r) && addUnit(s.map, spec.kind, wave.team, p.c, p.r));
      if (position) {
        arrived++;
        if (spec.alesiaOrigin) mobileAt(s.map, position.c, position.r).alesiaOrigin = spec.alesiaOrigin;
        if (spec.cargo) for (const kind of spec.cargo) {
          if (addEmbarkedUnit(s.map, kind, wave.team, mobileAt(s.map, position.c, position.r))) arrived++;
        }
      }
    }
    s.arrivedReinforcements.push(arrivalId);
    s.log.push(`${wave.label}：${arrived} 枚棋子到达（第 ${s.turn} 回合）`);
  }
  if (s.map.scenarioId === 'carrhae' && s.side === 'coalition') {
    for (const u of s.map.units) if (u.kind === 'parthianHorseArcher' && u.hp > 0) {
      const camel = s.map.units.find(c => c.kind === 'arrowCamel' && c.team === 'coalition' &&
        c.hp > 0 && distance(c,u) <= 2);
      if (camel && u.ammo < STATS.parthianHorseArcher.ammo) {
        const before = u.ammo; u.ammo = Math.min(STATS.parthianHorseArcher.ammo, u.ammo + 3);
        s.log.push(`${unitName(s.map,u)}从驮箭骆驼补充 ${u.ammo-before} 支箭`);
      }
    }
  }
  for (const u of s.map.units) if (u.team === s.side) {
    u.responsesUsed = 0;
    u.actionsLeft = heroWaiting(s, u) || hectorWaiting(s, u) || u.uncontrolled ? 0 : u.routed ? 1 : initialActions(u.kind, tile(s.map, u.c, u.r).terrain, bridgeAt(s.map, u.c, u.r));
    u.movedSteps = 0; u.movesUsed = 0; u.attacksUsed = 0; u.interceptUsed = false;
    interruptCharge(s,u.id);
    u.withdrawalGuard = false; u.feignedRetreat = false;
    if (isFormableInfantry(u)) u.formationSteps = 0;
  }
  if (s.map.heroRelease?.team === s.side && s.turn === s.map.heroRelease.turn) {
    const hero = s.map.units.find(u => u.team === s.side && u.kind === 'hero' && u.hp > 0);
    if (hero) s.log.push(`${unitName(s.map, hero)}离开海边营帐，加入战斗。`);
  }
  if (s.map.scenarioId === 'troy' && s.side === 'coalition' && s.turn === s.map.hectorSortieTurn &&
      s.map.units.some(u => u.kind === 'hero' && u.team === 'coalition' && u.hp > 0))
    s.log.push('赫克托率军出城，转入平原野战。');
  recomputeFog(s);
  rallyRoutedSoldiers(s, s.side);
  applyNearbyRoutMorale(s, s.side);
  if (s.map.scenarioId === 'cannae' && s.side === 'egypt') {
    const punicWing = (west) => s.map.units.filter(u => u.team === 'coalition' && u.hp > 0 &&
      ['africanInfantry', 'punicHeavyHorse', 'numidianHorse'].includes(u.kind) &&
      (west ? u.c < 32 : u.c > 47) && u.r <= 31).length;
    if (punicWing(true) >= 3 && punicWing(false) >= 3 && !s.cannaeWingMoraleTriggered) {
      s.cannaeWingMoraleTriggered = true;
      for (const u of s.map.units) if (u.team === 'egypt' && isRomanLine(u) && u.hp > 0)
        changeMorale(s, u, -0.14, '双翼受压');
      s.log.push('迦太基双翼同时压迫罗马密集步兵线，罗马军团士气下降');
      checkVictory(s);
      if (s.over) return;
    }
  }
  resolveRouts(s);
}
export function aiTurn(s, rng = Math.random, policyScore = null) {
  s=planningState(s,s.side);
  if (s.over || s.deploying) return [];
  const difficulty = ['easy', 'normal', 'hard'].includes(s.aiDifficulty) ? s.aiDifficulty : 'normal';
  const team = s.side, opponent = team === 'egypt' ? 'coalition' : 'egypt';
  const actions = [];
  const routeCache = new Map();
  const siegeKinds = new Set(['siegeRam', 'romanOnager', 'siegeTower', 'siegeGalley', 'trojanHorse']);
  const isCommander = u => commandKinds.has(u.kind) || !!u.commander;
  const hadContact = s.map.units.some(x => x.team === opponent && x.hp > 0 &&
    x.kind !== 'fort' && visibleTo(s, team, x.c, x.r));
  const livingAllies = () => s.map.units.filter(x => x.team === team && x.hp > 0 &&
    !x.aboard && !isRouted(x) && x.kind !== 'fort');
  const fieldAllies = livingAllies().filter(x => !isCommander(x) && !isShip(x) &&
    !['engineer', 'siegeRam', 'siegeTower', 'romanOnager', 'supplyWagon', 'moraleGuard'].includes(x.kind));
  const explorerIds = new Set(fieldAllies.filter(x => !hadContact &&
    (x.kind==='scout' || x.scout || unitStats(s.map, x).move >= 3))
    .sort((a, b) => Number(!!b.scout) - Number(!!a.scout) ||
      unitStats(s.map, b).move - unitStats(s.map, a).move || unitStats(s.map, b).vision - unitStats(s.map, a).vision)
    .slice(0, 2).map(x => x.id));
  const intel = (s.aiIntel ||= { egypt: {}, coalition: {} })[team] ||= {};
  const visibleFoes = () => s.map.units.filter(x => x.team === opponent && x.hp > 0 &&
    !x.aboard && x.kind !== 'fort' && visibleTo(s, team, x.c, x.r));
  const rememberSighting = () => {
    const foes = visibleFoes();
    if (foes.length) {
      const scout = fieldAllies.find(x => explorerIds.has(x.id) && x.hp > 0);
      const observer = scout || fieldAllies[0];
      const nearest = [...foes].sort((a, b) => distance(observer || a, a) - distance(observer || b, b))[0];
      if (intel.lastSeen?.c !== nearest.c || intel.lastSeen?.r !== nearest.r ||
          intel.lastSeen?.turn !== s.turn) routeCache.clear();
      intel.lastSeen = { c: nearest.c, r: nearest.r, turn: s.turn };
    }
  };
  rememberSighting();
  const exposedCrossing = p => {
    const terrain = tile(s.map, p.c, p.r)?.terrain ?? 0;
    if (!(terrain & TERRAIN.MOUNTAIN) && !isFord(s.map, p.c, p.r) ||
        fortAt(s.map, p.c, p.r)?.team === team) return false;
    return visibleFoes().some(e => !isRouted(e) &&
      (unitStats(s.map, e).melee > 0 || unitStats(s.map, e).ranged > 0) &&
      distance(p, e) <= Math.min(6,
      Math.max(2, unitStats(s.map, e).move + (e.ammo > 0 ? unitStats(s.map, e).range : 1))));
  };
  const keepsCohesion = (u, p) => {
    if (explorerIds.has(u.id) || isCommander(u) || isShip(u)) return true;
    const group = fieldAllies.filter(x => x.id !== u.id && !explorerIds.has(x.id) && x.hp > 0 &&
      (!u.formation || x.formation === u.formation));
    const support = group.some(x => distance(u, x) <= 4);
    if (!support) return true;
    if (u.formation && group.length >= 3) {
      const center = { c: Math.round(group.reduce((sum, x) => sum + x.c, u.c) / (group.length + 1)),
        r: Math.round(group.reduce((sum, x) => sum + x.r, u.r) / (group.length + 1)) };
      if (distance(p, center) > 7) return false;
    }
    return group.some(x => distance(p, x) <= 5);
  };
  const scoutGoal = u => {
    const origin = fieldAllies.length ? fieldAllies.reduce((sum, x) => sum + x.c, 0) / fieldAllies.length : u.c;
    const forward = origin < s.map.cols / 2 ? s.map.cols - 2 : 1;
    const knownGoal = hasChinaCaptureObjective(s.map) && team === s.map.victory.attacker ?
      s.map.victory.objective : null;
    const bias = knownGoal || { c: forward, r: u.r };
    const sector = [...explorerIds].indexOf(u.id) ? 7 : -7;
    const desiredRow = Math.max(2, Math.min(s.map.rows - 3, bias.r + sector));
    const candidates = [];
    for (let r = 1; r < s.map.rows - 1; r++) for (let c = 1; c < s.map.cols - 1; c++) {
      if (s.fog[team].explored.has(key(c, r)) || distance(u, { c, r }) > 18) continue;
      const ground = tile(s.map, c, r).terrain;
      if (ground === TERRAIN.SEA || (ground & TERRAIN.RIVER) && !(ground & TERRAIN.ROAD) ||
          chinaChariotBlocked(u.kind, ground, !usesMountainMarchRules(s))) continue;
      candidates.push({ c, r });
    }
    candidates.sort((a, b) => distance(a, { c: bias.c, r: desiredRow }) -
      distance(b, { c: bias.c, r: desiredRow }) || distance(u, a) - distance(u, b));
    return candidates[0] || { c: bias.c, r: desiredRow };
  };
  const terrainValue = (u, p) => {
    if (isShip(u)) return 0;
    const fort = fortAt(s.map, p.c, p.r);
    const ground = tile(s.map, p.c, p.r)?.terrain || 0;
    const ranged = unitStats(s.map, u).ranged > 0 && u.ammo > 0;
    return (fort?.team === u.team ? 4 : 0) + (houseAt(s.map, p.c, p.r) ? 2 : 0) +
      (ground & TERRAIN.MOUNTAIN ? ranged ? 3 : 1 : 0) -
      (isFord(s.map, p.c, p.r) ? 4 : 0);
  };
  const battleGoal = s.map.victory?.objective || s.map.victory?.capture ||
    s.map.victory?.byrsa || s.map.victory?.harbor;
  const usefulWall = wall => {
    const victory = s.map.victory || {};
    if (victory.breach && (wall.cityId === victory.breach || wall.id === victory.breach)) return true;
    if (victory.walls?.includes(wall.cityId)) return true;
    if (victory.stages?.some(stage => stage.walls?.includes(wall.cityId))) return true;
    return !!battleGoal && distance(wall, battleGoal) <= 2;
  };
  const kadeshGoal = u => u.c >= 36 ? (u.r < 23 ? { c: 35, r: 18 } : { c: 35, r: 28 }) : { c: 22, r: 13 };
  const routeTo = (unit, goal) => {
    const kind=unit.kind;
    const routeKey = `${kind}:${!!unit.formed}:${!!unit.onFoot}:${goal.c},${goal.r}`;
    if (routeCache.has(routeKey)) return routeCache.get(routeKey);
    const field = new Uint16Array(s.map.cols * s.map.rows).fill(65535);
    const buckets = [[goal]]; field[index(s.map, goal.c, goal.r)] = 0;
    // Integer-cost Dijkstra: the same edge cost as human path previews/execution.
    // Legacy profiles retain unit-distance routing.
    for (let distanceCost=0;distanceCost<buckets.length;distanceCost++) {
      for(const from of buckets[distanceCost]||[]) {
      if(field[index(s.map,from.c,from.r)]!==distanceCost)continue;
      for (const p of neighbors(from.c, from.r)) {
        if (!inBounds(s.map, p.c, p.r)) continue;
        const i = index(s.map, p.c, p.r), terrain = s.map.terrain[i];
        if ((isShip({ kind }) ? terrain !== TERRAIN.SEA : terrain === TERRAIN.SEA && kind !== 'supplyWagon') ||
            ((terrain & TERRAIN.RIVER) && !(terrain & TERRAIN.ROAD) && kind !== 'supplyWagon') ||
            (kind === 'supplyWagon' && isWagonWater(s.map, { kind }, p.c, p.r) &&
              !isWagonWater(s.map, { kind }, from.c, from.r) &&
              !wagonLanding(tile(s.map, from.c, from.r).terrain)) ||
            exposedCrossing(p) ||
            chinaChariotBlocked(kind, terrain, !usesMountainMarchRules(s)) ||
            (isChariot({ kind }) && (terrain & TERRAIN.MOUNTAIN) && !(terrain & TERRAIN.ROAD)) ||
            (houseAt(s.map, p.c, p.r) && isChariot({ kind })) ||
            !canPassFort({ kind, team, onFoot: kind === 'pharaoh' && s.map.scenarioId === 'babylon' },
              fortAt(s.map, p.c, p.r))) continue;
        const proxy={...unit,c:p.c,r:p.r,actionsLeft:2};
        const edgeCost=usesMountainMarchRules(s)?moveCost(s,proxy,from.c,from.r):1;
        const nextDistance=distanceCost+edgeCost;
        if(!Number.isFinite(edgeCost)||nextDistance>=field[i])continue;
        field[i]=nextDistance;(buckets[nextDistance]??=[]).push(p);
      }
      }
    }
    routeCache.set(routeKey, field); return field;
  };
  const march = (u, goal) => {
    const field = routeTo(u, goal), before = field[index(s.map, u.c, u.r)];
    const reach = [...reachable(s, u).values()].filter(p =>
      !exposedCrossing(p) && keepsCohesion(u, p));
    const marchScore = p => field[index(s.map, p.c, p.r)] -
      (!isShip(u) && (tile(s.map, p.c, p.r).terrain & TERRAIN.ROAD) ?
        u.kind === 'supplyWagon' ? 1.5 : 1.1 : 0) -
      (policyScore?.(s, u, { type: 'move', to: p }) || 0);
    reach.sort((a, b) => marchScore(a) - marchScore(b) ||
      terrainValue(u, b) - terrainValue(u, a));
    const best = reach[0];
    if (!best) return false;
    const after = field[index(s.map, best.c, best.r)];
    const joinsRoad = !isShip(u) && !(tile(s.map, u.c, u.r).terrain & TERRAIN.ROAD) &&
      (tile(s.map, best.c, best.r).terrain & TERRAIN.ROAD) &&
      after <= before + 1 && marchScore(best) < before;
    if (after >= before && !joinsRoad) return false;
    const from = { c: u.c, r: u.r };
    move(s, u.id, best.c, best.r); actions.push({ type: 'move', id: u.id, from, to: best });
    if (explorerIds.has(u.id)) intel.scoutTrail = { c: u.c, r: u.r, turn: s.turn };
    rememberSighting();
    return true;
  };
  const followArmy = u => {
    if (isShip(u)) return false;
    const body = fieldAllies.filter(x => x.hp > 0 && !isRouted(x) && !explorerIds.has(x.id));
    if (body.length < 2) return false;
    const nearest = p => Math.min(...body.map(x => distance(p, x)));
    const before = nearest(u);
    if (before <= 3) return false;
    const foes = visibleFoes();
    const options = [...reachable(s, u).values()].filter(p => nearest(p) < before &&
      foes.every(e => distance(p, e) >= 3) && !exposedCrossing(p))
      .sort((a, b) => nearest(a) - nearest(b) ||
        body.filter(x => distance(b, x) <= 3).length - body.filter(x => distance(a, x) <= 3).length);
    if (!options.length) return false;
    const from = { c: u.c, r: u.r }, to = options[0];
    move(s, u.id, to.c, to.r);
    actions.push({ type: 'move', id: u.id, from, to });
    return true;
  };
  const captureGoal = u => {
    if (isShip(u) || isCommander(u) || siegeKinds.has(u.kind) ||
        ['supplyWagon', 'moraleGuard'].includes(u.kind)) return null;
    const v = s.map.victory;
    if (v.mode === 'china') {
      if (s.map.scenarioId === 'china_kunyang' && team !== v.attacker)
        return KUNYANG_CITY_OBJECTIVE;
      if (!hasChinaCaptureObjective(s.map) || team !== v.attacker || v.breach && !s.map.units.some(x => x.kind === 'fort' &&
          x.team === opponent && x.hp <= 0)) return null;
      return v.objective;
    }
    if (v.mode === 'jerusalem') {
      const stage = v.stages[s.jerusalemStage];
      return stage && stage.walls.every(id => s.map.units.some(x => x.kind === 'fort' &&
        x.cityId === id && x.hp <= 0)) ? stage : null;
    }
    if (v.mode === 'syracuse') return v.walls.every(id => s.map.units.some(x =>
      x.kind === 'fort' && x.cityId === id && x.hp <= 0)) ? v.capture : null;
    if (v.mode === 'carthage') return s.carthageHarborTaken ? v.byrsa : v.harbor;
    if (['tyre', 'troy'].includes(v.mode)) return v.capture;
    return null;
  };
  const alesiaGoal = u => {
    const v = s.map.victory, ring = u.alesiaOrigin === 'inner' ? v.inner : v.outer;
    const gap = ring.filter(([c, r]) => !fortAt(s.map, c, r))
      .sort((a, b) => distance(u, { c: a[0], r: a[1] }) - distance(u, { c: b[0], r: b[1] }))[0];
    if (!gap) return null;
    const corridor = neighbors(gap[0], gap[1]).filter(p => inBounds(s.map, p.c, p.r) &&
      distance(p, v.center) === (u.alesiaOrigin === 'inner' ? 9 : 11));
    return corridor[0] || { c: gap[0], r: gap[1] };
  };
  const alesiaRomanWorkGoal = u => {
    const center = s.map.victory.center;
    const sites = [...s.map.victory.inner, ...s.map.victory.outer]
      .filter(([c, r]) => {
        const wall = fortAt(s.map, c, r);
        return !wall || wall.team === 'egypt' && wall.hp < FORT_HP[wall.level];
      })
      .filter(([c, r]) => mobileAt(s.map, c, r)?.team !== 'coalition')
      .sort((a, b) => Number(!!fortAt(s.map, a[0], a[1])) - Number(!!fortAt(s.map, b[0], b[1])) ||
        distance(u, { c: a[0], r: a[1] }) - distance(u, { c: b[0], r: b[1] }));
    for (const [c, r] of sites.slice(0, 12)) {
      const goals = neighbors(c, r).filter(p => inBounds(s.map, p.c, p.r) &&
        distance(p, center) >= 8 && distance(p, center) <= 12 &&
        tile(s.map, p.c, p.r).terrain !== TERRAIN.SEA &&
        !mobileAt(s.map, p.c, p.r) && canEnterFort(u, fortAt(s.map, p.c, p.r)))
        .sort((a, b) => distance(u, a) - distance(u, b));
      for (const goal of goals) if (march(u, goal)) return true;
    }
    return false;
  };
  const canThreatenCommander = u => u.team === opponent && u.hp > 0 && !u.aboard &&
    u.kind !== 'fort' && u.kind !== 'captive' && u.kind !== 'transport' &&
    (unitStats(s.map, u).melee > 0 || unitStats(s.map, u).ranged > 0) &&
    (u.kind !== 'siegeRam' && u.kind !== 'trojanHorse');
  const commanderThreats = leader => s.map.units.filter(e => canThreatenCommander(e) &&
    visibleTo(s, team, e.c, e.r) &&
    distance(leader, e) <= Math.min(6, Math.max(2, unitStats(s.map, e).move +
      (unitStats(s.map, e).ranged > 0 && e.ammo > 0 ? unitStats(s.map, e).range : 1))));
  const threatenedLeaders = s.map.units.filter(u => u.team === team && u.hp > 0 && isCommander(u) &&
    !(s.map.scenarioId === 'actium' && team === 'coalition') &&
    !(s.map.scenarioId === 'teutoburg' && team === 'egypt') &&
    commanderThreats(u).length);
  const escorts = new Map();
  for (const leader of threatenedLeaders) {
    const nearby = s.map.units.filter(u => u.team === team && u.hp > 0 && !u.aboard &&
      !isCommander(u) && !['fort', 'captive', 'engineer', 'transport', 'siegeRam'].includes(u.kind) &&
      isShip(u) === isShip(leader) && distance(u, leader) <= 3)
      .sort((a, b) => Number(b.kind === 'guard') - Number(a.kind === 'guard') ||
        distance(a, leader) - distance(b, leader));
    for (const escort of nearby.slice(0, 3)) if (!escorts.has(escort.id)) escorts.set(escort.id, leader.id);
  }
  const protectedUnits = s.map.units.filter(x => x.team === team && !['fort', 'captive'].includes(x.kind) &&
    !x.aboard && x.hp > 0 && !isRouted(x))
    .sort((a, b) => Number(threatenedLeaders.some(x => x.id === b.id)) -
      Number(threatenedLeaders.some(x => x.id === a.id)) ||
      Number(escorts.has(b.id)) - Number(escorts.has(a.id)) ||
      Number(siegeKinds.has(b.kind)) - Number(siegeKinds.has(a.kind)));
  for (const u of protectedUnits) {
    let fogAttempts=0;
    while ((++fogAttempts<=8) && (u.actionsLeft > 0 || crossbowBonusShot(s, u)) && !s.over &&
        (difficulty !== 'easy' || !actions.some(action => action.id === u.id))) {
      if(u.kind==='scout'){
        const goal=scoutGoal(u),foes=visibleFoes(),near=foes.filter(e=>distance(u,e)<=5),options=[...reachable(s,u).values()];
        const score=p=>near.length?Math.min(...near.map(e=>distance(p,e)))*20-distance(u,p):-(distance(p,goal));
        const to=options.sort((a,b)=>score(b)-score(a)||a.cost-b.cost)[0];
        if(to&&score(to)>score(u)){const from={c:u.c,r:u.r},result=move(s,u.id,to.c,to.r);if(result.ok){actions.push({type:'move',id:u.id,from,to:{...to,path:result.path},result});continue;}}
        break;
      }
      if(s.rulesVersion>=18){
        const targets=captureOptions(s,u).filter(t=>t.status==='not-known-guarded'&&!t.inContact);
        if(targets.length&&!s.map.units.some(e=>e.team!==team&&e.kind!=='fort'&&e.hp>0&&attackPreview(s,u,e.c,e.r))){
          const contacts=new Set(targets.flatMap(t=>contactPoints(t,s.map)).map(p=>key(p.c,p.r))),to=[...reachable(s,u).values()].filter(p=>contacts.has(key(p.c,p.r))).sort((a,b)=>a.cost-b.cost||a.r-b.r||a.c-b.c)[0];
          if(to){const from={c:u.c,r:u.r},result=move(s,u.id,to.c,to.r);if(result.ok){actions.push({type:'move',id:u.id,from,to:{...to,path:result.path},result});continue;}}
        }
      }
      if (u.kind === 'moraleGuard') {
        const routed = s.map.units.filter(x => x.team === team && x.hp > 0 &&
          isFleeingSoldier(x) && !x.uncontrolled && (x.hunger || 0) < 3)
          .sort((a, b) => distance(u, a) - distance(u, b));
        if (routed.length && distance(u, routed[0]) > 2 && march(u, routed[0])) continue;
        if (!routed.length && followArmy(u)) continue;
        break;
      }
      if (u.kind === 'supplyWagon' && s.map.logistics) {
        const foodLeft = (u.supplyStock || 0) * SATIETY_PER_SUPPLY + (u.supplyCredit || 0);
        const soldiers = s.map.units.filter(x => x.team === team && logisticsSoldier(x) && !isRouted(x));
        const need = x => Math.max(0, carriedRationCapacity(x) - (x.fedTurns || 0)) + (x.hunger || 0);
        const urgent = soldiers.filter(x => (x.fedTurns || 0) <= 1 || (x.hunger || 0) > 0);
        const nearby = urgent.filter(x => distance(u, x) <= 3);
        if (foodLeft <= 15 && (!nearby.length || foodLeft < nearby.reduce((n, x) => n + need(x), 0))) {
          const depot = s.map.logistics.depots[team][0];
          if (distance(u, depot) <= 1) {
            const result = replenishConvoy(s, u.id);
            if (result.ok) actions.push({ type: 'replenish', id: u.id, amount: result.amount });
          } else if (march(u, depot)) continue;
        } else {
          const target = urgent.sort((a, b) =>
            (a.fedTurns || 0) - (b.fedTurns || 0) || b.hunger - a.hunger ||
            distance(u, a) - distance(u, b))[0];
          const escort = target || soldiers.filter(x => (x.fedTurns || 0) <= 2)
            .sort((a, b) => distance(u, a) - distance(u, b))[0];
          if (escort && distance(u, escort) > 2 &&
              !visibleFoes().some(e => distance(e, escort) <= 2) && march(u, escort)) continue;
        }
        break;
      }
      if (s.map.scenarioId === 'china_seven_states' && team === 'coalition' &&
          u.formation === '周亚夫断粮骑兵' && !logisticsRouteCut(s, 'egypt')) {
        const wagon = s.map.units.find(x => x.team === 'egypt' && x.kind === 'supplyWagon' &&
          x.hp > 0 && visibleTo(s, team, x.c, x.r));
        if (wagon && attackPreview(s, u, wagon.c, wagon.r)) {
          actions.push({ type: 'attack', id: u.id, c: wagon.c, r: wagon.r,
            result: attack(s, u.id, wagon.c, wagon.r, rng()) });
          continue;
        }
        if (march(u, wagon || s.map.logistics.routes.egypt.at(-1))) continue;
      }
      if (threatenedLeaders.some(x => x.id === u.id)) {
        const threats = commanderThreats(u);
        if (!threats.length) break;
        const nearbyEnemies = s.map.units.filter(e => canThreatenCommander(e) &&
          visibleTo(s, team, e.c, e.r) && distance(u, e) <= 8);
        const safety = p => {
          const nearest = Math.min(...nearbyEnemies.map(e => distance(p, e)));
          const cover = s.map.units.filter(x => x.team === team && x.id !== u.id && x.hp > 0 &&
            x.kind !== 'fort' && !x.aboard && distance(x, p) === 1).length;
          return nearest * 100 + Math.min(3, cover) * 12 +
            (fortAt(s.map, p.c, p.r)?.team === team ? 12 : 0) +
            (houseAt(s.map, p.c, p.r) ? 8 : 0);
        };
        const before = safety(u);
        const retreat = [...reachable(s, u).values()].sort((a, b) => safety(b) - safety(a))[0];
        if (retreat && safety(retreat) > before) {
          const from = { c: u.c, r: u.r };
          move(s, u.id, retreat.c, retreat.r);
          actions.push({ type: 'move', id: u.id, from, to: retreat });
          continue;
        }
        break;
      }
      if (isCommander(u) && !['actium', 'teutoburg', 'carrhae'].includes(s.map.scenarioId)) {
        if (followArmy(u)) continue;
        break;
      }
      // Role policy sees only this faction's planning view; movement and attacks
      // remain separate paid engine actions. Commander protection stays above it.
      const mobileAction=lightMobileAction(s,u,{attacked:actions.some(a=>a.id===u.id&&a.type==='attack'),moved:actions.some(a=>a.id===u.id&&a.type==='move'),policyScore});
      if(mobileAction){
        if(mobileAction.type==='hold')break;
        if(mobileAction.type==='move'){const from={c:u.c,r:u.r},to=mobileAction.to,result=move(s,u.id,to.c,to.r);if(result.ok){actions.push({type:'move',id:u.id,from,to:{...to,path:result.path},result,roleIntent:mobileAction.intent});continue;}break;}
        const t=mobileAction.target,result=attack(s,u.id,t.c,t.r,rng(),rng(),rng(),rng());
        if(result.ok){actions.push({type:'attack',id:u.id,c:t.c,r:t.r,result,roleIntent:mobileAction.intent});continue;}break;
      }
      const capture = captureGoal(u);
      if (capture && !mobileAt(s.map, capture.c, capture.r) && !exposedCrossing(capture)) {
        const step = reachable(s, u).get(key(capture.c, capture.r));
        if (step) {
          const from = { c: u.c, r: u.r };
          move(s, u.id, capture.c, capture.r);
          actions.push({ type: 'move', id: u.id, from, to: step });
          continue;
        }
      }
      const protectedLeader = s.map.units.find(x => x.id === escorts.get(u.id) && x.hp > 0);
      if (protectedLeader) {
        const threats = s.map.units.filter(e => canThreatenCommander(e) &&
          visibleTo(s, team, e.c, e.r) &&
          distance(e, protectedLeader) <= 6)
          .sort((a, b) => distance(a, protectedLeader) - distance(b, protectedLeader));
        const target = threats.find(e => attackPreview(s, u, e.c, e.r));
        if (target) {
          actions.push({ type: 'attack', id: u.id, c: target.c, r: target.r,
            result: attack(s, u.id, target.c, target.r, rng()) });
          continue;
        }
        const nearest = threats[0];
        if (nearest) {
          const screen = [...reachable(s, u).values()]
            .filter(p => distance(p, protectedLeader) === 1 &&
              distance(p, nearest) < distance(protectedLeader, nearest))
            .sort((a, b) => distance(a, nearest) - distance(b, nearest))[0];
          const alreadyScreening = distance(u, protectedLeader) === 1 &&
            distance(u, nearest) < distance(protectedLeader, nearest);
          if (!alreadyScreening && screen) {
            const from = { c: u.c, r: u.r };
            move(s, u.id, screen.c, screen.r);
            actions.push({ type: 'move', id: u.id, from, to: screen });
            continue;
          }
        }
        break;
      }
      if (!isShip(u) && !['defenseTower', 'engineer'].includes(u.kind)) {
        const bridge = (s.map.bridges || []).find(p => distance(u, p) <= 1 &&
          mobileAt(s.map, p.c, p.r)?.team === opponent);
        if (bridge && destroyBridge(s, u.id, bridge.c, bridge.r).ok) {
          actions.push({ type: 'destroyBridge', id: u.id, c: bridge.c, r: bridge.r });
          continue;
        }
      }
      if (s.map.scenarioId === 'alesia' && team === 'egypt') {
        const nearbyGauls = s.map.units.filter(x => x.team === 'coalition' && x.kind !== 'fort' &&
          x.hp > 0 && !x.aboard && distance(x, s.map.victory.center) >= 7);
        if (u.kind === 'engineer') {
          const work = alesiaWorkOptions(s, u).filter(p => !p.blocked)
            .sort((a, b) => Number(!a.build) - Number(!b.build))[0];
          if (work) {
            const result = buildAlesiaWork(s, u.id, work.c, work.r);
            if (result.ok) { actions.push({ type: 'alesiaWork', id: u.id, c: work.c, r: work.r }); continue; }
          }
          if (alesiaRomanWorkGoal(u)) continue;
          break;
        }
        if (isRomanLine(u) && u.formed && s.map.units.some(x => x.kind === 'fort' &&
            x.team === 'egypt' && x.hp > 0 && x.hp < FORT_HP[x.level] && distance(x, u) === 1)) {
          const changed = setPhalanxMode(s, u.id, false);
          if (changed.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: false }); continue; }
        }
        const work = alesiaWorkOptions(s, u).find(p => !p.blocked && !p.build);
        if (work) {
          const result = buildAlesiaWork(s, u.id, work.c, work.r);
          if (result.ok) { actions.push({ type: 'alesiaWork', id: u.id, c: work.c, r: work.r }); continue; }
        }
        const target = nearbyGauls.find(x => attackPreview(s, u, x.c, x.r));
        if (target) {
          actions.push({ type: 'attack', id: u.id, c: target.c, r: target.r,
            result: attack(s, u.id, target.c, target.r, rng()) });
          continue;
        }
        break;
      }
      if (s.map.scenarioId === 'alesia' && team === 'coalition' && u.alesiaOrigin === 'inner' &&
          distance(u, s.map.victory.center) <= 5 && s.turn < 8) {
        const target = s.map.units.find(x => x.team === 'egypt' && x.hp > 0 &&
          attackPreview(s, u, x.c, x.r));
        if (target) {
          actions.push({ type: 'attack', id: u.id, c: target.c, r: target.r,
            result: attack(s, u.id, target.c, target.r, rng()) });
          continue;
        }
        break;
      }
      if(s.rulesVersion>=20&&canRam(u)&&u.actionsLeft>=2){
        const option=ramOpportunities(s,u).find(o=>o.preview.ram);
        if(option){const from={c:u.c,r:u.r},to=option.destination,result=move(s,u.id,to.c,to.r);if(result.ok){actions.push({type:'move',id:u.id,from,to:{...to,path:result.path}});continue;}}
      }
      // A bow-to-broadside ram is worth spending one action to line up when it
      // leaves another action to strike. Do not turn away from an existing ram.
      if (s.rulesVersion<20 && isTrireme(u) && u.kind !== 'siegeGalley' && u.actionsLeft >= 2) {
        const ships = s.map.units.filter(e => e.team === opponent && e.hp > 0 &&
          isTrireme(e) && distance(u, e) === 1 && visibleTo(s, team, e.c, e.r));
        const existingRam = ships.some(e => attackPreview(s, u, e.c, e.r)?.ram);
        if (!existingRam) {
          const target = ships.find(e => {
            const direction = adjacentDirection(u, e);
            return direction !== u.facing && sideExposedTo(u, e) &&
              attackPreview(s, u, e.c, e.r)?.melee;
          });
          if (target) {
            const facing = adjacentDirection(u, target);
            if (turnShip(s, u.id, facing).ok) {
              actions.push({ type: 'turnShip', id: u.id, facing });
              continue;
            }
          }
        }
      }
      if (s.map.scenarioId === 'troy' && team === 'coalition' && u.kind === 'hero' &&
          s.turn >= s.map.hectorSortieTurn && u.c >= 35 && march(u, { c: 30, r: 20 })) continue;
      if (s.map.scenarioId === 'troy' && team === 'egypt' && u.kind === 'trojanHorse' &&
          u.c < 34 && march(u, { c: 34, r: 20 })) continue;
      if (s.map.scenarioId === 'carthage' && team === 'egypt' && isShip(u) && u.kind !== 'transport') {
        const targets = s.map.units.filter(x => x.team === 'coalition' && x.hp > 0 &&
          (u.kind === 'siegeGalley' ? x.kind === 'defenseTower' || isShip(x) : isShip(x)))
          .sort((a, b) => (a.kind === 'defenseTower' ? -1 : 0) - (b.kind === 'defenseTower' ? -1 : 0) ||
            distance(u, a) - distance(u, b));
        const target = targets.find(x => attackPreview(s, u, x.c, x.r));
        if (target) {
          actions.push({ type: 'attack', id: u.id, c: target.c, r: target.r,
            result: attack(s, u.id, target.c, target.r, rng()) });
          continue;
        }
      }
      if (s.map.scenarioId === 'carthage' && team === 'egypt' && isShip(u) &&
          u.kind !== 'transport' && (u.c > 63 || u.r < 33 || u.r > 35) &&
          march(u, { c: 63, r: 34 })) continue;
      if (s.map.scenarioId === 'tyre' && team === 'egypt' && u.kind === 'engineer') {
        const next = nextMoleCells(s.map).sort((a, b) =>
          Math.abs(a.r - u.r) - Math.abs(b.r - u.r) || distance(u, a) - distance(u, b))[0];
        if (next) {
          if (distance(u, next) === 1) {
            const built = buildMole(s, u.id, next.c, next.r);
            if (built.ok) { actions.push({ type: 'buildMole', id: u.id, cell: built.cell }); continue; }
          }
          const head = moleLanes(s.map)[next.laneIndex].slice().reverse()
            .find(([c, r]) => tile(s.map, c, r).terrain === TERRAIN.ROAD);
          if (head && march(u, { c: head[0], r: head[1] })) continue;
        }
      }
      if (s.map.scenarioId === 'babylon' && team === 'coalition' && u.pursuer && !s.babylonAlarm) break;
      if (s.map.scenarioId === 'carrhae') {
        if (u.kind === 'arrowCamel') break;
        if (team === 'egypt') {
          const nearby = s.map.units.some(e => e.team === 'coalition' && e.hp > 0 &&
            e.kind !== 'arrowCamel' && distance(u,e) <= 1);
          if (!nearby && march(u,{c:5,r:Math.max(16,Math.min(26,u.r))})) continue;
        } else if (u.kind === 'parthianHorseArcher') {
          if (u.ammo === 0) {
            const camel = s.map.units.filter(c => c.kind === 'arrowCamel' && c.hp > 0)
              .sort((a,b)=>distance(u,a)-distance(u,b))[0];
            if (camel && distance(u,camel)>2 && march(u,camel)) continue;
            break;
          }
          const close = s.map.units.filter(e => e.team === 'egypt' && e.hp > 0 &&
            distance(u,e) === 1);
          if (close.length && u.actionsLeft > 1) {
            const spots = [...reachable(s,u).values()].filter(p =>
              close.every(e=>distance(p,e)>=2) && close.some(e=>distance(p,e)<=3))
              .sort((a,b)=>distance(a,close[0])-distance(b,close[0]));
            if (spots.length) {
              const from={c:u.c,r:u.r}, to=spots[0];
              move(s,u.id,to.c,to.r); actions.push({type:'move',id:u.id,from,to}); continue;
            }
          }
        }
      }
      if (s.map.scenarioId === 'syracuse' && team === 'egypt' &&
          ['siegeRam', 'romanOnager', 'siegeGalley'].includes(u.kind)) {
        const wallId = s.map.victory.walls.find(id => !s.map.units.some(x =>
          x.kind === 'fort' && x.cityId === id && x.hp <= 0));
        const targets = s.map.units.filter(x => x.kind === 'fort' && x.hp > 0 &&
          x.cityId === (u.kind === 'siegeGalley' ? '海墙' : wallId))
          .sort((a,b) => Math.abs(a.r-25)-Math.abs(b.r-25) || distance(u,a)-distance(u,b));
        const shot = targets.find(x => attackPreview(s,u,x.c,x.r));
        if (shot) {
          actions.push({ type:'attack', id:u.id, c:shot.c, r:shot.r,
            result:attack(s,u.id,shot.c,shot.r,rng()) });
          continue;
        }
        if (u.kind === 'siegeGalley') {
          if (march(u,{c:58,r:Math.max(16,Math.min(32,u.r))})) continue;
        } else if (targets[0] && march(u,targets[0])) continue;
        break;
      }
      if (s.map.scenarioId === 'jerusalem' && team === 'egypt' &&
          ['siegeRam', 'romanOnager', 'siegeTower'].includes(u.kind)) {
        const stage = s.map.victory.stages[s.jerusalemStage];
        const wallId = stage?.walls.find(id => !s.map.units.some(x =>
          x.kind === 'fort' && x.cityId === id && x.hp <= 0));
        const walls = s.map.units.filter(x => x.kind === 'fort' && x.cityId === wallId && x.hp > 0)
          .sort((a,b) => Math.abs(a.c-stage.c) - Math.abs(b.c-stage.c) || distance(u,a) - distance(u,b));
        const target = walls[0];
        if (target) {
          const shot = walls.find(x => attackPreview(s,u,x.c,x.r));
          if (shot) {
            actions.push({ type: 'attack', id: u.id, c: shot.c, r: shot.r,
              result: attack(s,u.id,shot.c,shot.r,rng()) });
            continue;
          }
          if (march(u,target)) continue;
        }
        break;
      }
      if ((['qarqar', 'babylon', 'tyre', 'carthage'].includes(s.map.scenarioId) ||
          s.map.victory.mode === 'china') && u.kind === 'siegeRam') {
        const walls = s.map.units.filter(x => x.kind === 'fort' && x.team !== team && x.hp > 0)
          .filter(x => !(s.map.scenarioId === 'babylon' && team === 'coalition' &&
            !s.babylonAlarm && x.cityId === '犹大流亡者围院'))
          .sort((a, b) => distance(u, a) - distance(u, b) || a.hp - b.hp);
        const target = walls[0];
        if (!target) break;
        const preview = attackPreview(s, u, target.c, target.r);
        if (preview) {
          actions.push({ type: 'attack', id: u.id, c: target.c, r: target.r,
            result: attack(s, u.id, target.c, target.r, rng()) });
          continue;
        }
        if (distance(u, target) > 1 && march(u, target)) continue;
        break;
      }
      if (u.kind === 'transport' && cargoOf(s.map, u).length) {
        if (s.map.scenarioId === 'carthage' && team === 'egypt' && !carthageSeaSecured(s)) break;
        const shore = neighbors(u.c, u.r).find(p => inBounds(s.map, p.c, p.r) &&
          (s.map.scenarioId !== 'carthage' || team !== 'egypt' || p.r === 30 && p.c >= 53 && p.c <= 59) &&
          (tile(s.map, p.c, p.r).terrain & TERRAIN.BEACH) && !mobileAt(s.map, p.c, p.r) &&
          canEnterFort(cargoOf(s.map, u)[0], fortAt(s.map, p.c, p.r)));
        if (shore && disembark(s, u.id, shore.c, shore.r)) {
          actions.push({ type: 'disembark', id: u.id, to: shore });
          continue;
        }
        if (team === 'egypt' && s.map.scenarioId === 'troy' && march(u, { c: 15, r: u.r < 18 ? 13 : 23 })) continue;
        if (team === 'egypt' && s.map.scenarioId === 'tyre' && march(u, u.r < 19 ? { c: 39, r: 10 } : { c: 42, r: 28 })) continue;
        if (team === 'egypt' && s.map.scenarioId === 'carthage' && march(u, { c: 56, r: 31 })) continue;
        break;
      }
      if (s.map.scenarioId === 'babylon' && team === 'coalition' && s.babylonAlarm && u.pursuer) {
        const captive = s.map.units.find(x => x.kind === 'captive' && x.hp > 0);
        if (captive) {
          const preview = attackPreview(s, u, captive.c, captive.r);
          if (preview) {
            actions.push({ type: 'attack', id: u.id, c: captive.c, r: captive.r,
              result: attack(s, u.id, captive.c, captive.r, rng()) });
            continue;
          }
          if (march(u, captive)) continue;
        }
      }
      const enemies = s.map.units.filter(x => x.team === opponent && x.hp > 0 &&
        !heroWaiting(s, x) &&
        !(s.map.scenarioId === 'babylon' && x.kind === 'captive') &&
        !(s.map.scenarioId === 'babylon' && team === 'coalition' && !s.babylonAlarm &&
          x.kind === 'fort' && x.cityId === '犹大流亡者围院') &&
        !(s.map.scenarioId === 'babylon' && team === 'egypt' && s.babylonAlarm && x.kind === 'fort') &&
        visibleTo(s, team, x.c, x.r) &&
        (x.kind !== 'fort' || siegeKinds.has(u.kind) ||
          usefulWall(x) && !s.map.units.some(ally => ally.team === team && ally.hp > 0 &&
            siegeKinds.has(ally.kind) && distance(ally, x) <= 6)));
      if (!enemies.some(e => attackPreview(s, u, e.c, e.r))) {
        const fleeingAlly = s.map.units.find(x => x.team === team && x.id !== u.id && x.hp > 0 &&
          isFleeingSoldier(x) && attackPreview(s, u, x.c, x.r));
        if (fleeingAlly) {
          actions.push({ type: 'attack', id: u.id, c: fleeingAlly.c, r: fleeingAlly.r,
            result: attack(s, u.id, fleeingAlly.c, fleeingAlly.r, rng()) });
          continue;
        }
      }
      if (s.map.victory.mode === 'classical' && classicalFighter(u) &&
          !enemies.some(e => attackPreview(s, u, e.c, e.r))) {
        const v = s.map.victory, area = v.escape?.find(a => a.team === team && a.ships === isShip(u));
        if (area && inClassicalArea(u, area)) break;
        const goals = [];
        if (area) for (let r=area.rMin;r<=area.rMax;r++) for (let c=area.cMin;c<=area.cMax;c++)
          if (!mobileAt(s.map,c,r)) goals.push({c,r});
        if (!isShip(u) && v.capture?.team === team) goals.push(v.capture);
        goals.sort((a,b)=>distance(u,a)-distance(u,b));
        if (goals[0] && march(u,goals[0])) continue;
      }
      // The exposed Athenian ships win by leaving the anchorage. Keep a course
      // for the western exit unless an enemy is already in striking range.
      if (s.map.scenarioId === 'aegospotami' && team === 'coalition' &&
          u.c > s.map.victory.escape.cMax &&
          !enemies.some(e => attackPreview(s, u, e.c, e.r)) &&
          march(u, { c: 12, r: Math.max(12, Math.min(34, u.r)) })) continue;
      if(s.rulesVersion>=22){const decision=phalanxTacticalAction(s,u);if(decision){let result;if(decision.type==='move'){const from={c:u.c,r:u.r};result=move(s,u.id,decision.to.c,decision.to.r);if(result.ok)actions.push({type:'move',id:u.id,from,to:{...decision.to,path:result.path},formationReason:decision.reason});}else {result=decision.type==='turn'?turnPhalanx(s,u.id,decision.facing):setPhalanxMode(s,u.id,decision.type==='form',decision.facing);if(result.ok)actions.push({type:decision.type==='turn'?'phalanxTurn':'phalanxMode',id:u.id,formed:u.formed,facing:u.facing,formationReason:decision.reason});}if(result?.ok)continue;}}
      if (s.rulesVersion<22 && isFormableInfantry(u) && u.movesUsed === 0) {
        const nearest = enemies.filter(e => e.kind !== 'fort' && !isShip(e))
          .sort((a, b) => distance(u, a) - distance(u, b))[0];
        if (nearest && u.formed && distance(u, nearest) >= 4) {
          const result = setPhalanxMode(s, u.id, false);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: false }); continue; }
        }
        if (nearest && !u.formed && distance(u, nearest) <= 2 &&
            !fortAt(s.map, u.c, u.r) && !houseAt(s.map, u.c, u.r)) {
          const facing = directionToward(u, nearest);
          const result = setPhalanxMode(s, u.id, true, facing);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: true, facing }); continue; }
        }
        if (nearest && u.formed && distance(u, nearest) === 1 &&
            !formationFaces(s,u,nearest) &&
            !enemies.some(e => e.kind !== 'fort' && attackPreview(s, u, e.c, e.r))) {
          const facing = adjacentDirection(u, nearest);
          const result = turnPhalanx(s, u.id, facing);
          if (result.ok) { actions.push({ type: 'phalanxTurn', id: u.id, facing }); continue; }
        }
      }
      if (s.map.scenarioId === 'jerusalem' && team === 'egypt' &&
          !commandKinds.has(u.kind) && u.kind !== 'engineer' &&
          !enemies.some(e => e.kind !== 'fort' && attackPreview(s,u,e.c,e.r))) {
        const stage = s.map.victory.stages[s.jerusalemStage];
        const wallId = stage?.walls.find(id => !s.map.units.some(x =>
          x.kind === 'fort' && x.cityId === id && x.hp <= 0));
        if (!wallId && stage && march(u,stage)) continue;
        const wall = wallId && s.map.units.filter(x => x.kind === 'fort' && x.cityId === wallId && x.hp > 0)
          .sort((a,b) => Math.abs(a.c-stage.c) - Math.abs(b.c-stage.c) || distance(u,a)-distance(u,b))[0];
        if (wall) {
          const preview = attackPreview(s,u,wall.c,wall.r);
          if (preview) {
            actions.push({ type: 'attack', id:u.id, c:wall.c, r:wall.r,
              result:attack(s,u.id,wall.c,wall.r,rng()) });
            continue;
          }
          if (march(u,{c:wall.c,r:Math.max(0,wall.r-1)})) continue;
        }
      }
      if (s.map.scenarioId === 'syracuse' && team === 'coalition' &&
          !enemies.some(e => e.kind !== 'fort' && distance(u,e) <= 4)) break;
      if (s.map.scenarioId === 'jerusalem' && team === 'coalition' &&
          !enemies.some(e => e.kind !== 'fort' && distance(u,e) <= 4)) break;
      if (s.map.scenarioId === 'teutoburg' && team === 'egypt' &&
          (u.kind === 'scipio' || !enemies.some(e => distance(u, e) <= 2)) &&
          march(u, { c: 8, r: 24 })) continue;
      if (s.map.scenarioId === 'actium' && team === 'coalition' &&
          (u.kind === 'cleopatraGalley' || u.commander === '安东尼') &&
          !enemies.some(e => distance(u, e) <= 2) && march(u, { c: 10, r: 24 })) continue;
      if (s.map.scenarioId === 'carthage' && team === 'egypt' &&
          !commandKinds.has(u.kind) && !isShip(u) && u.kind !== 'siegeRam' &&
          !enemies.some(e => e.kind !== 'fort' && attackPreview(s, u, e.c, e.r)) &&
          march(u, s.carthageHarborTaken ? s.map.victory.byrsa : s.map.victory.harbor)) continue;
      if (s.rulesVersion<22 && s.map.scenarioId === 'zama' && team === 'egypt' && isRomanLine(u) && enemies.length) {
        const nearest = [...enemies].sort((a, b) => distance(u, a) - distance(u, b))[0];
        if (u.formed && distance(u, nearest) >= 4 && u.movesUsed === 0) {
          const result = setPhalanxMode(s, u.id, false);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: false }); continue; }
        }
        if (!u.formed && distance(u, nearest) <= 2 && u.movesUsed === 0) {
          const facing = directionToward(u, nearest);
          const result = setPhalanxMode(s, u.id, true, facing);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: true, facing }); continue; }
        }
        if (u.formed && distance(u, nearest) === 1 &&
            !formationFaces(s,u,nearest)) {
          const facing = adjacentDirection(u, nearest);
          const result = turnPhalanx(s, u.id, facing);
          if (result.ok) { actions.push({ type: 'phalanxTurn', id: u.id, facing }); continue; }
        }
      }
      if (s.map.scenarioId === 'zama' && team === 'coalition' && u.kind === 'zamaVeteran' &&
          enemies.every(e => distance(u, e) > 4) &&
          s.map.units.some(x => x.team === 'coalition' && x.hp > 0 &&
            ['gaulInfantry', 'iberianInfantry', 'africanInfantry'].includes(x.kind))) break;
      if (s.map.scenarioId === 'cannae' && team === 'coalition' && u.kind === 'punicSkirmisher' &&
          s.map.units.some(ally => ally.team === team && ally.hp > 0 && PUNIC_CENTER.has(ally.kind) &&
            distance(u, ally) <= 5) &&
          !enemies.some(foe => attackPreview(s, u, foe.c, foe.r))) break;
      if (s.map.scenarioId === 'cannae' && team === 'coalition' && PUNIC_CENTER.has(u.kind) &&
          u.r < 40 && u.lastWithdrawalTurn !== s.turn &&
          enemies.some(e => e.kind !== 'fort' && distance(u, e) <= 3)) {
        const result = withdrawCenter(s, u.id);
        if (result.ok) { actions.push({ type: 'withdrawCenter', id: u.id, from: result.from, to: result.to }); break; }
      }
      if (s.map.scenarioId === 'cannae' && team === 'coalition' && u.kind === 'africanInfantry' && u.r > 29) {
        const goal = { c: u.c < 40 ? 27 : 51, r: 28 };
        if (march(u, goal)) continue;
      }
      if (s.rulesVersion<22 && s.map.scenarioId === 'cannae' && isRomanLine(u) && u.actionsLeft > 1) {
        const adjacentFoe = enemies.find(e => e.kind !== 'fort' && distance(u, e) === 1 &&
          !formationFaces(s,u,e));
        if (adjacentFoe) {
          const result = turnRomanLine(s, u.id, adjacentDirection(u, adjacentFoe));
          if (result.ok) { actions.push({ type: 'romanTurn', id: u.id, facing: u.facing }); continue; }
        }
      }
      if (s.rulesVersion<22 && ['gaugamela', 'issus', 'pydna'].includes(s.map.scenarioId) && isPhalangite(u) && enemies.length) {
        const nearest = [...enemies].sort((a, b) => distance(u, a) - distance(u, b))[0];
        if (u.formed && distance(u, nearest) >= 4 && u.movesUsed === 0) {
          const result = setPhalanxMode(s, u.id, false);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: false }); continue; }
        }
        if (!u.formed && distance(u, nearest) <= 2 && u.movesUsed === 0) {
          const result = setPhalanxMode(s, u.id, true);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: true }); continue; }
        }
        if (u.formed && distance(u, nearest) === 1 &&
            !formationFaces(s,u,nearest)) {
          const result = turnPhalanx(s, u.id, adjacentDirection(u, nearest));
          if (result.ok) { actions.push({ type: 'phalanxTurn', id: u.id, facing: u.facing }); continue; }
        }
      }
      if (!enemies.length) {
        if (s.map.victory.mode === 'classical') {
          const goal=classicalApproach(s.map,u,team,isShip(u));
          if(goal && march(u,goal))continue;
          break;
        }
        if (s.map.scenarioId === 'mantinea') {
          if (march(u, { c: team === 'egypt' ? 38 : 32,
            r: Math.max(6, Math.min(41, u.r)) })) continue;
          break;
        }
        if (s.map.scenarioId === 'aegospotami') {
          if (team === 'egypt' && march(u, { c: u.c, r: 31 })) continue;
          break;
        }
        if (s.map.victory.mode === 'china') {
          if (explorerIds.has(u.id) && !fortAt(s.map, u.c, u.r) &&
              march(u, scoutGoal(u))) continue;
          const memory = intel.lastSeen?.turn >= s.turn - 8 ? intel.lastSeen :
            intel.scoutTrail?.turn >= s.turn - 8 ? intel.scoutTrail : null;
          const elimination = isChinaEliminationCampaign(s.map);
          const goal = memory || (s.map.scenarioId === 'china_kunyang' && team !== s.map.victory.attacker ?
            KUNYANG_CITY_OBJECTIVE : elimination ? { c: s.map.cols - 3, r: u.r } : s.map.victory.objective);
          if (u.kind !== 'chinaGeneral' &&
              (elimination ? team === s.map.victory.attacker || s.map.scenarioId === 'china_kunyang' || !!memory :
                team === s.map.victory.attacker || distance(u, s.map.victory.objective) > 5) &&
              march(u, goal)) continue;
          break;
        }
        if (s.map.scenarioId === 'alesia') {
          if (team === 'coalition') {
            const target = s.map.units.filter(x => x.team === 'coalition' && x.hp > 0 &&
              x.alesiaOrigin && x.alesiaOrigin !== u.alesiaOrigin)
              .sort((a, b) => distance(u, a) - distance(u, b))[0];
            const goal = target && distance(u, s.map.victory.center) > 8 &&
                distance(u, s.map.victory.center) < 12 ? target : alesiaGoal(u);
            if (goal && u.alesiaOrigin && march(u, goal)) continue;
          }
          break;
        }
        if (s.map.scenarioId === 'zama') {
          if (commandKinds.has(u.kind) || u.kind === 'zamaVeteran' ||
              (team === 'coalition' && u.kind === 'africanInfantry')) break;
          if (team === 'egypt' && isRomanLine(u) && u.formed && !u.movesUsed) {
            const result = setPhalanxMode(s, u.id, false);
            if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: false }); continue; }
          }
          const goal = team === 'egypt' ?
            ['romanHorse', 'masinissaHorse'].includes(u.kind) ? { c: u.c, r: 45 } : { c: u.c, r: 43 } :
            u.kind === 'warElephant' ? { c: u.c, r: 30 } :
              ['numidianHorse', 'zamaPunicHorse'].includes(u.kind) ? { c: u.c, r: 26 } : { c: u.c, r: 30 };
          if (march(u, goal)) continue;
          break;
        }
        if (s.map.scenarioId === 'pharsalus') {
          if (commandKinds.has(u.kind)) break;
          if (u.kind === 'caesarReserve' && !s.map.units.some(x => x.kind === 'pompeyHorse' &&
              x.hp > 0 && distance(u, x) <= 6)) break;
          const goal = u.kind === 'pompeyHorse' ? { c: 35, r: 12 } :
            u.kind === 'caesarReserve' || u.kind === 'romanHorse' ? { c: 51, r: 12 } :
              team === 'egypt' ? { c: 49, r: 29 } : { c: 37, r: 29 };
          if (march(u, goal)) continue;
          break;
        }
        if (s.map.scenarioId === 'syracuse') {
          if (team === 'coalition' || commandKinds.has(u.kind)) break;
          if (isShip(u)) { if (march(u,{c:58,r:u.r})) continue; }
          else if (!['siegeRam','romanOnager'].includes(u.kind) &&
              march(u,s.map.victory.capture)) continue;
          break;
        }
        if (s.map.scenarioId === 'pydna') {
          if (commandKinds.has(u.kind)) break;
          if (march(u,team === 'egypt' ? {c:36,r:22} : {c:27,r:22})) continue;
          break;
        }
        if (s.map.scenarioId === 'cannae') {
          if (commandKinds.has(u.kind) || u.kind === 'africanInfantry' ||
              (team === 'coalition' && (PUNIC_CENTER.has(u.kind) || u.kind === 'punicSkirmisher'))) break;
          const goal = team === 'egypt' ?
            ['romanHorse', 'romanAlliedHorse'].includes(u.kind) ?
              { c: u.c < 40 ? 20 : 59, r: 36 } : { c: u.c < 36 ? 35 : u.c > 43 ? 44 : 40, r: 39 } :
            u.kind === 'punicHeavyHorse' ? { c: 20, r: 27 } :
            u.kind === 'numidianHorse' ? { c: 58, r: 27 } : { c: 40, r: 28 };
          if (march(u, goal)) continue;
          break;
        }
        if (s.map.scenarioId === 'issus' && team === 'egypt' && isPhalangite(u) && u.formed && !u.movesUsed) {
          const result = setPhalanxMode(s, u.id, false);
          if (result.ok) { actions.push({ type: 'phalanxMode', id: u.id, formed: false }); continue; }
        }
        if (s.map.scenarioId === 'gaugamela' && !commandKinds.has(u.kind) &&
            u.kind !== 'warElephant' && march(u, team === 'egypt' ? { c: 54, r: 26 } : { c: 43, r: 26 })) continue;
        if (s.map.scenarioId === 'issus' && team === 'egypt' &&
            march(u, u.kind === 'pharaoh' || u.kind === 'companionCavalry' ? { c: 64, r: 20 } :
              u.kind === 'cavalry' ? { c: 22, r: 20 } : { c: 42, r: 20 })) continue;
        if (s.map.scenarioId === 'issus' && team === 'coalition' && u.scout &&
            march(u, { c: 63, r: 34 })) continue;
        if (s.map.scenarioId === 'issus' && team === 'coalition') break;
        if (s.map.scenarioId === 'salamis' && march(u,
          team === 'coalition' ? { c: 27, r: 23 } : { c: 38, r: 32 })) continue;
        if (s.map.scenarioId === 'actium' && march(u,
          team === 'coalition' ? { c: 31, r: 25 } : { c: 44, r: 25 })) continue;
        if (s.map.scenarioId === 'carrhae') {
          if (team === 'egypt' && march(u,{c:5,r:Math.max(16,Math.min(26,u.r))})) continue;
          if (team === 'coalition' && ['parthianCataphract','parthianHorseArcher'].includes(u.kind) &&
              march(u,{c:27,r:21})) continue;
          break;
        }
        if (s.map.scenarioId === 'teutoburg' && march(u,
          team === 'egypt' ? { c: 8, r: 24 } : { c: Math.max(20, Math.min(53, u.c)), r: 24 })) continue;
        if (s.map.scenarioId === 'tyre') {
          if (team === 'coalition') break;
          if (isShip(u) && march(u, u.r < 19 ? { c: 39, r: 10 } : { c: 42, r: 28 })) continue;
          if (u.kind !== 'pharaoh' && march(u, { c: 34, r: 19 })) continue;
        }
        if (s.map.scenarioId === 'carthage') {
          if (team === 'coalition') break;
          if (isShip(u)) {
            if (march(u, { c: 60, r: 34 })) continue;
          } else if (!commandKinds.has(u.kind) && u.kind !== 'siegeRam' &&
              march(u, s.carthageHarborTaken ? s.map.victory.byrsa : s.map.victory.harbor)) continue;
          break;
        }
        if (s.map.scenarioId === 'babylon') {
          if (team === 'egypt' && u.kind !== 'pharaoh' && march(u, s.map.victory.rescue)) continue;
          if (team === 'coalition' && !u.pursuer && march(u, { c: 55, r: 22 })) continue;
        }
        if (s.map.scenarioId === 'qarqar') {
          const wallsRemain = s.map.units.some(x => x.kind === 'fort' && x.team === 'coalition' && x.hp > 0);
          if (team === 'egypt' && u.kind !== 'pharaoh' && march(u, wallsRemain && u.c > 35 ? { c: 34, r: 18 } : s.map.victory.objective)) continue;
          if (team === 'coalition' && u.kind !== 'hittiteKing' && march(u, s.map.victory.objective)) continue;
        }
        if (s.map.scenarioId === 'troy') {
          if (isShip(u)) {
            if (team === 'egypt' && march(u, { c: 15, r: 18 })) continue;
          } else if (team === 'egypt' && u.kind !== 'pharaoh' && march(u, { c: 42, r: 18 })) continue;
          else if (team === 'coalition' && s.map.recruitment) {
            const muster = s.map.recruitment.muster.coalition.land;
            if (u.c === muster.c && u.r === muster.r && march(u, { c: 40, r: 20 })) continue;
          }
        }
        const king = s.map.units.find(x => x.kind === 'hittiteKing' && x.hp > 0);
        if (team === 'egypt' && u.kind !== 'pharaoh' &&
            s.map.scenarioId === 'megiddo' &&
            march(u, u.c < 30 ? { c: 31, r: 29 } : { c: 63, r: 17 })) continue;
        if (team === 'egypt' && s.map.scenarioId === 'kadesh' &&
            u.kind !== 'pharaoh' && u.kind !== 'guard' &&
            march(u, { c: 31, r: 18 })) continue;
        if (team === 'coalition' && s.map.scenarioId === 'kadesh' && u.kind !== 'hittiteKing' &&
            !(u.kind === 'guard' && king && distance(u, king) <= 2) && !fortAt(s.map, u.c, u.r) &&
            march(u, kadeshGoal(u))) continue;
        if (team === 'coalition' && u.scout) {
          const reach = [...reachable(s, u).values()].sort((a, b) => distance(a, { c: 12, r: 33 }) - distance(b, { c: 12, r: 33 }));
          if (reach.length && distance(reach[0], { c: 12, r: 33 }) < distance(u, { c: 12, r: 33 })) {
            const from = { c: u.c, r: u.r }; move(s, u.id, reach[0].c, reach[0].r);
            actions.push({ type: 'move', id: u.id, from, to: reach[0] });
            continue;
          }
        }
        if (explorerIds.has(u.id) && !fortAt(s.map, u.c, u.r) &&
            march(u, scoutGoal(u))) continue;
        const memory = intel.lastSeen?.turn >= s.turn - 8 ? intel.lastSeen :
          intel.scoutTrail?.turn >= s.turn - 8 ? intel.scoutTrail : null;
        if (memory && !isCommander(u) && march(u, memory)) continue;
        break;
      }
      const enemyLeader = opponent === 'egypt' ? 'pharaoh' :
        ['leader_duel', 'gaugamela', 'issus'].includes(s.map.victory.mode) ? 'hittiteKing' : null;
      const priority = e => (e.kind === enemyLeader ? -6 : e.kind === 'fort' ? 4 : 0) + distance(u, e);
      enemies.sort((a, b) => priority(a) - priority(b));
      const options = enemies.map(e => ({ e, p: attackPreview(s, u, e.c, e.r) })).filter(x => x.p);
      if (options.length) {
        const attackScore = ({e,p}) => {
          const siege = siegeKinds.has(u.kind) && e.kind === 'fort' ? 20 : 0;
          const counter = !isShip(u) && !siegeKinds.has(u.kind) &&
            ['cavalry', 'companionCavalry', 'punicHeavyHorse', 'pompeyHorse', 'romanHorse',
              'romanAlliedHorse', 'parthianCataphract'].includes(u.kind) &&
            unitStats(s.map, e).ranged > 0 && unitStats(s.map, e).armor <= 1 ? 3 : 0;
          return (difficulty === 'hard' ?
            p.damage * p.hit / 100 + (p.damage >= e.hp ? 18 : 0) +
            (e.kind === enemyLeader ? 14 : 0) +
            (e.kind !== 'fort' && unitStats(s.map, e).ranged > 0 ? 2 : 0) + siege + counter :
            (e.kind === enemyLeader ? 5 : 0) + p.damage / 10 + siege + counter) +
            (policyScore?.(s, u, { type: 'attack', target: e, preview: p }) || 0);
        };
        const soldiers = options.filter(x => x.e.kind !== 'fort');
        const choices = soldiers.length && !siegeKinds.has(u.kind) ? soldiers : options;
        choices.sort((a, b) => attackScore(b) - attackScore(a));
        const best = choices[0];
        actions.push({ type: 'attack', id: u.id, c: best.e.c, r: best.e.r, result: attack(s, u.id, best.e.c, best.e.r, rng(), ...(s.rulesVersion>=17?[rng(),rng(),rng()]:[])) });
        continue;
      }
      if (s.map.scenarioId === 'issus' && team === 'coalition' && u.r < 24 &&
          enemies.every(e => e.r >= 24)) break;
      if (s.map.scenarioId === 'babylon' && team === 'egypt' && u.kind !== 'pharaoh' &&
          march(u, s.map.victory.rescue)) continue;
      const ownLeaderKind = team === 'egypt' ? 'pharaoh' : 'hittiteKing';
      const king = s.map.units.find(x => x.team === team && x.kind === ownLeaderKind && x.hp > 0);
      if (commandKinds.has(u.kind) || ((s.map.scenarioId === 'kadesh' || s.map.scenarioId === 'troy') && u.kind === 'guard' && king && distance(u, king) <= 2) ||
          fortAt(s.map, u.c, u.r)) break;
      // The camp is known, but unseen Egyptian pieces stay hidden. East-bank reserves follow mapped fords.
      if (team === 'coalition' && s.map.scenarioId === 'kadesh' && u.c >= 36 && enemies.every(e => e.c < 36) &&
          march(u, kadeshGoal(u))) continue;
      const chargeOption=chargeOpportunities(s,u,enemies).find(o=>!exposedCrossing(o.destination)&&keepsCohesion(u,o.destination));
      if(chargeOption){const from={c:u.c,r:u.r},to=chargeOption.destination,result=move(s,u.id,to.c,to.r);if(result.ok){actions.push({type:'move',id:u.id,from,to:{...to,path:result.path}});continue;}}
      const reach = [...reachable(s, u).values()].filter(p =>
        !exposedCrossing(p) && keepsCohesion(u, p));
      const nearest = p => Math.min(...enemies.map(e => {
        const d = distance(p, e);
        const cavalry = ['cavalry', 'companionCavalry', 'punicHeavyHorse', 'pompeyHorse',
          'romanHorse', 'romanAlliedHorse', 'parthianCataphract'].includes(u.kind);
        const softRanged = cavalry && unitStats(s.map, e).ranged > 0 && unitStats(s.map, e).armor <= 1;
        const frontOfPikes = cavalry && isPhalangite(e) && e.formed &&
          formationFaces(s,e,p);
        const wallBias = e.kind === 'fort' ? siegeKinds.has(u.kind) ? -0.5 : 1 : 0;
        return d + wallBias + (e.kind === enemyLeader ? -2 : 0) -
          (softRanged ? 0.5 : 0) + (frontOfPikes ? 0.75 : 0);
      }));
      const approachScore = p => {
        const neighborsFormed=s.rulesVersion>=22&&effectiveFormation(u)?s.map.units.filter(a=>a.id!==u.id&&a.team===u.team&&effectiveFormation(a)):[];
        const cohesive=neighborsFormed.some(a=>distance(p,a)===1),rearThreat=s.rulesVersion>=22&&effectiveFormation(u)&&enemies.some(e=>distance(p,e)<=2&&!formationFaces(s,{...u,c:p.c,r:p.r},e));
        const base = nearest(p)+(neighborsFormed.length&&!cohesive?1.25:0)+(rearThreat?1:0);
        const roadBias = !isShip(u) && (tile(s.map, p.c, p.r).terrain & TERRAIN.ROAD) ? 0.35 : 0;
        if (difficulty !== 'hard') return base - roadBias;
        const stat = unitStats(s.map, u), canStrike = u.actionsLeft >= 2 && enemies.some(e => {
          const d = distance(p,e);
          return d === 1 && stat.melee > 0 &&
            (!isFormableInfantry(u) || !u.formed || formationFaces(s,{...u,c:p.c,r:p.r},e)) ||
            d >= (u.kind === 'romanOnager' ? 2 : 1) &&
            d <= stat.range && stat.ranged > 0 && u.ammo > 0 &&
            (d > 1 || !isFormableInfantry(u) || !u.formed);
        });
        return base - (canStrike ? 3 : 0) - terrainValue(u, p) * 0.12 - roadBias -
          (policyScore?.(s, u, { type: 'move', to: p }) || 0);
      };
      reach.sort((a, b) => approachScore(a) - approachScore(b) ||
        terrainValue(u, b) - terrainValue(u, a));
      if (!reach.length || Math.min(...enemies.map(e => distance(reach[0], e))) >= Math.min(...enemies.map(e => distance(u, e)))) break;
      const from = { c: u.c, r: u.r }, best = reach[0];
      move(s, u.id, best.c, best.r); actions.push({ type: 'move', id: u.id, from, to: best });
    }
  }
  if (!s.over && s.map.logistics && !logisticsRouteCut(s, team)) {
    const wagons = s.map.units.filter(u => u.team === team && u.kind === 'supplyWagon' && u.hp > 0);
    const troops = s.map.units.filter(u => u.team === team && logisticsSoldier(u) && !isRouted(u));
    const needWagons = Math.min(8, Math.max(1, Math.ceil(troops.length / 18)));
    const shortage = troops.filter(u => (u.fedTurns || 0) <= 1 || (u.hunger || 0) > 0).length;
    const needSupply = wagons.length < needWagons &&
      (shortage >= 3 || wagons.length === 0);
    if (needSupply && s.money[team] >= LOGISTICS_COSTS.supplyWagon) {
      const result = recruitLogistics(s, 'supplyWagon');
      if (result.ok) actions.push({ type: 'recruit', id: result.unit.id, kind: 'supplyWagon' });
    } else if (s.turn % 3 === 0 && s.money[team] > 80) {
      const kind = s.turn % 2 ? 'cavalry' : 'heavy';
      const result = recruitLogistics(s, kind);
      if (result.ok) actions.push({ type: 'recruit', id: result.unit.id, kind });
    }
  }
  if (!s.over && s.map.recruitment) {
    if (team === 'egypt') {
      if (s.turn >= 30 && !s.trojanHorsePurchased) {
        if (s.turn >= s.map.victory.horseUnlockTurn) {
          const result = recruit(s, 'trojanHorse');
          if (result.ok) actions.push({ type: 'recruit', id: result.unit.id, kind: 'trojanHorse' });
        }
      } else {
        const at = s.map.recruitment.muster.egypt.sea;
        if (!mobileAt(s.map, at.c, at.r)) {
          const result = recruit(s, 'transport');
          if (result.ok) actions.push({ type: 'recruit', id: result.unit.id, kind: 'transport' });
        }
        const ship = mobileAt(s.map, at.c, at.r);
        if (ship?.kind === 'transport' && ship.team === team) {
          for (const kind of ['heavy', 'light']) {
            const result = recruit(s, kind);
            if (result.ok) actions.push({ type: 'recruit', id: result.unit.id, kind });
          }
        }
      }
    } else {
      const at = s.map.recruitment.muster.coalition.land;
      if (!mobileAt(s.map, at.c, at.r)) {
        const preference = s.turn % 3 === 0 ? ['archer', 'heavy', 'light'] : ['heavy', 'light'];
        for (const kind of preference) {
          const result = recruit(s, kind);
          if (result.ok) { actions.push({ type: 'recruit', id: result.unit.id, kind }); break; }
        }
      }
    }
  }
  if (!s.over) endSide(s, rng);
  return actions;
}

// Playable, not georeferenced: Aruna corridor, Qina brook south of Megiddo,
// city on the north bank, and the Taanach approach follow the ancient account.
export function megiddoMap() {
  const m = newMap(80, 48);
  m.scenarioId = 'megiddo';
  m.name = '美吉多 · 阿鲁纳山口';
  m.factions = { egypt: '埃及', coalition: '迦南联军' };
  m.intro = '请在西侧部署区调整埃及军队，然后进军阿鲁纳山口。';
  m.deployment = { team: 'egypt', cMin: 1, cMax: 15, rMin: 25, rMax: 43 };
  m.landmarks = [
    { c: 20, r: 29, label: '阿鲁纳山口' }, { c: 49, r: 32, label: '基纳溪 Qina' },
    { c: 63, r: 17, label: '美吉多' }, { c: 54, r: 43, label: '塔纳赫方向' },
  ];
  const noise = (c, r) => Math.sin(c * 1.73 + r * 0.91) * 0.6 + Math.sin(c * 0.53 - r * 1.43) * 0.5;
  for (let r = 2; r < 46; r++) for (let c = 0; c < 44; c++) {
    const pass = 35 - c * 0.24 + 0.9 * Math.sin(c * 0.19);
    const d = Math.abs(r - pass);
    const north = r < pass && d < 9 + 1.5 * Math.sin(c * 0.13);
    const south = r > pass && d < 7 + 1.2 * Math.sin(c * 0.17);
    if ((north || south) && d > 1.4 + noise(c, r) * 0.35) m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
  }
  // Southern ridge and low hills west of the city.
  for (let r = 31; r < 47; r++) for (let c = 23; c < 55; c++) {
    const e = ((c - 38) / 18) ** 2 + ((r - 46) / 14) ** 2;
    if (e < 1 + noise(c, r) * 0.07 && r > 36) m.terrain[index(m, c, r)] |= TERRAIN.MOUNTAIN;
  }
  // Qina brook: south of the tell, flowing across the valley. Roads form two fords.
  for (let c = 36; c <= 79; c++) {
    const r = Math.round(31 + 2.2 * Math.sin((c - 35) * 0.15) + (c - 35) * 0.015);
    setTerrain(m, c, r, TERRAIN.RIVER);
    if (c % 5 !== 0) setTerrain(m, c, r + 1, TERRAIN.RIVER);
  }
  drawRoad(m, Array.from({ length: 47 }, (_, i) => ({ c: i + 1,
    r: Math.round(35 - (i + 1) * 0.24 + 0.9 * Math.sin((i + 1) * 0.19)) })));
  drawRoad(m, Array.from({ length: 17 }, (_, i) => ({ c: i + 46, r: Math.round(30 - i * 0.68) })));
  // Southern Taanach route, shown as a broad approach rather than a second river.
  drawRoad(m, Array.from({ length: 32 }, (_, i) => ({ c: i + 35, r: Math.round(43 - i * 0.2) })));
  // Join the mountain route, city approach, and southern route through two named fords.
  for (let r = 24; r <= 42; r++) m.terrain[index(m, 47, r)] |= TERRAIN.ROAD;
  for (let r = 23; r <= 39; r++) m.terrain[index(m, 56, r)] |= TERRAIN.ROAD;
  drawRoad(m, [{ c: 47, r: 29 }, { c: 46, r: 30 }]);
  // One ring surrounds open ground. Each breached segment opens only its own cell.
  const wall = [[62, 15, 2], [63, 15, 2], [64, 15, 3], [62, 16, 2],
    [65, 16, 2], [61, 17, 2], [65, 17, 2], [62, 18, 2],
    [65, 18, 2], [62, 19, 1], [63, 19, 2], [64, 19, 2]];
  for (const [c, r, level] of wall) setFort(m, c, r, level, 'coalition', '美吉多');
  setSupplyPoint(m, 63, 17, 'coalition', '美吉多');
  const egypt = [
    ['pharaoh', 3, 35], ['guard', 3, 34], ['guard', 4, 35],
    ['heavy', 5, 34], ['heavy', 5, 36], ['heavy', 7, 34], ['heavy', 7, 36],
    ['light', 9, 32], ['light', 9, 37], ['light', 11, 34],
    ['archer', 5, 32], ['archer', 5, 38], ['archer', 9, 35],
    ['chariot', 2, 36], ['chariot', 8, 35], ['chariot', 12, 34],
  ];
  const coalition = [
    ['light', 26, 26, true], ['light', 33, 31, true],
    ['heavy', 52, 25], ['heavy', 55, 23], ['heavy', 59, 21], ['heavy', 61, 17],
    ['light', 49, 24], ['light', 53, 28], ['light', 58, 26], ['light', 64, 18],
    ['light', 57, 20], ['light', 60, 24],
    ['archer', 55, 20], ['archer', 58, 18], ['archer', 63, 16], ['archer', 65, 17],
    ['archer', 61, 24], ['archer', 62, 19],
    ['chariot', 51, 19], ['chariot', 57, 29],
  ];
  for (const [kind, pc, pr] of egypt) {
    const candidates = [];
    for (let r = m.deployment.rMin; r <= m.deployment.rMax; r++)
      for (let c = m.deployment.cMin; c <= m.deployment.cMax; c++) candidates.push({ c, r });
    candidates.sort((a, b) => distance(a, { c: pc, r: pr }) - distance(b, { c: pc, r: pr }));
    if (!candidates.some(p => !mobileAt(m, p.c, p.r) && addUnit(m, kind, 'egypt', p.c, p.r))) throw new Error(`埃及部署失败 ${kind}`);
  }
  for (const [kind, c, r, scout] of coalition) {
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`联军部署失败 ${kind} ${c},${r}`);
    if (scout) mobileAt(m, c, r).scout = true;
  }
  validateMap(m); return m;
}

// Tactical reconstruction of the crisis at Ramesses II's Amun camp, not a surveyed map.
// The king's later counterattack and the capture of Muwatalli are player alternatives.
export function kadeshMap() {
  const m = newMap(64, 40);
  m.scenarioId = 'kadesh';
  m.name = '卡迭石会战 · 奥龙特河';
  m.factions = { egypt: '埃及', coalition: '赫梯联军' };
  m.victory = { mode: 'leader_duel', leaders: { egypt: 'pharaoh', coalition: 'hittiteKing' } };
  m.intro = '拉神军团遭袭后，赫梯战车追入阿蒙军团营地；双方后队将分批投入。守住拉美西斯二世，击杀对方君主获胜。';
  m.landmarks = [
    { c: 22, r: 12, label: '阿蒙军团营地' },
    { c: 28, r: 25, label: '拉神军团受袭方向' },
    { c: 39, r: 18, label: '奥龙特河' },
    { c: 46, r: 15, label: '卡迭石城' },
    { c: 55, r: 17, label: '赫梯主力指挥区' },
    { c: 13, r: 15, label: '尼亚林援兵方向' },
    { c: 29, r: 35, label: '卜塔军团行军方向' },
  ];
  // The river runs north-south west of Kadesh; only roads mark playable crossings.
  for (let r = 0; r < m.rows; r++) {
    const riverC = Math.round(38 + 1.6 * Math.sin(r * 0.17) + (r > 26 ? (r - 26) * 0.08 : 0));
    setTerrain(m, riverC, r, TERRAIN.RIVER);
    setTerrain(m, riverC + 1, r, TERRAIN.RIVER);
  }
  drawRoad(m, Array.from({ length: 33 }, (_, i) => ({ c: i + 6, r: Math.round(12 + i * 0.23) })));
  drawRoad(m, Array.from({ length: 20 }, (_, i) => ({ c: Math.round(30 + 0.18 * (19 - i)), r: i + 17 })));
  drawRoad(m, Array.from({ length: 20 }, (_, i) => ({ c: i + 30, r: 28 })));
  drawRoad(m, Array.from({ length: 20 }, (_, i) => ({ c: i + 35, r: 18 })));
  drawRoad(m, Array.from({ length: 11 }, (_, i) => ({ c: 40, r: i + 18 })));
  drawRoad(m, [{ c: 33, r: 18 }, { c: 35, r: 18 }]);
  // The city's west and north approaches are partly confined by low ground.
  for (let r = 2; r <= 8; r++) for (let c = 43; c <= 57; c++)
    if ((c - 50) ** 2 / 95 + (r - 3) ** 2 / 32 < 1 && (c + r) % 5 !== 0) setTerrain(m, c, r, TERRAIN.MOUNTAIN);
  for (let r = 30; r <= 38; r++) for (let c = 45; c <= 59; c++)
    if ((c - 52) ** 2 / 110 + (r - 38) ** 2 / 55 < 1 && (c + r) % 6 !== 0) setTerrain(m, c, r, TERRAIN.MOUNTAIN);
  // A complete six-sided ring. The former hand-drawn outline split into four
  // disconnected groups on the offset hex grid, leaving unintended gaps.
  for (let r = 12; r <= 18; r++) for (let c = 43; c <= 49; c++) {
    if (distance({ c, r }, { c: 46, r: 15 }) !== 3) continue;
    if (!setFort(m, c, r, c === 46 && r === 12 ? 3 : 2, 'coalition', '卡迭石'))
      throw new Error('卡迭石城墙布设失败');
  }
  setSupplyPoint(m, 46, 15, 'coalition', '卡迭石');
  const egypt = [
    ['pharaoh',22,13], ['guard',21,13], ['guard',23,13],
    ['chariot',20,15], ['chariot',24,15], ['chariot',19,11],
    ['archer',19,13], ['archer',22,10], ['light',18,15], ['light',24,11],
    ['heavy',21,16], ['heavy',25,17], ['light',29,25],
  ];
  const hittite = [
    ['hittiteKing',55,17], ['guard',54,17], ['guard',55,16], ['guard',56,18],
    ['hittiteChariot',27,12], ['hittiteChariot',29,15], ['hittiteChariot',25,19],
    ['hittiteChariot',18,19], ['hittiteChariot',31,20], ['hittiteChariot',33,23],
    ['hittiteChariot',32,13], ['hittiteChariot',30,22], ['light',28,18], ['heavy',34,22],
    ['light',45,15], ['heavy',46,14], ['heavy',47,16], ['archer',47,14],
    ['heavy',51,18], ['heavy',53,20], ['archer',51,16], ['light',52,22],
  ];
  for (const [kind, c, r] of egypt) if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`埃及部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of hittite) if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`赫梯部署失败 ${kind} ${c},${r}`);
  m.reinforcements = [
    { turn: 3, team: 'egypt', label: '尼亚林部队从西方抵达', units: [
      { kind: 'light', c: 10, r: 14 }, { kind: 'heavy', c: 10, r: 16 },
      { kind: 'archer', c: 11, r: 13 }, { kind: 'chariot', c: 12, r: 15 },
      { kind: 'light', c: 9, r: 17 }, { kind: 'heavy', c: 12, r: 18 },
      { kind: 'chariot', c: 13, r: 12 },
    ] },
    { turn: 3, team: 'coalition', label: '赫梯第二波战车与步兵从东岸投入', units: [
      { kind: 'hittiteChariot', c: 42, r: 18 }, { kind: 'hittiteChariot', c: 43, r: 19 },
      { kind: 'heavy', c: 44, r: 20 }, { kind: 'light', c: 41, r: 21 },
    ] },
    { turn: 4, team: 'coalition', label: '赫梯步兵预备队抵达东岸', units: [
      { kind: 'heavy', c: 42, r: 25 }, { kind: 'heavy', c: 43, r: 26 },
      { kind: 'archer', c: 44, r: 26 }, { kind: 'light', c: 45, r: 25 },
    ] },
    { turn: 5, team: 'egypt', label: '卜塔军团从南方赶到', units: [
      { kind: 'heavy', c: 28, r: 36 }, { kind: 'heavy', c: 30, r: 36 },
      { kind: 'light', c: 27, r: 34 }, { kind: 'archer', c: 29, r: 34 },
      { kind: 'chariot', c: 31, r: 35 },
      { kind: 'heavy', c: 26, r: 36 }, { kind: 'archer', c: 32, r: 36 },
      { kind: 'light', c: 25, r: 33 },
    ] },
    { turn: 5, team: 'coalition', label: '赫梯南翼后队抵达东岸', units: [
      { kind: 'hittiteChariot', c: 42, r: 27 }, { kind: 'heavy', c: 43, r: 28 },
      { kind: 'archer', c: 44, r: 29 }, { kind: 'light', c: 45, r: 29 },
    ] },
    { turn: 6, team: 'egypt', label: '卜塔军团后队抵达', units: [
      { kind: 'heavy', c: 24, r: 36 }, { kind: 'heavy', c: 26, r: 38 },
      { kind: 'light', c: 28, r: 38 }, { kind: 'archer', c: 29, r: 37 },
      { kind: 'chariot', c: 31, r: 37 }, { kind: 'guard', c: 30, r: 38 },
    ] },
  ];
  validateMap(m);
  return m;
}

// Campaign-style reconstruction: the Kurkh inscription places Qarqar's destruction
// before its account of the coalition battle. The exact battlefield deployment is unknown.
export function qarqarMap() {
  const m = newMap(72, 46);
  m.scenarioId = 'qarqar';
  m.name = '卡尔卡尔之战 · 亚述西征';
  m.factions = { egypt: '亚述军', coalition: '诸王联军' };
  m.unitNames = { ...QARQAR_UNIT_NAMES };
  m.victory = { mode: 'qarqar', objective: { c: 25, r: 36 }, turnLimit: 20, holdTurns: 2 };
  m.intro = '前853年奥龙特斯河谷。先攻卡尔卡尔城，继而与诸王联军野战。攻城槌车参与此处围城是依据同期亚述战法作出的剧本推演。亚述军连续两回合控制南向道路获胜；联军守至第20回合获胜。';
  m.landmarks = [
    { c: 10, r: 22, label: '奥龙特斯河（示意）' },
    { c: 31, r: 18, label: '卡尔卡尔城' },
    { c: 25, r: 36, label: '通往哈马的道路' },
    { c: 55, r: 18, label: '亚述进军方向' },
    { c: 20, r: 37, label: '诸王联军集结方向' },
  ];
  for (let r = 0; r < m.rows; r++) {
    const riverC = 10 + Math.round(1.5 * Math.sin(r * 0.17));
    setTerrain(m, riverC, r, TERRAIN.RIVER);
    if (r % 5 !== 0) setTerrain(m, riverC + 1, r, TERRAIN.RIVER);
    for (let c = 0; c < m.cols; c++)
      if ((r < 5 && c > 15 && c < 47 && Math.sin(c * .43 + r) > -.25) ||
          (r > 41 && c > 39 && Math.sin(c * .37 + r) > .2))
        m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
  }
  drawRoad(m, [{ c: 61, r: 18 }, { c: 42, r: 18 }, { c: 31, r: 18 },
    { c: 28, r: 26 }, { c: 25, r: 36 }, { c: 21, r: 40 }]);
  drawRoad(m, [{ c: 31, r: 18 }, { c: 35, r: 28 }, { c: 25, r: 36 }]);
  for (let r = 16; r <= 20; r++) for (let c = 29; c <= 33; c++)
    if (distance({ c, r }, { c: 31, r: 18 }) === 2 &&
        !setFort(m, c, r, c === 33 && r === 18 ? 1 : 2, 'coalition', '卡尔卡尔'))
      throw new Error('卡尔卡尔城墙布设失败');
  if (!setSupplyPoint(m, 31, 18, 'coalition', '卡尔卡尔')) throw new Error('卡尔卡尔补给点布设失败');
  const assyria = [
    ['pharaoh',52,18],['guard',51,17],['guard',51,19],
    ['heavy',48,16],['heavy',48,18],['heavy',48,20],['heavy',45,17],['heavy',45,21],['heavy',43,15],['heavy',43,22],
    ['light',50,22],['light',49,23],['light',46,13],['light',44,24],['light',42,20],['light',42,15],['light',41,18],
    ['archer',52,15],['archer',52,21],['archer',47,14],['archer',47,22],['archer',43,19],['archer',40,21],
    ['chariot',56,14],['chariot',56,18],['chariot',56,22],['chariot',53,25],['chariot',54,11],['chariot',50,26],
    ['cavalry',58,16],['cavalry',58,20],['cavalry',55,24],['cavalry',54,13],['cavalry',50,12],
    ['siegeRam',40,17],['siegeRam',40,19],
  ];
  const coalition = [
    ['hittiteKing',31,18],['guard',30,18],['guard',32,18],['archer',33,18],['archer',30,16],
    ['heavy',32,20],['light',29,18],['heavy',28,27],['heavy',30,29],
    ['light',26,30],['light',31,31],['archer',24,31],['chariot',28,33],
  ];
  for (const [kind,c,r] of assyria) if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`亚述部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of coalition) if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`联军部署失败 ${kind} ${c},${r}`);
  m.reinforcements = [
    { turn: 4, team: 'coalition', label: '诸王联军主力到达', units: [
      { kind:'heavy',c:20,r:32 },{ kind:'heavy',c:21,r:34 },{ kind:'heavy',c:19,r:35 },
      { kind:'light',c:22,r:33 },{ kind:'light',c:20,r:37 },{ kind:'archer',c:18,r:33 },
      { kind:'archer',c:22,r:37 },{ kind:'chariot',c:23,r:34 },{ kind:'chariot',c:22,r:39 },
      { kind:'chariot',c:18,r:38 },{ kind:'cavalry',c:24,r:39 },
    ] },
    { turn: 5, team: 'coalition', label: '大马士革与以色列分队增援', units: [
      { kind:'heavy',c:19,r:40 },{ kind:'heavy',c:23,r:41 },{ kind:'light',c:16,r:35 },
      { kind:'light',c:18,r:41 },{ kind:'archer',c:16,r:39 },{ kind:'archer',c:22,r:43 },
      { kind:'chariot',c:24,r:43 },{ kind:'chariot',c:17,r:43 },{ kind:'chariot',c:25,r:42 },
      { kind:'cavalry',c:21,r:42 },
    ] },
  ];
  validateMap(m); return m;
}

// Alternate-history rescue at the fall of Babylon. The documented entry of
// Cyrus's army was peaceful; the refuge and assault are explicit game fiction.
export function babylonMap() {
  const m = newMap(104, 72);
  m.scenarioId = 'babylon';
  m.name = '巴比伦陷落 · 解救流亡者';
  m.factions = { egypt: '波斯军', coalition: '巴比伦守军' };
  m.unitNames = { ...BABYLON_UNIT_NAMES };
  m.victory = { mode: 'babylon', rescue: { c: 64, r: 41 },
    outer: { cMin: 34, rMin: 14, cMax: 77, rMax: 55 } };
  m.intro = '前539年巴比伦陷落的架空救援线。史料记载波斯军入城未发生城内战斗；围院与解救冲突属于游戏创作。居鲁士或犹大流亡者阵亡则巴比伦胜利。';
  m.garden = { cMin: 65, rMin: 25, cMax: 72, rMax: 30 };
  m.landmarks = [
    { c: 18, r: 35, label: '居鲁士营地' }, { c: 34, r: 35, label: '巴比伦西门' },
    { c: 52, r: 35, label: '幼发拉底河石桥' }, { c: 47, r: 14, label: '伊什塔尔门方向' },
    { c: 85, r: 36, label: '波斯东岸攻城营地' },
    { c: 58, r: 34, label: '游行大道' }, { c: 68, r: 27, label: '传说中的空中花园' },
    { c: 64, r: 41, label: '犹大流亡者围院' }, { c: 69, r: 23, label: '王宫区' },
  ];
  for (let r = 0; r < m.rows; r++) for (const c of [52, 53]) setTerrain(m, c, r, TERRAIN.RIVER);
  drawRoad(m, [{ c: 13, r: 35 }, { c: 34, r: 35 }, { c: 43, r: 35 },
    { c: 52, r: 35 }, { c: 55, r: 35 }, { c: 61, r: 41 }, { c: 64, r: 41 }]);
  drawRoad(m, [{ c: 47, r: 3 }, { c: 47, r: 14 }, { c: 47, r: 20 },
    { c: 51, r: 32 }, { c: 52, r: 35 }]);
  drawRoad(m, [{ c: 55, r: 35 }, { c: 60, r: 33 }, { c: 75, r: 34 }, { c: 89, r: 35 }]);
  drawRoad(m, [{ c: 43, r: 35 }, { c: 47, r: 42 }, { c: 52, r: 42 },
    { c: 54, r: 42 }, { c: 61, r: 41 }]);
  drawRoad(m, [{ c: 55, r: 35 }, { c: 57, r: 46 }, { c: 64, r: 51 }, { c: 77, r: 55 }]);
  setBridge(m, 52, 35); setBridge(m, 53, 35);
  // Two concentric city walls and a separate palace circuit. Gates and the
  // river create several playable routes rather than a solid wall of pieces.
  const ring = (left, top, right, bottom, level, cityId, openings = [], gates = []) => {
    for (let r = top; r <= bottom; r++) for (let c = left; c <= right; c++) {
      if (c !== left && c !== right && r !== top && r !== bottom) continue;
      if (m.terrain[index(m, c, r)] & TERRAIN.RIVER) continue;
      if (openings.some(p => p.c === c && p.r === r)) continue;
      const gate = gates.find(p => p.c === c && p.r === r);
      if (!setFort(m, c, r, gate ? gate.level : level, 'coalition', cityId))
        throw new Error(`${cityId}布设失败 ${c},${r}`);
    }
  };
  ring(34, 14, 77, 55, 3, '巴比伦外城', [{ c: 47, r: 14 }],
    [{ c: 34, r: 35, level: 2 }, { c: 77, r: 35, level: 2 }]);
  ring(43, 20, 76, 51, 3, '巴比伦内城', [{ c: 43, r: 35 }, { c: 47, r: 20 }]);
  ring(60, 22, 75, 33, 2, '巴比伦王宫', [{ c: 67, r: 33 }]);
  // The fictional Judean refuge is a fully enclosed earthen ring. Persian
  // infantry can climb its allied level-one walls to reach the captive.
  for (let r = 38; r <= 44; r++) for (let c = 61; c <= 67; c++) {
    if (c !== 61 && c !== 67 && r !== 38 && r !== 44) continue;
    if (!setFort(m, c, r, 1, 'egypt', '犹大流亡者围院')) throw new Error('围院布设失败');
  }
  // Houses are defensive cover without health bars. Roads, walls, the refuge,
  // and the legendary garden remain readable at the normal zoom level.
  for (let r = 16; r <= 53; r++) for (let c = 36; c <= 75; c++) {
    if ((c * 11 + r * 7) % 19 > 2) continue;
    if (c >= 59 && c <= 76 && r >= 21 && r <= 34) continue;
    if (c >= 59 && c <= 69 && r >= 36 && r <= 46) continue;
    setHouse(m, c, r);
  }
  setSupplyPoint(m, 38, 30, 'coalition', '巴比伦外城');
  setSupplyPoint(m, 59, 37, 'coalition', '巴比伦内城');
  setSupplyPoint(m, 69, 28, 'coalition', '巴比伦王宫');
  setSupplyPoint(m, 64, 41, 'egypt', '犹大流亡者围院');
  // Cyrus commands the western army; a second Persian siege force threatens
  // the eastern gate without starting inside Babylon's outer wall.
  const persia = [
    ['pharaoh',18,35],['guard',18,34],['guard',18,36],
    ['heavy',27,31],['heavy',29,33],['heavy',31,34],['heavy',33,36],['heavy',27,38],['heavy',25,40],['heavy',31,39],
    ['heavy',28,28],['heavy',29,43],
    ['light',23,29],['light',26,35],['light',29,38],['light',22,41],['light',28,40],['light',25,33],
    ['archer',22,27],['archer',24,30],['archer',23,43],['archer',27,42],['archer',26,46],
    ['cavalry',20,25],['cavalry',20,45],['cavalry',23,26],
    ['chariot',17,40],['chariot',22,36],
    ['siegeRam',32,35],['siegeRam',32,32],
    ['heavy',82,32],['heavy',82,38],['heavy',83,44],['heavy',85,31],['heavy',83,46],
    ['light',84,29],['light',84,40],['light',85,47],['light',88,40],
    ['archer',87,33],['archer',87,42],['archer',90,43],
    ['cavalry',86,28],['cavalry',88,45],['cavalry',90,30],
    ['chariot',87,36],['chariot',89,39],['chariot',91,36],
    ['siegeRam',81,35],['siegeRam',81,41],
  ];
  const babylon = [
    ['hittiteKing',69,27],['guard',68,27],['guard',70,27],
    ['heavy',35,35],['heavy',41,34],['heavy',44,36],['heavy',58,36],['heavy',71,41],['heavy',74,23],
    ['light',38,37],['light',46,38],['light',49,33],['light',59,44],['light',73,40],
    ['archer',37,32],['archer',44,31],['archer',57,31],['archer',69,36],['archer',73,43],
    ['cavalry',45,24],['cavalry',74,47],['light',76,17],
  ];
  for (const [kind,c,r] of persia) if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`波斯部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of babylon) if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`巴比伦部署失败 ${kind} ${c},${r}`);
  if (!addUnit(m, 'captive', 'egypt', 64, 41)) throw new Error('流亡者部署失败');
  for (const [c,r] of [[74,23],[76,17]]) mobileAt(m,c,r).pursuer = true;
  validateMap(m); return m;
}

// Playable Late Bronze Age coastal assault. Hisarlik is a fortified rise inland
// from the Bronze Age shore; neither the Homeric battle nor its exact shoreline
// can be mapped as a surveyed battlefield.
export function troyMap() {
  const m = newMap(60, 38);
  m.scenarioId = 'troy';
  m.name = '特洛伊之战 · 海岸登陆';
  m.factions = { egypt: '阿开亚联军', coalition: '特洛伊守军' };
  m.unitNames = Object.fromEntries(Object.entries(TROY_UNIT_NAMES).filter(([k])=>!k.endsWith(':scout')));
  m.victory = { mode: 'troy', capture: { c: 47, r: 13 }, horseUnlockTurn: TROY_HORSE_UNLOCK_TURN };
  m.heroRelease = { team: 'egypt', turn: 25 };
  m.hectorSortieTurn = 21;
  m.recruitment = { startingMoney: { egypt: 42, coalition: 28 }, income: { egypt: 10, coalition: 10 },
    muster: { egypt: { sea: { c: 7, r: 18 }, land: { c: 18, r: 20 } },
      coalition: { sea: { c: 12, r: 35 }, land: { c: 47, r: 20 } } },
    costs: { ...TROY_COSTS } };
  m.intro = '阿开亚军占领城内标记点获胜；守军清除全部参战的陆上阿开亚棋子获胜。赫克托第 21 回合出城野战，阿喀琉斯第 25 回合参战。第 61 回合起阿开亚可花 600 金购买一次特洛伊木马；不再有第 40 回合自动胜利。';
  m.landmarks = [
    { c: 8, r: 6, label: '爱琴海近岸' }, { c: 16, r: 29, label: '登陆滩头' },
    { c: 16, r: 17, label: '阿喀琉斯海边营帐' },
    { c: 7, r: 18, label: '阿开亚海上召集点' },
    { c: 18, r: 20, label: '阿开亚木马工坊' },
    { c: 12, r: 35, label: '特洛伊海上召集点' },
    { c: 47, r: 20, label: '特洛伊城内召集点' },
    { c: 29, r: 29, label: '斯卡曼德罗斯平原（示意）' },
    { c: 26, r: 11, label: '北滩头堡垒' },
    { c: 29, r: 24, label: '平原堡垒' },
    { c: 23, r: 30, label: '南滩头堡垒' },
    { c: 35, r: 20, label: '下城西南门' },
    { c: 45, r: 24, label: '特洛伊下城' },
    { c: 47, r: 23, label: '下城集会庭院' },
    { c: 47, r: 13, label: '希萨尔利克内城' },
    { c: 54, r: 8, label: '达达尼尔海峡方向' },
  ];
  const coast = r => 14 + Math.round(1.2 * Math.sin(r * 0.27));
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if (c <= coast(r)) m.terrain[index(m, c, r)] = TERRAIN.SEA;
    else if (c <= coast(r) + 2) m.terrain[index(m, c, r)] = TERRAIN.BEACH;
    else if (c >= 48 && (r < 8 || r > 30) &&
      Math.sin(c * .31 + r * .47) > -.45) m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
  }
  // North citadel and the wider southern lower town form one irregular enclosed area.
  // The outline is a tactical simplification of the excavation plans, not a surveyed wall.
  const spans = [
    [9, 46, 48], [10, 44, 50], [11, 43, 51], [12, 42, 52], [13, 41, 53],
    [14, 40, 54], [15, 39, 54], [16, 38, 55], [17, 37, 55], [18, 36, 55],
    [19, 35, 55], [20, 35, 55], [21, 35, 54], [22, 36, 54], [23, 37, 53],
    [24, 38, 53], [25, 39, 52], [26, 40, 51], [27, 41, 50], [28, 43, 49],
  ];
  const inside = new Set();
  for (const [r, left, right] of spans) for (let c = left; c <= right; c++) inside.add(key(c, r));
  m.garden = { cMin: 45, rMin: 22, cMax: 49, rMax: 25 };
  // A continuous road connects beach, south-west gate, lower town and citadel.
  drawRoad(m, [{ c: 18, r: 18 }, { c: 30, r: 19 }, { c: 35, r: 20 },
    { c: 42, r: 19 }, { c: 47, r: 11 }, { c: 47, r: 13 }]);
  drawRoad(m, [{ c: 30, r: 19 }, { c: 36, r: 29 }, { c: 46, r: 28 }, { c: 47, r: 20 }]);
  for (const cell of inside) {
    const [c, r] = cell.split(',').map(Number);
    if (neighbors(c, r).every(p => inside.has(key(p.c, p.r)))) continue;
    if (!setFort(m, c, r, 2, 'coalition', '特洛伊')) throw new Error('特洛伊城墙布设失败');
  }
  // A second, smaller enceinte surrounds the citadel objective. Its western
  // wall is also level two; attackers still have to make a breach before entry.
  const citadel = m.victory.capture;
  for (let r = citadel.r - 2; r <= citadel.r + 2; r++) for (let c = citadel.c - 3; c <= citadel.c + 3; c++) {
    if (distance({ c, r }, citadel) !== 2) continue;
    if (!setFort(m, c, r, 2, 'coalition', '特洛伊内城')) throw new Error('特洛伊内城布设失败');
  }
  // Three compact, separate fieldworks defend the open plain behind the beach.
  const beachForts = [
    { c: 26, r: 11, name: '北滩头堡垒' },
    { c: 29, r: 24, name: '平原堡垒' },
    { c: 23, r: 30, name: '南滩头堡垒' },
  ];
  for (const site of beachForts) {
    for (const p of neighbors(site.c, site.r))
      if (!setFort(m, p.c, p.r, 2, 'coalition', site.name)) throw new Error(`${site.name}布设失败`);
  }
  for (const [c, r, cityId] of [[45,20,'特洛伊'], [47,13,'特洛伊内城'],
    [26,11,'北滩头堡垒'], [29,24,'平原堡垒'], [23,30,'南滩头堡垒']])
    if (!setSupplyPoint(m, c, r, 'coalition', cityId)) throw new Error(`${cityId}补给点布设失败`);
  const acheans = [
    ['pharaoh', 20, 18], ['hero', 16, 17], ['guard', 19, 17], ['guard', 20, 19],
    ['heavy', 18, 16], ['light', 17, 18],
    ['chariot', 23, 18], ['warship', 11, 15], ['warship', 11, 23],
    ['transport', 3, 5], ['transport', 7, 9], ['transport', 10, 18],
    ['transport', 13, 13], ['transport', 13, 25], ['transport', 10, 33],
  ];
  const trojans = [
    ['hittiteKing', 47, 12], ['hero', 41, 20], ['guard', 48, 12], ['guard', 48, 13],
    ['heavy', 39, 19], ['heavy', 44, 22], ['heavy', 48, 18],
    ['heavy', 33, 18], ['heavy', 34, 24],
    ['light', 29, 16], ['light', 32, 23], ['light', 42, 26],
    ['archer', 37, 19], ['archer', 44, 15], ['archer', 48, 14],
    ['archer', 26, 11], ['heavy', 29, 24], ['light', 23, 30],
    // Two distant scouts and a seven-piece coastal corps contest the landing.
    ['light', 16, 8], ['archer', 17, 31],
    ['archer', 22, 15], ['heavy', 24, 17], ['light', 23, 23],
    ['heavy', 24, 20], ['archer', 25, 18], ['light', 22, 21],
    ['heavy', 25, 20], ['light', 27, 27], ['archer', 30, 15],
    ['hittiteChariot', 32, 27], ['warship', 13, 8], ['warship', 13, 30],
  ];
  for (const [kind, c, r] of acheans) if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`阿开亚部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of trojans) if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`特洛伊部署失败 ${kind} ${c},${r}`);
  for (const [c, r, kinds] of [
    [3, 5, ['heavy']], [7, 9, ['light', 'heavy']],
    [10, 18, ['heavy', 'guard']], [13, 13, ['heavy', 'light']],
    [13, 25, ['heavy', 'archer']], [10, 33, ['heavy']],
  ]) {
    const ship = mobileAt(m, c, r);
    for (const kind of kinds) if (!addEmbarkedUnit(m, kind, 'egypt', ship)) throw new Error('阿开亚登船失败');
  }
  // Small, separated houses fill the lower town while preserving its streets,
  // muster point, citadel approach, and open gathering courtyard.
  for (const cell of inside) {
    const [c, r] = cell.split(',').map(Number);
    if (distance({ c, r }, citadel) <= 3 ||
        (c >= m.garden.cMin && c <= m.garden.cMax && r >= m.garden.rMin && r <= m.garden.rMax) ||
        (c * 5 + r * 9) % 17 > 3) continue;
    setHouse(m, c, r);
  }
  // Two defenders begin in cover so the new city buildings affect play at once.
  for (const [c, r] of [[44, 22], [44, 15]])
    if (!setHouse(m, c, r)) throw new Error('特洛伊驻军房屋布设失败');
  m.reinforcements = [];
  validateMap(m); return m;
}

// A playable schematic of the 480 BCE Salamis strait. The shoreline and
// squadron counts are tactical abstractions rather than surveyed ship positions.
export function salamisMap() {
  const m = newMap(80, 52);
  m.scenarioId = 'salamis';
  m.name = '萨拉米斯海战 · 海峡决战';
  m.factions = { egypt: '希腊联军', coalition: '波斯舰队' };
  m.unitNames = { ...SALAMIS_UNIT_NAMES };
  m.victory = { mode: 'salamis', bay: { cMin: 22, rMin: 19, cMax: 33, rMax: 26 },
    greekLosses: 10, persianLosses: 10, bayShips: 4 };
  m.intro = '公元前480年萨拉米斯海战的战术示意。任一方击溃敌方四分之三分舰队获胜；波斯也可用4支战船稳控安贝拉基湾一整轮。波斯有两批预定援军，击溃门槛按全部参战舰队计算。每枚棋子代表分舰队，双方无新船招募。';
  m.weather = { windDir: 0, clouds: [{ c: 35, r: 29, radius: 4 }, { c: 52, r: 39, radius: 4 }] };
  m.landmarks = [
    { c: 24, r: 20, label: '安贝拉基湾 · 希腊锚地' },
    { c: 32, r: 34, label: '基诺苏拉海角' },
    { c: 46, r: 40, label: '普西塔利亚岛' },
    { c: 62, r: 23, label: '阿提卡海岸' },
    { c: 48, r: 47, label: '波斯舰队南方入口' },
  ];
  for (let r = 0; r < m.rows; r++) {
    const west = r < 21 ? 21 : r < 27 ? 18 : r < 31 ? 22 : r < 35 ? 30 :
      r < 39 ? 31 : 17;
    const east = r < 27 ? 60 : r < 31 ? 55 : r < 35 ? 51 :
      r < 39 ? 60 : 67;
    for (let c = west + 1; c < east; c++) m.terrain[index(m, c, r)] = TERRAIN.SEA;
    for (const c of [west, east]) m.terrain[index(m, c, r)] = TERRAIN.BEACH;
  }
  // Psyttaleia splits the southern approach into two navigable channels.
  for (let r = 38; r <= 42; r++) for (let c = 43; c <= 49; c++) {
    if (distance({ c, r }, { c: 46, r: 40 }) > 3) continue;
    m.terrain[index(m, c, r)] = distance({ c, r }, { c: 46, r: 40 }) === 3 ? TERRAIN.BEACH : TERRAIN.PLAIN;
  }
  for (let r = 12; r <= 30; r++) for (let c = 65; c < m.cols; c++)
    if ((c + r) % 4 !== 0) m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
  const greek = [
    ['athenianTrireme',28,21],['athenianTrireme',30,19],['athenianTrireme',32,20],
    ['athenianTrireme',34,18],['athenianTrireme',36,20],['athenianTrireme',38,18],
    ['athenianTrireme',40,20],['athenianTrireme',42,19],['athenianTrireme',29,25],
    ['athenianTrireme',33,24],['athenianTrireme',37,25],['athenianTrireme',41,24],
    ['alliedTrireme',26,23],['alliedTrireme',30,23],['alliedTrireme',34,22],
    ['alliedTrireme',38,23],['alliedTrireme',42,22],['alliedTrireme',28,28],
    ['alliedTrireme',35,28],['alliedTrireme',43,27],
  ];
  const persianVanguard = [
    ['phoenicianTrireme',28,44],['phoenicianTrireme',32,44],
    ['phoenicianTrireme',36,44],['phoenicianTrireme',40,44],
    ['phoenicianTrireme',52,44],['phoenicianTrireme',56,44],
    ['phoenicianTrireme',30,46],['phoenicianTrireme',35,46],
    ['phoenicianTrireme',40,46],['phoenicianTrireme',52,46],
    ['imperialTrireme',25,43],['imperialTrireme',29,43],
    ['imperialTrireme',34,43],['imperialTrireme',39,43],
    ['imperialTrireme',51,43],['imperialTrireme',55,43],
    ['imperialTrireme',60,43],['imperialTrireme',63,43],
  ];
  for (const [kind, c, r] of greek) if (!addUnit(m, kind, 'egypt', c, r))
    throw new Error(`希腊舰队部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of persianVanguard) if (!addUnit(m, kind, 'coalition', c, r))
    throw new Error(`波斯舰队部署失败 ${kind} ${c},${r}`);
  for (const [c, r, name] of [[28, 21, '地米斯托克利'], [26, 23, '欧律比亚德斯'],
    [28, 44, '阿里亚比格涅斯'], [63, 43, '阿尔忒弥西亚']])
    mobileAt(m, c, r).commander = name;
  m.reinforcements = [
    { turn: 2, team: 'coalition', label: '波斯外海第二梯队进入海峡', units: [
      { kind: 'phoenicianTrireme', c: 24, r: 49 },
      ...[30, 36, 50, 56, 62].map(c => ({ kind: 'imperialTrireme', c, r: 49 })),
    ] },
    { turn: 3, team: 'coalition', label: '波斯外海第三梯队进入海峡', units: [
      { kind: 'phoenicianTrireme', c: 22, r: 50 },
      ...[28, 34, 52, 58, 64].map(c => ({ kind: 'imperialTrireme', c, r: 50 })),
    ] },
  ];
  validateMap(m); return m;
}

// Tactical reconstruction of the broad Gaugamela plain, not a surveyed map.
export function gaugamelaMap() {
  const m = newMap(88, 52);
  m.scenarioId = 'gaugamela';
  m.name = '高加米拉之战 · 方阵与两翼';
  m.factions = { egypt: '马其顿联军', coalition: '阿契美尼德波斯军' };
  m.unitNames = { ...GAUGAMELA_UNIT_NAMES };
  m.victory = { mode: 'gaugamela', phalanxLosses: 8 };
  m.intro = '前331年高加米拉战术示意。马其顿使大流士负伤退出战场、击杀他或击溃波斯军四分之三获胜；波斯击杀亚历山大或击溃马其顿方阵四分之三获胜。战象据阿里安记载在波斯军中，实际参战情况不明，玩家调其冲锋属于可玩性推演。';
  m.landmarks = [
    { c: 17, r: 25, label: '马其顿后方营地' },
    { c: 43, r: 25, label: '马其顿方阵中军' },
    { c: 51, r: 25, label: '波斯整平的战车冲击地带' },
    { c: 62, r: 25, label: '大流士三世帅旗' },
    { c: 72, r: 25, label: '波斯后方营地' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if ((r <= 4 || r >= 47) && (c * 7 + r * 11) % 5 < 2)
      m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
  }
  drawRoad(m, [{ c: 11, r: 25 }, { c: 35, r: 25 }, { c: 52, r: 25 }, { c: 76, r: 25 }]);
  const macedonians = [
    ['pharaoh',36,13],
    ...[[37,12],[39,14],[36,16],[34,13],[35,17]].map(([c,r]) => ['companionCavalry',c,r]),
    ['guard',40,18],['guard',40,33],
    ...Array.from({ length: 12 }, (_, i) => ['phalangite',42,20+i]),
    ['archer',39,22],['archer',39,28],['archer',37,29],
    ['light',43,18],['light',43,33],['light',40,16],['light',40,35],
    ['cavalry',36,36],['cavalry',38,38],['cavalry',34,34],
  ];
  const persians = [
    ['hittiteKing',62,25],
    ['guard',61,24],['guard',61,26],['guard',60,25],['guard',62,26],
    ...Array.from({ length: 8 }, (_, i) => ['heavy',49,21+i]),
    ['archer',51,19],['archer',51,31],['archer',53,17],['archer',53,34],['archer',55,22],['archer',55,29],
    ['light',48,17],['light',48,33],['light',52,20],['light',52,30],
    ['light',55,19],['light',55,32],['light',46,22],['light',46,30],
    ...[[48,10],[50,12],[52,9],[54,11],[56,13],[58,15],
      [48,40],[50,38],[52,42],[54,39],[56,37],[58,35]].map(([c,r]) => ['cavalry',c,r]),
    ['scythedChariot',46,19],['scythedChariot',46,26],['scythedChariot',46,34],
    ['warElephant',59,20],['warElephant',59,31],
  ];
  for (const [kind, c, r] of macedonians) if (!addUnit(m, kind, 'egypt', c, r))
    throw new Error(`马其顿部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of persians) if (!addUnit(m, kind, 'coalition', c, r))
    throw new Error(`波斯部署失败 ${kind} ${c},${r}`);
  validateMap(m); return m;
}

// Issus is a schematic coastal corridor: sea to the west, Amanus foothills to
// the east, and the Pinarus between the two armies. Ford locations are a
// playable abstraction; their precise historical sites are unknown.
export function issusMap() {
  const m = newMap(84, 48);
  m.scenarioId = 'issus';
  m.name = '伊苏斯之战 · 皮纳鲁斯河';
  m.factions = { egypt: '马其顿联军', coalition: '阿契美尼德波斯军' };
  m.unitNames = { ...ISSUS_UNIT_NAMES };
  m.victory = { mode: 'issus', phalanxLosses: 7 };
  m.intro = '前333年伊苏斯战术示意。马其顿从南侧进军，须越过皮纳鲁斯河；波斯守住北岸，希腊雇佣重步兵据守中央、骑兵集中近海翼。亚历山大阵亡或四分之三方阵被击溃则波斯获胜；大流士阵亡、负伤撤离或波斯战斗部队四分之三被击溃则马其顿获胜。地形及棋子数量是游戏抽象。';
  m.landmarks = [
    { c: 8, r: 23, label: '地中海' },
    { c: 20, r: 24, label: '皮纳鲁斯河口浅滩' },
    { c: 43, r: 24, label: '皮纳鲁斯河中央渡口' },
    { c: 65, r: 24, label: '东侧山麓渡口' },
    { c: 74, r: 15, label: '阿马努斯山麓' },
    { c: 43, r: 17, label: '波斯希腊雇佣军中军' },
    { c: 22, r: 17, label: '波斯近海骑兵翼' },
    { c: 62, r: 32, label: '亚历山大右翼' },
    { c: 43, r: 13, label: '大流士三世中军' },
  ];
  for (let r = 0; r < m.rows; r++) {
    const coast = 11 + Math.round(Math.sin(r * .22));
    const ridge = 73 - (r < 9 ? 3 : r > 39 ? 2 : 0) + Math.round(Math.sin(r * .18));
    for (let c = 0; c < m.cols; c++) {
      if (c <= coast) m.terrain[index(m, c, r)] = TERRAIN.SEA;
      else if (c <= coast + 2) m.terrain[index(m, c, r)] = TERRAIN.BEACH;
      else if (c >= ridge) m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
    }
  }
  for (let c = 13; c <= 72; c++) m.terrain[index(m, c, 24)] = TERRAIN.RIVER;
  // Three narrow crossing sectors represent the shallow delta and viable gaps
  // in otherwise difficult central and foothill banks.
  for (const [left, right] of [[18, 22], [39, 43], [63, 65]])
    for (let c = left; c <= right; c++) m.terrain[index(m, c, 24)] |= TERRAIN.ROAD;
  drawRoad(m, [{ c: 24, r: 45 }, { c: 29, r: 32 }, { c: 40, r: 24 },
    { c: 42, r: 16 }, { c: 43, r: 5 }]);
  drawRoad(m, [{ c: 29, r: 32 }, { c: 20, r: 27 }, { c: 20, r: 24 }, { c: 22, r: 18 }]);
  drawRoad(m, [{ c: 29, r: 32 }, { c: 40, r: 29 }, { c: 62, r: 27 },
    { c: 64, r: 24 }, { c: 65, r: 20 }]);
  const macedonians = [
    ['pharaoh',62,34],
    ['companionCavalry',60,32],['companionCavalry',62,32],
    ['companionCavalry',64,33],['companionCavalry',66,34],
    ['guard',57,32],['guard',59,33],
    ...Array.from({ length: 11 }, (_, i) => ['phalangite',35+i,31]),
    ['archer',31,33],['archer',48,33],['archer',58,30],
    ['light',32,30],['light',49,30],['light',61,29],['light',65,31],
    ['cavalry',18,34],['cavalry',20,33],['cavalry',22,34],
    ['cavalry',24,33],['cavalry',27,34],
  ];
  const persians = [
    ['hittiteKing',43,13],
    ['guard',42,12],['guard',44,12],['guard',42,14],['guard',44,14],
    ...Array.from({ length: 11 }, (_, i) => ['heavy',35+i,20]),
    ['archer',32,21],['archer',39,22],['archer',47,22],
    ['archer',53,21],['archer',61,21],['archer',24,21],
    ['light',31,19],['light',49,19],['light',52,20],['light',55,20],
    ['light',58,20],['light',62,20],['light',65,20],['light',67,22],
    ['light',68,28],['light',70,29],
    ['cavalry',17,17],['cavalry',19,17],['cavalry',21,17],
    ['cavalry',23,17],['cavalry',25,17],['cavalry',27,17],
    ['cavalry',18,19],['cavalry',20,19],['cavalry',22,19],
    ['cavalry',24,19],['cavalry',26,19],['cavalry',28,19],
  ];
  for (const [kind, c, r] of macedonians) if (!addUnit(m, kind, 'egypt', c, r))
    throw new Error(`马其顿部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of persians) if (!addUnit(m, kind, 'coalition', c, r))
    throw new Error(`波斯部署失败 ${kind} ${c},${r}`);
  for (const u of m.units) if (isPhalangite(u)) u.facing = 2;
  for (const [c, r] of [[68,28],[70,29]]) mobileAt(m, c, r).scout = true;
  validateMap(m); return m;
}

// Tyre in 332 BCE was an offshore island. Its exact ancient shoreline and wall
// line are uncertain; these hexes are a playable diagram of mole and sea assault.
export function tyreMap() {
  const m = newMap(60, 40);
  m.scenarioId = 'tyre';
  m.name = '推罗围城战 · 堤道与舰队';
  m.factions = { egypt: '马其顿联军', coalition: '推罗守军' };
  m.unitNames = { ...TYRE_UNIT_NAMES };
  m.victory = { mode: 'tyre', capture: { c: 42, r: 19 }, turnLimit: 24,
    moles: [
      Array.from({ length: 17 }, (_, i) => [14 + i, 19]),
      Array.from({ length: 18 }, (_, i) => [14 + i, 18]),
      Array.from({ length: 18 }, (_, i) => [14 + i, 20]),
    ] };
  m.intro = '前332年推罗围城战术示意。工程队可同时修筑同一条宽堤道的北、中、南三列；马其顿盟邦舰队第4回合抵达，可从海上炮击或登陆。占领内城标记点获胜；推罗击杀亚历山大或守至第24回合获胜。回合数与兵力为游戏抽象。';
  m.landmarks = [
    { c: 8, r: 7, label: '旧推罗 · 大陆' },
    { c: 18, r: 19, label: '马其顿宽堤道' },
    { c: 29, r: 8, label: '北侧海域' },
    { c: 39, r: 7, label: '西顿港方向' },
    { c: 48, r: 29, label: '埃及港方向' },
    { c: 41, r: 19, label: '推罗岛城' },
    { c: 42, r: 19, label: '推罗内城目标' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if (c <= 13) {
      if (c === 13) m.terrain[index(m, c, r)] = TERRAIN.BEACH;
      else if (c <= 4 && (r <= 5 || r >= 34)) m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
      continue;
    }
    const ellipse = ((c - 41) / 10) ** 2 + ((r - 19) / 8) ** 2;
    m.terrain[index(m, c, r)] = ellipse <= 1 ? ellipse >= .72 ? TERRAIN.BEACH : TERRAIN.PLAIN : TERRAIN.SEA;
  }
  for (const [c, r] of [[40,11],[41,11],[41,12],[42,11],[42,12],
    [41,27],[42,27],[42,28],[43,27]])
    m.terrain[index(m, c, r)] = TERRAIN.SEA;
  drawRoad(m, [{ c: 2, r: 19 }, { c: 13, r: 19 }]);
  drawRoad(m, [{ c: 13, r: 18 }, { c: 13, r: 20 }]);
  drawRoad(m, [{ c: 31, r: 19 }, { c: 42, r: 19 }, { c: 45, r: 17 }]);
  drawRoad(m, [{ c: 38, r: 18 }, { c: 40, r: 13 }]);
  drawRoad(m, [{ c: 39, r: 20 }, { c: 41, r: 24 }]);
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++)
    if (m.terrain[index(m, c, r)] === (TERRAIN.BEACH | TERRAIN.ROAD))
      setTerrain(m, c, r, TERRAIN.ROAD);
  for (const lane of m.victory.moles) for (const [c, r] of lane.slice(0, 9))
    if (!setTerrain(m, c, r, TERRAIN.ROAD)) throw new Error('推罗堤道初始段布设失败');
  const city = new Set();
  for (let r = 12; r <= 26; r++) for (let c = 32; c <= 50; c++)
    if (((c - 41) / 8) ** 2 + ((r - 19) / 6) ** 2 <= 1) city.add(key(c, r));
  for (const cell of city) {
    const [c, r] = cell.split(',').map(Number);
    if (neighbors(c, r).every(p => city.has(key(p.c, p.r)))) continue;
    if (!setFort(m, c, r, 3, 'coalition', '推罗城墙')) throw new Error(`推罗城墙布设失败 ${cell}`);
  }
  for (const [c, r] of [[38,17], [43,22]])
    if (!setSupplyPoint(m, c, r, 'coalition', '推罗城墙')) throw new Error('推罗补给点布设失败');
  const macedonians = [
    ['pharaoh', 7, 16], ['guard', 8, 16], ['guard', 8, 18],
    ['engineer', 21, 19], ['engineer', 20, 18], ['engineer', 18, 20],
    ['siegeRam', 17, 19], ['siegeRam', 15, 19],
    ...[[9,17],[10,18],[11,20],[12,18],[14,19],[16,19],[18,19],[19,19]].map(([c,r]) => ['phalangite',c,r]),
    ['heavy',8,20], ['heavy',10,21], ['heavy',12,21], ['heavy',17,20],
    ['light',9,14], ['light',10,15], ['light',11,16], ['light',13,17],
    ['archer',8,22], ['archer',10,23], ['archer',13,21],
    ['companionCavalry',6,19], ['companionCavalry',7,20],
  ];
  const tyrians = [
    ['hittiteKing', 44, 19], ['guard', 43, 18], ['guard', 45, 18], ['guard', 44, 20],
    ...[[35,18],[36,16],[38,22],[40,15],[42,16],[46,19],[47,21]].map(([c,r]) => ['heavy',c,r]),
    ...[[36,21],[39,17],[41,21],[45,15],[46,23]].map(([c,r]) => ['light',c,r]),
    ...[[34,19],[35,16],[39,23],[42,14],[43,24],[48,19]].map(([c,r]) => ['archer',c,r]),
    ['phoenicianTrireme', 35, 7], ['phoenicianTrireme', 38, 8],
    ['phoenicianTrireme', 43, 8], ['imperialTrireme', 46, 9],
    ['phoenicianTrireme', 37, 30], ['phoenicianTrireme', 41, 31],
    ['imperialTrireme', 46, 30],
  ];
  for (const [kind,c,r] of macedonians)
    if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`马其顿部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of tyrians)
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`推罗部署失败 ${kind} ${c},${r}`);
  for (const u of m.units) if (isPhalangite(u)) u.facing = 0;
  for (const cell of city) {
    const [c,r] = cell.split(',').map(Number);
    if ((c * 5 + r * 7) % 11 < 2 && distance({ c,r }, m.victory.capture) > 1) setHouse(m, c, r);
  }
  m.reinforcements = [
    { turn: 4, team: 'egypt', label: '腓尼基盟邦舰队抵达', units: [
      { kind: 'alliedTrireme', c: 23, r: 7 }, { kind: 'alliedTrireme', c: 25, r: 9 },
      { kind: 'alliedTrireme', c: 25, r: 29 }, { kind: 'alliedTrireme', c: 27, r: 31 },
      { kind: 'siegeGalley', c: 27, r: 12 }, { kind: 'siegeGalley', c: 28, r: 27 },
      { kind: 'transport', c: 26, r: 14, cargo: ['heavy', 'light'] },
      { kind: 'transport', c: 27, r: 25, cargo: ['guard', 'archer'] },
    ] },
    { turn: 7, team: 'egypt', label: '马其顿后续攻城船抵达', units: [
      { kind: 'siegeGalley', c: 23, r: 11 },
      { kind: 'transport', c: 24, r: 27, cargo: ['heavy', 'heavy'] },
    ] },
  ];
  validateMap(m); return m;
}

export function cannaeMap() {
  const m = newMap(96, 60);
  m.scenarioId = 'cannae';
  m.name = '坎尼会战 · 双翼合围';
  m.factions = { egypt: '罗马共和国', coalition: '汉尼拔联军' };
  m.victory = { mode: 'cannae', romanLosses: 29, punicLosses: 20, turnLimit: 20 };
  m.intro = '前216年坎尼会战战术复原。罗马步兵人数占优，汉尼拔中央可有序后撤，两翼步兵与骑兵须实际完成合围。双方无招募和援军。';
  m.landmarks = [
    { c: 6, r: 12, label: '罗马大营 · 河西岸' },
    { c: 18, r: 12, label: '罗马小营 · 河东岸' },
    { c: 12, r: 30, label: '奥菲杜斯河' },
    { c: 39, r: 31, label: '坎尼会战中央' },
    { c: 47, r: 52, label: '迦太基营地' },
    { c: 82, r: 48, label: '坎尼村址 · 示意' },
  ];
  for (let r = 0; r < m.rows; r++) {
    const riverC = 12 + Math.round(1.2 * Math.sin(r * 0.14));
    for (const c of [riverC - 1, riverC, riverC + 1])
      if (!setTerrain(m, c, r, TERRAIN.RIVER)) throw new Error('奥菲杜斯河绘制失败');
  }
  drawRoad(m, [{ c: 5, r: 12 }, { c: 18, r: 12 }, { c: 24, r: 10 },
    { c: 78, r: 10 }, { c: 80, r: 45 }, { c: 47, r: 52 }]);
  for (const [c, r, team, city] of [
    [5, 11, 'egypt', '罗马大营'], [7, 11, 'egypt', '罗马大营'],
    [17, 11, 'egypt', '罗马小营'], [19, 11, 'egypt', '罗马小营'],
    [46, 51, 'coalition', '迦太基营地'], [48, 51, 'coalition', '迦太基营地'],
  ]) if (!setFort(m, c, r, 1, team, city)) throw new Error(`坎尼营垒布设失败 ${c},${r}`);
  const roman = [
    ...Array.from({ length: 8 }, (_, i) => ['romanVelites', 31 + i * 2, 30]),
    ...Array.from({ length: 18 }, (_, i) => ['romanHastati', 29 + i, 27]),
    ...Array.from({ length: 18 }, (_, i) => ['romanPrincipes', 29 + i, 24]),
    ...Array.from({ length: 8 }, (_, i) => ['romanTriarii', 34 + i, 21]),
    ['romanHorse', 19, 27], ['romanHorse', 21, 27],
    ...Array.from({ length: 4 }, (_, i) => ['romanAlliedHorse', 56 + i, 27]),
    ['paullus', 23, 22], ['varro', 58, 22],
  ];
  const punic = [
    ...Array.from({ length: 12 }, (_, i) => [i % 2 ? 'iberianInfantry' : 'gaulInfantry',
      33 + i, 36 + Math.floor(Math.abs(i - 5.5) / 3)]),
    ...Array.from({ length: 5 }, (_, i) => ['africanInfantry', 27 + i, 35]),
    ...Array.from({ length: 5 }, (_, i) => ['africanInfantry', 47 + i, 35]),
    ...Array.from({ length: 5 }, (_, i) => ['punicSkirmisher', 35 + i * 2, 39]),
    ...Array.from({ length: 6 }, (_, i) => ['punicHeavyHorse', 18 + i, 33]),
    ...Array.from({ length: 6 }, (_, i) => ['numidianHorse', 57 + i, 33]),
    ['hannibal', 40, 43],
  ];
  for (const [kind, c, r] of roman)
    if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`罗马部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of punic)
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`迦太基部署失败 ${kind} ${c},${r}`);
  validateMap(m); return m;
}

export function zamaMap() {
  const m = newMap(96, 64);
  m.scenarioId = 'zama';
  m.name = '扎马会战 · 战象与骑兵回击';
  m.factions = { egypt: '罗马·努米底亚联军', coalition: '汉尼拔的迦太基军' };
  m.victory = { mode: 'zama', romanLosses: 27, punicLosses: 27, turnLimit: 22 };
  m.intro = '前202年扎马会战战术示意：罗马三线军团留出战象通道，轻兵掩护前沿；汉尼拔列战象、雇佣兵、迦太基本土兵和意大利老兵，双方骑兵展开翼侧争夺。地图以开阔平原表现战术位置，不声称精确复原战场坐标。双方无招募和援军。';
  m.landmarks = [
    { c: 46, r: 9, label: '西庇阿指挥区' },
    { c: 46, r: 24, label: '罗马三线阵列' },
    { c: 46, r: 34, label: '战象通道' },
    { c: 46, r: 47, label: '迦太基第一、二线' },
    { c: 46, r: 57, label: '汉尼拔老兵预备队' },
  ];
  m.unitNames = {
    'egypt:scipio': '大西庇阿', 'egypt:masinissa': '马西尼萨',
    'egypt:romanHorse': '拉埃利乌斯意大利骑兵',
    'egypt:masinissaHorse': '马西尼萨努米底亚骑兵',
    'coalition:warElephant': '迦太基战象',
    'coalition:gaulInfantry': '凯尔特雇佣兵',
    'coalition:iberianInfantry': '利古里亚雇佣兵',
    'coalition:africanInfantry': '利比亚·迦太基步兵',
    'coalition:zamaVeteran': '汉尼拔意大利老兵',
    'coalition:numidianHorse': '迦太基盟军努米底亚骑兵',
    'coalition:zamaPunicHorse': '迦太基本土骑兵',
  };
  const roman = [
    ...Array.from({ length: 10 }, (_, i) => ['romanHastati', 27 + 4 * i, 26]),
    ...Array.from({ length: 10 }, (_, i) => ['romanPrincipes', 27 + 4 * i, 23]),
    ...Array.from({ length: 10 }, (_, i) => ['romanTriarii', 27 + 4 * i, 20]),
    ...Array.from({ length: 9 }, (_, i) => ['romanVelites', 29 + 4 * i, 30]),
    ...Array.from({ length: 6 }, (_, i) => ['romanHorse', 16 + i, 26]),
    ...Array.from({ length: 8 }, (_, i) => ['masinissaHorse', 69 + i, 26]),
    ['scipio', 45, 16], ['masinissa', 75, 20],
  ];
  const punic = [
    ...Array.from({ length: 9 }, (_, i) => ['warElephant', 29 + 4 * i, 35]),
    ...Array.from({ length: 12 }, (_, i) => [i % 2 ? 'iberianInfantry' : 'gaulInfantry', 27 + 3 * i, 43]),
    ...Array.from({ length: 12 }, (_, i) => ['africanInfantry', 27 + 3 * i, 47]),
    ...Array.from({ length: 12 }, (_, i) => ['zamaVeteran', 27 + 3 * i, 53]),
    ...Array.from({ length: 3 }, (_, i) => ['numidianHorse', 18 + i, 44]),
    ...Array.from({ length: 5 }, (_, i) => ['zamaPunicHorse', 69 + i, 44]),
    ['hannibal', 47, 57],
  ];
  for (const [kind, c, r] of roman)
    if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`罗马部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of punic)
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`迦太基部署失败 ${kind} ${c},${r}`);
  validateMap(m); return m;
}

export function carthageMap() {
  const m = newMap(72, 48);
  m.scenarioId = 'carthage';
  m.name = '迦太基围城战 · 港区与比尔萨';
  m.factions = { egypt: '罗马共和国', coalition: '迦太基守军' };
  m.unitNames = {
    'egypt:scipio': '小西庇阿', 'egypt:romanVelites': '罗马投枪轻兵',
    'egypt:romanLegion': '罗马军团重步兵', 'egypt:siegeRam': '罗马攻城槌车',
    'egypt:romanOnager': '罗马扭力抛石机', 'egypt:romanArcher': '罗马弓箭手',
    'egypt:engineer': '罗马攻城工程队', 'egypt:siegeGalley': '罗马攻城舰',
    'egypt:alliedTrireme': '罗马盟邦战船', 'egypt:transport': '罗马运兵船',
    'coalition:defenseTower': '军港弩炮塔', 'coalition:hannibal': '哈斯德鲁巴',
    'coalition:africanInfantry': '迦太基守城重步兵',
    'coalition:iberianInfantry': '迦太基城防步兵',
    'coalition:punicSkirmisher': '迦太基投射轻兵',
    'coalition:phoenicianTrireme': '迦太基港口战船',
  };
  m.victory = { mode: 'carthage', harbor: { c: 51, r: 29 },
    byrsa: { c: 53, r: 16 }, turnLimit: 24 };
  m.intro = '前146年迦太基围城战的可玩战术示意。罗马舰队压制军港战船与弩炮塔，运兵船可经军港入口驶入港内登陆；扭力抛石机与弓箭手支援陆军攻城。先占科通港区，再夺比尔萨城堡。守军清除陆上攻城军或坚守至第24回合获胜。';
  m.landmarks = [
    { c: 27, r: 25, label: '罗马攻城阵地' },
    { c: 38, r: 25, label: '迦太基外墙' },
    { c: 49, r: 25, label: '城区街巷' },
    { c: 51, r: 29, label: '科通港区 · 第一目标' },
    { c: 56, r: 33, label: '军港水域' },
    { c: 53, r: 16, label: '比尔萨城堡 · 最终目标' },
    { c: 66, r: 26, label: '罗马封锁舰队' },
    { c: 58, r: 44, label: '罗马运兵船' },
    { c: 44, r: 40, label: '南岸登陆滩头' },
    { c: 56, r: 30, label: '军港内侧登陆岸' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if (c >= 62 || (r >= 40 && c >= 46) || (c >= 53 && c <= 59 && r >= 31 && r <= 35) ||
        (r >= 33 && r <= 35 && c >= 59)) setTerrain(m, c, r, TERRAIN.SEA);
    else if (c === 61 || (r === 39 && c >= 46) || (r === 10 && c >= 49))
      setTerrain(m, c, r, TERRAIN.BEACH);
  }
  for (const [c, r] of [[45, 40], [44, 40], [44, 41],
    [45, 41], [46, 41], [47, 41], [48, 41], [49, 41]])
    setTerrain(m, c, r, TERRAIN.BEACH);
  for (let c = 53; c <= 59; c++) setTerrain(m, c, 30, TERRAIN.BEACH);
  drawRoad(m, [{ c: 22, r: 25 }, { c: 38, r: 25 }, { c: 51, r: 29 }]);
  drawRoad(m, [{ c: 29, r: 30 }, { c: 38, r: 30 }, { c: 47, r: 29 }]);
  drawRoad(m, [{ c: 46, r: 28 }, { c: 49, r: 22 }, { c: 53, r: 19 }, { c: 53, r: 16 }]);
  drawRoad(m, [{ c: 51, r: 29 }, { c: 54, r: 25 }, { c: 53, r: 19 }]);
  drawRoad(m, [{ c: 43, r: 27 }, { c: 44, r: 19 }, { c: 51, r: 17 }]);
  // Continuous western curtain wall; the two lower-level gate sectors invite a focused breach.
  for (let r = 10; r <= 38; r++)
    if (!setFort(m, 38, r, [25, 30].includes(r) ? 1 : 2, 'coalition', '迦太基外墙'))
      throw new Error('迦太基外墙布设失败');
  if (!setFort(m, 38, 39, 2, 'coalition', '迦太基外墙'))
    throw new Error('迦太基西南城角布设失败');
  for (let c = 39; c <= 61; c++) {
    if (!setFort(m, c, 10, 2, 'coalition', '迦太基外墙') ||
        !setFort(m, c, 39, 2, 'coalition', '迦太基外墙')) throw new Error('迦太基沿海城墙布设失败');
  }
  for (const r of [...Array.from({ length: 22 }, (_, i) => 11 + i), 36, 37, 38])
    if (!setFort(m, 61, r, [32, 36].includes(r) ? 1 : 2, 'coalition', '迦太基外墙')) throw new Error('迦太基海墙布设失败');
  for (let c = 49; c <= 57; c++)
    if (!setFort(m, c, 13, 2, 'coalition', '比尔萨城堡')) throw new Error('比尔萨北墙布设失败');
  for (let r = 14; r <= 19; r++) for (const c of [49, 57])
    if (!setFort(m, c, r, 2, 'coalition', '比尔萨城堡')) throw new Error('比尔萨侧墙布设失败');
  for (let c = 50; c <= 56; c++) if (c !== 53)
    if (!setFort(m, c, 20, 2, 'coalition', '比尔萨城堡')) throw new Error('比尔萨南墙布设失败');
  for (const [c, r, city] of [[43, 25, '迦太基外墙'], [54, 17, '比尔萨城堡']])
    if (!setSupplyPoint(m, c, r, 'coalition', city)) throw new Error('迦太基补给点布设失败');
  const roman = [
    ['scipio', 25, 23], ['siegeRam', 35, 25], ['siegeRam', 35, 30],
    ['engineer', 33, 24], ['engineer', 33, 31],
    ['romanOnager', 29, 24], ['romanOnager', 29, 31],
    ['romanArcher', 32, 23], ['romanArcher', 33, 23],
    ['romanArcher', 32, 29], ['romanArcher', 33, 29],
    ...Array.from({ length: 8 }, (_, i) => ['romanLegion', 27 + i, 21]),
    ...Array.from({ length: 8 }, (_, i) => ['romanLegion', 27 + i, 34]),
    ...Array.from({ length: 6 }, (_, i) => ['romanVelites', 29 + i, 27]),
    ...Array.from({ length: 4 }, (_, i) => ['romanLegion', 26 + i, 38]),
    ['siegeGalley', 65, 29], ['siegeGalley', 65, 36],
    ['siegeGalley', 68, 29], ['siegeGalley', 68, 37],
    ['alliedTrireme', 67, 31], ['alliedTrireme', 67, 38],
    ['transport', 54, 44], ['transport', 58, 44],
  ];
  const punic = [
    ['hannibal', 53, 16],
    ...[[41,22],[42,27],[43,31],[47,24],[50,25],[51,27],[51,21],[54,22],
      [52,18],[54,18],[55,16],[54,29]].map(([c,r]) => ['africanInfantry', c, r]),
    ...[[39,25],[39,30],[44,24],[46,29],[50,28],[53,24],[50,17]].map(([c,r]) => ['iberianInfantry', c, r]),
    ...[[38,20],[38,23],[38,28],[38,33],[45,23],[48,27],[52,23],
      [55,20],[50,15],[56,15]].map(([c,r]) => ['punicSkirmisher', c, r]),
    ['phoenicianTrireme', 55, 33], ['phoenicianTrireme', 57, 34],
    ['defenseTower', 61, 32], ['defenseTower', 61, 36],
  ];
  for (const [kind, c, r] of roman)
    if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`罗马部署失败 ${kind} ${c},${r}`);
  for (const [kind, c, r] of punic)
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`迦太基部署失败 ${kind} ${c},${r}`);
  const transports = m.units.filter(u => u.kind === 'transport' && u.team === 'egypt');
  for (const [i, cargo] of [['romanLegion', 'romanVelites'], ['romanLegion', 'romanLegion']].entries())
    for (const kind of cargo)
      if (!addEmbarkedUnit(m, kind, 'egypt', transports[i]))
        throw new Error(`罗马运兵船载员部署失败 ${kind}`);
  for (const u of m.units) if (u.team === 'egypt' && isRomanLine(u)) u.formed = false;
  for (let r = 21; r <= 37; r++) for (let c = 40; c <= 59; c++)
    if ((c * 7 + r * 11) % 9 < 2 && distance({ c, r }, m.victory.harbor) > 1)
      setHouse(m, c, r);
  validateMap(m); return m;
}
export function alesiaMap() {
  const m = newMap(80, 52), center = { c: 40, r: 26 };
  m.scenarioId = 'alesia'; m.name = '凯撒围攻阿莱西亚';
  m.factions = { egypt: '罗马', coalition: '高卢' };
  m.unitNames = {
    'egypt:scipio': '凯撒', 'egypt:engineer': '罗马工兵',
    'egypt:romanLegion': '罗马军团重步兵', 'egypt:romanVelites': '罗马轻步兵',
    'egypt:romanArcher': '罗马弓箭手', 'coalition:hannibal': '维钦托利',
    'coalition:gaulInfantry': '高卢战士', 'coalition:archer': '高卢弓手',
    'coalition:cavalry': '高卢骑兵',
  };
  const ring = radius => {
    const cells = [];
    for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++)
      if (distance(center, { c, r }) === radius) cells.push([c, r]);
    return cells.sort((a, b) => Math.atan2(a[1] - center.r, a[0] - center.c) -
      Math.atan2(b[1] - center.r, b[0] - center.c));
  };
  const inner = ring(8), outer = ring(12);
  m.victory = { mode: 'alesia', center, inner, outer, turnLimit: 24 };
  m.intro = '阿莱西亚城有完整的三级城墙、城内步兵与骑兵，罗马军团难以直接攻破。罗马以军团与弓箭手围困，须坚守24回合，阻止城内外高卢军在双层工事间会合；两道罗马工事开局各完成一半。工兵可新建和快速修复，普通士兵只能修复尚存的破损工事。外援第8回合起逐轮增加。';
  m.landmarks = [
    { c: 40, r: 26, label: '阿莱西亚城内 · 高卢守军' },
    { c: 45, r: 26, label: '阿莱西亚城墙' },
    { c: 48, r: 26, label: '罗马内向围困工事' },
    { c: 52, r: 26, label: '罗马外向防援工事' },
    { c: 57, r: 26, label: '高卢援军来向' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    const d = distance(center, { c, r });
    if (d <= 4 && (c * 3 + r * 5) % 7 === 0) setTerrain(m, c, r, TERRAIN.MOUNTAIN);
    else if (d > 12 && d < 17 && (c * 11 + r * 7) % 17 === 0) setTerrain(m, c, r, TERRAIN.MOUNTAIN);
  }
  for (const path of [
    [{ c: 40, r: 26 }, { c: 40, r: 8 }],
    [{ c: 40, r: 26 }, { c: 60, r: 26 }],
    [{ c: 40, r: 26 }, { c: 23, r: 26 }],
  ]) drawRoad(m, path);
  for (let r = center.r - 3; r <= center.r + 3; r++) for (let c = center.c - 3; c <= center.c + 3; c++)
    if (distance(center, { c, r }) <= 3 && (c * 3 + r) % 4 === 0 &&
        tile(m, c, r).terrain === TERRAIN.PLAIN) setHouse(m, c, r);
  for (const [c, r] of ring(5))
    if (!setFort(m, c, r, 3, 'coalition', '阿莱西亚城墙'))
      throw new Error('阿莱西亚城墙部署失败');
  for (const [name, cells] of [['内环', inner], ['外环', outer]]) {
    const sectorLength = cells.length / 8;
    for (let i = 0; i < cells.length; i++) if (Math.floor(i / sectorLength) % 2 === 0) {
      const [c, r] = cells[i];
      if (!setFort(m, c, r, 1, 'egypt', `阿莱西亚${name}`)) throw new Error('阿莱西亚工事部署失败');
    }
  }
  const place = (kind, team, c, r, origin = null) => {
    if (!addUnit(m, kind, team, c, r)) throw new Error(`阿莱西亚部队部署失败 ${kind} ${c},${r}`);
    if (origin) mobileAt(m, c, r).alesiaOrigin = origin;
  };
  place('scipio', 'egypt', 50, 25);
  for (const [i, [c, r]] of ring(9).entries()) if (i % 3 === 0)
    place('romanLegion', 'egypt', c, r);
  for (const [i, [c, r]] of ring(11).entries()) if (i % 3 === 0)
    place(i % 2 ? i % 4 === 3 ? 'romanArcher' : 'romanVelites' : 'romanLegion', 'egypt', c, r);
  for (const [i, [c, r]] of ring(9).entries()) if (i % 12 === 2)
    place('engineer', 'egypt', c, r);
  for (const [i, [c, r]] of ring(11).entries()) if (i % 12 === 2)
    place('engineer', 'egypt', c, r);
  for (const [i, [c, r]] of ring(10).entries()) if (i % 8 === 4)
    place('romanArcher', 'egypt', c, r);
  place('hannibal', 'coalition', 40, 26, 'inner');
  const cavalrySites = ring(4).filter(([c, r]) =>
    !(tile(m, c, r).terrain & TERRAIN.MOUNTAIN) || !!(tile(m, c, r).terrain & TERRAIN.ROAD));
  for (let i = 0; i < 4; i++) {
    const [c, r] = cavalrySites[Math.floor(i * cavalrySites.length / 4)];
    place('cavalry', 'coalition', c, r, 'inner');
  }
  for (const [i, [c, r]] of ring(5).entries()) if (i % 3 === 0)
    place(i % 2 ? 'gaulInfantry' : 'archer', 'coalition', c, r, 'inner');
  for (const [i, [c, r]] of ring(7).entries()) if (i % 7 === 0)
    place('gaulInfantry', 'coalition', c, r, 'inner');
  const arrivalRing = ring(17);
  m.reinforcements = Array.from({ length: 17 }, (_, i) => {
    const count = i + 1;
    return { turn: i + 8, team: 'coalition', label: `高卢外部援军第 ${i + 1} 批`,
      units: Array.from({ length: count }, (_, j) => {
        const [c, r] = arrivalRing[(i * 13 + j * 5) % arrivalRing.length];
        return { kind: j % 5 === 4 ? 'cavalry' : j % 4 === 3 ? 'archer' : 'gaulInfantry',
          c, r, alesiaOrigin: 'outer' };
      }) };
  });
  validateMap(m); return m;
}

// Schematic battlefield: the exact location and orientation relative to the
// Enipeus are disputed. The river marks the constrained flank, not survey data.
export function pharsalusMap() {
  const m = newMap(80, 52);
  m.scenarioId = 'pharsalus';
  m.name = '法萨卢斯会战 · 第四线反击';
  m.factions = { egypt: '恺撒军', coalition: '庞培军' };
  m.unitNames = {
    'egypt:scipio': '盖乌斯·尤利乌斯·恺撒',
    'coalition:hannibal': '格奈乌斯·庞培',
    'egypt:romanLegion': '恺撒老兵军团',
    'egypt:caesarReserve': '第四线精锐军团',
    'egypt:romanHorse': '恺撒骑兵',
    'egypt:romanVelites': '恺撒轻步兵',
    'coalition:pompeyLegion': '庞培军团',
    'coalition:pompeyHorse': '庞培同盟骑兵',
    'coalition:punicSkirmisher': '庞培弓手与投石兵',
  };
  m.victory = { mode: 'pharsalus', caesarLosses: 16, pompeyLosses: 22, turnLimit: 20 };
  m.intro = '公元前48年法萨卢斯会战战术示意。恺撒以较少军团迎击兵力约为其两倍的庞培，抽出第四线应对庞培在一翼集中的骑兵。任一方击溃敌军四分之三获胜；第20回合比较损失比例。河道、阵位与棋子数量均为游戏抽象，并非精确战场测绘。';
  m.landmarks = [
    { c: 18, r: 26, label: '恺撒营地方向' },
    { c: 33, r: 14, label: '恺撒第四线预备队' },
    { c: 42, r: 28, label: '法萨卢斯主战场' },
    { c: 55, r: 11, label: '庞培骑兵集结翼' },
    { c: 62, r: 27, label: '庞培营地方向' },
    { c: 43, r: 47, label: '埃尼佩乌斯河 · 示意' },
  ];
  for (let c = 6; c < 74; c++) {
    const r = 47 + Math.round(Math.sin(c * 0.13));
    setTerrain(m, c, r, TERRAIN.RIVER);
  }
  drawRoad(m, [{ c: 12, r: 27 }, { c: 27, r: 27 }, { c: 42, r: 27 },
    { c: 57, r: 27 }, { c: 70, r: 27 }]);
  for (const [c, r, team, city] of [
    [17, 26, 'egypt', '恺撒营地'], [18, 26, 'egypt', '恺撒营地'],
    [64, 26, 'coalition', '庞培营地'], [65, 26, 'coalition', '庞培营地'],
  ]) if (!setFort(m, c, r, 1, team, city)) throw new Error('法萨卢斯营垒布设失败');
  const caesarians = [
    ['scipio', 27, 27],
    ...Array.from({ length: 10 }, (_, i) => ['romanLegion', 35, 19 + i * 2]),
    ...Array.from({ length: 9 }, (_, i) => ['romanLegion', 32, 20 + i * 2]),
    ...[[32,12],[33,13],[33,15],[34,16]].map(([c,r]) => ['caesarReserve', c, r]),
    ...[[31,9],[33,9],[35,10]].map(([c,r]) => ['romanHorse', c, r]),
    ...[[38,21],[38,25],[38,29],[38,33]].map(([c,r]) => ['romanVelites', c, r]),
  ];
  const pompeians = [
    ['hannibal', 55, 29],
    ...Array.from({ length: 14 }, (_, i) => ['pompeyLegion', 43, 17 + i * 2]),
    ...Array.from({ length: 12 }, (_, i) => ['pompeyLegion', 46, 19 + i * 2]),
    ...Array.from({ length: 9 }, (_, i) => ['pompeyLegion', 49, 18 + i * 2]),
    ...Array.from({ length: 9 }, (_, i) => ['pompeyLegion', 52, 19 + i * 2]),
    ...[[44,9],[46,9],[48,9],[50,9],[52,9],[45,12],[47,12],[49,12],[51,12],[53,12]].map(([c,r]) => ['pompeyHorse', c, r]),
    ...[[41,19],[41,23],[41,27],[41,31],[41,35]].map(([c,r]) => ['punicSkirmisher', c, r]),
  ];
  for (const [kind,c,r] of caesarians)
    if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`恺撒军部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of pompeians)
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`庞培军部署失败 ${kind} ${c},${r}`);
  for (const u of m.units) if (isRomanLine(u)) u.facing = u.team === 'egypt' ? 0 : 3;
  validateMap(m); return m;
}

// Actium's gulf entrance and the fleets are drawn as a playable schematic.
// Ship counters are squadrons; ancient fleet totals and exact tracks vary by source.
export function actiumMap() {
  const m = newMap(70, 48);
  m.scenarioId = 'actium';
  m.name = '亚克兴角海战 · 封锁与突围';
  m.factions = { egypt: '屋大维·阿格里帕舰队', coalition: '安东尼·克娄巴特拉舰队' };
  m.unitNames = {
    'egypt:octavianLiburnian': '屋大维轻型战船',
    'coalition:antonyHeavyGalley': '安东尼重型战船',
    'coalition:cleopatraGalley': '埃及快速战船',
  };
  m.victory = { mode: 'actium', escape: { cMax: 12, rMin: 12, rMax: 36 },
    escortShips: 3, octavianLosses: 11, antonyLosses: 12, turnLimit: 18 };
  m.intro = '公元前31年亚克兴角海战战术示意。屋大维与阿格里帕的舰队封锁安布拉基亚湾出口；安东尼重舰掩护克娄巴特拉的埃及舰队。任一方击溃敌舰四分之三获胜；安东尼也可护送两艘指挥舰及3支护航舰突围，屋大维可封锁至第18回合。';
  m.landmarks = [
    { c: 10, r: 24, label: '爱奥尼亚海 · 突围出口' },
    { c: 29, r: 25, label: '屋大维舰队封锁线' },
    { c: 41, r: 15, label: '尼科波利斯方向' },
    { c: 42, r: 25, label: '安布拉基亚湾入口' },
    { c: 42, r: 36, label: '亚克兴角' },
    { c: 55, r: 25, label: '埃及舰队后队' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    const water = c < 40 ? r >= 6 && r <= 42 :
      c <= 44 ? r >= 20 && r <= 31 : r >= 17 && r <= 35;
    const coast = c < 40 ? r === 5 || r === 43 :
      c <= 44 ? r === 19 || r === 32 : r === 16 || r === 36;
    m.terrain[index(m, c, r)] = water ? TERRAIN.SEA : coast ? TERRAIN.BEACH : TERRAIN.PLAIN;
  }
  const octavian = [
    ...Array.from({ length: 10 }, (_, i) => ['octavianLiburnian', 32, 13 + i * 2]),
    ...Array.from({ length: 10 }, (_, i) => ['octavianLiburnian', 36, 14 + i * 2]),
    ...[[39,22],[39,26],[39,30]].map(([c,r]) => ['octavianLiburnian', c, r]),
  ];
  const antony = [
    ...Array.from({ length: 8 }, (_, i) => ['antonyHeavyGalley', 45, 19 + i * 2]),
    ...Array.from({ length: 8 }, (_, i) => ['antonyHeavyGalley', 49, 19 + i * 2]),
    ...Array.from({ length: 8 }, (_, i) => ['antonyHeavyGalley', 53, 19 + i * 2]),
    ...[[55,20],[55,22],[55,24],[55,26],[55,28],[55,30]].map(([c,r]) => ['cleopatraGalley', c, r]),
  ];
  for (const [kind,c,r] of octavian)
    if (!addUnit(m, kind, 'egypt', c, r)) throw new Error(`屋大维舰队部署失败 ${c},${r}`);
  for (const [kind,c,r] of antony)
    if (!addUnit(m, kind, 'coalition', c, r)) throw new Error(`安东尼舰队部署失败 ${c},${r}`);
  for (const [c,r,name] of [[32,25,'屋大维'], [36,24,'阿格里帕'],
    [45,23,'安东尼'], [55,26,'克娄巴特拉']]) {
    const ship = mobileAt(m,c,r);
    if (!ship) throw new Error(`亚克兴角指挥舰部署失败 ${name}`);
    ship.commander = name;
  }
  for (const u of m.units) u.facing = u.team === 'egypt' ? 0 : 3;
  validateMap(m); return m;
}

// The road, wooded ridges and bog are a tactical diagram, not a surveyed
// reconstruction of the debated Varus battlefield.
export function teutoburgMap() {
  const m = newMap(72, 48);
  m.scenarioId = 'teutoburg';
  m.name = '条顿森林之战 · 林道伏击';
  m.factions = { egypt: '瓦卢斯罗马纵队', coalition: '阿尔米尼乌斯日耳曼联军' };
  m.unitNames = {
    'egypt:scipio': '普布利乌斯·昆克蒂利乌斯·瓦卢斯',
    'egypt:romanLegion': '罗马军团纵队',
    'egypt:romanVelites': '罗马辅助步兵',
    'egypt:romanHorse': '罗马骑兵',
    'coalition:hannibal': '阿尔米尼乌斯',
    'coalition:gaulInfantry': '日耳曼部族战士',
    'coalition:punicSkirmisher': '日耳曼投射兵',
  };
  m.victory = { mode: 'teutoburg', escape: { cMax: 10, rMin: 20, rMax: 28 },
    escapeUnits: 8, romanLosses: 15, germanLosses: 18, turnLimit: 18 };
  m.intro = '公元9年瓦卢斯军团遭阿尔米尼乌斯联军伏击的战术示意。罗马护送瓦卢斯与8支部队向西突围，或击溃伏击军四分之三；日耳曼军击杀瓦卢斯、击溃罗马军四分之三，或阻断道路至第18回合获胜。林地山坡遮挡视线并拖慢行军，前三回合林中近战伏击有加成。地点、道路、沼泽和回合数均为玩法抽象。';
  m.landmarks = [
    { c: 9, r: 24, label: '西侧道路 · 撤离出口' },
    { c: 24, r: 18, label: '北侧密林' },
    { c: 40, r: 24, label: '罗马行军纵队' },
    { c: 24, r: 34, label: '低地沼泽' },
    { c: 54, r: 18, label: '日耳曼伏击翼' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    let terrain = TERRAIN.PLAIN;
    if (c >= 11 && c <= 64 && (r <= 20 || r >= 29)) terrain = TERRAIN.MOUNTAIN;
    if (c >= 12 && c <= 35 && r >= 34 && r <= 43) terrain = TERRAIN.RIVER;
    if (c >= 8 && c <= 65 && r >= 23 && r <= 25) terrain = TERRAIN.ROAD;
    m.terrain[index(m, c, r)] = terrain;
  }
  const roman = [
    ...Array.from({ length: 9 }, (_, i) => ['romanLegion', 28 + 3 * i, 23]),
    ...Array.from({ length: 9 }, (_, i) => ['romanLegion', 28 + 3 * i, 25]),
    ...Array.from({ length: 6 }, (_, i) => ['romanVelites', 26 + 5 * i, 24]),
    ...[[29,26],[43,26],[55,26]].map(([c,r]) => ['romanHorse',c,r]),
    ['scipio',50,24],
  ];
  const germans = [
    ...Array.from({ length: 9 }, (_, i) => ['gaulInfantry', 22 + 4 * i, 20]),
    ...Array.from({ length: 9 }, (_, i) => ['gaulInfantry', 24 + 4 * i, 29]),
    ...Array.from({ length: 6 }, (_, i) => ['punicSkirmisher', 20 + 6 * i, 17]),
    ...Array.from({ length: 6 }, (_, i) => ['punicSkirmisher', 23 + 6 * i, 31]),
    ['hannibal',58,18],
  ];
  for (const [kind,c,r] of roman) if (!addUnit(m,kind,'egypt',c,r))
    throw new Error(`罗马纵队部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of germans) if (!addUnit(m,kind,'coalition',c,r))
    throw new Error(`日耳曼联军部署失败 ${kind} ${c},${r}`);
  for (const u of m.units) u.facing = u.team === 'egypt' ? 3 : u.r < 24 ? 5 : 1;
  validateMap(m); return m;
}

// Jerusalem's northern defensive belts, Antonia and the Temple precinct are
// arranged for play. Josephus' three walls were not three concentric rings.
export function jerusalemMap() {
  const m = newMap(82, 60);
  m.scenarioId = 'jerusalem';
  m.name = '耶路撒冷围城战 · 三道城墙';
  m.factions = { egypt: '提图斯罗马攻城军', coalition: '耶路撒冷守军' };
  m.unitNames = {
    'egypt:scipio': '提图斯',
    'egypt:romanLegion': '罗马军团重步兵',
    'egypt:romanVelites': '罗马辅助步兵',
    'egypt:romanArcher': '罗马弓手',
    'egypt:romanOnager': '罗马扭力抛石机',
    'egypt:siegeRam': '罗马撞城槌车',
    'egypt:siegeTower': '罗马大型攻城塔',
    'egypt:engineer': '罗马工兵',
    'coalition:hannibal': '西门·巴尔·吉奥拉',
    'coalition:africanInfantry': '犹太守城重步兵',
    'coalition:iberianInfantry': '犹太守城步兵',
    'coalition:punicSkirmisher': '犹太投石兵',
    'coalition:archer': '犹太城墙弓手',
  };
  m.victory = { mode: 'jerusalem', romanLosses: 28, turnLimit: 50, stages: [
    { name: '新城', c: 42, r: 25, walls: ['第三道城墙'] },
    { name: '中城', c: 48, r: 35, walls: ['第二道城墙'] },
    { name: '安东尼亚堡', c: 60, r: 37, walls: ['安东尼亚堡'] },
    { name: '圣殿区', c: 65, r: 48, walls: ['第一道城墙', '圣殿区围墙'] },
    { name: '上城', c: 44, r: 49, walls: ['第一道城墙'] },
  ] };
  m.intro = '维斯帕芗先于公元67年起指挥犹太战争，公元70年耶路撒冷围城由其子提图斯指挥。本图将北面的第三、第二、第一道城墙、安东尼亚堡、圣殿区和上城压缩为五阶段攻城战。罗马有大型攻城塔、撞城槌和扭力抛石机。道路、兵数及防线位置是玩法抽象，不是遗址测绘。';
  m.landmarks = [
    { c: 45, r: 9, label: '提图斯攻城阵地' },
    { c: 42, r: 19, label: '第三道城墙' },
    { c: 42, r: 25, label: '新城 · 第一目标' },
    { c: 48, r: 31, label: '第二道城墙' },
    { c: 48, r: 35, label: '中城 · 第二目标' },
    { c: 60, r: 37, label: '安东尼亚堡' },
    { c: 47, r: 43, label: '第一道城墙' },
    { c: 65, r: 48, label: '圣殿区' },
    { c: 44, r: 49, label: '上城 · 最终目标' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if ((c <= 12 || c >= 78) && r >= 17 && r <= 56) m.terrain[index(m,c,r)] = TERRAIN.MOUNTAIN;
    if (r >= 55 && c >= 26 && c <= 74) m.terrain[index(m,c,r)] = TERRAIN.MOUNTAIN;
  }
  drawRoad(m, [{ c: 44, r: 7 }, { c: 44, r: 25 }, { c: 48, r: 35 }, { c: 60, r: 37 }]);
  drawRoad(m, [{ c: 48, r: 35 }, { c: 49, r: 44 }, { c: 44, r: 49 }]);
  drawRoad(m, [{ c: 60, r: 37 }, { c: 64, r: 48 }]);
  const wall = (id, cells, level, hp) => {
    for (const [c,r] of cells) {
      if (!setFort(m,c,r,level,'coalition',id)) throw new Error(`耶路撒冷城墙布设失败 ${id} ${c},${r}`);
      fortAt(m,c,r).hp = hp;
    }
  };
  wall('第三道城墙', Array.from({length:55},(_,i)=>[18+i,19]), 2, 200);
  wall('第二道城墙', Array.from({length:47},(_,i)=>[26+i,31]), 2, 240);
  wall('第一道城墙', Array.from({length:42},(_,i)=>[31+i,43]), 3, 320);
  wall('外城侧墙', [...Array.from({length:34},(_,i)=>[18,20+i]),
    ...Array.from({length:34},(_,i)=>[72,20+i])], 2, 200);
  wall('中城侧墙', Array.from({length:21},(_,i)=>[26,32+i]), 2, 220);
  wall('安东尼亚堡', [
    ...Array.from({length:11},(_,i)=>[55+i,33]),
    ...Array.from({length:11},(_,i)=>[55+i,40]),
    ...Array.from({length:6},(_,i)=>[55,34+i]),
    ...Array.from({length:6},(_,i)=>[65,34+i])], 2, 220);
  wall('圣殿区围墙', [
    ...Array.from({length:14},(_,i)=>[58+i,45]),
    ...Array.from({length:14},(_,i)=>[58+i,53]),
    ...Array.from({length:7},(_,i)=>[58,46+i]),
    ...Array.from({length:7},(_,i)=>[71,46+i])], 3, 300);
  for (let r = 23; r <= 51; r += 4) for (let c = 33; c <= 69; c += 5)
    if (tile(m,c,r).terrain === TERRAIN.PLAIN && !fortAt(m,c,r) &&
        !m.victory.stages.some(p=>p.c===c&&p.r===r) && (c*3+r)%4!==0) setHouse(m,c,r);
  const romans = [
    ...Array.from({length:10},(_,i)=>['romanLegion',24+i*4,8]),
    ...Array.from({length:10},(_,i)=>['romanLegion',24+i*4,11]),
    ...[[25,16],[33,16],[41,16],[49,16],[57,16]].map(([c,r])=>['romanLegion',c,r]),
    ...Array.from({length:8},(_,i)=>['romanArcher',26+i*5,9]),
    ...[[28,15],[36,15],[44,15],[52,15],[60,15]].map(([c,r])=>['romanVelites',c,r]),
    ...[[36,6],[44,6],[52,6]].map(([c,r])=>['romanOnager',c,r]),
    ...[[36,13],[56,13]].map(([c,r])=>['siegeTower',c,r]),
    ...[[44,13],[48,13],[52,13]].map(([c,r])=>['siegeRam',c,r]),
    ...[[27,10],[39,10],[51,10],[63,10]].map(([c,r])=>['engineer',c,r]),
    ['scipio',48,7],
  ];
  const defenders = [
    ...[[25,19],[30,19],[35,19],[40,19],[45,19],[50,19],[55,19],[60,19],[65,19]].map(([c,r])=>['archer',c,r]),
    ...[[32,31],[39,31],[46,31],[53,31],[60,31],[67,31]].map(([c,r])=>['archer',c,r]),
    ...[[37,43],[44,43],[51,43],[68,43]].map(([c,r])=>['archer',c,r]),
    ...Array.from({length:9},(_,i)=>['iberianInfantry',31+i*4,26]),
    ...Array.from({length:9},(_,i)=>['africanInfantry',31+i*4,37]),
    ...[[35,47],[40,47],[45,47],[50,47],[54,47],[61,48],[68,48]].map(([c,r])=>['africanInfantry',c,r]),
    ...[[29,23],[34,23],[55,26],[64,27],[34,35],[42,35],[51,35],[63,41]].map(([c,r])=>['punicSkirmisher',c,r]),
    ['hannibal',48,50],
  ];
  for (const [kind,c,r] of romans) if (!addUnit(m,kind,'egypt',c,r))
    throw new Error(`罗马攻城军部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of defenders) if (!addUnit(m,kind,'coalition',c,r))
    throw new Error(`耶路撒冷守军部署失败 ${kind} ${c},${r}`);
  validateMap(m); return m;
}

export function carrhaeMap() {
  const m = newMap(66, 42);
  m.scenarioId = 'carrhae'; m.name = '卡莱之战 · 骑射与包围';
  m.factions = { egypt: '克拉苏罗马军', coalition: '苏雷纳帕提亚军' };
  m.unitNames = {
    'egypt:scipio':'马库斯·李锡尼·克拉苏',
    'egypt:romanLegion':'罗马军团重步兵',
    'egypt:romanArcher':'罗马弓手',
    'egypt:romanVelites':'罗马轻步兵',
    'egypt:romanHorse':'罗马骑兵',
    'coalition:hannibal':'苏雷纳',
    'coalition:parthianHorseArcher':'帕提亚骑射手',
    'coalition:parthianCataphract':'帕提亚具装骑兵',
    'coalition:arrowCamel':'驮箭骆驼',
  };
  m.victory = { mode:'carrhae', escape:{cMax:6,rMin:14,rMax:28},
    escapeUnits:10, romanLosses:24, parthianLosses:8, turnLimit:24 };
  m.intro = '前53年，克拉苏罗马军与苏雷纳的帕提亚骑兵在卡莱附近交战。骑射手可在脱离相邻罗马军后回射；驮箭骆驼为两格内骑射手补箭。罗马军可护送克拉苏和十支部队向西撤离，或击溃帕提亚骑兵。地图与兵数是战术抽象。';
  m.landmarks = [
    {c:5,r:21,label:'西侧撤退通道'},
    {c:26,r:21,label:'罗马方阵'},
    {c:51,r:18,label:'帕提亚骑射线'},
    {c:55,r:22,label:'驮箭骆驼补给地'},
  ];
  for (let c=0;c<=19;c++) m.terrain[index(m,c,21)] = TERRAIN.ROAD;
  for (let c=8;c<=13;c++) for (let r=5;r<=10;r++)
    if ((c+r)%3===0) m.terrain[index(m,c,r)] = TERRAIN.MOUNTAIN;
  for (let c=12;c<=17;c++) for (let r=32;r<=37;r++)
    if ((c+r)%3===1) m.terrain[index(m,c,r)] = TERRAIN.MOUNTAIN;
  const romans = [
    ...Array.from({length:9},(_,i)=>['romanLegion',19+i*2,17]),
    ...Array.from({length:9},(_,i)=>['romanLegion',20+i*2,21]),
    ...Array.from({length:7},(_,i)=>['romanLegion',22+i*2,25]),
    ...[[18,19],[22,19],[26,19],[30,19],[34,19],[27,27]].map(([c,r])=>['romanArcher',c,r]),
    ...[[20,15],[24,15],[28,15],[32,15]].map(([c,r])=>['romanVelites',c,r]),
    ...[[17,24],[19,26],[21,28],[24,29],[27,29]].map(([c,r])=>['romanHorse',c,r]),
    ['scipio',22,23],
  ];
  const parthians = [
    ...Array.from({length:4},(_,i)=>['parthianHorseArcher',18+i*8,10]),
    ...Array.from({length:4},(_,i)=>['parthianHorseArcher',18+i*8,33]),
    ...[[49,17],[49,25]].map(([c,r])=>['parthianCataphract',c,r]),
    ...[[31,8],[31,35]].map(([c,r])=>['arrowCamel',c,r]),
    ['hannibal',60,21],
  ];
  for (const [kind,c,r] of romans) if (!addUnit(m,kind,'egypt',c,r))
    throw new Error(`卡莱罗马军部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of parthians) if (!addUnit(m,kind,'coalition',c,r))
    throw new Error(`卡莱帕提亚军部署失败 ${kind} ${c},${r}`);
  validateMap(m); return m;
}

// Playable coastal siege schematic: land assault, seaward engines, and two successive breaches.
export function syracuseMap() {
  const m = newMap(72, 48);
  m.scenarioId = 'syracuse'; m.name = '叙拉古围城战 · 阿基米德的防线';
  m.factions = { egypt: '马塞卢斯罗马军', coalition: '叙拉古守军' };
  m.unitNames = {
    'egypt:scipio': '马库斯·克劳狄乌斯·马塞卢斯',
    'egypt:romanLegion': '罗马军团', 'egypt:romanVelites': '罗马轻兵',
    'egypt:romanArcher': '罗马弓手', 'egypt:siegeGalley': '罗马舰载攻城器械船',
    'egypt:romanOnager': '罗马扭力抛石机', 'egypt:siegeRam': '罗马撞城槌车',
    'coalition:hannibal': '叙拉古守军指挥官',
    'coalition:defenseTower': '阿基米德机械塔',
    'coalition:africanInfantry': '叙拉古重步兵',
    'coalition:iberianInfantry': '叙拉古守城步兵',
    'coalition:archer': '叙拉古城墙弓手',
    'coalition:punicSkirmisher': '叙拉古投射兵',
    'coalition:phoenicianTrireme': '叙拉古战船',
  };
  m.victory = { mode: 'syracuse', capture: { c: 47, r: 25 },
    walls: ['厄庇波莱外墙', '阿克拉迪纳内墙'], romanLosses: 20, turnLimit: 36 };
  m.intro = '前213—前212年叙拉古围城战。罗马从陆地及海上进攻，阿基米德设计的投射机械和抓船装置强化了守军。破坏外墙与内墙各至少一段，再占领黄色目标；海岸、街区和兵数均为游戏示意。';
  m.landmarks = [
    { c: 14, r: 25, label: '罗马陆上攻城营' },
    { c: 31, r: 24, label: '厄庇波莱外墙' },
    { c: 39, r: 25, label: '阿克拉迪纳内墙' },
    { c: 47, r: 25, label: '叙拉古城心 · 占领目标' },
    { c: 56, r: 29, label: '海墙与守城机械' },
    { c: 64, r: 24, label: '罗马攻城舰队' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if (c >= 58 || (c >= 55 && r <= 9)) setTerrain(m,c,r,TERRAIN.SEA);
    else if (c === 57 && r >= 10) setTerrain(m,c,r,TERRAIN.BEACH);
    else if (c < 10 && (r < 10 || r > 37)) setTerrain(m,c,r,TERRAIN.MOUNTAIN);
  }
  drawRoad(m,[{c:12,r:25},{c:31,r:25},{c:39,r:25},{c:47,r:25},{c:55,r:25}]);
  const wall = (id,c,r0,r1,level) => {
    for (let r=r0;r<=r1;r++) if (!setFort(m,c,r,level,'coalition',id))
      throw new Error(`叙拉古城墙部署失败 ${id} ${c},${r}`);
  };
  wall('厄庇波莱外墙',31,10,39,2);
  wall('阿克拉迪纳内墙',39,15,35,2);
  wall('海墙',55,10,39,2);
  for (let c=31;c<=55;c++) for (let r of [10,39])
    if (!setFort(m,c,r,2,'coalition','城侧墙')) throw new Error('叙拉古侧墙部署失败');
  for (let r=17;r<=36;r+=4) for (let c=35;c<=52;c+=4)
    if (!fortAt(m,c,r) && !(c===47 && r===25) && (c+r)%3) setHouse(m,c,r);
  const romans = [
    ['scipio',13,25],
    ...Array.from({length:7},(_,i)=>['romanLegion',18+i*2,13]),
    ...Array.from({length:7},(_,i)=>['romanLegion',18+i*2,34]),
    ...Array.from({length:7},(_,i)=>['romanLegion',22,18+i*3]),
    ...[[16,18],[16,23],[16,28],[16,33]].map(([c,r])=>['romanArcher',c,r]),
    ...[[24,19],[24,31],[26,25],[19,25]].map(([c,r])=>['romanVelites',c,r]),
    ...[[20,21],[20,29]].map(([c,r])=>['romanOnager',c,r]),
    ...[[27,23],[27,27]].map(([c,r])=>['siegeRam',c,r]),
    ...[[63,18],[63,24],[63,30]].map(([c,r])=>['siegeGalley',c,r]),
  ];
  const defenders = [
    ['hannibal',48,27],
    ...[[55,16],[55,24],[55,32]].map(([c,r])=>['defenseTower',c,r]),
    ...[[31,15],[31,21],[31,29],[31,35],[39,19],[39,25],[39,31]].map(([c,r])=>['archer',c,r]),
    ...[[35,18],[35,25],[35,32],[44,18],[44,32],[49,21],[49,29]].map(([c,r])=>['iberianInfantry',c,r]),
    ...[[43,23],[43,27],[47,20],[47,30],[52,25]].map(([c,r])=>['africanInfantry',c,r]),
    ...[[33,23],[36,28],[42,19],[51,34]].map(([c,r])=>['punicSkirmisher',c,r]),
    ...[[60,12],[60,36]].map(([c,r])=>['phoenicianTrireme',c,r]),
  ];
  for (const [kind,c,r] of romans) if (!addUnit(m,kind,'egypt',c,r))
    throw new Error(`叙拉古罗马军部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of defenders) if (!addUnit(m,kind,'coalition',c,r))
    throw new Error(`叙拉古守军部署失败 ${kind} ${c},${r}`);
  validateMap(m); return m;
}

// The phalanx begins on open ground; broken foothills create the vulnerable gaps.
export function pydnaMap() {
  const m = newMap(66, 44);
  m.scenarioId = 'pydna'; m.name = '彼得那会战 · 崎岖地形与方阵缺口';
  m.factions = { egypt: '埃米利乌斯·保卢斯罗马军', coalition: '珀尔修斯马其顿军' };
  m.unitNames = {
    'egypt:scipio': '卢基乌斯·埃米利乌斯·保卢斯',
    'egypt:romanLegion': '罗马军团重步兵', 'egypt:romanVelites': '罗马投枪轻兵',
    'egypt:romanHorse': '罗马骑兵', 'egypt:romanAlliedHorse': '同盟骑兵',
    'coalition:hannibal': '马其顿王珀尔修斯',
    'coalition:phalangite': '马其顿长枪方阵',
    'coalition:companionCavalry': '马其顿骑兵',
    'coalition:archer': '马其顿弓手',
    'coalition:light': '马其顿轻步兵',
  };
  m.victory = { mode:'pydna', romanLosses: 16, macedonianLosses: 18, turnLimit: 20 };
  m.intro = '前168年彼得那会战。马其顿长枪方阵在平地正面强大；进入起伏山麓后阵线出现空隙，罗马重步兵在崎岖地形攻击方阵获得额外伤害。道路、溪流与兵数为游戏示意。';
  m.landmarks = [
    {c:15,r:22,label:'保卢斯罗马军'}, {c:30,r:22,label:'崎岖山麓 · 方阵缺口'},
    {c:43,r:22,label:'珀尔修斯长枪方阵'}, {c:56,r:36,label:'彼得那方向'},
  ];
  for (let r=5;r<=38;r++) for (let c=28;c<=34;c++)
    if ((c*2+r)%5<2) setTerrain(m,c,r,TERRAIN.MOUNTAIN);
  for (let c=8;c<=56;c++) setTerrain(m,c,40,TERRAIN.RIVER);
  drawRoad(m,[{c:8,r:22},{c:27,r:22},{c:42,r:22},{c:57,r:22}]);
  const romans = [
    ['scipio',12,22],
    ...Array.from({length:11},(_,i)=>['romanLegion',20,10+i*2]),
    ...Array.from({length:9},(_,i)=>['romanLegion',17,12+i*2]),
    ...[[23,12],[23,18],[23,24],[23,30]].map(([c,r])=>['romanVelites',c,r]),
    ...[[17,6],[20,6],[17,36],[20,36]].map(([c,r])=>['romanHorse',c,r]),
    ...[[13,8],[13,34]].map(([c,r])=>['romanAlliedHorse',c,r]),
  ];
  const macedonians = [
    ['hannibal',53,22],
    ...Array.from({length:13},(_,i)=>['phalangite',39,9+i*2]),
    ...Array.from({length:11},(_,i)=>['phalangite',43,11+i*2]),
    ...Array.from({length:10},(_,i)=>['phalangite',47,10+i*3]),
    ...[[46,6],[49,6],[46,36],[49,36]].map(([c,r])=>['companionCavalry',c,r]),
    ...[[45,17],[45,23],[45,29]].map(([c,r])=>['archer',c,r]),
    ...[[36,12],[36,20],[36,28],[36,34]].map(([c,r])=>['light',c,r]),
  ];
  for (const [kind,c,r] of romans) if (!addUnit(m,kind,'egypt',c,r))
    throw new Error(`彼得那罗马军部署失败 ${kind} ${c},${r}`);
  for (const [kind,c,r] of macedonians) if (!addUnit(m,kind,'coalition',c,r))
    throw new Error(`彼得那马其顿军部署失败 ${kind} ${c},${r}`);
  for (const u of m.units) if (isRomanLine(u) || isPhalangite(u)) u.facing = u.team === 'egypt' ? 0 : 3;
  validateMap(m); return m;
}
