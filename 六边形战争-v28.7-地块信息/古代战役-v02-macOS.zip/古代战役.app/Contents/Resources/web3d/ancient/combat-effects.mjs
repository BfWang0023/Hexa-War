import * as THREE from '../vendor/three/three.module.js';
import { offsetToWorld } from '../js/core/hex.js';
import { fortAt, fmt } from './engine.mjs';
import { terrainHeight } from './terrain.mjs';

const forward = new THREE.Vector3(0, 0, 1);
const clamp = value => Math.max(0, Math.min(1, value));
const ease = value => 1 - (1 - value) ** 3;

function worldPoint(map, cell, kind) {
  const p = offsetToWorld(cell.c, cell.r);
  const wall = fortAt(map, cell.c, cell.r);
  const wallHeight = kind !== 'fort' && wall ? [0, 1.75, 2.6, 3.5][wall.level] : 0;
  const figureHeight = kind === 'fort' ? 1.8 : ['warship', 'transport'].includes(kind) || kind.endsWith('Trireme') ? 1.35 : 2.8;
  return new THREE.Vector3(p.x, terrainHeight(map, cell.c, cell.r) + wallHeight + figureHeight, p.z);
}

function projectile(kind) {
  const spear = ['hero', 'hittiteChariot', 'romanVelites', 'numidianHorse', 'masinissa', 'masinissaHorse'].includes(kind);
  const group = new THREE.Group();
  if (kind === 'punicSkirmisher') {
    const stone = new THREE.Mesh(new THREE.DodecahedronGeometry(.22, 0),
      new THREE.MeshStandardMaterial({ color: 0xb9a478, roughness: 1 }));
    group.add(stone); return group;
  }
  const wood = new THREE.MeshStandardMaterial({ color: 0x69462c, roughness: 1 });
  const bronze = new THREE.MeshStandardMaterial({ color: 0xd7b06b, metalness: .35, roughness: .52 });
  const feather = new THREE.MeshStandardMaterial({ color: 0xe9ddbd, roughness: 1 });
  const length = spear ? 3.1 : 2.15;
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(spear ? .065 : .038, spear ? .065 : .038,
    length, 5), wood);
  shaft.rotation.x = Math.PI / 2; group.add(shaft);
  const point = new THREE.Mesh(new THREE.ConeGeometry(spear ? .19 : .12, spear ? .52 : .34, 5), bronze);
  point.rotation.x = Math.PI / 2; point.position.z = length / 2 + (spear ? .23 : .13); group.add(point);
  if (!spear) for (const side of [-1, 1]) {
    const vane = new THREE.Mesh(new THREE.BoxGeometry(.3, .025, .48), feather);
    vane.position.set(side * .13, 0, -length / 2 + .22); vane.rotation.y = side * .35;
    group.add(vane);
  }
  return group;
}

function strikingBlade(kind) {
  const group = new THREE.Group();
  const bronze = new THREE.MeshStandardMaterial({ color: 0xf1cf84, metalness: .45, roughness: .36,
    emissive: 0x4b2d0c, emissiveIntensity: .4 });
  const grip = new THREE.MeshStandardMaterial({ color: 0x53341f, roughness: 1 });
  if (['siegeRam', 'warship'].includes(kind) || kind.endsWith('Trireme')) {
    const head = new THREE.Mesh(new THREE.BoxGeometry(.9, .8, 2.4), grip);
    group.add(head);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(.6, .9, 5), bronze);
    tip.rotation.x = Math.PI / 2; tip.position.z = 1.5; group.add(tip);
  } else if (['cavalry', 'chariot', 'hittiteChariot', 'romanHorse', 'romanAlliedHorse',
    'punicHeavyHorse', 'numidianHorse', 'masinissa', 'masinissaHorse', 'zamaPunicHorse'].includes(kind)) {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(.075, .075, 3.3, 5), grip);
    shaft.rotation.x = Math.PI / 2; group.add(shaft);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(.18, .48, 5), bronze);
    tip.rotation.x = Math.PI / 2; tip.position.z = 1.85; group.add(tip);
  } else {
    const hilt = new THREE.Mesh(new THREE.BoxGeometry(.22, .68, .18), grip);
    hilt.position.y = -.8; group.add(hilt);
    const guard = new THREE.Mesh(new THREE.BoxGeometry(.9, .13, .16), bronze);
    guard.position.y = -.42; group.add(guard);
    const blade = new THREE.Mesh(new THREE.BoxGeometry(.22, 2.25, .12), bronze);
    blade.position.y = .78; group.add(blade);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(.15, .48, 4), bronze);
    tip.position.y = 2.1; group.add(tip);
  }
  return group;
}

function disposeEffect(effect, root) {
  root.remove(effect.group);
  effect.group.traverse(object => {
    object.geometry?.dispose();
    if (object.material) {
      if (Array.isArray(object.material)) object.material.forEach(material => material.dispose());
      else object.material.dispose();
    }
  });
  effect.label.remove();
}

export function createCombatEffects(scene, camera, stage) {
  const root = new THREE.Group(); root.name = 'combat-effects'; scene.add(root);
  const overlay = document.createElement('div'); overlay.id = 'fx-labels'; stage.append(overlay);
  const active = [];

  function clear() {
    while (active.length) disposeEffect(active.pop(), root);
  }

  function play(result, map, delay = 0) {
    if (!result?.ok || !result.visual) return;
    const { visual } = result;
    const start = worldPoint(map, visual.from, visual.attackerKind);
    const target = worldPoint(map, visual.to, visual.defenderKind);
    const direction = target.clone().sub(start);
    const sideways = new THREE.Vector3(-direction.z, 0, direction.x).normalize();
    const end = target.clone().addScaledVector(sideways, result.hit ? 0 : 3.0);
    const group = new THREE.Group(); root.add(group);
    const weapons = [];
    if (visual.melee) {
      const weapon = strikingBlade(visual.attackerKind); group.add(weapon); weapons.push(weapon);
    } else {
      const volleys = visual.attackerKind === 'warship' || visual.attackerKind.endsWith('Trireme') ? 3 : 1;
      for (let i = 0; i < volleys; i++) {
        const weapon = projectile(visual.attackerKind); group.add(weapon); weapons.push(weapon);
      }
    }
    const slash = new THREE.Mesh(new THREE.TorusGeometry(1.75, .12, 5, 24, Math.PI * 1.03),
      new THREE.MeshBasicMaterial({ color: result.hit ? 0xffdf8f : 0xe4cdae, transparent: true,
        opacity: .9, depthWrite: false, side: THREE.DoubleSide }));
    slash.visible = false; group.add(slash);
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 0),
      new THREE.MeshBasicMaterial({ color: visual.killed ? 0xf2684f : result.hit ? 0xffd683 : 0xb9b5a4,
        transparent: true, opacity: .85, depthWrite: false }));
    core.visible = false; group.add(core);
    const shards = [];
    const color = visual.killed ? 0xd65743 : visual.defenderKind === 'fort' ? 0xc7aa79 : 0xe9bc72;
    for (let i = 0; i < (visual.killed ? 10 : 6); i++) {
      const shard = new THREE.Mesh(new THREE.TetrahedronGeometry(visual.killed ? .36 : .22),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: .85, depthWrite: false }));
      shard.visible = false; group.add(shard); shards.push(shard);
    }
    const label = document.createElement('div');
    label.className = `combat-damage${visual.killed ? ' kill' : ''}${result.hit ? '' : ' miss'}`;
    const damage = (result.fortDamage || 0) + (result.unitDamage || 0);
    label.textContent = result.hit ? `${visual.ram ? '撞击 ' : ''}${visual.killed ? '击杀  ' : ''}−${fmt(damage)}` : '未命中';
    overlay.append(label);
    active.push({ result, visual, map, group, weapons, slash, core, shards, label, start, target, end,
      begins: performance.now() + delay, duration: visual.melee ? 920 : 1120 });
    if (active.length > 18) disposeEffect(active.shift(), root);
  }

  function playBatch(results, map) {
    results.filter(result => result?.ok && result.visual).slice(-6)
      .forEach((result, index) => play(result, map, index * 145));
  }

  function update(now) {
    for (let i = active.length - 1; i >= 0; i--) {
      const effect = active[i];
      const t = (now - effect.begins) / effect.duration;
      if (t < 0) { effect.group.visible = false; effect.label.style.display = 'none'; continue; }
      if (t >= 1) { disposeEffect(effect, root); active.splice(i, 1); continue; }
      effect.group.visible = true;
      const { visual, result, start, target, end, weapons, slash, core, shards } = effect;
      const strikeAt = visual.melee ? .39 : .72;
      if (visual.melee) {
        const p = ease(clamp(t / .44));
        const weapon = weapons[0];
        weapon.visible = t < .58;
        weapon.position.copy(start).lerp(target, p * .68);
        weapon.position.y += .6 + Math.sin(p * Math.PI) * .55;
        if (['siegeRam', 'warship', 'cavalry', 'chariot', 'hittiteChariot', 'romanHorse',
          'romanAlliedHorse', 'punicHeavyHorse', 'numidianHorse', 'masinissa', 'masinissaHorse', 'zamaPunicHorse'].includes(visual.attackerKind) || visual.attackerKind.endsWith('Trireme'))
          weapon.quaternion.setFromUnitVectors(forward, target.clone().sub(start).normalize());
        else {
          weapon.quaternion.copy(camera.quaternion);
          weapon.rotateZ(-1.2 + p * 2.35);
        }
        slash.visible = t >= .2 && t <= .7;
        if (slash.visible) {
          slash.position.copy(target); slash.position.y += .5;
          slash.quaternion.copy(camera.quaternion); slash.rotateZ(-.7 + p * 1.4);
          slash.scale.setScalar(.55 + p * .8);
          slash.material.opacity = (1 - clamp((t - .38) / .35)) * .85;
        }
      } else {
        const p = ease(clamp((t - .08) / .64));
        const axis = end.clone().sub(start).normalize();
        weapons.forEach((weapon, index) => {
          weapon.visible = t < .79;
          const lane = index - (weapons.length - 1) / 2;
          weapon.position.copy(start).lerp(end, p).addScaledVector(new THREE.Vector3(-axis.z, 0, axis.x), lane * .8);
          weapon.position.y += Math.sin(p * Math.PI) * Math.min(4.5, start.distanceTo(target) * .11);
          weapon.quaternion.setFromUnitVectors(forward, axis);
        });
      }
      const burst = clamp((t - strikeAt) / .42);
      const burstVisible = t >= strikeAt && t < .87;
      core.visible = burstVisible && result.hit;
      if (core.visible) {
        core.position.copy(target); core.scale.setScalar((visual.killed ? 1.55 : 1) * (1 + burst * 2.2));
        core.material.opacity = .56 * (1 - burst);
      }
      shards.forEach((shard, index) => {
        shard.visible = burstVisible && result.hit;
        if (!shard.visible) return;
        const angle = index * 2.39996;
        const travel = (visual.killed ? 4.2 : 2.7) * burst;
        shard.position.set(target.x + Math.cos(angle) * travel,
          target.y + Math.sin(angle * 1.7) * travel * .55 - burst * burst * 1.4,
          target.z + Math.sin(angle) * travel);
        shard.rotation.set(burst * (index + 1), burst * 2, angle);
        shard.material.opacity = .85 * (1 - burst);
      });
      const labelVisible = t >= strikeAt && t < .93;
      effect.label.style.display = labelVisible ? '' : 'none';
      if (labelVisible) {
        const pos = target.clone(); pos.y += 2.1 + burst * 2.4; pos.project(camera);
        effect.label.style.left = `${(pos.x * .5 + .5) * stage.clientWidth}px`;
        effect.label.style.top = `${(-pos.y * .5 + .5) * stage.clientHeight}px`;
        effect.label.style.opacity = String(1 - clamp((t - .78) / .16));
      }
    }
  }

  return { play, playBatch, update, clear };
}
