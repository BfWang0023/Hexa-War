import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {CLASSICAL_CAMPAIGNS,CLASSICAL_IDS,classicalKinds} from './classical-data.mjs';
import {makeClassicalMap} from './classical-maps.mjs';
import {classicalBrief,inClassicalArea} from './classical-rules.mjs';
import {classicalHelp} from './classical-ui.mjs';
import {CAMPAIGN_CATALOG} from './campaign-catalog.mjs';
import {loadCampaign} from './campaign-loader.mjs';
import {mapFor,seededRandom} from '../../tools/ai-training/maps.mjs';
import {STATS,TERRAIN as T,addUnit,newMap,startGame,checkVictory,endSide,aiTurn,exportMap,importMap,tile,mobileAt,canPlaceKind,isShip,isRouted,reachable,move,setPhalanxMode} from './engine.mjs';
import {createSave,restoreSave,SAVE_FORMAT} from './save.mjs';
const fighters=(s,t)=>s.map.units.filter(u=>u.team===t&&!['fort','moraleGuard','moraleFlagship'].includes(u.kind));
const saved=s=>{const d=createSave(s.map,s,'egypt');delete d.savedAt;return JSON.stringify(d);};
for(const info of CLASSICAL_CAMPAIGNS)test(`${info.id}: catalog/loaders, legal deployment, map/editor roundtrip and save`,()=>{
 assert.equal(CAMPAIGN_CATALOG.filter(c=>c.id===info.id).length,1);const m=makeClassicalMap(info.id),s=startGame(m);assert.equal(s.over,false);assert.equal(s.deploying,false);assert.equal(m.recruitment,null);
 assert.deepEqual(exportMap(loadCampaign(info.id)),exportMap(mapFor(info.id)));assert.deepEqual(exportMap(importMap(exportMap(m))),exportMap(m));assert.equal(m.units.length,new Set(m.units.filter(u=>u.kind!=='fort').map(u=>`${u.c},${u.r}`)).size+m.units.filter(u=>u.kind==='fort').length);
 assert.ok(m.units.every(u=>u.kind==='fort'||classicalKinds(info.id,u.team).includes(u.kind)));assert.ok(m.units.filter(isShip).every(u=>tile(m,u.c,u.r).terrain===T.SEA));
 const d=createSave(m,s,'egypt'),r=restoreSave(JSON.parse(JSON.stringify(d)));assert.equal(d.format,SAVE_FORMAT);assert.deepEqual(r.game.map.victory,s.map.victory);assert.equal(r.game.map.units.length,s.map.units.length);assert.ok(classicalHelp(m).includes('缩放'));assert.ok(info.sources.length);assert.ok(classicalBrief(m).includes(String(m.victory.turnLimit)));
});
for(const id of CLASSICAL_IDS)for(const team of ['egypt','coalition'])test(`${id}: ${team} can win by existing 75% rout definition`,()=>{
 const s=startGame(makeClassicalMap(id)),victim=team==='egypt'?'coalition':'egypt',units=fighters(s,victim);for(const u of units.slice(0,s.map.victory.losses[victim]))u.hp=0;checkVictory(s);assert.equal(s.winner,team);assert.equal(s.victoryReason,'classical_rout');
});
test('old 71 default maps, terrain, rosters and victory data stay identical',()=>{
 const records=JSON.parse(fs.readFileSync(new URL('../../docs/greek-expansion/before-existing-maps.json',import.meta.url)));assert.equal(records.length,71);for(const r of records){const hash=crypto.createHash('sha256').update(JSON.stringify(exportMap(mapFor(r.id)))).digest('hex');assert.equal(hash,r.sha256,r.id);}
});
test('Thermopylae has ancient coast, open land gate, mountain detour and Phocian defenders',()=>{
 const m=makeClassicalMap('thermopylae');assert.equal(tile(m,35,6).terrain,T.SEA);assert.ok(tile(m,33,28).terrain&T.MOUNTAIN);assert.ok(tile(m,33,28).terrain&T.ROAD);assert.ok(m.units.some(u=>u.formation==='佛基斯山路守军'));assert.ok(m.units.some(u=>u.customName?.includes('三百人')));assert.ok(!m.units.some(u=>isShip(u)||u.kind==='cavalry'));
 const s=startGame(m),u=fighters(s,'coalition')[0];u.c=s.map.victory.capture.c;u.r=s.map.victory.capture.r;checkVictory(s);assert.equal(s.winner,'coalition');assert.equal(s.victoryReason,'classical_capture');
 const wrong=startGame(m);const defender=fighters(wrong,'egypt')[0];Object.assign(defender,{c:m.victory.capture.c,r:m.victory.capture.r});checkVictory(wrong);assert.equal(wrong.over,false);
});
test('hold goals expire after both sides act, and a last-turn breakthrough takes precedence',()=>{
 for(const id of ['thermopylae','sphacteria','sicily_413']){const s=startGame(makeClassicalMap(id));s.turn=s.map.victory.turnLimit;endSide(s,seededRandom(1));assert.equal(s.over,false);assert.equal(s.side,'coalition');endSide(s,seededRandom(1));assert.equal(s.winner,s.map.victory.holdWinner);assert.equal(s.victoryReason,'classical_hold');}
 const s=startGame(makeClassicalMap('thermopylae'));s.turn=s.map.victory.turnLimit;s.side='coalition';Object.assign(fighters(s,'coalition')[0],s.map.victory.capture);endSide(s);assert.equal(s.winner,'coalition');assert.equal(s.victoryReason,'classical_capture');
});
test('field battles end on proportional losses, with honest draws and simultaneous routs',()=>{
 let s=startGame(makeClassicalMap('marathon'));s.turn=s.map.victory.turnLimit;s.side='coalition';endSide(s);assert.equal(s.over,true);assert.equal(s.winner,null);
 s=startGame(makeClassicalMap('marathon'));fighters(s,'egypt')[0].hp=0;fighters(s,'coalition')[0].hp=0;s.turn=s.map.victory.turnLimit;s.side='coalition';endSide(s);assert.equal(s.winner,'coalition');
 s=startGame(makeClassicalMap('marathon'));for(const team of ['egypt','coalition'])for(const u of fighters(s,team).slice(0,s.map.victory.losses[team]))u.hp=0;checkVictory(s);assert.equal(s.winner,null);assert.equal(s.over,true);
});
test('Sicily maritime OR land escape counts only valid living units, without duplicate scoring',()=>{
 for(const ships of [true,false]){const s=startGame(makeClassicalMap('sicily_413')),a=s.map.victory.escape.find(a=>a.ships===ships),units=fighters(s,'egypt').filter(u=>isShip(u)===ships);for(let i=0;i<a.needed;i++){units[i].c=a.cMin+i%(a.cMax-a.cMin+1);units[i].r=a.rMin+Math.floor(i/(a.cMax-a.cMin+1));}checkVictory(s);assert.equal(s.winner,'egypt');assert.equal(s.victoryReason,'classical_escape');}
 const s=startGame(makeClassicalMap('sicily_413')),a=s.map.victory.escape[0],ships=fighters(s,'egypt').filter(isShip);for(let i=0;i<a.needed;i++){ships[i].c=a.cMin;ships[i].r=a.rMin+i;}ships[0].routed=true;checkVictory(s);assert.equal(s.over,false);ships[0].routed=false;ships[0].aboard=ships[1].id;checkVictory(s);assert.equal(s.over,false);ships[0].aboard=null;checkVictory(s);assert.equal(s.winner,'egypt');checkVictory(s);assert.equal(s.log.filter(l=>l.includes('达成战役目标')).length,1);
});
test('river systems have edge-to-edge continuity or an outlet to the sea; no invented bridges',()=>{
 for(const [id,cells] of [['plataea',[[0,9],[71,9]]],['chaeronea',[[0,5],[71,5]]],['sicily_413',[[0,35],[34,35]]]]){const m=makeClassicalMap(id);for(const [c,r] of cells)assert.ok(tile(m,c,r).terrain&T.RIVER);assert.equal(m.bridges.length,0);}
});
test('Greek wings, sacred bands and Macedonian commanders retain historical relative positions',()=>{
 const m=makeClassicalMap('marathon');assert.equal(m.units.filter(u=>u.team==='egypt').length,20);assert.equal(m.units.filter(u=>u.team==='coalition').length,40);assert.equal(m.units.filter(u=>u.formation==='较薄的雅典中军').length,4);
 const l=makeClassicalMap('leuctra');assert.equal(l.units.filter(u=>u.formation==='底比斯左翼纵深集团').length,16);assert.ok(l.units.filter(u=>u.formation==='后撤的中军与右翼').every(u=>u.c<26));
 const c=makeClassicalMap('chaeronea');assert.ok(c.units.find(u=>u.customName?.includes('腓力')).r>c.units.find(u=>u.customName?.includes('亚历山大')).r);assert.ok(c.units.find(u=>u.customName?.includes('圣队')).r<20);
});
test('only the seven new scenarios extend hoplite placement; all stats and saved format stay unchanged',()=>{
 for(const id of CLASSICAL_IDS)assert.ok(canPlaceKind('greekHoplite','coalition',id));assert.equal(canPlaceKind('greekHoplite','egypt','megiddo'),false);assert.equal(canPlaceKind('greekHoplite','egypt','mantinea'),true);assert.equal(Object.keys(STATS).length,69);assert.equal(SAVE_FORMAT,'hex_wargame.ancient.save.v1');
});
test('invalid new objectives are rejected instead of silently losing victory fields',()=>{
 for(const mutate of [d=>d.victory.variant='mantinea',d=>d.victory.turnLimit=0,d=>d.victory.capture.c=999,d=>d.victory.holdWinner='bad']){const d=exportMap(makeClassicalMap('thermopylae'));mutate(d);assert.throws(()=>importMap(d));}
 for(const mutate of [d=>d.victory.escape[0].needed=-1,d=>d.victory.escape[0].ships='yes',d=>d.victory.escape[0].cMax=999]){const d=exportMap(makeClassicalMap('sicily_413'));mutate(d);assert.throws(()=>importMap(d));}
});
for(const id of CLASSICAL_IDS)test(`${id}: both AI sides can act legally and preserve unique cells`,()=>{
 for(const team of ['egypt','coalition']){const s=startGame(makeClassicalMap(id));s.side=team;const before=saved(s),actions=aiTurn(s,seededRandom(3));assert.ok(actions.some(a=>a.type==='move'),team);const living=s.map.units.filter(u=>u.kind!=='fort'&&u.hp>0&&!u.aboard);assert.equal(new Set(living.map(u=>`${u.c},${u.r}`)).size,living.length);assert.notEqual(saved(s),before);assert.ok(living.every(u=>u.actionsLeft>=0));assert.ok(restoreSave(JSON.parse(saved(s))).game.map.units.length);}
});
test('formed hoplites, moving and save restore work in every new land battle',()=>{
 for(const id of CLASSICAL_IDS){const m=makeClassicalMap(id),s=startGame(m),u=s.map.units.find(u=>u.kind==='greekHoplite'&&u.team==='egypt'&&!(tile(m,u.c,u.r).terrain&T.MOUNTAIN));if(!u)continue;assert.ok(setPhalanxMode(s,u.id,true,u.facing).ok);const r=restoreSave(JSON.parse(JSON.stringify(createSave(m,s,'egypt'))));assert.equal(r.game.map.units.find(x=>x.id===u.id).formed,true);}
});
