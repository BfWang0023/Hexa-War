import {HELLENISTIC_CAMPAIGNS} from './hellenistic-data.mjs';
import { CLASSICAL_CAMPAIGNS } from './classical-data.mjs';
import { CHINA_CAMPAIGNS } from './china-campaigns.mjs';
import { IMPERIAL_CAMPAIGNS } from './imperial-campaigns.mjs';

// Sort by the beginning of a campaign; dateLabel records the uncertainty or full span shown to players.
const otherCampaigns = [
  ['megiddo', -1457, '美吉多之战', '约前1457年'],
  ['kadesh', -1274, '卡迭石会战', '前1274年'],
  ['troy', -1184, '特洛伊之战', '传说约前1184年'],
  ['qarqar', -853, '卡尔卡尔之战', '前853年'],
  ['babylon', -539, '巴比伦陷落', '前539年'],
  ['salamis', -480, '萨拉米斯海战', '前480年'],
  ['mantinea', -418, '曼提尼亚会战', '前418年'],
  ['aegospotami', -405, '羊河口之战', '前405年'],
  ['issus', -333, '伊苏斯之战', '前333年'],
  ['tyre', -332, '推罗围城战', '前332年'],
  ['gaugamela', -331, '高加米拉之战', '前331年'],
  ['cannae', -216, '坎尼会战', '前216年'],
  ['syracuse', -213, '叙拉古围城战', '前213—前212年'],
  ['zama', -202, '扎马会战', '前202年'],
  ['pydna', -168, '彼得那会战', '前168年'],
  ['carthage', -149, '迦太基围城战', '前149—前146年'],
  ['carrhae', -53, '卡莱之战', '前53年'],
  ['alesia', -52, '阿莱西亚围城战', '前52年'],
  ['pharsalus', -48, '法萨卢斯会战', '前48年'],
  ['actium', -31, '亚克兴角海战', '前31年'],
  ['teutoburg', 9, '条顿森林之战', '公元9年'],
  ['jerusalem', 70, '耶路撒冷围城战', '公元70年'],
].map(([id, year, name, dateLabel]) => ({ id, year, name, dateLabel }));

const approximateChineseDates = new Set(['china_mingtiao', 'china_muye', 'china_three_guards', 'china_zhou_xu']);
const chineseDateSpans = Object.freeze({
  china_yan_ying: '前279—前278年',
  china_eyu: '前270—前269年',
  china_qin_chu: '前224—前223年',
});
export const CAMPAIGN_CATALOG = Object.freeze([...otherCampaigns,
  ...[...CLASSICAL_CAMPAIGNS,...HELLENISTIC_CAMPAIGNS].map(({id,year,name})=>({id,year,name,dateLabel:`前${-year}年`})),
  ...IMPERIAL_CAMPAIGNS.map(({ id, year, name }) => ({ id, year, name,
    dateLabel: year > 0 ? `公元${year}年` :
      id === 'china_dayuan' ? '前104—前101年' : `${id === 'china_longxi' ? '公元' : '前'}${-year}年`,
  })),
  ...CHINA_CAMPAIGNS.map(({ id, year, name }) => ({ id, year, name,
    dateLabel: chineseDateSpans[id] || `${approximateChineseDates.has(id) ? '约' : ''}前${-year}年`,
  }))].sort((a, b) => a.year - b.year).map(entry => Object.freeze({
    ...entry, title: `${entry.name}（${entry.dateLabel}）`,
  })));

export const CAMPAIGN_IDS = new Set(CAMPAIGN_CATALOG.map(entry => entry.id));
const campaignById = new Map(CAMPAIGN_CATALOG.map(entry => [entry.id, entry]));
export function campaignTitle(id, fallback = '古代战役地图') {
  return campaignById.get(id)?.title ?? fallback;
}
