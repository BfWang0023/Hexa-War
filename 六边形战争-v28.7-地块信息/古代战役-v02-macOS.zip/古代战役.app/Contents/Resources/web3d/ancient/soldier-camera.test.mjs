import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {createSoldierCamera,canFollowSoldier,SOLDIER_CAMERA} from './soldier-camera.mjs';
import {createUnitModel} from './unit-presentation.mjs';
import {createUnitAnimator} from './unit-animation.mjs';
import {animateFullModel} from './full-models.mjs';
import {neighbors} from './engine.mjs';
import {offsetToWorld} from '../js/core/hex.js';
const unit=(extra={})=>({id:'u1',kind:'heavy',team:'egypt',hp:100,c:3,r:4,morale:1,...extra});
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} vs ${b}`);
function fixture(u=unit(),options={}){const camera=new T.PerspectiveCamera(45,1,.8,2200),model=createUnitModel(u,'china_changping',options),events=[],view=createSoldierCamera(camera,r=>events.push(r));view.setStabilized(false);model.userData.unitId=u.id;model.scale.setScalar(1.16);return {camera,model,view,events,u};}

test('only living available friendly troops can be followed, with both sides available to spectators',()=>{
 assert.equal(canFollowSoldier(unit(),'egypt'),true);assert.equal(canFollowSoldier(unit(),'coalition'),false);assert.equal(canFollowSoldier(unit(),'coalition',true),true);
 for(const extra of [{hp:0},{kind:'fort'},{aboard:'u2'}])assert.equal(canFollowSoldier(unit(extra),'egypt',true),false);assert.equal(canFollowSoldier(null,'egypt'),false);
});
test('camera sits above the primary soldier head and respects the model world height and scale',()=>{
 const f=fixture();f.model.position.set(40,7,-20);assert.ok(f.view.start(f.u,f.model));const head=f.model.getObjectByName('near').getObjectByName('soldier').localToWorld(new T.Vector3(0,3.25,0));close(f.camera.position.x,head.x);close(f.camera.position.z,head.z);close(f.camera.position.y,head.y+8);assert.equal(f.camera.fov,60);assert.equal(f.camera.near,.2);
});
test('height and pitch controls clamp invalid or extreme values without changing rule state',()=>{
 const f=fixture(),before=JSON.stringify(f.u);f.view.start(f.u,f.model);for(const value of [-100,100,NaN,Infinity]){f.view.setHeight(value);f.view.setPitch(value);f.view.update(f.u,f.model);assert.ok(f.view.height>=2&&f.view.height<=24);assert.ok(f.view.pitch>=8&&f.view.pitch<=75);assert.ok(f.camera.position.toArray().every(Number.isFinite));}assert.equal(JSON.stringify(f.u),before);
});
test('model heading and mouse look change viewing direction without moving the head anchor',()=>{
 const f=fixture();f.view.start(f.u,f.model);const first=f.camera.getWorldDirection(new T.Vector3()),position=f.camera.position.clone();f.view.rotate(100,20);f.view.update(f.u,f.model);assert.ok(first.distanceTo(f.camera.getWorldDirection(new T.Vector3()))>.2);assert.ok(position.distanceTo(f.camera.position)<1e-7);f.view.forward();f.view.update(f.u,f.model);assert.ok(first.distanceTo(f.camera.getWorldDirection(new T.Vector3()))<1e-7);f.model.rotation.y=Math.PI/2;f.view.update(f.u,f.model);assert.ok(f.camera.getWorldDirection(new T.Vector3()).z<-.8);
});
test('death requests a replacement once and never silently follows another soldier',()=>{
 const f=fixture();f.view.start(f.u,f.model);f.u.hp=0;assert.equal(f.view.update(f.u,f.model),false);assert.equal(f.view.active,false);assert.equal(f.events.length,1);assert.match(f.events[0],/阵亡.*重新选择/);f.view.update(unit({id:'u2'}),f.model);assert.equal(f.events.length,1);assert.equal(f.view.id,null);assert.equal(f.view.holding,true);assert.equal(f.view.engaged,true);assert.equal(f.camera.fov,60);f.view.stop();assert.equal(f.view.engaged,false);assert.equal(f.camera.fov,45);assert.equal(f.camera.near,.8);
});
test('removed, embarked and permission-lost targets hold the last camera pose',()=>{
 for(const change of [f=>[null,null,true],f=>[{...f.u,aboard:'u2'},f.model,true],f=>[f.u,f.model,false]]){const f=fixture();f.view.start(f.u,f.model);assert.equal(f.view.update(...change(f)),false);assert.equal(f.view.active,false);assert.equal(f.events.length,1);}
});
test('model rebuild binds to the replacement head without following stale mesh references',()=>{
 const f=fixture();f.view.start(f.u,f.model);const replacement=createUnitModel(f.u,'china_changping');replacement.position.set(75,13,24);f.view.update(f.u,replacement);assert.ok(f.camera.position.x>70);assert.ok(f.camera.position.y>24);f.model.position.set(-200,0,0);f.view.update(f.u,replacement);assert.ok(f.camera.position.x>70);
});
test('near/far LOD switches preserve the same head anchor, with no geometry or material edits',()=>{
 const f=fixture(),meshes=[];f.model.traverse(o=>{if(o.isMesh)meshes.push([o,o.geometry,o.material]);});f.view.start(f.u,f.model);const point=f.camera.position.clone();for(const distance of [150,10,150]){animateFullModel(f.model,0,{distance});f.view.update(f.u,f.model);assert.ok(point.distanceTo(f.camera.position)<1e-6);}for(const [o,geometry,material]of meshes){assert.equal(o.geometry,geometry);assert.equal(o.material,material);}
});
test('phase-one and legacy pieces have finite supported camera anchors',()=>{
 for(const options of [{phase1:true},{legacy:true}]){const f=fixture(unit(),options);assert.ok(f.view.start(f.u,f.model));assert.ok(f.camera.position.toArray().every(Number.isFinite));f.view.stop();assert.equal(f.view.active,false);}
});
test('unmanned units use a cached body-top anchor and empty fallback models stay finite',()=>{
 for(const kind of ['chinaFireOx','siegeRam','warship','supplyWagon']){const f=fixture(unit({kind}));assert.ok(f.view.start(f.u,f.model));assert.ok(f.camera.position.toArray().every(Number.isFinite));}
 const f=fixture();assert.ok(f.view.start(f.u,new T.Group()));assert.ok(f.camera.position.toArray().every(Number.isFinite));
});
test('stop and restart restore the overview lens without overwriting its saved parameters',()=>{
 const f=fixture();for(let i=0;i<3;i++){f.view.start(f.u,f.model);f.view.start({...f.u,id:'u2'},f.model);f.view.stop();assert.equal(f.camera.fov,45);assert.equal(f.camera.near,.8);}assert.equal(f.view.start(unit({hp:0}),f.model),false);assert.equal(f.view.active,false);
});
test('camera follows actual interpolated movement instead of the already committed rule destination',()=>{
 const f=fixture(),group=new T.Group(),anim=createUnitAnimator(),height=p=>p.c*.12+p.r*.07;group.add(f.model);const world=p=>{const w=offsetToWorld(p.c,p.r);return new T.Vector3(w.x,height(p)+.08,w.z);};f.model.position.copy(world(f.u));anim.setHeightResolver(height);anim.observe([f.u],0,{scenarioId:'china_changping'});f.view.start(f.u,f.model);const initial=f.camera.position.clone(),next=neighbors(f.u.c,f.u.r)[0];anim.move(f.u.id,f.u,[next],0);anim.observe([{...f.u,...next}],1);f.model.position.copy(world(next));const reference=new T.PerspectiveCamera();reference.position.set(0,30,40);
 for(const time of [0,45,90,150,250,339,340,500]){anim.update(group,reference,time);f.view.update({...f.u,...next},f.model);const head=f.model.getObjectByName('near').getObjectByName('soldier').localToWorld(new T.Vector3(0,3.25,0));close(f.camera.position.x,head.x);close(f.camera.position.z,head.z);close(f.camera.position.y,head.y+SOLDIER_CAMERA.height);if(time<90)assert.ok(initial.distanceTo(f.camera.position)<.1);}
 assert.ok(initial.distanceTo(f.camera.position)>5);
});


test('temporary missing render models retain the target and resume without loss events',()=>{
 const f=fixture();f.view.start(f.u,f.model);const position=f.camera.position.clone(),rotation=f.camera.quaternion.clone();
 for(let i=0;i<4;i++){assert.equal(f.view.update(f.u,null,true,100+i*16),false);assert.equal(f.view.id,f.u.id);assert.equal(f.view.active,true);assert.equal(f.events.length,0);assert.deepEqual(f.camera.position,position);assert.deepEqual(f.camera.quaternion.toArray(),rotation.toArray());}
 const replacement=createUnitModel(f.u,'china_changping');replacement.position.copy(f.model.position);assert.equal(f.view.update(f.u,replacement,true,200),true);assert.equal(f.view.id,f.u.id);
});
test('death freezes position, rotation and lens until explicit replacement or exit',()=>{
 const f=fixture();f.view.start(f.u,f.model);f.view.rotate(90,12);f.view.update(f.u,f.model);const position=f.camera.position.clone(),rotation=f.camera.quaternion.clone();
 f.view.update({...f.u,hp:0},null,true,500);assert.equal(f.view.holding,true);assert.equal(f.view.active,false);assert.deepEqual(f.camera.position,position);assert.deepEqual(f.camera.quaternion.toArray(),rotation.toArray());assert.equal(f.camera.fov,60);
 const next={...f.u,id:'u2'};assert.equal(f.view.start(next,f.model),true);assert.equal(f.view.holding,false);assert.equal(f.view.id,'u2');f.view.stop();assert.equal(f.camera.fov,45);
});

test('model integration protection rejects unrelated app edits while allowing the camera repair',async()=>{
 const {assertCameraOnlyAppChange}=await import('../../tools/spectator-follow/app-integrity.mjs'),fs=await import('node:fs'),crypto=await import('node:crypto');
 const baseline=fs.readFileSync(new URL('../../docs/spectator-follow/before/app.mjs',import.meta.url),'utf8'),hash=crypto.createHash('sha256').update(baseline).digest('hex'),current=fs.readFileSync(new URL('./app.mjs',import.meta.url),'utf8');assertCameraOnlyAppChange(hash,current);assert.throws(()=>assertCameraOnlyAppChange(hash,current.replace('unitAnimator.update(unitGroup,camera,time)','unitAnimator.update(unitGroup,camera,time+100)')));
});
