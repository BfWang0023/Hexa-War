import {unitKnown} from './fog-policy.mjs';
// Accounting only: recorded at authoritative event sites, never drives simulation.
export function recordBattleEvent(s,type,u,other=null,amount=0){
 if(!s||s.deploying)return;const journal=s.turnJournal??=[];
 const visible=['egypt','coalition'].filter(team=>s.fogPolicy?unitKnown(s,team,u):u?.team===team||s.fog?.[team]?.visible.has(`${u?.c},${u?.r}`));
 const event={turn:s.turn,side:s.side,type,team:u?.team,id:u?.id,otherTeam:other?.team,amount,visible};
 if(['death','rout','retreat'].includes(type)&&journal.some(e=>e.turn===s.turn&&e.type===type&&e.id===u.id))return;
 journal.push(event);
}
export function summarizeTurn(s,turn,viewer){const teams=['egypt','coalition'],rows=Object.fromEntries(teams.map(t=>[t,{dead:0,kills:0,routed:0,routs:0,retreated:0,income:0,expense:0,net:0,finance:!!s.money&&(viewer===t||s.fogPolicy?.unitFog===false)}]));
 for(const e of s.turnJournal||[]){if(e.turn!==turn||!e.visible.includes(viewer))continue;const row=rows[e.team];if(!row)continue;if(e.type==='death'){row.dead++;if(e.otherTeam&&e.otherTeam!==e.team)rows[e.otherTeam].kills++;}if(e.type==='rout'){row.routed++;if(e.otherTeam&&e.otherTeam!==e.team)rows[e.otherTeam].routs++;}if(e.type==='retreat')row.retreated++;if(e.type==='income'&&row.finance)row.income+=e.amount;if(e.type==='expense'&&row.finance)row.expense+=e.amount;}
 for(const row of Object.values(rows))row.net=row.income-row.expense;return rows;
}
const actors=new WeakMap();export function combatActor(s){return actors.get(s);}
export function withCombatActor(s,id,run){const actor=s.map.units.find(u=>u.id===id),old=actors.get(s);actors.set(s,actor);try{return run();}finally{old?actors.set(s,old):actors.delete(s);}}
export function observeCasualties(s){const old=s.turnUnitSnapshot??{},next={};for(const u of s.map.units){if(u.kind==='fort')continue;const p=old[u.id];if(p&&p.hp>0&&u.hp<=0)recordBattleEvent(s,'death',u);if(p&&u.hp>0&&u.routed&&(p.c!==u.c||p.r!==u.r))recordBattleEvent(s,'retreat',u);next[u.id]={hp:u.hp,c:u.c,r:u.r};}s.turnUnitSnapshot=next;}
