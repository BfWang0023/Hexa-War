import {HELLENISTIC_IDS} from './hellenistic-data.mjs';
import {makeHellenisticMap} from './hellenistic-maps.mjs';
import {CLASSICAL_IDS} from './classical-data.mjs';
import {makeClassicalMap} from './classical-maps.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as engine from './engine.mjs';
import { CAMPAIGN_CATALOG } from './campaign-catalog.mjs';
import { makeChinaMap } from './china-campaigns.mjs';
import { IMPERIAL_CAMPAIGN_IDS, makeImperialMap } from './imperial-campaigns.mjs';
import { mantineaMap, aegospotamiMap } from './greek-campaigns.mjs';
import { createSave, restoreSave } from './save.mjs';

function campaignMap(id) {
  if (HELLENISTIC_IDS.has(id)) return makeHellenisticMap(id);
  if (CLASSICAL_IDS.has(id)) return makeClassicalMap(id);
  if (IMPERIAL_CAMPAIGN_IDS.has(id)) return makeImperialMap(id);
  if (id.startsWith('china_')) return makeChinaMap(id);
  if (id === 'mantinea') return mantineaMap();
  if (id === 'aegospotami') return aegospotamiMap();
  return engine[`${id}Map`]();
}

test('all 85 campaigns derive their configured army rout threshold', () => {
  for (const { id } of CAMPAIGN_CATALOG) {
    const m = campaignMap(id);
    for (const team of ['egypt', 'coalition'])
      assert.equal(m.victory.routLosses[team], engine.armyRoutThreshold(m, team), `${id}: ${team}`);
    assert.deepEqual(engine.importMap(engine.exportMap(m)).victory.routLosses,
      m.victory.routLosses, `${id}: map round trip`);
  }
});

test('Kunyang, Changping, and Qin versus Chu require 80 percent losses on generated and user-edited maps', () => {
  for (const id of ['china_kunyang', 'china_changping', 'china_qin_chu']) {
    for (const map of [campaignMap(id), engine.importMap(JSON.parse(readFileSync(
      new URL(`./bundled-maps/${id}.json`, import.meta.url), 'utf8')))]) {
      assert.equal(engine.armyRoutFraction(map), 0.8, id);
      const foes = map.units.filter(u => u.team === 'coalition' &&
        !['fort', 'chinaGeneral', 'supplyWagon', 'moraleGuard'].includes(u.kind));
      const target = Math.ceil(foes.length * 0.8);
      assert.equal(map.victory.losses.coalition, target, id);
      const game = engine.startGame(map);
      game.map.units.filter(u => u.team === 'coalition' &&
        !['fort', 'chinaGeneral', 'supplyWagon', 'moraleGuard'].includes(u.kind))
        .slice(0, target - 1).forEach(u => { u.hp = 0; });
      assert.equal(engine.checkVictory(game), null, `${id}: below 80 percent`);
      game.map.units.filter(u => u.team === 'coalition' &&
        !['fort', 'chinaGeneral', 'supplyWagon', 'moraleGuard'].includes(u.kind))[target - 1].hp = 0;
      assert.equal(engine.checkVictory(game), 'egypt', `${id}: reaches 80 percent`);
      const old = createSave(map, engine.startGame(map), 'egypt');
      old.scenario.victory.losses = { egypt: 1, coalition: 1 };
      old.game.map.victory.losses = { egypt: 1, coalition: 1 };
      assert.equal(restoreSave(old).game.map.victory.losses.coalition, target, `${id}: old save`);
    }
  }
  assert.equal(engine.armyRoutFraction(makeImperialMap('china_seven_states')), 0.75);
});

test('army rout waits for three quarters, including in formerly half-force campaigns', () => {
  const china = engine.startGame(makeChinaMap('china_three_guards'));
  const foes = china.map.units.filter(u => u.team === 'coalition' && u.kind !== 'chinaGeneral' && u.kind !== 'fort');
  const target = china.map.victory.losses.coalition;
  foes.slice(0, target - 1).forEach(u => { u.hp = 0; });
  assert.equal(engine.checkVictory(china), null);
  foes[target - 1].hp = 0;
  assert.equal(engine.checkVictory(china), 'egypt');

  const megiddo = engine.startGame(engine.megiddoMap());
  const egypt = megiddo.map.units.filter(u => u.team === 'egypt' && u.kind !== 'pharaoh');
  const egyptTarget = megiddo.map.victory.routLosses.egypt;
  egypt.slice(0, egyptTarget - 1).forEach(u => { u.hp = 0; });
  assert.equal(engine.checkVictory(megiddo), null);
  egypt[egyptTarget - 1].hp = 0;
  assert.equal(engine.checkVictory(megiddo), 'coalition');
  assert.equal(megiddo.victoryReason, 'army_rout');
});

test('loading an older slot updates its victory thresholds to the current rule', () => {
  const m = makeChinaMap('china_three_guards');
  const saved = createSave(m, engine.startGame(m), 'egypt');
  saved.scenario.victory.losses = { egypt: 11, coalition: 11 };
  saved.game.map.victory.losses = { egypt: 11, coalition: 11 };
  const restored = restoreSave(saved);
  assert.equal(restored.game.map.victory.losses.egypt, 17);
  assert.equal(restored.game.map.victory.losses.coalition, 17);
});
