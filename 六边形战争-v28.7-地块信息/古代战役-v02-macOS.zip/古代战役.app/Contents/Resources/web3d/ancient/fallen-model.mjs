// Static, volumetric, authored body silhouettes. No animation/physics or simulation mutation.
import * as T from '../vendor/three/three.module.js';
// A static, genuinely three-dimensional distance LOD. Cluster only the baked corpse,
// never the live model. Degenerate faces disappear while silhouette/colour remain.
export function simplifyFallenModel(source,cell=.24){
 const p=source.attributes.position,c=source.attributes.color,clusters=new Map(),keys=[];
 for(let i=0;i<p.count;i++){const key=[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v/cell)).join(',');keys.push(key);let a=clusters.get(key);if(!a)clusters.set(key,a=[0,0,0,0]);a[0]+=p.getX(i);a[1]+=p.getY(i);a[2]+=p.getZ(i);a[3]++;}
 for(const a of clusters.values())for(let j=0;j<3;j++)a[j]/=a[3];
 const pos=[],colors=[],faces=new Set();
 for(let i=0;i<p.count;i+=3){const ks=keys.slice(i,i+3);if(new Set(ks).size!==3)continue;const face=[...ks].sort().join('/');if(faces.has(face))continue;faces.add(face);for(let j=0;j<3;j++){pos.push(...clusters.get(ks[j]).slice(0,3));colors.push(c.getX(i+j),c.getY(i+j),c.getZ(i+j));}}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function bakeFallenModel(model,pose=0){
 const level=model.getObjectByName('near')||model,visual=level.getObjectByName('visual')||level;
 model.rotation.set(0,0,0);for(const child of model.children)if(child!==level)child.visible=false;level.visible=true;
 model.traverse(o=>{if(o.userData.unitBase)o.visible=false;});model.updateMatrixWorld(true);
 const persons=[];visual.traverse(o=>{if(['soldier','rider'].includes(o.name))persons.push(o);});
 // Detach riders before laying mounts down. Keep their authored dimensions.
 for(const o of persons)if(o.parent!==visual)visual.attach(o);
 const bodies=[...visual.children].filter(o=>['horse','beast-body','supply-assembly'].includes(o.name));
 for(const [i,o] of [...persons,...bodies].entries()){
  if(o.name==='supply-assembly'){o.rotation.z=.13;continue;}
  o.rotation.x+=pose?Math.PI/2:-Math.PI/2;
  if(o.name==='rider'){o.position.x-=1.1;o.position.z+=1.25;}
  model.updateMatrixWorld(true);const box=new T.Box3().setFromObject(o),scale=new T.Vector3();o.parent.getWorldScale(scale);o.position.y-=(box.min.y-.04)/scale.y;
 }
 // Chariot and engine frames remain recognizable static wreckage, gently tilted.
 if(!persons.length&&!bodies.length)visual.rotation.z=.12;
 model.updateMatrixWorld(true);const pos=[],norm=[],colors=[],normalMatrix=new T.Matrix3(),v=new T.Vector3(),n=new T.Vector3();
 level.traverseVisible(o=>{if(!o.isMesh||o.userData.unitBase)return;let g=o.geometry.index?o.geometry.toNonIndexed():o.geometry;const p=g.attributes.position,no=g.attributes.normal,co=g.attributes.color,mat=Array.isArray(o.material)?o.material:[o.material];normalMatrix.getNormalMatrix(o.matrixWorld);
  for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld);pos.push(v.x,v.y,v.z);n.fromBufferAttribute(no,i).applyMatrix3(normalMatrix).normalize();norm.push(n.x,n.y,n.z);const material=mat[g.groups.find(x=>i>=x.start&&i<x.start+x.count)?.materialIndex||0],c=(material.color||new T.Color(0xffffff)).clone();if(co)c.multiply(new T.Color().fromBufferAttribute(co,i));c.multiplyScalar(.88);colors.push(c.r,c.g,c.b);}if(g!==o.geometry)g.dispose();});
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(pos,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(norm,3));geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));geometry.computeBoundingBox();geometry.translate(0,.035-geometry.boundingBox.min.y,0);geometry.computeBoundingBox();geometry.computeBoundingSphere();
 return geometry;
}
