import * as THREE from '../vendor/three/three.module.js';
import { createFullModel } from './full-models.mjs';
import { createV02, supportsV02 } from './models-v02.mjs';
import { isRouted } from './engine.mjs';

// Low polygon silhouettes, with all paints shared by the complete army.
const paint = (color, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.91, flatShading: true, ...extra });
const M = {
  egypt: paint(0x185675), egyptBright: paint(0x2d8da5), canaan: paint(0x9a4736),
  canaanLight: paint(0xc27d4e), white: paint(0xe8dcc1), linen: paint(0xc4ae89),
  skin: paint(0xa76643), skinC: paint(0x98603f), hair: paint(0x211c1a),
  leather: paint(0x543725), wood: paint(0x71482b), darkWood: paint(0x38281e),
  bronze: paint(0xae8350, { metalness: 0.16 }), gold: paint(0xe7bc64, { metalness: 0.2 }),
  blueGold: paint(0x27627c), red: paint(0x972f28), purple: paint(0x704879), horse: paint(0x8b5838),
  horsePale: paint(0xb88e5e), mane: paint(0x35291f), stone: paint(0xb9a478),
  stoneDark: paint(0x897852),
  routed: paint(0x777c80),
};
const mesh = (geometry, material, parent, x = 0, y = 0, z = 0) => {
  const object = new THREE.Mesh(geometry, material);
  object.position.set(x, y, z); parent.add(object); return object;
};
const box = (w, h, d, m, p, x, y, z) => mesh(new THREE.BoxGeometry(w, h, d), m, p, x, y, z);
const sphere = (r, m, p, x, y, z) => mesh(new THREE.SphereGeometry(r, 7, 5), m, p, x, y, z);
const cyl = (top, bottom, h, m, p, x, y, z, n = 7) =>
  mesh(new THREE.CylinderGeometry(top, bottom, h, n), m, p, x, y, z);
function rod(a, b, radius, material, parent, sides = 5) {
  const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b);
  const o = cyl(radius, radius, start.distanceTo(end), material, parent,
    (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2, sides);
  o.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), end.sub(start).normalize());
  return o;
}
function flatShape(points, material, parent, x, y, z) {
  const s = new THREE.Shape(); s.moveTo(...points[0]);
  for (const point of points.slice(1)) s.lineTo(...point);
  s.closePath();
  const o = mesh(new THREE.ShapeGeometry(s), material, parent, x, y, z);
  o.material.side = THREE.DoubleSide;
  return o;
}
function plinth(g, team, routed = false) {
  const first = g.children.length;
  cyl(2.42, 2.42, .16, routed ? M.routed : M.darkWood, g, 0, .08, 0, 12);
  cyl(2.34, 2.34, .075, routed ? M.routed : team === 'egypt' ? M.egypt : M.canaan, g, 0, .2, 0, 12);
  // Three short ticks remain legible even when the unit label is hidden.
  for (const x of [-.42, 0, .42]) box(.24, .035, .08, M.gold, g, x, .25, 2.06);
  for (let i = first; i < g.children.length; i++) g.children[i].userData.unitBase = true;
}
function shield(g, egypt, x, z, large, elite) {
  const h = large ? 1.57 : 1.24, w = large ? .89 : .68;
  const group = new THREE.Group(); group.position.set(x, 2.16, z); g.add(group);
  // Egyptian round-topped hide shield; Levantine shields are a deliberately simpler oval.
  if (egypt) {
    flatShape([[-w,-h/2],[w,-h/2],[w,h*.24],[w*.75,h*.42],[0,h*.54],[-w*.75,h*.42],[-w,h*.24]],
      elite ? M.gold : M.leather, group, 0, 0, 0);
    flatShape([[-w*.78,-h*.36],[w*.78,-h*.36],[w*.78,h*.22],[0,h*.42],[-w*.78,h*.22]],
      elite ? M.egypt : M.egyptBright, group, 0, 0, .025);
  } else {
    const o = sphere(1, elite ? M.bronze : M.leather, group, 0, 0, 0);
    o.scale.set(w, h*.51, .085);
    const trim = sphere(1, M.canaanLight, group, 0, 0, .035);
    trim.scale.set(w*.82, h*.42, .082);
  }
  const boss = sphere(.15, elite ? M.gold : M.bronze, group, 0, .03, .11);
  boss.scale.z = .45;
}
function bow(g, x, y, z, egypt) {
  // Angular composite-bow outline and a separate pale bowstring.
  const wood = egypt ? M.darkWood : M.wood;
  rod([x-.25,y-.82,z],[x+.14,y-.43,z+.04],.065,wood,g);
  rod([x+.14,y-.43,z+.04],[x+.3,y,z],.065,wood,g);
  rod([x+.3,y,z],[x+.14,y+.43,z+.04],.065,wood,g);
  rod([x+.14,y+.43,z+.04],[x-.25,y+.82,z],.065,wood,g);
  rod([x-.25,y-.82,z],[x-.25,y+.82,z],.017,M.linen,g,3);
}
function spear(g, x, z, short = false) {
  const top = short ? 3.9 : 4.68;
  rod([x,.55,z],[x,top-.36,z],.045,M.wood,g);
  const tip = mesh(new THREE.ConeGeometry(.12,.45,4),M.bronze,g,x,top-.15,z);
  tip.rotation.y = Math.PI/4;
}
function axe(g, x, z) {
  rod([x,1.48,z],[x,3.57,z],.052,M.wood,g);
  const head = box(.45,.26,.11,M.bronze,g,x-.19,3.55,z);
  head.rotation.z = -.18;
}
function quiver(g, x, z) {
  const q = cyl(.18,.14,.99,M.leather,g,x,2.13,z,6); q.rotation.z = -.32;
  for (const dx of [-.09,.05]) rod([x+dx,2.52,z],[x+dx+.11,2.79,z],.024,M.wood,g,4);
}
function figure(parent, team, role, x = 0, z = 0, elite = false, tiny = false) {
  const g = new THREE.Group(); g.position.set(x,0,z);
  if (tiny) g.scale.setScalar(.72);
  parent.add(g);
  const egypt = team === 'egypt', scout = role === 'light';
  const cloth = elite ? (egypt ? M.white : M.canaanLight) : (egypt ? M.white : M.linen);
  const accent = elite ? M.gold : (egypt ? M.egyptBright : M.canaan);
  // Bare chest and short wrapped shendyt for Egyptian troops; longer colored tunic in Canaan.
  if (egypt) {
    cyl(.43,.35,.88,M.skin,g,0,2.31,0);
    cyl(.37,.57,.72,cloth,g,0,1.54,0);
    box(.82,.11,.68,accent,g,0,1.89,0);
    if (elite) box(.16,.83,.07,M.gold,g,0,2.32,.37);
  } else {
    cyl(.42,.48,.84,cloth,g,0,2.30,0);
    cyl(.43,.60,scout ? .64 : .89,accent,g,0,1.48,0);
    box(.83,.12,.68,M.leather,g,0,1.96,0);
  }
  for (const dx of [-.24,.24]) {
    rod([dx,1.24,0],[dx*1.1,.39,.055],.105,M.skin,g);
    box(.32,.13,.52,egypt ? M.linen : M.leather,g,dx*1.1,.33,.13);
  }
  for (const dx of [-.53,.53]) rod([dx*.71,2.62,0],[dx,2.04,.10],.105,M.skin,g);
  sphere(.38,egypt ? M.skin : M.skinC,g,0,3.06,0);
  if (egypt) {
    // Cropped dark hair; royal guards have a blue cloth cap.
    const cap = cyl(elite ? .39 : .35,.37,elite ? .37 : .15,
      elite ? M.egypt : M.hair,g,0,3.39,0,8);
    if (elite) box(.83,.08,.09,M.gold,g,0,3.28,.32);
  } else {
    const hair = cyl(.36,.36,.24,M.hair,g,0,3.40,-.04,8);
    if (elite) box(.78,.12,.09,M.bronze,g,0,3.47,.29);
    // Small beard gives the coalition a distinct profile, without claiming uniform equipment.
    box(.25,.20,.18,M.hair,g,0,2.82,.32);
  }
  if (role === 'archer') {
    bow(g,.67,2.27,.3,egypt); quiver(g,-.42,-.30);
  } else {
    shield(g,egypt,-.66,.33,role === 'heavy' || elite,elite);
    if (role === 'guard') axe(g,.72,.12);
    else spear(g,.69,.12,scout);
  }
  if (scout) {
    // A narrow diagonal sling reads as lighter marching equipment at the pass.
    rod([-.42,2.64,-.34],[.33,1.92,-.37],.045,M.leather,g);
  }
  return g;
}
function horse(g, z, pale = false) {
  const coat = pale ? M.horsePale : M.horse;
  const torso = box(1.57,.71,.62,coat,g,1.10,1.35,z);
  torso.rotation.z = -.03;
  const neck = box(.42,.93,.45,coat,g,1.73,1.87,z);
  neck.rotation.z = -.48;
  const head = box(.68,.40,.43,coat,g,2.04,2.29,z);
  head.rotation.z = -.14;
  for (const dz of [-.23,.23]) for (const xx of [.53,1.55]) {
    rod([xx,1.11,z+dz],[xx+(xx<1 ? -.14 : .14),.34,z+dz],.085,coat,g);
  }
  box(.47,.12,.48,M.mane,g,1.68,2.35,z);
  for (const dz of [-.18,.18]) {
    const ear = mesh(new THREE.ConeGeometry(.09,.28,4),coat,g,1.78,2.58,z+dz);
    ear.rotation.z = -.2;
  }
  rod([.38,1.55,z],[.15,.73,z+.08],.058,M.mane,g);
  // Bridle and a chest strap, readable in the oblique game camera.
  rod([1.82,2.20,z-.25],[2.20,2.18,z-.25],.025,M.darkWood,g,4);
  rod([1.35,1.23,z-.34],[1.35,1.63,z-.34],.035,M.leather,g);
}
function wheel(g, z, egypt, heavy = false) {
  const centerX = -1.25, centerY = .87, radius = .66;
  const tor = mesh(new THREE.TorusGeometry(radius,.095,5,16),egypt ? M.wood : M.darkWood,g,centerX,centerY,z);
  for (let i=0;i<(heavy ? 8 : 6);i++) {
    const a = i*Math.PI/(heavy ? 4 : 3);
    rod([centerX,centerY,z],[centerX+radius*Math.cos(a),centerY+radius*Math.sin(a),z],.038,M.wood,g,4);
  }
  sphere(.13,M.bronze,g,centerX,centerY,z+(z>0?.05:-.05));
  return tor;
}
function chariot(g, team, royal = false, heavy = false, throwingSpearAvailable = true) {
  const egypt = team === 'egypt';
  // Compact two-horse vehicle; open back, rear axle and six-spoke wheels.
  horse(g,-.74,egypt); horse(g,.74,!egypt);
  rod([-1.24,1.05,0],[1.25,1.06,0],.075,M.wood,g);
  box(1.54,.14,1.36,M.wood,g,-1.37,1.45,0);
  for (const z of [-.69,.69]) {
    const side = box(heavy ? 1.72 : 1.48,heavy ? .72 : .54,.075,royal ? M.gold : (heavy ? M.bronze : (egypt ? M.egypt : M.canaan)),
      g,-1.38,1.81,z);
    side.rotation.z = -.05;
    box(.85,.08,.085,egypt ? M.gold : M.bronze,g,-1.32,1.81,z+(z>0?.052:-.052));
    wheel(g,z > 0 ? .91 : -.91,egypt,heavy);
  }
  box(.075,.56,1.36,royal ? M.gold : M.wood,g,-.65,1.80,0);
  rod([-1.96,1.55,-.68],[-1.96,1.55,.68],.055,M.wood,g);
  // The driver and bowman stand inside the open fighting platform.
  for (const z of [-.29,.31]) {
    cyl(.24,.29,.53,z>0 && royal ? M.white : (egypt ? M.white : M.canaanLight),g,-1.38,2.02,z,6);
    sphere(.23,z>0 && !egypt ? M.skinC : M.skin,g,-1.38,2.49,z);
    cyl(.24,.24,.12,z>0 && royal ? M.egypt : M.hair,g,-1.38,2.71,z,7);
  }
  if (heavy) {
    // One spear remains for melee after the other is thrown.
    cyl(.23,.28,.51,M.canaanLight,g,-1.03,2.04,0,6);
    sphere(.22,M.skinC,g,-1.03,2.49,0);
    cyl(.23,.23,.13,M.hair,g,-1.03,2.70,0,7);
    spear(g,-.80,-.36,true);
    if (throwingSpearAvailable) spear(g,-.54,.30,true);
    box(.12,.70,.12,M.bronze,g,-1.38,1.98,-.68);
  } else { bow(g,-.94,2.40,.48,egypt); quiver(g,-1.89,.34); }
  if (royal) {
    // Thutmose III is shown in a khat cloth with uraeus, not a later fantasy crown.
    const cloth = mesh(new THREE.ConeGeometry(.29,.56,7),M.egypt,g,-1.38,2.98,.31);
    cloth.rotation.z = -.12;
    sphere(.072,M.gold,g,-1.35,2.88,.55);
    box(.09,.42,.07,M.gold,g,-1.97,2.15,.16);
  } else {
    box(.29,.41,.07,egypt ? M.egyptBright : M.canaanLight,g,-.60,1.86,.71);
  }
}
function ship(g, team, warship) {
  const hull = new THREE.Shape();
  for (const [i, [x, z]] of [[-2.75,-.52],[-2.30,-.88],[1.75,-.88],[2.85,0],[1.75,.88],[-2.30,.88],[-2.75,-.52]].entries()) {
    if (i) hull.lineTo(x, z); else hull.moveTo(x, z);
  }
  const body = mesh(new THREE.ExtrudeGeometry(hull, { depth: .78, bevelEnabled: false }),
    warship ? M.darkWood : M.wood, g, 0, .42, 0);
  body.rotation.x = -Math.PI / 2;
  box(4.7,.12,1.32,M.wood,g,-.15,1.25,0);
  for (const z of [-.66,.66]) {
    box(3.6,.33,.13,team === 'egypt' ? M.egyptBright : M.canaanLight,g,-.25,1.48,z);
    for (const x of [-1.65,-.8,.05,.9,1.65]) {
      rod([x,1.32,z],[x+.44,.35,z+(z>0?1.2:-1.2)],.045,M.linen,g);
    }
  }
  if (warship) {
    box(1.15,.33,.42,M.bronze,g,2.74,.77,0);
    figure(g,team,'archer',-.75,0,false,true);
    figure(g,team,'guard',.6,0,false,true);
    box(.9,.35,.4,M.bronze,g,-1.85,1.37,0);
  } else {
    rod([-.2,1.35,0],[-.2,4.1,0],.08,M.wood,g);
    const sail = box(.12,1.6,1.9,M.linen,g,-.14,3.13,0);
    sail.rotation.z = -.08;
    box(.12,.12,2.15,M.wood,g,-.2,3.94,0);
    box(.12,.12,2.15,M.wood,g,-.2,2.29,0);
  }
}
function trireme(g, unit) {
  const greek = unit.team === 'egypt';
  const trim = unit.kind === 'cleopatraGalley' ? M.purple :
    unit.kind === 'antonyHeavyGalley' ? M.gold : unit.kind === 'octavianLiburnian' ? M.red :
      greek ? M.egyptBright : unit.kind === 'phoenicianTrireme' ? M.canaanLight : M.red;
  const hull = box(5.35,.72,1.72,M.darkWood,g,-.12,.91,0);
  hull.rotation.z = -.025;
  box(4.8,.14,1.55,M.wood,g,-.2,1.34,0);
  for (const side of [-1,1]) {
    box(4.35,.31,.11,trim,g,-.18,1.52,side*.84);
    for (let tier=0;tier<3;tier++) for (const x of [-1.8,-.9,0,.9,1.8]) {
      const y = 1.2-tier*.22;
      rod([x,y,side*.82],[x+.28,y-.38,side*(1.65+tier*.12)],.037,
        tier===1 ? M.linen : M.wood,g,4);
    }
  }
  const ram = mesh(new THREE.ConeGeometry(.36,1.12,6),M.bronze,g,2.87,.77,0);
  ram.rotation.z = -Math.PI/2;
  box(.7,.26,.5,M.bronze,g,2.4,.77,0);
  for (const x of [-1.02,.5]) {
    cyl(.18,.22,.47,greek ? M.white : M.canaanLight,g,x,1.69,0,6);
    sphere(.17,M.skin,g,x,2.02,0);
    box(.27,.12,.29,greek ? M.bronze : M.gold,g,x,2.19,0);
  }
  rod([-.2,1.38,0],[-.2,2.95,0],.055,M.wood,g);
  box(.52,.13,.62,trim,g,-.2,2.79,0);
  if (unit.kind === 'antonyHeavyGalley') {
    for (const z of [-.58,.58]) box(2.1,.33,.14,M.bronze,g,-.25,1.92,z);
    box(1.1,.2,.72,M.wood,g,-.35,2.11,0);
  }
  if (unit.kind === 'cleopatraGalley') {
    box(.1,1.24,1.05,M.purple,g,-.32,2.27,0);
  }
  if (unit.commander || unit.kind === 'moraleFlagship') {
    rod([-1.8,1.3,0],[-1.8,3.2,0],.045,M.wood,g);
    box(.68,.48,.06,greek ? M.gold : M.red,g,-1.45,2.95,0);
  }
}
function ironAgeFigure(g, team, role, x = 0, z = 0, elite = false, tiny = false) {
  const soldier = figure(g, 'coalition', role, x, z, elite, tiny);
  if (team === 'egypt') {
    const helmet = mesh(new THREE.ConeGeometry(.39, .55, 7), elite ? M.gold : M.bronze,
      soldier, 0, 3.67, 0);
    helmet.rotation.y = Math.PI / 7;
    box(.48,.16,.12,M.gold,soldier,0,3.42,.34);
  }
  return soldier;
}
function cannaeFigure(g, team, role, x = 0, z = 0, tiny = false) {
  const roman = team === 'egypt';
  const soldier = ironAgeFigure(g, team, role, x, z, role === 'heavy', tiny);
  if (roman && role === 'heavy') {
    // Broad red scutum and metal boss identify a Roman infantry unit at map scale.
    box(.82, 1.42, .12, M.red, soldier, -.68, 2.1, .48);
    box(.2, .2, .09, M.bronze, soldier, -.68, 2.12, .59);
  } else if (!roman && role === 'heavy') {
    box(.64, .22, .1, M.white, soldier, -.68, 2.53, .48);
  }
  return soldier;
}
function siegeRam(g) {
  box(3.25,.24,1.78,M.darkWood,g,0,.72,0);
  for (const x of [-1.22,1.22]) for (const z of [-.88,.88]) {
    const wheel = mesh(new THREE.TorusGeometry(.41,.1,5,12),M.wood,g,x,.63,z);
    wheel.rotation.y = Math.PI/2;
  }
  for (const z of [-.78,.78]) for (const x of [-1.18,1.18])
    box(.16,2.0,.16,M.wood,g,x,1.78,z);
  const roof = box(3.5,.35,2.1,M.leather,g,0,2.88,0);
  roof.rotation.z = -.04;
  rod([-1.4,1.55,0],[1.95,1.55,0],.21,M.wood,g,7);
  mesh(new THREE.ConeGeometry(.32,.65,6),M.bronze,g,2.13,1.55,0).rotation.z = -Math.PI/2;
  for (const x of [-.9,.6]) box(.13,.55,.06,M.bronze,g,x,2.72,1.02);
}
function romanOnager(g) {
  box(3.45, .27, 2.12, M.darkWood, g, 0, .72, 0);
  for (const x of [-1.24, 1.24]) for (const z of [-1.02, 1.02]) {
    const wheel = mesh(new THREE.TorusGeometry(.45, .12, 6, 12), M.wood, g, x, .65, z);
    wheel.rotation.y = Math.PI / 2;
  }
  for (const z of [-.77, .77]) {
    rod([-.9, .92, z], [.35, 2.45, z], .14, M.wood, g);
    rod([.35, 2.45, z], [1.28, .92, z], .14, M.wood, g);
    rod([-.38, 1.3, z], [.8, 1.3, z], .11, M.wood, g);
  }
  rod([.12, 1.28, -.96], [.12, 1.28, .96], .25, M.darkWood, g, 8);
  for (const z of [-.8, .8]) for (let i = 0; i < 3; i++)
    rod([-.28 + i * .1, 1.07, z], [.35 + i * .1, 1.45, z], .04, M.linen, g);
  rod([.1, 1.36, 0], [1.04, 3.75, 0], .16, M.wood, g);
  sphere(.43, M.stoneDark, g, 1.11, 3.83, 0);
  box(.61, .32, .7, M.leather, g, 1.03, 3.55, 0);
  for (const z of [-.45, .45]) cannaeFigure(g, 'egypt', 'light', -1.3, z, true);
  box(.36, .19, 1.82, M.red, g, -1.54, 1.14, 0);
}
function siegeTower(g) {
  // A tall mobile timber tower with three floors, protected wheels and an
  // elevated fighting platform. Its height is deliberately legible at map scale.
  box(4.3, .45, 3.2, M.darkWood, g, 0, .65, 0);
  for (const x of [-1.55, 1.55]) for (const z of [-1.25, 1.25]) {
    const wheel = mesh(new THREE.TorusGeometry(.48, .15, 6, 14), M.wood, g, x, .53, z);
    wheel.rotation.y = Math.PI / 2;
    box(.27, 8.0, .27, M.wood, g, x, 4.7, z);
  }
  for (const y of [2.1, 4.8, 7.9]) {
    box(4.2, .25, 3.1, M.wood, g, 0, y, 0);
    for (const z of [-1.45, 1.45]) box(4.2, .8, .16, M.leather, g, 0, y + .56, z);
    for (const x of [-1.95, 1.95]) box(.16, .8, 2.9, M.leather, g, x, y + .56, 0);
  }
  for (const y of [2.55, 5.25]) for (const z of [-.72, .72])
    box(1.05, 1.2, .16, M.bronze, g, 2.05, y, z);
  box(4.7, .38, 3.6, M.darkWood, g, 0, 8.9, 0);
  box(.35, 3.5, 1.7, M.wood, g, 2.35, 9.0, 0).rotation.z = -.44;
  for (const z of [-.75, .75]) cannaeFigure(g, 'egypt', 'archer', 0, z, true, true).position.y = 7.8;
  box(.18, 1.5, 1.65, M.red, g, -1.85, 7.1, 0);
}
function arrowCamel(g) {
  const body = sphere(.85, M.leather, g, 0, 1.65, 0);
  body.scale.set(1.85, .68, .86);
  for (const x of [-.85, .88]) for (const z of [-.48, .48])
    rod([x, 1.55, z], [x + .13, .23, z], .17, M.wood, g);
  for (const x of [-.58, .48]) {
    const hump = sphere(.45, M.leather, g, x, 2.2, 0);
    hump.scale.set(.82, 1.2, .86);
  }
  rod([1.2, 1.63, 0], [1.5, 2.77, 0], .3, M.leather, g);
  sphere(.36, M.leather, g, 1.7, 2.87, 0).scale.set(1.16, .55, .7);
  for (const z of [-.72, .72]) box(.55, .85, .5, M.wood, g, -.25, 1.95, z);
  for (const z of [-.72, .72]) for (let i=0;i<3;i++)
    rod([-.49,1.72+i*.22,z*1.32],[-.02,1.72+i*.22,z*1.32],.035,M.white,g);
}
function romanTransport(g) {
  ship(g, 'egypt', false);
  for (const x of [-1.45, -.45, .55, 1.45]) {
    box(.33, .67, .11, M.red, g, x, 1.65, .72);
    box(.33, .67, .11, M.red, g, x, 1.65, -.72);
  }
  box(1.45, .25, 1.28, M.darkWood, g, -1.05, 1.48, 0);
  for (const x of [-1.45, -.7]) {
    cyl(.17, .19, .48, M.bronze, g, x, 1.89, 0, 7);
    sphere(.17, M.skin, g, x, 2.2, 0);
  }
}
function harborTower(g) {
  box(2.42, 3.15, 2.42, M.stone, g, 0, 1.8, 0);
  box(2.88, .34, 2.88, M.stoneDark, g, 0, 3.55, 0);
  for (const x of [-1.06, 0, 1.06]) for (const z of [-1.06, 1.06])
    box(.57, .67, .57, M.stoneDark, g, x, 3.99, z);
  for (const z of [-1.06, 0, 1.06]) for (const x of [-1.06, 1.06])
    box(.57, .67, .57, M.stoneDark, g, x, 3.99, z);
  box(1.65, .17, .85, M.darkWood, g, .17, 4.02, 0);
  for (const z of [-.48, .48]) {
    rod([-.65, 4.08, z], [1.36, 4.08, z * 1.42], .09, M.wood, g);
    rod([1.36, 4.08, z * 1.42], [1.48, 4.08, 0], .025, M.linen, g);
  }
  rod([-.52, 4.12, 0], [1.95, 4.12, 0], .12, M.wood, g);
  mesh(new THREE.ConeGeometry(.17, .43, 5), M.bronze, g, 2.08, 4.12, 0).rotation.z = -Math.PI / 2;
}

/** Build a single self-contained chess piece in the dimensions used by the hex map. */
export function createUnitModel(unit, scenarioId = null, options = {}) {
  if (!options.legacy && !options.phase1) {
    const upgraded = createFullModel(unit, scenarioId, options.map);
    if (upgraded) { plinth(upgraded, unit.team, isRouted(unit)); upgraded.children.sort((a,b)=>Number(b.isMesh||false)-Number(a.isMesh||false)); return upgraded; }
  }
  if (!options.legacy && supportsV02(unit, scenarioId)) {
    const upgraded = createV02(unit, scenarioId);
    plinth(upgraded, unit.team, isRouted(unit));
    return upgraded;
  }
  const g = new THREE.Group(), team = unit.team === 'egypt' ? 'egypt' : 'coalition';
  plinth(g, team, isRouted(unit));
  if (unit.kind === 'moraleGuard') {
    ironAgeFigure(g, team, 'guard', -.5, 0, true);
    ironAgeFigure(g, team, 'guard', .65, .3, false, false);
    rod([1.25, .45, -.45], [1.25, 4.7, -.45], .065, M.wood, g);
    box(.82, .6, .08, team === 'egypt' ? M.red : M.gold, g, 1.65, 4.35, -.45);
    return g;
  }
  if (unit.kind === 'moraleFlagship') {
    trireme(g, unit);
    return g;
  }
  if ((['salamis', 'tyre', 'carthage', 'syracuse', 'aegospotami'].includes(scenarioId) && unit.kind.endsWith('Trireme')) ||
      (scenarioId === 'actium' && ['octavianLiburnian', 'antonyHeavyGalley', 'cleopatraGalley'].includes(unit.kind))) {
    trireme(g,unit);
    return g;
  }
  if (['tyre', 'carthage', 'syracuse'].includes(scenarioId) && unit.kind === 'siegeGalley') {
    trireme(g, { ...unit, kind: 'alliedTrireme' });
    box(1.45, .18, 1.35, M.wood, g, -.45, 2.58, 0);
    for (const x of [-1.05, .15]) for (const z of [-.51, .51])
      box(.12, 1.22, .12, M.wood, g, x, 2.02, z);
    rod([-.55, 2.72, 0], [2.38, 2.92, 0], .11, M.darkWood, g);
    box(.56, .27, .44, M.bronze, g, 2.25, 2.9, 0);
    return g;
  }
  if (scenarioId === 'carthage' && unit.kind === 'transport') {
    romanTransport(g);
    return g;
  }
  if (['carthage', 'syracuse'].includes(scenarioId) && unit.kind === 'defenseTower') {
    harborTower(g);
    return g;
  }
  if (scenarioId?.startsWith('china_')) {
    switch (unit.kind) {
      case 'chinaGeneral':
        ironAgeFigure(g, team, 'guard', 0, 0, true);
        rod([1.18, .45, -.42], [1.18, 4.95, -.42], .07, M.wood, g);
        box(.9, .72, .08, team === 'egypt' ? M.red : M.gold, g, 1.65, 4.55, -.42);
        break;
      case 'moraleGuard':
        ironAgeFigure(g, team, 'guard', -.5, 0, true);
        ironAgeFigure(g, team, 'guard', .65, .3, false, false);
        rod([1.25, .45, -.45], [1.25, 4.7, -.45], .065, M.wood, g);
        box(.82, .6, .08, team === 'egypt' ? M.red : M.gold, g, 1.65, 4.35, -.45);
        break;
      case 'chinaCrossbow':
        ironAgeFigure(g, team, 'archer', 0, 0);
        rod([-.95, 2.12, .64], [1.25, 2.12, .64], .07, M.wood, g);
        rod([.25, 2.12, -.28], [.25, 2.12, 1.3], .045, M.bronze, g);
        break;
      case 'chinaFireOx': {
        const body = sphere(.82, M.stoneDark, g, -.12, 1.55, 0);
        body.scale.set(1.8, .82, 1.05);
        for (const x of [-.95, .85]) for (const z of [-.53, .53])
          cyl(.15, .2, 1.35, M.stoneDark, g, x, .72, z, 6);
        sphere(.54, M.stoneDark, g, 1.22, 1.83, 0);
        for (const z of [-.42, .42]) rod([1.32, 2.14, z], [1.78, 2.82, z * 1.5], .065, M.white, g);
        box(1.45, .1, 1.25, M.red, g, -.2, 2.37, 0);
        break;
      }
      case 'siegeRam': siegeRam(g); break;
      case 'supplyWagon':
        box(2.7, .35, 1.65, M.darkWood, g, 0, 1.05, 0);
        box(2.35, 1.05, 1.45, M.wood, g, 0, 1.65, 0);
        for (const x of [-.88, .88]) for (const z of [-.9, .9])
          cyl(.48, .48, .14, M.bronze, g, x, .62, z, 10).rotation.x = Math.PI / 2;
        for (const x of [-.7, 0, .7])
          box(.62, .38, 1.15, M.linen, g, x, 2.36, 0);
        break;
      case 'chinaHeavyChariot':
        chariot(g, team, false, true);
        horse(g, -2.05, team === 'egypt'); horse(g, 2.05, team !== 'egypt');
        for (const z of [-2.05, 2.05]) rod([-1.2, 1.78, z], [1.66, 1.7, z], .028, M.leather, g);
        break;
      case 'chariot': chariot(g, team, false, true); break;
      case 'cavalry':
        horse(g, 0, team !== 'egypt');
        ironAgeFigure(g, team, 'guard', .95, 0, true, true).position.y = 1.16;
        break;
      case 'archer': ironAgeFigure(g, team, 'archer'); break;
      case 'light': ironAgeFigure(g, team, 'light'); break;
      default:
        ironAgeFigure(g, team, unit.kind === 'guard' ? 'guard' : 'heavy', .43, -.34);
        ironAgeFigure(g, team, unit.kind === 'guard' ? 'guard' : 'heavy', -.77, .56, false, false);
    }
    g.rotation.y = team === 'egypt' ? 0 : Math.PI;
    return g;
  }
  if (scenarioId === 'cannae' || scenarioId === 'zama' || scenarioId === 'carthage' || scenarioId === 'pharsalus' || scenarioId === 'teutoburg' || scenarioId === 'jerusalem' || scenarioId === 'carrhae' || scenarioId === 'syracuse' || scenarioId === 'pydna' || scenarioId === 'mantinea') {
    switch (unit.kind) {
      case 'siegeRam': siegeRam(g); break;
      case 'romanOnager': romanOnager(g); break;
      case 'siegeTower': siegeTower(g); break;
      case 'arrowCamel': arrowCamel(g); break;
      case 'parthianHorseArcher':
        horse(g, 0, true);
        cannaeFigure(g, team, 'archer', .9, 0, true).position.y = 1.16;
        break;
      case 'parthianCataphract':
        horse(g, 0, false);
        box(2.4, .42, 1.02, M.bronze, g, -.05, 1.7, 0);
        cannaeFigure(g, team, 'guard', .9, 0, true).position.y = 1.16;
        rod([1.4,2.3,.12],[3.4,2.75,.12],.075,M.wood,g);
        break;
      case 'romanArcher':
        cannaeFigure(g, team, 'archer', -.68, -.36);
        cannaeFigure(g, team, 'archer', .66, .4, false);
        break;
      case 'engineer':
        cannaeFigure(g, team, 'light', -.55, -.36);
        cannaeFigure(g, team, 'light', .65, .4, false);
        rod([-.8, 2.2, .75], [1.1, 2.2, .75], .12, M.wood, g);
        break;
      case 'romanHorse': case 'romanAlliedHorse': case 'punicHeavyHorse': case 'pompeyHorse': case 'numidianHorse':
      case 'masinissa': case 'masinissaHorse': case 'zamaPunicHorse':
        horse(g, 0, ['numidianHorse', 'romanAlliedHorse', 'masinissa', 'masinissaHorse'].includes(unit.kind));
        cannaeFigure(g, team, ['numidianHorse', 'masinissa', 'masinissaHorse'].includes(unit.kind) ? 'light' : 'guard', .9, 0, true).position.y = 1.16;
        if (['numidianHorse', 'masinissa', 'masinissaHorse'].includes(unit.kind)) spear(g, 1.46, .2, true);
        break;
      case 'companionCavalry':
        horse(g, 0, false);
        cannaeFigure(g, team, 'guard', .9, 0, true).position.y = 1.16;
        spear(g, 1.46, .2, true);
        break;
      case 'phalangite':
        cannaeFigure(g, team, 'heavy', .43, -.34);
        cannaeFigure(g, team, 'heavy', -.77, .56, false);
        if (unit.formed) for (const z of [-.55,.22,.86]) rod([-.68,2.18,z],[2.38,2.12,z],.055,M.wood,g);
        break;
      case 'greekHoplite':
        ironAgeFigure(g, team, 'heavy', .43, -.34);
        ironAgeFigure(g, team, 'heavy', -.77, .56, false, false);
        if (unit.formed) for (const z of [-.55,.55]) rod([-.45,2.1,z],[1.75,2.04,z],.06,M.wood,g);
        break;
      case 'hannibal': case 'paullus': case 'varro': case 'scipio':
        cannaeFigure(g, team, 'guard', 0, 0);
        rod([1.17, .4, -.4], [1.17, 4.8, -.4], .06, M.wood, g);
        box(.72, .8, .08, team === 'egypt' ? M.red : M.gold, g, 1.52, 4.35, -.4);
        break;
      case 'warElephant': {
        const body = sphere(1.05,M.stoneDark,g,-.15,2.22,0);
        body.scale.set(1.82,1.12,1.2);
        for (const x of [-1.14,.83]) for (const z of [-.72,.72])
          cyl(.29,.34,1.66,M.stoneDark,g,x,1.1,z,7);
        const head = sphere(.82,M.stoneDark,g,1.28,2.62,0);
        head.scale.set(1.05,.9,1.02);
        for (const z of [-.6,.6]) {
          const ear = sphere(.42,M.stone,g,1.18,2.79,z);
          ear.scale.set(.31,.78,.83);
          rod([1.72,2.23,z*.58],[2.38,1.63,z*.8],.085,M.white,g);
        }
        rod([1.93,2.36,0],[2.13,1.42,0],.23,M.stoneDark,g,7);
        rod([2.13,1.42,0],[1.95,.73,.12],.2,M.stoneDark,g,7);
        box(1.8,.09,1.3,M.red,g,-.2,3.32,0);
        cannaeFigure(g,'coalition','light',-.23,-.1,true).position.y = 2.17;
        break;
      }
      case 'romanVelites': case 'punicSkirmisher':
        cannaeFigure(g, team, 'light');
        break;
      default:
        cannaeFigure(g, team, 'heavy', .43, -.34);
        cannaeFigure(g, team, 'heavy', -.77, .56, false);
        if (unit.formed && ['romanHastati', 'romanPrincipes', 'romanTriarii', 'romanLegion', 'caesarReserve', 'pompeyLegion'].includes(unit.kind))
          for (const z of [-.45,.5]) rod([-.35,2.2,z],[2.1,2.14,z],.052,M.wood,g);
    }
    g.rotation.y = team === 'egypt' ? 0 : Math.PI;
    return g;
  }
  if (scenarioId === 'gaugamela' || scenarioId === 'issus' || scenarioId === 'tyre') {
    switch (unit.kind) {
      case 'phalangite':
        ironAgeFigure(g,'egypt','heavy',-.52,-.42);
        ironAgeFigure(g,'egypt','heavy',-.88,.76,false,false);
        if (unit.formed) for (const z of [-.55,.22,.86]) {
          rod([-.68,2.18,z],[2.38,2.12,z],.055,M.wood,g);
          mesh(new THREE.ConeGeometry(.12,.42,5),M.bronze,g,2.48,2.12,z).rotation.z = -Math.PI/2;
        }
        break;
      case 'companionCavalry':
        horse(g,0,false);
        ironAgeFigure(g,'egypt','guard',.95,0,true,true).position.y = 1.16;
        rod([.3,2.9,-.38],[2.65,2.65,-.38],.065,M.wood,g);
        break;
      case 'scythedChariot':
        chariot(g,'coalition',false,true,false);
        for (const z of [-1.05,1.05]) {
          const blade = mesh(new THREE.ConeGeometry(.16,.85,4),M.bronze,g,-1.32,.91,z);
          blade.rotation.z = Math.PI/2;
        }
        break;
      case 'engineer':
        ironAgeFigure(g, team, 'light', -.55, -.36);
        ironAgeFigure(g, team, 'light', .65, .4, false, false);
        rod([-.8, 2.2, .75], [1.1, 2.2, .75], .12, M.wood, g);
        break;
      case 'siegeRam': siegeRam(g); break;
      case 'warElephant': {
        const body = sphere(1.05,M.stoneDark,g,-.15,2.22,0);
        body.scale.set(1.82,1.12,1.2);
        for (const x of [-1.14,.83]) for (const z of [-.72,.72])
          cyl(.29,.34,1.66,M.stoneDark,g,x,1.1,z,7);
        const head = sphere(.82,M.stoneDark,g,1.28,2.62,0);
        head.scale.set(1.05,.9,1.02);
        for (const z of [-.6,.6]) {
          const ear = sphere(.42,M.stone,g,1.18,2.79,z);
          ear.scale.set(.31,.78,.83);
          rod([1.72,2.23,z*.58],[2.38,1.63,z*.8],.085,M.white,g);
        }
        rod([1.93,2.36,0],[2.13,1.42,0],.23,M.stoneDark,g,7);
        rod([2.13,1.42,0],[1.95,.73,.12],.2,M.stoneDark,g,7);
        box(1.8,.09,1.3,M.red,g,-.2,3.32,0);
        ironAgeFigure(g,'coalition','light',-.23,-.1,false,true).position.y = 2.17;
        if (unit.uncontrolled) box(2.2,.14,.14,M.gold,g,0,3.35,0);
        break;
      }
      case 'pharaoh':
        horse(g,0,false);
        ironAgeFigure(g,'egypt','guard',.96,0,true,true).position.y = 1.16;
        cyl(.29,.31,.15,M.gold,g,.96,4.57,0,8);
        break;
      case 'hittiteKing':
        chariot(g,'coalition',true,true,false);
        box(.48,.6,.07,M.red,g,-.38,2.26,.7);
        break;
      case 'guard':
      case 'heavy':
        ironAgeFigure(g,team,unit.kind,.43,-.34,unit.kind === 'guard');
        ironAgeFigure(g,team,unit.kind,-.77,.56,unit.kind === 'guard',false);
        break;
      case 'archer': ironAgeFigure(g,team,'archer'); break;
      case 'cavalry':
        horse(g,0,team !== 'egypt');
        ironAgeFigure(g,team,'guard',.95,0,false,true).position.y = 1.16;
        break;
      default: ironAgeFigure(g,team,'light');
    }
    if (unit.kind !== 'phalangite') g.rotation.y = team === 'egypt' ? 0 : Math.PI;
    return g;
  }
  if (scenarioId === 'qarqar' || scenarioId === 'babylon') {
    switch (unit.kind) {
      case 'captive':
        cyl(.4,.62,1.65,M.linen,g,0,1.62,0,8);
        sphere(.36,M.skinC,g,0,2.72,0);
        cyl(.38,.36,.18,M.hair,g,0,3.06,0,8);
        box(.82,.12,.6,M.white,g,0,1.95,0);
        break;
      case 'siegeRam': siegeRam(g); break;
      case 'cavalry': {
        horse(g,0,team !== 'egypt');
        const rider = ironAgeFigure(g,team,'guard',.95,0,false,true);
        rider.position.y = 1.16; rider.scale.setScalar(.68);
        break;
      }
      case 'chariot': chariot(g,scenarioId === 'babylon' ? team : 'coalition',false,scenarioId === 'qarqar'); break;
      case 'pharaoh': case 'hittiteKing':
        ironAgeFigure(g,team,'guard',0,0,true);
        cyl(.43,.46,.18,M.gold,g,0,3.64,0,9);
        break;
      case 'guard':
        ironAgeFigure(g,team,'guard',.43,-.34,true);
        ironAgeFigure(g,team,'guard',-.77,.56,true,false);
        break;
      case 'heavy':
        ironAgeFigure(g,team,'heavy',.43,-.34);
        ironAgeFigure(g,team,'heavy',-.77,.56,false,false);
        break;
      case 'archer': ironAgeFigure(g,team,'archer'); break;
      default: ironAgeFigure(g,team,'light');
    }
    g.rotation.y = team === 'egypt' ? 0 : Math.PI;
    return g;
  }
  switch (unit.kind) {
    case 'warship': ship(g,team,true); break;
    case 'transport': ship(g,team,false); break;
    case 'hero':
      figure(g,team,'guard',0,0,true);
      spear(g,.98,.26);
      box(.9,.16,.16,M.gold,g,0,3.5,.1);
      break;
    case 'chariot': chariot(g,team); break;
    case 'hittiteChariot': chariot(g,'coalition',false,true,unit.ammo > 0); break;
    case 'siegeRam': siegeRam(g); break;
    case 'trojanHorse': g.add(createTrojanHorseModel()); break;
    case 'cavalry':
      horse(g,0,team !== 'egypt');
      figure(g,team,'guard',0,0,false,true).position.y = 1.16;
      break;
    case 'pharaoh':
      if (scenarioId === 'troy') {
        figure(g,'egypt','guard',0,0,true);
        cyl(.41,.41,.14,M.gold,g,0,3.48,0,9);
      } else chariot(g,'egypt',true);
      break;
    case 'hittiteKing':
      figure(g,'coalition','guard',0,0,true);
      cyl(.43,.48,.20,M.gold,g,0,3.62,0,9);
      box(.18,.26,.12,M.red,g,0,3.80,.37);
      rod([1.13,.36,-.40],[1.13,4.78,-.40],.058,M.wood,g);
      box(.76,.92,.07,M.red,g,1.48,4.28,-.40);
      break;
    case 'archer': figure(g,team,'archer'); break;
    case 'light': figure(g,team,'light'); break;
    case 'heavy':
      figure(g,team,'heavy',.43,-.34);
      figure(g,team,'heavy',-.77,.56,false,false);
      break;
    case 'guard':
      figure(g,team,'guard',.43,-.34,true);
      figure(g,team,'guard',-.77,.56,true,false);
      break;
    default: figure(g,team,'light');
  }
  g.rotation.y = team === 'egypt' ? 0 : Math.PI;
  return g;
}

export function createTrojanHorseModel() {
  const g = new THREE.Group();
  box(4.6,.25,2.2,M.darkWood,g,0,.72,0);
  for (const x of [-1.55,1.55]) for (const z of [-1.16,1.16]) {
    const wheel = mesh(new THREE.TorusGeometry(.48,.10,5,12),M.wood,g,x,.66,z);
    wheel.rotation.y = 0;
    box(.52,2.4,.5,M.wood,g,x,1.95,z*.57);
  }
  box(3.1,1.8,1.54,M.wood,g,-.15,3.65,0);
  for (const x of [-1.45,-.75,-.05,.65,1.32])
    box(.08,1.67,1.6,M.darkWood,g,x,3.66,0);
  const neck = box(.9,2.18,.84,M.wood,g,1.35,5.05,0);
  neck.rotation.z = -.34;
  box(1.38,.73,.9,M.wood,g,2.06,6.13,0);
  for (const z of [-.28,.28]) {
    const ear = mesh(new THREE.ConeGeometry(.15,.46,4),M.darkWood,g,2.08,6.65,z);
    ear.rotation.z = -.20;
    sphere(.07,M.darkWood,g,2.54,6.23,z > 0 ? .46 : -.46);
  }
  rod([-1.65,3.9,0],[-2.35,2.55,0],.22,M.darkWood,g,5);
  box(.94,.22,.94,M.darkWood,g,-.1,4.65,0);
  return g;
}

export function createFortModel(level, hpRatio = 1, neighbors = []) {
  const g = new THREE.Group();
  const h = [0, 1.75, 2.6, 3.5][level];
  if (neighbors.length) {
    box(2.6,h,2.6,M.stoneDark,g,0,h/2,0);
    for (const { x, z } of neighbors) {
      const length = Math.hypot(x,z)/2;
      const arm = new THREE.Group(); arm.rotation.y = -Math.atan2(z,x); g.add(arm);
      box(length+.25,h,2.15,M.stone,arm,length/2,h/2,0);
      for (let p=1.2;p<length;p+=1.55) box(.8,.65,2.4,M.stoneDark,arm,p,h+.3,0);
    }
  } else {
    box(9.6,h,2.15,M.stone,g,0,h/2,0);
    for (const x of [-4.3,-2.6,-.9,.8,2.5,4.2]) box(.9,.7,2.4,M.stoneDark,g,x,h+.3,0);
  }
  if (hpRatio<.5) box(2.6,.4,2.6,M.stoneDark,g,0,h+.12,0);
  return g;
}
