import test from 'node:test';
import assert from 'node:assert/strict';
import { TERRAIN, newMap, setTerrain, setFort, addUnit, startGame, mobileAt,
  fortAt, reachable, move, setUnitStats, exportMap, importMap, recomputeFog, aiTurn } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

// An isolated one-cell-wide land corridor makes bypassing the wall impossible.
function corridor(kind = 'cavalry', team = 'egypt', level = 1) {
  const map = newMap(10, 6);
  map.scenarioId = 'custom_wall_transit';
  for (let r = 0; r < map.rows; r++) for (let c = 0; c < map.cols; c++)
    setTerrain(map, c, r, r === 3 || c === 0 && r === 0 || c === 9 && r === 5 ? TERRAIN.PLAIN : TERRAIN.SEA);
  assert.ok(addUnit(map, 'pharaoh', 'egypt', 0, 0));
  assert.ok(addUnit(map, 'light', team === 'egypt' ? 'coalition' : 'egypt', 9, 5));
  assert.ok(setFort(map, 3, 3, level, team));
  assert.ok(addUnit(map, kind, team, 2, 3));
  const s = startGame(map);
  s.side = team;
  recomputeFog(s);
  return { s, u: mobileAt(s.map, 2, 3) };
}

for (const [kind, team] of [
  ['cavalry', 'egypt'], ['chariot', 'egypt'], ['chinaHeavyChariot', 'egypt'],
  ['pharaoh', 'egypt'], ['hittiteChariot', 'coalition'], ['romanHorse', 'egypt'],
  ['parthianCataphract', 'coalition'], ['arrowCamel', 'coalition'],
]) test(`${kind} crosses an allied level-one wall without stopping on it`, () => {
  const { s, u } = corridor(kind, team);
  const wall = fortAt(s.map, 3, 3), hp = wall.hp;
  assert.equal(reachable(s, u).has('3,3'), false);
  assert.equal(move(s, u.id, 3, 3).ok, false);
  assert.deepEqual(reachable(s, u).get('4,3')?.path, [{ c: 3, r: 3 }, { c: 4, r: 3 }]);
  const result = move(s, u.id, 4, 3);
  assert.equal(result.ok, true);
  assert.deepEqual([u.c, u.r, u.actionsLeft, u.movedSteps], [4, 3, 1, 2]);
  assert.equal(wall.hp, hp);
});

test('other movers unable to mount walls may transit if their movement budget allows', () => {
  for (const kind of ['siegeRam', 'romanOnager', 'siegeTower', 'warElephant', 'trojanHorse']) {
    const { s, u } = corridor(kind);
    setUnitStats(s.map, kind, { move: 2 });
    assert.equal(reachable(s, u).has('3,3'), false, kind);
    assert.equal(move(s, u.id, 4, 3).ok, true, kind);
  }
});

test('transit costs ordinary steps and grants no level-two wall travel bonus', () => {
  const { s, u } = corridor();
  setUnitStats(s.map, u.kind, { move: 1 });
  assert.equal(reachable(s, u).has('4,3'), false);
  setUnitStats(s.map, u.kind, { move: 3 });
  assert.ok(setFort(s.map, 4, 3, 1, 'egypt'));
  assert.deepEqual(reachable(s, u).get('5,3')?.path, [{ c: 3, r: 3 }, { c: 4, r: 3 }, { c: 5, r: 3 }]);
  assert.equal(reachable(s, u).has('4,3'), false);
  assert.equal(reachable(s, u).has('6,3'), false);
});

test('enemy walls and occupied allied walls still block transit', () => {
  for (const occupied of [false, true]) {
    const { s, u } = corridor();
    if (occupied) assert.ok(addUnit(s.map, 'light', 'egypt', 3, 3));
    else fortAt(s.map, 3, 3).team = 'coalition';
    recomputeFog(s);
    assert.equal(reachable(s, u).has('4,3'), false);
    assert.equal(move(s, u.id, 4, 3).ok, false);
  }
});

test('damaged walls allow transit; destroyed walls permit ground-level stopping', () => {
  const { s, u } = corridor();
  const wall = fortAt(s.map, 3, 3);
  wall.hp = 1;
  assert.ok(reachable(s, u).has('4,3'));
  assert.equal(reachable(s, u).has('3,3'), false);
  wall.hp = 0;
  assert.ok(reachable(s, u).has('3,3'));
});

test('low-wall transit does not override terrain or higher-wall restrictions', () => {
  const { s, u } = corridor('chinaHeavyChariot');
  setTerrain(s.map, 3, 3, TERRAIN.MOUNTAIN | TERRAIN.ROAD);
  assert.equal(reachable(s, u).has('4,3'), true); // v12 allows mountain-road transit
  setTerrain(s.map,3,3,TERRAIN.MOUNTAIN);
  assert.equal(reachable(s,u).has('4,3'),false);
  for (const level of [2, 3]) {
    const other = corridor('chinaHeavyChariot', 'egypt', level);
    assert.equal(reachable(other.s, other.u).has('4,3'), false);
    assert.equal(reachable(other.s, other.u).has('3,3'), false);
    const cavalry = corridor('cavalry', 'egypt', level);
    assert.ok(reachable(cavalry.s, cavalry.u).has('3,3'));
  }
});

test('editor placement and save roundtrips retain stopping restrictions', () => {
  const { s, u } = corridor();
  assert.equal(addUnit(s.map, 'chariot', 'egypt', 3, 3), false);
  assert.ok(addUnit(s.map, 'light', 'egypt', 3, 3));
  s.map.units = s.map.units.filter(x => x.kind !== 'light' || x.team !== 'egypt');
  assert.ok(move(s, u.id, 4, 3).ok);
  assert.ok(importMap(exportMap(s.map)));
  const restored = restoreSave(JSON.parse(JSON.stringify(createSave(s.map, s, 'egypt')))).game;
  const v = restored.map.units.find(x => x.id === u.id);
  assert.deepEqual([v.c, v.r], [4, 3]);
  assert.ok(reachable(restored, v).has('2,3'));
  assert.equal(reachable(restored, v).has('3,3'), false);
});

test('AI marching uses the same allied low-wall passage', () => {
  const { s, u } = corridor();
  assert.ok(addUnit(s.map, 'chinaGeneral', 'egypt', 1, 3));
  s.map.victory = { mode: 'china', attacker: 'egypt', objective: { c: 7, r: 3 },
    losses: { egypt: 100, coalition: 100 } };
  const orders = aiTurn(s, () => 0.99);
  const crossing = orders.find(order => order.type === 'move' && order.id === u.id);
  assert.ok(crossing);
  assert.ok(crossing.to.c >= 4);
  assert.equal(crossing.to.r, 3);
  assert.equal(fortAt(s.map, u.c, u.r), null);
});
