import {validFacing,facingYaw} from './directions12.mjs';
import {HIT_FLASH_MS} from './hit-feedback.mjs';
import * as T from '../vendor/three/three.module.js';
import {offsetToWorld} from '../js/core/hex.js';
import {isRouted,isShip,neighbors} from './engine.mjs';
import {visualProfile,actionFor} from './visual-profiles.mjs';
import {animateFullModel} from './full-models.mjs';
import {animateV02} from './models-v02.mjs';
export const headingBetween=(a,b)=>{const p=offsetToWorld(a.c,a.r),q=offsetToWorld(b.c,b.r);return -Math.atan2(q.z-p.z,q.x-p.x);};
export const angleDelta=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
// Ease heading independently of the unchanged 340 ms path step. Zero angular
// speed at either end avoids abrupt starts/stops, including at path corners.
const moveTurnBlend=elapsed=>{const t=Math.max(0,Math.min(1,elapsed/200));return t*t*(3-2*t);};
const cell=p=>({c:p.c,r:p.r});
const same=(a,b)=>a&&b&&a.c===b.c&&a.r===b.r;
const point=p=>{const v=offsetToWorld(p.c,p.r);return new T.Vector3(v.x,0,v.z);};
// All state below is ephemeral presentation data. No unit object is retained or mutated.
export function createUnitAnimator(){
 const states=new Map();let anchors=new WeakMap(),effects=null,quality='standard',height=()=>0,surface=null;
 function state(id){if(!states.has(id))states.set(id,{queue:[],heading:0,last:null,hitUntil:0});return states.get(id);}
 function enqueue(id,event,now){const s=state(id),previous=s.queue.at(-1);event.initialHeading=previous?.terminalHeading??s.renderYaw??s.heading;event.terminalHeading=event.type==='move'?headingBetween(event.nodes.at(-2),event.nodes.at(-1)):headingBetween(event.result.visual.from,event.result.visual.to);event.start=Math.max(now,s.queue.at(-1)?.end||now);event.end=event.start+event.duration;s.queue.push(event);return event;}
 function movement(id,from,path,now){if(!path?.length)return;const nodes=[cell(from),...path.map(cell)];enqueue(id,{type:'move',nodes,duration:path.length*340,initialHeading:state(id).heading},now);state(id).queuedCell=nodes.at(-1);}
 function launch(s,event,model,now){if(event.fired)return;event.fired=true;if(!effects)return;
  const start=point(event.result.visual.from);start.y=height(event.result.visual.from)+2.5;const target=point(event.result.visual.to);target.y=height(event.result.visual.to)+1.8;
  if(model){model.updateMatrixWorld(true);const near=model.children.find(c=>c.visible&&(c.name==='near'||c.name==='far'));const muzzle=near?.getObjectByName('muzzle');if(muzzle)muzzle.getWorldPosition(start);}
  effects.launch(event.result,start,target,event.action,now);
 }
 const api={
  setEffects(value){effects=value;},setHeightResolver(fn){height=fn;},setSurfaceResolver(fn){surface=fn;},setQuality(value){quality=value==='low'?'low':'standard';},
  observe(units,now,map){const alive=new Set();for(const u of units){alive.add(u.id);const s=state(u.id),prev=s.last,p=visualProfile(u,map?.scenarioId,map);if(prev&&!same(prev,u)&&!same(s.queuedCell,u))movement(u.id,prev,[u],now);if(prev&&u.hp<prev.hp)s.hitUntil=now+HIT_FLASH_MS;s.last={...cell(u),hp:u.hp,kind:u.kind,team:u.team,facing:u.facing,heading12:u.heading12,formed:u.formed,routed:isRouted(u)};s.profile=p;const oldRuleHeading=s.ruleHeading;if(p?.ruleFacing&&validFacing(u.facing))s.ruleHeading=facingYaw(u.facing);else s.ruleHeading=null;if(prev&&isShip(u)&&s.ruleHeading!=null&&oldRuleHeading!=null&&Math.abs(angleDelta(oldRuleHeading,s.ruleHeading))>1e-8)s.ruleTurn={from:s.renderYaw??oldRuleHeading,to:s.ruleHeading,start:now};if(!prev)s.heading=s.ruleHeading??(u.heading12!==undefined?(3-u.heading12)*Math.PI/6:(u.team==='egypt'?0:Math.PI));}
   for(const id of states.keys())if(!alive.has(id))states.delete(id);
  },
  move(id,from,path,now){movement(id,from,path,now);},
  attack(result,now,map){if(!result?.ok||!result.visual)return null;const v=result.visual,s=state(v.attackerId);const p=visualProfile({kind:v.attackerKind,team:v.attackerTeam},map?.scenarioId,map)||s.profile;return enqueue(v.attackerId,{type:'attack',result:structuredClone(result),action:actionFor(p,v),duration:700,initialHeading:s.heading},now);},
  actions(actions,now,map,visible=()=>true){for(const a of actions){if(a.type==='move'&&visible(a.from)&&visible(a.to))movement(a.id,a.from,a.to.path?.length?a.to.path:[a.to],now);else if(a.type==='attack'&&(visible(a.result?.visual?.from)||visible(a.result?.visual?.to)))api.attack(a.result,now,map);}},
  update(group,camera,now){let detailed=0;for(const model of group.children){const s=states.get(model.userData.unitId);if(!s||!model.userData.fullUnit&&!model.userData.v02)continue;
   while(s.queue[0]&&now>=s.queue[0].end){const ended=s.queue.shift();if(ended.type==='attack'){launch(s,ended,null,now);if(s.ruleHeading==null)s.heading=s.last.heading12!==undefined?(3-s.last.heading12)*Math.PI/6:headingBetween(ended.result.visual.from,ended.result.visual.to);}else s.heading=headingBetween(ended.nodes.at(-2),ended.nodes.at(-1));}
   const event=s.queue[0],active=event&&now>=event.start;let moving=false,action='none',progress=0,position=point(s.last),yaw=s.ruleHeading??s.heading;
   position.y=height(s.last);
   if(active&&event.type==='move'){moving=true;const elapsed=now-event.start,idx=Math.min(event.nodes.length-2,Math.floor(elapsed/340)),local=(elapsed-idx*340);const from=event.nodes[idx],to=event.nodes[idx+1],desired=headingBetween(from,to),old=idx?headingBetween(event.nodes[idx-1],from):event.initialHeading;yaw=s.profile?.formed?s.ruleHeading:old+angleDelta(old,desired)*moveTurnBlend(local);const blend=isShip(s.last)?local/340:Math.max(0,(local-90)/250);position=point(from).lerp(point(to),blend);position.y=height(from)+(height(to)-height(from))*blend;
    if(surface){const a=point(from),b=point(to),extraA=height(from)-surface(a.x,a.z),extraB=height(to)-surface(b.x,b.z);position.y=surface(position.x,position.z)+extraA+(extraB-extraA)*blend;}
    s.heading=desired;}
   if(active&&event.type==='attack'){action=event.action;progress=(now-event.start)/700;position=point(event.result.visual.from);position.y=height(event.result.visual.from);const desired=headingBetween(event.result.visual.from,event.result.visual.to);yaw=s.ruleHeading??event.initialHeading+angleDelta(event.initialHeading,desired)*Math.min(1,progress/.18);if(s.ruleHeading==null){s.heading=s.last.heading12!==undefined?(3-s.last.heading12)*Math.PI/6:desired;if(progress>.82)yaw+=angleDelta(yaw,s.heading)*moveTurnBlend((progress-.82)/.18*200);}}
   if(isShip(s.last)&&s.ruleTurn&&!(active&&event.type==='move'))yaw=s.ruleTurn.from+angleDelta(s.ruleTurn.from,s.ruleTurn.to)*moveTurnBlend(now-s.ruleTurn.start);
   // Move the complete piece, including its colored base. The rule position is
   // already the destination; retain only the model's fixed placement offset.
   if(!anchors.has(model)){const target=point(s.last);target.y=height(s.last);anchors.set(model,model.position.clone().sub(target));}
   model.position.copy(position).add(anchors.get(model));
   if(model.userData.previewFacing!=null)yaw=facingYaw(model.userData.previewFacing);model.rotation.y=yaw;s.renderYaw=yaw;const dist=model.position.distanceTo(camera.position),complex=quality==='standard'&&dist<115&&detailed++<48;
   let animationDistance=quality==='low'?150:dist;
   const ship=isShip(s.last);
   if(ship){
    // Hysteresis stops near/far models alternating at one sharp distance cutoff.
    if(quality==='low')s.shipFar=true;
    else if(s.shipFar===undefined)s.shipFar=dist>115;
    else if(dist>130)s.shipFar=true;
    else if(dist<100)s.shipFar=false;
    animationDistance=s.shipFar?Math.max(116,animationDistance):Math.min(114,animationDistance);
   }
   // The piece glides; its oars and deck crew do not use marching locomotion.
   if(model.userData.fullUnit)animateFullModel(model,now,{moving:moving&&!ship,routed:s.last.routed,action,progress,hit:s.hitUntil>now?1:0,distance:animationDistance,complex});else animateV02(model,now,{moving,routed:s.last.routed,hit:s.hitUntil>now?1:0,distance:dist,complex});
   for(const level of model.children.filter(c=>c.name==='near'||c.name==='far')){const visual=level.children[0];
    if(active&&event.type==='attack'&&s.ruleHeading!=null&&!s.profile?.formed){const relative=headingBetween(event.result.visual.from,event.result.visual.to)-yaw;visual.traverse(o=>{if(o.name==='soldier'||o.name==='rider')o.rotation.y=Math.PI/2+relative;});}}
   if(active&&event.type==='attack'&&progress>=.55)launch(s,event,model,now);
  }effects?.update(now);},
  inspect(id){const s=states.get(id);return s?{heading:s.heading,queue:s.queue.map(e=>({type:e.type,start:e.start,end:e.end,action:e.action,fired:!!e.fired})),ruleHeading:s.ruleHeading}:null;},
  clear(){states.clear();anchors=new WeakMap();effects?.clear();}
 };return api;
}
