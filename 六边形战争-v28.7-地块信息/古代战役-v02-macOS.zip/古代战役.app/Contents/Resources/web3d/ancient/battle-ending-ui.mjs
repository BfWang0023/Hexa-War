import {captureOutcome,continuePursuit,finalizeBattle,battleStats} from './battle-ending.mjs';
export function bindBattleEndingUI({document,getState,getTeam,getMode,label,refresh,observe,enemyTurn,isActive=()=>true}){
 const dialog=document.createElement('dialog');dialog.id='battle-ending-dialog';const title=document.createElement('h2'),detail=document.createElement('pre'),pursue=document.createElement('button'),end=document.createElement('button'),policy=document.createElement('label'),toggle=document.createElement('input');toggle.type='checkbox';policy.append(toggle,' 观战允许手动追击（默认关闭）');pursue.textContent='继续追击';pursue.id='continue-pursuit';end.textContent='结束战役';end.id='finalize-battle';detail.style.whiteSpace='pre-wrap';dialog.append(title,detail,pursue,end);document.body.append(dialog);
 const finish=document.createElement('button');finish.id='finish-pursuit';finish.textContent='结束追击 / 结束战役';finish.hidden=true;document.getElementById('end-turn').after(finish);document.getElementById('settings-dialog').append(policy);
 let shown=null,shownPhase=null,busy=false;
 function close(){if(dialog.open)dialog.close();}
 end.onclick=()=>{finalizeBattle(getState());close();refresh();};finish.onclick=()=>{finalizeBattle(getState());shown=null;refresh();};
 pursue.onclick=()=>{const s=getState(),team=s.battleOutcome.winner;if(continuePursuit(s,team).ok){close();observe(team);refresh();}};
 dialog.addEventListener('cancel',e=>{e.preventDefault();});
 return setInterval(()=>{if(!isActive())return;const s=getState();captureOutcome(s);finish.hidden=s.battlePhase!=='pursuit';
 if(s.battlePhase==='pursuit'){if(getMode()!=='ai-ai'&&!busy&&s.side!==s.battleOutcome.winner){busy=true;setTimeout(()=>{if(isActive()&&getState()===s&&s.battlePhase==='pursuit'&&s.side!==s.battleOutcome.winner)enemyTurn();busy=false;},350);}return;}
 if(!s.battleOutcome||shown===s.battleOutcome&&shownPhase===s.battlePhase||!s.over)return;
 if(document.querySelector('dialog[open]'))return;
 shown=s.battleOutcome;shownPhase=s.battlePhase;const winner=s.battleOutcome.winner;title.textContent=winner===null?'战役平局':getMode()==='ai-ai'? '战役结束':winner===getTeam()?'战役胜利':'战役失败';const stats=battleStats(s);detail.textContent=`胜利方：${winner?s.map.factions[winner]:'无'}\n条件：${label(s)}\n首次判定：第${s.battleOutcome.turn}回合\n`+Object.entries(stats).map(([t,v])=>`${s.map.factions[t]}：剩余${v.remaining}，阵亡${v.dead}，溃逃${v.routed}`).join('\n')+'\n'+s.battleOutcome.log.join('\n');pursue.hidden=s.battlePhase==='finalized'||!winner||!(getMode()==='human-human'||getMode()==='ai-ai'&&toggle.checked||getMode()==='human-ai'&&winner===getTeam());dialog.showModal();
 },200);
}
