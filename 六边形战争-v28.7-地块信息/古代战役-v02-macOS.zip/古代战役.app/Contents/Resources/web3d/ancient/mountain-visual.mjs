// Rendering only. These functions never write a map or supply a combat elevation.
import * as T from '../vendor/three/three.module.js';
const ramp=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
export const MOUNTAIN_VISUAL_SCALE=4.6;
export function mountainSurfaceHeight(logical,coverage,x,z){const interior=ramp(.12,.88,coverage)*ramp(.35,1.8,logical),ridge=Math.pow(.5+.5*Math.sin(x*.035+z*.019+Math.sin(z*.018)*.8),1.7),saddle=.5+.5*Math.sin(x*.016-z*.025);return logical*MOUNTAIN_VISUAL_SCALE+interior*(.6+5.0*ridge+1.8*(saddle-.5)+1.4*(.5+.5*Math.sin(x*.057-z*.034)))+.045*Math.sin(x*.09)*Math.sin(z*.11);}
const grass=new T.Color(0x7b8b62),foot=new T.Color(0x95956b),soil=new T.Color(0x9f916f),upper=new T.Color(0x998b76),rock=new T.Color(0x8d8275),snow=new T.Color(0xdedfd4);
export function mountainSurfaceColor(target,logical,nx,ny,nz,mountain=0){logical=Math.max(logical,.35*Number(mountain));const slope=Math.hypot(nx,nz)/Math.max(.05,ny);target.copy(grass).lerp(foot,ramp(.15,1.0,logical));target.lerp(soil,ramp(.9,2.5,logical));target.lerp(upper,ramp(2.3,4.6,logical));target.lerp(rock,ramp(4.2,6.6,logical));target.lerp(rock,ramp(.2,.65,slope)*ramp(.35,2.2,logical)*.30);target.lerp(snow,ramp(7.2,9.2,logical)*(.5+.5*Math.max(0,ny)));target.multiplyScalar(.99+.035*ny+.16*(nx*.7+nz*.3));return target;}
export const usesMountainPalette=m=>!!m.autoElevation&&!['carrhae','zama','tyre','babylon','teutoburg'].includes(m.scenarioId);
