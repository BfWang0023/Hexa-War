import { TERRAIN, addUnit, applyCampaignFinances, expandLogisticsConvoys, inBounds, mobileAt, newMap, setBridge, setFort, setHouse, setTerrain,
  tile, validateMap } from './engine.mjs';

// Dates are campaign starting years. Each map depicts a tactical episode, not a survey map.
const records = `
dingtao|-208|定陶之战|秦军|楚军|章邯|项梁|定陶楚军营垒|章邯袭破项梁军，项梁战死。|plain
julu|-207|巨鹿之战|楚与诸侯军|秦军|项羽|王离|巨鹿秦军甬道|楚军渡河后攻击秦军甬道与围城部队。|river
three_qin|-206|还定三秦|汉军|三秦军|刘邦|章邯|关中通道|汉军由汉中重返关中；多阶段战事压缩为一处关口。|pass
pengcheng|-205|彭城大战|楚军|汉与诸侯军|项羽|刘邦|彭城汉军中营|项羽精兵快速反击占领彭城的汉军。|river
puban|-205|蒲坂之战|汉军|魏军|韩信|魏豹|魏军蒲坂营|汉军佯向蒲坂而另取渡河之路。|river
jingxing|-204|井陉之战|汉军|赵军|韩信|陈余|赵军井陉阵地|汉军背水列阵，奇兵夺赵营。|pass
gaixia|-202|垓下会战|汉与诸侯联军|楚军|刘邦|项羽|垓下楚军本营|汉军围攻楚军，楚军可沿东南通道突围。|plain
seven_states|-154|七国之乱|七国联军|朝廷与梁国军|刘濞|周亚夫|西进目标|吴楚联军西进，梁王刘武守睢阳，周亚夫骑兵截断其后方粮道。|seven
mayi|-133|马邑之谋|匈奴军|汉军|军臣单于|王恢|匈奴撤离通道|汉军设伏，匈奴识破后撤；史实中主力未发生决战。|ambush
hexi|-121|河西之战|汉军|匈奴军|霍去病|浑邪王|河西王庭|汉骑兵沿河西走廊纵深突击。|steppe
mobei|-119|漠北之战|汉军|匈奴军|卫青|伊稚斜单于|单于本营|以卫青与单于主力交战为战术场景，霍去病东路另标地名。|steppe
dayuan|-104|汉征大宛|汉军|大宛军|李广利|大宛守将|贵山城门|第二次远征的围城阶段，汉军须打开城防。|siege
kunyang|23|昆阳大战|绿林军|新朝军|刘秀|王邑|新军中营|刘秀率援军反击围城新军，守军从昆阳呼应。|relief
longxi|30|陇西会战|东汉军|陇西割据军|刘秀|隗嚣|陇西主营|东汉平陇西的多年战事压缩为一图；双方依靠后方补给与召集。|longxi
`;
export const IMPERIAL_CAMPAIGNS = Object.freeze(records.trim().split('\n').map(line => {
  const [key, year, name, attacker, defender, leader, foe, objectiveName, note, terrain] = line.split('|');
  return Object.freeze({ id: `china_${key}`, year: Number(year), name, attacker, defender,
    leader, foe, objectiveName, note, terrain });
}));
export const IMPERIAL_CAMPAIGN_IDS = new Set(IMPERIAL_CAMPAIGNS.map(x => x.id));
const BANDS = {
  dingtao: [['egypt', 13, 22, 'H5 X2 V1 G2', '秦军夜袭中路'],
    ['egypt', 17, 13, 'H2 X1 V1', '秦军北路'], ['egypt', 17, 32, 'H2 X1 V1', '秦军南路'],
    ['coalition', 52, 22, 'H8 X3 G2', '楚军定陶本营'],
    ['coalition', 48, 32, 'H3 V2', '楚军营外巡队']],
  julu: [['egypt', 17, 23, 'H6 G2 X3', '楚军破釜沉舟主力'],
    ['egypt', 17, 16, 'H4 V2 G2', '楚军北渡队'], ['egypt', 17, 32, 'V2', '楚军南渡骑兵'],
    ['coalition', 51, 23, 'H8 X3 G2', '秦军甬道守军'],
    ['coalition', 55, 15, 'H5 X2 V3', '秦军围城队']],
  three_qin: [['egypt', 15, 23, 'H7 X3 G2', '汉军关口主力'],
    ['egypt', 19, 13, 'H3 X1 V2', '汉军北路'], ['egypt', 19, 33, 'V2', '汉军南路'],
    ['coalition', 54, 23, 'H7 X3 G2', '三秦关中守军'],
    ['coalition', 48, 31, 'H3 X1 V3', '三秦侧翼']],
  puban: [['egypt', 16, 23, 'H5 X4 V2 G2', '韩信蒲坂佯攻军'],
    ['egypt', 21, 33, 'H3 V3', '韩信夏阳奇渡队'],
    ['coalition', 53, 22, 'H6 X3 V2 G2', '魏军蒲坂本营'],
    ['coalition', 41, 23, 'H3 V1', '魏军渡口守军']],
  pengcheng: [['egypt', 15, 22, 'V8 H3 G3', '项羽精骑反击主力'],
    ['egypt', 20, 13, 'V2 H1', '楚军北翼突击'], ['egypt', 20, 34, 'V2 H1', '楚军南翼突击'],
    ['coalition', 52, 22, 'H12 X4 V3 G2', '汉军彭城中营'],
    ['coalition', 54, 34, 'H6 X2 V2', '汉军城南后队']],
  jingxing: [['egypt', 16, 26, 'H10 X5 V1 G2', '韩信背水主阵'],
    ['egypt', 54, 9, 'V2', '汉军赤帜绕后奇兵'],
    ['coalition', 52, 22, 'H8 X3 V2 G2', '赵军井陉主营'],
    ['coalition', 56, 32, 'H4 X1 V2', '赵军后备']],
  gaixia: [['egypt', 14, 23, 'H7 X3 V2 G3', '汉军西面主力'],
    ['egypt', 23, 12, 'H3 X1 V2', '诸侯北翼'], ['egypt', 23, 35, 'H3 X1 V2', '诸侯南翼'],
    ['coalition', 51, 23, 'H9 V5 G3', '项羽垓下楚营']],
  seven_states: [['egypt', 62, 21, 'H13 X5 V5 G3'], ['coalition', 37, 24, 'H9 X4 G3'],
    ['coalition', 57, 36, 'V7 X2']],
  mayi: [['egypt', 52, 23, 'V13 A3 G2'], ['coalition', 30, 16, 'H8 X6 V5 G2'],
    ['coalition', 30, 31, 'H7 X4 V3']],
  hexi: [['egypt', 14, 22, 'V10 A2 G2', '霍去病河西骑兵主力'],
    ['egypt', 19, 14, 'V6 A1', '汉军北路长驱骑兵'],
    ['coalition', 52, 23, 'V10 A3 G2', '匈奴河西王庭主力'],
    ['coalition', 50, 33, 'V5 A1', '匈奴南路骑兵']],
  mobei: [['egypt', 15, 23, 'V12 A3 G3', '卫青漠北主力'],
    ['egypt', 18, 36, 'V6 A1', '汉军南翼骑兵'],
    ['coalition', 53, 22, 'V13 A3 G2', '单于本部'],
    ['coalition', 50, 10, 'V6 A1', '匈奴北翼骑兵']],
  dayuan: [['egypt', 13, 23, 'H8 X5 R2 G2', '李广利攻城主力'],
    ['egypt', 18, 15, 'H4 X2 V3', '汉军北面围攻队'],
    ['egypt', 18, 32, 'V2', '汉军南面骑兵'],
    ['coalition', 53, 23, 'H8 X4 G2', '大宛贵山城守军'],
    ['coalition', 58, 32, 'H2 X2 V3', '大宛城外援队']],
  kunyang: [['egypt', 18, 21, 'V7 H6 G2', '刘秀西水援军'],
    ['egypt', 51, 24, 'H5 X3', '昆阳城内守军'],
    ['coalition', 41, 23, 'H17 X7 V5 G4 R2', '王邑王寻围城中军'],
    ['coalition', 47, 15, 'H5 X3 V2', '新军北围营'],
    ['coalition', 47, 33, 'H5 X2 V2', '新军南围营']],
  longxi: [['egypt', 14, 23, 'H7 X4 V3 G3', '东汉陇西中军'],
    ['egypt', 19, 13, 'H2 X1 V2', '东汉北路'], ['egypt', 19, 34, 'H2 X1 V2', '东汉南路'],
    ['coalition', 54, 23, 'H6 X4 V2 G3', '隗嚣陇西主营'],
    ['coalition', 53, 13, 'H2 X1 V2', '陇西北寨'], ['coalition', 53, 34, 'H2 X1 V2', '陇西南寨']],
};
const KINDS = { H: 'heavy', X: 'chinaCrossbow', V: 'cavalry', G: 'guard', A: 'archer', R: 'siegeRam' };
function draw(m, x1, y1, x2, y2, kind) {
  const steps = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
  for (let i = 0; i <= steps; i++) {
    const c = Math.round(x1 + (x2 - x1) * i / (steps || 1));
    const r = Math.round(y1 + (y2 - y1) * i / (steps || 1));
    if (!inBounds(m, c, r)) continue;
    const old = tile(m, c, r).terrain;
    setTerrain(m, c, r, kind === 'road' ? old | TERRAIN.ROAD :
      kind === 'ford' ? TERRAIN.RIVER | TERRAIN.ROAD : kind === 'river' ? TERRAIN.RIVER : TERRAIN.MOUNTAIN);
  }
}
function deploy(m, kind, team, c, r, formation) {
  for (let radius = 0; radius < 12; radius++) for (let dr = -radius; dr <= radius; dr++)
    for (let dc = -radius; dc <= radius; dc++) {
      const p = { c: c + dc, r: r + dr };
      if (Math.max(Math.abs(dc), Math.abs(dr)) !== radius || !inBounds(m, p.c, p.r) ||
          mobileAt(m, p.c, p.r) || !addUnit(m, kind, team, p.c, p.r)) continue;
      const u = m.units.at(-1); u.formation = formation; return u;
    }
  throw new Error(`${m.scenarioId}:无法部署${kind}`);
}
function fortRing(m, c, r, rx, ry, team, name, level = 2) {
  for (let x = c - rx; x <= c + rx; x++) for (const y of [r - ry, r + ry])
    setFort(m, x, y, level, team, name);
  for (let y = r - ry + 1; y < r + ry; y++) for (const x of [c - rx, c + rx])
    setFort(m, x, y, level, team, name);
}
function landscape(m, key) {
  draw(m, 3, 23, 68, 23, 'road');
  if (key === 'dingtao') {
    draw(m, 4, 12, 45, 18, 'road'); draw(m, 4, 35, 45, 29, 'road');
    fortRing(m, 53, 23, 5, 6, 'coalition', '定陶楚营');
    setFort(m, 48, 23, 0); setFort(m, 53, 29, 0);
    draw(m, 31, 8, 40, 14, 'ridge');
  } else if (key === 'julu') {
    draw(m, 34, 3, 34, 42, 'river');
    for (const r of [17, 23, 32]) draw(m, 34, r, 35, r, 'ford');
    draw(m, 8, 17, 44, 17, 'road'); draw(m, 8, 32, 45, 32, 'road');
    draw(m, 44, 23, 65, 23, 'road');
    for (const [c, r] of [[56, 12], [57, 12], [58, 12], [57, 13]]) setHouse(m, c, r);
  } else if (key === 'three_qin') {
    draw(m, 35, 3, 41, 17, 'ridge'); draw(m, 35, 29, 42, 42, 'ridge');
    draw(m, 27, 11, 45, 17, 'road'); draw(m, 26, 35, 45, 29, 'road');
    fortRing(m, 55, 23, 4, 5, 'coalition', '关中秦营'); setFort(m, 51, 23, 0);
  } else if (key === 'puban') {
    draw(m, 34, 3, 34, 42, 'river');
    for (const r of [15, 23, 33]) draw(m, 34, r, 35, r, 'ford');
    draw(m, 8, 33, 47, 33, 'road'); draw(m, 20, 14, 45, 14, 'road');
    for (const r of [19, 23, 27]) setFort(m, 41, r, 1, 'coalition', '蒲坂魏营');
  } else if (key === 'pengcheng') {
    draw(m, 63, 3, 63, 42, 'river');
    for (const r of [17, 23, 32]) draw(m, 63, r, 64, r, 'ford');
    fortRing(m, 52, 23, 5, 6, 'coalition', '彭城'); setFort(m, 47, 23, 0);
    draw(m, 4, 13, 44, 13, 'road'); draw(m, 4, 34, 44, 34, 'road');
    for (const [c, r] of [[50, 20], [53, 20], [51, 26], [54, 26]]) setHouse(m, c, r);
  } else if (key === 'jingxing') {
    draw(m, 10, 3, 10, 42, 'river'); draw(m, 10, 26, 11, 26, 'ford');
    draw(m, 10, 35, 11, 35, 'ford');
    draw(m, 35, 3, 42, 17, 'ridge'); draw(m, 35, 29, 42, 42, 'ridge');
    draw(m, 20, 9, 60, 9, 'road'); draw(m, 42, 9, 59, 16, 'road');
    fortRing(m, 53, 23, 5, 6, 'coalition', '赵军营垒');
    setFort(m, 48, 23, 0); setFort(m, 53, 17, 0);
  } else if (key === 'gaixia') {
    fortRing(m, 51, 23, 5, 6, 'coalition', '垓下楚营');
    setFort(m, 46, 23, 0); setFort(m, 56, 29, 0);
    draw(m, 12, 12, 49, 12, 'road'); draw(m, 12, 35, 49, 35, 'road');
    draw(m, 56, 29, 68, 40, 'road');
  } else if (key === 'seven_states') {
    draw(m, 48, 3, 48, 42, 'river');
    for (const r of [14, 23, 35]) draw(m, 48, r, 49, r, 'ford');
    draw(m, 9, 14, 65, 14, 'road'); draw(m, 10, 35, 67, 35, 'road');
    fortRing(m, 36, 23, 4, 5, 'coalition', '睢阳');
    setFort(m, 40, 23, 0); setFort(m, 32, 23, 0);
    draw(m, 56, 35, 65, 29, 'road');
  } else if (key === 'mayi') {
    draw(m, 22, 4, 38, 15, 'ridge'); draw(m, 22, 41, 38, 31, 'ridge');
    draw(m, 15, 17, 46, 17, 'road'); draw(m, 15, 30, 46, 30, 'road');
    draw(m, 43, 7, 58, 16, 'ridge');
  } else if (key === 'hexi') {
    draw(m, 6, 8, 66, 8, 'ridge'); draw(m, 7, 39, 66, 39, 'ridge');
    draw(m, 7, 14, 65, 14, 'road'); draw(m, 7, 33, 65, 33, 'road');
    draw(m, 37, 8, 43, 15, 'ridge');
  } else if (key === 'mobei') {
    draw(m, 7, 10, 65, 10, 'road'); draw(m, 7, 36, 65, 36, 'road');
    draw(m, 26, 5, 33, 12, 'ridge'); draw(m, 39, 33, 47, 41, 'ridge');
    draw(m, 50, 8, 56, 13, 'ridge');
  } else if (key === 'dayuan') {
    fortRing(m, 53, 23, 5, 6, 'coalition', '贵山城');
    draw(m, 9, 15, 47, 17, 'road'); draw(m, 9, 32, 47, 30, 'road');
    draw(m, 43, 34, 64, 34, 'river');
    draw(m, 43, 35, 64, 35, 'river');
    draw(m, 49, 34, 49, 35, 'ford');
    draw(m, 59, 34, 59, 35, 'ford');
    for (const [c, r] of [[51, 20], [54, 20], [51, 26], [55, 26]]) setHouse(m, c, r);
  } else if (key === 'kunyang') {
    draw(m, 29, 3, 29, 42, 'river');
    for (const r of [15, 23, 32]) draw(m, 29, r, 30, r, 'ford');
    draw(m, 10, 15, 45, 15, 'road'); draw(m, 10, 32, 45, 32, 'road');
    fortRing(m, 52, 24, 4, 5, 'egypt', '昆阳', 3); setFort(m, 48, 24, 0);
    for (const r of [16, 24, 33]) setFort(m, 43, r, 1, 'coalition', '新军围城营');
  } else if (key === 'longxi') {
    draw(m, 35, 3, 42, 18, 'ridge'); draw(m, 35, 29, 42, 42, 'ridge');
    draw(m, 6, 13, 65, 13, 'road'); draw(m, 6, 34, 65, 34, 'road');
    draw(m, 44, 16, 44, 31, 'river');
    draw(m, 44, 23, 45, 23, 'ford');
    draw(m, 44, 18, 45, 18, 'ford'); draw(m, 44, 30, 45, 30, 'ford');
    for (const r of [20, 27]) setFort(m, 49, r, 1, 'coalition', '陇西关寨');
  }
  const bridgeCrossings = {
    julu: [[34, 23], [35, 23]],
    pengcheng: [[63, 23], [64, 23]],
    puban: [[34, 23], [35, 23]],
    jingxing: [[10, 26], [11, 26]],
    seven_states: [[48, 23], [49, 23]],
    dayuan: [[49, 34], [49, 35]],
    kunyang: [[29, 23], [30, 23]],
    longxi: [[44, 23], [45, 23]],
  };
  for (const [c, r] of bridgeCrossings[key] || [])
    if (!setBridge(m, c, r)) throw new Error(`${m.scenarioId}:桥梁必须叠在渡口上`);
}
export function makeImperialMap(id) {
  const spec = IMPERIAL_CAMPAIGNS.find(x => x.id === id);
  if (!spec) throw new Error(`未知秦汉战役：${id}`);
  const m = newMap(72, 46);
  m.scenarioId = id; m.name = spec.name;
  m.factions = { egypt: spec.attacker, coalition: spec.defender };
  m.unitNames = { 'egypt:chinaGeneral': spec.leader, 'coalition:chinaGeneral': spec.foe,
    heavy: '重步兵', chinaCrossbow: '弩兵', guard: '亲卫', cavalry: '骑兵', siegeRam: '攻城槌车' };
  m.intro = `${spec.note}阵位与距离为战棋化示意，编组不按史载人数换算。`;
  const objective = spec.terrain === 'seven' ? { c: 7, r: 23 } :
    spec.terrain === 'ambush' ? { c: 5, r: 23 } :
    spec.terrain === 'siege' ? { c: 53, r: 23 } :
    spec.terrain === 'relief' ? { c: 40, r: 23 } :
    spec.terrain === 'river' ? { c: 52, r: 23 } : { c: 54, r: 23 };
  if (id === 'china_julu') objective.c = 48;
  m.victory = { mode: 'china', attacker: 'egypt', objective, objectiveName: spec.objectiveName,
    losses: { egypt: 1, coalition: 1 }, turnLimit: id === 'china_seven_states' ? 38 : 30,
    breach: spec.terrain === 'siege' };
  landscape(m, id.slice(6));
  m.landmarks = [{ c: objective.c, r: objective.r, label: spec.objectiveName }];
  if (id === 'china_julu') {
    for (let r = 17; r <= 29; r += 3) setFort(m, 48, r, 1, 'coalition', '秦军甬道');
    m.landmarks.push({ c: 34, r: 23, label: '漳水中路桥' }, { c: 48, r: 23, label: '秦军甬道' });
  }
  const battleLandmarks = {
    dingtao: [[53, 23, '项梁定陶营垒'], [48, 23, '楚营西门'], [17, 13, '秦军北路夜袭']],
    julu: [[56, 12, '巨鹿城与诸侯观战营'], [48, 23, '秦军甬道'], [34, 17, '楚军北渡口']],
    three_qin: [[39, 23, '关中山口'], [55, 23, '三秦守军营垒'], [35, 12, '汉军北路']],
    puban: [[34, 23, '蒲坂主桥'], [34, 33, '夏阳奇渡'], [41, 23, '魏军渡口守备']],
    pengcheng: [[52, 23, '彭城汉军中营'], [63, 23, '城东木桥'], [20, 13, '项羽西来北翼突击']],
    jingxing: [[10, 26, '汉军背水桥'], [40, 23, '井陉口'], [53, 23, '赵军营垒'],
      [54, 9, '赤帜骑兵绕后小道']],
    gaixia: [[51, 23, '项羽垓下楚营'], [56, 29, '楚军东南突围口'], [23, 12, '诸侯北翼']],
    seven_states: [[36, 23, '梁王刘武守睢阳'], [58, 36, '周亚夫轻骑截粮道'],
      [48, 23, '睢阳东侧主桥']],
    mayi: [[30, 17, '汉军北翼伏兵'], [30, 30, '汉军南翼伏兵'], [5, 23, '匈奴撤离方向']],
    hexi: [[40, 23, '河西走廊中段'], [19, 14, '霍去病北路骑兵'], [52, 23, '匈奴王庭']],
    mobei: [[35, 23, '漠北交战平原'], [59, 9, '霍去病东路（场外）'], [53, 22, '单于本阵']],
    dayuan: [[53, 23, '大宛贵山城'], [49, 34, '城南引水渠桥'], [18, 15, '汉军北面围攻队']],
    kunyang: [[29, 23, '刘秀西水中路桥'], [43, 24, '新军围城中营'], [52, 24, '昆阳城']],
    longxi: [[40, 23, '陇西山口'], [44, 23, '陇西河谷桥'], [49, 20, '隗嚣关寨']],
  };
  m.landmarks.push(...battleLandmarks[id.slice(6)].map(([c, r, label]) => ({ c, r, label })));
  const leaders = id === 'china_seven_states' ? [[62, 23], [57, 37]] : [[11, 23], [58, 23]];
  for (const [team, [c, r]] of [['egypt', leaders[0]], ['coalition', leaders[1]]])
    deploy(m, 'chinaGeneral', team, c, r, '统帅');
  for (const [team, c, r, units, formation] of BANDS[id.slice(6)]) for (const token of units.split(' ')) {
    const kind = KINDS[token[0]];
    for (let i = 0; i < Number(token.slice(1)); i++) {
      const name = id === 'china_seven_states' && team === 'coalition' && r > 30 ?
        '周亚夫断粮骑兵' : formation || `${spec.name}军阵`;
      const u = deploy(m, kind, team, c, r, name);
      if (name === '周亚夫断粮骑兵' && kind === 'cavalry') u.deepRaider = true;
    }
  }
  if (id === 'china_seven_states' || id === 'china_longxi') {
    for (const [team, [c, r]] of [['egypt', leaders[0]], ['coalition', leaders[1]]])
      deploy(m, 'moraleGuard', team, c + (team === 'egypt' ? -2 : 2), r + 2, `${m.factions[team]}后方督战队`);
  }
  if (id === 'china_seven_states') {
    m.logistics = { startingMoney: { egypt: 250, coalition: 650 }, income: { egypt: 75, coalition: 220 },
      depots: { egypt: [{ c: 66, r: 22 }], coalition: [{ c: 9, r: 22 }] },
      musters: { egypt: [{ c: 64, r: 26 }], coalition: [{ c: 13, r: 27 }] },
      routes: { egypt: [{ c: 64, r: 23 }, { c: 61, r: 23 }, { c: 58, r: 28 }, { c: 61, r: 31 }],
        coalition: [{ c: 12, r: 23 }, { c: 19, r: 23 }, { c: 25, r: 23 }] } };
    deploy(m, 'supplyWagon', 'egypt', 65, 22, '七国辎重');
    deploy(m, 'supplyWagon', 'egypt', 61, 18, '七国辎重');
    deploy(m, 'supplyWagon', 'egypt', 61, 28, '七国辎重');
    deploy(m, 'supplyWagon', 'coalition', 10, 22, '汉军辎重');
    deploy(m, 'supplyWagon', 'coalition', 36, 23, '睢阳粮仓');
  }
  if (id === 'china_longxi') {
    m.logistics = { startingMoney: { egypt: 650, coalition: 180 }, income: { egypt: 240, coalition: 70 },
      depots: { egypt: [{ c: 6, r: 23 }], coalition: [{ c: 65, r: 23 }] },
      musters: { egypt: [{ c: 9, r: 25 }], coalition: [{ c: 62, r: 25 }] },
      routes: { egypt: [{ c: 9, r: 23 }, { c: 18, r: 23 }, { c: 27, r: 23 }],
        coalition: [{ c: 62, r: 23 }, { c: 54, r: 23 }, { c: 46, r: 23 }] } };
    deploy(m, 'supplyWagon', 'egypt', 7, 23, '东汉辎重');
    deploy(m, 'supplyWagon', 'egypt', 18, 20, '东汉辎重');
    deploy(m, 'supplyWagon', 'egypt', 18, 28, '东汉辎重');
    deploy(m, 'supplyWagon', 'coalition', 64, 23, '陇西辎重');
    deploy(m, 'supplyWagon', 'coalition', 53, 19, '陇西辎重');
    deploy(m, 'supplyWagon', 'coalition', 53, 29, '陇西辎重');
  }
  if (m.logistics) expandLogisticsConvoys(m);
  applyCampaignFinances(m);
  validateMap(m);
  return m;
}
