import test from 'node:test';
import assert from 'node:assert/strict';
import { CAMPAIGN_CATALOG, CAMPAIGN_IDS, campaignTitle } from './campaign-catalog.mjs';

test('all ancient campaigns appear once in chronological order with name followed by date', () => {
  assert.equal(CAMPAIGN_CATALOG.length, 89);
  assert.equal(CAMPAIGN_IDS.size, CAMPAIGN_CATALOG.length);
  for (let i = 0; i < CAMPAIGN_CATALOG.length; i++) {
    const entry = CAMPAIGN_CATALOG[i];
    assert.match(entry.title, /^.+（(?:约?前|传说约前|公元)\d+(?:—前\d+)?年）$/);
    assert.equal(entry.title, campaignTitle(entry.id));
    if (i) assert.ok(CAMPAIGN_CATALOG[i - 1].year <= entry.year,
      `${CAMPAIGN_CATALOG[i - 1].title} should precede ${entry.title}`);
  }
  assert.equal(CAMPAIGN_CATALOG[0].id, 'china_mingtiao');
  assert.equal(CAMPAIGN_CATALOG[0].title, '鸣条之战（约前1600年）');
  assert.equal(CAMPAIGN_CATALOG[1].id, 'megiddo');
  assert.equal(CAMPAIGN_CATALOG.at(-1).id, 'jerusalem');
  assert.ok(CAMPAIGN_CATALOG.findIndex(x => x.id === 'carrhae') <
    CAMPAIGN_CATALOG.findIndex(x => x.id === 'alesia'));
  assert.ok(CAMPAIGN_CATALOG.findIndex(x => x.id === 'issus') <
    CAMPAIGN_CATALOG.findIndex(x => x.id === 'tyre'));
  assert.ok(CAMPAIGN_CATALOG.findIndex(x => x.id === 'china_muye') <
    CAMPAIGN_CATALOG.findIndex(x => x.id === 'china_three_guards'));
  assert.ok(CAMPAIGN_CATALOG.findIndex(x => x.id === 'mantinea') <
    CAMPAIGN_CATALOG.findIndex(x => x.id === 'aegospotami'));
  assert.ok(CAMPAIGN_CATALOG.findIndex(x => x.id === 'china_pengcheng') <
    CAMPAIGN_CATALOG.findIndex(x => x.id === 'china_puban'));
});
