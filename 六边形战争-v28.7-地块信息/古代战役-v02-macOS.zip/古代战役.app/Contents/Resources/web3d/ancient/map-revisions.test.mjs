import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sync=JSON.parse(readFileSync(new URL('../../docs/map-sync/manifest.json',import.meta.url)));
import {index,TERRAIN,importMap,exportMap,neighbors,inBounds} from './engine.mjs';
const changes=JSON.parse(readFileSync(new URL('../../docs/terrain-v02/map-revisions.json',import.meta.url)));
for(const change of changes)test(`bounded map revision: ${change.id}`,()=>{
 // Later user map edits have independent exact-copy regression tests. Keep the
 // original bounded terrain-upgrade contract on its immutable pre-sync snapshot.
 const revision=sync.records.find(r=>r.id===change.id&&r.changed&&!r.added);
 const rawBytes=readFileSync(new URL(revision?`../../docs/map-sync/before/${change.id}.json`:`./bundled-maps/${change.id}.json`,import.meta.url));
 if(revision)assert.equal(createHash('sha256').update(rawBytes).digest('hex'),revision.destinationSha256Before);
 const raw=JSON.parse(rawBytes),before=JSON.parse(readFileSync(new URL(`../../docs/terrain-v02/original-maps/${change.id}.json`,import.meta.url)));
 const original=importMap(before),m=importMap(raw);
 const normalize=x=>{const y=structuredClone(x);delete y.terrain;for(const u of y.units)if(u.kind==='fort'){delete u.team;delete u.cityId;}return y;};
 assert.deepEqual(normalize(raw),normalize(before));
 const allowedTerrain=new Map(change.river.map(p=>[index(m,p.c,p.r),p]));
 for(let i=0;i<m.terrain.length;i++){
  if(allowedTerrain.has(i)){const p=allowedTerrain.get(i);assert.equal(m.terrain[i],p.after);assert.equal(original.terrain[i],p.before);assert.equal(m.terrain[i]&TERRAIN.ROAD,original.terrain[i]&TERRAIN.ROAD);assert.ok(Math.min(p.c,m.cols-1-p.c,p.r,m.rows-1-p.r)<=2);}
  else assert.equal(m.terrain[i],original.terrain[i]);
 }
 const allowedForts=new Map(change.forts.map(p=>[`${p.c},${p.r}`,p]));
 for(const u of m.units){
  if(u.kind==='fort'&&allowedForts.has(`${u.c},${u.r}`)){const p=allowedForts.get(`${u.c},${u.r}`);assert.equal(u.team,p.toTeam);assert.equal(u.cityId,p.toCity);}
  else assert.deepEqual(u,original.units.find(v=>v.id===u.id));
 }
 assert.deepEqual(m.victory,original.victory);assert.deepEqual(m.bridges,original.bridges);assert.deepEqual(m.supplyPoints,original.supplyPoints);
 assert.ok(importMap(exportMap(m)));assert.equal(change.blocked.length,0);
 // Each extended segment actually reaches its selected edge through water.
 for(const edge of new Set(change.river.map(p=>p.edge))){
  const start=change.river.find(p=>p.edge===edge),q=[start],seen=new Set([index(m,start.c,start.r)]);let reached=false;
  for(let i=0;i<q.length;i++){const p=q[i];if(edge==='left'?p.c===0:edge==='right'?p.c===m.cols-1:edge==='top'?p.r===0:p.r===m.rows-1)reached=true;
   for(const n of neighbors(p.c,p.r))if(inBounds(m,n.c,n.r)&&m.terrain[index(m,n.c,n.r)]&TERRAIN.RIVER&&!seen.has(index(m,n.c,n.r))){seen.add(index(m,n.c,n.r));q.push(n);}}
  assert.ok(reached,edge);
 }
});
