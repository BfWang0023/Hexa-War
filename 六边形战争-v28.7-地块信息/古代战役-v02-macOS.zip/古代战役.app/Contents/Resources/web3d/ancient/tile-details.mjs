import {tile,TERRAIN,moveCost,bridgeAt} from './engine.mjs';
import {groundElevation} from './elevation-rules.mjs';
export function tileDescription(map,c,r,unit,state){
 const t=tile(map,c,r);if(!t||map.unknown?.[r*map.cols+c])return ['尚未侦察：地形与通行难度未知'];
 const names=Object.entries({MOUNTAIN:'山地',FOREST:'森林',SWAMP:'沼泽',RIVER:'河流',SEA:'海域',ROAD:'道路',BEACH:'海滩'}).filter(([k])=>t.terrain&TERRAIN[k]).map(([,v])=>v);
 const rows=[`地形：${names.join('、')||'平原'}${bridgeAt(map,c,r)?' · 桥梁':''}`,`逻辑高程：${groundElevation(map,c,r)}`];
 if(map.staleMask?.[r*map.cols+c])rows.push('历史地形情报：当前未确认变化');
 if(unit&&state){const cost=moveCost(state,unit,c,r);rows.push(`当前兵种通行难度：${Number.isFinite(cost)?cost:'不可通行'}`);rows.push('数值为单格路径成本，并非行动次数；实际移动仍受占格、工事与行动力限制。');}
 else rows.push('选择己方部队后显示该兵种的通行成本。');
 return rows;
}
export function bindTileDetails(document){
 const panel=document.createElement('section');panel.id='tile-details';panel.className='card';panel.hidden=true;
 const toggle=document.createElement('button'),body=document.createElement('div');toggle.type='button';toggle.className='panel-minimize';toggle.textContent='地块信息 − 最小化';toggle.setAttribute('aria-expanded','true');
 toggle.onclick=()=>{body.hidden=!body.hidden;toggle.textContent=body.hidden?'地块信息 ＋ 展开':'地块信息 − 最小化';toggle.setAttribute('aria-expanded',String(!body.hidden));};
 panel.append(toggle,body);document.getElementById('battle-sidebar-scroll').prepend(panel);
 return {show(map,c,r,unit,state){panel.hidden=false;body.replaceChildren();for(const text of [`坐标：(${c}, ${r}) · 零基坐标`,...tileDescription(map,c,r,unit,state)]){const p=document.createElement('p');p.textContent=text;body.append(p);}const close=document.createElement('button');close.textContent='关闭地块信息';close.onclick=()=>{panel.hidden=true;};body.append(close);},hide(){panel.hidden=true;}};
}
