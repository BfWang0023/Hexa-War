import {refreshKnowledgeMist,releaseKnowledgeMist} from './knowledge-mist.mjs';
import * as THREE from '../vendor/three/three.module.js';
import { createAncientTerrain, terrainHeight } from './terrain.mjs';
import {crossingAxis} from './terrain-adjacency.mjs';
import {offsetToWorld,worldToOffset} from '../js/core/hex.js';
import { createTerrainForts } from './terrain-forts.mjs';
import { bounds, contains } from './terrain-adjacency.mjs';
import { neighbors, inBounds, index, TERRAIN, bridgeAt } from './engine.mjs';

function dispose(group) {
  group?.removeFromParent();
  group?.traverse(o=>{
    if(o.isInstancedMesh)o.dispose();
    if(o.geometry && !o.geometry.userData.sharedTerrain)o.geometry.dispose();
    for(const m of o.material?(Array.isArray(o.material)?o.material:[o.material]):[])
      if(!m.userData.sharedTerrain)m.dispose();
  });
}
// Chunk-level static cache. A cell change invalidates its four-ring dependency halo,
// including cross-chunk corner heights, road sampling and wall transitions.
export function createTerrainRefresh(chunkSize=16) {
  const group=new THREE.Group(),forts=new THREE.Group(),grid={visible:true};
  const chunks=new Map();let map=null,snapshot=null,meta='',quality='standard';
  const id=(c,r)=>`${Math.floor(c/chunkSize)},${Math.floor(r/chunkSize)}`;
  const api={group,forts,grid,pickables:[],lastUpdate:null,chunks,
    refresh(m){
      refreshKnowledgeMist(m);
      const nextMeta=JSON.stringify([m.scenarioId,m.cols,m.rows,m.garden,m.victory]);
      const reset=map!==m||meta!==nextMeta;
      if(reset){if(map&&map!==m)releaseKnowledgeMist(map);for(const x of chunks.values()){dispose(x.terrain?.group);dispose(x.forts);}chunks.clear();snapshot=null;}
      const walls=m.units.filter(u=>u.kind==='fort'),byCell=new Map(walls.map(u=>[`${u.c},${u.r}`,u]));
      const bridges=new Set((m.bridges||[]).map(p=>`${p.c},${p.r}`));
      const next=[],dirtyTerrain=new Set(),dirtyForts=new Set(),dirtyVegetation=new Set(),changed=[];
      for(let r=0;r<m.rows;r++)for(let c=0;c<m.cols;c++) {
        const i=index(m,c,r),wall=byCell.get(`${c},${r}`);
        const value=[m.terrain[i],m.houses?.[i]||0,bridges.has(`${c},${r}`)?1:0,
          wall?`${wall.id}:${wall.level}:${wall.hp}:${wall.team}`:'',wall?.hp>0?1:0,m.elevations?.[i]??null,m.unknown?.[i]||0,m.staleMask?.[i]||0];next[i]=value;
        if(snapshot && value.every((v,j)=>snapshot[i][j]===v))continue;
        changed.push({c,r});if(!snapshot)continue;const ground=!snapshot||value[5]!==snapshot[i][5]||value[6]!==snapshot[i][6]||value[7]!==snapshot[i][7]||value.slice(0,3).some((v,j)=>snapshot[i][j]!==v);if(snapshot[i][4]!==value[4])dirtyVegetation.add(id(c,r));
        const haloMap=new Map([[`${c},${r}`,{c,r}]]);let edge=[{c,r}];for(let j=0;j<4;j++){const nextEdge=[];for(const v of edge)for(const p of neighbors(v.c,v.r)){const k=`${p.c},${p.r}`;if(!haloMap.has(k)){haloMap.set(k,p);nextEdge.push(p);}}edge=nextEdge;}const halo=[...haloMap.values()];
        for(const p of halo)if(inBounds(m,p.c,p.r)){dirtyForts.add(id(p.c,p.r));if(ground)dirtyTerrain.add(id(p.c,p.r));}
      }
      // Initial generation includes empty chunks, so future insertions are local.
      if(reset)for(let r=0;r<m.rows;r+=chunkSize)for(let c=0;c<m.cols;c+=chunkSize){dirtyTerrain.add(id(c,r));dirtyForts.add(id(c,r));}
      for(const key of new Set([...dirtyTerrain,...dirtyForts,...dirtyVegetation])) {
        const [x,y]=key.split(',').map(Number),region=bounds(m,{c0:x*chunkSize,r0:y*chunkSize,c1:(x+1)*chunkSize,r1:(y+1)*chunkSize});
        const chunk=chunks.get(key)||{region};
        if(dirtyTerrain.has(key)){
          dispose(chunk.terrain?.group);chunk.terrain=createAncientTerrain(m,null,false,region);
          chunk.terrain.setQuality(quality);chunk.terrain.grid.visible=grid.visible;group.add(chunk.terrain.group);
        }
        if(!dirtyTerrain.has(key)&&dirtyVegetation.has(key))chunk.terrain.refreshVegetation(quality);
        if(dirtyForts.has(key)){
          dispose(chunk.forts);chunk.forts=createTerrainForts(m,walls.filter(u=>contains(region,u.c,u.r)),(map,c,r)=>{const p=offsetToWorld(c,r);return chunk.terrain.sample(c,r,p.x,p.z)},walls);forts.add(chunk.forts);
        }
        chunks.set(key,chunk);
      }
      map=m;meta=nextMeta;snapshot=next;
      api.pickables=[...chunks.values()].flatMap(x=>x.terrain.pickables);
      api.lastUpdate={reset,changedCells:changed,terrainChunks:[...dirtyTerrain],fortChunks:[...dirtyForts],vegetationChunks:[...dirtyVegetation],totalChunks:chunks.size};
      return api.lastUpdate;
    },
    sample(x,z){if(!map)return 0;const p=worldToOffset(x,z),chunk=chunks.get(id(p.col,p.row));if(inBounds(map,p.col,p.row)){const t=map.terrain[index(map,p.col,p.row)];if(t&(TERRAIN.RIVER|TERRAIN.SEA)){if(t&TERRAIN.ROAD){const center=offsetToWorld(p.col,p.row),a=crossingAxis(map,p.col,p.row),dx=x-center.x,dz=z-center.z,lateral=dx*Math.sin(a)+dz*Math.cos(a);if(Math.abs(lateral)<(bridgeAt(map,p.col,p.row)?2:1.45))return bridgeAt(map,p.col,p.row)?.5:-.12;}return -.42;}}return chunk?.terrain.sample(p.col,p.row,x,z)??(inBounds(map,p.col,p.row)?terrainHeight(map,p.col,p.row):0);},
    height(c,r){const p=offsetToWorld(c,r);return api.sample(p.x,p.z);},
    updateLOD(camera){for(const chunk of chunks.values())chunk.terrain.updateLOD?.(camera);},
    invalidate(){map=null;},
    setQuality(value){quality=value;for(const x of chunks.values())x.terrain.setQuality(value);},
    setGrid(value){grid.visible=value;for(const x of chunks.values())x.terrain.grid.visible=value;},
    update(time){for(const x of chunks.values())x.terrain.update(time);},
    dispose(){if(map)releaseKnowledgeMist(map);for(const x of chunks.values()){dispose(x.terrain.group);dispose(x.forts);}chunks.clear();group.removeFromParent();forts.removeFromParent();},
  };
  return api;
}
