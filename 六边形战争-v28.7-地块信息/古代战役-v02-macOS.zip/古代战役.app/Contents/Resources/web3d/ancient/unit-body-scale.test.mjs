import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import * as T from '../vendor/three/three.module.js';
import {createUnitModel,UNIT_SCENE_SCALE} from './unit-presentation.mjs';import {animateFullModel} from './full-models.mjs';import {createSoldierCamera} from './soldier-camera.mjs';
const oldSource=fs.readFileSync(new URL('../../docs/hellenistic-expansion/before/unit-presentation.mjs',import.meta.url),'utf8').replace(/from '([^']+)'/g,(_,p)=>`from '${new URL(p,import.meta.url).href}'`);
const before=await import('data:text/javascript;base64,'+Buffer.from(oldSource).toString('base64'));
const catalog=JSON.parse(fs.readFileSync(new URL('./unit_animation_catalog.json',import.meta.url))).units.filter(u=>u.id!=='fort'&&u.id!=='scout');
const box=o=>new T.Box3().setFromObject(o).getSize(new T.Vector3());
function meshes(o){const xs=[];o.traverse(n=>{if(n.isMesh)xs.push(n)});return xs;}
test('all 67 types and both teams grow bodies by exactly another 20%, while every base vertex and material stays identical',()=>{
 assert.equal(catalog.length,67);assert.equal(UNIT_SCENE_SCALE,before.UNIT_SCENE_SCALE);
 for(const c of catalog)for(const team of ['egypt','coalition']){
  const u={id:'u1',kind:c.id,team,hp:100,morale:1,c:3,r:4},saved=JSON.stringify(u),id=c.contexts[0].scenarioId,a=before.createUnitModel(u,id),b=createUnitModel(u,id);a.scale.setScalar(UNIT_SCENE_SCALE);b.scale.setScalar(UNIT_SCENE_SCALE);
  const oldBases=a.children.filter(n=>n.userData.unitBase),newBases=b.children.filter(n=>n.userData.unitBase);assert.equal(newBases.length,5);
  oldBases.forEach((o,i)=>{const n=newBases[i];assert.deepEqual(n.position.toArray(),o.position.toArray());assert.deepEqual(n.scale.toArray(),o.scale.toArray());assert.ok(box(n).distanceTo(box(o))<1e-8);assert.deepEqual(n.geometry.attributes.position.array,o.geometry.attributes.position.array);assert.deepEqual(n.geometry.index.array,o.geometry.index.array);assert.equal(n.material,o.material);});
  for(const name of ['near','far']){const old=a.getObjectByName(name),now=b.getObjectByName(name);assert.ok(box(now).distanceTo(box(old).multiplyScalar(1.2))<1e-5,c.id+' '+name);const m=meshes(old),n=meshes(now);assert.equal(m.length,n.length);m.forEach((o,i)=>{assert.equal(n[i].geometry,o.geometry);assert.equal(n[i].material,o.material)});}
  assert.equal(JSON.stringify(u),saved);
 }
});
test('walking, formation, attack, gray hit flash and LOD changes never restore old body size or enlarge bases',()=>{
 for(const kind of ['greekHoplite','phalangite','guard','cavalry','chinaHeavyChariot','warElephant','warship','siegeRam']){
  const u={id:'u1',kind,team:'egypt',hp:100,formed:true,facing:0},m=createUnitModel(u,'custom_body_test'),levels=['near','far'].map(n=>m.getObjectByName(n)),sizes=levels.map(l=>l.scale.clone()),base=m.children.find(n=>n.userData.unitBase),baseScale=base.scale.clone();
  for(const distance of [20,150,20])for(const action of ['none','thrust','bow'])for(const hit of [0,1]){animateFullModel(m,320,{moving:true,action,progress:.4,hit,distance});levels.forEach((l,i)=>assert.deepEqual(l.scale,sizes[i]));assert.deepEqual(base.scale,baseScale);}
 }
});
test('the stabilized follow camera anchors above the newly enlarged soldier head and still follows the root',()=>{
 const camera=new T.PerspectiveCamera(),view=createSoldierCamera(camera),u={id:'u1',kind:'heavy',team:'egypt',hp:100},m=createUnitModel(u,'mantinea');m.scale.setScalar(UNIT_SCENE_SCALE);m.position.set(20,3,30);m.updateMatrixWorld(true);const models=new Map([[u.id,m]]);assert.ok(view.start(u,m));view.update(u,m,true,0);const head=m.getObjectByName('near').getObjectByName('soldier').localToWorld(new T.Vector3(0,3.25,0));assert.ok(Math.abs(camera.position.y-head.y-view.height)<1e-7);assert.equal(camera.position.x,m.position.x);m.position.x+=5;view.update(u,m,true,16);assert.equal(camera.position.x,m.position.x);
});
