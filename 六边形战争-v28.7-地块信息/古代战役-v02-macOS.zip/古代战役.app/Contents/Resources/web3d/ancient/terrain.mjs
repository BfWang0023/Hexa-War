import {terrainArtProfile} from './terrain-art-profile.mjs';
import {createKnowledgeMist,attachKnowledgeMist} from './knowledge-mist.mjs';
import {groundElevation} from './elevation-rules.mjs';
import {createVegetation} from './terrain-vegetation.mjs';
import { bounds, contains } from './terrain-adjacency.mjs';
import { createSurface, createRoads } from './terrain-surface.mjs';
import { createCrossings } from './terrain-crossings.mjs';
import * as THREE from '../vendor/three/three.module.js';
import { hexCorners, offsetToWorld } from '../js/core/hex.js';
import { TERRAIN, index, inBounds, neighbors, distance, moleLanes, bridgeAt } from './engine.mjs';

const earth = new THREE.Color(0x728451);
const dry = new THREE.Color(0xa49b65);
const ridge = new THREE.Color(0x857e6b);
const road = new THREE.Color(0xb49c6e);
const water = new THREE.Color(0x335c72);
const sea = new THREE.Color(0x25566c);
const sand = new THREE.Color(0xc2ad7a);
const random = (c, r, salt = 0) => {
  const n = Math.sin(c * 127.1 + r * 311.7 + salt * 74.7) * 43758.5453;
  return n - Math.floor(n);
};
export function terrainHeight(m, c, r) {
  const t = m.terrain[index(m, c, r)];
  if (t & TERRAIN.SEA) return -0.45;
  if (t & TERRAIN.BEACH) return 0.05 + random(c, r, 2) * 0.12;
  if(m.autoElevation && !(t & TERRAIN.RIVER)) return groundElevation(m,c,r)*3;
  if (m.scenarioId === 'troy' && distance({ c, r }, m.victory.capture) <= 3)
    return 1.35 + random(c, r, 2) * 0.24;
  if (bridgeAt(m, c, r)) return 0.5;
  if (t & TERRAIN.RIVER) return t & TERRAIN.ROAD ? -.12 : -.42;
  if (t & TERRAIN.MOUNTAIN) return (t & TERRAIN.ROAD ? 1.35 : 3.25) + random(c, r, 1) * 1.8;
  if (m.scenarioId === 'zama' || m.scenarioId === 'carrhae') return 0.1 + random(c, r, 2) * 0.12;
  return 0.12 + random(c, r, 2) * 0.42;
}
function tileBase(t, c, r, m) {
  if(m.unknown?.[r*m.cols+c])return new THREE.Color(0x69764f);
  if (m.scenarioId === 'carrhae' && t === TERRAIN.PLAIN)
    return new THREE.Color(0xa99570).lerp(new THREE.Color(0xc9b389), random(c, r, 6) * 0.42);
  if (m.scenarioId === 'carrhae' && (t & TERRAIN.ROAD))
    return new THREE.Color(0xc8ad7c).lerp(new THREE.Color(0xd5bc91), random(c, r, 5) * 0.25);
  if (m.scenarioId === 'zama' && t === TERRAIN.PLAIN)
    return new THREE.Color(0xa49869).lerp(new THREE.Color(0xc1af7c), random(c, r, 6) * 0.38);
  if (m.scenarioId === 'babylon' && t === TERRAIN.PLAIN && c > m.victory.outer.cMin && c < m.victory.outer.cMax &&
      r > m.victory.outer.rMin && r < m.victory.outer.rMax)
    return new THREE.Color(0xb7a079).lerp(new THREE.Color(0xd0b995), random(c, r, 6) * 0.22);
  if (t & TERRAIN.SEA) return sea.clone().lerp(new THREE.Color(0x3b8291), random(c, r, 3) * 0.32);
  if (t & TERRAIN.BEACH) return sand.clone().lerp(new THREE.Color(0xe2c990), random(c, r, 5) * 0.25);
  if (m.scenarioId === 'tyre' && t === TERRAIN.PLAIN)
    return new THREE.Color(0xa89973).lerp(new THREE.Color(0xc2b18b), random(c, r, 6) * .32);
  if (m.scenarioId === 'tyre' && (t & TERRAIN.ROAD))
    return new THREE.Color(0xb9aa84).lerp(new THREE.Color(0xd0bb91), random(c, r, 5) * .22);
  if (m.scenarioId === 'troy' && distance({ c, r }, m.victory.capture) <= 3)
    return dry.clone().lerp(new THREE.Color(0xbfb193), random(c, r, 4) * 0.3);
  if (m.scenarioId === 'teutoburg' && t & TERRAIN.MOUNTAIN)
    return new THREE.Color(0x3f6547).lerp(new THREE.Color(0x6b8352), random(c, r, 4) * .4);
  if (m.scenarioId === 'teutoburg' && t & TERRAIN.RIVER)
    return new THREE.Color(0x526c53).lerp(new THREE.Color(0x73856c), random(c, r, 5) * .4);
  if (m.scenarioId?.startsWith('china_') && t & TERRAIN.MOUNTAIN)
    return new THREE.Color(0x6d7952).lerp(new THREE.Color(0x9e9972), random(c, r, 4) * .46);
  if (t & TERRAIN.RIVER) return t & TERRAIN.ROAD ? road.clone().lerp(water, .18) :
    water.clone().lerp(new THREE.Color(0x467d87), random(c, r, 3) * 0.35);
  if (t & TERRAIN.MOUNTAIN) return ridge.clone().lerp(new THREE.Color(0xada28a), random(c, r, 4) * 0.34);
  if (t & TERRAIN.ROAD) return road.clone().lerp(dry, random(c, r, 5) * 0.25);
  return earth.clone().lerp(dry, 0.12 + random(c, r, 6) * 0.38);
}
export function createAncientTerrain(m, fog = null, editing = false, region = null) {
  const b=bounds(m,region);
  const visual = createSurface(m, terrainHeight, tileBase, region);
  const { group, surface, grid, water } = visual;
  const roads = createRoads(m, visual.sample, region); group.add(roads);
  let vegetation=createVegetation(m,visual.sample,region);group.add(vegetation.group);
  const crossings = createCrossings(m,region); group.add(crossings.group);
  if (m.scenarioId === 'tyre') {
    const built = moleLanes(m).flat().filter(([c, r]) => m.terrain[index(m, c, r)] === TERRAIN.ROAD && contains(region,c,r));
    if (built.length) {
      const blocks = new THREE.InstancedMesh(new THREE.BoxGeometry(10.5, .34, 9.4),
        new THREE.MeshStandardMaterial({ color: 0xc0ae89, roughness: 1, flatShading: true }), built.length);
      const o = new THREE.Object3D();
      built.forEach(([c, r], i) => {
        const p = offsetToWorld(c, r);
        o.position.set(p.x, visual.sample(c,r,p.x,p.z) + .05, p.z); o.updateMatrix();
        blocks.setMatrixAt(i, o.matrix);
      });
      blocks.instanceMatrix.needsUpdate = true; blocks.receiveShadow = true; group.add(blocks);
    }
  }

  const rocks = [];
  for (let r = b.r0; r < b.r1; r++) for (let c = b.c0; c < b.c1; c++) {
    const t = m.terrain[index(m, c, r)];
    if (!(t & TERRAIN.MOUNTAIN) || (t & TERRAIN.ROAD) ||
        (m.scenarioId === 'teutoburg' && (c + r) % 3 !== 0) ||
        (m.scenarioId?.startsWith('china_') && (c * 3 + r) % 4 !== 0)) continue;
    const p = offsetToWorld(c, r),profile=terrainArtProfile(m,c,r);
    for (let j = 0; j < (m.scenarioId==='teutoburg'?2:profile.patch>.6&&(profile.slope>.12||profile.ridge)&&random(c,r,29)<.14?2:0); j++) {
      const angle=random(c,r,30)*Math.PI*2+j*.17, x=p.x+Math.cos(angle)*(4.1-j*.25),z=p.z+Math.sin(angle)*(4.1-j*.25);
      rocks.push({x,z,y:visual.sample(c,r,x,z)+.15,scale:.55+random(c,r,50+j)*.35,dark:false});
    }
  }
  if (rocks.length) {
    const geoRock = new THREE.IcosahedronGeometry(1, 0);
    const matRock = new THREE.MeshStandardMaterial({ color: 0xffffff, flatShading: true, roughness: 1 });
    const mesh = new THREE.InstancedMesh(geoRock, matRock, rocks.length);
    const o = new THREE.Object3D();
    rocks.forEach((rock, i) => {
      o.position.set(rock.x, rock.y, rock.z); o.scale.set(rock.scale * 1.1, rock.scale * .9, rock.scale);
      o.rotation.set(random(i, 1) * .3, random(i, 2) * 6, random(i, 3) * .3); o.updateMatrix();
      mesh.setMatrixAt(i, o.matrix);
      mesh.setColorAt(i, new THREE.Color(m.scenarioId === 'teutoburg' ? 0x506b4b :
        rock.dark ? 0x45504c : (i % 3 ? 0xa7a18d : 0x77786f)));
    });
    mesh.instanceMatrix.needsUpdate = true; mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = true; group.add(mesh);
  }
  const scatter = [];
  for (let r=b.r0;r<b.r1;r++) for (let c=b.c0;c<b.c1;c++) {
    const t=m.terrain[index(m,c,r)];
    if (m.unknown?.[index(m,c,r)] || t !== TERRAIN.PLAIN || m.houses?.[index(m,c,r)] || terrainArtProfile(m,c,r).patch<.67 || random(c,r,80)>.08) continue;
    const p=offsetToWorld(c,r), angle=random(c,r,81)*Math.PI*2;
    const x=p.x+Math.cos(angle)*3.8,z=p.z+Math.sin(angle)*3.8;
    scatter.push({x,z,y:visual.sample(c,r,x,z)});
  }
  if(scatter.length) {
    const stones=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1,0),new THREE.MeshStandardMaterial({color:0x9a9878,roughness:1,flatShading:true}),scatter.length);
    const o=new THREE.Object3D();
    scatter.forEach((p,i)=>{o.position.set(p.x,p.y+.04,p.z);o.scale.set(.16+random(i,3)*.14,.09,.2);o.rotation.y=random(i,4)*6;o.updateMatrix();stones.setMatrixAt(i,o.matrix);});
    stones.name='terrain-scatter';stones.instanceMatrix.needsUpdate=true;group.add(stones);
  }
  if (m.scenarioId === 'teutoburg' && rocks.length) {
    const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(.19, .28, 2.5, 5),
      new THREE.MeshStandardMaterial({ color: 0x574b34, roughness: 1 }), rocks.length);
    const crowns = new THREE.InstancedMesh(new THREE.ConeGeometry(1.25, 3.5, 6),
      new THREE.MeshStandardMaterial({ color: 0x294e39, roughness: 1, flatShading: true }), rocks.length);
    const o = new THREE.Object3D();
    rocks.forEach((tree, i) => {
      o.position.set(tree.x, tree.y + 1.1, tree.z); o.scale.setScalar(tree.scale); o.updateMatrix();
      trunks.setMatrixAt(i, o.matrix);
      o.position.y = tree.y + 3.45; o.rotation.y = random(i, 7) * 6; o.updateMatrix();
      crowns.setMatrixAt(i, o.matrix);
    });
    trunks.instanceMatrix.needsUpdate = true; crowns.instanceMatrix.needsUpdate = true;
    group.add(trunks, crowns);
  }
  if (m.houses?.some(Boolean) || m.garden) {
    const positions = [];
    for (let r = b.r0; r < b.r1; r++) for (let c = b.c0; c < b.c1; c++)
      if (m.houses[index(m, c, r)]) positions.push({ c, r, p: offsetToWorld(c, r) });
    if (positions.length) {
      const masonry = new THREE.InstancedMesh(new THREE.BoxGeometry(6.5, 1.9, 5.6),
        new THREE.MeshStandardMaterial({ color: m.scenarioId === 'troy' ? 0xb2a18a : 0xb28e66,
          roughness: 1, flatShading: true }), positions.length);
      const roofs = new THREE.InstancedMesh(new THREE.BoxGeometry(7.6, .24, 6.6),
        new THREE.MeshStandardMaterial({ color: m.scenarioId === 'troy' ? 0x945f4d : 0x9b7755,
          roughness: 1, transparent: true,
          opacity: .72, depthWrite: false }), positions.length);
      const o = new THREE.Object3D();
      positions.forEach(({ c, r, p }, i) => {
        const ground = visual.sample(c,r,p.x,p.z);
        o.position.set(p.x, ground + .95, p.z); o.rotation.set(0, (i % 3 - 1) * .11, 0); o.updateMatrix();
        masonry.setMatrixAt(i, o.matrix);
        o.position.y = ground + 2.02; o.updateMatrix(); roofs.setMatrixAt(i, o.matrix);
      });
      masonry.instanceMatrix.needsUpdate = true; roofs.instanceMatrix.needsUpdate = true;
      masonry.receiveShadow = true; group.add(masonry, roofs);
    }
    if (m.garden && contains(region,Math.floor((m.garden.cMin+m.garden.cMax)/2),Math.floor((m.garden.rMin+m.garden.rMax)/2)) && m.scenarioId === 'troy') {
      const centerC = Math.floor((m.garden.cMin + m.garden.cMax) / 2);
      const centerR = Math.floor((m.garden.rMin + m.garden.rMax) / 2);
      const center = offsetToWorld(centerC, centerR);
      const court = new THREE.Group(); court.position.set(center.x, terrainHeight(m, centerC, centerR), center.z);
      const paving = new THREE.MeshStandardMaterial({ color: 0xb9a58a, roughness: 1 });
      const stone = new THREE.MeshStandardMaterial({ color: 0xd0baa0, roughness: 1, flatShading: true });
      const floor = new THREE.Mesh(new THREE.BoxGeometry(21, .12, 13), paving);
      floor.position.y = .08; court.add(floor);
      for (const x of [-8, 8]) for (const z of [-4.8, 4.8]) {
        const column = new THREE.Mesh(new THREE.CylinderGeometry(.32, .44, 2.6, 6), stone);
        column.position.set(x, 1.4, z); court.add(column);
      }
      group.add(court);
    } else if (m.garden && contains(region,Math.floor((m.garden.cMin+m.garden.cMax)/2),Math.floor((m.garden.rMin+m.garden.rMax)/2))) {
      const center = offsetToWorld(Math.floor((m.garden.cMin + m.garden.cMax) / 2),
        Math.floor((m.garden.rMin + m.garden.rMax) / 2));
      const garden = new THREE.Group(); garden.position.set(center.x, .55, center.z);
      const brick = new THREE.MeshStandardMaterial({ color: 0xc9ab7a, roughness: 1 });
      const green = new THREE.MeshStandardMaterial({ color: 0x4f7855, roughness: 1, flatShading: true });
      for (const [w,d,y] of [[36,25,.15],[29,20,.42],[21,15,.72]]) {
        const tier = new THREE.Mesh(new THREE.BoxGeometry(w,.25,d),brick);
        tier.position.y = y; garden.add(tier);
      }
      for (let i = 0; i < 15; i++) {
        const x = (random(i, 8) - .5) * 30, z = (random(i, 13) - .5) * 19;
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.14,.21,1.6,5),brick);
        trunk.position.set(x, 1.48, z); garden.add(trunk);
        const canopy = new THREE.Mesh(new THREE.ConeGeometry(1.28,2.1,6),green);
        canopy.position.set(x, 2.85, z); garden.add(canopy);
      }
      group.add(garden);
    }
  }
  const mist=createKnowledgeMist(m,b,visual.sample);group.add(mist.group);
  group.traverse(o=>{if(o.isMesh)attachKnowledgeMist(o,m);});
  const details = group.children.filter(o => o !== surface && o !== grid && o !== water && o !== roads && o !== crossings.group);
  return { group, surface, sample:visual.sample, pickables: [surface, water, ...crossings.pickables].filter(Boolean), grid,
    setQuality(quality) {
      const low = quality === 'low';vegetation.setQuality(quality);
      for (const o of details) if (o.name === 'terrain-scatter') o.visible = !low;
      surface.material.userData.detail.value = low ? 0 : 1;
      if (water) water.material.userData.detail.value = low ? 0 : 1;
    },
    refreshVegetation(quality) {
      vegetation.group.removeFromParent();for(const mesh of vegetation.group.children)mesh.dispose();
      vegetation=createVegetation(m,visual.sample,region);vegetation.setQuality(quality);group.add(vegetation.group);
    },
    update(time) {mist.update(time); if (water) water.material.userData.clock.value = time * .001; },
  };
}
