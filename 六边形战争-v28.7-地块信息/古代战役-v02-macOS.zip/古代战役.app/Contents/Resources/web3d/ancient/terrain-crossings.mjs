import * as THREE from '../vendor/three/three.module.js';
import { offsetToWorld } from '../js/core/hex.js';
import { TERRAIN, index, neighbors, inBounds, bridgeAt } from './engine.mjs';

import { bounds, crossingAxis } from './terrain-adjacency.mjs';
export const crossingAngle = crossingAxis;
function batch(group,name,items,color) {
  if(!items.length)return null;
  const mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial({color,roughness:.95}),items.length),o=new THREE.Object3D();
  items.forEach((item,i)=>{o.position.set(...item.p);o.scale.set(...item.s);o.rotation.set(0,item.a,0);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);});
  mesh.castShadow=true;mesh.receiveShadow=true;mesh.name=name;mesh.instanceMatrix.needsUpdate=true;group.add(mesh);return mesh;
}
export function createCrossings(m, region = null) {
  const b=bounds(m,region);
  const group=new THREE.Group(),wood=[],stone=[],decks=[];
  for(let r=b.r0;r<b.r1;r++)for(let c=b.c0;c<b.c1;c++) {
    if((m.terrain[index(m,c,r)]&(TERRAIN.RIVER|TERRAIN.ROAD))!==(TERRAIN.RIVER|TERRAIN.ROAD))continue;
    const p=offsetToWorld(c,r),a=crossingAngle(m,c,r),cs=Math.cos(a),sn=Math.sin(a);
    const at=(x,y,z)=>[p.x+cs*x+sn*z,y,p.z-sn*x+cs*z];
    // The underlying ford is always present, including while the bridge is standing.
    for(let j=-3;j<=3;j++)stone.push({p:at(j*1.48,-.23,(j%2)*.18),s:[1.38,.22,2.9],a});
    if(!bridgeAt(m,c,r))continue;
    decks.push({p:at(0,.35,0),s:[10.5,.30,4.0],a});
    for(const side of [-1,1]) {
      wood.push({p:at(0,1.03,side*2),s:[10.5,.24,.22],a});
      for(const x of [-4.6,0,4.6])wood.push({p:at(x,.22,side*2),s:[.28,1.9,.28],a});
    }
    for(let x=-4.6;x<5;x+=.85)wood.push({p:at(x,.514,0),s:[.045,.025,3.95],a});
  }
  const ford=batch(group,'underlying-fords',stone,0xb5ad8e);
  const deck=batch(group,'bridge-decks',decks,0x9f8058);
  batch(group,'bridge-structure',wood,0x68543e);
  return {group,pickables:[ford,deck].filter(Boolean)};
}
