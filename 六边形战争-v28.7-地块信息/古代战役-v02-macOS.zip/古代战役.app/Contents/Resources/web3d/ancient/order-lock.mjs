// Authority is scoped to one synchronous engine call chain, never saved or sent by LLM.
const executing=new WeakMap();
export function committedTask(s,id){return s.delegatedOrders?.find(t=>t.irrevocable&&['active','blocked','paused'].includes(t.status)&&t.ids.includes(id));}
export function orderLocked(s,id){return !!committedTask(s,id)&&executing.get(s)!==id;}
export const LOCK_REASON='军令已生效，受托部队不能接受其他指令；完成或失败后解除锁定';
export function executeCommitted(s,id,fn){const previous=executing.get(s);executing.set(s,id);try{return fn();}finally{if(previous===undefined)executing.delete(s);else executing.set(s,previous);}}
