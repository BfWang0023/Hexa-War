import {mountainSurfaceHeight,mountainSurfaceColor,usesMountainPalette} from './mountain-visual.mjs';
import { groundElevation } from './elevation-rules.mjs';
// Continuous world-space surface: v13 interpolates saved heights; legacy retains its visual relief.
// Rendering never writes simulation data or consumes the game RNG.
import * as T from '../vendor/three/three.module.js';
import {hexCorners,offsetToWorld,worldToOffset} from '../js/core/hex.js';
import {TERRAIN,index,inBounds} from './engine.mjs';
import {bounds} from './terrain-adjacency.mjs';
export const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
export function createVisualField(m,baseHeight){
 const cache=new Map(),relief=new Map(),cells=[];
 function height(x,z){const k=Math.round(x*10000)+','+Math.round(z*10000);if(cache.has(k))return cache.get(k);const cell=worldToOffset(x,z);let weights=0,mountain=0,base=0,elevationOffset=0,road=0,roadHeight=0,nearestRoad=Infinity,water=0,waterHeight=0,nearestWater=Infinity;
  for(let r=cell.row-3;r<=cell.row+3;r++)for(let c=cell.col-3;c<=cell.col+3;c++){if(!inBounds(m,c,r))continue;const cellIndex=index(m,c,r);let source=cells[cellIndex];if(!source){const p=offsetToWorld(c,r),t=m.terrain[cellIndex];cells[cellIndex]=source={...p,t,h:baseHeight(m,c,r),e:groundElevation(m,c,r)-((t&TERRAIN.MOUNTAIN)?1:0)};}const {t}=source,dsq=(x-source.x)**2+(z-source.z)**2;if(dsq>529)continue;const w=Math.exp(-dsq/(m.autoElevation?64:78));weights+=w;elevationOffset+=w*source.e;mountain+=(t&TERRAIN.MOUNTAIN?w:0);base+=w*(t&(TERRAIN.RIVER|TERRAIN.SEA)?-.95:t&TERRAIN.MOUNTAIN?.35:source.h);if(t&TERRAIN.ROAD){const rw=Math.exp(-dsq/32);road+=rw;roadHeight+=rw*source.h;nearestRoad=Math.min(nearestRoad,dsq);}if(t&(TERRAIN.RIVER|TERRAIN.SEA)){const ww=Math.exp(-dsq/32);water+=ww;waterHeight+=ww*-.95;nearestWater=Math.min(nearestWater,dsq);}}
  if(!weights)return baseHeight(m,Math.max(0,Math.min(m.cols-1,cell.col)),Math.max(0,Math.min(m.rows-1,cell.row)));
  const coverage=mountain/weights,mask=smooth(.08,.86,coverage),warp=Math.sin(x*.013+z*.021)*12;
  // Oblique, overlapping broad ridges; crests extend over many cells, not one peak per cell.
  const ridge=Math.pow(.5+.5*Math.sin(x*.035+z*.019+Math.sin(z*.018)*.8),1.7),broad=.5+.5*Math.sin(x*.013-z*.024+Math.sin(x*.009)*.9),secondary=.5+.5*Math.sin((x+warp)*.057-z*.034);
  let h=(base+elevationOffset*3)/weights+mask*(1.2+6.0*ridge+2.0*broad+1.1*secondary);
  if(m.autoElevation)h=mountainSurfaceHeight((elevationOffset+mountain)/weights,coverage,x,z);
  relief.set(k,{logical:(elevationOffset+mountain)/weights,coverage});
  // Existing roads and water carve broad continuous valleys; no per-hex center pits.
  if(road&&!m.autoElevation){const influence=1-smooth(2.7,10.0,Math.sqrt(nearestRoad));h=h*(1-influence)+(roadHeight/road)*influence;}
  if(water){const influence=1-smooth(5.1,9.2,Math.sqrt(nearestWater));h=h*(1-influence)+(waterHeight/water)*influence;}
  cache.set(k,h);return h;
 }return {height,relief(x,z){const k=Math.round(x*10000)+","+Math.round(z*10000);height(x,z);return relief.get(k);},clear(){cache.clear();relief.clear();cells.length=0;}};
}
export function createContinuousSurface(m,baseHeight,tileBase,region,material,waterMaterial,fullDetail=true){
 const group=new T.Group(),area=bounds(m,region),field=createVisualField(m,baseHeight),positions=[],colors=[],indices=[],gridPos=[],waterPos=[],waterColors=[],faces=new Map();
 const detailCache=new Map(),detail=(c,r)=>{if(!fullDetail)return 1;const k=c+','+r;if(detailCache.has(k))return detailCache.get(k);let n=1;for(let rr=r-2;rr<=r+2;rr++)for(let cc=c-2;cc<=c+2;cc++)if(inBounds(m,cc,rr)&&m.terrain[index(m,cc,rr)]&TERRAIN.MOUNTAIN)n=3;detailCache.set(k,n);return n;};
 const position=(c,r,x,z,color)=>{const id=positions.length/3;positions.push(x,field.height(x,z),z);colors.push(color.r,color.g,color.b);return id;};
 for(let r=area.r0;r<area.r1;r++)for(let c=area.c0;c<area.c1;c++){
  const N=detail(c,r),p=offsetToWorld(c,r),corners=hexCorners(p.x,p.z),t=m.terrain[index(m,c,r)],earth=tileBase(t&TERRAIN.ROAD&&!(t&(TERRAIN.RIVER|TERRAIN.SEA))?t&~TERRAIN.ROAD:t,c,r,m),cellFaces=[];
  for(let side=0;side<6;side++){const a=corners[side],b=corners[(side+1)%6],rows=[],across=worldToOffset(p.x+((a[0]+b[0])/2-p.x)*1.05,p.z+((a[1]+b[1])/2-p.z)*1.05),edgeN=N===1?detail(across.col,across.row):N;
   // A coarse cell fans out to the fine neighbour's exact edge samples, avoiding T-junction cracks.
   if(N===1){const center=position(c,r,p.x,p.z,earth);for(let j=0;j<edgeN;j++){const ids=[j/edgeN,(j+1)/edgeN].map(f=>position(c,r,a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f,earth)),face=[center,...ids.reverse()];indices.push(...face);cellFaces.push(face);}}else{
   for(let i=0;i<=N;i++){const row=[];for(let j=0;j<=N-i;j++){const x=p.x+(a[0]-p.x)*i/N+(b[0]-p.x)*j/N,z=p.z+(a[1]-p.z)*i/N+(b[1]-p.z)*j/N;const col=earth.clone();if(t&TERRAIN.MOUNTAIN)col.lerp(new T.Color(0x92917a),smooth(3,9,field.height(x,z))*.35);row.push(position(c,r,x,z,col));}rows.push(row);}
   for(let i=0;i<N;i++)for(let j=0;j<N-i;j++){const f=[rows[i][j],rows[i][j+1],rows[i+1][j]];indices.push(...f);cellFaces.push(f);if(j<N-i-1){const g=[rows[i+1][j],rows[i][j+1],rows[i+1][j+1]];indices.push(...g);cellFaces.push(g);}}
   }
   for(let j=0;j<edgeN;j++)for(const fraction of [j/edgeN,(j+1)/edgeN]){const x=a[0]+(b[0]-a[0])*fraction,z=a[1]+(b[1]-a[1])*fraction;gridPos.push(x,Math.max(field.height(x,z),t&(TERRAIN.RIVER|TERRAIN.SEA)?-.42:-Infinity)+.045,z);}
   if(t&(TERRAIN.RIVER|TERRAIN.SEA))for(const [x,z] of [[p.x,p.z],b,a]){waterPos.push(x,-.42,z);const col=new T.Color(t&TERRAIN.ROAD?0x669389:t&TERRAIN.SEA?0x315e70:0x426f76);waterColors.push(col.r,col.g,col.b);}
  }faces.set(index(m,c,r),cellFaces);
 }
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));geometry.setIndex(indices);
 // Analytical normals sample the same field on either side of a chunk boundary.
 const normals=[];for(let i=0;i<positions.length;i+=3){const x=positions[i],z=positions[i+2],e=.12,v=new T.Vector3(field.height(x-e,z)-field.height(x+e,z),2*e,field.height(x,z-e)-field.height(x,z+e)).normalize();normals.push(v.x,v.y,v.z);}geometry.setAttribute('normal',new T.Float32BufferAttribute(normals,3));
 const surface=new T.Mesh(geometry,material);surface.name='ancient-terrain';surface.receiveShadow=true;
 // Broad terrain reads through normals; removing self-shadow casting avoids the old
 // 1024px shadow-map stair/acne bands without raising shadow resolution or light cost.
 surface.castShadow=false;group.add(surface);
 const grid=new T.LineSegments(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(gridPos,3)),new T.LineBasicMaterial({color:0x263b2f,transparent:true,opacity:.16,depthWrite:false}));grid.name='hex-grid';grid.renderOrder=2;group.add(grid);
 let water=null;if(waterPos.length){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(waterPos,3));g.setAttribute('color',new T.Float32BufferAttribute(waterColors,3));g.computeVertexNormals();water=new T.Mesh(g,waterMaterial);water.name='continuous-water';water.renderOrder=1;group.add(water);}
 const point=new T.Vector3(),a=new T.Vector3(),b=new T.Vector3(),d=new T.Vector3(),bary=new T.Vector3();
 function sample(c,r,x,z){point.set(x,0,z);for(const f of faces.get(index(m,c,r))||[]){a.set(positions[f[0]*3],0,positions[f[0]*3+2]);b.set(positions[f[1]*3],0,positions[f[1]*3+2]);d.set(positions[f[2]*3],0,positions[f[2]*3+2]);T.Triangle.getBarycoord(point,a,b,d,bary);if(Math.min(bary.x,bary.y,bary.z)>=-1e-5)return positions[f[0]*3+1]*bary.x+positions[f[1]*3+1]*bary.y+positions[f[2]*3+1]*bary.z;}return field.height(x,z);}
 if(usesMountainPalette(m)){const col=new T.Color(),attribute=geometry.attributes.color;for(let i=0;i<positions.length;i+=3){const cell=worldToOffset(Math.round(positions[i]*10000)/10000,Math.round(positions[i+2]*10000)/10000),t=m.terrain[index(m,cell.col,cell.row)];if(m.unknown?.[index(m,cell.col,cell.row)]||t&(TERRAIN.RIVER|TERRAIN.SEA|TERRAIN.BEACH))continue;const info=field.relief(positions[i],positions[i+2]);if(!info)continue;mountainSurfaceColor(col,info.logical,normals[i],normals[i+1],normals[i+2],info.coverage);attribute.setXYZ(i/3,col.r,col.g,col.b);}}
 // Construction samples/normals are baked; do not retain their large temporary lookup tables.
 field.clear();
 return {group,surface,grid,water,sample,visualField:field};
}
