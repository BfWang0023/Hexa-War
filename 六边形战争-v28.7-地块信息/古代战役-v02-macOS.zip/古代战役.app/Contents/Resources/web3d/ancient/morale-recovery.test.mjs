import {HELLENISTIC_IDS} from './hellenistic-data.mjs';
import {makeHellenisticMap} from './hellenistic-maps.mjs';
import {CLASSICAL_IDS} from './classical-data.mjs';
import {makeClassicalMap} from './classical-maps.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { addUnit, armyRoutThreshold, canPlaceKind, endSide, isRouted, mobileAt, newMap,
  rallyRoutedSoldiers, startGame, unitMaxHp } from './engine.mjs';
import { makeChinaMap } from './china-campaigns.mjs';
import { IMPERIAL_CAMPAIGN_IDS, makeImperialMap } from './imperial-campaigns.mjs';
import { CAMPAIGN_CATALOG } from './campaign-catalog.mjs';
import { createSave, restoreSave } from './save.mjs';

test('a safe idle soldier gradually recovers morale up to one, with faster command support', () => {
  const map = newMap(20, 10);
  addUnit(map, 'pharaoh', 'egypt', 2, 5);
  addUnit(map, 'light', 'egypt', 4, 5);
  addUnit(map, 'light', 'coalition', 17, 5);
  const game = startGame(map), soldier = mobileAt(game.map, 4, 5);
  soldier.morale = 0.5;
  endSide(game);
  assert.equal(soldier.morale, 0.56);
  endSide(game);
  soldier.movesUsed = 1;
  endSide(game);
  assert.equal(soldier.morale, 0.56);
  endSide(game);
  soldier.movesUsed = 0;
  soldier.morale = 0.99;
  endSide(game);
  assert.equal(soldier.morale, 1);
});

test('one morale guard rallies at most two safe nearby routed soldiers per own turn', () => {
  const map = newMap(20, 12);
  map.scenarioId = 'custom_rally';
  addUnit(map, 'pharaoh', 'egypt', 2, 5);
  addUnit(map, 'moraleGuard', 'egypt', 6, 5);
  for (const [c, r] of [[6, 4], [7, 5], [5, 5]]) addUnit(map, 'light', 'egypt', c, r);
  addUnit(map, 'light', 'coalition', 17, 5);
  const game = startGame(map);
  const targets = game.map.units.filter(u => u.team === 'egypt' && u.kind === 'light');
  for (const u of targets) Object.assign(u, { routed: true, hp: 10, morale: 0.2, ammo: 0 });
  const first = rallyRoutedSoldiers(game, 'egypt');
  assert.equal(first.length, 2);
  assert.deepEqual(rallyRoutedSoldiers(game, 'egypt'), []);
  for (const u of targets.filter(u => first.includes(u.id))) {
    assert.equal(isRouted(u), false);
    assert.equal(u.hp, Math.ceil(unitMaxHp(game.map, u) / 2));
    assert.equal(u.morale, 0.7);
    assert.equal(u.actionsLeft, 0);
  }
  assert.equal(targets.filter(isRouted).length, 1);
  endSide(game);
  endSide(game);
  assert.equal(targets.filter(isRouted).length, 0);
  const last = targets.find(u => !first.includes(u.id));
  assert.equal(last.hp, Math.ceil(unitMaxHp(game.map, last) / 2));
  assert.equal(last.actionsLeft, 0);
  const veteran = targets.find(u => first.includes(u.id));
  const beforeRest = veteran.hp;
  endSide(game);
  assert.ok(veteran.hp > beforeRest);
});

test('morale guards are limited to large campaigns and older slots gain one per side', () => {
  for (const id of ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi']) {
    const map = ['china_changping', 'china_qin_chu'].includes(id) ? makeChinaMap(id) : makeImperialMap(id);
    for (const team of ['egypt', 'coalition'])
      assert.equal(map.units.filter(u => u.team === team && u.kind === 'moraleGuard').length, 1);
    assert.equal(canPlaceKind('moraleGuard', 'egypt', id), true);
  }
  assert.equal(canPlaceKind('moraleGuard', 'egypt', 'china_muye'), true);
  assert.equal(canPlaceKind('moraleGuard', 'egypt', 'custom_battle'), true);

  const map = makeImperialMap('china_seven_states'), game = startGame(map);
  const old = createSave(map, game, 'egypt');
  old.rulesVersion = 7;
  old.scenario.units = old.scenario.units.filter(u => u.kind !== 'moraleGuard');
  old.game.map.units = old.game.map.units.filter(u => u.kind !== 'moraleGuard');
  const restored = restoreSave(old);
  for (const team of ['egypt', 'coalition']) {
    assert.equal(restored.scenario.units.filter(u => u.team === team && u.kind === 'moraleGuard').length, 1);
    assert.equal(restored.game.map.units.filter(u => u.team === team && u.kind === 'moraleGuard').length, 1);
  }
});

test('large fleet battles add one flagship per side and recover two nearby routed ships', async () => {
  const { salamisMap, actiumMap, distance, isShip, usesMorale, neighbors, mobileAt, tile, TERRAIN } = await import('./engine.mjs');
  const { aegospotamiMap } = await import('./greek-campaigns.mjs');
  for (const make of [salamisMap, aegospotamiMap, actiumMap]) {
    const scenario = make(), game = startGame(scenario);
    assert.equal(scenario.units.some(u => u.kind === 'moraleFlagship'), false);
    for (const team of ['egypt', 'coalition'])
      assert.equal(game.map.units.filter(u => u.team === team && u.kind === 'moraleFlagship').length, 1);
  }
  for (const make of [
    (await import('./engine.mjs')).tyreMap,
    (await import('./engine.mjs')).syracuseMap,
    (await import('./engine.mjs')).carthageMap,
  ]) {
    const game = startGame(make());
    for (const team of ['egypt', 'coalition']) {
      const fleet = game.map.units.filter(u => u.team === team && isShip(u) &&
        u.kind !== 'moraleFlagship' && usesMorale(u));
      if (fleet.length >= 2)
        assert.equal(game.map.units.filter(u => u.team === team && u.kind === 'moraleFlagship').length, 1);
    }
  }
  const game = startGame(salamisMap());
  const guard = game.map.units.find(u => u.team === 'egypt' && u.kind === 'moraleFlagship');
  const ships = game.map.units.filter(u => u.team === 'egypt' && isShip(u) &&
    u.kind !== 'moraleFlagship' && !u.commander);
  const positions = neighbors(guard.c, guard.r).filter(p =>
    tile(game.map, p.c, p.r)?.terrain === TERRAIN.SEA && !mobileAt(game.map, p.c, p.r));
  assert.ok(positions.length >= 2);
  const nearby = ships.slice(0, 2);
  for (const [i, ship] of nearby.entries()) Object.assign(ship,
    { ...positions[i], routed: true, hp: 10, morale: 0.1, ammo: 0 });
  const rallied = rallyRoutedSoldiers(game, 'egypt');
  assert.equal(rallied.length, 2);
  for (const ship of nearby.slice(0, 2)) {
    assert.equal(isRouted(ship), false);
    assert.equal(ship.hp, Math.ceil(unitMaxHp(game.map, ship) / 2));
    assert.equal(ship.actionsLeft, 0);
  }
  assert.deepEqual(rallyRoutedSoldiers(game, 'egypt'), []);
});

test('a version-eight fleet save gains flagships without changing losses', async () => {
  const { salamisMap } = await import('./engine.mjs');
  const map = salamisMap(), game = startGame(map);
  const saved = createSave(map, game, 'egypt');
  saved.rulesVersion = 8;
  saved.game.map.units = saved.game.map.units.filter(u => u.kind !== 'moraleFlagship');
  const loaded = restoreSave(saved);
  for (const team of ['egypt', 'coalition'])
    assert.equal(loaded.game.map.units.filter(u => u.team === team && u.kind === 'moraleFlagship').length, 1);
  assert.deepEqual(loaded.game.map.victory.routLosses, game.map.victory.routLosses);
});


test('every army above thirty combat units starts with a land morale guard', async () => {
  const engine = await import('./engine.mjs');
  const { mantineaMap, aegospotamiMap } = await import('./greek-campaigns.mjs');
  for (const { id } of CAMPAIGN_CATALOG) {
    const map = HELLENISTIC_IDS.has(id) ? makeHellenisticMap(id) : CLASSICAL_IDS.has(id) ? makeClassicalMap(id) : IMPERIAL_CAMPAIGN_IDS.has(id) ? makeImperialMap(id) :
      id.startsWith('china_') ? makeChinaMap(id) :
      id === 'mantinea' ? mantineaMap() : id === 'aegospotami' ? aegospotamiMap() :
      engine[`${id}Map`]();
    if (['salamis', 'aegospotami', 'actium'].includes(id)) continue;
    const game = startGame(map);
    for (const team of ['egypt', 'coalition']) if (armyRoutThreshold(map, team) >= 24)
      assert.equal(game.map.units.filter(u => u.team === team && u.kind === 'moraleGuard').length,
        1, `${id}: ${team}`);
  }
});

test('isolated but unengaged troops keep morale through twelve rounds', () => {
  const map = newMap(24, 12);
  map.scenarioId = 'custom_no_spontaneous_rout';
  addUnit(map, 'pharaoh', 'egypt', 1, 1);
  addUnit(map, 'light', 'egypt', 13, 5);
  addUnit(map, 'light', 'coalition', 17, 5);
  const game = startGame(map), soldier = mobileAt(game.map, 13, 5);
  for (let i = 0; i < 24; i++) endSide(game);
  assert.equal(soldier.morale, 1);
  assert.equal(isRouted(soldier), false);
});
