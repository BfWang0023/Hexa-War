import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import * as THREE from '../vendor/three/three.module.js';
import {offsetToWorld,hexCorners} from '../js/core/hex.js';
import {newMap,TERRAIN,setTerrain,setBridge,bridgeAt,setFort,FORT_HP,exportMap,importMap,startGame} from './engine.mjs';
import {createAncientTerrain,terrainHeight} from './terrain.mjs';
import {createTerrainForts,wallHeight} from './terrain-forts.mjs';
import {terrainSignature} from './terrain-environment.mjs';
import {CAMPAIGN_CATALOG} from './campaign-catalog.mjs';
import {mapFor} from '../../tools/ai-training/maps.mjs';
import {createSave,restoreSave} from './save.mjs';
const digest=m=>createHash('sha256').update(JSON.stringify(exportMap(m))).digest('hex');
function dispose(g){const geo=new Set(),mat=new Set();g.traverse(o=>{if(o.isInstancedMesh)o.dispose();if(o.geometry)geo.add(o.geometry);if(o.material)mat.add(o.material)});geo.forEach(o=>o.dispose());mat.forEach(o=>o.dispose());}
for(const {id} of CAMPAIGN_CATALOG)test(`visual regression: ${id} loads without mutating map or rules`,()=>{
  const m=mapFor(id),before=digest(m),t=createAncientTerrain(m);
  t.group.updateMatrixWorld(true);
  t.group.traverse(o=>{
    if(o.geometry)for(const a of Object.values(o.geometry.attributes))assert.ok(a.array.every(Number.isFinite),`${id} ${o.name}`);
    if(o.isInstancedMesh){assert.equal(o.userData.unitIds?.length||o.count,o.count);assert.ok(o.instanceMatrix.array.every(Number.isFinite));}
  });
  assert.equal(digest(m),before);
  const restored=importMap(exportMap(m));assert.equal(digest(restored),digest(importMap(exportMap(mapFor(id)))));
  t.setQuality('low');t.update(1000);t.setQuality('standard');dispose(t.group);
});
test('shared terrain corners have identical height across odd/even rows',()=>{
  const m=newMap(8,8);for(let r=1;r<7;r++)setTerrain(m,3,r,TERRAIN.MOUNTAIN);
  const t=createAncientTerrain(m),a=t.surface.geometry.attributes.position,seen=new Map();
  for(let i=0;i<a.count;i++){
    const k=`${a.getX(i).toFixed(3)},${a.getZ(i).toFixed(3)}`;
    if(seen.has(k))assert.ok(Math.abs(seen.get(k)-a.getY(i))<1e-5);else seen.set(k,a.getY(i));
  }dispose(t.group);
});
test('all logical cell centers raycast to their visual anchor and remain pickable',()=>{
  const m=newMap(8,8);setTerrain(m,2,2,TERRAIN.MOUNTAIN);setTerrain(m,3,3,TERRAIN.ROAD|TERRAIN.RIVER);setTerrain(m,4,4,TERRAIN.RIVER|TERRAIN.ROAD);setBridge(m,4,4);
  const t=createAncientTerrain(m);t.group.updateMatrixWorld(true);
  for(let r=0;r<8;r++)for(let c=0;c<8;c++){
    const p=offsetToWorld(c,r),ray=new THREE.Raycaster(new THREE.Vector3(p.x,30,p.z),new THREE.Vector3(0,-1,0));
    const hit=ray.intersectObjects(t.pickables,false)[0];assert.ok(hit);assert.ok(Math.abs(hit.point.y-((bridgeAt(m,c,r)||(m.terrain[r*m.cols+c]&TERRAIN.RIVER&&m.terrain[r*m.cols+c]&TERRAIN.ROAD))?terrainHeight(m,c,r):m.terrain[r*m.cols+c]&(TERRAIN.RIVER|TERRAIN.SEA)?-.42:t.sample(c,r,p.x,p.z)))<.1,`${c},${r}: ${hit.point.y}`);
  }dispose(t.group);
});
test('bridge removal exposes the same underlying ford without changing terrain bits',()=>{
  const m=newMap(8,8);setTerrain(m,3,3,TERRAIN.RIVER|TERRAIN.ROAD);setBridge(m,3,3);
  const bits=m.terrain.slice(),key=terrainSignature(m),withBridge=createAncientTerrain(m);
  assert.ok(withBridge.group.getObjectByName('bridge-decks'));assert.ok(withBridge.group.getObjectByName('underlying-fords'));
  setBridge(m,3,3,false);assert.equal(bridgeAt(m,3,3),false);assert.deepEqual(m.terrain,bits);assert.notEqual(terrainSignature(m),key);
  const ford=createAncientTerrain(m);assert.equal(ford.group.getObjectByName('bridge-decks'),undefined);assert.ok(ford.group.getObjectByName('underlying-fords'));assert.equal(terrainHeight(m,3,3),-.12);
  dispose(withBridge.group);dispose(ford.group);
});
test('water surface is planar across connected river, ford, bridge and sea',()=>{
  const m=newMap(8,8);for(let c=1;c<7;c++)setTerrain(m,c,3,TERRAIN.RIVER|(c===3?TERRAIN.ROAD:0));setBridge(m,3,3);setTerrain(m,6,3,TERRAIN.SEA);
  const t=createAncientTerrain(m),water=t.group.getObjectByName('continuous-water').geometry.attributes.position;
  for(let i=0;i<water.count;i++)assert.ok(Math.abs(water.getY(i)+.42)<1e-6);dispose(t.group);
});
test('static cache signature invalidates visual edits but ignores mobile unit moves and fort damage',()=>{
  const m=mapFor('china_changping'),sig=terrainSignature(m);m.units[0].hp-=1;m.units[0].c+=1;assert.equal(terrainSignature(m),sig);
  m.terrain[0]^=TERRAIN.ROAD;assert.notEqual(terrainSignature(m),sig);
});
test('forts batch intact/damaged/destroyed states and retain picking IDs and level anchors',()=>{
  const m=newMap(8,8);for(let i=1;i<=3;i++)setFort(m,i+1,3,i,'egypt');
  m.units[1].hp=FORT_HP[2]*.3;m.units[2].hp=0;const before=JSON.stringify(m.units),g=createTerrainForts(m,m.units,terrainHeight);
  assert.ok(g.children.length<=5);assert.ok(g.getObjectByName('wall-cracks'));assert.ok(g.getObjectByName('wall-rubble'));
  g.traverse(o=>{if(o.isInstancedMesh)assert.equal(o.count,o.userData.unitIds.length)});
  assert.equal(JSON.stringify(m.units),before);assert.equal(wallHeight(3),3.5);dispose(g);
});
test('34 revised bundled maps survive renderer and save roundtrip',()=>{
  assert.ok(readdirSync(new URL('./bundled-maps/',import.meta.url)).filter(n=>n.endsWith('.json')).length>=34);
  const m=mapFor('china_changping'),game=startGame(m),save=JSON.parse(JSON.stringify(createSave(m,game,'egypt')));
  const restored=restoreSave(save);assert.ok(restored);
});
test('mountain banks cannot close the channel between adjacent water cells',()=>{
  const m=newMap(8,8);for(let r=1;r<7;r++)for(let c=1;c<7;c++)setTerrain(m,c,r,TERRAIN.MOUNTAIN);
  setTerrain(m,3,3,TERRAIN.RIVER);setTerrain(m,3,4,TERRAIN.RIVER);
  const a=offsetToWorld(3,3),b=offsetToWorld(3,4),t=createAncientTerrain(m);t.group.updateMatrixWorld(true);
  const ray=new THREE.Raycaster(new THREE.Vector3((a.x+b.x)/2,30,(a.z+b.z)/2),new THREE.Vector3(0,-1,0));
  const hit=ray.intersectObjects(t.pickables,false)[0];assert.ok(Math.abs(hit.point.y+.42)<1e-5);dispose(t.group);
});

test('fort levels have distinct timber, stone and tower silhouettes without changing rule heights',()=>{
  const m=newMap(8,8),bounds=[];
  for(let level=1;level<=3;level++){
    setFort(m,3,3,level,'egypt');const u=m.units.find(u=>u.c===3&&u.r===3);
    const g=createTerrainForts(m,[u],terrainHeight);g.updateMatrixWorld(true);
    assert.equal(!!g.getObjectByName('wall-timber'),level===1);
    const box=new THREE.Box3().setFromObject(g);bounds.push(box.max.y-terrainHeight(m,3,3));
    assert.ok(g.children.length<=5);dispose(g);
  }
  assert.ok(bounds[0]<bounds[1]);assert.ok(bounds[2]>bounds[1]+1.5);
  assert.deepEqual([1,2,3].map(wallHeight),[1.75,2.6,3.5]);
});
