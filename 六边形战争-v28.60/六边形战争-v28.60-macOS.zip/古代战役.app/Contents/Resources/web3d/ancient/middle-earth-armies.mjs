import * as E from './engine.mjs';
import {groundConnection, groundStand} from './cliff-navigation.mjs';
import {isMorannon, meKind, meMountedRole, morannonWindows} from './middle-earth-data.mjs';

const W='egypt', B='coalition', VERSION=1;
const gondor=['meGondor','meGuard','meGondorBow','meGondor','meGondorBow'];
const cavalry=['meRohan','meRohan','meRohanLight','meGondorHorse'];
const rohan=['meRohanFoot','meRohanBow','meRohanFoot','meRohanLight','meRohanFoot'];
const orcs=['meOrc','meOrcBow','meOrc','meEast','meOrc','meHarad'];
const uruks=['meUruk','meUruk','meUrukBow','meDunland','meOrc'];
const wolves=['meOrc','meWarg','meOrcBow','meWolf','meOrc'];
const allies=['meDwarf','meLake','meElf','meDwarf','meLake'];
const corsairs=['meCorsair','meCorsair','meHarad'];
// Map-scoped profiles keep the original balance in saved V6 battles.
export const ARMY_ELITES={
  meGuard:{hp:164,armor:4,melee:11,meleeHit:84},
  meDwarf:{hp:152,armor:5,melee:10},
  meElf:{ranged:7.2,rangedHit:89},
  meUruk:{hp:123,armor:3,melee:10.5,meleeHit:83},
  meRohan:{hp:112,melee:11,meleeHit:84},
  meWitchKing:{hp:310,armor:6,melee:21,meleeHit:89},
  meGrond:{hp:440,armor:7,melee:27,meleeHit:89},
  meNazgul:{hp:228,armor:4,melee:16,meleeHit:85},
  meMumak:{hp:330,armor:5,melee:20,meleeHit:82},
  meTroll:{hp:218,armor:4,melee:17,meleeHit:81},
  meBeorn:{hp:240,armor:4,melee:18,meleeHit:85},
};
// Each entry is count, assembly area, objective, roster, and the scenario lane.
const sector=(count,c,r,gc,gr,kinds,lane)=>({count,entry:{c,r},goal:{c:gc,r:gr},kinds,lane});
const wave=(key,turn,team,label,position)=>({key,turn,team,label,...position});
const configs={
  me_pelennor:{
    mounts:{meEowyn:'shock'},
    peak:[48,80],total:[64,120],
    front:[
      [sector(7,11,24,14,27,gondor,'王城守军'),sector(8,17,29,20,28,gondor,'南侧出击'),sector(6,18,19,23,22,cavalry,'骑兵预备')],
      [sector(14,23,27,15,27,orcs,'大门围攻'),sector(14,27,19,19,22,orcs,'北翼包抄'),sector(13,30,29,20,30,orcs,'南翼压迫')],
    ],
    story:{rohan:[20,8,23,22,'洛汗侧翼'],harad:[39,22,22,28,'南方反骑兵'],ships:[42,32,26,27,'哈隆德援军']},
    waves:[
      wave('rohan-wing',3,W,'洛汗第二线沿北路展开',sector(8,18,9,23,22,cavalry,'洛汗侧翼')),
      wave('siege-follow',3,B,'魔多后续步兵从围城大道压上',sector(16,36,21,17,26,orcs,'大门围攻')),
      wave('east-shields',6,B,'东方步兵进入南翼',sector(16,40,28,23,29,orcs,'南翼压迫')),
      wave('harbour-line',7,W,'南方步兵由河港接续登陆',sector(7,43,31,24,27,gondor,'哈隆德援军')),
      wave('mordor-reserve',9,B,'魔多北线预备队投入',sector(16,37,16,23,21,orcs,'北翼包抄')),
      wave('gondor-reserve',11,W,'王城预备队换防',sector(5,10,28,18,27,gondor,'王城守军')),
      wave('last-orcs',12,B,'魔多最后的军团进入战场',sector(12,42,24,22,25,orcs,'南翼压迫')),
    ],
  },
  me_hornburg:{
    mounts:{meGandalf:'maneuver'},
    peak:[28,52],total:[36,84],
    front:[[sector(5,24,14,26,16,rohan,'主门守军'),sector(4,24,21,26,19,rohan,'侧门预备')],
      [sector(8,35,13,28,16,uruks,'主门围攻'),sector(7,35,20,28,19,uruks,'深谷侧翼'),sector(4,34,23,28,22,['meOrc','meOrcBow'],'溪流涵洞')]],
    story:{dawn:[44,13,39,16,'黎明援军']},
    waves:[
      wave('deep-wall-relief',4,W,'堡内守军补位',sector(5,20,15,26,18,rohan,'侧门预备')),
      wave('isengard-main',3,B,'艾辛格第二线向主门推进',sector(17,47,15,28,16,uruks,'主门围攻')),
      wave('westfold-foot',7,W,'西谷步兵跟进反击',sector(7,45,12,39,16,rohan,'黎明援军')),
      wave('isengard-south',6,B,'艾辛格从深谷南侧增援',sector(17,46,22,29,21,uruks,'深谷侧翼')),
      wave('isengard-last',9,B,'艾辛格最后一批后备队抵达',sector(18,49,18,29,17,uruks,'主门围攻')),
    ],
  },
  me_erebor:{
    peak:[42,68],total:[54,100],
    front:[[sector(7,14,20,18,25,['meElf','meLake'],'乌鸦岭'),sector(8,30,15,25,19,allies,'谷口协防')],
      [sector(12,11,31,16,24,wolves,'乌鸦岭包抄'),sector(11,26,30,24,18,orcs,'谷口主攻'),sector(8,40,26,29,20,wolves,'东山脊包抄')]],
    story:{eagles:[14,21,24,21,'高处支援'],beorn:[16,31,24,21,'谷口反击']},
    waves:[
      wave('lake-second',4,W,'湖民从东坡接续',sector(8,34,17,26,19,allies,'谷口协防')),
      wave('gundabad-wing',4,B,'刚达巴军团沿西侧上场',sector(18,9,34,16,26,wolves,'乌鸦岭包抄')),
      wave('iron-hills',7,W,'铁丘陵预备队进入山门通路',sector(13,33,13,24,18,allies,'谷口协防')),
      wave('gundabad-valley',7,B,'半兽人继续进攻谷口',sector(18,31,34,24,18,orcs,'谷口主攻')),
      wave('gundabad-last',10,B,'东山脊最后一批座狼抵达',sector(16,43,29,29,20,wolves,'东山脊包抄')),
    ],
  },
  me_isen_first:{
    peak:[28,44],total:[32,64],
    front:[[sector(6,18,18,24,17,rohan,'西岸掩护'),sector(7,34,19,27,17,rohan,'东岸换防')],
      [sector(11,15,13,23,17,uruks,'西岸压迫'),sector(9,35,9,27,17,uruks,'东岸切入')]],
    story:{rescue:[42,26,35,22,'东岸接应']},
    waves:[
      wave('isen-reserve-a',3,B,'艾辛格第二线压向渡口',sector(16,10,11,24,17,uruks,'西岸压迫')),
      wave('isen-relief',5,W,'洛汗步兵接应撤离',sector(9,42,25,36,22,rohan,'东岸接应')),
      wave('isen-reserve-b',6,B,'艾辛格东岸后备到位',sector(16,42,8,34,20,uruks,'东岸切入')),
    ],
  },
  me_isen_second:{
    peak:[32,64],total:[36,104],
    front:[[sector(8,18,17,24,17,rohan,'西岸掩护'),sector(9,34,19,27,17,rohan,'东岸换防')],
      [sector(19,14,13,23,17,uruks,'西岸压迫'),sector(17,35,10,29,18,uruks,'东岸切入')]],
    story:{flank:[39,8,32,19,'东岸切入']},
    waves:[
      wave('isen-pressure',3,B,'艾辛格西岸后备到位',sector(17,9,12,23,17,uruks,'西岸压迫')),
      wave('isen-rearguard',4,W,'洛汗后卫接应渡口撤离',sector(12,41,24,35,22,rohan,'东岸接应')),
      wave('isen-east',6,B,'艾辛格北方包抄',sector(18,42,9,34,20,uruks,'东岸切入')),
      wave('isen-last',8,B,'艾辛格最后一批后备投入',sector(18,11,15,24,17,uruks,'西岸压迫')),
    ],
  },
  me_pelargir:{
    peak:[24,40],total:[28,60],
    front:[[sector(3,23,10,35,7,gondor,'北码头'),sector(4,22,23,32,25,gondor,'南码头')],
      [sector(4,33,10,35,7,corsairs,'北码头'),sector(5,32,18,34,16,corsairs,'中码头'),sector(4,32,24,32,25,corsairs,'南码头')]],
    waves:[
      wave('living-vanguard',2,W,'活人后续队伍沿港外大道抵达',sector(10,20,16,34,17,gondor,'中码头')),
      wave('corsair-rotation',5,B,'海盗码头守军轮换',sector(16,31,11,34,16,corsairs,'中码头')),
      wave('living-harbour',6,W,'活人接管队从南路进入',sector(2,17,24,32,25,gondor,'南码头')),
      wave('corsair-last',8,B,'海盗后备分守南港',sector(16,29,25,32,25,corsairs,'南码头')),
    ],
  },
  me_morannon:{
    mounts:{meAragorn:'shock',meGandalf:'maneuver'},
    peak:[28,80],total:[32,144],
    front:[[sector(7,11,12,15,13,gondor,'北翼牵制'),sector(6,11,19,15,17,cavalry,'南翼牵制')],
      [sector(16,24,10,16,13,orcs,'黑门北翼'),sector(15,24,18,16,17,orcs,'黑门南翼')]],
    story:{'mordor-1':[28,10,16,13,'黑门北翼'],'mordor-2':[28,19,16,17,'黑门南翼']},
    waves:[
      wave('west-front-reserve',5,W,'西方联军最后一批预备队就位',sector(8,8,16,14,15,gondor,'正面牵制')),
      wave('mordor-north',4,B,'魔多北翼第二线投入',sector(18,29,9,16,13,orcs,'黑门北翼')),
      wave('mordor-south',6,B,'魔多南翼第二线投入',sector(18,29,20,16,17,orcs,'黑门南翼')),
      wave('mordor-depth',9,B,'魔多门后纵深后备投入',sector(18,31,14,14,15,orcs,'黑门北翼')),
      wave('mordor-last',12,B,'黑门最后一批预备队到达',sector(18,31,18,15,16,orcs,'黑门南翼')),
      wave('mordor-flank-last',15,B,'魔多最后的侧翼梯队就位',sector(12,29,10,16,14,orcs,'黑门北翼')),
    ],
  },
};

export function frontUnit(map,u){
  if(u.kind==='fort')return false;
  if(!isMorannon(map.scenarioId))return true;
  const [lo,hi]=morannonWindows(map).front;
  return u.c>=lo&&u.c<hi;
}

function assemblyCells(map,origin,kind,radius){
  const cells=[];
  const [lo,hi]=isMorannon(map.scenarioId)?morannonWindows(map).front:[0,map.cols];
  const stats=meKind(kind), mounted=meMountedRole(map,{kind})||['meWarg','meWolf'].includes(kind);
  for(let r=Math.max(0,origin.r-radius);r<=Math.min(map.rows-1,origin.r+radius);r++){
    for(let c=Math.max(lo,origin.c-radius);c<Math.min(hi,origin.c+radius+1);c++){
      const p={c,r},d=E.distance(origin,p);
      if(d>radius||E.fortAt(map,c,r)||E.houseAt(map,c,r))continue;
      const t=E.tile(map,c,r).terrain;
      if(!stats.air&&(t&(E.TERRAIN.RIVER|E.TERRAIN.SEA|E.TERRAIN.ROAD)||mounted&&t&E.TERRAIN.MOUNTAIN))continue;
      if(!groundStand(map,{kind},c,r))continue;
      if(!stats.air&&!E.neighbors(c,r).some(next=>E.inBounds(map,next.c,next.r)&&
        !groundConnection(map,{kind},next,p)))continue;
      cells.push({...p,score:d+Math.abs(c-origin.c)*.28+(t&E.TERRAIN.MOUNTAIN?1.15:0)});
    }
  }
  return cells.sort((a,b)=>a.score-b.score||a.r-b.r||a.c-b.c);
}
function place(map,kind,team,cells,{enemyDistance=0}={}){
  for(const {c,r} of cells){
    if(map.units.some(u=>u.kind!=='fort'&&u.hp>0&&!u.escaped&&u.c===c&&u.r===r))continue;
    if(enemyDistance&&map.units.some(u=>u.kind!=='fort'&&u.team!==team&&u.hp>0&&!u.escaped&&E.distance(u,{c,r})<enemyDistance))continue;
    // addUnit is an editor operation that replaces a previous occupant. Preserve casualties for the after-action record.
    const history=map.units.filter(u=>u.kind!=='fort'&&u.c===c&&u.r===r&&(u.hp<=0||u.escaped));
    if(!E.addUnit(map,kind,team,c,r))continue;
    const unit=map.units.at(-1);
    const replaced=history.filter(u=>!map.units.includes(u));
    map.units.unshift(...replaced);
    return unit;
  }
}
export function applyArmyDeployment(map){
  const config=configs[isMorannon(map.scenarioId)?'me_morannon':map.scenarioId];
  if(!config)return;
  const army={version:VERSION,peak:config.peak,total:config.total,mounts:{...config.mounts},assignments:[]};
  map.victory.army=army;
  for(const u of map.units.filter(u=>army.mounts[u.kind])){
    const t=E.tile(map,u.c,u.r).terrain;
    if(groundStand(map,u,u.c,u.r)&&(!(t&E.TERRAIN.MOUNTAIN)||t&E.TERRAIN.ROAD))continue;
    const cells=[...E.neighbors(u.c,u.r),...assemblyCells(map,u,u.kind,4)];
    const next=cells.find(p=>{
      if(!E.inBounds(map,p.c,p.r)||E.mobileAt(map,p.c,p.r)||E.fortAt(map,p.c,p.r)||E.houseAt(map,p.c,p.r))return false;
      const t=E.tile(map,p.c,p.r).terrain;
      return !(t&(E.TERRAIN.RIVER|E.TERRAIN.SEA))&&(!(t&E.TERRAIN.MOUNTAIN)||t&E.TERRAIN.ROAD)&&groundStand(map,u,p.c,p.r);
    });
    if(!next)throw Error(`找不到骑乘指挥官的出发阵位：${u.kind}`);
    Object.assign(u,{c:next.c,r:next.r});
  }
  config.front.forEach((groups,side)=>{
    const team=side===0?W:B;
    for(const group of groups){
      for(let i=0;i<group.count;i++){
        const kind=group.kinds[i%group.kinds.length];
        const cells=assemblyCells(map,group.entry,kind,5);
        const unit=place(map,kind,team,cells,{enemyDistance:3});
        if(!unit)throw Error(`扩军部署失败 ${map.scenarioId} ${group.lane} ${kind}`);
        army.assignments.push({team,kind,c:unit.c,r:unit.r,lane:group.lane,goal:group.goal});
      }
    }
  });
  const kinds=new Set([...map.units.map(u=>u.kind),
    ...map.victory.waves.flatMap(w=>w.rows.map(([kind])=>kind)),...config.waves.flatMap(w=>w.kinds)]);
  for(const [kind,profile] of Object.entries(ARMY_ELITES))if(kinds.has(kind))E.setUnitStats(map,kind,profile);
  for(const kind of Object.keys(army.mounts))E.setUnitStats(map,kind,{...map.unitStats?.[kind],move:3});
  for(const w of map.victory.waves){
    const entry=config.story?.[w.key];
    if(entry){const [c,r,gc,gr,lane]=entry;Object.assign(w,{entry:{c,r},goal:{c:gc,r:gr},lane});}
    w.story=true;
  }
  for(const w of config.waves){
    const rows=Array.from({length:w.count},(_,i)=>[w.kinds[i%w.kinds.length],w.entry.c,w.entry.r,null]);
    const {count,kinds,...metadata}=w;
    map.victory.waves.push({...metadata,rows,story:false});
  }
}

export function initializeArmy(s){
  const army=s.map.victory.army;
  if(!army)return;
  const initial=s.map.units.filter(u=>frontUnit(s.map,u));
  const roles={};
  for(const a of army.assignments){
    const unit=initial.find(u=>u.team===a.team&&u.kind===a.kind&&u.c===a.c&&u.r===a.r);
    if(unit)roles[unit.id]={lane:a.lane,goal:a.goal};
  }
  let serial=10000;
  const reserve=Object.fromEntries(s.map.victory.waves.map(w=>[w.key,w.rows.map(()=>({id:`u${serial++}`,entered:null}))]));
  s.middleEarth.army={version:VERSION,initial:initial.map(u=>u.id),roles,reserve};
}
export function armyReservePending(s,team){
  const army=s.middleEarth.army;
  return !!army&&s.map.victory.waves.some(w=>w.team===team&&army.reserve[w.key].some(slot=>slot.entered===null));
}
export function deployArmyWave(s,w,record){
  const state=s.middleEarth.army, slots=state.reserve[w.key], teamIndex=w.team===W?0:1;
  const active=s.map.units.filter(u=>u.team===w.team&&frontUnit(s.map,u)&&u.hp>0&&!u.escaped);
  const cap=s.map.victory.army.peak[teamIndex];
  const reserved=w.story?0:s.map.victory.waves.filter(other=>other.story&&other.team===w.team)
    .reduce((n,other)=>n+state.reserve[other.key].filter(slot=>slot.entered===null).length,0);
  let room=Math.max(0,cap-active.length-reserved);
  for(let i=0;i<slots.length&&room;i++){
    const slot=slots[i];
    if(slot.entered!==null)continue;
    const [kind,c,r,name]=w.rows[i];
    const origin=w.story?{c,r}:w.entry;
    const preferred=w.story?[origin,...assemblyCells(s.map,origin,kind,3)]:assemblyCells(s.map,origin,kind,4);
    const mounted=meMountedRole(s.map,{kind});
    const cells=preferred.filter(p=>{
      if(E.fortAt(s.map,p.c,p.r)||Object.values(s.map.victory.points).some(q=>E.distance(p,q)<=1))return false;
      const terrain=E.tile(s.map,p.c,p.r).terrain;
      return !mounted||!(terrain&E.TERRAIN.MOUNTAIN)||terrain&E.TERRAIN.ROAD;
    });
    const u=place(s.map,kind,w.team,cells,{enemyDistance:2});
    if(!u)continue;
    u.id=slot.id;u.heading12=u.team===W?3:9;
    if(name)u.customName=name;
    if(w.goal)state.roles[u.id]={lane:w.lane,goal:w.goal};
    slot.entered=s.turn;
    room--;
    if(!s.middleEarth.events[w.key])record(s,w.key,w.label);
  }
}
export function validateArmy(map){
  const a=map.victory.army;
  if(!a)return;
  if(a.version!==VERSION||map.victory.layoutVersion!==6||![a.peak,a.total].every(xs=>Array.isArray(xs)&&xs.length===2&&xs.every(x=>Number.isInteger(x)&&x>0&&x<=200))||
    (a.mounts&&Object.entries(a.mounts).some(([kind,role])=>!meKind(kind)?.story||!['shock','maneuver'].includes(role)))||
    !Array.isArray(a.assignments)||a.assignments.some(x=>!x||!meKind(x.kind)||![W,B].includes(x.team)||!E.inBounds(map,x.c,x.r)||!E.inBounds(map,x.goal?.c,x.goal?.r)||typeof x.lane!=='string'))
    throw Error('扩军配置无效');
  for(const [i,team] of [W,B].entries()){
    const count=map.units.filter(u=>u.team===team&&frontUnit(map,u)).length;
    const future=map.victory.waves.filter(w=>w.team===team).reduce((n,w)=>n+w.rows.length,0);
    if(count>a.peak[i]||count+future>a.total[i])throw Error('扩军兵力超过预算');
  }
}
export function validateArmySave(map,d,units){
  if(!map.victory.army){if(d.army)throw Error('旧版中土存档不能加载扩军队列');return;}
  const a=d.army;
  const unitIds=new Set(units.map(u=>u.id));
  if(a?.version!==VERSION||!Array.isArray(a.initial)||new Set(a.initial).size!==a.initial.length||
    a.initial.some(id=>!unitIds.has(id))||!a.roles||!a.reserve)throw Error('扩军存档无效');
  let serial=10000;
  for(const w of map.victory.waves){
    const slots=a.reserve[w.key];
    if(!Array.isArray(slots)||slots.length!==w.rows.length)throw Error('增援队列无效');
    for(const slot of slots){
      if(slot?.id!==`u${serial++}`||unitIds.has(slot.id)!==(slot.entered!==null)||
        (slot.entered!==null&&(!Number.isInteger(slot.entered)||slot.entered<1)))throw Error('增援唯一标识无效');
    }
  }
}
