import {fortificationLayout,isSolidWall,usesFortificationLayout} from './fortification-layout.mjs';
import * as T from '../vendor/three/three.module.js';
import {worldToOffset} from '../js/core/hex.js';
import {meKind} from './middle-earth-data.mjs';
import {TERRAIN,index,inBounds,isRouted} from './engine.mjs';

import {createArmyMemberGeometry} from './army-member-geometry.mjs';
import {visualProfile} from './visual-profiles.mjs';
import {UNIT_SCENE_SCALE,unitBodyScale} from './unit-presentation.mjs';

export function isArmyFormation(u){
  const p=meKind(u.kind);
  return !!p&&(!p.story||u.kind==='meDead');
}
const specs={
  infantry:{width:2.8,length:2.9},
  ranged:{width:2.7,length:3.0},
  ghost:{width:2.8,length:2.9},
};
const longFormation=new Set(['mounted','warg','wolf']);
const modeFor=(u,profile)=>u.kind==='meWarg'?'warg':u.kind==='meWolf'?'wolf':u.kind==='meDead'?'ghost':
  profile.family==='cavalry'?'mounted':profile.canRanged?'ranged':'infantry';
export const ARMY_FORMATION_COUNT=4;
const rows=(length,width)=>[-.5,.5].flatMap(x=>[-.5,.5].map(z=>({x:x*length,z:z*width})));
const buildingOffsets=rows(3.3,7.7);
const singleRider=[{x:0,z:0}];
const wallFile=[-1.5,-.5,.5,1.5].map(i=>({x:i*1.78,z:0}));
export function formationOffsets(mode,narrow=false){
  if(longFormation.has(mode))return singleRider;
  const {length,width}=specs[mode];
  if(narrow)return [-1.5,-.5,.5,1.5].map(x=>({x:x*1.95,z:0}));
  return rows(length,width);
}
function corridorPoint(corridor,offset){
  const {points,blend}=corridor;
  let i=corridor.idx,from=points[i],to=points[i+1],length=from.distanceTo(to);
  let along=length*blend+offset;
  while(along<0&&i>0){to=from;from=points[--i];length=from.distanceTo(to);along+=length;}
  while(along>length&&i+2<points.length){along-=length;from=to;to=points[++i+1];length=from.distanceTo(to);}
  const t=along/Math.max(.01,length);
  return {x:from.x+(to.x-from.x)*t,z:from.z+(to.z-from.z)*t,yaw:-Math.atan2(to.z-from.z,to.x-from.x)};
}
export function createArmyFormationRenderer(){
  const batches=new Map(), group=new T.Group(),tmp=new T.Object3D();
  group.name='middle-earth-formations';
  let entries=[], map=null, sample, last=-Infinity, visibleMen=0, cameraMatrix=new T.Matrix4(),frustum=new T.Frustum();
  const sphere=new T.Sphere(new T.Vector3(),9), tint=new T.Color(), flash=new T.Color(0xffbd95);
  const pose={morphTargetInfluences:[0,0,0,0]};
  const material=new T.MeshLambertMaterial({vertexColors:true});
  const ghostMaterial=new T.MeshLambertMaterial({vertexColors:true,transparent:true,opacity:.72,depthWrite:false});
  const geometry=new Map(), layouts=new Map();
  let fortCells=new Set(),works=null;

  function obtain(key,entry,capacity){
    const old=batches.get(key);
    if(old&&old.instanceMatrix.count>=capacity)return old;
    if(old){old.removeFromParent();old.dispose();}
    if(!geometry.has(key))geometry.set(key,createArmyMemberGeometry(entry.u,map));
    const ghost=entry.mode==='ghost';
    const mesh=new T.InstancedMesh(geometry.get(key),ghost?ghostMaterial:material,Math.max(16,capacity));
    mesh.name='formation-'+entry.u.kind;
    mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
    // Allocate for the batch capacity before resetting the visible count.
    mesh.setMorphAt(0,pose);
    mesh.count=0;
    mesh.frustumCulled=false;
    mesh.userData.formationIds=[];
    group.add(mesh);
    batches.set(key,mesh);
    return mesh;
  }
  function bind(m,units,models,groundSample){
    map=m;
    sample=groundSample;
    works=usesFortificationLayout(m)?fortificationLayout(m):null;
    fortCells=new Set(m?.units.filter(v=>v.kind==='fort'&&v.hp>0).map(v=>index(m,v.c,v.r)));
    const groups=new Map();
    entries=[];
    for(const u of units){
      const model=models.get(u.id);
      if(!model?.userData.armyFormation)continue;
      const profile=visualProfile(u,m.scenarioId,m),mode=modeFor(u,profile);
      const key=JSON.stringify([u.kind,profile.family,profile.canMelee,profile.canRanged]);
      const scale=UNIT_SCENE_SCALE*unitBodyScale(profile);
      const entry={u,mode,key,model,profile,scale,seed:Number(u.id.slice(1))||0};
      entries.push(entry);
      const spec=groups.get(key);
      const count=longFormation.has(mode)?1:ARMY_FORMATION_COUNT;
      if(spec)spec.capacity+=count;
      else groups.set(key,{entry,capacity:count});
    }
    for(const [key,{entry,capacity}] of groups)obtain(key,entry,capacity);
    for(const {key,model,scale} of entries){
      const {standingHeight,muzzle}=geometry.get(key).userData;
      model.userData.armyHeight=standingHeight*scale;
      model.userData.armyMuzzle=muzzle&&muzzle.map(n=>n*scale);
    }
    for(const [key,mesh] of batches)if(!groups.has(key)){
      mesh.removeFromParent();
      mesh.dispose();
      batches.delete(key);
    }
    group.visible=entries.length>0;
    if(!group.visible)visibleMen=0;
    last=-Infinity;
  }
  function update(camera,time){
    if(!group.visible||time-last<32)return;
    last=time;
    cameraMatrix.multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);
    frustum.setFromProjectionMatrix(cameraMatrix);
    for(const mesh of batches.values()){mesh.count=0;mesh.userData.formationIds.length=0;}
    visibleMen=0;
    for(const {u,model,mode,seed,key,profile,scale} of entries){
      const {x,y,z}=model.position,dist=camera.position.distanceTo(model.position);
      sphere.center.copy(model.position);
      if(!frustum.intersectsSphere(sphere))continue;
      const p=worldToOffset(x,z),cell=inBounds(map,p.col,p.row)?index(map,p.col,p.row):-1;
      const moving=model.userData.armyMoving,routed=isRouted(u);
      const courtyard=map.victory.layoutVersion>=2&&map.houses[cell]&&!moving;
      const narrow=!!((map.terrain[cell]&(TERRAIN.RIVER|TERRAIN.ROAD))&&moving||fortCells.has(cell));
      const layout=mode+':'+narrow;
      if(!layouts.has(layout))layouts.set(layout,formationOffsets(mode,narrow));
      const work=works?.at(p.col,p.row),gate=work?.fort.gate&&work.fort.hp>0,wall=isSolidWall(work?.fort);
      const corridor=model.userData.armyCorridor;
      const positions=longFormation.has(mode)?singleRider:
        gate||corridor||wall?wallFile:courtyard?buildingOffsets:layouts.get(layout);
      const mesh=batches.get(key);
      // Heading is locked to the opening or walkway while the formation is on it.
      let yaw=model.rotation.y;
      if(gate&&!corridor)yaw=work.axis+Math.PI/2;
      else if(wall&&!moving)yaw=-Math.atan2(work.arms[0].dz,work.arms[0].dx);
      else if(courtyard)yaw=Math.cos(yaw)>=0?0:Math.PI;
      const cs=Math.cos(yaw),sn=Math.sin(yaw);
      const action=model.userData.armyAction,progress=model.userData.armyProgress??0;
      for(let i=0;i<positions.length;i++){
        const offset=positions[i];
        const lane=corridor&&corridorPoint(corridor,offset.x);
        let px=lane?lane.x:x+cs*offset.x+sn*offset.z,pz=lane?lane.z:z-sn*offset.x+cs*offset.z;
        if(narrow&&!gate&&!wall&&!corridor){
          const at=worldToOffset(px,pz);
          if(at.col!==p.col||at.row!==p.row){px=x+(px-x)*.55;pz=z+(pz-z)*.55;}
        }
        const ground=(gate||corridor)&&sample?sample(px,pz)+.08:
          dist<100&&sample&&!wall?Math.max(y-.48,Math.min(y+.48,sample(px,pz)+.08)):y;
        const gait=moving?Math.sin(time*(routed?.015:.009)+seed*.67+i*.83):0;
        tmp.position.set(px,ground+(moving?Math.abs(gait)*.045:0),pz);
        tmp.rotation.set(0,lane?lane.yaw:yaw+(gate||wall?0:(i%3-1)*.035),0);
        tmp.scale.setScalar(scale);
        tmp.updateMatrix();
        mesh.setMatrixAt(mesh.count,tmp.matrix);
        tint.setScalar((routed?.64:.90)+(seed+i*7)%11*.017);
        if(model.userData.armyHit)tint.lerp(flash,.5);
        mesh.setColorAt(mesh.count,tint);

        const strength=Math.sin(progress*Math.PI);
        pose.morphTargetInfluences[0]=Math.max(0,gait);
        pose.morphTargetInfluences[1]=Math.max(0,-gait);
        pose.morphTargetInfluences[2]=action===profile.meleeAction&&action!=='none'?strength:0;
        pose.morphTargetInfluences[3]=action===profile.rangedAction&&action!=='none'?strength:0;
        mesh.setMorphAt(mesh.count,pose);
        mesh.userData.formationIds[mesh.count]=u.id;
        mesh.count++;
      }
      visibleMen+=positions.length;
    }
    for(const mesh of batches.values()){
      mesh.instanceMatrix.needsUpdate=true;
      mesh.morphTexture.needsUpdate=true;
      if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
      mesh.boundingSphere=null;
    }
  }
  return {group,bind,update,get visibleMen(){return visibleMen;},clear(){bind(null,[],new Map(),null);}};
}
