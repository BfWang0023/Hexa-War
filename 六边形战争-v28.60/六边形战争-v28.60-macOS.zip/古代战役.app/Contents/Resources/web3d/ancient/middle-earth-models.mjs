import * as T from '../vendor/three/three.module.js';

export const MIDDLE_EARTH_INFANTRY_SCALE=.78;

const colors={
  gondor:[0x21394c,0xc5cdd3],rohan:[0x415637,0xa3824f],orc:[0x49372f,0x645347],
  uruk:[0x272326,0x54515b],dunland:[0x744735,0xd39e63],elf:[0x495e38,0xb6a667],
  dwarf:[0x713a32,0x9a9c95],lake:[0x5a4841,0xa79676],harad:[0x9b382b,0xb98c49],
  east:[0x4f303c,0xbf923f],corsair:[0x364349,0xa2835e],hobbit:[0x74583a,0xb69d64],
  gollum:[0x796e59,0x72694d],wizard:[0x7b7e7d,0xc5c1a7],dead:[0x377461,0xa6d8b9],
};
const mats=new Map();
function mat(color,ghost=false){
  const key=color+':'+ghost;
  if(!mats.has(key))mats.set(key,new T.MeshStandardMaterial({
    color,flatShading:true,roughness:.74,transparent:ghost,opacity:ghost?.73:1,
    depthWrite:!ghost,side:ghost?T.FrontSide:T.DoubleSide
  }));
  const material=mats.get(key);material.userData.atlasCell=0;
  return material;
}
export function buildMiddleEarthModel(root,unit,p,low,kit,{single=false}={}){
  const {box,oval,rod,part,joint,person,horse}=kit;
  const role=p.middleEarth,ghost=role==='dead';
  const [c,a]=colors[role]||[0x413930,0x927f66];
  const cloth=mat(c,ghost),trim=mat(a,ghost),dark=mat(0x272427,ghost),ivory=mat(0xd9cbb0,ghost);
  const cone=(g,m,pos,r,h,n=6)=>part(g,new T.ConeGeometry(r,h,n),m,pos);
  function loft(g,m,rings,sides=low?6:10){
    const vertices=[],uv=[],indices=[];
    for(const [y,rx,rz,x=0,z=0] of rings)for(let i=0;i<sides;i++){
      const angle=(i+.5)*Math.PI*2/sides;
      vertices.push(x+Math.sin(angle)*rx,y,z+Math.cos(angle)*rz);
      uv.push(i/sides,y/rings.at(-1)[0]);
    }
    for(let row=0;row<rings.length-1;row++)for(let i=0;i<sides;i++){
      const a=row*sides+i,b=row*sides+(i+1)%sides;
      indices.push(a,b,a+sides,b,b+sides,a+sides);
    }
    const geo=new T.BufferGeometry();
    geo.setAttribute('position',new T.Float32BufferAttribute(vertices,3));
    geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
    geo.setIndex(indices);geo.computeVertexNormals();
    return part(g,geo,m,[0,0,0]);
  }
  function figure(parent,pos,rider=false,scale=MIDDLE_EARTH_INFANTRY_SCALE){
    const role=unit.kind==='meWarg'?'orc':p.middleEarth;
    const [clothColor,trimColor]=colors[role]||[0x413930,0x927f66];
    const cloth=mat(clothColor,ghost),trim=mat(trimColor,ghost);
    const u=person(parent,unit.team,{...p,weapon:unit.kind==='meWarg'?'sword':p.weapon,armor:0,commander:false},pos,scale,{rider});
    const torso=u.getObjectByName('breath'), arm=u.getObjectByName('shield');
    const orc=role==='orc'||role==='uruk', heavy=role==='dwarf'||role==='troll'||role==='uruk';
    const elven=role==='elf', green=role==='rohan', plate=role==='gondor'||heavy||elven||ghost;
    const guard=unit.kind==='meGuard',rang=p.rangedWeapon;
    const kind=unit.kind,unhelmed=['meAragorn','meEowyn','meFrodo','meSam','meMerry','meGollum','meGandalf'].includes(kind);
    const hair=mat(kind==='meEowyn'||kind==='meMerry'?0xb29659:kind==='meGandalf'?0xe1dbcd:0x49352e);
    const hood=mat(kind==='meFrodo'?0x514a36:kind==='meSam'?0x876b48:0x67735b);
    const leather=mat(orc?0x362d24:0x504033,ghost);
    const skin=mat(role==='gollum'?0x887b65:orc?role==='uruk'?0x754834:0x81715a:ghost?0xa0c8af:0xc69a7a,ghost);
    const edge=role==='uruk'?dark:trim;
    const headWidth=heavy?.28:elven?.19:.22;
    for(const child of [...torso.children])if(child.isMesh){child.geometry.dispose();child.removeFromParent();}
    if(rang){
      const quiver=rod(torso,leather,[-.24,1.82,-.32],[-.44,2.53,-.30],.10);
      quiver.name='middle-earth-quiver';
      for(const dx of [-.056,.056])rod(torso,ivory,[-.44+dx,2.46,-.30],[-.50+dx,2.70,-.29],.018);
    }
    if(kind==='meGollum'){
      for(const mesh of [...arm.children])if(mesh.isMesh){mesh.geometry.dispose();mesh.removeFromParent();}
    }
    const torsoCloth=kind==='meGollum'?skin:cloth;
    loft(torso,torsoCloth,[[1.39,.30,.21],[1.83,.30,.22],[2.12,heavy?.42:.33,.26],[2.49,heavy?.46:.36,.23],[2.62,.20,.16]]);
    if(kind!=='meGollum')loft(torso,plate?trim:leather,[[1.82,.265,.215],[2.01,.31,.26],[2.34,heavy?.43:.335,.27],[2.51,.29,.22],[2.56,.16,.165]]);
    loft(torso,role==='gollum'?leather:cloth,[[1.27,heavy?.46:.36,.25],[1.50,.36,.24],[1.84,.29,.22]]);
    box(torso,leather,[0,1.85,0],[.63,.115,.51]);
    box(torso,edge,[0,1.86,.264],[.15,.12,.028]);
    if(role==='gondor'||green||elven||ghost||role==='wizard'||role==='hobbit'||kind==='meThorin'){
      // A folded wool or elven cloak flares around the calves behind the rig.
      loft(torso,role==='hobbit'?hood:cloth,[[1.04,.56,.07,0,-.38],[1.38,.48,.075,0,-.41],[1.92,.39,.07,0,-.31],[2.49,.31,.08,0,-.19]],7);
    }
    if(plate||green)for(const side of [-1,1]){
      oval(torso,trim,[side*(heavy?.41:.33),2.44,0],[heavy?.26:.19,.16,.27]);
      if(!low)for(let row=0;row<3;row++){
        const pauldron=box(torso,edge,[side*(.40+row*.04),2.39-row*.105,.02],[.22,.105,.42]);
        pauldron.rotation.z=-side*.31;
      }
      if(!low)for(let j=0;j<3;j++){
        const panel=box(torso,plate?trim:leather,[side*(.075+j*.105),1.58,.25-j*.017],[.10,.30-j*.024,.08]);
        panel.rotation.z=side*.15;
      }
    }
    if(role==='gondor'){
      rod(torso,ivory,[0,2.00,.27],[0,2.39,.271],.025);
      for(const x of [-1,1])for(const y of [2.16,2.27])rod(torso,ivory,[0,y,.28],[x*.16,y+.12,.255],.015);
    }
    if(role==='dwarf'){
      for(const y of [2.05,2.20,2.35])box(torso,cloth,[0,y,.265],[.43,.065,.043]);
    }
    if(elven){
      for(const x of [-1,1])for(const y of [2.11,2.27])
        rod(torso,cloth,[0,y,.277],[x*.24,y+.18,.230],.021);
    }
    if(role==='orc'){
      const plate=box(torso,dark,[.36,2.36,-.025],[.30,.23,.36]);
      plate.rotation.z=-.43;
      rod(torso,trim,[-.28,1.88,.235],[.28,2.44,.239],.040);
    }
    if(ghost){
      for(const x of [-1,1])for(const y of [2.11,2.23])
        rod(torso,ivory,[0,y,.278],[x*.21,y+.06,.242],.023);
    }
    if(green&&!low)for(let row=0;row<4;row++)for(let col=-2;col<=2;col++)
      oval(torso,trim,[col*.105,2.00+row*.11,.258-Math.abs(col)*.012],[.055,.07,.034]);
    const headZ=orc?.13:.025;
    loft(torso,skin,[[2.66,.09,.11,0,headZ],[2.73,headWidth*.75,.19,0,headZ+.04],
      [2.91,headWidth,.22,0,headZ],[3.06,headWidth*.94,.20,0,headZ],[3.13,.03,.04,0,headZ]]);
    oval(torso,skin,[0,2.90,headZ+.226],[.061,.078,.069]);
    if(!low||orc||ghost)for(const x of [-.088,.088]){
      oval(torso,dark,[x,2.958,headZ+.195],[.048,.022,.023]);
      if(orc)cone(torso,ivory,[x,2.79,headZ+.224],.027,.105,4);
    }
    if(role==='orc'||role==='gollum'){
      torso.rotation.x=.20;
      for(const side of [-1,1]){
        const ear=cone(torso,skin,[side*.22,2.94,headZ],.083,.25,4);
        ear.rotation.z=-side*1.13;
      }
      if(role==='orc')loft(torso,leather,[[2.95,.25,.21,0,headZ-.035],[3.16,.21,.19,0,headZ],[3.23,.04,.05,0,headZ]],7);
    }else if(unhelmed){
      if(kind==='meGandalf'){
        loft(torso,hair,[[2.08,.02,.037,0,.34],[2.48,.20,.13,0,.29],[2.78,.20,.087,0,.20]],8);
        loft(torso,cloth,[[3.02,.43,.37],[3.11,.44,.38],[3.14,.23,.22],[3.48,.16,.15,0,-.04],[3.73,.018,.022,0,-.19]],9);
      }else{
        loft(torso,hair,[[2.72,headWidth,.115,0,-.12],[3.01,headWidth*1.16,.24,0,-.037],[3.14,headWidth*.79,.18,0,-.025],[3.19,.035,.045]],8);
        if(kind==='meAragorn'||kind==='meEowyn')for(const x of [-.16,.16])
          rod(torso,hair,[x,2.99,-.11],[x*1.22,2.54,-.057],.075,.089);
        if(role==='hobbit')oval(torso,hood,[0,2.55,-.17],[.22,.17,.18]);
      }
    }else{
      const crown=guard?3.57:green?3.37:elven?3.51:role==='wizard'?3.72:3.30;
      const rim=heavy?.31:elven?.218:.256;
      loft(torso,trim,[[2.96,rim,.25,0,headZ],[3.085,rim*1.05,.255,0,headZ],
        [3.21,rim*.83,.198,0,headZ],[crown,.017,.023,0,headZ-.055]]);
      if(role==='wizard')loft(torso,cloth,[[3.01,.46,.42],[3.1,.44,.39],[3.13,.24,.23]]);
      if(role==='uruk')box(torso,dark,[0,2.972,headZ+.215],[.49,.10,.088]);
      if(role==='gondor'||green||elven||heavy)for(const side of [-1,1]){
        const cheek=box(torso,trim,[side*.195,2.885,headZ+.126],[.087,.245,.235]);
        cheek.rotation.z=side*(elven?.24:.15);
      }
      if(role==='gondor'||green)rod(torso,trim,[0,2.87,headZ+.255],[0,3.31,headZ+.165],.034);
      if(green)loft(torso,dark,[[3.10,.065,.22,0,-.28],[3.22,.082,.25,0,-.20],[3.48,.033,.09,0,-.055]],6);
      if(role==='dwarf'||role==='wizard'){
        const beard=mat(role==='wizard'?0xb1ad9f:unit.kind==='meThorin'?0x493a37:0x73513d);
        loft(torso,beard,[[2.14,.05,.071,0,.275],[2.48,.23,.11,0,.262],[2.79,.22,.081,0,.183]],8);
        if(!low)for(const x of [-.14,.14])rod(torso,trim,[x,2.38,.31],[x,2.48,.33],.043);
      }
    }
    if(!rider&&!rang&&role!=='gollum'){
      for(const child of [...arm.children])if(child.isMesh){child.geometry.dispose();child.removeFromParent();}
      const shield=joint(arm,'middle-earth-shield',[-.13,-.34,.46]);
      if(green||role==='lake'||role==='dunland'||ghost){
        part(shield,new T.CylinderGeometry(.51,.51,.095,low?8:14),trim,[0,0,0]).rotation.x=Math.PI/2;
        part(shield,new T.CylinderGeometry(.46,.46,.107,low?8:14),cloth,[0,0,0]).rotation.x=Math.PI/2;
        oval(shield,trim,[0,0,.065],[.127,.127,.087]);
        if(!low)for(const angle of [0,Math.PI/2,Math.PI,Math.PI*1.5])rod(shield,trim,
          [.19*Math.cos(angle),.19*Math.sin(angle),.056],[.40*Math.cos(angle),.40*Math.sin(angle),.056],.025);
      }else{
        const shape=new T.Shape();
        const corners=role==='uruk'?[[-.42,.80],[-.35,-.4],[-.11,-.7],[.34,-.54],[.40,.8],[.12,.53],[-.10,.54]]:
          role==='dwarf'?[[-.45,.54],[-.45,-.47],[0,-.72],[.45,-.47],[.45,.54],[.30,.7],[-.30,.7]]:
          [[-.37,.54],[-.34,-.32],[0,-.76],[.34,-.32],[.37,.54],[.23,.68],[-.23,.68]];
        corners.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));
        shape.closePath();
        part(shield,new T.ExtrudeGeometry(shape,{depth:.065,bevelEnabled:false}),edge,[0,0,-.035]);
        box(shield,cloth,[0,0,.037],[.46,.78,.03]);
        if(role==='uruk'){
          box(shield,ivory,[.025,-.005,.061],[.175,.23,.015]);
          for(const [x,y,h] of [[-.071,.155,.19],[-.008,.183,.23],[.054,.171,.21],[.117,.127,.16]])
            box(shield,ivory,[x,y,.063],[.043,h,.018]);
          box(shield,ivory,[-.10,-.01,.062],[.16,.055,.018]).rotation.z=-.51;
        }else{
          rod(shield,trim,[0,-.28,.06],[0,.35,.06],.025);
          if(role==='gondor')for(const side of [-1,1])for(let row=0;row<2;row++)
            rod(shield,trim,[0,-.03+row*.15,.064],[side*.20,.17+row*.15,.064],.020);
        }
      }
    }
    for(const child of u.children)if(child.name.startsWith('leg')){
      child.traverse(o=>{if(o.isMesh)o.material=role==='gollum'?skin:leather;});
      if(!rider&&(plate||green)){
        const greave=oval(child,trim,[0,-.71,.08],[.105,.34,.088]);
        greave.rotation.x=-.10;
      }
    }
    torso.traverse(o=>{
      if(!o.isMesh)return;
      if(o.parent.name==='upper-arm')o.material=role==='gollum'?skin:cloth;
      if(o.parent.name==='lower-arm')o.material=role==='gollum'?skin:leather;
      if(o.parent.name==='hand-grip')o.material=skin;
    });
    if(role==='dwarf')u.scale.set(scale*1.30,scale*.77,scale*1.2);
    if(elven)u.scale.set(scale*.84,scale*1.13,scale*.86);
    if(role==='uruk')u.scale.set(scale*1.15,scale*1.10,scale*1.13);
    if(role==='orc')u.scale.set(scale,scale*.91,scale);
    if(unit.kind==='meBolg')u.scale.set(scale*1.20,scale*1.10,scale*1.18);
    if(role==='hobbit')u.scale.setScalar(unit.kind==='meSam'?.53:.49);
    if(role==='gollum'){u.scale.setScalar(.45);u.rotation.x=.28;}
    if(ghost)u.traverse(o=>{if(o.isMesh&&!o.material.transparent)o.material=mat(0x7da591,true);});
    return u;
  }
  function quadruped(type){
    const spider=type==='spider',bear=type==='bear',wolf=type==='wolf';
    const body=joint(root,'beast-body',[0,0,0]),fur=mat(spider?0x211a28:bear?0x50342b:0x615044);
    const mane=mat(bear?0x6c4a38:0x49392c);
    oval(body,fur,[spider?-.55:-.15,1.15,0],[spider?.94:1.14,bear?.77:.52,bear?.63:.44]);
    if(!spider){
      oval(body,mane,[.46,1.43,0],[.80,bear?.71:.57,bear?.64:.42]);
      if(!low)for(const side of [-1,1])for(let i=0;i<5;i++){
        const tufts=cone(body,i%2?fur:mane,[.76-i*.22,1.49-i*.047,side*(.24+i*.035)],.22,.55,5);
        tufts.rotation.z=1.19;
      }
    }
    const head=joint(body,'me-beast-head',[.88,wolf?1.53:1.31,0]);
    oval(head,fur,[0,.10,0],[wolf?.52:.49,wolf?.35:.43,wolf?.31:.36]);
    const muzzle=oval(head,fur,[wolf?.51:.49,-.025,0],[wolf?.49:.33,wolf?.14:.19,wolf?.20:.25]);
    if(wolf)muzzle.rotation.z=-.13;
    if(wolf){
      oval(head,dark,[.90,-.082,0],[.12,.085,.146]);
      const jaw=joint(head,'me-jaw',[.16,-.16,0]);
      oval(jaw,mane,[.29,-.013,0],[.44,.12,.23]);
      for(const z of [-.13,.13])cone(jaw,ivory,[.52,.06,z],.032,.128,4);
      if(!low)for(const z of [-.17,.17])for(const x of [.25,.38])
        cone(jaw,ivory,[x,.055,z],.021,.087,4);
    }
    for(const z of [-.25,.25]){
      if(!spider){
        const ear=cone(head,fur,[-.17,.42,z*.88],wolf?.12:.13,wolf?.36:.28,5);
        ear.rotation.set(wolf?z*.95:0,0,wolf?.38:.12);
      }
      oval(head,spider?mat(0xae3033):wolf?mat(0xe4b374):trim,[.28,.23,z*.90],[.055,.037,.045]);
      const fang=cone(head,ivory,[.62,-.14,z*.56],.046,.22,4);fang.rotation.z=Math.PI;
    }
    const stations=spider?[-.78,-.30,.20,.66]:[-.72,.62];
    for(const [i,x] of stations.entries())for(const z of [-1,1]){
      const leg=joint(body,`beastleg:${x}:${z}`,[x,1,z*.31]);
      const knee=[spider?x*.62:0,spider?.33:-.43,z*(spider?.94:.09)];
      const end=[spider?x*.92:.12,-.91,z*(spider?1.30:.12)];
      rod(leg,fur,[0,0,0],knee,spider?.069:.15);rod(leg,fur,knee,end,spider?.052:.10);
      if(!spider){
        oval(leg,fur,[end[0]+.08,end[1]+.024,end[2]],[.21,.13,.155]);
        if(wolf&&i===1)oval(leg,mane,[.015,-.20,z*.04],[.23,.36,.22]);
      }
      leg.userData.gait=wolf?i*.76+(z>0?.28:0):i+(z>0?1:0);
    }
    if(!spider)rod(body,fur,[-.92,1.31,0],[-1.65,.90,0],.13,.035);
    if(wolf&&unit.kind==='meWarg'){
      box(body,mat(0x413328),[-.14,1.65,0],[.86,.15,.73]);
      figure(body,[-.14,.97,0],true,.58).rotation.z=.18;
    }
  }
  function flyer(){
    const eagle=role==='eagle',color=mat(eagle?0x795037:0x332a36),membrane=mat(eagle?0xb99b66:0x4e3c4c);
    oval(root,color,[0,1.34,0],[1.0,.51,.41]);
    rod(root,color,[.59,1.46,0],[1.10,2.05,0],.19,.27);
    if(!eagle){
      rod(root,color,[1.10,2.05,0],[1.64,1.88,0],.143,.19);
      oval(root,color,[1.79,1.84,0],[.34,.19,.20]);
      for(const s of [-1,1])cone(root,ivory,[1.98,1.67,s*.14],.038,.19,5).rotation.z=Math.PI;
      rod(root,color,[-1.25,1.10,0],[-2.45,.87,.30],.087,.023);
    }
    if(eagle)oval(root,ivory,[1.19,2.07,0],[.34,.24,.25]);
    if(eagle)cone(root,trim,[1.51,2.02,0],.17,.37,4).rotation.z=-Math.PI/2;
    rod(root,color,[-.64,1.31,0],[-1.62,1.02,0],.11,.02);
    for(const side of [-1,1]){
      const wing=joint(root,'me-wing',[0,1.58,side*.30]);
      wing.userData.side=side;
      const vertices=[.58,0,0,.21,.22,side*1.2,-.73,-.03,side*1.2,-.65,0,0];
      const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(vertices,3));
      geo.setAttribute('uv',new T.Float32BufferAttribute([0,0,0,1,1,1,1,0],2));
      geo.setIndex([0,1,2,0,2,3]);geo.computeVertexNormals();part(wing,geo,membrane,[0,0,0]);
      rod(wing,color,[.58,0,0],[.21,.22,side*1.2],.09);
      const tip=joint(wing,'me-wing-tip',[.21,.22,side*1.20]);
      tip.userData.side=side;
      rod(tip,color,[0,0,0],[-.77,-.03,side*1.08],.072,.023);
      if(!eagle){
        const web=new T.BufferGeometry();
        const verts=[0,0,0,-.77,-.03,side*1.08,-.91,-.08,side*.67,-1.07,-.19,side*.37,-.94,-.25,0];
        web.setAttribute('position',new T.Float32BufferAttribute(verts,3));
        web.setAttribute('uv',new T.Float32BufferAttribute([0,0,1,1,1,.62,1,.35,1,0],2));
        web.setIndex([0,1,2,0,2,3,0,3,4]);
        web.computeVertexNormals();
        part(tip,web,membrane,[0,0,0]);
        for(const [x,y,z] of [[-.91,-.08,.67],[-1.07,-.19,.37],[-.94,-.25,0]])
          rod(tip,color,[0,0,0],[x,y,side*z],.045,.015);
      }else for(let i=0;i<6;i++){
        const span=.11+i*.16;
        rod(tip,membrane,[-span*.60,-.04,side*span],[-.97+i*.04,-.11,side*(span+.18)],.105,.035);
      }
    }
    if(!eagle){
      const rider=joint(root,'rider',[-.23,1.70,0]);
      rider.rotation.y=Math.PI/2;
      loft(rider,dark,[[.03,.53,.31],[.61,.37,.29],[1.08,.27,.22],[1.28,.16,.14]]);
      loft(rider,dark,[[1.03,.24,.24],[1.39,.18,.18],[1.61,.025,.04]],7);
      for(const x of [-.24,.24])rod(rider,dark,[x,1.03,0],[x,.60,.35],.073,.104);
      if(unit.kind==='meWitchKing')for(const x of [-.17,0,.17])cone(rider,trim,[x,1.57,.065],.046,.34,4);
    }
  }
  if(['wolf','bear','spider'].includes(role)){quadruped(role);return;}
  if(role==='eagle'||role==='nazgul'){flyer();return;}
  if(role==='mumak'){
    const body=joint(root,'beast-body',[0,0,0]),hide=mat(0x756b64);
    oval(body,hide,[0,1.63,0],[1.52,1.03,.79]);oval(body,hide,[1.07,1.88,0],[.64,.69,.56]);
    for(const x of [-.84,.85])for(const z of [-.50,.50]){
      const leg=joint(body,`beastleg:${x}:${z}`,[x,1.21,z]);
      rod(leg,hide,[0,0,0],[0,-1.11,0],.23,.30);
    }
    const trunk=joint(body,'me-beast-head',[1.49,1.76,0]);
    rod(trunk,hide,[0,0,0],[.28,-.79,0],.18,.25);
    rod(trunk,hide,[.28,-.79,0],[.64,-1.04,0],.11,.18);
    for(const side of [-1,1]){
      oval(body,hide,[.93,1.97,side*.59],[.19,.65,.48]).rotation.x=side*.34;
      for(const [y,z] of [[1.64,.39],[1.88,.57]]){
        const a=[1.36,y,z*side],b=[2.10,y-.37,(z+.24)*side],c=[2.56,y-.20,(z+.44)*side];
        rod(body,ivory,a,b,.086,.135);rod(body,ivory,b,c,.021,.086);
      }
      rod(body,trim,[-1,2.42,side*.59],[-.85,1.17,side*.74],.042);
    }
    box(body,mat(0xa43d2a),[-.15,2.43,0],[1.94,.16,1.65]);
    box(body,trim,[-.15,2.68,0],[1.45,.31,1.08]);
    for(const x of [-.79,.49])for(const z of [-.47,.47])rod(body,trim,[x,2.46,z],[x,3.43,z],.072);
    box(body,mat(0x594133),[-.15,3.34,0],[1.53,.14,1.21]);
    for(const z of [-.57,.57]){
      rod(body,trim,[-.85,3.09,z],[.61,3.09,z],.054);
      for(const x of [-.55,-.10,.34])rod(body,dark,[x,2.59,z],[x,3.10,z],.042);
    }
    if(!low)for(const x of [-.43,.20]){
      oval(body,mat(0x9b382b),[x,2.99,.05],[.135,.26,.16]);
      oval(body,mat(0xad7756),[x,3.24,.06],[.10,.12,.10]);
    }
    return;
  }
  if(role==='ship'){
    const hull=oval(root,dark,[0,.32,0],[2.26,.49,.67]);hull.rotation.z=.04;
    box(root,trim,[0,.72,0],[3.56,.14,1.06]);rod(root,trim,[.22,.64,0],[.22,3.12,0],.073);
    for(const side of [-1,1]){
      oval(root,cloth,[-.22,2.22,side*.52],[.16,.77,.63]).rotation.y=side*.19;
      for(const x of [-1.22,-.51,.20,.91,1.62])rod(root,trim,[x,.72,side*.60],[x-.33,.98,side*.76],.039);
    }
    rod(root,trim,[.22,3.12,-1.26],[.22,3.12,1.26],.044);
    for(const x of [-1.85,1.81])rod(root,trim,[x,.65,0],[x*1.10,1.27,0],.065);
    return;
  }
  if(role==='blast'||role==='grond'){
    for(const x of [-.81,.81])for(const z of [-.71,.71]){
      const wheel=joint(root,'wheel',[x,.39,z]);part(wheel,new T.TorusGeometry(.35,.085,6,10),dark,[0,0,0]);
    }
    box(root,trim,[0,.72,0],[2.51,.2,1.54]);
    if(role==='blast')for(const x of [-.65,0,.65])oval(root,dark,[x,1.04,0],[.33,.44,.42]);
    else{
      const ram=joint(root,'ram-head',[0,1.14,0]);rod(ram,dark,[-1.18,0,0],[1.35,0,0],.19);
      oval(ram,dark,[1.49,0,0],[.49,.32,.27]);
      for(const z of [-.24,.24])cone(ram,ivory,[1.68,-.25,z],.07,.26,4).rotation.z=Math.PI;
      for(const x of [-.88,.88])for(const z of [-.65,.65])rod(root,trim,[x,.77,z],[x,2.11,z],.07);
      box(root,dark,[0,2.14,0],[2.62,.16,1.47]);
    }
    return;
  }
  if(role==='troll'){const troll=figure(root,[0,0,0],false,1.27);troll.scale.x*=1.39;troll.scale.z*=1.28;return;}
  if(p.family==='cavalry'){
    const mount=horse(root,0,unit.kind==='meAragorn'?0:role==='rohan'?1:2);
    box(mount,cloth,[-.21,1.69,0],[1.12,.12,.80]);
    for(const z of [-.35,.35]){
      const clothFlap=box(mount,cloth,[-.20,1.49,z],[.87,.48,.065]);
      clothFlap.rotation.x=z*.42;
      rod(mount,trim,[-.63,1.32,z*1.1],[.18,1.32,z*1.1],.028);
      rod(mount,dark,[1.38,2.10,z*.53],[-.04,2.24,z*.72],.016);
    }
    if(role==='gondor'&&unit.kind!=='meAragorn'){
      oval(mount,trim,[.68,1.72,0],[.33,.53,.31]);
      oval(mount,trim,[1.13,2.40,0],[.225,.15,.22]);
    }
    figure(root,[.59,1.05,0],true,.64);
    return;
  }
  if(p.story||single)figure(root,[0,0,0]);
  else for(const pos of [[-.62,0,-.50],[.62,0,-.50],[0,0,.64]])figure(root,pos);
}
