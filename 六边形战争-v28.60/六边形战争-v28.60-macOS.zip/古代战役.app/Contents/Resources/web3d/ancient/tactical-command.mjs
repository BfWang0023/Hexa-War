import {orderLocked,committedTask,executeCommitted,LOCK_REASON} from './order-lock.mjs';
import {captureOptions,captureGoal} from './fortification-capture.mjs';
import {chargeClass,chargeText,interruptCharge} from './charge-rules.mjs';
import {knownMap} from './fog-policy.mjs';
import {commandSnapshot} from './command-snapshot.mjs';
import {iterateFlankRally} from './flank-rally.mjs';
// AI Order Officer execution API. Explicit player/AI intent only; engine owns legality and costs.
import {move,attack,attackPreview,chargeOpportunities,reachable,mobileAt,fortAt,distance,inBounds,setPhalanxMode,destroyBridge,isFormableInfantry,isShip,isRouted,visibleTo,turnPhalanx} from './engine.mjs';
import {axial,offset,selectable} from './group-command.mjs';
import {validateTacticalCommand} from './tactical-schema.mjs';
import {commandFrame,directionIndex,translate,resolveUnits,world} from './tactical-units.mjs';
import {iterateFormationPlan} from './formation-doctrine.mjs';
import {resolveLocation} from './tactical-location.mjs';
import {expandTacticalTemplates} from './tactical-templates.mjs';
import {planLogistics,executeConvoyRefill} from './logistics-command.mjs';
import {roadField,roadProgress,legalRoadPath} from './tactical-road.mjs';
import {centroid,hexFromPlane} from './battlefield-space.mjs';
const now=()=>performance.now();
export function createTacticalCommandAPI({getState,canAct=()=>true,onAction=()=>{},onChange=()=>{},pace=true,clock=now,sleep=ms=>new Promise(r=>setTimeout(r,ms)),rng=Math.random}={}){
 const jobs=new Map(),records=new Set(),recent=[];let running=false,serial=0;
 const stateValid=j=>getState()===j.state&&j.state.map===j.authorityMap&&j.state.turn===j.turn&&j.state.side===j.team&&!j.state.over&&!j.state.deploying&&canAct(j.team);
 function updateRecord(record){for(const g of record.groups||[]){const rs=record.results.filter(r=>r.group===g.id);g.pending=g.ids.length-rs.length;g.status=!g.ids.length?(g.after.length?(g.after.every(id=>record.groups.find(x=>x.id===id)?.status==='completed')?'completed':'accepted'):g.status==='failed'?'failed':'completed'):g.pending?(g.started?'executing':'accepted'):rs.every(r=>r.status==='completed')?'completed':rs.some(r=>r.status==='cancelled')?'cancelled':rs.some(r=>r.status==='partial'||r.actions)?'partial':'failed';}record.stage=record.results.length===record.total?(record.results.every(r=>r.status==='completed')?'completed':'finished'):record.firstActionMs!==null?'executing':'accepted';record.completed=record.results.filter(r=>r.status==='completed').length;record.partial=record.results.filter(r=>r.status==='partial').length;record.failed=record.results.filter(r=>r.status==='failed').length;record.cancelled=record.results.filter(r=>r.status==='cancelled').length;record.pending=record.total-record.results.length;onChange(record);if(!record.pending&&!record.finished){record.finished=true;record.timeline.push({stage:record.stage,at:clock()});record.elapsedMs=clock()-record.submittedAt;record.resolve(record);records.delete(record);}}
 function finish(j,status,reason=''){if(jobs.get(j.key)!==j)return;jobs.delete(j.key);j.record.results.push({id:j.id,status,reason,actions:j.actions,moves:j.moves,attacks:j.attacks,forms:j.forms,group:j.group.id,position:{c:j.map.units.find(u=>u.id===j.id)?.c,r:j.map.units.find(u=>u.id===j.id)?.r},note:j.note||''});updateRecord(j.record);}
 function cancel(ids=null,mode='all'){
  const set=ids?new Set(ids):null;let count=0;
  for(const j of [...jobs.values()])if((!set||set.has(j.id))&&!committedTask(j.state,j.id)){
   if(mode==='all'&&j.index>=j.steps.length){finish(j,'completed');continue;}if(mode==='all'){if(j.moves)interruptCharge(j.state,j.id);finish(j,'cancelled','尚未执行的命令已取消；已完成行动不回滚');count++;}
   else {const current=j.steps[j.index];j.steps=j.steps.filter((s,i)=>i<j.index||(mode==='attack'?s.type!=='attack':!['move','deploy','logistics','rally','capture'].includes(s.type)));if(mode==='move')for(const s of j.steps)if(s.type==='attack')s.advance=false;if(j.steps[j.index]!==current){j.goal=null;j.stepAttacks=0;}count++;if(j.index>=j.steps.length)finish(j,'cancelled',mode==='attack'?'停止攻击':'停止移动');}
  }return count;
 }
 function action(j,type,result,from){j.actions++;j.group.started=true;j.record.engineMs+=clock()-j.engineStart;if(j.record.firstActionMs===null){j.record.firstActionMs=clock()-j.record.submittedAt;j.record.timeline.push({stage:'executed',at:clock()});}const u=j.map.units.find(u=>u.id===j.id);onAction({type,id:j.id,from,to:u?{c:u.c,r:u.r,path:result.path}:null,result},j.record);j.ready=clock()+(pace?(type==='move'?(result.path?.length||1)*340:type==='attack'?700:20):0);updateRecord(j.record);}
 function moveToward(j,u,goal,alongRoad=false){
  if(!inBounds(j.map,goal.c,goal.r))return {ok:false,reason:'目标区域超出地图'};
  const field=alongRoad?(j.road?.goal.c===goal.c&&j.road?.goal.r===goal.r?j.road:(j.road=roadField(j.state,goal,j.team))):null;
  const metric=p=>field?roadProgress(field,p):distance(p,goal),before=metric(u),options=[...reachable(j.state,u).values()];
  const candidates=options.filter(p=>(p.c!==u.c||p.r!==u.r)&&!mobileAt(j.map,p.c,p.r)&&!p.path.some(c=>{const o=mobileAt(j.map,c.c,c.r);return o&&o.id!==u.id;})&&(!alongRoad||legalRoadPath(j.state,p.path,goal))&&metric(p)<before);
  candidates.sort((a,b)=>metric(a)-metric(b)||a.cost-b.cost||a.steps-b.steps||a.r-b.r||a.c-b.c);
  const to=candidates[0];if(!to)return {ok:false,reason:u.actionsLeft<=0?'行动力不足':alongRoad?'没有符合沿道路约束的合法路径':'目标区域不可达或路径被占据'};
  const from={c:u.c,r:u.r};j.engineStart=clock();const result=move(j.state,u.id,to.c,to.r);if(result.ok){j.moves++;action(j,'move',result,from);}return result;
 }
 function tick(j){return j.record.actor==='delegate'?executeCommitted(j.state,j.id,()=>tickActual(j)):tickActual(j);}
 function tickActual(j){
 if(orderLocked(j.state,j.id)){finish(j,'failed',LOCK_REASON);return;}
  if(!stateValid(j)){finish(j,'cancelled','战场、回合或操控权已变化');return;}
  const u=j.map.units.find(u=>u.id===j.id);if(!selectable(u,j.team)){finish(j,j.actions?'partial':'failed','部队已阵亡、溃逃或无法控制');return;}
  const dependencies=j.group.after.map(id=>j.record.groups.find(g=>g.id===id));if(dependencies.some(g=>g.pending>0)){j.ready=clock()+8;return;}if(dependencies.some(g=>g.status!=='completed')){finish(j,'failed','前置任务未完整完成，未执行依赖动作');return;}
  const step=j.steps[j.index];if(!step){finish(j,'completed');return;}
  const done=()=>{j.index++;j.goal=null;j.road=null;j.stepAttacks=0;j.phase=null;j.group.progress.set(j.id,j.index);if(j.index>=j.steps.length&&(!pace||j.ready<=clock()))finish(j,'completed');};
  const fail=reason=>finish(j,j.actions?'partial':'failed',reason);
  const requiresPlan=step.type==='deploy'||step.type==='rally'||step.type==='logistics'||step.type==='move'&&(step.anchor||step.position);
  if(requiresPlan&&[...j.group.progress].some(([id,index])=>index<j.index&&[...jobs.values()].some(x=>x.id===id&&x.group===j.group))){j.ready=clock()+8;return;}
  if(step.type==='deploy'||step.type==='rally'||step.type==='logistics'){
   let plan=j.group.plans.get(j.index);if(!plan){
    const actors=j.group.ids.map(id=>j.map.units.find(u=>u.id===id)).filter(u=>selectable(u,j.team)&&[...jobs.values()].some(x=>x.id===u.id&&x.group===j.group));
    try{plan=step.type==='deploy'?{iterator:iterateFormationPlan(j.state,actors,step,j.context),cpuMs:0}:step.type==='rally'?{iterator:iterateFlankRally(j.state,actors,step,j.context),cpuMs:0}:planLogistics(j.state,actors,step,j.context);j.group.plans.set(j.index,plan);if(!plan.iterator){j.record.plans.push({group:j.group.id,step:j.index,...plan});}}
    catch(e){plan={error:e.message};j.group.plans.set(j.index,plan);}
   }
   if(plan.iterator){const begin=clock();try{let next,n=0;do{next=plan.iterator.next();}while(!next.done&&++n<8&&clock()-begin<3);plan.cpuMs+=clock()-begin;if(!next.done){j.ready=clock()+1;return;}const cpuMs=plan.cpuMs;plan={...next.value,cpuMs};j.group.plans.set(j.index,plan);j.record.plans.push({group:j.group.id,step:j.index,...plan});j.record.planningMs+=cpuMs;}catch(e){plan={error:e.message};j.group.plans.set(j.index,plan);}}
   if(plan.error){fail(plan.error);return;}const entry=plan.assignments.find(p=>p.id===j.id);if(!entry||entry.reason||!entry.to){fail(entry?.reason||'没有合法分配阵位');return;}j.note=plan.note||`${plan.label} · ${plan.reference}${entry.changedFormation?' · 避让地形调整阵位':''}`;
   if(step.type==='logistics'&&(step.mode==='refill'||step.mode==='connect')&&!j.phase){
    const depot=entry.refill;if(!depot){fail('仓库阵位不可用');return;}if(distance(u,depot)>0){const r=moveToward(j,u,depot);if(!r.ok){fail(r.reason);return;}return;}
    // Full loads need no payment. Empty/partial loads call only the original paid refill action.
    if((u.supplyStock||0)*5+(u.supplyCredit||0)<120){j.engineStart=clock();const r=executeConvoyRefill(j.state,u.id);if(!r.ok){fail(r.reason);return;}action(j,'resupply',r,{c:u.c,r:u.r});}
    j.phase='loaded';if(step.mode==='refill'){done();return;}
   }
   if(distance(u,entry.to)>0){const r=moveToward(j,u,entry.to,!!step.alongRoad);if(r.ok){j.blocked=0;return;}if(u.actionsLeft>0&&jobs.size>1&&++j.blocked<=3){j.ready=clock()+16;return;}fail(r.reason);return;}
   if(step.type==='deploy'&&plan.stance&&!isFormableInfantry(u)){fail('几何阵位已处理，但该兵种没有原生列阵姿态能力');return;}
   if(step.type==='deploy'&&plan.stance&&isFormableInfantry(u)&&(!u.formed||u.facing!==plan.heading)){j.engineStart=clock();const r=u.formed?turnPhalanx(j.state,u.id,plan.heading):setPhalanxMode(j.state,u.id,true,plan.heading);if(!r.ok){fail(r.reason);return;}j.forms++;action(j,'form',r,{c:u.c,r:u.r});}
   done();return;
  }
  if(step.type==='hold'){interruptCharge(j.state,u.id);done();return;}
  if(step.type==='stop'){done();return;}
  if(step.type==='form'||step.type==='defend'){
   const formed=step.type==='defend'?true:step.formed;if(!isFormableInfantry(u)){if(step.type==='defend'||!formed){done();return;}fail('该兵种不支持列阵');return;}
   if(u.formed===formed){if(formed&&step.direction!==undefined&&u.facing!==directionIndex(step.direction,j.context.frame)){j.engineStart=clock();const result=turnPhalanx(j.state,u.id,directionIndex(step.direction,j.context.frame));if(!result.ok){fail(result.reason);return;}j.forms++;action(j,'form',result,{c:u.c,r:u.r});}done();return;}
   j.engineStart=clock();const result=setPhalanxMode(j.state,u.id,formed,formed?directionIndex(step.direction||'forward',j.context.frame):undefined);
   if(!result.ok){fail(result.reason);return;}j.forms++;action(j,'form',result,{c:u.c,r:u.r});done();return;
  }
  if(step.type==='move'){
   if(!j.goal){if(step.anchor||step.position){let location=j.group.plans.get(j.index);if(!location){const actors=j.group.ids.map(id=>j.map.units.find(u=>u.id===id)).filter(Boolean);location=step.anchor?resolveLocation(j.state,step.anchor,j.context,actors):{position:step.position,description:'指定坐标'};const center=hexFromPlane(centroid(actors)),origin=actors.reduce((a,b)=>distance(a,center)<=distance(b,center)?a:b),a=axial(origin);location.relativeById=Object.fromEntries(actors.map(u=>{const p=axial(u);return [u.id,{q:p.q-a.q,r:p.r-a.r}]}));j.group.plans.set(j.index,location);j.record.plans.push({group:j.group.id,step:j.index,reference:location.description,anchor:location.position});}const t=axial(location.position),relative=location.relativeById[j.id]||j.relative;j.goal=offset({q:t.q+relative.q,r:t.r+relative.r});}else j.goal=translate(u,directionIndex(step.direction,j.context.frame),step.distance);}
   if(distance(u,j.goal)===0){done();return;}
   const r=moveToward(j,u,j.goal,!!step.alongRoad);if(r.ok){j.blocked=0;if(distance(u,j.goal)===0){done();if(j.steps[j.index]?.type==='attack'&&j.steps[j.index].charge&&jobs.get(j.key)===j)tick(j);}return;}
   // Another commanded unit may vacate a cell later in this pass.
   if(u.actionsLeft>0&&jobs.size>1&&++j.blocked<=2){j.ready=clock()+16;return;}fail(r.reason);return;
  }
  if(step.type==='attack'){
   if(step.charge&&!chargeClass(j.map,u,j.state.rulesVersion)){fail('该兵种没有近战冲锋能力');return;}
   const targets=step.targetIds.map(id=>j.map.units.find(u=>u.id===id)).filter(e=>e&&e.hp>0&&!e.aboard&&e.team!==j.team&&visibleTo(j.state,j.team,e.c,e.r));
   if(!targets.length){if(j.stepAttacks)done();else fail('指定目标已不在视野内、已阵亡或不存在');return;}
   targets.sort((a,b)=>(step.focus?step.targetIds.indexOf(a.id)-step.targetIds.indexOf(b.id):distance(u,a)-distance(u,b))||a.id.localeCompare(b.id));
   const legal=targets.find(e=>!fortAt(j.map,e.c,e.r)&&(()=>{const p=attackPreview(j.state,u,e.c,e.r);return p&&p.target.kind!=='fort'&&(!step.fireOnly||!p.melee)&&(!step.charge||p.melee)})());
   if(legal){j.engineStart=clock();const r=attack(j.state,u.id,legal.c,legal.r,rng(),rng(),rng(),j.state.rulesVersion>=17?rng():null);if(!r.ok){fail(r.reason);return;}j.attacks++;j.stepAttacks++;if(step.charge)j.note=chargeText(r.visual?.chargeBonus||{triggered:false,reason:'未满足条件'});action(j,'attack',r,{c:u.c,r:u.r});if(!step.repeat||j.actions>=32)done();return;}
   if(u.actionsLeft<=0){if(j.stepAttacks)done();else fail('行动力不足，尚未完成攻击');return;}
   if(targets.every(e=>fortAt(j.map,e.c,e.r))){fail('目标受城墙保护；普通批量攻击不损伤工事，请明确破坏城墙');return;}
   if(j.stepAttacks||!step.advance){if(j.stepAttacks)done();else fail('没有合法射程内的指定目标；未擅自移动');return;}
   if(step.charge){const option=chargeOpportunities(j.state,u,targets).find(o=>!fortAt(j.map,o.target.c,o.target.r));if(option){const from={c:u.c,r:u.r},to=option.destination;j.engineStart=clock();const result=move(j.state,u.id,to.c,to.r);if(!result.ok){fail(result.reason);return;}j.moves++;action(j,'move',result,from);if(jobs.get(j.key)===j)tick(j);return;}}
   const r=moveToward(j,u,targets[0]);if(!r.ok)fail(r.reason);return;
  }
  if(step.type==='capture'){
   const options=captureOptions(j.state,u);let target=j.captureTarget;
   if(!target){const choices=options.filter(t=>(step.kind==='any'||t.kind===step.kind)&&(step.name===undefined||t.name===step.name)&&(!step.position||t.fortIds.some(id=>{const f=j.map.units.find(f=>f.id===id);return f?.c===step.position.c&&f?.r===step.position.r;})||t.area.some(p=>p.c===step.position.c&&p.r===step.position.r)));
    if(!choices.length&&step.kind==='fortress'){const fallback=options.filter(t=>t.kind==='segment'&&t.name!=='独立墙段'&&(step.name===undefined||t.name===step.name)&&(!step.position||t.target.c===step.position.c&&t.target.r===step.position.r));if(new Set(fallback.map(t=>t.name)).size===1){fallback.sort((a,b)=>distance(u,a.target)-distance(u,b.target)||a.id.localeCompare(b.id));if(fallback[0])choices.push(fallback[0]);}}
    if(choices.length!==1){fail(choices.length?'发现多个已知工事目标，请指定名称或坐标':'未找到明确的已发现工事目标');return;}target=j.captureTarget=choices[0];
   }
   const walls=j.map.units.filter(f=>target.fortIds.includes(f.id));if(walls.some(f=>f.hp>0)&&walls.filter(f=>f.hp>0).every(f=>f.team===u.team)){j.captureTarget=null;done();return;}
   const current=options.find(t=>t.id===target.id);if(!current){fail('目标情报已变化，请重新下令');return;}
   if(current.inContact){fail('本次接触未取得控制；不查询隐藏守军，也不额外支付接管行动');return;}
   const goal=captureGoal(j.state,u,current);if(!goal){fail('没有已知合法接触位置');return;}const r=moveToward(j,u,goal);if(!r.ok){fail(r.reason);return;}
   if(r.captures?.includes(target.id)){j.note='合法抵近后立即夺取，无额外占领行动消耗';j.captureTarget=null;done();}return;
  }
  if(step.type==='demolish'){
   const p=step.position;if(!inBounds(j.map,p.c,p.r)||!visibleTo(j.state,j.team,p.c,p.r)){fail('结构目标不在当前视野内');return;}
   let r;j.engineStart=clock();if(step.structure==='bridge')r=destroyBridge(j.state,u.id,p.c,p.r);else {const fort=fortAt(j.map,p.c,p.r),preview=attackPreview(j.state,u,p.c,p.r);r=fort&&fort.team!==j.team&&preview?.target.kind==='fort'?attack(j.state,u.id,p.c,p.r,rng(),rng(),rng()):{ok:false,reason:'请选择能明确攻击该城墙的器械或空墙目标'};}
   if(!r.ok){fail(r.reason||'无法破坏结构');return;}action(j,'demolish',r,{c:u.c,r:u.r});done();return;
  }
 }
 async function pump(){if(running)return;running=true;try{while(jobs.size){let n=0;const begin=clock();for(const j of [...jobs.values()]){if(j.ready>clock())continue;try{tick(j);}catch(e){finish(j,j.actions?'partial':'failed','执行接口拒绝动作：'+e.message);}if(++n>=4||clock()-begin>=7)break;}await sleep(pace?8:0);}}finally{running=false;}}
 function submit(raw,{team,selectedIds=[],frame,actor='human',snapshot}={}){
  const started=clock(),command=validateTacticalCommand(expandTacticalTemplates(validateTacticalCommand(raw))),state=getState();if(command.clarification||command.confidence<.85)throw Error(command.clarification||'请明确命令');
  if(snapshot&&snapshot!==commandSnapshot(state))throw Error('命令快照已过期，请重新下令');
  if(!state||state.side!==team||state.over||state.deploying||!canAct(team))throw Error('现在不是可指挥的本方战斗回合');
  const context={team,selectedIds:[...new Set(selectedIds)],frame:frame||commandFrame(state,team),recentOrders:recent},prepared=[],assigned=new Set(),groupErrors=[],groups=[];
  for(const [oi,order] of command.orders.entries()){let generated='group'+(oi+1);while(command.orders.some(o=>o.id===generated)||groups.some(g=>g.id===generated))generated+='_';const group={id:order.id||generated,after:order.after||[],ids:[],pending:0,status:'accepted',started:false,progress:new Map(),plans:new Map()};groups.push(group);const units=resolveUnits(state,order.select,context).filter(u=>!order.select.exceptPrior||!assigned.has(u.id));if(!units.length){group.status='failed';groupErrors.push(order.select.scope==='selected'?'未找到符合条件的已选部队，请先选择部队或直接写明兵种':'未找到符合条件的部队');continue;}
   const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
   const equivalent=(a,b)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
   const duplicate=new Set();
   for(const u of units){const previous=prepared.filter(p=>p.u.id===u.id);for(const p of previous){
    if(equivalent(p.rawSteps,order.steps)&&equivalent(p.rawAfter,order.after||[])){duplicate.add(u.id);group.after=[...new Set([...group.after,p.group.id])];continue;}
    const follows=(id,seen=new Set())=>{if(id===p.group.id)return true;if(seen.has(id))return false;seen.add(id);return groups.find(g=>g.id===id)?.after.some(n=>follows(n,seen));};
    if(!group.after.some(id=>follows(id)))throw Error(`同一部队收到互相重叠的指令（${u.id}）：同期动作或目标不同，请明确先后或例外`);
   }assigned.add(u.id);}
   for(let i=units.length-1;i>=0;i--)if(duplicate.has(units[i].id))units.splice(i,1);
   group.ids=units.map(u=>u.id);group.pending=units.length;group.progress=new Map(group.ids.map(id=>[id,0]));if(!units.length)continue;
   const coords=units.map(axial),center=coords.reduce((a,p)=>({q:a.q+p.q/units.length,r:a.r+p.r/units.length}),{q:0,r:0});const anchor=units.reduce((a,b)=>{const score=u=>{const p=axial(u);return (p.q-center.q)**2+(p.r-center.r)**2};return score(b)<score(a)?b:a;}),origin=axial(anchor);
   const steps=structuredClone(order.steps);for(const step of steps)if(step.type==='attack'){const targets=resolveUnits(state,step.target,context,{enemy:true});const middle={c:anchor.c,r:anchor.r};targets.sort((a,b)=>distance(middle,a)-distance(middle,b)||a.id.localeCompare(b.id));step.targetIds=targets.map(u=>u.id);}
   const first=steps.find(s=>s.type==='move'),dir=first?.direction?directionIndex(first.direction,context.frame):null;
   // Leading units vacate first. This is formation execution, not a new tactical objective.
   units.sort((a,b)=>{const goal=dir!==null?translate(anchor,dir,1):first?.position;if(!goal)return a.id.localeCompare(b.id);const f=world(goal),o=world(anchor),pa=world(a),pb=world(b);return (pb.x-pa.x)*(f.x-o.x)+(pb.z-pa.z)*(f.z-o.z)||a.id.localeCompare(b.id);});
   for(const u of units){const p=axial(u);prepared.push({u,group,rawSteps:order.steps,rawAfter:order.after||[],relative:{q:p.q-origin.q,r:p.r-origin.r},steps:structuredClone(steps)});}
  }
  if(actor!=='delegate'&&prepared.some(p=>committedTask(state,p.u.id)))throw Error(LOCK_REASON);
  if(!prepared.length)throw Error(groupErrors[0]||'未找到可执行部队');
  const record={rulesVersion:state.rulesVersion??10,elevationRules:structuredClone(state.elevationRules),chargeRules:structuredClone(state.chargeRules),id:++serial,actor,team,ids:[...new Set(prepared.map(p=>p.u.id))],total:prepared.length,groups,plans:[],planningMs:0,timeline:[{stage:'accepted',at:clock()}],stage:'accepted',command:structuredClone(command),groupErrors,results:[],completed:0,failed:0,partial:0,cancelled:0,pending:prepared.length,finished:false,submittedAt:started,validationMs:clock()-started,firstActionMs:null,engineMs:0,elapsedMs:null};record.promise=new Promise(r=>record.resolve=r);records.add(record);
  for(const id of record.ids){const p=prepared.find(p=>p.u.id===id),stop=p.steps.find(s=>s.type==='stop');if(stop)interruptCharge(state,id);cancel([id],stop?.mode||'all');}
  for(const {u,group,relative,steps} of prepared){const onlyStop=steps.every(s=>s.type==='stop');if(onlyStop){record.results.push({id:u.id,group:group.id,status:'completed',reason:'停止尚未执行的指定动作',actions:0,moves:0,attacks:0,forms:0});continue;}
   const jobKey=record.id+':'+group.id+':'+u.id;
   jobs.set(jobKey,{key:jobKey,id:u.id,group,state,authorityMap:state.map,get map(){return knownMap(state,team)},turn:state.turn,team,context,relative,steps:steps.filter(s=>s.type!=='stop'),index:0,goal:null,ready:clock(),record,actions:0,moves:0,attacks:0,forms:0,stepAttacks:0,blocked:0,phase:null,road:null,note:''});}
  recent.push({id:record.id,team,turn:state.turn,map:state.map,ids:[...record.ids]});while(recent.length>16)recent.shift();updateRecord(record);void pump();return record;
 }
 return {submit,cancel,get pending(){return jobs.size},get activeRecords(){return [...records]},reset(){cancel();recent.length=0;}};
}
