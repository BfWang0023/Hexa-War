import {TERRAIN,tile,mobileAt,fortAt,neighbors,isShip,isRouted,moveCost,distance,movementAllowance} from './engine.mjs';
import {orderLocked} from './order-lock.mjs';
export function roadPriority(s,u){
 if(!u||u.hp<=0||u.aboard||isRouted(u)||isShip(u)||['fort','captive','defenseTower'].includes(u.kind))return 0;
 if(u.kind!=='supplyWagon')return 3;
 const p=s.logisticsPlan?.carts?.find(c=>c.id===u.id);
 return p?.phase==='returning'||p?.phase==='waiting'||(u.supplyStock||0)*5+(u.supplyCredit||0)<=0?1:2;
}
const road=(m,p)=>!!(tile(m,p.c,p.r)?.terrain&TERRAIN.ROAD)&&!(tile(m,p.c,p.r)?.terrain&(TERRAIN.RIVER|TERRAIN.SEA))&&!fortAt(m,p.c,p.r);
// Yielding is a real one-step move by the lower-priority friendly cart, paid
// from its own remaining actions. No swaps, overlap or enemy passage.
export function roadYieldPlan(s,u,from,to){
 const v=mobileAt(s.map,to.c,to.r);if(!v||v.id===u.id||v.team!==u.team||v.kind!=='supplyWagon'||v.actionsLeft<1||orderLocked(s,v.id)||!road(s.map,from)||!road(s.map,to)||roadPriority(s,u)<=roadPriority(s,v))return null;
 const dir=neighbors(from.c,from.r).findIndex(p=>p.c===to.c&&p.r===to.r);if(dir<0||!Number.isFinite(v.heading12))return null;
 const heading=(3-2*dir+12)%12,diff=Math.abs(((v.heading12-heading+18)%12)-6);if(diff<4)return null;
 const choices=neighbors(v.c,v.r).filter(p=>!mobileAt(s.map,p.c,p.r)&&!fortAt(s.map,p.c,p.r)&&tile(s.map,p.c,p.r)&&!(tile(s.map,p.c,p.r).terrain&(TERRAIN.RIVER|TERRAIN.SEA))&&Number.isFinite(moveCost(s,v,p.c,p.r))&&moveCost(s,v,p.c,p.r)<=movementAllowance(s,v).budget);
 choices.sort((a,b)=>Number(road(s.map,a))-Number(road(s.map,b))||distance(a,from)-distance(b,from)||a.r-b.r||a.c-b.c);
 return choices.length?{id:v.id,to:choices[0]}:null;
}
