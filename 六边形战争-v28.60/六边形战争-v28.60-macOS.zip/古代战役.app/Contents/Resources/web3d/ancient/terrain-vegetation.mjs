import {isMorannon} from './middle-earth-data.mjs';
import {terrainArtProfile} from './terrain-art-profile.mjs';
import * as T from '../vendor/three/three.module.js';
import {TERRAIN,tile,index} from './engine.mjs';
import {offsetToWorld,hexCorners} from '../js/core/hex.js';
import {bounds} from './terrain-adjacency.mjs';
let enabled=true;
export const vegetationEnabled=()=>enabled;
export const setVegetation=value=>{enabled=!!value;};
const rand=(c,r,s)=>{const n=Math.sin(c*127.1+r*311.7+s*74.7)*43758.5453;return n-Math.floor(n)};
let treeGeometry=null,grassGeometry=null,treeMaterial=null,grassMaterial=null;
function combine(parts){const positions=[],normals=[],colors=[];for(const [source,color]of parts){const g=source.index?source.toNonIndexed():source;positions.push(...g.attributes.position.array);normals.push(...g.attributes.normal.array);for(let i=0;i<g.attributes.position.count;i++)colors.push(color.r,color.g,color.b);if(g!==source)g.dispose();source.dispose();}const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('normal',new T.Float32BufferAttribute(normals,3));geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));geo.userData.sharedTerrain=true;return geo;}
function lodMaterial(){const m=new T.MeshLambertMaterial({vertexColors:true,transparent:true,depthWrite:true});m.userData.sharedTerrain=true;m.onBeforeCompile=s=>{s.vertexShader='varying float vegetationFade;\n'+s.vertexShader;s.vertexShader=s.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\nvegetationFade=smoothstep(1.8,5.5,650.0/max(1.0,-mvPosition.z));');s.fragmentShader='varying float vegetationFade;\n'+s.fragmentShader;s.fragmentShader=s.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\ndiffuseColor.a*=vegetationFade; if(diffuseColor.a<0.02)discard;');};return m;}
function geometries(){if(treeGeometry)return;
 const trunk=new T.CylinderGeometry(.18,.27,2.2,5).translate(0,1.1,0),leaf=new T.Color(0x607750);
 treeGeometry=combine([[trunk,new T.Color(0x78684c)],[new T.IcosahedronGeometry(1.35,0).scale(1,1.25,1).translate(0,3.0,0),leaf],[new T.IcosahedronGeometry(1.05,0).translate(.45,4.1,.1),leaf.clone().multiplyScalar(1.12)],[new T.IcosahedronGeometry(.95,0).translate(-.65,3.4,-.15),leaf.clone().multiplyScalar(.92)]]);
 grassGeometry=combine([[-.5,.35,.1,.62],[.3,.45,0,.73],[.05,.22,.55,.45]].map(([x,y,z,size])=>[new T.IcosahedronGeometry(size,0).scale(1,.65,1).translate(x,y,z),new T.Color(0x80905f)]));treeMaterial=lodMaterial();grassMaterial=lodMaterial();
}
export function vegetationPoints(m,region=null){const b=bounds(m,region),trees=[],grass=[],walls=new Set(m.units.filter(u=>u.kind==='fort'&&u.hp>0).map(u=>u.c+','+u.r));for(let r=b.r0;r<b.r1;r++)for(let c=b.c0;c<b.c1;c++){
 if(m.victory?.layoutVersion>=3&&(c+2*r)%4!==0)continue;
 if(m.unknown?.[index(m,c,r)])continue;
 const t=tile(m,c,r).terrain;if(t&(TERRAIN.ROAD|TERRAIN.RIVER|TERRAIN.SEA|TERRAIN.BEACH)||m.houses?.[index(m,c,r)]||walls.has(c+','+r))continue;
 const profile=terrainArtProfile(m,c,r);
 const p=offsetToWorld(c,r),corners=hexCorners(p.x,p.z),corner=corners[Math.floor(rand(c,r,103)*6)],x=p.x+(corner[0]-p.x)*.83,z=p.z+(corner[1]-p.z)*.83,mountain=!!(t&TERRAIN.MOUNTAIN),patch=(Math.sin(p.x*.038+p.z*.021)+Math.sin(p.z*.047-p.x*.017))*.25+.5;
 const treeChance=profile.ridge?.015:profile.valley?.18:profile.foot?.18:mountain?.08:.05,grassChance=profile.ridge?.025:profile.valley?.22:profile.foot?.20:mountain?.10:.12;
 if(m.scenarioId!=='teutoburg'&&profile.patch>.57&&rand(c,r,101)<treeChance)trees.push({c,r,x,z,scale:.92+rand(c,r,104)*.16,yaw:rand(c,r,105)*Math.PI*2});
 if(profile.patch>.52&&rand(c,r,106)<grassChance)grass.push({c,r,x,z,scale:3*(.9+rand(c,r,107)*.2),yaw:rand(c,r,108)*Math.PI*2});
 }return {trees,grass};}
export function createVegetation(m,sample,region=null){geometries();const group=new T.Group();group.name='terrain-vegetation';if(isMorannon(m.scenarioId))return {group,setQuality(){}};
const points=vegetationPoints(m,region),o=new T.Object3D();
 for(const [kind,geometry,material]of [['trees',treeGeometry,treeMaterial],['grass',grassGeometry,grassMaterial]]){const xs=points[kind];if(!xs.length)continue;const mesh=new T.InstancedMesh(geometry,material,xs.length);mesh.name='vegetation-'+kind;mesh.userData.fullCount=xs.length;xs.forEach((p,i)=>{o.position.set(p.x,sample(p.c,p.r,p.x,p.z)+.015,p.z);o.rotation.set(0,p.yaw,0);o.scale.setScalar(p.scale);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);mesh.setColorAt(i,new T.Color().setRGB(.93+rand(p.c,p.r,109)*.1,1,.92));});mesh.instanceMatrix.needsUpdate=true;mesh.instanceColor.needsUpdate=true;mesh.receiveShadow=true;mesh.castShadow=false;group.add(mesh);}
 return {group,points,setQuality(quality){group.visible=enabled;for(const mesh of group.children)mesh.count=quality==='low'?(mesh.name==='vegetation-trees'?Math.ceil(mesh.userData.fullCount*.5):0):mesh.userData.fullCount;}};}
