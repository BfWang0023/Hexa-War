import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import * as T from '../vendor/three/three.module.js';
import {fortificationLayout} from './fortification-layout.mjs';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {MIDDLE_EARTH} from './middle-earth-data.mjs';
import {createTerrainForts} from './terrain-forts.mjs';
import {createTerrainRefresh} from './terrain-refresh.mjs';
import {createUnitAnimator} from './unit-animation.mjs';
import {createSave,restoreSave} from './save.mjs';
import {HEX_R,SQRT3,offsetToWorld} from '../js/core/hex.js';

const full={unitFog:false,terrainFog:false,initialKnowledge:'full'};
const named=(s,kind)=>s.map.units.find(u=>u.kind===kind);
const pelennor=()=>E.startGame(makeMiddleEarthMap('me_pelennor'),{fogPolicy:full});
const has=(s,u,c,r)=>E.reachable(s,u).has(E.key(c,r));

test('Pelennor mounted units cannot enter a solid wall even where the road reaches its tile',()=>{
  const s=pelennor(),wall=E.fortAt(s.map,14,24),horse=named(s,'meGondorHorse');
  assert.ok(wall);
  // The planned one-edge cost is used by actual movement, not the road overlay.
  const side={c:15,r:24};
  assert.equal(E.fortificationStep(s.map,horse,side,wall),'该部队不能登墙，请从城门通过');
  assert.ok(E.fortificationStep(s.map,{...horse,team:'coalition'},side,wall));
  assert.equal(E.fortificationStep(s.map,{kind:'meWitchKing',team:'coalition'},side,wall),'');
});

test('gate openings share the actual mounted and foot route; infantry climb and dismount in separate actions',()=>{
  const s=pelennor(),g=E.fortAt(s.map,14,27);
  assert.equal(g.hp,E.FORT_HP[g.level]*.7);
  const layout=fortificationLayout(s.map);
  assert.deepEqual([...layout.at(g.c,g.r).openings].sort(),['27:13','27:15']);
  assert.match(E.fortificationStep(s.map,{kind:'meGondorHorse',team:'egypt'},{c:15,r:26},g),/门洞/);
  const u=s.map.units.find(u=>u.c===13&&u.r===26&&u.kind==='meGondor');
  const entering={...u,kind:'meRohanFoot',c:13,r:27};
  const through=E.reachable(s,entering).get('15,27');
  assert.deepEqual(through.path,[{c:14,r:27},{c:15,r:27}]);
  assert.equal(E.move(s,u.id,14,26).ok,true);
  const down=E.reachable(s,u).get('15,26');
  assert.ok(down?.path.length===1);
  for(const p of E.reachable(s,u).values()){
    if(!E.fortAt(s.map,p.c,p.r))assert.ok(p.path.slice(0,-1).every(q=>E.fortAt(s.map,q.c,q.r)));
  }
  const base=makeMiddleEarthMap('me_pelennor'),loaded=restoreSave(JSON.parse(JSON.stringify(createSave(base,s,'egypt')))).game;
  assert.equal(E.fortAt(loaded.map,14,26).hp,E.fortAt(s.map,14,26).hp);
  assert.equal(loaded.map.units.find(p=>p.id===u.id).c,14);
});

test('on a guarded strict map, enemy gate is closed and destructive work never grants a water route',()=>{
  const map=E.newMap(18,12);
  map.gateRules=1;
  E.addUnit(map,'pharaoh','egypt',0,0);
  E.addUnit(map,'hittiteKing','coalition',17,11);
  E.addUnit(map,'cavalry','egypt',7,5);
  E.setGate(map,8,5,2,'coalition','门');
  E.setTerrain(map,8,5,E.TERRAIN.ROAD);
  const s=E.startGame(map,{fogPolicy:full}),u=named(s,'cavalry'),gate=E.fortAt(s.map,8,5);
  assert.equal(E.move(s,u.id,8,5).ok,false);
  assert.equal(u.actionsLeft,2);
  gate.hp=0;
  assert.ok(has(s,u,8,5));
  E.setTerrain(s.map,8,5,E.TERRAIN.SEA);
  assert.equal(has(s,u,8,5),false);
  assert.equal(E.move(s,u.id,8,5).ok,false);
  assert.equal(u.actionsLeft,2);
});

test('connected historical gate only accepts its facing approaches and an open wall end remains passable',()=>{
  const m=E.newMap(18,12);
  m.gateRules=1;
  E.setGate(m,8,6,2,'egypt');
  E.setFort(m,8,5,2,'egypt');
  E.setFort(m,8,7,2,'egypt');
  const g=E.fortAt(m,8,6),u={kind:'cavalry',team:'egypt'};
  const plan=fortificationLayout(m).at(g.c,g.r);
  assert.equal(plan.openings.size,2);
  for(const approach of E.neighbors(g.c,g.r)){
    const open=plan.openings.has(approach.r+':'+approach.c);
    assert.equal(!E.fortificationStep(m,u,approach,g),open);
  }
  assert.equal(E.fortificationStep(m,u,{c:7,r:4},{c:8,r:4}),'');
});

test('closed empty fortress changes gate ownership from an exterior approach, without wall or HP reset',()=>{
  const map=E.newMap(25,16),core={c:11,r:8};
  map.gateRules=1;
  E.addUnit(map,'pharaoh','egypt',0,0);
  E.addUnit(map,'hittiteKing','coalition',24,15);
  E.addUnit(map,'light','egypt',6,8);
  for(let r=5;r<=11;r++)for(let c=8;c<=14;c++)if(E.distance({c,r},core)===2)E.setFort(map,c,r,2,'coalition','测试堡');
  E.setGate(map,9,8,2,'coalition','测试堡');
  E.fortAt(map,9,8).hp=123;
  const s=E.startGame(map,{manualCores:true,fogPolicy:full}),u=named(s,'light'),gate=E.fortAt(s.map,9,8);
  assert.equal(has(s,u,9,8),false);
  const move=E.move(s,u.id,8,8);
  assert.equal(move.ok,true);
  assert.equal(move.captures.length,1);
  assert.equal(gate.team,'egypt');
  assert.equal(gate.hp,123);
  assert.equal(E.moveCost(s,u,9,8),1);
  assert.equal(E.reachable(s,u).get('10,8')?.path[0].c,9);
});

test('animations reserve one gate passage at a time and stand at its ground anchor',()=>{
  const s=pelennor(),layout=fortificationLayout(s.map),animator=createUnitAnimator();
  animator.setWorksResolver(()=>layout);
  animator.setHeightResolver(()=>0);
  const actors=[{id:'a',c:13,r:27,kind:'meGondor',team:'egypt'},{id:'b',c:15,r:27,kind:'meGondorHorse',team:'egypt'}];
  animator.observe(actors,0,s.map);
  animator.move('a',actors[0],[{c:14,r:27},{c:15,r:27}],0);
  animator.move('b',actors[1],[{c:14,r:27},{c:13,r:27}],0);
  assert.ok(animator.inspect('b').queue[0].start>=animator.inspect('a').queue[0].end);
  const camera=new T.PerspectiveCamera(),group=new T.Group(),model=new T.Group();
  model.userData={unitId:'a',armyFormation:true};
  const start=offsetToWorld(13,27);
  model.position.set(start.x,0,start.z);group.add(model);
  animator.update(group,camera,0);
  animator.update(group,camera,340);
  const anchor=layout.at(14,27).p;
  assert.equal(model.position.x,anchor.x);
  assert.equal(model.position.y,0);
  assert.ok(model.userData.armyCorridor);
  const waiting=new T.Group(),from=offsetToWorld(15,27),to=offsetToWorld(13,27);
  waiting.userData={unitId:'b',armyFormation:true};
  waiting.position.set(to.x,0,to.z);
  group.add(waiting);
  animator.observe([actors[0],{...actors[1],c:13}],340,s.map);
  animator.update(group,camera,340);
  assert.equal(waiting.position.x,from.x);
  assert.equal(waiting.userData.armyMoving,false);
});

test('foundations and roads rebuild locally when a wall becomes a gate or a breach',()=>{
  const m=makeMiddleEarthMap('me_pelennor'),terrain=createTerrainRefresh();
  terrain.refresh(m);
  const gate=E.fortAt(m,14,27),r=terrain.lastUpdate;
  assert.ok(r.terrainChunks.length);
  assert.ok([...terrain.chunks.values()].some(x=>x.forts.getObjectByName('wall-footings')));
  gate.hp=0;
  const result=terrain.refresh(m);
  assert.equal(result.reset,false);
  assert.ok(result.terrainChunks.length>0&&result.terrainChunks.length<=r.totalChunks);
  terrain.dispose();
});

test('a complete wall blocks ground sight and arrows, while the wall itself can be attacked',()=>{
  const map=E.newMap(19,14);
  map.gateRules=1;
  E.addUnit(map,'pharaoh','egypt',0,0);
  E.addUnit(map,'hittiteKing','coalition',18,13);
  E.addUnit(map,'archer','egypt',8,6);
  E.addUnit(map,'heavy','coalition',10,6);
  E.setFort(map,9,6,2,'coalition','隔断');
  const s=E.startGame(map,{fogPolicy:full}),bow=named(s,'archer');
  assert.equal(E.unitSightCells(s,bow).has('10,6'),false);
  assert.equal(E.attackPreview(s,bow,10,6),null);
  assert.equal(E.attackPreview(s,bow,9,6).target.kind,'fort');
  E.fortAt(s.map,9,6).hp=0;
  assert.ok(E.unitSightCells(s,bow).has('10,6'));
  assert.equal(E.attackPreview(s,bow,10,6).melee,false);
});

test('legal wall-top attacks use the existing logical elevation multiplier',()=>{
  function sample(top){
    const map=E.newMap(19,14);
    map.gateRules=1;
    E.addUnit(map,'pharaoh','egypt',0,0);
    E.addUnit(map,'hittiteKing','coalition',18,13);
    if(top)E.setFort(map,8,6,2,'egypt','平台');
    E.addUnit(map,'light','egypt',8,6);
    E.addUnit(map,'heavy','coalition',9,6);
    const s=E.startGame(map,{fogPolicy:full});
    return E.attackPreview(s,named(s,'light'),9,6);
  }
  assert.equal(sample(false).elevation.multiplier,1);
  assert.equal(sample(true).elevation.multiplier,1.30);
  assert.ok(sample(true).damage>sample(false).damage);
});


test('Middle-earth walls, towers and foundations stay within their own hexes',()=>{
  const matrix=new T.Matrix4(),v=new T.Vector3();
  const normals=Array.from({length:6},(_,i)=>[Math.cos(i*Math.PI/3),Math.sin(i*Math.PI/3)]);
  const apothem=HEX_R*SQRT3/2;
  for(const {id} of MIDDLE_EARTH){
    const m=makeMiddleEarthMap(id),walls=m.units.filter(u=>u.kind==='fort'),layout=fortificationLayout(m);
    for(const u of walls)assert.deepEqual(layout.position(u),offsetToWorld(u.c,u.r));
    // Different neighboring heights exercise the sloped wall pieces as well.
    const group=createTerrainForts(m,walls,(_map,c,r)=>(c+r*3)%5*.63);
    for(const mesh of group.children){
      for(const [i,{c,r}] of mesh.userData.cells.entries()){
        mesh.getMatrixAt(i,matrix);
        const p=offsetToWorld(c,r);
        for(const x of [-.5,.5])for(const z of [-.5,.5]){
          v.set(x,0,z).applyMatrix4(matrix);
          assert.ok(normals.every(([nx,nz])=>(v.x-p.x)*nx+(v.z-p.z)*nz<=apothem+.001),
            `${id} ${mesh.name} ${c},${r}: corner ${v.x-p.x},${v.z-p.z}`);
        }
      }
      mesh.dispose();mesh.geometry.dispose();mesh.material.dispose();
    }
  }
});
