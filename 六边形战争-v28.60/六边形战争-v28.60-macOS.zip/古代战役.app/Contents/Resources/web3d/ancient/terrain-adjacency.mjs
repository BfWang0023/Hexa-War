import {bridgeEnds,hasCliffNavigation} from './cliff-navigation.mjs';
// Derived visual connectivity; no orientation fields are written into maps/saves.
import { neighbors, inBounds, index, TERRAIN } from './engine.mjs';
import { offsetToWorld } from '../js/core/hex.js';
export function bounds(m, region = null, halo = 0) {
  return {c0:Math.max(0,(region?.c0??0)-halo),r0:Math.max(0,(region?.r0??0)-halo),
    c1:Math.min(m.cols,(region?.c1??m.cols)+halo),r1:Math.min(m.rows,(region?.r1??m.rows)+halo)};
}
export function contains(region,c,r) {return !region || c>=region.c0 && c<region.c1 && r>=region.r0 && r<region.r1;}
export function adjacency(m,c,r,bit) {
  return neighbors(c,r).map((p,direction)=>({...p,direction})).filter(p=>inBounds(m,p.c,p.r)&&(m.terrain[index(m,p.c,p.r)]&bit));
}
export function wallNeighbors(m,u,byCell) {
  return neighbors(u.c,u.r).map((p,direction)=>({wall:byCell.get(`${p.c},${p.r}`),direction}))
    .filter(p=>p.wall?.hp>0 && p.wall.team===u.team);
}
export function crossingAxis(m,c,r) {
  const center=offsetToWorld(c,r), roads=adjacency(m,c,r,TERRAIN.ROAD), rivers=adjacency(m,c,r,TERRAIN.RIVER);
  if(hasCliffNavigation(m)&&m.bridges.some(b=>b.c===c&&b.r===r)){
    const [first,last]=bridgeEnds(m,{c,r}).map(p=>offsetToWorld(p.c,p.r));
    if(first)return last?-Math.atan2(last.z-first.z,last.x-first.x):-Math.atan2(first.z-center.z,first.x-center.x);
  }
  const dry=roads.filter(p=>!(m.terrain[index(m,p.c,p.r)]&TERRAIN.RIVER));
  // Prefer opposite dry-bank roads, then connected ford/bridge road segments.
  const choose=points=>{
    let best=null,score=-Infinity;
    for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++) {
      const a=offsetToWorld(points[i].c,points[i].r),b=offsetToWorld(points[j].c,points[j].r);
      const dot=(a.x-center.x)*(b.x-center.x)+(a.z-center.z)*(b.z-center.z);
      if(-dot>score){score=-dot;best={a,b};}
    }
    return best;
  };
  let pair=dry.length>=2?choose(dry):choose(roads);
  if(pair)return -Math.atan2(pair.b.z-pair.a.z,pair.b.x-pair.a.x);
  if(roads.length){const p=offsetToWorld(roads[0].c,roads[0].r);return -Math.atan2(p.z-center.z,p.x-center.x);}
  pair=choose(rivers);
  if(pair)return -Math.atan2(pair.b.z-pair.a.z,pair.b.x-pair.a.x)+Math.PI/2;
  if(rivers.length){const p=offsetToWorld(rivers[0].c,rivers[0].r);return -Math.atan2(p.z-center.z,p.x-center.x)+Math.PI/2;}
  return 0;
}

// Compact maps traverse only the rule-defined bridge approaches. Give each
// approach its own half-span when the roads turn inside the bridge hex.
export function bridgeDeckSpans(m,c,r){
  if(!hasCliffNavigation(m))return [];
  const center=offsetToWorld(c,r);
  return bridgeEnds(m,{c,r}).map(p=>{
    const end=offsetToWorld(p.c,p.r),dx=end.x-center.x,dz=end.z-center.z;
    return {x:center.x+dx*.25,z:center.z+dz*.25,angle:-Math.atan2(dz,dx),length:Math.hypot(dx,dz)*.5+.10};
  });
}
export function bridgeDeckContains(spans,x,z){
  return spans.some(span=>{
    const dx=x-span.x,dz=z-span.z,cs=Math.cos(span.angle),sn=Math.sin(span.angle);
    return Math.abs(dx*cs-dz*sn)<=span.length/2&&Math.abs(dx*sn+dz*cs)<=2;
  });
}
