import {projectConstructionMaps,surfaceMaps} from './middle-earth-materials.mjs';
import {culvertBanks} from './cliff-navigation.mjs';
import * as THREE from '../vendor/three/three.module.js';
import { offsetToWorld } from '../js/core/hex.js';
import { TERRAIN, index, neighbors, inBounds, bridgeAt } from './engine.mjs';

import { bounds, bridgeDeckSpans, crossingAxis } from './terrain-adjacency.mjs';
export const crossingAngle = crossingAxis;
function batch(group,name,items,color,maps={}) {
  if(!items.length)return null;
  const material=new THREE.MeshStandardMaterial({color,roughness:.95,...maps});
  projectConstructionMaps(material,name==='culvert-stone'?6.4:4.5);
  const mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),material,items.length),o=new THREE.Object3D();
  items.forEach((item,i)=>{o.position.set(...item.p);o.scale.set(...item.s);o.rotation.set(0,item.a,0);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);});
  mesh.castShadow=true;mesh.receiveShadow=true;mesh.name=name;mesh.instanceMatrix.needsUpdate=true;group.add(mesh);return mesh;
}
export function createCrossings(m, region = null) {
  const b=bounds(m,region);
  const group=new THREE.Group(),wood=[],stone=[],decks=[],arch=[],shade=[];
  const remaster=!!m.victory?.army;
  const culvert=culvertBanks(m)&&m.victory.points.culvert;
  for(let r=b.r0;r<b.r1;r++)for(let c=b.c0;c<b.c1;c++) {
    if((m.terrain[index(m,c,r)]&(TERRAIN.RIVER|TERRAIN.ROAD))!==(TERRAIN.RIVER|TERRAIN.ROAD))continue;
    const p=offsetToWorld(c,r),a=crossingAngle(m,c,r),cs=Math.cos(a),sn=Math.sin(a);
    const at=(x,y,z)=>[p.x+cs*x+sn*z,y,p.z-sn*x+cs*z];
    if(culvert?.c===c&&culvert.r===r){
      for(const q of culvertBanks(m)){
        const v=offsetToWorld(q.c,q.r),angle=-Math.atan2(v.z-p.z,v.x-p.x),co=Math.cos(angle),si=Math.sin(angle);
        const face=(x,y,z)=>[p.x+co*x+si*z,y,p.z-si*x+co*z];
        for(const z of [-1.48,1.48]){
          arch.push({p:face(3.45,1.05,z),s:[1.3,2.7,.70],a:angle});
          arch.push({p:face(3.45,2.42,z*.72),s:[1.35,.68,.84],a:angle});
        }
        arch.push({p:face(3.45,2.87,0),s:[1.45,.58,2.35],a:angle});
        shade.push({p:face(2.18,1.12,0),s:[.10,2.45,2.45],a:angle});
      }
      continue;
    }
    // The underlying ford is always present, including while the bridge is standing.
    for(let j=-3;j<=3;j++){
      const stagger=(j%2)*.18;
      stone.push({p:at(j*1.48,-.23,stagger),s:[remaster?1.28:1.38,.22,remaster?2.28+Math.abs(j%3)*.16:2.9],a:a+(remaster?stagger*.45:0)});
    }
    if(!bridgeAt(m,c,r))continue;
    const spans=bridgeDeckSpans(m,c,r);
    const bent=spans.length===2&&Math.abs(Math.sin(spans[0].angle-spans[1].angle))>.01;
    if(bent||spans.length===1){
      for(const {x,z,angle,length} of spans){
        const co=Math.cos(angle),si=Math.sin(angle);
        decks.push({p:[x,.35,z],s:[length,.30,4],a:angle});
        for(const side of [-1,1]){
          const lateral=side*2, along=.65;
          wood.push({p:[x+co*along+si*lateral,1.03,z-si*along+co*lateral],s:[length-1.3,.24,.22],a:angle});
          const post=length/2-.50;
          wood.push({p:[x+co*post+si*lateral,.22,z-si*post+co*lateral],s:[.28,1.9,.28],a:angle});
        }
      }
      continue;
    }
    decks.push({p:at(0,.35,0),s:[10.5,.30,4.0],a});
    for(const side of [-1,1]) {
      wood.push({p:at(0,1.03,side*2),s:[10.5,.24,.22],a});
      for(const x of [-4.6,0,4.6])wood.push({p:at(x,.22,side*2),s:[.28,1.9,.28],a});
    }
    for(let x=-4.6;x<5;x+=.85)wood.push({p:at(x,.514,0),s:[.045,.025,3.95],a});
  }
  const ford=batch(group,'underlying-fords',stone,remaster?0xc8c3ae:0xb5ad8e,remaster?surfaceMaps('stone'):{});
  const woodMaps=remaster?surfaceMaps('wood'):{};
  const deck=batch(group,'bridge-decks',decks,remaster?0xc0a78c:0x9f8058,woodMaps);
  batch(group,'bridge-structure',wood,0x68543e,woodMaps);
  batch(group,'culvert-stone',arch,0x777368,remaster?surfaceMaps('stone'):{});
  batch(group,'culvert-interior',shade,0x252724);
  return {group,pickables:[ford,deck].filter(Boolean)};
}
