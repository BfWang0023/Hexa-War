// Ground-plan projection of saved works, shared by the terrain renderer and
// movement. Coordinates and health remain authoritative in map.units.
import {DIRS,offsetToWorld} from '../js/core/hex.js';

const key=(c,r)=>r+':'+c;
const inside=(m,c,r)=>c>=0&&r>=0&&c<m.cols&&r<m.rows;
const adjacent=({c,r})=>DIRS.map(([dq,dr])=>({c:c+dq+Math.floor((r+dr)/2)-Math.floor(r/2),r:r+dr}));
const cache=new WeakMap();
export const isSolidWall=fort=>!!fort&&fort.hp>0&&!fort.gate&&fort.cityId!=='外堤';
export const usesFortificationLayout=m=>m?.gateRules===1||m?.victory?.mode==='middle-earth'&&m.victory.layoutVersion>=2;
export const fortWallHeight=level=>[0,2.8,4.2,5.6][level]||0;
export const fortWallWidth=(m,grand)=>m.victory?.layoutVersion>=2?4.3:grand?3.25:2.7;

function rectangle(x,z,length,width,angle=0){
  return {x,z,a:length/2,b:width/2,cs:Math.cos(angle),sn:Math.sin(angle)};
}
function intersects(rect,from,to){
  const local=p=>{const x=p.x-rect.x,z=p.z-rect.z;return [x*rect.cs-z*rect.sn,x*rect.sn+z*rect.cs];};
  const p=local(from),q=local(to);
  let low=.001,high=.999;
  for(const [i,size] of [rect.a-.045,rect.b-.045].entries()){
    const d=q[i]-p[i];
    if(Math.abs(d)<1e-6){if(Math.abs(p[i])>=size)return false;continue;}
    const a=(-size-p[i])/d,b=(size-p[i])/d;
    low=Math.max(low,Math.min(a,b));
    high=Math.min(high,Math.max(a,b));
    if(low>=high)return false;
  }
  return true;
}
const world=f=>offsetToWorld(f.c,f.r);
const direction=(p,q)=>-Math.atan2(q.z-p.z,q.x-p.x);

export function fortificationLayout(map){
  const all=map.units.filter(u=>u.kind==='fort');
  const sig=all.map(f=>[f.id,f.c,f.r,f.level,f.gate,f.hp>0,f.team,f.cityId,f.gate?adjacent(f).map(q=>map.terrain[q.r*map.cols+q.c]&1).join(''):''].join(',')).join(';');
  const old=cache.get(map);
  if(old?.units===map.units&&old.sig===sig)return old.layout;
  const allAt=new Map(all.map(f=>[key(f.c,f.r),f])), plans=new Map();
  const authored=map.victory?.layoutVersion>=2, governed=usesFortificationLayout(map);
  const anchor=world;
  for(const fort of all){
    const at=key(fort.c,fort.r),p=anchor(fort),neighbors=adjacent(fort);
    const connected=neighbors.map(q=>allAt.get(key(q.c,q.r))).filter(f=>f?.hp>0&&f.team===fort.team);
    const arms=connected.map(v=>{const q=anchor(v);return {fort:v,dx:(q.x-p.x)/2,dz:(q.z-p.z)/2};});
    if(!arms.length)arms.push({dx:4.8,dz:0},{dx:-4.8,dz:0});
    // At a gate turn choose the wall's through axis, independent of neighbor order.
    const ends=connected.map(anchor);
    const axis=ends.length===2?direction(ends[0],ends[1]):ends.length?direction(p,ends[0]):0;
    const grand=fort.level===3&&!(map.victory?.layoutVersion===6&&fort.cityId==='深谷墙');
    const width=fortWallWidth(map,grand),nodeWidth=authored?width:grand?3.8:3.2;
    const angle=-Math.atan2(arms[0].dz,arms[0].dx);
    const towerOffset=authored?2.1:3.55;
    const tower=grand?{x:p.x+Math.sin(angle)*towerOffset,z:p.z+Math.cos(angle)*towerOffset,size:authored?4.4:2.4,angle}:null;
    const blocks=[];
    if(isSolidWall(fort)){
      blocks.push(rectangle(p.x,p.z,nodeWidth,nodeWidth));
      for(const arm of arms)blocks.push(rectangle(p.x+arm.dx/2,p.z+arm.dz/2,Math.hypot(arm.dx,arm.dz)+(authored?0:.12),width,-Math.atan2(arm.dz,arm.dx)));
      if(tower)blocks.push(rectangle(tower.x,tower.z,tower.size,tower.size,angle));
    }else if(fort.gate&&fort.hp>0){
      for(const side of [-1,1]){
        const x=p.x+Math.cos(axis)*side*2,z=p.z-Math.sin(axis)*side*2;
        blocks.push(rectangle(x,z,1.5,3.2,axis));
      }
    }
    const openings=new Set();
    if(fort.gate&&governed&&connected.length){
      const co=Math.cos(axis),si=Math.sin(axis),approaches=neighbors.filter(q=>inside(map,q.c,q.r)&&!isSolidWall(allAt.get(key(q.c,q.r)))).map(q=>{
        const v=world(q),dx=v.x-p.x,dz=v.z-p.z;
        return {q,side:dx*si+dz*co,along:Math.abs(dx*co-dz*si)};
      });
      // A portal faces the two cells most nearly perpendicular to the wall.
      for(const sign of [-1,1]){
        const eligible=approaches.filter(q=>sign*q.side>2&&q.along<Math.abs(q.side)*.9);
        eligible.sort((a,b)=>Number(!!(map.terrain[b.q.r*map.cols+b.q.c]&1))-Number(!!(map.terrain[a.q.r*map.cols+a.q.c]&1))||
          a.along/Math.abs(a.side)-b.along/Math.abs(b.side));
        if(eligible.length)openings.add(key(eligible[0].q.c,eligible[0].q.r));
      }
    }
    plans.set(at,{fort,p,axis,connected,arms,width,nodeWidth,tower,blocks,openings});
  }
  const edges=new Map();
  const layout={
    at:(c,r)=>plans.get(key(c,r)),
    anchor,
    position(p){const plan=plans.get(key(p.c,p.r));return plan?.fort.hp>0?plan.p:world(p);},
    gateConnects(gate,other){
      const openings=plans.get(key(gate.c,gate.r))?.openings;
      return !openings?.size||openings.has(key(other.c,other.r));
    },
    blocksEdge(from,to){
      const a=key(from.c,from.r),b=key(to.c,to.r),edge=a<b?a+'/'+b:b+'/'+a;
      if(edges.has(edge))return edges.get(edge);
      const start=layout.position(from),end=layout.position(to);
      let blocked=false;
      for(let r=Math.min(from.r,to.r)-1;r<=Math.max(from.r,to.r)+1&&!blocked;r++)
        for(let c=Math.min(from.c,to.c)-1;c<=Math.max(from.c,to.c)+1&&!blocked;c++){
          const k=key(c,r);
          if(k!==a&&k!==b)blocked=plans.get(k)?.blocks.some(part=>intersects(part,start,end))??false;
        }
      edges.set(edge,blocked);
      return blocked;
    },
  };
  cache.set(map,{sig,units:map.units,layout});
  return layout;
}
