import * as T from '../vendor/three/three.module.js';
import {animateFullModel,createMiddleEarthFormationMember} from './full-models.mjs';

// Each formation draws one instanced mesh per equipment set. Bake a few poses
// from the same joints used in the encyclopedia and interpolate them on the GPU.
export function createArmyMemberGeometry(unit,map){
  const member=createMiddleEarthFormationMember(unit,map);
  const meshes=[],p=new T.Vector3(),n=new T.Vector3(),normalMatrix=new T.Matrix3();
  member.traverse(mesh=>{
    if(mesh.isMesh)meshes.push({mesh,geometry:mesh.geometry,base:0});
  });
  let vertices=0,indices=0;
  for(const item of meshes){
    item.base=vertices;
    vertices+=item.geometry.attributes.position.count;
    indices+=item.geometry.index?.count??item.geometry.attributes.position.count;
  }

  function sample(time,options){
    animateFullModel(member,time,options);
    member.updateMatrixWorld(true);
    const positions=new Float32Array(vertices*3),normals=new Float32Array(vertices*3);
    for(const {mesh,geometry,base} of meshes){
      let visible=true;
      for(let joint=mesh;visible&&joint;joint=joint.parent)visible=joint.visible;
      const a=geometry.attributes.position,b=geometry.attributes.normal;
      normalMatrix.getNormalMatrix(mesh.matrixWorld);
      for(let i=0;i<a.count;i++){
        const offset=(base+i)*3;
        if(visible)p.fromBufferAttribute(a,i);
        else p.set(0,0,0);
        p.applyMatrix4(mesh.matrixWorld).toArray(positions,offset);
        n.fromBufferAttribute(b,i).applyNormalMatrix(normalMatrix).toArray(normals,offset);
      }
    }
    return {positions,normals};
  }

  const color=new Float32Array(vertices*3),index=new Uint16Array(indices);
  if(vertices>65535)throw new Error('中土编队单体网格超过索引容量');
  let cursor=0;
  for(const {mesh,geometry,base} of meshes){
    const count=geometry.attributes.position.count;
    for(let i=0;i<count;i++)mesh.material.color.toArray(color,(base+i)*3);
    for(let i=0;i<(geometry.index?.count??count);i++)
      index[cursor++]=base+(geometry.index?.getX(i)??i);
  }

  const profile=member.userData.profile;
  const poses=[
    sample(0,{}),
    sample(196,{moving:true}),
    sample(589,{moving:true}),
    sample(0,{action:profile.meleeAction,progress:.45}),
    sample(0,{action:profile.rangedAction,progress:.54}),
  ];
  const [base,...targets]=poses;
  const muzzle=member.getObjectByName('muzzle')?.getWorldPosition(new T.Vector3());
  let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
  for(let i=0;i<base.positions.length;i+=3){
    minX=Math.min(minX,base.positions[i]);
    maxX=Math.max(maxX,base.positions[i]);
    minY=Math.min(minY,base.positions[i+1]);
    maxY=Math.max(maxY,base.positions[i+1]);
  }
  const mounted=profile.family==='cavalry'||profile.middleEarth==='wolf';
  const centerX=mounted?(minX+maxX)/2:0;
  for(const {positions} of poses)for(let i=0;i<positions.length;i+=3){
    positions[i]-=centerX;
    positions[i+1]-=minY;
  }

  const geometry=new T.BufferGeometry();
  geometry.setIndex(new T.BufferAttribute(index,1));
  geometry.setAttribute('position',new T.BufferAttribute(base.positions,3));
  geometry.setAttribute('normal',new T.BufferAttribute(base.normals,3));
  geometry.setAttribute('color',new T.BufferAttribute(color,3));
  geometry.userData.standingHeight=maxY-minY;
  if(muzzle)geometry.userData.muzzle=muzzle.sub(new T.Vector3(centerX,minY,0)).toArray();
  geometry.morphAttributes.position=targets.map(pose=>new T.BufferAttribute(pose.positions,3));
  geometry.morphAttributes.normal=targets.map(pose=>new T.BufferAttribute(pose.normals,3));
  for(const {geometry:part} of meshes)part.dispose();
  return geometry;
}
