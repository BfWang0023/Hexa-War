import * as T from '../vendor/three/three.module.js';
import {fmt} from './engine.mjs';
const arrowGeo=new T.CylinderGeometry(.025,.025,1.25,5);arrowGeo.rotateX(Math.PI/2);
const pointGeo=new T.ConeGeometry(.08,.25,4);pointGeo.rotateX(Math.PI/2);
const stoneGeo=new T.IcosahedronGeometry(.21,0),ringGeo=new T.TorusGeometry(.55,.04,4,16);
const wood=new T.MeshStandardMaterial({color:0x8a5935}),metal=new T.MeshStandardMaterial({color:0xb0b5a7,metalness:.5,roughness:.5});
export function createWeaponEffects(scene,camera,stage,onAttack){
 const root=new T.Group();root.name='weapon-effects-v02';scene.add(root);const active=[];
 function remove(e){root.remove(e.group);e.label?.remove();e.marker.material.dispose();}
 return {
  play(result,map,delay=0){if(result?.ok&&result.visual)onAttack(result,performance.now()+delay,map);},
  playBatch(results,map){for(const result of results)this.play(result,map);},
  launch(result,origin,target,action,now){
   const ranged=!result.visual.melee,group=new T.Group(),projectile=new T.Group();group.add(projectile);
   if(['catapult','sling','generic-projectile'].includes(action))projectile.add(new T.Mesh(stoneGeo,metal));
   else {projectile.add(new T.Mesh(arrowGeo,wood));const tip=new T.Mesh(pointGeo,metal);tip.position.z=.75;projectile.add(tip);if(action==='throw')projectile.scale.setScalar(1.5);}
   projectile.visible=ranged;const marker=new T.Mesh(ringGeo,new T.MeshBasicMaterial({color:result.hit?0xe8b764:0xaab6c3,transparent:true,opacity:.8}));marker.visible=false;group.add(marker);root.add(group);
   const end=target.clone();if(!result.hit){const direction=target.clone().sub(origin).normalize();end.x+=-direction.z*1.4;end.z+=direction.x*1.4;}
   let label=null;if(stage){label=document.createElement('div');label.className='combat-damage';label.textContent=result.hit?`${result.visual.chargeCritical?.triggered?'冲锋暴击 ':result.visual.chargeBonus?.triggered?'冲锋 ':result.visual.ram?'撞击 ':''}−${fmt((result.fortDamage||0)+(result.unitDamage||0))}`:result.visual.chargeBonus?.triggered?'冲锋未命中':'未命中';label.style.display='none';stage.append(label);}
   active.push({group,projectile,marker,label,origin:origin.clone(),target:end,now,duration:ranged?280:0,action});
   // Bound only transient visible effects; rules and attack queues are untouched.
   if(active.length>96)remove(active.shift());
  },
  update(now){for(let i=active.length-1;i>=0;i--){const e=active[i],elapsed=now-e.now,p=Math.min(1,elapsed/Math.max(1,e.duration));if(elapsed>e.duration+350){remove(e);active.splice(i,1);continue;}
   e.projectile.visible=elapsed<e.duration;const arc=e.action==='catapult'?4:e.action==='throw'?1.3:.35;
   e.projectile.position.copy(e.origin).lerp(e.target,p);e.projectile.position.y+=Math.sin(p*Math.PI)*arc;
   const tangent=e.target.clone().sub(e.origin);tangent.y+=Math.cos(p*Math.PI)*Math.PI*arc;e.projectile.quaternion.setFromUnitVectors(new T.Vector3(0,0,1),tangent.normalize());
   const impact=elapsed>=e.duration;e.marker.visible=impact;if(impact){const fade=(elapsed-e.duration)/350;e.marker.position.copy(e.target);e.marker.quaternion.copy(camera.quaternion);e.marker.scale.setScalar(1+fade*2);e.marker.material.opacity=1-fade;}
   if(e.label){e.label.style.display=impact?'':'none';const v=e.target.clone().project(camera);e.label.style.left=`${(v.x*.5+.5)*stage.clientWidth}px`;e.label.style.top=`${(-v.y*.5+.5)*stage.clientHeight-25}px`;}
  }},
  clear(){for(const e of active)remove(e);active.length=0;},
  get activeCount(){return active.length;}
 };
}
