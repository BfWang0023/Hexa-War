import {projectConstructionMaps,surfaceMaps} from './middle-earth-materials.mjs';
import {projectMiddleEarthCell,middleEarthScale} from './middle-earth-data.mjs';
import * as T from '../vendor/three/three.module.js';
import {offsetToWorld} from '../js/core/hex.js';
import {index,TERRAIN} from './engine.mjs';
import {contains} from './terrain-adjacency.mjs';

const sand=0xa8957a,dark=0x4a4238,mortar=0x766d61,stone=0x938679,ivory=0xc1baaa;
const whiteParapet=0xd7d4c8,whiteSlate=0x706e73;
const hornburgStone=0x75766c,hornburgCap=0xa19d86,ereborStone=0x657a6f,ereborBronze=0x8a815c;
const innerCity=[
  {c:11,r0:20,r1:33,h:4.4}, {c:10,r0:21,r1:33,h:4.1},
  {c:9,r0:21,r1:32,h:4.2}, {c:8,r0:22,r1:31,h:4.4},
  {c:7,r0:23,r1:31,h:4.6}, {c:6,r0:24,r1:30,h:5.0},
];
function whiteCity(map,cell){
  for(const [tier,{c,r0,r1,h}] of innerCity.entries())for(let r=r0;r<=r1;r++){
    const terrain=map.terrain[index(map,c,r)];
    if(terrain&TERRAIN.ROAD||r===27)continue;
    const range=r<27?27-r0:r1-27,span=19-tier*1.7;
    const bend=((r-27)/range)**2*span;
    const tilt=Math.atan2(-2*(r-27)*span/(range**2),9);
    const x=2.8-(r&1)*5.196-bend;
    cell(c,r,block=>{
      const end=r===r0||r===r1;
      // Long retaining faces and crenellations read as rings across the stepped hill.
      block(ivory,x,h*.12,0,1.75,h,10.3,tilt);
      block(whiteParapet,x+.52,h*.34,0,.78,.23,10.25,tilt);
      block(whiteParapet,x,h*.62,0,2.15,.31,10.35,tilt);
      for(const z of [-3.4,-1.1,1.1,3.4])block(ivory,x+Math.sin(tilt)*z,h*.74,Math.cos(tilt)*z,1.45,.70,.83,tilt);
      if(end){
        block(ivory,x-.65,h*.22,0,3.20,h+1.0,3.62);
        block(whiteParapet,x-.65,h*.72+.42,0,3.46,.44,3.88);
      }
      if(tier>1&&r%2===tier%2&&!end){
        const roof=2.25+(tier+r)%3*.43;
        block(ivory,x-3.2,roof/2,0,3.0,roof,4.1);
        block(whiteSlate,x-3.94,roof+.20,0,1.79,.24,4.5,0,.28);
        block(whiteSlate,x-2.46,roof+.20,0,1.79,.24,4.5,0,-.28);
        for(const z of [-1.1,.8])block(dark,x-1.66,roof*.66,z,.12,.71,.31);
      }
    });
  }
  // The citadel sits on the summit. The tower, hall and fountain court share the stone palette.
  cell(3,27,block=>{
    block(ivory,0,.2,0,10.6,1.8,10.8);
    block(whiteParapet,0,1.2,0,10.9,.31,11.0);
    block(ivory,-1.0,4.1,-.6,6.4,5.9,6.6);
    block(whiteParapet,-1.0,7.05,-.6,7.0,.45,7.1);
    block(ivory,-1.0,13.0,-.6,3.55,11.9,3.55);
    for(const z of [-1.4,.27])for(const y of [10.5,13.6,16.6])
      block(dark,.80,y,z,.12,1.12,.42);
    block(whiteParapet,-1.0,18.94,-.6,4.38,.65,4.38);
    for(const x of [-2.8,.8])for(const z of [-2.4,1.2])block(ivory,x,19.52,z,.66,1.05,.66);
    block(ivory,-1.0,20.05,-.6,2.72,1.9,2.72);
    block(whiteSlate,-1.0,21.19,-.6,2.93,.46,2.93);
    block(ivory,-1.0,22.22,-.6,.78,1.75,.78);
  });
  for(const r of [26,28])cell(3,r,block=>{
    block(ivory,0,2.6,0,8.0,6.0,8.5);
    block(whiteSlate,-2.04,5.9,0,4.64,.45,9.1,0,.34);
    block(whiteSlate,2.04,5.9,0,4.64,.45,9.1,0,-.34);
    for(const z of [-2.9,-1.0,1.0,2.9])block(dark,4.03,3.21,z,.12,1.25,.42);
  });
  cell(4,27,block=>{
    block(whiteParapet,0,.2,0,9.1,.85,8.3);
    block(ivory,2.45,.72,0,3.60,.65,3.45);
    block(0x56888a,2.45,1.10,0,2.97,.12,2.72);
    block(0xe1e0d1,0,2.30,0,.24,3.55,.22);
    for(const side of [-1,1]){
      block(0xe1e0d1,side*.67,3.55,0,.18,1.98,.17,0,side*-.49);
      block(0xe1e0d1,side*1.12,4.12,.13,.14,1.38,.14,0,side*-.34);
    }
  });
}
function cityRockSpur(sample){
  const positions=[],uv=[],faces=[],colors=[];
  const rockTone=new T.Color();
  const sections=[[4,10,5.5],[5,11.2,6.5],[6,9.6,6],[7,7.8,5.3],[8,6.5,4.5],[9,4.7,2.9],[10,2.8,1.4]];
  for(const [c,width,height] of sections){
    const {x,z}=offsetToWorld(c,27), y=sample(c,27,x,z);
    for(const [dy,dz,tone] of [[-2,-width/2,0x837e74],[height*.48,-width*.30,0xa79e91],[height,0,0xd1c6b4],
      [height*.56,width*.30,0xbeb3a6],[-2,width/2,0x898174]]){
      positions.push(x,y+dy,z+dz);uv.push(x/11,(y+dy)/10+dz*.05);
      rockTone.setHex(tone);colors.push(rockTone.r,rockTone.g,rockTone.b);
    }
  }
  for(let i=0;i<sections.length-1;i++)for(let j=0;j<4;j++){
    const a=i*5+j,b=a+1;
    faces.push(a,b,a+5,b,b+5,a+5);
  }
  const tip=(sections.length-1)*5;
  faces.push(tip,tip+1,tip+2,tip,tip+2,tip+3,tip,tip+3,tip+4);
  const geo=new T.BufferGeometry();
  geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));
  geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
  geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  geo.setIndex(faces);geo.computeVertexNormals();
  const rock=new T.Mesh(geo,new T.MeshStandardMaterial({vertexColors:true,side:T.DoubleSide,roughness:1,...surfaceMaps('rock')}));
  rock.name='minas-tirith-rock-spur';rock.castShadow=true;rock.receiveShadow=true;
  return rock;
}
export function middleEarthScenery(map,region,sample){
  const group=new T.Group(),batches=new Map();
  const id=map.scenarioId,remaster=!!map.victory?.army;
  const put=(color,x,y,z,w,h,d,yaw=0,roll=0)=>{
    const list=batches.get(color)||[];
    list.push([x,y,z,w,h,d,yaw,roll]);
    batches.set(color,list);
  };
  const known=(c,r)=>contains(region,c,r)&&!map.unknown?.[index(map,c,r)];
  function cell(c,r,draw,size=1){
    if(!known(c,r))return;
    const {x,z}=offsetToWorld(c,r);
    const y=sample(c,r,x,z);
    draw((color,dx,dy,dz,w,h,d,yaw,roll)=>put(color,x+dx*size,y+dy*size,z+dz*size,w*size,h*size,d*size,yaw,roll));
  }
  const localCell=(c,r,draw)=>{
    const p=projectMiddleEarthCell(map,c,r);
    cell(p.c,p.r,draw,middleEarthScale(map.victory.layoutVersion));
  };
  function porch(c,r,side,height,color,local=false){
    (local?localCell:cell)(c,r,block=>{
      // Beveled dark opening and heavy stone jambs against the adjacent cliff.
      const west=side==='west';
      const piece=(t,a,y,b,w,h,d)=>west?block(t,b,y,a,d,h,w):block(t,a,y,b,w,h,d);
      piece(dark,0,height*.38,-3.6,6.7,height*.76,.52);
      for(const s of [-1,1]){
        piece(color,s*3.25,height*.37,-3.8,1.65,height*.75,2.15);
        piece(color,s*2.55,height*.72,-3.8,1.75,height*.25,2.15);
      }
      piece(color,0,height*.87,-3.9,4.6,height*.24,2.35);
      piece(mortar,0,height*1.02,-3.9,8.25,.62,2.72);
    });
  }
  if(id==='me_hornburg'){
    const p=map.victory.points.cave;
    porch(p.c,p.r,'west',7.9,hornburgStone);
    const compact=map.victory.layoutVersion===6;
    const keep=compact?[[20,12],[22,11],[24,11]]:[[22,13],[22,14],[23,13],[24,13],[25,13]];
    for(const [i,[c,r]] of keep.entries())localCell(c,r,block=>{
      const high=i===0,h=high?8.9:5.1;
      block(hornburgStone,0,h*.32,0,7.8,h,7.5);
      block(hornburgCap,0,h*.82,0,8,.40,7.7);
      block(hornburgStone,-.8,h*.82+2,-.5,5.4,4.0,5.2);
      block(hornburgCap,-.8,h*.82+4,-.5,5.9,.34,5.7);
      for(const x of [-3.1,-.8,1.5])for(const z of [-2.7,1.7])
        block(hornburgStone,x,h*.82+4.52,z,.62,.76,.72);
      for(const z of [-2,0,2])block(dark,3.95,h*.45,z,.14,1.2,.28);
      for(const z of [-2.55,2.55])block(hornburgStone,3.3,1.48,z,1.9,4.2,1.14);
      if(high){
        block(hornburgStone,-.8,h*.82+7,-.5,3.0,5.6,3.0);
        block(hornburgCap,-.8,h*.82+9.9,-.5,3.7,.48,3.7);
        for(const x of [-2.25,.65])for(const z of [-1.95,.95])
          block(hornburgStone,x,h*.82+10.5,z,.58,.76,.58);
      }
    });
  }
  if(id==='me_erebor'){
    porch(25,7,'north',13.2,ereborStone,true);
    for(const c of [22,23,27,28])localCell(c,7,block=>{
      block(ereborStone,0,4.3,0,8.5,10.6,7.5);
      block(ereborStone,0,10.8,0,7.7,2.6,7.1);
      block(ereborBronze,0,12.3,0,8.4,.4,7.8);
      for(const x of [-2.65,2.65]){
        block(ereborStone,x,4.9,3.65,1.22,10.8,1.12);
        block(ereborBronze,x,7.45,4.24,.64,.65,.13,0,Math.PI/4);
      }
      block(dark,0,6.3,3.77,.69,4.25,.17);
    });
  }
  if(id==='me_pelennor'&&remaster){
    group.name='minas-tirith-scenery';
    whiteCity(map,cell);
    if(known(5,27))group.add(cityRockSpur(sample));
  }else if(id==='me_pelennor'){
    for(let tier=0;tier<5;tier++){
      const c=11-tier;
      for(let r=22+tier;r<=32-tier;r++)localCell(c,r,block=>{
        block(ivory,0,1.42,0,6.5,3.8,9.4);
        if((r+tier)%2===0)block(0x82706e,0,3.58,0,6.3,.55,8.4);
        for(const z of [-3.4,0,3.4])block(stone,2.7,3.39,z,.55,.7,1.0);
      });
    }
    localCell(6,27,block=>{
      block(ivory,0,5,0,3.4,11,3.2);
      block(ivory,0,11,0,4.5,1.8,4.3);
      block(mortar,0,12,0,3.4,.62,3.2);
    });
  }
  if(id==='me_pelargir'){
    for(const key of ['dock0','dock1','dock2']){
      const p=map.victory.points[key];
      cell(p.c,p.r,block=>{
        block(mortar,-3.2,.22,0,7.9,1.4,8.4);
        block(sand,-3.2,1.05,0,7.9,.3,8.5);
        for(const z of [-3.8,3.8]){
          block(0x624c39,-1.2,1.35,z,.48,1.6,.48);
          block(0x624c39,2.8,.46,z,4.9,.27,.24);
        }
      });
    }
  }
  const origin=id==='me_pelennor'?projectMiddleEarthCell(map,0,0):{c:0,r:0};
  for(let r=region.r0;r<region.r1;r++)for(let c=region.c0;c<region.c1;c++){
    if(map.houses[index(map,c,r)])cell(c,r,block=>{
      const variation=(c+3*r)%4;
      const yaw=(variation-1.5)*.12;
      if(id==='me_erebor'){
        block(stone,-.5,.24,0,7.1,.48,6.6,yaw);
        block(mortar,-3.1,.90,0,.65,1.8,5.3,yaw);
        block(stone,-1.65,.95,-2.42,3.7,1.9,.62,yaw);
        block(stone,1.88,.49,2.07,2.6,.99,.67,-yaw);
        block(0x72574a,1.9,.63,-1.8,2.9,.20,2.2,yaw,.32);
        for(let k=0;k<4;k++)block(k%2?mortar:sand,(k-2)*.73,.32+(k%2)*.19,1.4-Math.sin(k)*.7,.74,.54,.72,k*.83);
      }else{
        const tall=(id==='me_pelargir'?3.35:2.7)+(remaster?(variation-1.5)*.22:0);
        block(sand,0,tall*.5,-.25,6.3,tall,5.1,yaw);
        block(0x71554a,-1.46,tall+.37,-.25,3.43,.25,5.75,yaw,.28);
        block(0x71554a,1.46,tall+.37,-.25,3.43,.25,5.75,yaw,-.28);
        block(dark,0,.89,2.33,1.05,1.72,.15,yaw);
        if(remaster){
          for(const x of [-1.85,1.85]){
            block(0x79563c,x,tall*.61,2.34,.74,.70,.13,yaw);
            block(dark,x,tall*.63,2.42,.47,.48,.08,yaw);
          }
          block(0x79563c,0,tall-.12,2.34,6.4,.16,.18,yaw);
        }
        if(id==='me_pelargir')for(const x of [-2.8,2.7])block(0x79563c,x,.53,3.36,.91,.95,.78,yaw);
      }
    });
    const s=middleEarthScale(map.victory.layoutVersion);
    const x=(c-origin.c)/s,y=(r-origin.r)/s;
    if(id==='me_pelennor'&&map.terrain[index(map,c,r)]===TERRAIN.PLAIN&&
      ((x>=24&&x<=29&&y>=9&&y<=14)||(x>=33&&x<=37&&y>=22&&y<=26))){
      cell(c,r,block=>{
        for(const z of [-2.8,0,2.8])block(0x89804e,0,.07,z,8.9,.1,.87,.12);
        if((c+r)%3===0)for(const x of [-2.7,2.7]){
          block(0x68533b,x,.82,0,.29,1.64,.3);
          block(0x526140,x,1.69,0,1.34,1.2,1.57,.35);
        }
      });
    }
  }
  const transform=new T.Object3D();
  for(const [color,blocks] of batches){
    const finish=remaster?([ivory,whiteParapet].includes(color)?'stone':[0x82706e,whiteSlate].includes(color)?'slate':color===0x71554a?'clay':
      [0x79563c,0x624c39].includes(color)||id==='me_pelargir'&&color===sand?'wood':
      [mortar,stone,sand,hornburgStone,hornburgCap,ereborStone].includes(color)?'stone':null):null;
    const tint=finish?([ivory,whiteParapet].includes(color)?0xeeeae3:finish==='clay'?0xcdada1:finish==='slate'?0xc3c2bf:
      color===sand?0xd8b38a:color===mortar?0xad9d8e:color===stone?0xc1ae9d:color):color;
    const material=new T.MeshStandardMaterial({color:tint,roughness:.94,...(finish?surfaceMaps(finish):{})});
    if(finish)projectConstructionMaps(material,finish==='stone'?6.4:4.5);
    const mesh=new T.InstancedMesh(new T.BoxGeometry(),material,blocks.length);
    blocks.forEach(([x,y,z,w,h,d,yaw,roll],i)=>{
      transform.position.set(x,y,z);transform.scale.set(w,h,d);transform.rotation.set(0,yaw,roll);
      transform.updateMatrix();mesh.setMatrixAt(i,transform.matrix);
    });
    mesh.name='middle-earth-architecture';
    mesh.receiveShadow=true;mesh.castShadow=true;
    group.add(mesh);
  }
  return group;
}
