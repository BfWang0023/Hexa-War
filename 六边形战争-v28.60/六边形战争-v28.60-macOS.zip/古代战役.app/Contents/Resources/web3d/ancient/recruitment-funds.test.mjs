import test from 'node:test';
import assert from 'node:assert/strict';
import {mapFor} from '../../tools/ai-training/maps.mjs';
import {startGame,recruitLogistics,recruit,LOGISTICS_COSTS,canPlaceKind,exportMap,importMap,attackPreview,distance} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
const ids=['china_changping','china_qin_chu','china_seven_states','china_longxi'];
function setup(id,team){const s=startGame(mapFor(id));s.side=team;s.map.logistics.routes[team]=[s.map.logistics.depots[team][0]];return s;}
for(const id of ids)for(const team of ['egypt','coalition']){
 test(`${id}/${team}: insufficient/zero/negative money rejects every recruit without changing balance or units`,()=>{
  for(const kind of ['light','heavy','archer','chinaCrossbow','cavalry','guard','moraleGuard','supplyWagon','siegeRam'])for(const funds of [-100,0,1]){
   const s=setup(id,team);s.money[team]=funds;const count=s.map.units.length,before=JSON.stringify(exportMap(s.map));assert.equal(recruitLogistics(s,kind).ok,false,kind);assert.equal(s.money[team],funds);assert.equal(s.map.units.length,count);assert.equal(JSON.stringify(exportMap(s.map)),before);
  }
 });
 test(`${id}/${team}: both sides may buy a ram with exact funds and preserve map/save legality`,()=>{
  const s=setup(id,team),price=LOGISTICS_COSTS.siegeRam;assert.ok(Number.isInteger(price)&&price>0);assert.equal(canPlaceKind('siegeRam',team,id),true);s.money[team]=price;
  const r=recruitLogistics(s,'siegeRam');assert.equal(r.ok,true,r.reason);assert.equal(r.cost,price);assert.equal(r.unit.team,team);assert.equal(r.unit.actionsLeft,0);assert.equal(r.unit.kind,'siegeRam');assert.equal(s.money[team],0);assert.ok(s.map.logistics.musters[team].some(p=>distance(p,r.unit)<=1));
  const before=s.map.units.length;assert.equal(recruitLogistics(s,'light').ok,false);assert.equal(s.money[team],0);assert.equal(s.map.units.length,before);
  const m=importMap(exportMap(s.map));assert.ok(m.units.some(u=>u.id===r.unit.id&&u.kind==='siegeRam'));
  const restored=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,team)))).game;assert.equal(restored.money[team],0);assert.ok(restored.map.units.some(u=>u.id===r.unit.id&&u.kind==='siegeRam'));
 });
}
test('sequential purchases stop at available funds and never borrow or overshoot',()=>{
 const s=setup(ids[0],'egypt');s.money.egypt=LOGISTICS_COSTS.light*2;assert.ok(recruitLogistics(s,'light').ok);assert.ok(recruitLogistics(s,'light').ok);const count=s.map.units.length;assert.equal(s.money.egypt,0);for(let i=0;i<4;i++)assert.equal(recruitLogistics(s,'light').ok,false);assert.equal(s.map.units.length,count);assert.equal(s.money.egypt,0);
});
test('invalid money types cannot bypass the payment guard',()=>{
 for(const funds of [NaN,Infinity,-Infinity,undefined,null,'100',{}]){const s=setup(ids[0],'egypt');s.money.egypt=funds;const count=s.map.units.length;assert.equal(recruitLogistics(s,'heavy').ok,false);assert.equal(s.map.units.length,count);assert.ok(Object.is(s.money.egypt,funds));}
});
test('Troy recruitment uses the same no-credit restriction',()=>{
 for(const team of ['egypt','coalition'])for(const funds of [-1,0,NaN,Infinity]){
  const s=startGame(mapFor('troy'));s.deploying=false;s.side=team;s.money[team]=funds;const count=s.map.units.length;assert.equal(recruit(s,'light').ok,false);assert.equal(s.map.units.length,count);assert.ok(Object.is(s.money[team],funds));
 }
});
test('ram purchase remains blocked by cut supply routes, wrong side, deployment or a finished battle',()=>{
 for(const change of [s=>s.over=true,s=>s.deploying=true,s=>s.side='coalition',s=>{const foe=s.map.units.find(u=>u.team==='coalition'&&u.hp>0&&!['fort','supplyWagon'].includes(u.kind));const p=s.map.logistics.routes.egypt[0];foe.c=p.c;foe.r=p.r;}]){
  const s=setup(ids[0],'egypt');s.money.egypt=1000;change(s);const count=s.map.units.length;assert.equal(recruitLogistics(s,'siegeRam','egypt').ok,false);assert.equal(s.money.egypt,1000);assert.equal(s.map.units.length,count);
 }
});
test('rams retain siege-only targeting and other campaign faction restrictions',()=>{
 const s=setup(ids[0],'coalition');s.money.coalition=1000;const r=recruitLogistics(s,'siegeRam');assert.ok(r.ok);r.unit.actionsLeft=2;
 const neighbor=s.map.units.find(u=>u.team==='egypt'&&u.hp>0&&!['fort','supplyWagon'].includes(u.kind));neighbor.c=r.unit.c+1;neighbor.r=r.unit.r;assert.equal(attackPreview(s,r.unit,neighbor.c,neighbor.r),null);
 assert.equal(canPlaceKind('siegeRam','coalition','troy'),false);assert.equal(canPlaceKind('siegeRam','coalition','china_kunyang'),true);assert.equal(canPlaceKind('siegeRam','coalition','china_handan'),false);
});

for(const id of ids)for(const team of ['egypt','coalition']){
 test(`${id}/${team}: equipment prices, independent three-round limits and exact funds`,async()=>{
  const {recruitmentWait}=await import('./engine.mjs');const s=setup(id,team);s.money[team]=10000;
  for(const [kind,cost] of [['chinaHeavyChariot',150],['siegeRam',120]]){
   assert.equal(LOGISTICS_COSTS[kind],cost);const initial=s.money[team],r=recruitLogistics(s,kind);assert.ok(r.ok,r.reason);assert.equal(initial-s.money[team],cost);assert.equal(recruitmentWait(s,kind),3);
   const count=s.map.units.length,after=s.money[team];for(let i=0;i<3;i++)assert.equal(recruitLogistics(s,kind).ok,false);assert.equal(s.map.units.length,count);assert.equal(s.money[team],after);
   // Free only the test recruit's muster cell, without changing the cooldown.
   r.unit.hp=0;
  }
  for(const turn of [2,3]){s.turn=turn;for(const kind of ['chinaHeavyChariot','siegeRam'])assert.equal(recruitLogistics(s,kind).ok,false);}
  s.turn=4;for(const kind of ['chinaHeavyChariot','siegeRam']){const r=recruitLogistics(s,kind);assert.ok(r.ok,r.reason);r.unit.hp=0;assert.equal(s.recruitmentReadyTurn[team][kind==='siegeRam'?'siegeRam':'chariot'],7);}
 });
 test(`${id}/${team}: equipment cooldown survives save restore and failed purchases do not start it`,()=>{
  const s=setup(id,team);s.money[team]=119;assert.equal(recruitLogistics(s,'siegeRam').ok,false);assert.equal(s.recruitmentReadyTurn,undefined);
  s.money[team]=120;assert.ok(recruitLogistics(s,'siegeRam').ok);s.money[team]=10000;
  const data=JSON.parse(JSON.stringify(createSave(s.map,s,team))),restored=restoreSave(data).game;assert.equal(recruitLogistics(restored,'siegeRam').ok,false);assert.equal(restored.money[team],10000);restored.turn=3;assert.equal(recruitLogistics(restored,'siegeRam').ok,false);restored.turn=4;assert.ok(recruitLogistics(restored,'siegeRam').ok);
 });
}
test('equipment limits are per faction; ordinary troops remain unrestricted',()=>{
 const s=setup(ids[0],'egypt');for(const team of ['egypt','coalition']){s.side=team;s.map.logistics.routes[team]=[s.map.logistics.depots[team][0]];s.money[team]=1000;assert.ok(recruitLogistics(s,'siegeRam').ok);assert.ok(recruitLogistics(s,'light').ok);assert.ok(recruitLogistics(s,'light').ok);}
});
test('blocked muster does not spend money or start equipment cooldown',()=>{
 const s=setup(ids[0],'egypt');s.money.egypt=1000;s.map.logistics.musters.egypt=[];assert.equal(recruitLogistics(s,'siegeRam').ok,false);assert.equal(s.money.egypt,1000);assert.equal(s.recruitmentReadyTurn,undefined);
});
test('old saves without recruitment cooldown remain compatible; invalid cooldown data is rejected',()=>{
 const s=setup(ids[0],'egypt'),data=JSON.parse(JSON.stringify(createSave(s.map,s,'egypt')));assert.ok(restoreSave(data));
 for(const bad of [null,[],{enemy:{siegeRam:4}},{egypt:{light:4}},{egypt:{siegeRam:-1}},{egypt:{siegeRam:5}},{egypt:{chariot:'4'}}]){const slot=structuredClone(data);slot.game.recruitmentReadyTurn=bad;assert.throws(()=>restoreSave(slot),/召集间隔/);}
});
test('Troy chariot variants cost 150 even in old maps and share the three-round vehicle limit',async()=>{
 const {recruitmentCost,recruitmentWait}=await import('./engine.mjs');
 for(const [team,kind] of [['egypt','chariot'],['coalition','hittiteChariot']]){
  const s=startGame(mapFor('troy'));s.deploying=false;s.side=team;s.money[team]=149;s.map.recruitment.costs[kind]=18;assert.equal(recruitmentCost(s,kind),150);assert.equal(recruit(s,kind).ok,false);assert.equal(s.money[team],149);
  if(team==='egypt'){s.money[team]=1000;const at=s.map.recruitment.muster.egypt.sea;s.map.units=s.map.units.filter(u=>u.c!==at.c||u.r!==at.r);assert.ok(recruit(s,'transport').ok);}else{const at=s.map.recruitment.muster.coalition.land;s.map.units=s.map.units.filter(u=>u.c!==at.c||u.r!==at.r);}
  s.money[team]=150;const r=recruit(s,kind);assert.ok(r.ok,r.reason);assert.equal(r.cost,150);assert.equal(s.money[team],0);assert.equal(recruitmentWait(s,'chariot'),3);assert.equal(recruitmentWait(s,'hittiteChariot'),3);s.money[team]=1000;assert.equal(recruit(s,kind).ok,false);
  const restored=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,team)))).game;assert.equal(recruit(restored,kind).ok,false);assert.equal(recruitmentWait(restored,kind),3);
 }
});
test('equipment cooldown advances on full rounds, not on each side turn',async()=>{
 const {endSide,recruitmentWait}=await import('./engine.mjs');const s=setup(ids[0],'egypt');s.money.egypt=120;assert.ok(recruitLogistics(s,'siegeRam').ok);for(let turn=1;turn<=3;turn++){assert.equal(s.turn,turn);endSide(s);assert.equal(s.turn,turn);assert.equal(recruitmentWait(s,'siegeRam','egypt'),4-turn);endSide(s);assert.equal(s.turn,turn+1);}assert.equal(recruitmentWait(s,'siegeRam','egypt'),0);
});
