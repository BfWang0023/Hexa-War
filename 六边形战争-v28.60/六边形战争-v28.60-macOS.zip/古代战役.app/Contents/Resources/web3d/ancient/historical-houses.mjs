import * as T from '../vendor/three/three.module.js';
import {offsetToWorld} from '../js/core/hex.js';
import {projectConstructionMaps,surfaceMaps} from './middle-earth-materials.mjs';

export function createHistoricalHouses(map,region,sample){
  const group=new T.Group(),pieces=new Map();
  group.name='historical-houses';
  const clayRoof=map.scenarioId==='troy'||map.scenarioId?.startsWith('china_')||
    ['salamis','tyre','carthage','syracuse','jerusalem'].includes(map.scenarioId);
  const finishes={
    stone:{color:clayRoof?0xd6c2a4:0xc6aa87,texture:'stone',period:6.4},
    roof:{color:clayRoof?0xb07a63:0xb89c72,texture:clayRoof?'clay':'wood',period:4.5},
    trim:{color:0x9c7955,texture:'wood',period:4.5},
    opening:{color:0x40372d},
  };
  for(let r=region.r0;r<region.r1;r++)for(let c=region.c0;c<region.c1;c++){
    const index=r*map.cols+c;
    if(!map.houses?.[index]||map.unknown?.[index])continue;
    const {x,z}=offsetToWorld(c,r),y=sample(c,r,x,z);
    const variant=(c*3+r*5)%4,height=1.85+variant*.14;
    const yaw=(variant-1.5)*.09,cos=Math.cos(yaw),sin=Math.sin(yaw);
    const add=(finish,dx,dy,dz,width,h,depth,tilt=0)=>{
      if(!pieces.has(finish))pieces.set(finish,[]);
      pieces.get(finish).push({
        position:[x+cos*dx+sin*dz,y+dy,z-sin*dx+cos*dz],
        size:[width,h,depth],yaw,tilt,
      });
    };
    add('stone',0,height/2-.12,0,6.4,height+.24,5.25);
    add('stone',0,.1,0,6.65,.42,5.55);
    add('trim',0,height-.14,0,6.75,.20,5.59);
    if(clayRoof){
      for(const side of [-1,1])add('roof',0,height+.39,side*1.57,7.12,.23,3.34,side*.24);
      add('roof',0,height+.81,0,7.17,.24,.33);
      add('trim',0,height+.25,0,6.3,.47,4.12);
    }else{
      add('roof',0,height+.13,0,7.15,.25,5.97);
      for(const side of [-1,1])add('trim',0,height+.25,side*2.81,7.1,.26,.18);
    }
    add('opening',0,.77,2.648,.82,1.52,.065);
    add('trim',0,1.57,2.68,1.15,.18,.14);
    for(const dx of [-1.89,1.89]){
      add('opening',dx,height*.64,2.652,.53,.53,.07);
      add('trim',dx,height*.64-.29,2.69,.77,.12,.15);
    }
  }
  const transform=new T.Object3D();
  for(const [finish,instances] of pieces){
    const {color,texture,period}=finishes[finish];
    const material=new T.MeshStandardMaterial({color,roughness:.94,...(texture?surfaceMaps(texture):{})});
    if(texture)projectConstructionMaps(material,period);
    const mesh=new T.InstancedMesh(new T.BoxGeometry(),material,instances.length);
    mesh.name='historical-house-'+finish;
    mesh.castShadow=finish!=='opening';
    mesh.receiveShadow=true;
    instances.forEach(({position,size,yaw,tilt},i)=>{
      transform.position.set(...position);
      transform.scale.set(...size);
      transform.rotation.set(0,yaw,0);
      transform.rotateX(tilt);
      transform.updateMatrix();
      mesh.setMatrixAt(i,transform.matrix);
    });
    mesh.instanceMatrix.needsUpdate=true;
    group.add(mesh);
  }
  return group;
}
