import {validateMiddleEarthSave} from './middle-earth-rules.mjs';
import {validateMutiny} from './mutiny.mjs';
import {validateGrowth} from './unit-growth.mjs';
import {validateLogisticsPlan} from './logistics-plan.mjs';
import {validateRamState} from './naval-ram.mjs';
import {validateDelegatedOrders} from './delegated-orders.mjs';
import {validateCaptureState} from './fortification-capture.mjs';
import {validateEnding} from './battle-ending.mjs';
import {usesChargeRules,validateChargeState} from './charge-rules.mjs';
import {fogPolicy} from './fog-policy.mjs';
import {validateAutoElevation} from './auto-elevation.mjs';
import {validateRecon} from './reconnaissance.mjs';
import { ruleConfig, validateElevations, RULES_VERSION } from './elevation-rules.mjs';
import { STATS, unitStats, SUPPLY_WAGON_CAPACITY, TERRAIN, MORALE_GUARD_SCENARIOS, addUnit, applyCampaignFinances, carriedRationCapacity, ensureMoraleGuards, expandLogisticsConvoys,
  exportMap, importMap, inBounds, isRouted, mobileAt, recomputeFog, unitMaxHp } from './engine.mjs';
import { makeChinaMap } from './china-campaigns.mjs';
import { makeImperialMap } from './imperial-campaigns.mjs';

export const SAVE_FORMAT = 'hex_wargame.ancient.save.v1';

export const BATTLE_MODES = Object.freeze(['human-ai', 'human-human', 'ai-ai']);

const knowledgeTeams=['egypt','coalition'];

function packKnowledge(knowledge,cols){
  return Object.fromEntries(knowledgeTeams.map(team=>[team,Object.entries(knowledge[team]).map(([key,v])=>{
    const [c,r]=key.split(',').map(Number);
    const cell=[r*cols+c,v.terrain,v.height];
    if(v.house||v.bridge||v.forts.length||v.landmarks.length||v.supplyPoints.length)
      cell.push(v.house,v.bridge?1:0,v.forts,v.landmarks,v.supplyPoints);
    return cell;
  })]));
}

function unpackKnowledge(knowledge,map){
  return Object.fromEntries(knowledgeTeams.map(team=>{
    if(!Array.isArray(knowledge?.[team])||knowledge[team].length>map.cols*map.rows)
      throw Error('存档地形情报无效');
    const cells={};
    for(const row of knowledge[team]){
      if(!Array.isArray(row)||![3,8].includes(row.length))throw Error('存档地形情报无效');
      const [i,terrain,height,house=0,bridge=0,forts=[],landmarks=[],supplyPoints=[]]=row;
      if(!Number.isInteger(i)||i<0||i>=map.cols*map.rows||!Number.isInteger(terrain)||terrain<0||terrain>16||
        !Number.isFinite(height)||![0,1].includes(house)||![0,1].includes(bridge)||
        ![forts,landmarks,supplyPoints].every(Array.isArray))throw Error('存档地形情报无效');
      const key=`${i%map.cols},${Math.floor(i/map.cols)}`;
      if(Object.hasOwn(cells,key))throw Error('存档地形情报重复');
      cells[key]={terrain,height,house,bridge:!!bridge,forts,landmarks,supplyPoints};
    }
    return [team,cells];
  }));
}

export function createSave(scenario, game, playerTeam, camera = null, hiddenLogIndices = [], battleMode = 'human-ai') {
  if (!['egypt', 'coalition'].includes(playerTeam)) throw new Error('操控阵营无效');
  if (!BATTLE_MODES.includes(battleMode)) throw new Error('交战模式无效');
  const large=game.map.victory?.layoutVersion>=3&&game.mapKnowledge;
  return {
    format: SAVE_FORMAT,
    rulesVersion: game.rulesVersion ?? 10,
    savedAt: new Date().toISOString(),
    scenarioName: scenario.name,
    scenarioId: scenario.scenarioId,
    turn: game.turn,
    playerTeam,
    battleMode,
    scenario: exportMap(scenario),
    game: {
      ...game,
      ...(large?{mapKnowledge:packKnowledge(game.mapKnowledge,game.map.cols),mapKnowledgeFormat:1}:{}),
      map: { ...game.map, terrain: Array.from(game.map.terrain), houses: Array.from(game.map.houses) },
      fog: Object.fromEntries(['egypt', 'coalition'].map(team =>
        [team, { explored: Array.from(game.fog[team].explored) }]))
    },
    camera,
    hiddenLogIndices: Array.from(hiddenLogIndices),
  };
}

export function restoreSave(data) {
  if (data?.format !== SAVE_FORMAT || !['egypt', 'coalition'].includes(data.playerTeam))
    throw new Error('不是支持的古代战役存档');
  if (data.battleMode !== undefined && !BATTLE_MODES.includes(data.battleMode))
    throw new Error('存档中的交战模式无效');
  const scenario = importMap(data.scenario);
  let game = data.game;
  if(game?.mapKnowledgeFormat!==undefined){
    if(game.mapKnowledgeFormat!==1||!(scenario.victory.layoutVersion>=3))throw Error('存档地形情报版本无效');
    const {mapKnowledgeFormat,...plain}=game;
    game={...plain,mapKnowledge:unpackKnowledge(game.mapKnowledge,scenario)};
  }
  validateMiddleEarthSave(scenario,game);
  if(game?.scoutDetectionRadius!==undefined&&game.scoutDetectionRadius!==3)throw Error('斥候隐蔽规则配置无效');
  if(game?.fogPolicy){fogPolicy(game.fogPolicy);if(!game.mapKnowledge?.egypt||!game.mapKnowledge?.coalition||!game.enemyIntel?.egypt||!game.enemyIntel?.coalition)throw Error("存档缺少阵营情报");}
  if(game){validateEnding(game);validateCaptureState(game);}
  const map = game?.map;
  if(map?.riverCrossing!==undefined&&map.riverCrossing!==1)throw Error('涉水规则版本无效');
  if(game){validateDelegatedOrders(game);validateLogisticsPlan(game);}
  const activeRules = data.rulesVersion ?? 1;
  if(activeRules<19&&map?.units.some(u=>u.facing!==undefined&&!Number.isInteger(u.facing)))throw Error('旧规则存档不支持30度朝向');
  if(activeRules>=14&&!game?.fogPolicy)throw Error('新版存档缺少迷雾规则');
  if (!Number.isInteger(activeRules) || activeRules < 1 || activeRules > RULES_VERSION) throw Error('不支持的存档规则版本');
  if (activeRules >= 11 && (game?.rulesVersion !== activeRules || !map?.elevations || !game?.elevationRules)) throw Error('新版存档缺少逻辑高程或规则参数');
  validateRamState(game);
  if(activeRules>=15){if(!game?.chargeRules)throw Error('新版存档缺少冲锋规则');validateChargeState(game);}
  if (map) {validateElevations(map);validateAutoElevation(map);validateRecon(game);}
  if(activeRules>=13&&!map?.autoElevation&&!(map?.victory?.mode==='middle-earth'&&map.victory.layoutVersion>=2))throw Error("新版存档缺少自动高程版本");
  const elevationRules = ruleConfig(game?.elevationRules);
  if (!map || map.scenarioId !== scenario.scenarioId || map.cols !== scenario.cols || map.rows !== scenario.rows ||
      !Array.isArray(map.terrain) || map.terrain.length !== map.cols * map.rows ||
      !Array.isArray(map.houses) || map.houses.length !== map.cols * map.rows ||
      map.terrain.some(n => !Number.isInteger(n) || n < 0 || n > 255) ||
      map.houses.some(n => n !== 0 && n !== 1) ||
      (map.bridges !== undefined && (!Array.isArray(map.bridges) || map.bridges.some((p, i) =>
        !inBounds(map, p?.c, p?.r) ||
        (map.terrain[p.r * map.cols + p.c] & (TERRAIN.ROAD | TERRAIN.RIVER)) !== (TERRAIN.ROAD | TERRAIN.RIVER) ||
        map.bridges.findIndex(q => q.c === p.c && q.r === p.r) !== i))) ||
      !Array.isArray(map.units) || map.units.length > 10000 ||
      !Number.isInteger(game.turn) || game.turn < 1 || game.turn > 100000 ||
      !['egypt', 'coalition'].includes(game.side) ||
      (game.aiDifficulty !== undefined && !['easy', 'normal', 'hard'].includes(game.aiDifficulty)) ||
      typeof game.deploying !== 'boolean' || typeof game.over !== 'boolean' ||
      !Array.isArray(game.log) || game.log.some(s => typeof s !== 'string') ||
      (game.logOwners !== undefined && (!Array.isArray(game.logOwners) ||
        game.logOwners.length > game.log.length ||
        game.logOwners.some(owner => owner !== null && owner !== 'egypt' && owner !== 'coalition'))))
    throw new Error('存档中的战场数据无效');
  // Optional additive state: old saves without equipment recruitment remain valid.
  const cooldown = game.recruitmentReadyTurn;
  if (cooldown !== undefined && (!cooldown || typeof cooldown !== 'object' || Array.isArray(cooldown) ||
      Object.entries(cooldown).some(([team, entries]) => !['egypt', 'coalition'].includes(team) ||
        !entries || typeof entries !== 'object' || Array.isArray(entries) ||
        Object.entries(entries).some(([kind, turn]) => !['chariot', 'siegeRam'].includes(kind) ||
          !Number.isSafeInteger(turn) || turn < 1 || turn > game.turn + 3))))
    throw new Error('存档中的装备召集间隔无效');
  if(game.growthRules!==undefined&&game.growthRules!==1)throw Error('成长规则版本无效');
  if(game.mutinyState){const state=game.mutinyState;if(state.version!==1||!Number.isInteger(state.random)||state.random<0||state.random>4294967295||!Number.isInteger(state.lastTurn)||!Array.isArray(state.pending))throw Error('哗变随机状态无效');}
  validateMutiny(game);
  const ids = new Set();
  for (const u of map.units) {
    validateGrowth(u);
    if (!STATS[u.kind] || !['egypt', 'coalition'].includes(u.team) || !inBounds(map, u.c, u.r) ||
        typeof u.id !== 'string' || !/^u\d+$/.test(u.id) || ids.has(u.id) || !Number.isFinite(u.hp) ||
        !Number.isFinite(u.actionsLeft)) throw new Error('存档中的棋子数据无效');
    if (u.wagonCaptureLoss !== undefined && (u.kind !== 'supplyWagon' || !Number.isInteger(u.wagonCaptureLoss) ||
        u.wagonCaptureLoss < 0 || u.wagonCaptureLoss > unitStats(scenario, u).hp)) throw new Error('存档中的粮车争夺损耗无效');
    ids.add(u.id);
  }
  const restored = {
    ...game,
    rulesVersion: activeRules <= 10 ? 10 : activeRules, elevationRules,
    ...(cooldown === undefined ? {} : { recruitmentReadyTurn: structuredClone(cooldown) }),
    aiDifficulty: game.aiDifficulty ?? 'normal',
    map: { ...map, terrain: Uint8Array.from(map.terrain), houses: Uint8Array.from(map.houses), bridges: map.bridges || [],
      unitStats: structuredClone(scenario.unitStats || {}) },
    fog: Object.fromEntries(['egypt', 'coalition'].map(team => {
      const explored = game.fog?.[team]?.explored;
      if (!Array.isArray(explored) || explored.some(k => typeof k !== 'string' || !/^\d+,\d+$/.test(k)))
        throw new Error('存档中的视野数据无效');
      return [team, { visible: new Set(), explored: new Set(explored) }];
    })),
  };
  // Rebuild rule thresholds from the saved scenario so older slots use the
  // current campaign-specific rout rule without changing the played unit state.
  restored.map.victory = structuredClone(scenario.victory);
  if ((data.rulesVersion ?? 1) < 2 && scenario.scenarioId?.startsWith('china_')) {
    for (const u of restored.map.units) {
      const oldMaxHp = u.kind === 'chinaCrossbow' ? 85 : STATS[u.kind].hp;
      const newMaxHp = unitMaxHp(restored.map, u);
      if (u.hp > 0 && newMaxHp !== oldMaxHp)
        u.hp = Math.max(1, Math.min(newMaxHp, u.hp + newMaxHp - oldMaxHp));
      if (u.kind === 'chinaCrossbow') u.ammo = STATS.chinaCrossbow.ammo;
    }
  }
  if ((data.rulesVersion ?? 1) < 3 && ['china_changping', 'china_qin_chu'].includes(scenario.scenarioId) &&
      !restored.map.logistics) {
    const latest = makeChinaMap(scenario.scenarioId);
    for (const map of [scenario, restored.map]) {
      map.logistics = structuredClone(latest.logistics);
      for (const wagon of latest.units.filter(u => u.kind === 'supplyWagon')) {
        let placed = false;
        for (let radius = 0; radius <= 5 && !placed; radius++) for (let dr = -radius; dr <= radius && !placed; dr++)
          for (let dc = -radius; dc <= radius && !placed; dc++) {
            const c = wagon.c + dc, r = wagon.r + dr;
            if (Math.max(Math.abs(dc), Math.abs(dr)) !== radius || !inBounds(map, c, r) || mobileAt(map, c, r)) continue;
            if (addUnit(map, 'supplyWagon', wagon.team, c, r)) {
              const created = map.units.at(-1);
              created.supplyStock = SUPPLY_WAGON_CAPACITY; created.supplyTravel = 0; created.actionsLeft = 0;
              placed = true;
            }
          }
      }
      for (const u of map.units.filter(u => u.kind !== 'fort' && u.kind !== 'supplyWagon')) {
        u.hunger ??= 0; u.fedTurns ??= 0; u.maxHungerTurns ??= 0;
      }
    }
    restored.money ??= { ...latest.logistics.startingMoney };
    restored.log.push('旧存档已加入财政、粮秣运输队与饥饿规则。');
  }
  if ((data.rulesVersion ?? 1) < 4 &&
      ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi'].includes(scenario.scenarioId)) {
    const latest = ['china_changping', 'china_qin_chu'].includes(scenario.scenarioId) ?
      makeChinaMap(scenario.scenarioId) : makeImperialMap(scenario.scenarioId);
    for (const map of [scenario, restored.map]) {
      map.logistics ??= structuredClone(latest.logistics);
      map.logistics.income = { ...latest.logistics.income };
      for (const wagon of map.units.filter(u => u.kind === 'supplyWagon' && u.hp > 0))
        wagon.supplyStock = Math.min(SUPPLY_WAGON_CAPACITY, (wagon.supplyStock || 0) + 12);
      expandLogisticsConvoys(map);
    }
    for (const u of restored.map.units.filter(u => u.kind !== 'fort' && u.kind !== 'supplyWagon' && u.hp > 0)) {
      u.hunger = 0; u.hungerClock = 0; u.fedTurns = 3; u.maxHungerTurns = 0;
      if (u.starvedRouted) {
        u.starvedRouted = false;
        if (typeof u.morale === 'number') u.morale = Math.max(u.morale, 0.4);
      }
    }
    restored.money ??= { ...latest.logistics.startingMoney };
    for (const team of ['egypt', 'coalition'])
      restored.money[team] = Math.max(restored.money[team] || 0,
        Math.floor(latest.logistics.startingMoney[team] / 2));
    restored.log.push('旧存档已按新版粮秣节奏调整，并为部队补发口粮。');
  }
  if ((data.rulesVersion ?? 1) < 5 &&
      ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi'].includes(scenario.scenarioId)) {
    for (const u of restored.map.units.filter(u => u.hp > 0 && !['fort', 'supplyWagon'].includes(u.kind))) {
      u.hunger = 0; u.hungerClock = 0; u.fedTurns = 10; u.maxHungerTurns = 0;
      if (u.starvedRouted) {
        u.starvedRouted = false;
        if (typeof u.morale === 'number') u.morale = Math.max(u.morale, 0.4);
      }
    }
    restored.log.push('旧存档已恢复口粮与饥饿状态。');
  }
  if ((data.rulesVersion ?? 1) < 6 &&
      ['china_changping', 'china_qin_chu', 'china_seven_states', 'china_longxi'].includes(scenario.scenarioId)) {
    for (const map of [scenario, restored.map]) for (const u of map.units) {
      if (u.kind === 'cavalry' && (
          scenario.scenarioId === 'china_changping' && u.team === 'egypt' &&
            ['秦军北路后队', '秦军南路后队'].includes(u.formation) ||
          scenario.scenarioId === 'china_seven_states' && u.team === 'coalition' &&
            u.formation === '周亚夫断粮骑兵')) u.deepRaider = true;
    }
    for (const u of restored.map.units.filter(u => u.hp > 0 && !['fort', 'supplyWagon'].includes(u.kind))) {
      const capacity = carriedRationCapacity(u);
      u.fedTurns = u.deepRaider ? capacity : Math.min(Math.max(0, u.fedTurns || 0), capacity);
    }
    restored.log.push('旧存档随身口粮上限已调整：普通部队三回合，绕后奇兵十回合。');
  }
  if ((data.rulesVersion ?? 1) < 7) {
    const routed = restored.map.units.filter(u => u.hp > 0 && !u.uncontrolled && isRouted(u));
    for (const u of routed) {
      u.routed = true; u.hp = Math.min(u.hp, 10); u.ammo = 0; u.actionsLeft = 0;
    }
    if (routed.length) restored.log.push('旧存档溃逃部队已按生命 1.0、无攻防的新规则转换。');
  }
  if ((data.rulesVersion ?? 1) < 8 && MORALE_GUARD_SCENARIOS.has(scenario.scenarioId)) {
    for (const map of [scenario, restored.map]) for (const team of ['egypt', 'coalition']) {
      if (map.units.some(u => u.team === team && u.kind === 'moraleGuard')) continue;
      const leader = map.units.find(u => u.team === team && u.kind === 'chinaGeneral' && u.hp > 0);
      const anchor = leader || map.units.find(u => u.team === team && u.hp > 0 && u.kind !== 'fort');
      if (!anchor) continue;
      let placed = false;
      for (let radius = 1; radius <= 5 && !placed; radius++) for (let dr = -radius; dr <= radius && !placed; dr++)
        for (let dc = -radius; dc <= radius && !placed; dc++) {
          const c = anchor.c + dc, r = anchor.r + dr;
          if (Math.max(Math.abs(dc), Math.abs(dr)) !== radius || !inBounds(map, c, r) || mobileAt(map, c, r)) continue;
          if (addUnit(map, 'moraleGuard', team, c, r)) {
            const guard = map.units.at(-1);
            guard.formation = `${map.factions[team]}后方督战队`;
            if (map === restored.map) guard.actionsLeft = 0;
            placed = true;
          }
        }
    }
    restored.log.push('旧存档已加入督战队与士气休整规则。');
  }
  if ((data.rulesVersion ?? 1) < 9) {
    const scenarioAdded = ensureMoraleGuards(scenario);
    const gameAdded = ensureMoraleGuards(restored.map);
    for (const unit of gameAdded) unit.actionsLeft = 0;
    if (scenarioAdded.length || gameAdded.length)
      restored.log.push('旧存档已补齐大型战役的督战队与海战督战舰。');
  }
  if ((data.rulesVersion ?? 1) < 10 && restored.map.logistics) {
    applyCampaignFinances(restored.map);
    restored.log.push('本战役财政收入已按新版国力差距调整。');
  }
  // Preserve spent ammunition; old unlimited counters cannot exceed the new capacity.
  for (const u of restored.map.units) if (['hero', 'chinaHeavyChariot'].includes(u.kind) &&
      Number.isFinite(u.ammo)) u.ammo = Math.min(u.ammo, unitStats(restored.map, u).ammo);
  if(restored.fogPolicy)restored.fogPolicy=fogPolicy(restored.fogPolicy);
  for(const u of restored.map.units)if(u.kind==='scout')for(const k of ['hunger','hungerClock','fedTurns','maxHungerTurns'])delete u[k];
  recomputeFog(restored);
  return {
    scenario,
    game: restored,
    playerTeam: data.playerTeam,
    battleMode: data.battleMode ?? 'human-ai',
    camera: data.camera,
    hiddenLogIndices: Array.isArray(data.hiddenLogIndices) ? new Set(data.hiddenLogIndices.filter(Number.isInteger)) : new Set(),
  };
}
