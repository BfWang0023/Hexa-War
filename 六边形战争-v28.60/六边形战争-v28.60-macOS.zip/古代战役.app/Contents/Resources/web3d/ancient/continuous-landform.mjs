import {worldUv} from './middle-earth-materials.mjs';
import {groundAnchorHeight,groundCell,hasCliffNavigation} from './cliff-navigation.mjs';
import {isMorannon,middleEarthScale,morannonWindows} from './middle-earth-data.mjs';
import {mountainSurfaceHeight,mountainSurfaceColor,usesMountainPalette} from './mountain-visual.mjs';
import { groundElevation } from './elevation-rules.mjs';
// Continuous world-space surface: v13 interpolates saved heights; legacy retains its visual relief.
// Rendering never writes simulation data or consumes the game RNG.
import * as T from '../vendor/three/three.module.js';
import {hexCorners,offsetToWorld,worldToOffset} from '../js/core/hex.js';
import {TERRAIN,index,inBounds,neighbors} from './engine.mjs';
import {bounds} from './terrain-adjacency.mjs';
export const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
function largeVisualField(m){
 const step=offsetToWorld(1,0).x;
 const water=t=>!!(t&(TERRAIN.RIVER|TERRAIN.SEA));
 function rowAt(x,r){
  r=Math.max(0,Math.min(m.rows-1,r));
  const u=Math.max(0,Math.min(m.cols-1,x/step-(r%2)*.5)),c=Math.floor(u),f=u-c,i=r*m.cols+c;
  const j=Math.min(i+1,(r+1)*m.cols-1);
  const a=water(m.terrain[i])?-.95:m.elevations[i]??0,b=water(m.terrain[j])?-.95:m.elevations[j]??0;
  return a+(b-a)*f;
 }
 function height(x,z){
  const f=z/9,r=Math.floor(f),a=rowAt(x,r),b=rowAt(x,r+1),h=a+(b-a)*(f-r);
  return h<0?h:(h*4.65+Math.max(0,h-.75)*2.6)*middleEarthScale(m.victory.layoutVersion);
 }
 return {height,clear(){},relief(){return null;}};
}
export function createVisualField(m,baseHeight){
 if(m.victory?.layoutVersion>=3)return largeVisualField(m);
 const cache=new Map(),relief=new Map(),cells=[];
 const authored=m.victory?.layoutVersion>=2;
 function height(x,z){const k=Math.round(x*10000)+','+Math.round(z*10000);if(cache.has(k))return cache.get(k);const cell=worldToOffset(x,z);let weights=0,mountain=0,base=0,elevationOffset=0,road=0,roadHeight=0,nearestRoad=Infinity,water=0,waterHeight=0,nearestWater=Infinity,nearSea=Infinity,channel=Infinity;
  const radius=authored?2:3;
  for(let r=cell.row-radius;r<=cell.row+radius;r++)for(let c=cell.col-radius;c<=cell.col+radius;c++){if(!inBounds(m,c,r))continue;const cellIndex=index(m,c,r);let source=cells[cellIndex];if(!source){const p=offsetToWorld(c,r),t=m.terrain[cellIndex];cells[cellIndex]=source={...p,t,h:baseHeight(m,c,r),e:groundElevation(m,c,r)-((t&TERRAIN.MOUNTAIN)?1:0)};}const {t}=source,dsq=(x-source.x)**2+(z-source.z)**2;if(dsq>529)continue;const w=Math.exp(-dsq/(authored?80:m.autoElevation?64:78));weights+=w;elevationOffset+=w*source.e;mountain+=(t&TERRAIN.MOUNTAIN?w:0);base+=w*(t&(TERRAIN.RIVER|TERRAIN.SEA)?-.95:t&TERRAIN.MOUNTAIN?.35:source.h);if(t&TERRAIN.ROAD){const rw=Math.exp(-dsq/32);road+=rw;roadHeight+=rw*source.h;nearestRoad=Math.min(nearestRoad,dsq);}if(t&(TERRAIN.RIVER|TERRAIN.SEA)){const ww=Math.exp(-dsq/32);water+=ww;waterHeight+=ww*-.95;nearestWater=Math.min(nearestWater,dsq);
   if(authored&&dsq<155){
    if(t&TERRAIN.SEA)nearSea=Math.min(nearSea,dsq);
    else if(t&TERRAIN.RIVER){
     channel=Math.min(channel,dsq);
     for(const v of neighbors(c,r)){
      if(!inBounds(m,v.c,v.r)||!(m.terrain[index(m,v.c,v.r)]&(TERRAIN.RIVER|TERRAIN.SEA)))continue;
      const q=offsetToWorld(v.c,v.r),dx=q.x-source.x,dz=q.z-source.z;
      const u=Math.max(0,Math.min(1,((x-source.x)*dx+(z-source.z)*dz)/(dx*dx+dz*dz)));
      channel=Math.min(channel,(x-source.x-dx*u)**2+(z-source.z-dz*u)**2);
     }
    }
   }
  }}
  if(!weights)return baseHeight(m,Math.max(0,Math.min(m.cols-1,cell.col)),Math.max(0,Math.min(m.rows-1,cell.row)));
  const coverage=mountain/weights,mask=smooth(.08,.86,coverage),warp=Math.sin(x*.013+z*.021)*12;
  // Oblique, overlapping broad ridges; crests extend over many cells, not one peak per cell.
  const ridge=Math.pow(.5+.5*Math.sin(x*.035+z*.019+Math.sin(z*.018)*.8),1.7),broad=.5+.5*Math.sin(x*.013-z*.024+Math.sin(x*.009)*.9),secondary=.5+.5*Math.sin((x+warp)*.057-z*.034);
  let h=(base+elevationOffset*3)/weights+mask*(1.2+6.0*ridge+2.0*broad+1.1*secondary);
  if(authored){
   const logical=(elevationOffset+mountain)/weights;
   h=logical*4.65+Math.max(0,logical-.75)*2.6+(.13*Math.sin(x*.18+z*.067))*mask;
  }
  if(m.autoElevation)h=mountainSurfaceHeight((elevationOffset+mountain)/weights,coverage,x,z);
  relief.set(k,{logical:(elevationOffset+mountain)/weights,coverage});
  // Existing roads and water carve broad continuous valleys; no per-hex center pits.
  if(road&&!m.autoElevation&&!authored){const influence=1-smooth(2.7,10.0,Math.sqrt(nearestRoad));h=h*(1-influence)+(roadHeight/road)*influence;}
  if(water){const influence=authored?Math.max(1-smooth(2.45,5.15,Math.sqrt(channel)),1-smooth(5.5,9.2,Math.sqrt(nearSea))):1-smooth(5.1,9.2,Math.sqrt(nearestWater));h=h*(1-influence)+(waterHeight/water)*influence;}
  cache.set(k,h);return h;
 }return {height,relief(x,z){const k=Math.round(x*10000)+","+Math.round(z*10000);height(x,z);return relief.get(k);},clear(){cache.clear();relief.clear();cells.length=0;}};
}
export function createContinuousSurface(m,baseHeight,tileBase,region,material,waterMaterial,fullDetail=true){
 const group=new T.Group(),area=bounds(m,region),field=createVisualField(m,baseHeight),positions=[],colors=[],indices=[],gridPos=[],waterPos=[],waterColors=[],faces=new Map();
 const remaster=!!m.victory?.army,cliff=hasCliffNavigation(m),scaled=!cliff&&m.victory?.layoutVersion>=4;
 const zones=cliff&&isMorannon(m.scenarioId)?Object.values(morannonWindows(m)):null;
 const sameZone=(c,q)=>!zones||zones.some(([start,end])=>c>=start&&c<end&&q.c>=start&&q.c<end);
 const detailCache=new Map(),detail=(c,r)=>{if(!fullDetail||m.victory?.layoutVersion>=3)return 1;const k=c+','+r;if(detailCache.has(k))return detailCache.get(k);let n=1;for(let rr=r-2;rr<=r+2;rr++)for(let cc=c-2;cc<=c+2;cc++)if(inBounds(m,cc,rr)&&m.terrain[index(m,cc,rr)]&(TERRAIN.MOUNTAIN|(m.victory?.layoutVersion>=2?TERRAIN.RIVER:0)))n=3;detailCache.set(k,n);return n;};
 const position=(c,r,x,z,color)=>{const id=positions.length/3;positions.push(x,field.height(x,z),z);colors.push(color.r,color.g,color.b);return id;};
 for(let r=area.r0;r<area.r1;r++)for(let c=area.c0;c<area.c1;c++){
  const N=detail(c,r),p=offsetToWorld(c,r),corners=hexCorners(p.x,p.z),t=m.terrain[index(m,c,r)],earth=tileBase(t&TERRAIN.ROAD&&!(t&(TERRAIN.RIVER|TERRAIN.SEA))?t&~TERRAIN.ROAD:t,c,r,m),cellFaces=[];
  const first=positions.length/3;
  if(cliff){
    const {center,inner,rim,sides}=groundCell(m,c,r);
    const wet=!!(t&(TERRAIN.RIVER|TERRAIN.SEA)), submerged=wet&&!(t&TERRAIN.ROAD);
    const dryBank=[];
    if(remaster&&wet)for(let rr=r-2;rr<=r+2;rr++)for(let cc=c-2;cc<=c+2;cc++){
      if(inBounds(m,cc,rr)&&!(m.terrain[index(m,cc,rr)]&(TERRAIN.RIVER|TERRAIN.SEA)))
        dryBank.push(offsetToWorld(cc,rr));
    }
    const shore=(x,z)=>1-smooth(5,8.7,Math.min(14,...dryBank.map(q=>Math.hypot(q.x-x,q.z-z))));
    for(const vertex of [[center.x,center.y,center.z],...inner,...rim]){
      if(remaster&&submerged){
        const [x,y,z]=vertex;
        positions.push(x,Math.min(y,-.55+shore(x,z)*.46),z);
      }else positions.push(...vertex);
      colors.push(earth.r,earth.g,earth.b);
    }
    for(let i=0;i<12;i++){
      const a=1+i,b=1+(i+1)%12;
      const triangles=[[first,first+b,first+a],[first+a,first+b,first+a+12],[first+b,first+b+12,first+a+12]];
      for(const f of triangles){indices.push(...f);cellFaces.push(f);}
      const q=sides[Math.floor(i/2)];
      const neighbor=q&&m.terrain[index(m,q.c,q.r)];
      const otherSubmerged=!!(neighbor&(TERRAIN.RIVER|TERRAIN.SEA))&&!(neighbor&TERRAIN.ROAD);
      const shared=!!q&&sameZone(c,q);
      const ownsEdge=!remaster||!shared||(submerged!==otherSubmerged?!submerged:index(m,c,r)<index(m,q.c,q.r));
      if(ownsEdge)for(const [x,y,z] of [rim[i],rim[(i+1)%12]]){
        const surfaceY=remaster&&submerged?-.42:wet?Math.max(-.42,y):y;
        gridPos.push(x,surfaceY+(remaster?.095:.055),z);
      }
      if(t&(TERRAIN.RIVER|TERRAIN.SEA)){
        const sea=t&TERRAIN.SEA,base=sea?0x315c6c:0x3c6965,shallow=new T.Color(t&TERRAIN.ROAD?0x7e9b85:0x648674);
        for(const [x,y,z] of [[center.x,center.y,center.z],rim[(i+1)%12],rim[i]]){
          waterPos.push(x,-.42,z);
          const tint=new T.Color(base).lerp(shallow,(remaster?shore(x,z)*.46:smooth(-.88,.5,y)*.62));
          waterColors.push(tint.r,tint.g,tint.b);
        }
      }
    }
    if(remaster&&submerged)for(const q of sides){
      if(!q||!sameZone(c,q))continue;
      const other=m.terrain[index(m,q.c,q.r)];
      if(other&(TERRAIN.RIVER|TERRAIN.SEA)&&!(other&TERRAIN.ROAD))continue;
      // The lowered riverbed leaves a vertical interval under the adjacent bank.
      // Close it with a rendered bank face without changing navigation heights.
      const bank=groundCell(m,q.c,q.r),edge=bank.sides.findIndex(p=>p?.c===c&&p.r===r)*2;
      if(edge<0)continue;
      for(let segment=0;segment<2;segment++){
        const a=bank.rim[(edge+segment)%12],b=bank.rim[(edge+segment+1)%12];
        const start=positions.length/3;
        const bottom=-.56;
        for(const vertex of [a,b,[b[0],Math.min(b[1],bottom),b[2]],[a[0],Math.min(a[1],bottom),a[2]]]){
          positions.push(...vertex);
          colors.push(.22,.17,.12);
        }
        indices.push(start,start+1,start+2,start,start+2,start+3);
      }
    }
    faces.set(index(m,c,r),cellFaces);
    continue;
  }
  if(scaled){
    position(c,r,p.x,p.z,earth);
    for(const [x,z] of corners)position(c,r,x,z,earth);
  }
  for(let side=0;side<6;side++){const a=corners[side],b=corners[(side+1)%6],rows=[],across=worldToOffset(p.x+((a[0]+b[0])/2-p.x)*1.05,p.z+((a[1]+b[1])/2-p.z)*1.05),edgeN=N===1?detail(across.col,across.row):N;
   // A coarse cell fans out to the fine neighbour's exact edge samples, avoiding T-junction cracks.
   if(scaled){indices.push(first,first+1+(side+1)%6,first+1+side);}
   else if(N===1){const center=position(c,r,p.x,p.z,earth);for(let j=0;j<edgeN;j++){const ids=[j/edgeN,(j+1)/edgeN].map(f=>position(c,r,a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f,earth)),face=[center,...ids.reverse()];indices.push(...face);cellFaces.push(face);}}else{
   for(let i=0;i<=N;i++){const row=[];for(let j=0;j<=N-i;j++){const x=p.x+(a[0]-p.x)*i/N+(b[0]-p.x)*j/N,z=p.z+(a[1]-p.z)*i/N+(b[1]-p.z)*j/N;const col=earth.clone();if(t&TERRAIN.MOUNTAIN)col.lerp(new T.Color(0x92917a),smooth(3,9,field.height(x,z))*.35);row.push(position(c,r,x,z,col));}rows.push(row);}
   for(let i=0;i<N;i++)for(let j=0;j<N-i;j++){const f=[rows[i][j],rows[i][j+1],rows[i+1][j]];indices.push(...f);cellFaces.push(f);if(j<N-i-1){const g=[rows[i+1][j],rows[i][j+1],rows[i+1][j+1]];indices.push(...g);cellFaces.push(g);}}
   }
   for(let j=0;j<edgeN;j++)for(const fraction of [j/edgeN,(j+1)/edgeN]){const x=a[0]+(b[0]-a[0])*fraction,z=a[1]+(b[1]-a[1])*fraction;gridPos.push(x,Math.max(field.height(x,z),t&(TERRAIN.RIVER|TERRAIN.SEA)?-.42:-Infinity)+.045,z);}
   if(t&(TERRAIN.RIVER|TERRAIN.SEA))for(const [x,z] of [[p.x,p.z],b,a]){waterPos.push(x,-.42,z);const col=new T.Color(t&TERRAIN.ROAD?0x669389:t&TERRAIN.SEA?0x315e70:0x426f76);waterColors.push(col.r,col.g,col.b);}
  }
  if(!scaled)faces.set(index(m,c,r),cellFaces);
 }
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));geometry.setIndex(indices);
 // Analytical normals sample the same field on either side of a chunk boundary.
 if(cliff){
  const values=[],normal=new T.Vector3();
  // Lighting uses the slope across nearby anchors so the walking pads do not
  // appear as a repeating pattern on broad hills. Geometry remains identical.
  for(let i=0;i<positions.length;i+=3){
   const x=positions[i],z=positions[i+2],{col,row}=worldToOffset(x,z);
   let sum=0,h=0,dx=0,dz=0,wx=0,wz=0;
   for(let r=Math.max(0,row-2);r<=Math.min(m.rows-1,row+2);r++)for(let c=Math.max(0,col-2);c<=Math.min(m.cols-1,col+2);c++){
    const p=offsetToWorld(c,r),u=p.x-x,v=p.z-z,w=Math.exp(-(u*u+v*v)/144),y=groundAnchorHeight(m,c,r);
    sum+=w;h+=w*y;dx+=w*u*y;dz+=w*v*y;wx+=w*u;wz+=w*v;
   }
   const mean=h/sum;
   normal.set((wx*mean-dx)/(72*sum),1,(wz*mean-dz)/(72*sum)).normalize();
   values.push(normal.x,normal.y,normal.z);
  }
  geometry.setAttribute('normal',new T.Float32BufferAttribute(values,3));
 }
 else{
  const values=[];
  for(let i=0;i<positions.length;i+=3){
   const x=positions[i],z=positions[i+2],e=scaled?27*middleEarthScale(m.victory.layoutVersion)/7:.12;
   const v=new T.Vector3(field.height(x-e,z)-field.height(x+e,z),2*e,field.height(x,z-e)-field.height(x,z+e)).normalize();
   values.push(v.x,v.y,v.z);
  }
  geometry.setAttribute('normal',new T.Float32BufferAttribute(values,3));
 }
 if(remaster){
  worldUv(geometry,18);
  const tint=geometry.attributes.color;
  const lit=geometry.attributes.normal;
  const slate=new T.Color(isMorannon(m.scenarioId)?0x635955:0x959082),shade=new T.Color();
  for(let i=0;i<tint.count;i++){
    const y=positions[i*3+1];
    if(y<1.2)continue;
    const face=smooth(.015,.24,1-lit.getY(i));
    const bands=.64+.22*Math.cos(y*.91+positions[i*3]*.045+positions[i*3+2]*.027);
    shade.fromBufferAttribute(tint,i).lerp(slate,face*bands*.72);
    tint.setXYZ(i,shade.r,shade.g,shade.b);
  }
 }
 const normals=geometry.attributes.normal.array;
 const surface=new T.Mesh(geometry,material);surface.name='ancient-terrain';surface.receiveShadow=true;
 // Broad terrain reads through normals; removing self-shadow casting avoids the old
 // 1024px shadow-map stair/acne bands without raising shadow resolution or light cost.
 surface.castShadow=false;group.add(surface);
 const grid=new T.LineSegments(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(gridPos,3)),new T.LineBasicMaterial({color:remaster&&isMorannon(m.scenarioId)?0xd3c4af:0x263b2f,transparent:true,
  opacity:remaster?.21:cliff?.045:m.victory?.layoutVersion>=2?.085:.16,depthWrite:false}));grid.name='hex-grid';
 if(remaster){
   grid.userData.gridOpacity={board:.62,tactical:grid.material.opacity};
   grid.userData.gridColor={board:0xaebba2,tactical:grid.material.color.getHex()};
 }
 grid.renderOrder=2;group.add(grid);
 let water=null;if(waterPos.length){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(waterPos,3));g.setAttribute('color',new T.Float32BufferAttribute(waterColors,3));g.computeVertexNormals();water=new T.Mesh(g,waterMaterial);water.name='continuous-water';water.renderOrder=1;group.add(water);}
 const point=new T.Vector3(),a=new T.Vector3(),b=new T.Vector3(),d=new T.Vector3(),bary=new T.Vector3();
 const verts=scaled?geometry.attributes.position.array:positions;
 function sample(c,r,x,z){
  point.set(x,0,z);
  const interpolate=(i,j,k)=>{
   a.set(verts[i*3],0,verts[i*3+2]);b.set(verts[j*3],0,verts[j*3+2]);d.set(verts[k*3],0,verts[k*3+2]);
   T.Triangle.getBarycoord(point,a,b,d,bary);
   return Math.min(bary.x,bary.y,bary.z)>=-1e-5?verts[i*3+1]*bary.x+verts[j*3+1]*bary.y+verts[k*3+1]*bary.z:null;
  };
  if(scaled&&c>=area.c0&&c<area.c1&&r>=area.r0&&r<area.r1){
   const start=((r-area.r0)*(area.c1-area.c0)+c-area.c0)*7;
   for(let side=0;side<6;side++){
    const h=interpolate(start,start+1+(side+1)%6,start+1+side);
    if(h!==null)return h;
   }
  }else for(const f of faces.get(index(m,c,r))||[]){
   const h=interpolate(...f);if(h!==null)return h;
  }
  if(cliff&&inBounds(m,c,r))return groundCell(m,c,r).center.y;
  return field.height(x,z);
 }
 if(usesMountainPalette(m)){const col=new T.Color(),attribute=geometry.attributes.color;for(let i=0;i<positions.length;i+=3){const cell=worldToOffset(Math.round(positions[i]*10000)/10000,Math.round(positions[i+2]*10000)/10000),t=m.terrain[index(m,cell.col,cell.row)];if(m.unknown?.[index(m,cell.col,cell.row)]||t&(TERRAIN.RIVER|TERRAIN.SEA|TERRAIN.BEACH))continue;const info=field.relief(positions[i],positions[i+2]);if(!info)continue;mountainSurfaceColor(col,info.logical,normals[i],normals[i+1],normals[i+2],info.coverage);attribute.setXYZ(i/3,col.r,col.g,col.b);}}
 if(m.victory?.layoutVersion>=2&&!isMorannon(m.scenarioId)){
  const color=geometry.attributes.color,stone=new T.Color(0x756d62),pale=new T.Color(0xb2aba2),col=new T.Color();
  for(let i=0;i<positions.length;i+=3){
   const x=positions[i],z=positions[i+2],cell=worldToOffset(x,z);
   const j=index(m,cell.col,cell.row),t=m.terrain[j];
   if(m.unknown?.[j]||t&(TERRAIN.RIVER|TERRAIN.SEA))continue;
   const cliff=smooth(.06,.38,1-normals[i+1]);
   col.fromBufferAttribute(color,i/3).lerp(stone,cliff*.94);
   col.lerp(pale,smooth(26,50,positions[i+1])*.55);
   col.multiplyScalar(.96+.045*Math.sin(x*.12+z*.19)+.03*Math.cos(x*.25-z*.056));
   color.setXYZ(i/3,col.r,col.g,col.b);
  }
 }
 if(isMorannon(m.scenarioId)){
  const color=geometry.attributes.color;
  const tide=t=>m.victory?.layoutVersion>=2&&t&(TERRAIN.RIVER|TERRAIN.SEA);
  const ash=new T.Color(0x63534f),stone=new T.Color(0x4f4b55);
  for(let i=0;i<positions.length;i+=3){
   const cell=worldToOffset(positions[i],positions[i+2]),j=index(m,cell.col,cell.row);
   if(m.unknown?.[j]||!inBounds(m,cell.col,cell.row)||tide(m.terrain[j]))continue;
   const t=m.terrain[j],x=positions[i],z=positions[i+2];
   const variation=m.victory.layoutVersion>=3?.90+.055*Math.sin(x*.013+Math.cos(z*.021))+
     .045*Math.cos(z*.018+x*.009)*Math.sin(x*.011-z*.007):.76+.20*Math.sin(x*.044+z*.054);
   const tone=t&TERRAIN.MOUNTAIN?stone:ash;
   color.setXYZ(i/3,tone.r*variation,tone.g*variation,tone.b*variation);
  }
 }
 // Construction samples/normals are baked; do not retain their large temporary lookup tables.
 field.clear();
 return {group,surface,grid,water,sample,visualField:field};
}
