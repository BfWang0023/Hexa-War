import test from 'node:test';
import assert from 'node:assert/strict';
import { carrhaeMap, troyMap, actiumMap, jerusalemMap, syracuseMap, pydnaMap, babylonMap, bridgeAt, destroyBridge, startGame, endSide } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

test('eight-slot snapshot restores a played turn, unit state, terrain and fog', () => {
  const scenario = carrhaeMap();
  const game = startGame(scenario);
  game.aiDifficulty = 'hard';
  const unit = game.map.units.find(u => u.kind === 'romanLegion');
  unit.hp -= 17;
  unit.actionsLeft = 0;
  game.map.terrain[0] = 1;
  game.fog.egypt.explored.add('0,0');
  endSide(game);
  const snapshot = JSON.parse(JSON.stringify(createSave(scenario, game, 'egypt', { x: 3, z: 4, distance: 150 }, new Set([2]))));
  const restored = restoreSave(snapshot);
  assert.equal(restored.game.turn, game.turn);
  assert.equal(restored.game.map.units.find(u => u.id === unit.id).hp, unit.hp);
  assert.equal(restored.game.map.units.find(u => u.id === unit.id).actionsLeft, game.map.units.find(u => u.id === unit.id).actionsLeft);
  assert.equal(restored.game.map.terrain[0], 1);
  assert.ok(restored.game.fog.egypt.explored.has('0,0'));
  assert.equal(restored.playerTeam, 'egypt');
  assert.equal(restored.game.aiDifficulty, 'hard');
  assert.equal(restored.camera.distance, 150);
  assert.ok(restored.hiddenLogIndices.has(2));
});

test('save keeps the intact scenario bridge and the played demolition state separately', () => {
  const scenario = babylonMap();
  const game = startGame(scenario);
  const unit = game.map.units.find(u => u.team === 'egypt' && u.kind !== 'fort');
  unit.c = 51; unit.r = 35; unit.actionsLeft = 1;
  assert.equal(destroyBridge(game, unit.id, 52, 35).ok, true);
  const restored = restoreSave(JSON.parse(JSON.stringify(createSave(scenario, game, 'egypt'))));
  assert.equal(bridgeAt(restored.scenario, 52, 35), true);
  assert.equal(bridgeAt(restored.game.map, 52, 35), false);
  assert.equal(bridgeAt(restored.game.map, 53, 35), true);
});

test('rejects malformed and incompatible saves', () => {
  const save = createSave(carrhaeMap(), startGame(carrhaeMap()), 'egypt');
  assert.throws(() => restoreSave({ ...save, format: 'unknown' }));
  const bad = structuredClone(save);
  bad.game.map.units[0].kind = 'unknown';
  assert.throws(() => restoreSave(bad));
  const old = structuredClone(save);
  delete old.game.aiDifficulty;
  assert.equal(restoreSave(old).game.aiDifficulty, 'normal');
  const invalid = structuredClone(save);
  invalid.game.aiDifficulty = 'impossible';
  assert.throws(() => restoreSave(invalid));
  const legacyMode = structuredClone(save);
  delete legacyMode.battleMode;
  assert.equal(restoreSave(legacyMode).battleMode, 'human-ai');
  const invalidMode = structuredClone(save);
  invalidMode.battleMode = 'unknown';
  assert.throws(() => restoreSave(invalidMode), /交战模式/);
});

test('all three battle modes survive a save and load', () => {
  for (const mode of ['human-ai', 'human-human', 'ai-ai']) {
    const scenario = carrhaeMap(), game = startGame(scenario);
    if (mode === 'human-human') game.logOwners = [null, 'egypt'];
    if (mode === 'human-human') game.log.push('埃及隐蔽行动');
    const save = JSON.parse(JSON.stringify(createSave(scenario, game, 'egypt', null, [], mode)));
    const restored = restoreSave(save);
    assert.equal(restored.battleMode, mode);
    if (mode === 'human-human') assert.deepEqual(restored.game.logOwners, [null, 'egypt']);
  }
});

test('restores siege, transport, and naval campaign state', () => {
  for (const makeMap of [troyMap, actiumMap, jerusalemMap, syracuseMap, pydnaMap]) {
    const scenario = makeMap();
    const game = startGame(scenario);
    const restored = restoreSave(JSON.parse(JSON.stringify(createSave(scenario, game, 'coalition'))));
    assert.equal(restored.game.map.units.length, game.map.units.length);
    assert.deepEqual(restored.game.weather, game.weather);
    assert.deepEqual(restored.game.map.victory, game.map.victory);
    assert.deepEqual(restored.game.map.units.map(u => u.aboard).filter(Boolean),
      game.map.units.map(u => u.aboard).filter(Boolean));
  }
});
