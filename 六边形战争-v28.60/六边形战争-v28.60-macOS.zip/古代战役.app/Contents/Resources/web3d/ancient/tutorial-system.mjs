import {TUTORIALS,tutorialSteps,displayBinding} from './tutorial-content.mjs';
export function lessonSnapshot(x){return {turn:x.game.turn,camera:{...x.camera},serial:x.serial,units:Object.fromEntries(x.game.map.units.map(u=>[u.id,{...u}])),tasks:x.game.delegatedOrders?.length||0};}
export function bindTutorialSystem(h){
 const d=h.document,card=d.createElement('aside');card.id='tutorial-guide';card.hidden=true;card.setAttribute('aria-label','互动教学');
 const header=d.createElement('small'),title=d.createElement('h3'),copy=d.createElement('p'),feedback=d.createElement('p'),actions=d.createElement('div');feedback.id='tutorial-feedback';feedback.setAttribute('role','status');card.append(header,title,copy,feedback,actions);d.body.append(card);
 const layer=d.createElement('div');layer.id='tutorial-targets';d.body.append(layer);
 const button=(label,fn)=>{const b=d.createElement('button');b.textContent=label;b.onclick=fn;return b;};
 let active=false,id=null,actors={},steps=[],index=0,baseline=null,serial=0,events=[],results=[],advancing=false,timer=null,lastKey='';
 const context=()=>{const x=h.context();return {...x,actors,serial,events,key:name=>displayBinding(x.bindings[name]||name),unit:tag=>x.game.map.units.find(u=>u.id===actors[tag])};};
 function show(){
  actions.replaceChildren();layer.replaceChildren();lastKey='';
  if(index>=steps.length){header.textContent='练习结束';title.textContent=TUTORIALS.find(t=>t.id===id).name;copy.textContent=`实际完成 ${results.filter(r=>r==='passed').length} 步，跳过 ${results.filter(r=>r==='skipped').length} 步。可重试或独立学习其他模块。`;feedback.textContent=results.includes('skipped')?'跳过项没有记为实操通过。':'所有目标均由真实游戏状态验证。';const next=TUTORIALS.find(t=>t.id===id).next;if(next)actions.append(button('继续：移动与攻击',()=>start(next)));actions.append(button('重练本模块',()=>start(id)),button('选择其他教学',()=>h.choose()),button('返回主菜单',()=>h.exit()));return;}
  const x=context(),step=steps[index];baseline=lessonSnapshot(x);header.textContent=`${TUTORIALS.find(t=>t.id===id).name} · ${index+1}/${steps.length}`;title.textContent=step.title;copy.textContent=step.text(x);feedback.textContent='等待实际操作';
  actions.append(button('相关规则',()=>h.manual(step.rule||'controls')),button('跳过步骤',()=>advance('skipped')),button('重新开始',()=>start(id)),button('退出教学',()=>h.exit()));
 }
 function advance(result){if(!active||advancing||index>=steps.length)return;advancing=true;results.push(result);feedback.textContent=result==='passed'?'✓ 已检测到真实操作':'已跳过；未计入实操完成';timer=setTimeout(()=>{advancing=false;index++;show();},result==='passed'?550:0);}
 async function start(next){stop();id=next;steps=tutorialSteps(id);index=0;serial=0;events=[];results=[];actors=await h.setup(id);active=true;h.ready?.();card.hidden=false;show();}
 function stop(){clearTimeout(timer);timer=null;advancing=false;active=false;card.hidden=true;layer.replaceChildren();d.querySelectorAll('.tutorial-control').forEach(e=>e.classList.remove('tutorial-control'));}
 function tick(){
  const visible=active&&d.body.dataset.page==='Tutorial';card.hidden=!visible;layer.hidden=!visible;if(!visible||index>=steps.length)return;
  const x=context(),step=steps[index];copy.textContent=step.text(x);
  if(!advancing&&step.test(x,baseline))advance('passed');
  const targets=[...(step.actors||[]),...(step.actor?[step.actor]:[])].map(tag=>x.unit(tag)).filter(Boolean);if(step.cell)targets.push(step.cell);
  const markerKey=index+':'+targets.length;if(markerKey!==lastKey){layer.replaceChildren();for(const _ of targets){const mark=d.createElement('span');mark.className='tutorial-ring';mark.textContent='↓';layer.append(mark);}d.querySelectorAll('.tutorial-control').forEach(e=>e.classList.remove('tutorial-control'));if(step.element)d.getElementById(step.element)?.classList.add('tutorial-control');lastKey=markerKey;}
  targets.forEach((p,i)=>{const screen=h.project(p),mark=layer.children[i];if(!mark)return;mark.hidden=!screen.visible;mark.style.left=screen.x+'px';mark.style.top=screen.y+'px';});
 }
 const interval=setInterval(tick,100);
 return {start,stop,tick,get active(){return active;},get id(){return id;},get step(){return steps[index]?.key||'complete';},get results(){return [...results];},get actors(){return {...actors};},record(type,data){if(active){events.push({type,...data,serial:++serial});if(events.length>100)events.shift();}},feedback(message){if(active&&!advancing&&index<steps.length)feedback.textContent=message.slice(0,100);},dispose(){stop();clearInterval(interval);card.remove();layer.remove();}};
}
