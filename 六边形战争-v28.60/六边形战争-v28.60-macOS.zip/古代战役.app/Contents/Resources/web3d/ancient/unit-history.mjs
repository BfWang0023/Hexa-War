import {ME_STATS} from './middle-earth-data.mjs';
// Authored historical interpretation, separate from every numeric game rule.
export const SOURCES={
 middleEarth:['Tolkien Estate · 托尔金地图','https://www.tolkienestate.com/painting/maps/'],
 fireox:['《史记·田单列传》','https://www.shidianguji.com/zh/book/SJwSMQvJLG/chapter/1m8mabnjriu5q'],
 exile:['大都会艺术博物馆：居鲁士与犹大流亡者','https://www.metmuseum.org/es/perspectives/cyrus-and-the-judean-diaspora'],
 troy:['大英博物馆：特洛伊展览资料','https://www.britishmuseum.org/sites/default/files/2019-12/Large%20print%20guide_Troy.pdf'],
 actium:['普鲁塔克《安东尼传》','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Plutarch/Lives/Antony%2A.html'],
 zama:['波利比乌斯《历史》卷十五','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Polybius/15%2A.html'],
 macedon:['狄奥多罗斯：亚历山大军队（译文）','https://www.livius.org/sources/content/diodorus/diodorus-on-alexanders-army/'],
 chinaCar:['大英博物馆：商周战车构件','https://www.britishmuseum.org/collection/term/x14516'],
 greek:['大都会艺术博物馆：古希腊战争','https://www.metmuseum.org/de/essays/warfare-in-ancient-greece'],
 egypt:['新王国埃及战车图像研究','https://www.sidestone.com/openaccess/9789088902093.pdf'],
 hittite:['大英博物馆：卡迭石纸草文献','https://www.britishmuseum.org/collection/object/Y_EA10181-2'],
 qin:['剑桥大学：秦兵器考古研究','https://www.repository.cam.ac.uk/items/fe2338fa-508a-4910-b2f6-29cc5a24498b'],
 roman:['波利比乌斯《历史》卷六','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Polybius/6%2A.html'],
 punic:['波利比乌斯《历史》卷三','https://penelope.uchicago.edu/thayer/e/roman/texts/polybius/3%2A.html'],
 caesar:['恺撒《内战记》3.82–112','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Caesar/Civil_Wars/3D%2A.html'],
 parthia:['普鲁塔克《克拉苏传》','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Plutarch/Lives/Crassus%2A.html'],
 armor:['伊朗百科全书：铠甲','https://www.iranicaonline.org/articles/armor/'],
 navy:['希腊海军博物馆：三列桨战船','https://averof.hellenicnavy.gr/en/trireme-olympias/history-of-ancient-trireme/'],
 siege:['大英博物馆：拉吉围城浮雕','https://www.britishmuseum.org/collection/object/W_1856-0909-14_1'],
};
// Each entry has its own scope; campaign appearances are separately labeled as GAME data.
const records={};
function row(ids,origin,equipment,tactics,battle,source,limits='数值、行动次数、模型人数和技能都是游戏抽象，不代表历史编制或真实概率。'){for(const id of ids.split(' '))records[id]={origin,equipment,tactics,battle,source,limits};}
row('scout','古代多地军队均需先遣侦察，并非一个跨文明统一兵种。','轻便武器与适合行进的装具，装备随地域变化。','探路和传回情报，避免与主力正面交战。','不将某场战役专门归为这一通用模型。','greek','免补给、固定视野圈是游戏便利规则；真实侦察人员仍需食物。');
row('chariot','新王国埃及的战车军事传统。','轻型双马车，御者与战斗人员配合弓等武器。','机动射击与统帅展示；不能把所有埃及战车还原成同一种用途。','卡迭石的王室叙事含强烈宣传色彩。','egypt');
row('chinaHeavyChariot','先秦中原车战传统。','多马牵引，车上人员与步卒协同；长兵器和弓并用。','开阔地机动，受地形及步车协同条件制约。','具体战役配备不可仅由游戏车数推断。','qin','“重型冲锋车”是玩法分类；秦兵器资料不证明各时代战车结构完全一致。');
row('hittiteChariot','晚青铜时代安纳托利亚赫梯军队。','车组与马匹协同；乘员和武器复原存在讨论。','在大会战中集中使用，不能把现代轻重分类当作确证编制。','卡迭石，约前13世纪。','hittite');
row('light','古希腊等古代军队的轻装步行战斗人员。','轻盾、矛或其他便携武器，非统一装备表。','辅助主阵线、机动与追击。','通用类型不指定唯一代表战役。','greek');
row('heavy','古代密集步兵的综合游戏类型。','较强防护与近战武器，文明之间差别显著。','维持正面阵线，依赖组织与地形。','不能把通用重步兵等同于所有时代的方阵。','greek');
row('archer','古代多个文明的弓箭部队。','弓、箭与备用近战武器；弓材和护甲因地而异。','远程支援，需要掩护和弹药。','本条不将通用模型指定为某一种民族弓手。','greek');
row('chinaCrossbow','战国至秦汉的弩兵传统。','弩臂、弓体与扳机机构；秦出土铜弩机可供研究。','蓄力发射提供投射能力，装填过程有成本。','秦军兵器遗存提供装备证据，并非每场战役的部署证据。','qin');
row('chinaGeneral','先秦至汉代统兵身份的游戏合并角色。','身份、车骑与护卫配置随时代变化。','组织军队而非靠个人杀伤代表整个指挥系统。','以所选战役中的实名身份为准。','qin','共用统帅编号与模型，不代表不同朝代拥有同一制服或指挥制度。');
row('moraleGuard','维持军纪与整顿队伍的综合角色。','随所属军队使用近战装备。','督促与收拢是制度行为，不是一种跨文明统一兵种。','不为通用督战队虚构起源战役。','roman','游戏收拢溃兵技能不等同于某文明已经证实的标准督战编制。');
row('moraleFlagship','古代舰队指挥职能的综合角色。','舰船兼有指挥与信号人员。','组织舰队；通讯受距离、环境和信号限制。','不认定每支历史舰队均有同型督战舰。','navy');
row('chinaFireOx','中国古代田单故事中的火牛计题材。','以牲畜、火与惊扰制造混乱的叙事。','非常规突袭，不是长期制式化兵种。','即墨解围的传统记述；细节不能按现代战报核实。','qin','本条题材来自《史记·田单列传》；链接为时代兵器背景，不作为火牛细节证据。模型与可控性有显著游戏化。');
row('supplyWagon','古代各军的运输与粮秣保障职能。','车辆、驮畜与运输人员，依道路及地方条件变化。','维系行动；需受到护卫。','不指定跨时代通用粮车的唯一战例。','roman');
row('guard','君主或统帅近卫的综合类型。','较精良装备与身份象征，但不同文明并不统一。','护卫与战斗储备。','须结合所选战役辨别具体近卫身份。','greek');
row('pharaoh','埃及王权与统兵形象；游戏也复用此编号表示其他统帅。','埃及王室图像常见战车与弓。','图像强调君王胜利，不能直接视作个人战果记录。','美吉多、卡迭石的埃及王室叙事。','egypt','若选择亚历山大等战役变体，此埃及背景不适用；应阅读变体说明。');
row('hittiteKing','赫梯国王穆瓦塔利二世的角色来源。','王室战车、随员与指挥身份。','协调诸部作战，王室身份不等于固定单兵属性。','卡迭石。','hittite','编号也被复用为其他统帅，选定战役身份优先。');
row('warship','古代桨帆军舰的通用合并类型。','桨、帆和甲板战斗人员，结构因时代而异。','机动、接舷和部分舰型的撞击。','不将通用外形视为某艘考古复原舰。','navy');
row('transport','古代水上军队运输职能。','船体与载员空间优先于近战武器。','输送人员，需要战斗舰掩护。','通用运输模型不对应唯一历史船型。','navy');
row('hero','荷马史诗与特洛伊战争传说中的英雄形象。','矛、盾与身份化甲胄属于文学和图像传统。','英雄对决是叙事方式，不能用于复原整支军队。','特洛伊战争的年代与叙事细节存在争议。','greek','超常生命值与投矛次数是游戏设计；不把史诗战果当确证史实。');
row('trojanHorse','特洛伊木马的史诗传统。','木制献物与隐藏人员的故事形象。','计谋而非已证实的标准攻城装备。','特洛伊陷落传说。','greek','可移动攻击的木马是玩法改编；目前没有证据确认游戏结构真实存在。');
row('cavalry','古典时代多个地区的骑兵。','骑乘、矛与防护随文化及角色变化。','机动、翼侧支援和追击，不全是冲击骑兵。','通用骑兵不指定唯一历史编制。','greek');
row('siegeRam','古代近东等地区的攻城槌传统。','有防护的车体与撞击木梁。','接近墙门后反复破坏，需要步兵掩护。','拉吉围城浮雕记录了亚述攻城装备。','siege');
row('captive','犹大流亡历史的非战斗角色。','被迁徙的人群，不是军事兵种。','在游戏中体现保护与救援目标。','新巴比伦征服后的流亡背景；并非标准作战单位。','siege','超高生命与不可行动是任务抽象；拉吉资料为近东迁徙图像背景，非巴比伦事件的直接证据。');
row('athenianTrireme','古典雅典海军。','三列桨战船依赖受训桨手及少量甲板战斗人员。','机动与撞击需良好协同。','萨拉米斯。','navy');
row('alliedTrireme','古典希腊各盟邦海军。','舰船与船员来自不同城邦。','联盟协作，训练和使用方式并非完全一致。','希波战争海战。','navy');
row('phoenicianTrireme','东地中海腓尼基城市航海传统。','桨帆军舰，具体舰体不应照搬雅典标准。','在帝国舰队内承担海战任务。','希波战争中的波斯舰队。','navy');
row('imperialTrireme','阿契美尼德帝国海军中的属地舰队。','由多地区船员和舰船组成，并非统一民族船型。','联合舰队作战。','萨拉米斯背景。','navy');
row('octavianLiburnian','罗马共和国末期的轻型军舰角色。','游戏以轻快桨船抽象多种舰型。','机动与舰队协同，不是仅凭船小必胜。','亚克兴角；各船型数量及具体复原仍有讨论。','navy','三列桨资料说明桨舰背景，不证明亚克兴角轻舰均为同一利布尔尼亚船型。');
row('antonyHeavyGalley','共和国末期安东尼舰队的大型桨舰。','较大舰体、甲板战斗空间与众多船员。','接舷与投射平台，但操作和补给要求高。','亚克兴角。','navy','桨列名称并不简单等于船体垂直叠加的桨手层数；模型为风格化展示。');
row('cleopatraGalley','托勒密埃及末期王室舰队。','希腊化桨舰传统，不能套用新王国埃及战车时代装备。','舰队与王室行动的一部分。','亚克兴角。','navy');
row('phalangite','马其顿及希腊化王国的长枪方阵步兵。','长枪与盾，依靠密集阵列协同。','正面阵线有力，对地形与侧后保护有要求。','亚历山大与继业者战争。','greek');
row('greekHoplite','古风至古典时代希腊重装步兵。','大盾与长矛；防护配置并非一成不变。','密集步兵作战，与马其顿长枪兵不同。','希腊城邦战争。','greek');
row('companionCavalry','马其顿王室伙伴骑兵。','骑枪与骑乘装备，不等同于后世骑士。','与步兵协同，在合适时机集中攻击。','亚历山大远征。','greek');
row('scythedChariot','阿契美尼德等军队使用的镰刀战车题材。','车轴等处装刃，具体结构存在复原差异。','需要较开阔且合适的接近线路。','高加米拉的古代叙事。','armor','游戏可控性和固定伤害夸大了这类武器在不利条件下的稳定性。');
row('warElephant','南亚及后来希腊化、地中海军队的战象。','驭手与象体；塔楼、甲具因时代与军队不同。','威慑和冲击，也有受惊失控风险。','不以印度模型自动证明迦太基使用同种象或同款装备。','armor');
row('engineer','古代军队的工程技术与劳役职能。','工具、工匠与运输组织。','修筑和攻城，需要资源及保护。','围城战中的工程活动。','siege');
row('siegeGalley','古代舰船搭载攻城装备的综合角色。','舰体提供承载平台。','支援港口攻城，需近岸条件与舰队保护。','游戏推罗攻城场景；不把模型当作特定古舰精确复原。','siege');
row('defenseTower','城港防御工事的综合类型。','高台与远程守备人员。','保护要点，位置固定。','通用军港塔不指定唯一原型。','siege');
row('romanOnager','罗马扭力抛石装备的游戏合并类型。','木架、扭力构件与投射臂。','攻城投射，依赖专业人员及运输。','不能把晚期“野驴炮”形制无条件投射到全部共和时代围城。','siege','本模型跨时代复用；名称、年代与真实器械谱系不完全重合。');
row('siegeTower','古代大型移动攻城塔传统。','木制高层结构与防护。','接近城垣支援攻城，受路面条件限制。','围城工程的综合呈现。','siege');
row('parthianHorseArcher','帕提亚的骑射部队。','骑乘与弓箭。','持续骚扰和机动，依赖箭矢保障。','卡莱，前53年。','parthia');
row('parthianCataphract','帕提亚具装骑兵传统。','人马防护与长兵器，具体铠甲并非统一。','与骑射协同施压，不能无限追逐。','卡莱。','parthia');
row('arrowCamel','帕提亚军队的驮载补箭题材。','骆驼与箭矢运输。','支撑骑射部队的持续作战。','《克拉苏传》叙及卡莱补箭。','parthia','补给范围与自动补箭是游戏简化。');
row('romanArcher','罗马军队中的弓箭人员。','弓箭装备具有地域与时期差异。','配合主力投射，不能据同一模型推断全军编制。','不将帝国辅助军制度套用于全部共和国战役。','roman');
row('romanVelites','共和时期罗马军团轻兵。','投枪、剑与轻盾。','主线前的散兵战。','波利比乌斯的军团描述。','roman');
row('romanHastati','共和时期罗马青年兵。','盾、剑、投枪和不同程度防护。','主力第一线。','共和时期军团体系。','roman');
row('romanPrincipes','共和时期罗马壮年兵。','装备与青年兵近似。','位于青年兵之后的主力。','共和时期军团体系。','roman');
row('romanTriarii','共和时期罗马后备枪兵。','长矛、盾与防护。','资深后备力量。','共和时期军团体系。','roman');
row('romanLegion','罗马军团士兵的通用角色。','剑、盾和防护；装备随时期演变。','成建制作战，需要纪律和后勤。','不能用统一模型代替数世纪装备变化。','roman');
row('caesarReserve','法萨卢斯恺撒临时编出的第四线。','来自既有军团的步兵，并非永久独立兵种。','应对敌方骑兵迂回。','法萨卢斯，前48年。','caesar');
row('pompeyLegion','罗马内战中的庞培军团。','共享罗马军团传统，差异不等于独立民族兵种。','正面阵线与各兵种协同。','法萨卢斯。','caesar');
row('pompeyHorse','庞培阵营的骑兵力量。','来自多种地区的骑兵。','试图利用侧翼优势，需配合步兵。','法萨卢斯。','caesar');
row('romanHorse','共和罗马骑兵的综合角色。','骑乘与近战武器。','侧翼与追击。','共和时期军团与骑兵配合作战。','roman');
row('romanAlliedHorse','罗马盟邦提供的骑兵。','装备和组织不必与公民骑兵相同。','补充军队机动力量。','意大利盟邦军事体系。','roman');
row('gaulInfantry','汉尼拔军中高卢战士。','剑盾装备，内部差异不能省略。','参与主阵线。','坎尼。','punic');
row('iberianInfantry','汉尼拔军中伊比利亚步兵。','武器区别于高卢部队。','参与中央步兵阵线。','坎尼。','punic');
row('africanInfantry','汉尼拔军中的非洲步兵。','坎尼叙事提及使用缴获的罗马装备。','配合中央与骑兵。','坎尼。','punic');
row('punicSkirmisher','迦太基军中投射轻兵的合并类型。','游戏用投石索代表多来源投射力量。','接战前支援和扰乱。','非单一民族或单一编制。','punic');
row('punicHeavyHorse','汉尼拔的伊比利亚与高卢骑兵合并角色。','骑乘与近战装备。','翼侧作战。','坎尼。','punic');
row('numidianHorse','北非努米底亚骑兵。','较轻的骑乘投射装备。','机动牵制与追击。','第二次布匿战争。','punic');
row('hannibal','迦太基统帅汉尼拔。','指挥多来源军队，不是统一装备兵种。','协调步骑兵。','坎尼。','punic');
row('paullus','罗马执政官卢基乌斯·埃米利乌斯·保卢斯。','统帅与随员。','领导军队而非仅个人武勇。','坎尼。','punic');
row('varro','罗马执政官盖乌斯·特伦提乌斯·瓦罗。','统帅与随员。','史家对失败责任的归因需谨慎阅读。','坎尼。','punic');
row('scipio','罗马统帅大西庇阿。','指挥身份，非独立制式兵种。','军团与盟军协作。','扎马。','roman','具体统帅光环是游戏抽象，链接为罗马军制背景。');
row('masinissa','努米底亚王马西尼萨。','骑兵指挥身份。','与罗马协同的机动骑兵力量。','扎马。','punic','本条为身份概述，链接为布匿战争背景。');
row('masinissaHorse','马西尼萨麾下努米底亚骑兵的游戏分类。','轻型骑乘与投射装备。','机动与追击。','扎马。','punic');
row('zamaPunicHorse','扎马场景中的迦太基骑兵。','骑乘近战部队。','掩护主力侧翼。','扎马。','punic','与坎尼重骑兵分开是游戏场景分类，不代表严格统一的历史兵种表。');
row('zamaVeteran','汉尼拔从意大利返回的老兵群体。','长期服役经验，非统一新式装备。','作为经验丰富的作战力量。','扎马。','punic');
row('fort','古代城墙与防御体系的综合表示。','土、木、石等材料，随地区和时代变化。','保护要地，依赖守备。','拉吉等围城遗存与图像可作比较。','siege','等级、生命与整体夺取是游戏抽象；本模型不是特定遗址复原。');
for(const [ids,source]of [['chinaFireOx','fireox'],['captive','exile'],['hero trojanHorse','troy'],['octavianLiburnian antonyHeavyGalley cleopatraGalley','actium'],['scipio masinissa masinissaHorse zamaPunicHorse zamaVeteran warElephant','zama'],['phalangite companionCavalry','macedon'],['chinaHeavyChariot','chinaCar']])for(const id of ids.split(' '))records[id].source=source;
records.chinaFireOx.limits='以《史记》的故事为基础；数量与细节有叙事加工的可能。可控模型与伤害是游戏改编。';
records.captive.limits='生命值和不可行动状态是任务抽象，不代表历史人群的身体或行为属性。';
records.scipio.limits='统帅技能是游戏抽象，不能还原为历史上固定半径的指挥光环。';
records.masinissa.limits='固定攻击数值与指挥能力是游戏抽象。';
records.octavianLiburnian.limits='古代叙事可证轻型舰船参与；不能由此把全部舰队还原为同一种舰型。';
for(const [id,u] of Object.entries(ME_STATS)){
 row(id,`中土虚构单位：${u.name}。`,'原创兵模与装备细节。','按所属章节、兵种与剧情能力结算。','第三纪元中土章节。','middleEarth','单位比例、武器组合和数值是游戏设计。');
}
export const UNIT_HISTORY=Object.freeze(records);
export function historyFor(kind,context){const base=records[kind]||{origin:'新增兵种，历史资料待校订。',equipment:'请以实战装备展示为准；模型不是考古证据。',tactics:'见游戏机制页。',battle:'暂不列举未核实战例。',source:null,limits:'游戏能力已经自动收录，历史文字需人工核实。'};const reused=['pharaoh','hittiteKing','chinaGeneral','light','heavy','archer','cavalry','guard','scout'].includes(kind);let scoped=base;
if(context&&['pharaoh','hittiteKing'].includes(kind)&&['gaugamela','issus','tyre'].includes(context.scenarioId))scoped={...base,origin:kind==='pharaoh'?'马其顿国王亚历山大三世。':'阿契美尼德帝国国王大流士三世。',equipment:kind==='pharaoh'?'骑乘指挥形象，与埃及战车君王有别。':'波斯王室战车形象，与赫梯国王并非同一历史装备。',tactics:'统帅协调多兵种军队；个人模型代表指挥身份。',battle:'亚历山大东征；具体登场以所选战役为准。',source:'macedon',limits:'本条对应复用编号的战役身份，不是埃及或赫梯君王。护甲、马匹和随员是风格化表达。'};
if(context&&context.scenarioId?.startsWith('china_')&&['light','heavy','archer','cavalry','guard','scout'].includes(kind))scoped={...base,origin:'先秦至汉代中国军队中的'+({light:'步卒',heavy:'披甲步卒',archer:'弓箭人员',cavalry:'骑兵',guard:'护卫',scout:'侦察人员'})[kind]+'角色；具体时代由所选战役决定。',equipment:'中国武器、防护与组织随时代变化，不能直接套用希腊或罗马装备。',tactics:base.tactics,battle:'所选战役为游戏登场语境；并不证明通用模型的具体编制。',source:'qin',limits:'链接提供秦代兵器背景；更早时期与汉代细节不能据此直接推断。模型及单位分类是跨时代简化。'};
return {...scoped,contextNote:context&&reused?`当前展示：${context.civilization} · ${context.name}。这是游戏使用语境；通用背景不证明该文明与默认模型具有相同装备。`:''};}
