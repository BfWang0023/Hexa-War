import test from 'node:test';
import assert from 'node:assert/strict';
import { createUnitModel } from './models.mjs';
import { animateV02, supportsV02 } from './models-v02.mjs';
import { createUnitAnimator } from './unit-animation.mjs';
import * as T from '../vendor/three/three.module.js';
const unit=kind=>({id:1,kind,team:'egypt',hp:100,morale:1,c:1,r:1});
test('four horses, two wheels and two crew retained; one horse on ordinary cavalry',()=>{
 for(const [kind,count] of [['chinaHeavyChariot',4],['cavalry',1]]){const m=createUnitModel(unit(kind),'china_chengpu',{phase1:true});let horses=0,wheels=0,crew=0;m.children[0].traverse(o=>{horses+=o.name==='horse';wheels+=o.name==='wheel';crew+=o.name==='crew';});assert.equal(horses,count);if(count===4){assert.equal(wheels,2);assert.equal(crew,2);}}
});
test('scope stays within three representatives',()=>{for(const kind of ['archer','guard','chinaCrossbow','chariot','pharaoh','warship'])assert.equal(supportsV02(unit(kind),'china_chengpu'),false);assert.equal(supportsV02(unit('chinaHeavyChariot'),'megiddo'),false);});
test('instances share geometry and materials, not transforms',()=>{const a=createUnitModel(unit('heavy'),'china_chengpu',{phase1:true}),b=createUnitModel(unit('heavy'),'china_chengpu',{phase1:true});const meshes=m=>{const out=[];m.children[0].traverse(o=>{if(o.isMesh)out.push(o);});return out;};const aa=meshes(a),bb=meshes(b);assert.equal(aa[0].geometry,bb[0].geometry);assert.equal(aa[0].material,bb[0].material);animateV02(a,600,{moving:true,attack:1});assert.notEqual(a.children[0].children[0].position.y,b.children[0].children[0].position.y);});
test('animation never mutates rule data; LOD and matrices remain finite',()=>{const u=Object.freeze(unit('cavalry')),m=createUnitModel(u,'china_chengpu',{phase1:true});const before=JSON.stringify(u),anim=createUnitAnimator(),group=new T.Group(),camera=new T.PerspectiveCamera();m.userData.unitId=1;group.add(m);anim.observe([u],0);anim.observe([Object.freeze({...u,c:2,hp:90})],10);anim.attack({ok:true,visual:{attackerId:1,attackerKind:'cavalry',attackerTeam:'egypt',melee:true,from:{c:2,r:1},to:{c:3,r:1}}},10);for(let t=10;t<900;t+=50)anim.update(group,camera,t);assert.equal(JSON.stringify(u),before);animateV02(m,1000,{distance:150});assert.equal(m.children[0].visible,false);assert.equal(m.children[1].visible,true);m.updateMatrixWorld(true);m.traverse(o=>assert.ok(o.matrixWorld.elements.every(Number.isFinite)));});
