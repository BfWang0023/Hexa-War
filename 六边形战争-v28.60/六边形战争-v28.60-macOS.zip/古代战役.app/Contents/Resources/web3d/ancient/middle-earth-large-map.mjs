import * as E from './engine.mjs';
import {isMorannon,largeMiddleEarthBoard,largeMiddleEarthCell,morannonWindows} from './middle-earth-data.mjs';

const {ROAD,MOUNTAIN,RIVER,SEA,PLAIN}=E.TERRAIN;
const clamp=(x,min,max)=>Math.max(min,Math.min(max,x));
const ridge=(x,w)=>Math.exp(-((x/w)**2));
const swell=(x,y)=>.40+.28*Math.sin(x*.054+y*.081)+.22*Math.cos(y*.13-x*.043);

// The previous battle site remains a continuous part of a larger, playable region.
// Distances and road coordinates here are measured in the old site's local hexes.
const routes={
  isen:[
    [[-68,-56],[2,5],[9,31],[2,74],[-36,114]],
    [[67,-56],[38,0],[43,28],[54,59],[84,107]],
    [[-74,17],[0,17]],[[50,20],[117,42]],
    [[-64,-30],[65,-30]], [[-59,66],[73,66]],
  ],
  hornburg:[
    [[-71,-40],[-32,-14],[3,22],[14,19]],
    [[57,17],[86,18],[112,35],[151,41]],
    [[-65,72],[-23,43],[6,23]],
    [[51,3],[67,-23],[99,-32],[143,-61]],
    [[57,25],[77,37],[74,77],[129,112]],
    [[-70,49],[-16,48],[20,52],[52,59],[74,77]],
  ],
  erebor:[
    [[4,18],[-17,2],[-42,-33],[-72,-65]],
    [[46,21],[64,8],[77,-35],[120,-60]],
    [[20,39],[14,55],[32,73],[61,105],[108,127]],
    [[-64,49],[-21,58],[14,55],[45,51],[104,62]],
    [[-61,92],[-25,88],[32,73],[79,77],[125,95]],
  ],
  pelennor:[
    [[18,0],[21,-20],[38,-47],[52,-88]],
    [[11,34],[7,61],[18,90],[48,127]],
    [[44,32],[49,54],[54,96],[54,123]],
    [[-77,53],[-22,55],[7,61],[35,52],[49,54]],
    [[-80,-46],[-29,-45],[21,-20],[37,-16],[47,-5]],
  ],
  pelargir:[
    [[30,0],[34,-20],[39,-56],[39,-83]],
    [[29,32],[31,53],[26,90],[31,119]],
    [[2,17],[-17,14],[-58,3],[-89,-23]],
    [[-68,-48],[-35,-29],[-17,14],[-31,42],[-68,62]],
    [[-75,81],[-40,65],[-4,60],[31,53]],
  ],
  front:[
    [[2,15],[-24,15],[-62,28],[-73,52]],
    [[26,7],[41,-15],[66,-31],[114,-50]],
    [[26,23],[54,35],[79,49],[105,100]],
    [[-60,-28],[-24,-17],[4,4],[12,11]],
    [[-65,66],[-39,53],[-18,46],[12,20]],
  ],
  pass:[
    [[2,15],[-24,12],[-59,6]],
    [[25,15],[44,11],[82,14],[108,35]],
    [[-56,-37],[-12,-24],[8,-7],[15,8]],
    [[-47,58],[-17,42],[5,38],[32,30],[54,38],[94,61]],
  ],
  doom:[
    [[7,16],[-22,16],[-62,29]],
    [[18,23],[24,43],[58,57],[96,70]],
    [[9,8],[-5,-17],[-42,-34],[-77,-58]],
    [[-54,64],[-31,50],[-9,47],[24,43]],
  ],
};

function regionHeight(kind,x,y,w,h){
  const noise=swell(x,y);
  if(kind==='hornburg'){
    const basin=21+5*Math.sin(x*.027);
    return noise+8.2*ridge(y-basin-30,16)*ridge(x+10,78)+8*ridge(y-basin+31,17)*ridge(x-4,79)
      +2.4*ridge(y-71+x*.23,13)+2.2*ridge(y+66-x*.16,16);
  }
  if(kind==='erebor'){
    const left=15-y*.42+4*Math.sin(y*.059),right=35+y*.38;
    return noise+9.3*ridge(y+15,45)*ridge(x-24,42)+6.8*ridge(y-18,67)*(ridge(x-left,12)+ridge(x-right,14))
      +1.6*ridge(y-71+x*.24,16);
  }
  if(kind==='front'||kind==='pass'||kind==='doom'){
    const ridgeLine=20+7*Math.sin(x*.053);
    if(kind==='doom')return noise+9.6*ridge(x-34,23)*ridge(y-15,37)+3.4*ridge(x+y*.64-37,9)*ridge(y-30,66)
      +2.8*ridge(x-y*.74+37,12);
    return noise+7.5*ridge(y-ridgeLine-26,15)*ridge(x-w*.63,71)
      +7.4*ridge(y-ridgeLine+26,17)*ridge(x-w*.76,77)+2.6*ridge(y-71-x*.16,19);
  }
  if(kind==='pelennor')return noise+7.5*ridge(x-1,21)*ridge(y-34,42)+2.1*ridge(x+y*.35+38,22);
  if(kind==='pelargir')return noise+2.5*ridge(x-3,20)*ridge(y-18,54)+2.1*ridge(y+x*.22+48,15);
  return noise+2.1*ridge(x-25,14)*ridge(y-14,22)+2.8*ridge(y+x*.25-69,15)+1.8*ridge(y-x*.23+45,18);
}

function waterOutside(kind,x,y,w,h){
  if(kind==='pelennor'||kind==='pelargir'){
    const shore=(kind==='pelennor'?44:36)+6*Math.sin((y-11)*.049);
    const width=(kind==='pelargir'?21:17)+2.5*Math.cos(y*.08);
    if(x>=shore&&x<shore+width)return kind==='pelargir'?SEA:RIVER;
    if(kind==='pelennor'&&Math.abs(y-49-6*Math.sin(x*.064))<1.5&&x>9)return RIVER;
    return PLAIN;
  }
  if(kind==='hornburg'&&(x<0||x>=w)){
    const edge=x<0?0:w-1;
    return Math.abs(y-(x<0?24:25)-4*Math.sin((x-edge)*.057))<1.3?RIVER:PLAIN;
  }
  if(kind==='erebor'&&y>=h){
    return Math.abs(x-29-8*Math.sin((y-h+1)*.055))<1.5?RIVER:PLAIN;
  }
  if(kind==='isen'&&(y<0||y>=h)){
    const edge=y<0?0:h-1,branch=(y<0?25:27)+7*Math.sin((y-edge)*.049);
    const island=3.8*Math.sin((y-edge)*.035)**2;
    return Math.min(Math.abs(x-branch-island),Math.abs(x-branch+island))<2?RIVER:PLAIN;
  }
  return PLAIN;
}

export function makeLargeMiddleEarthMap(base){
  const id=base.scenarioId,chapter=id.split('_')[1],dual=isMorannon(id);
  const [cols,rows]=largeMiddleEarthBoard(id);
  const victory={...base.victory,layoutVersion:3};
  const map=E.newMap(cols,rows,{scenarioId:id,victory});
  Object.assign(map,{scenarioId:id,name:base.name,intro:base.intro,factions:base.factions,gateRules:base.gateRules,victory});
  map.elevations=Array(cols*rows).fill(-.46);
  if(dual)map.terrain.fill(SEA);
  const project=(c,r)=>largeMiddleEarthCell(id,c,r);
  const shift=p=>({...p,...project(p.c,p.r)});
  const previous=dual?morannonWindows(base):{[chapter]:[0,base.cols]};
  const next=dual?morannonWindows(map):{[chapter]:[0,cols]};
  for(const [kind,[left,right]] of Object.entries(previous)){
    const [start,end]=next[kind],origin=project(left,0),w=right-left,h=base.rows;
    const inside=(x,y)=>x>=0&&x<w&&y>=0&&y<h;
    const write=(c,r,t,level)=>{
      const i=E.index(map,c,r);
      map.terrain[i]=t;
      map.elevations[i]=Math.round(level*100)/100||0;
    };
    for(let r=0;r<rows;r++)for(let c=start;c<end;c++){
      const x=c-origin.c,y=r-origin.r;
      if(inside(x,y)){
        const source=E.index(base,left+x,y),i=E.index(map,c,r);
        map.terrain[i]=base.terrain[source];map.elevations[i]=base.elevations[source];map.houses[i]=base.houses[source];
        continue;
      }
      const sx=clamp(x,0,w-1),sy=clamp(y,0,h-1);
      const src=E.index(base,left+sx,sy),dist=Math.hypot(x-sx,y-sy);
      const mix=Math.max(0,1-dist/15);
      let wet=waterOutside(kind,x,y,w,h);
      if(dist<=2&&base.terrain[src]&(RIVER|SEA))wet=base.terrain[src]&(RIVER|SEA);
      const height=base.elevations[src]*mix+regionHeight(kind,x,y,w,h)*(1-mix);
      write(c,r,wet|| (height>=1.25?MOUNTAIN:PLAIN),wet?-.46:height);
    }
    const layRoad=(x,y)=>{
      const c=origin.c+x,r=origin.r+y;
      if(c<start||c>=end||!E.inBounds(map,c,r)||inside(x,y))return;
      const i=E.index(map,c,r),t=map.terrain[i];
      if(t!==SEA)map.terrain[i]=t|ROAD;
    };
    if(kind==='pelennor'||kind==='pelargir'){
      for(const y of [-44,69]){
        for(let x=18;x<=Math.min(end-origin.c-1,98);x++){
          const c=origin.c+x,r=origin.r+y,i=E.index(map,c,r),t=map.terrain[i];
          if(t&(RIVER|SEA)){
            map.terrain[i]=RIVER|ROAD;
            map.bridges.push({c,r});
          }else map.terrain[i]=t|ROAD;
        }
      }
    }
    for(const route of routes[kind])for(let j=1;j<route.length;j++){
      const [x0,y0]=route[j-1],[x1,y1]=route[j],steps=Math.max(Math.abs(x1-x0),Math.abs(y1-y0))*3;
      for(let i=0;i<=steps;i++)layRoad(Math.round(x0+(x1-x0)*i/steps),Math.round(y0+(y1-y0)*i/steps));
    }
  }
  map.bridges.push(...base.bridges.map(shift));
  map.units=base.units.map(shift);
  map.landmarks=base.landmarks.map(shift);
  victory.points=Object.fromEntries(Object.entries(base.victory.points).map(([key,p])=>[key,shift(p)]));
  victory.waves=base.victory.waves.map(w=>({...w,rows:w.rows.map(([kind,c,r,name])=>{
    const p=project(c,r);
    return [kind,p.c,p.r,name];
  })}));
  addOutlyingPositions(map,chapter,next,project);
  return map;
}

const outposts={
  isen:[[-12,17,'西岸接应路'],[64,36,'东岸南路']],
  hornburg:[[66,17,'东谷集结路'],[66,-15,'北山接应路']],
  erebor:[[10,49,'谷口南阵地'],[55,20,'东脊外围山道']],
  pelennor:[[22,-13,'北方骑兵通路'],[42,45,'南田接应线']],
  pelargir:[[29,-13,'北仓储道路'],[30,47,'南岸商路']],
  morannon:[[-10,15,'联军后阵'],[43,23,'魔多东麓道路']],
};
function addOutlyingPositions(map,chapter,windows,project){
  const f=map.factions;
  const anchor=project(0,0);
  const [left,right]=windows.front??windows[chapter];
  const kinds={
    isen:['meRohanLight','meDunland'],
    hornburg:['meRohanFoot','meOrc'],
    erebor:['meElf','meOrc'],
    pelennor:['meGondor','meEast'],
    pelargir:['meGondor','meCorsair'],
    morannon:['meGondor','meOrc'],
  }[chapter];
  for(const [x,y,label] of outposts[chapter]){
    const c=anchor.c+x,r=anchor.r+y;
    map.landmarks.push({c,r,label});
    for(const [i,team] of ['egypt','coalition'].entries()){
      const p={c:c+(i?4:-4),r:r+(i?-1:1)},idx=E.index(map,p.c,p.r);
      if(p.c<left||p.c>=right||map.terrain[idx]&(RIVER|SEA)||E.mobileAt(map,p.c,p.r))continue;
      if(map.elevations[idx]>=4.8)map.terrain[idx]|=ROAD;
      if(E.addUnit(map,kinds[i],team,p.c,p.r))map.units.at(-1).customName=f[team]+'外围斥候';
    }
  }
}
