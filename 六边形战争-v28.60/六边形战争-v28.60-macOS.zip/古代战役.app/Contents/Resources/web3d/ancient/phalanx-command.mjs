// UI, officer and tests can all use the same paid per-unit engine actions.
import {setPhalanxMode,turnPhalanx,isFormableInfantry,unitName,isRouted} from './engine.mjs';
import {validFacing} from './directions12.mjs';
export function commandPhalanx(s,ids,mode,facing,team=s.side){
 const results=[];
 for(const id of new Set(ids)){
  const u=s.map.units.find(x=>x.id===id);let result;
  if(!u||u.team!==team||team!==s.side)result={ok:false,reason:'当前无权指挥该部队'};
  else if(u.hp<=0||isRouted(u)||u.aboard||u.uncontrolled)result={ok:false,reason:u.hp<=0?'部队已阵亡':isRouted(u)?'溃逃部队不能列阵':u.aboard?'登船部队不能列阵或转向':'失控部队不能接受列阵命令'};
  else if(!isFormableInfantry(u))result={ok:false,reason:'该兵种不具备列阵能力'};
  else if(!['form','turn','unform'].includes(mode)||mode!=='unform'&&!validFacing(facing))result={ok:false,reason:'列阵命令或方向无效'};
  else if(mode==='unform'&&!u.formed||mode==='form'&&u.formed&&u.facing===facing||mode==='turn'&&u.formed&&u.facing===facing)result={ok:true,unchanged:true};
  else if(u.actionsLeft<1)result={ok:false,reason:'行动力不足，等待下一本方回合'};
  else if(mode==='turn'&&!u.formed)result={ok:false,reason:'该部队尚未列阵，请先列阵'};
  else result=mode==='unform'?setPhalanxMode(s,id,false):mode==='turn'||u.formed?turnPhalanx(s,id,facing):setPhalanxMode(s,id,true,facing);
  results.push({id,name:u?unitName(s.map,u):'无效部队',...result});
 }
 return {results,completed:results.filter(r=>r.ok&&!r.unchanged).length,unchanged:results.filter(r=>r.unchanged).length,failed:results.filter(r=>!r.ok).length};
}
