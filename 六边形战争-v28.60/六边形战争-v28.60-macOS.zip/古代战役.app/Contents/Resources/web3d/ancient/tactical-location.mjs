import {planningState} from './fog-policy.mjs';
import {visibleTo,distance,inBounds,fortAt,TERRAIN,tile} from './engine.mjs';
import {resolveUnits,commandFrame} from './tactical-units.mjs';
import {centroid,hexFromPlane,oppositeFrame,offsetRegion,battlefronts,plane} from './battlefield-space.mjs';
export function resolveLocation(state,reference,context,actors=[]){state=planningState(state,context.team);
 const own=context.frame||commandFrame(state,context.team);let frame=own,points=[],label='',source=[];const anchor=hexFromPlane(centroid(actors));
 if(reference.position){points=[reference.position];label=`坐标${reference.position.c},${reference.position.r}`;}
 else if(reference.select){const enemy=reference.side==='enemy';source=resolveUnits(state,reference.select,context,{enemy});if(!source.length)throw Error('参考部队不存在或不在当前视野中');frame=enemy?oppositeFrame(own,source):own;
  if(!reference.select.front&&actors.length){const groups=battlefronts(source,frame);if(groups.length>1){groups.sort((a,b)=>distance(hexFromPlane(a.frame.origin),anchor)-distance(hexFromPlane(b.frame.origin),anchor));source=groups[0].units;frame=groups[0].frame;}}
  points=[hexFromPlane(centroid(source))];label=(enemy?'敌方':'己方')+(reference.select.wing?{left:'左翼',right:'右翼',center:'中央'}[reference.select.wing]:'参考部队');
 }else {
  const m=state.map,known=p=>visibleTo(state,context.team,p.c,p.r);label={bridge:'桥梁',wall:'城墙',depot:'仓库',route:'补给通道',road:'道路',landmark:reference.name||'地标'}[reference.feature];
  if(reference.feature==='bridge')points=(m.bridges||[]).filter(known);
  if(reference.feature==='wall')points=m.units.filter(u=>u.kind==='fort'&&u.hp>0&&known(u)&&(reference.side==='enemy'?u.team!==context.team:u.team===context.team));
  if(reference.feature==='depot')points=m.logistics?.depots?.[context.team]||[];
  if(reference.feature==='route')points=(m.logistics?.routes?.[context.team]||[]).filter(known);
  if(reference.feature==='road'){for(let r=0;r<m.rows;r++)for(let c=0;c<m.cols;c++)if((tile(m,c,r).terrain&TERRAIN.ROAD)&&known({c,r}))points.push({c,r});}
  if(reference.feature==='landmark')points=(m.landmarks||[]).filter(p=>p.label?.includes(reference.name)&&known(p));
  if(reference.feature==='depot'&&reference.side==='enemy')throw Error('不能查询敌方隐藏仓库');
  points=[...points].sort((a,b)=>distance(a,anchor)-distance(b,anchor)||a.r-b.r||a.c-b.c);if(reference.ordinal)points=points[reference.ordinal-1]?[points[reference.ordinal-1]]:[];else points=points.slice(0,1);
 }
 if(!points.length)throw Error('没有符合条件的已知'+(label||'参考区域'));
 const center=points[0],position=offsetRegion(center,frame,reference.relation||'center',reference.distance??0);if(!inBounds(state.map,position.c,position.r))throw Error('参考区域位于地图外');if(!visibleTo(state,context.team,position.c,position.r))throw Error('参考阵位不在当前视野内');
 return {position,frame,label,sourceIds:source.map(u=>u.id),description:`${label}${{front:'前方',rear:'后方',left:'左侧',right:'右侧',center:''}[reference.relation||'center']} ${position.c},${position.r}`};
}
