import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {offsetToWorld} from '../js/core/hex.js';
import {neighbors} from './engine.mjs';
import {createUnitModel} from './models.mjs';
import {createUnitAnimator} from './unit-animation.mjs';
const height=p=>p.c*.12+p.r*.07;
const point=p=>{const w=offsetToWorld(p.c,p.r);return new T.Vector3(w.x,height(p)+.08,w.z);};
const equal=(a,b,label)=>assert.ok(a.distanceTo(b)<1e-7,`${label}: ${a.toArray()} vs ${b.toArray()}`);
function make(kind,options={}){
 const u={id:'moving',kind,team:'egypt',hp:100,c:3,r:4,ammo:999,morale:1};
 const model=createUnitModel(u,'china_chengpu',options);model.userData.unitId=u.id;model.scale.setScalar(1.16);model.position.copy(point(u));
 const group=new T.Group();group.add(model);const camera=new T.PerspectiveCamera();camera.position.set(0,20,30);
 const anim=createUnitAnimator();anim.setHeightResolver(height);anim.observe([u],0,{scenarioId:'china_chengpu'});
 return {u,model,group,camera,anim};
}
for(const [kind,options] of [['heavy',{}],['cavalry',{}],['chinaHeavyChariot',{}],['supplyWagon',{}],['warship',{}],['heavy',{phase1:true}]])
 test(`${kind}${options.phase1?' phase1':''}: base and body share the interpolated path through near/far changes`,()=>{
 const {u,model,group,camera,anim}=make(kind,options),a=neighbors(u.c,u.r)[0],b=neighbors(a.c,a.r)[1];
 const before=JSON.stringify(u);anim.move(u.id,u,[a,b],0);anim.observe([{...u,...b}],1);model.position.copy(point(b));
 for(const time of [0,45,90,150,250,339,340,420,510,630,680,800]){
  camera.position.set(time>340?200:0,20,30);anim.update(group,camera,time);model.updateMatrixWorld(true);
  const expected=model.position.clone();
  if(time===0)equal(expected,point(u),'exact start');
  if(time>=680)equal(expected,point(b),'exact destination');
  const flat=p=>point(p).setY(0),sample=expected.clone().setY(0),nearest=new T.Vector3();
  const deviation=Math.min(...[[u,a],[a,b]].map(([start,end])=>new T.Line3(flat(start),flat(end)).closestPointToPoint(sample,true,nearest).distanceTo(sample)));
  assert.ok(deviation<1.3,'rounded path stays near the legal route');
  if(time===340)assert.ok(deviation>.1,'corner is rounded instead of passing through its vertex');
  const bases=model.children.filter(o=>o.isMesh&&o.geometry.type==='CylinderGeometry');assert.ok(bases.length>0);
  for(const base of bases){
   const baseCenter=base.getWorldPosition(new T.Vector3());assert.ok(Math.hypot(baseCenter.x-expected.x,baseCenter.z-expected.z)<1e-7,'colored base stays with piece');
  }
  for(const level of model.children.filter(o=>o.name==='near'||o.name==='far')){
   const body=level.children[0].getWorldPosition(new T.Vector3());assert.ok(Math.hypot(body.x-expected.x,body.z-expected.z)<1e-7,'near/far body stays above base');
  }
 }
 assert.equal(JSON.stringify(u),before,'presentation does not alter rules');
 const end=model.position.clone();anim.update(group,camera,800);equal(model.position,end,'repeat frames do not drift');
});
test('rebuilding models during travel keeps base and body on the same current path position',()=>{
 const f=make('heavy'),a=neighbors(f.u.c,f.u.r)[0];f.anim.move(f.u.id,f.u,[a],0);f.anim.observe([{...f.u,...a}],1);f.model.position.copy(point(a));f.anim.update(f.group,f.camera,180);
 const replacement=createUnitModel({...f.u,...a},'china_chengpu');replacement.userData.unitId=f.u.id;replacement.position.copy(point(a));replacement.scale.setScalar(1.16);f.group.clear();f.group.add(replacement);f.anim.update(f.group,f.camera,180);
 equal(replacement.position,f.model.position,'replacement uses same interpolated anchor');
});
test('move/attack/move queue keeps whole base at each event location, not final logical cell',()=>{
 const f=make('heavy'),a=neighbors(f.u.c,f.u.r)[0],b=neighbors(a.c,a.r)[1],target=neighbors(a.c,a.r)[0];
 const result={ok:true,visual:{from:a,to:target,attackerId:f.u.id,attackerKind:'heavy',attackerTeam:'egypt',melee:true}};
 f.anim.actions([{type:'move',id:f.u.id,from:f.u,to:{...a,path:[a]}},{type:'attack',result},{type:'move',id:f.u.id,from:a,to:{...b,path:[b]}}],0,{scenarioId:'china_chengpu'});
 f.anim.observe([{...f.u,...b}],1);f.model.position.copy(point(b));
 for(const [time,expected] of [[0,point(f.u)],[340,point(a)],[700,point(a)],[1040,point(a)],[1380,point(b)]]){f.anim.update(f.group,f.camera,time);equal(f.model.position,expected,'queued whole-piece anchor');}
});
test('observed movement and animation clear/replay do not leave an old visual offset',()=>{
 const f=make('cavalry'),a=neighbors(f.u.c,f.u.r)[0];f.anim.observe([{...f.u,...a}],10);f.model.position.copy(point(a));f.anim.update(f.group,f.camera,10);equal(f.model.position,point(f.u),'observed move starts with base');
 f.anim.clear();f.model.position.copy(point(a));f.anim.observe([{...f.u,...a}],20);f.anim.update(f.group,f.camera,20);equal(f.model.position,point(a),'clear resets anchor');
});
