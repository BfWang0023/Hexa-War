import {offsetToWorld,worldToOffset} from '../js/core/hex.js';
export const MIDDLE_EARTH = [
  ['me_isen_first','艾辛河渡口·第一次','3019年 2月','洛汗','艾辛格','救援队沿东岸抵达后，至少撤出三队。希奥杰德获救会改变结局。'],
  ['me_isen_second','艾辛河渡口·第二次','3019年 3月','洛汗','艾辛格','守住渡口至第4回合，之后经东南道路撤出四队。'],
  ['me_hornburg','海尔姆深谷之战','3019年 3月','洛汗','艾辛格','等候甘道夫与鄂肯布兰德，随后从号角堡或洞窟出击夺回外堤。'],
  ['me_pelennor','佩兰诺平原之战','3019年 3月','刚铎与洛汗','魔多与盟军','守住城门内的城心，接应北方洛汗与南方黑船援军，夺回大道。'],
  ['me_erebor','孤山·五军之战','2941年','人类、精灵与矮人','半兽人与座狼','保持山门通路，击败波尔格与他的核心战团。'],
  ['me_pelargir','佩拉基尔夺船','3019年 3月','灰衣队伍与亡者','昂巴海盗','用亡者动摇守军，以活人占住至少两个泊位，阿拉贡亲临港口履约。'],
  ['me_morannon','黑门之战','3019年 3月','西方联军','魔多','在正面维持抵抗，同时让弗罗多携戒抵达末日裂隙。含西力斯昂哥序幕。'],
  ['me_morannon_final','黑门之战·直接决战','3019年 3月','西方联军','魔多','直接进入双战区。切换视图不会推进回合或恢复行动。'],
].map(([id,name,date,west,east,intro])=>({id,name,date,west,east,intro,title:`${name}（第三纪元 ${date}）`}));

export const ME_IDS = new Set(MIDDLE_EARTH.map(x=>x.id));
export const isMorannon = id => id==='me_morannon'||id==='me_morannon_final';

const foot = (name,hp,armor,melee,role,extra={}) => ({
  name,hp,armor,melee,role,move:2,vision:4,meleeHit:78,ranged:0,rangedHit:0,range:0,ammo:0,...extra
});
const bow={move:1,ranged:5.8,rangedHit:79,range:3,ammo:30,vision:6};
const charge={move:3,chargeClass:'cavalry',mountedRole:'shock'};
export const ME_STATS = {
  meGondor:foot('刚铎盾矛兵',108,2,7,'gondor',{move:1,formation:true}),
  meGuard:foot('刚铎王城卫队',135,3,9,'gondor',{move:1,elite:true,formation:true}),
  meGondorBow:foot('刚铎弓兵',74,0,4,'gondor',bow),
  meGondorHorse:foot('刚铎重骑兵',114,2,9,'gondor',charge),
  meRohan:foot('洛汗骑矛兵',100,1,9,'rohan',charge),
  meRohanLight:foot('洛汗轻骑',77,0,5,'rohan',{...bow,move:4,mountedRole:'skirmisher'}),
  meRohanFoot:foot('西谷步兵',92,1,7,'rohan'),
  meRohanBow:foot('洛汗步弓手',72,0,4,'rohan',bow),
  meOrc:foot('半兽人战团',66,0,6,'orc'),
  meOrcBow:foot('半兽人弓手',60,0,4,'orc',{...bow,range:3}),
  meTracker:foot('半兽人追踪者',57,0,5,'orc',{vision:6,move:3}),
  meUruk:foot('艾辛格强兽人',101,2,8,'uruk',{move:1,formation:true}),
  meUrukBow:foot('艾辛格紫杉弓手',79,1,6,'uruk',bow),
  meDunland:foot('登兰德战士',79,0,7,'dunland'),
  meWarg:foot('座狼骑兵',83,0,8,'wolf',{move:3}),
  meWolf:foot('座狼',60,0,7,'wolf',{move:3}),
  meElf:foot('林地精灵',81,0,6,'elf',{...bow,vision:7}),
  meDwarf:foot('铁丘陵矮人',125,3,9,'dwarf',{move:1,elite:true,formation:true}),
  meLake:foot('湖民长矛队',84,1,7,'lake'),
  meHarad:foot('南方军',81,1,6,'harad',{...bow,move:2,range:2}),
  meEast:foot('东方战士',96,2,7,'east',{move:1,formation:true}),
  meCorsair:foot('昂巴海盗',76,1,7,'corsair'),
  meMumak:foot('猛犸',240,3,15,'mumak',{large:true,story:true}),
  meTroll:foot('魔多巨魔',166,2,13,'troll',{large:true,story:true}),
  meNazgul:foot('戒灵与飞兽',140,2,12,'nazgul',{air:true,fear:true,story:true,move:5,airStrike:2}),
  meWitchKing:foot('安格玛巫王',165,2,13,'nazgul',{air:true,fear:true,story:true,move:5,airStrike:2}),
  meDead:foot('亡者军团',95,0,1,'dead',{fear:true,story:true}),
  meEagle:foot('巨鹰',116,1,12,'eagle',{air:true,story:true,move:5,airStrike:2}),
  meBeorn:foot('比翁巨熊',175,2,14,'bear',{large:true,story:true}),
  meFrodo:foot('弗罗多',42,0,3,'hobbit',{story:true,vision:4,move:2}),
  meSam:foot('山姆',58,1,8,'hobbit',{story:true,move:2}),
  meGollum:foot('咕噜',42,0,7,'gollum',{story:true,move:2}),
  meShelob:foot('尸罗',95,1,12,'spider',{story:true}),
  meAragorn:foot('阿拉贡',151,2,12,'gondor',{story:true}),
  meEowyn:foot('伊欧温',106,1,10,'rohan',{story:true}),
  meMerry:foot('梅里',56,0,7,'hobbit',{story:true}),
  meRiderLord:foot('洛汗将领',128,2,10,'rohan',{...charge,story:true}),
  meCaptain:foot('西谷将领',123,2,10,'rohan',{story:true}),
  meThorin:foot('索林',143,3,11,'dwarf',{story:true}),
  meBolg:foot('波尔格',147,2,11,'orc',{story:true}),
  meGandalf:foot('甘道夫',135,2,10,'wizard',{story:true}),
  meBlast:foot('萨鲁曼的爆破装置',70,1,0,'blast',{large:true,story:true,move:1}),
  meGrond:foot('格龙德',235,2,21,'grond',{large:true,story:true,move:1}),
  meBlackShip:foot('黑船',170,1,0,'ship',{story:true,move:0}),
};
export const meKind = kind => ME_STATS[kind];
export function meMountedRole(map,u){
  if(!u||u.onFoot)return null;
  return map?.victory?.army?.mounts?.[u.kind]||meKind(u.kind)?.mountedRole||null;
}

// Coordinates in the chapter plans are local authoring coordinates.
export const MORANNON_WINDOWS={front:[0,27],pass:[30,54],doom:[57,81]};
const EXPANDED_MORANNON_WINDOWS={front:[0,36],pass:[39,68],doom:[71,105]};
export function morannonWindows(map){
  const v=map?.victory?.layoutVersion;
  if(v===4||v===5){
    const scale=middleEarthScale(v);
    return Object.fromEntries(Object.entries(EXPANDED_MORANNON_WINDOWS).map(([zone,range])=>[zone,range.map(x=>Math.round(x*scale))]));
  }
  return v===3?LARGE_MORANNON_WINDOWS:(v===2||v===6)?EXPANDED_MORANNON_WINDOWS:MORANNON_WINDOWS;
}
export const expandedMorannonCell=(c,r)=>({c:c+(c<27?4:c<54?11:18),r:r+4});
export function morannonCell(c,r,map){
  const cell={c:c<19?c+(c<12?2:7):c<40?c+10:c+17,r:r+3};
  if(!(map?.victory?.layoutVersion>=2))return cell;
  const expanded=expandedMorannonCell(cell.c,cell.r);
  return projectMiddleEarthCell(map,expanded.c,expanded.r);
}

const LARGE_MORANNON_WINDOWS={front:[0,208],pass:[212,420],doom:[424,632]};
const LARGE_BOARDS={
  isen:[224,208,82,88],
  hornburg:[240,208,82,86],
  pelennor:[240,224,102,92],
  erebor:[224,224,84,80],
  pelargir:[224,208,96,86],
  morannon:[632,208],
};
export function largeMiddleEarthBoard(id){
  return LARGE_BOARDS[id.split('_')[1]];
}
export function largeMiddleEarthCell(id,c,r){
  const board=largeMiddleEarthBoard(id);
  if(!isMorannon(id))return {c:c+board[2],r:r+board[3]};
  const zone=Object.keys(EXPANDED_MORANNON_WINDOWS).find(z=>{
    const [left,right]=EXPANDED_MORANNON_WINDOWS[z];
    return c>=left&&c<right;
  });
  if(!zone)throw Error('黑门坐标不属于战区');
  const shift={front:78,pass:92,doom:88}[zone];
  return {c:LARGE_MORANNON_WINDOWS[zone][0]+shift+c-EXPANDED_MORANNON_WINDOWS[zone][0],r:r+88};
}


export const MIDDLE_EARTH_SCALE=7;
export const middleEarthScale=layoutVersion=>layoutVersion===5?MIDDLE_EARTH_SCALE/2:layoutVersion===4?MIDDLE_EARTH_SCALE:1;
export function projectMiddleEarthCell(map,c,r){
  if(map.victory.layoutVersion===3)return largeMiddleEarthCell(map.scenarioId,c,r);
  if(![4,5].includes(map.victory.layoutVersion))return {c,r};
  const p=offsetToWorld(c,r),scale=middleEarthScale(map.victory.layoutVersion),half=(scale-1)/2;
  const width=offsetToWorld(1,0).x;
  const f=worldToOffset(p.x*scale+width*(half+.25),p.z*scale+9*half);
  let first=0,last=map.cols;
  if(isMorannon(map.scenarioId)){
    const zone=Object.keys(EXPANDED_MORANNON_WINDOWS).find(k=>{
      const [a,b]=EXPANDED_MORANNON_WINDOWS[k];
      return c>=a&&c<b;
    });
    if(zone)[first,last]=morannonWindows(map)[zone];
  }
  return {c:Math.max(first,Math.min(last-1,f.col)),r:Math.max(0,Math.min(map.rows-1,f.row))};
}
