import {STATS} from './engine.mjs';
import {ROLE_KINDS,DIRECTIONS} from './tactical-units.mjs';
import {FORMATION_DOCTRINE} from './formation-doctrine.mjs';
import {ORDER_TEMPLATES} from './tactical-templates.mjs';
export const COMMAND_VERSION=1;
export const ACTION_TYPES=Object.freeze(['move','attack','form','defend','hold','stop','demolish','deploy','template','logistics','rally','capture']);
const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
function keys(o,allowed){if(!object(o)||Object.keys(o).some(k=>!allowed.includes(k)))throw Error('命令包含未知字段');}
const directions=[...Object.keys(DIRECTIONS),'forward','back','left','right'];
function integer(value,min,max,message){if(!Number.isInteger(value)||value<min||value>max)throw Error(message);}
function point(p){keys(p,['c','r']);integer(p.c,0,159,'目标坐标无效');integer(p.r,0,99,'目标坐标无效');}
export function validateSelector(s,enemy=false){
 keys(s,['scope','role','kind','ids','wing','zone','hpBelow','nearest','nearWall','rank','name','exceptPrior','front','group','lastOrder','kinds','exclude']);
 if(!['all','selected'].includes(s.scope)||enemy&&s.scope==='selected')throw Error('单位选择范围无效');
 if(s.role&&!Object.hasOwn(ROLE_KINDS,s.role)||s.kind&&!Object.hasOwn(STATS,s.kind))throw Error('未知兵种');
 if(s.kinds&&(!Array.isArray(s.kinds)||!s.kinds.length||s.kinds.length>100||s.kinds.some(k=>!Object.hasOwn(STATS,k))))throw Error('未知兵种集合');
 if(s.exclude){if(s.exclude.exclude)throw Error('排除选择不可递归');validateSelector(s.exclude,enemy);}
 if(s.ids&&(!Array.isArray(s.ids)||s.ids.length>1024||s.ids.some(id=>typeof id!=='string'||id.length>40)))throw Error('单位编号无效');
 if(s.wing&&!['left','right','center'].includes(s.wing)||s.zone&&!['front','rear','reserve','depth'].includes(s.zone))throw Error('战场位置无效');
 if(s.hpBelow!==undefined&&(!Number.isFinite(s.hpBelow)||s.hpBelow<=0||s.hpBelow>1))throw Error('生命比例无效');
 for(const k of ['nearest','rank','front'])if(s[k]!==undefined)integer(s[k],1,k==='nearest'?200:k==='front'?32:10,'数量或战线无效');
 if(s.exceptPrior!==undefined&&(typeof s.exceptPrior!=='boolean'||enemy))throw Error('其他部队选择范围无效');
 if(s.lastOrder!==undefined&&(typeof s.lastOrder!=='boolean'||enemy))throw Error('旧命令引用无效');
 if(s.nearWall!==undefined&&typeof s.nearWall!=='boolean')throw Error('选择条件无效');
 for(const k of ['name','group'])if(s[k]!==undefined&&(typeof s[k]!=='string'||!s[k].length||s[k].length>40))throw Error('选择名称无效');
}
function location(a){
 keys(a,['position','side','select','feature','name','ordinal','relation','distance']);if([a.position,a.select,a.feature].filter(Boolean).length!==1)throw Error('请明确一种参考区域');
 if(a.side!==undefined&&!['own','enemy'].includes(a.side))throw Error('参考阵营无效');
 if(a.position)point(a.position);if(a.select){validateSelector(a.select,a.side==='enemy');if(a.select.exceptPrior||a.select.lastOrder)throw Error('参考部队不可使用其他部队补集');}
 if(a.feature&&!['bridge','wall','depot','route','road','landmark'].includes(a.feature))throw Error('地物种类无效');
 if(a.name!==undefined&&(typeof a.name!=='string'||!a.name.length||a.name.length>40)||a.feature==='landmark'&&!a.name)throw Error('地标名称无效');
 if(a.ordinal!==undefined)integer(a.ordinal,1,32,'地物序号无效');
 if(a.relation!==undefined&&!['center','front','rear','left','right'].includes(a.relation))throw Error('参考位置关系无效');
 if(a.distance!==undefined)integer(a.distance,0,12,'参考距离无效');
}
const fields={
 capture:['kind','position','name'],
 move:['direction','distance','position','anchor','keepFormation','alongRoad'],attack:['target','advance','repeat','fireOnly','focus','charge'],form:['formed','direction'],defend:[],hold:[],stop:['mode'],demolish:['structure','position'],
 deploy:['shape','rows','columns','spacing','direction','anchor','formed','alongRoad'],template:['template','reference','rows','direction','distance','shape'],logistics:['mode','target'],rally:['wings','allocation','reference'],
};
export function validateTacticalCommand(raw){
 keys(raw,['v','confidence','clarification','orders']);if(raw.v!==1||!Number.isFinite(raw.confidence)||raw.confidence<0||raw.confidence>1||typeof raw.clarification!=='string'||raw.clarification.length>200||!Array.isArray(raw.orders)||raw.orders.length>12)throw Error('传令格式无效');
 if(raw.clarification||raw.confidence<.85){if(!raw.clarification)throw Error('命令含义不确定，请明确部队、动作和目标');return structuredClone(raw);}
 if(!raw.orders.length)throw Error('未识别出可执行动作');const ids=new Set();
 for(let oi=0;oi<raw.orders.length;oi++){
  const order=raw.orders[oi];keys(order,['id','after','select','steps']);validateSelector(order.select);if(oi===0&&order.select.exceptPrior)throw Error('请先明确其他部队相对于哪组部队');
  if(order.after!==undefined&&(!Array.isArray(order.after)||order.after.length>12||order.after.some(id=>!ids.has(id))))throw Error('依赖任务不存在、尚未定义或形成循环');
  if(order.id!==undefined){if(typeof order.id!=='string'||!/^[a-zA-Z][a-zA-Z0-9_-]{0,31}$/.test(order.id)||ids.has(order.id))throw Error('任务编号无效或重复');ids.add(order.id);}
  if(!Array.isArray(order.steps)||!order.steps.length||order.steps.length>12)throw Error('动作数量无效');
  for(const s of order.steps){if(!object(s)||!fields[s.type])throw Error('不支持该动作');keys(s,['type',...fields[s.type]]);
   if(s.direction!==undefined&&!directions.includes(s.direction))throw Error('方向无效');
   for(const k of ['keepFormation','formed','advance','repeat','fireOnly','focus','alongRoad','charge'])if(s[k]!==undefined&&typeof s[k]!=='boolean')throw Error('动作参数无效');
   if(s.position)point(s.position);if(s.anchor)location(s.anchor);if(s.reference)location(s.reference);
   if(s.distance!==undefined)integer(s.distance,1,20,'距离无效');
   if(s.type==='capture'&&(!['any','fortress','segment'].includes(s.kind)||s.name!==undefined&&(typeof s.name!=='string'||!s.name.length||s.name.length>80)))throw Error('占领目标无效');
   if(s.type==='rally'&&(s.wings!=='both'||s.allocation!=='nearest'))throw Error('两翼集结参数无效');
   if(s.type==='move'&&([s.position,s.direction,s.anchor].filter(Boolean).length!==1||s.direction&&s.distance===undefined))throw Error('请指定有效方向和距离，或目标区域');
   if(s.type==='attack'){if(s.charge&&s.fireOnly)throw Error('冲锋只能近战，不能同时自由射击');if(!s.target)throw Error('攻击命令缺少目标');validateSelector(s.target,true);}
   if(s.type==='form'&&typeof s.formed!=='boolean')throw Error('阵型状态无效');
   if(s.type==='stop'&&!['all','move','attack'].includes(s.mode))throw Error('停止动作范围无效');
   if(s.type==='demolish'&&(!['bridge','wall'].includes(s.structure)||!s.position))throw Error('请指定要破坏的桥梁或城墙坐标');
   if(s.type==='deploy'&&!FORMATION_DOCTRINE[s.shape]||s.type==='template'&&!ORDER_TEMPLATES[s.template])throw Error('阵型或模板无效');
   if(s.shape!==undefined&&!FORMATION_DOCTRINE[s.shape])throw Error('阵型无效');
   for(const k of ['rows','columns'])if(s[k]!==undefined)integer(s[k],1,12,'阵型排数无效');
   if(s.spacing!==undefined)integer(s.spacing,1,3,'阵型间距无效');
   if(s.type==='logistics'){if(!['deliver','refill','connect','guard','reroute','relocate'].includes(s.mode))throw Error('后勤动作无效');if(s.target)validateSelector(s.target);if(['deliver','connect'].includes(s.mode)&&!s.target)throw Error('请指定受补给部队');}
  }
 }
 return structuredClone(raw);
}
