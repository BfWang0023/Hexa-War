import * as E from './engine.mjs';
import {isMorannon,morannonWindows,middleEarthScale,projectMiddleEarthCell} from './middle-earth-data.mjs';
import {offsetToWorld,worldToOffset} from '../js/core/hex.js';

const {ROAD,RIVER,SEA}=E.TERRAIN;
const width=offsetToWorld(1,0).x;
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const key=p=>E.key(p.c,p.r);
const wet=t=>t&(RIVER|SEA);
const slope=(a,b)=>a*b>0?2*a*b/(a+b):0;
function interpolate(a,b,c,d,t){
  const t2=t*t,t3=t2*t;
  return (2*t3-3*t2+1)*b+(t3-2*t2+t)*slope(b-a,c-b)
    +(-2*t3+3*t2)*c+(t3-t2)*slope(c-b,d-c);
}

function traceLine(a,b){
  const n=E.distance(a,b),path=[a];
  for(let i=1;i<=n;i++){
    const current=path.at(-1),x=a.c+(b.c-a.c)*i/n,y=a.r+(b.r-a.r)*i/n;
    const next=E.neighbors(current.c,current.r).filter(p=>E.distance(p,b)===n-i)
      .sort((p,q)=>Math.hypot(p.c-x,p.r-y)-Math.hypot(q.c-x,q.r-y))[0];
    path.push(next);
  }
  return path;
}

export function scaleMiddleEarthMap(base,layoutVersion){
  const {scenarioId:id}=base,dual=isMorannon(id);
  const scale=middleEarthScale(layoutVersion),half=(scale-1)/2;
  const victory={...base.victory,layoutVersion,turnLimit:Math.ceil(base.victory.turnLimit*2.6)};
  const map=E.newMap(Math.round(base.cols*scale),Math.round(base.rows*scale),{scenarioId:id,victory});
  Object.assign(map,{scenarioId:id,victory,name:base.name,intro:base.intro,factions:base.factions,gateRules:base.gateRules});
  map.elevations=Array(map.cols*map.rows).fill(-.46);
  if(dual)map.terrain.fill(SEA);
  const project=(c,r)=>projectMiddleEarthCell(map,c,r),shift=p=>({...p,...project(p.c,p.r)});
  const oldZones=dual?morannonWindows(base):{battle:[0,base.cols]};
  const zones=dual?morannonWindows(map):{battle:[0,map.cols]};
  const sourceBridges=new Set(base.bridges.map(key));
  for(const [zone,[left,right]] of Object.entries(zones)){
    const [first,last]=oldZones[zone];
    const sourceAt=(x,r)=>{
      const row=clamp(r,0,base.rows-1);
      const u=clamp(x/width-(row&1)*.5,first,last-1),c=Math.floor(u);
      const height=col=>base.elevations[E.index(base,clamp(col,first,last-1),row)];
      return interpolate(height(c-1),height(c),height(c+1),height(c+2),u-c);
    };
    for(let r=0;r<map.rows;r++)for(let c=left;c<right;c++){
      const world=offsetToWorld(c,r);
      const x=(world.x-width*(half+.25))/scale,z=(world.z-9*half)/scale;
      const source=worldToOffset(x,z),c0=clamp(source.col,first,last-1),r0=clamp(source.row,0,base.rows-1);
      const t=base.terrain[E.index(base,c0,r0)],i=E.index(map,c,r);
      map.terrain[i]=t&~ROAD;
      if(!wet(t)){
        const f=z/9,row=Math.floor(f);
        const height=interpolate(sourceAt(x,row-1),sourceAt(x,row),sourceAt(x,row+1),sourceAt(x,row+2),f-row);
        map.elevations[i]=Math.round(height*100)/100||0;
      }
    }
  }
  const fineBridges=new Set();
  const layRoad=(p,onBridge)=>{
    const i=E.index(map,p.c,p.r);
    if(map.terrain[i]===SEA)return;
    map.terrain[i]|=ROAD;
    if(onBridge&&map.terrain[i]&RIVER)fineBridges.add(key(p));
  };
  for(let r=0;r<base.rows;r++)for(let c=0;c<base.cols;c++){
    if(!(base.terrain[E.index(base,c,r)]&ROAD))continue;
    const a=project(c,r),firstBridge=sourceBridges.has(E.key(c,r));
    layRoad(a,firstBridge);
    for(const v of E.neighbors(c,r)){
      if(!E.inBounds(base,v.c,v.r)||E.index(base,v.c,v.r)<=E.index(base,c,r)||
         !(base.terrain[E.index(base,v.c,v.r)]&ROAD))continue;
      const path=traceLine(a,project(v.c,v.r)),secondBridge=sourceBridges.has(key(v));
      path.forEach((p,i)=>layRoad(p,i<path.length/2?firstBridge:secondBridge));
    }
  }
  map.bridges=[...fineBridges].map(k=>{const [c,r]=k.split(',').map(Number);return {c,r};});
  for(let r=0;r<base.rows;r++)for(let c=0;c<base.cols;c++){
    if(!base.houses[E.index(base,c,r)])continue;
    const p=project(c,r);
    E.setHouse(map,p.c,p.r);
  }

  // Extend each existing wall connection through the intervening fine hexes.
  // Gate, breach target and mobile units keep one identity at their new anchors.
  const forts=base.units.filter(u=>u.kind==='fort');
  const byCell=new Map(forts.map(u=>[key(u),u]));
  const scaledForts=new Map(forts.map(u=>[key(shift(u)),shift(u)]));
  for(const u of forts)for(const neighbor of E.neighbors(u.c,u.r)){
    const v=byCell.get(key(neighbor));
    if(!v||v.team!==u.team||Number(v.id.slice(1))<=Number(u.id.slice(1)))continue;
    for(const p of traceLine(project(u.c,u.r),project(v.c,v.r)).slice(1,-1)){
      if(!scaledForts.has(key(p)))scaledForts.set(key(p),{...u,...p,gate:false,
        level:Math.min(u.level,v.level),hp:E.FORT_HP[Math.min(u.level,v.level)]});
    }
  }
  map.units=[...scaledForts.values(),...base.units.filter(u=>u.kind!=='fort').map(shift)]
    .map((u,i)=>({...u,id:'u'+(i+1)}));
  for(const u of map.units){
    const i=E.index(map,u.c,u.r);
    if(u.kind==='fort'){
      // The wall deck spans the water underneath the original line.
      if(wet(map.terrain[i]))map.terrain[i]=ROAD;
      map.houses[i]=0;
    }
  }
  map.bridges=map.bridges.filter(({c,r})=>map.terrain[E.index(map,c,r)]===(RIVER|ROAD));
  map.landmarks=base.landmarks.map(shift);
  victory.points=Object.fromEntries(Object.entries(base.victory.points).map(([k,p])=>[k,shift(p)]));
  victory.waves=base.victory.waves.map(w=>({...w,rows:w.rows.map(([kind,c,r,name])=>{
    const p=project(c,r);
    return [kind,p.c,p.r,name];
  })}));
  return map;
}
