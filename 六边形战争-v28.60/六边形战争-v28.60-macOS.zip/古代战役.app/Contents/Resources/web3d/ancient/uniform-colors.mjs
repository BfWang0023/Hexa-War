import {factionColor,DEFAULT_COLORS} from './faction-colors.mjs';
// A bounded shared material pair per authored material; geometry/animation untouched.
const entries=[];const cache=new WeakMap();
export function syncUniformColors(){for(const e of entries){if(factionColor(e.team)===DEFAULT_COLORS[e.team])e.copy.color.copy(e.original.color);else{e.copy.color.set(factionColor(e.team));e.copy.color.multiplyScalar(e.shade);}}}
export function applyUniformColors(root,team,materials){
 const accents=new Set(['blue','red','shieldBlue','shieldRed','royalBlue','indigo','cinnabar'].map(n=>materials[n]).filter(Boolean));
 root.traverse(o=>{if(!o.isMesh||!o.material)return;let person=false;for(let p=o.parent;p;p=p.parent)if(['soldier','rider'].includes(p.name))person=true;
 const recolor=original=>{if(!accents.has(original)&&!(person&&original===materials.linen))return original;let byTeam=cache.get(original);if(!byTeam){byTeam=new Map();cache.set(original,byTeam);}if(!byTeam.has(team)){const copy=original.clone();copy.userData.sharedUnitPalette=true;byTeam.set(team,copy);entries.push({original,copy,team,shade:original===materials.linen?1:.88});}return byTeam.get(team);};
 o.material=Array.isArray(o.material)?o.material.map(recolor):recolor(o.material);
 });syncUniformColors();return root;
}
