import * as THREE from '../vendor/three/three.module.js';
export function createTerrainEnvironment(scene,renderer) {
  // Atmospheric distance haze is separate from the opaque knowledge mask.
  // Keep the full battlefield legible at the existing maximum tactical zoom.
  if(scene.fog?.isFog){scene.fog.near=320;scene.fog.far=1400;}
  scene.add(new THREE.HemisphereLight(0xe9eee1,0x5e5b4a,1.35));
  const sun=new THREE.DirectionalLight(0xffecd1,1.85);scene.add(sun,sun.target);
  renderer.shadowMap.type=THREE.BasicShadowMap;
  renderer.shadowMap.autoUpdate=false;
  sun.shadow.mapSize.set(1024,1024);sun.shadow.bias=-.0005;sun.shadow.normalBias=.14;
  let quality='standard';
  return {
    invalidate(){renderer.shadowMap.needsUpdate=true;},
    setQuality(value){quality=value;sun.castShadow=quality==='standard';renderer.shadowMap.enabled=sun.castShadow;renderer.shadowMap.needsUpdate=true;},
    focus(p,distance){
      const extent=Math.min(320,Math.max(55,distance*1.1));
      sun.target.position.set(p.x,0,p.z);sun.position.set(p.x-100,160,p.z-80);
      Object.assign(sun.shadow.camera,{left:-extent,right:extent,top:extent,bottom:-extent,near:1,far:800});
      sun.shadow.camera.updateProjectionMatrix();renderer.shadowMap.needsUpdate=true;
    },
  };
}
// Content signature deliberately excludes mobile units, HP, fog and turn state.
export function terrainSignature(m) {
  return JSON.stringify([m.scenarioId,m.cols,m.rows,Array.from(m.terrain),Array.from(m.houses||[]),m.bridges||[],m.garden,m.victory]);
}
