import test from 'node:test';import assert from 'node:assert/strict';import * as E from './engine.mjs';import {formationMoveRange,executeGroupMove,executeArmyOrder} from './group-command.mjs';import {loadBindings} from './input-map.mjs';
function fixture(){const m=E.newMap(24,16);for(const [kind,team,c,r] of [['light','egypt',5,5],['light','egypt',5,6],['light','coalition',21,14]])E.addUnit(m,kind,team,c,r);E.addUnit(m,'pharaoh','egypt',1,1);return E.startGame(m);}
test('strict formation moves equal hex distance, or none when the actual route is blocked',()=>{const s=fixture(),units=s.map.units.filter(u=>u.team==='egypt'&&u.kind==='light'),ids=new Set(units.map(u=>u.id)),range=formationMoveRange(s,ids),plan=range.get('7,5');assert.ok(plan);const initial=units.map(({c,r})=>({c,r}));const blocked=structuredClone(s);E.addUnit(blocked.map,'light','coalition',7,6);assert.equal(executeGroupMove(blocked,plan).success,0);assert.deepEqual(blocked.map.units.slice(0,2).map(({c,r})=>({c,r})),initial);assert.equal(executeGroupMove(s,plan).success,2);assert.deepEqual(units.map((u,i)=>E.distance(u,initial[i])),[2,2]);assert.ok(units.every(u=>u.actionsLeft===1));});
test('attack area marks empty reachable targets without enabling attacks on empty cells',()=>{const s=fixture(),u=s.map.units[0];const outline=E.attackArea(s,u);assert.ok(outline.some(p=>p.c===6&&p.r===5&&!p.occupied));assert.ok(!outline.some(p=>p.c===5&&p.r===6));assert.equal(E.attackPreview(s,u,6,5),null);u.actionsLeft=0;assert.deepEqual(E.attackArea(s,u),[]);});
test('old custom E binding migrates without losing its action',()=>{const saved={confirm:'Enter',cancel:'Escape',pan:'Space',officer:'Alt+KeyO',top:'KeyE',settings:'Comma',follow:'KeyF',report:'KeyR'};const bindings=loadBindings({getItem:()=>JSON.stringify(saved)});assert.equal(bindings.top,'KeyE');assert.notEqual(bindings.endTurn,'KeyE');});
test('scouts gain one or two downhill cells but a ridge obscures uphill targets',()=>{const s=fixture();E.addUnit(s.map,'scout','egypt',5,10);const fog=s.fog.egypt.visible,h=s.map.elevations,at=(c,r)=>E.index(s.map,c,r);h[at(5,10)]=1;E.recomputeFog(s);assert.ok(fog.has('14,10'));assert.ok(!fog.has('15,10'));h[at(5,10)]=4;E.recomputeFog(s);assert.ok(fog.has('15,10'));assert.ok(!fog.has('16,10'));h[at(5,10)]=0;h[at(8,10)]=3;h[at(11,10)]=2;E.recomputeFog(s);assert.ok(fog.has('8,10'));assert.ok(!fog.has('11,10'));});
test('intact enemy walls hide defenders behind them while wall-top and breach rays stay visible',()=>{const s=fixture();E.addUnit(s.map,'scout','egypt',8,10);for(let r=6;r<=13;r++)E.setFort(s.map,10,r,2,'coalition');E.addUnit(s.map,'light','coalition',10,10);E.addUnit(s.map,'light','coalition',12,10);E.addUnit(s.map,'light','coalition',12,12);E.recomputeFog(s);assert.equal(E.knownUnitAt(s,'egypt',10,10)?.kind,'light');assert.equal(E.knownUnitAt(s,'egypt',12,10),null);assert.equal(E.knownUnitAt(s,'egypt',12,12),null);E.fortAt(s.map,10,10).hp=0;E.recomputeFog(s);assert.equal(E.knownUnitAt(s,'egypt',12,10)?.kind,'light');assert.equal(E.knownUnitAt(s,'egypt',12,12),null);});


test('historical batch moves several units to distinct legal cells',()=>{
  const s=fixture(),troops=s.map.units.slice(0,2);
  const before=troops.map(u=>u.actionsLeft);
  const result=executeArmyOrder(s,troops.map(u=>u.id),{c:8,r:5});
  assert.equal(result.moved,2);
  assert.equal(new Set(troops.map(u=>E.key(u.c,u.r))).size,2);
  assert.ok(troops.every((u,i)=>u.c>5&&u.actionsLeft>=0&&u.actionsLeft<before[i]));
});

test('historical focus fire selects the exact enemy on a wall and stops when it falls',()=>{
  const m=E.newMap(20,15);
  E.setFort(m,7,7,1,'coalition');
  for(const [kind,team,c,r] of [['light','egypt',6,7],['archer','egypt',6,8],
    ['light','coalition',7,7],['light','coalition',10,7]]) E.addUnit(m,kind,team,c,r);
  E.addUnit(m,'pharaoh','egypt',1,1);
  const s=E.startGame(m,{fogPolicy:{unitFog:true}}),troops=s.map.units.filter(u=>u.team==='egypt'&&u.kind!=='pharaoh');
  const wall=E.fortAt(s.map,7,7),target=E.mobileAt(s.map,7,7);
  const strike=(state,id,c,r)=>E.attack(state,id,c,r,0,.5,.9,.9);
  const wallHp=wall.hp,guardHp=target.hp;
  const wallOrder=executeArmyOrder(s,[troops[0].id],wall,{mode:'target',targetId:wall.id,strike});
  assert.equal(wallOrder.attacked,1);
  assert.ok(wall.hp<wallHp);
  assert.equal(target.hp,guardHp);
  target.hp=1;
  troops[0].actionsLeft=2;
  E.recomputeFog(s);
  const remainingWall=wall.hp,other=E.mobileAt(s.map,10,7),otherHp=other.hp;
  const ap=troops.reduce((n,u)=>n+u.actionsLeft,0);
  const focused=executeArmyOrder(s,troops.map(u=>u.id),target,{mode:'target',targetId:target.id,strike});
  assert.equal(focused.attacked,1);
  assert.equal(target.hp,0);
  assert.equal(wall.hp,remainingWall);
  assert.equal(other.hp,otherHp);
  assert.equal(troops.reduce((n,u)=>n+u.actionsLeft,0),ap-1);
});

test('historical naval batches use water routes and retain each ship attack cap',()=>{
  const m=E.newMap(20,15);
  m.terrain.fill(E.TERRAIN.SEA);
  for(const [team,c,r] of [['egypt',5,5],['egypt',5,7],['coalition',13,6]]) E.addUnit(m,'warship',team,c,r);
  E.setTerrain(m,1,1,E.TERRAIN.PLAIN);
  E.addUnit(m,'pharaoh','egypt',1,1);
  const s=E.startGame(m),ships=s.map.units.filter(u=>u.team==='egypt'&&E.isShip(u));
  const ids=ships.map(u=>u.id);
  const result=executeArmyOrder(s,ids,{c:8,r:6});
  assert.equal(result.moved,2);
  assert.notEqual(E.key(ships[0].c,ships[0].r),E.key(ships[1].c,ships[1].r));
  const target=s.map.units.find(u=>u.team==='coalition');
  for(const ship of ships){ship.actionsLeft=2;ship.attacksUsed=0;}
  [target.c,target.r]=[9,6];
  E.recomputeFog(s);
  const order=executeArmyOrder(s,ids,target,{mode:'area',strike:(state,id,c,r)=>E.attack(state,id,c,r,0,.5,.9,.9)});
  assert.ok(order.attacked>0);
  assert.ok(order.results.every(entry=>entry.attacks<=1));
  assert.ok(ships.every(ship=>ship.attacksUsed<=1));
});
