import {fortificationLayout,isSolidWall,usesFortificationLayout} from './fortification-layout.mjs';
import {armyReservePending, deployArmyWave, initializeArmy, validateArmy, validateArmySave} from './middle-earth-armies.mjs';
import {recordBattleEvent} from './turn-report.mjs';
import {groundConnection} from './cliff-navigation.mjs';
import * as E from './engine.mjs';
import {ME_IDS,isMorannon,meKind,meMountedRole,morannonWindows,morannonCell,projectMiddleEarthCell} from './middle-earth-data.mjs';

const west='egypt', east='coalition';
const blastDamage=[90,60,30];
export const hornburgBlastRadius=blastDamage.length-1;
export const blastOnlyWall=(m,f)=>m.scenarioId==='me_hornburg'&&m.victory.layoutVersion===6&&
  f?.kind==='fort'&&f.cityId==='深谷墙'&&!f.gate;

function detonate(s,device,wall){
  wall.hp=0;
  device.escaped=true;
  if(s.map.victory.layoutVersion!==6){
    event(s,'breach','萨鲁曼的装置炸开了深谷墙。');
    return;
  }
  for(const u of s.map.units){
    if(!alive(u)||u.kind==='fort'||meAir(u))continue;
    const damage=blastDamage[E.distance(u,wall)];
    if(!damage)continue;
    u.hp=Math.max(0,u.hp-damage);
    if(u.hp===0){
      u.actionsLeft=0;
      recordBattleEvent(s,'death',u,device);
    }
  }
  event(s,'breach','萨鲁曼的炸药炸开了三级深谷墙，冲击波波及两格内双方地面部队。');
}
const alive=u=>u&&u.hp>0&&!u.escaped;
const active=u=>alive(u)&&!E.isRouted(u)&&u.kind!=='fort';
const at=(u,p)=>u&&p&&u.c===p.c&&u.r===p.r;
const actor=(s,kind)=>s.map.units.find(u=>u.kind===kind);
export const meAir=u=>!!meKind(u?.kind)?.air;
export const meIndependent=u=>['meGollum','meShelob'].includes(u?.kind);
export function meZone(c,map){
  const windows=morannonWindows(map);
  return Object.keys(windows).find(z=>c>=windows[z][0]&&c<windows[z][1])||'gap';
}

export function validateMiddleEarth(map){
  const v=map.victory;
  if(v?.layoutVersion!==undefined&&(![2,3,4,5,6].includes(v.layoutVersion)||!Array.isArray(map.elevations)))
    throw Error('中土地图版本或高程无效');
  if(!ME_IDS.has(map.scenarioId)||v?.mode!=='middle-earth'||!Number.isInteger(v.turnLimit)||
     v.turnLimit<8||v.turnLimit>(v.layoutVersion>=4?120:60)||!v.points||!Array.isArray(v.waves)||v.waves.length>20)throw Error('中土剧本配置无效');
  const keys={
    me_isen_first:['ford','exit'],me_isen_second:['ford','exit'],me_hornburg:['core','cave','counter','culvert','blast'],
    me_pelennor:['core','gate','counter'],me_erebor:['core','counter'],me_pelargir:['core','dock0','dock1','dock2']
  }[map.scenarioId]||['front','start','pass','ash','crack','flee'];
  if(isMorannon(map.scenarioId)&&['meFrodo','meSam','meGollum','meNazgul'].some(kind=>map.units.filter(u=>u.kind===kind).length!==1))
    throw Error('黑门剧本缺少唯一剧情角色');
  if(keys.some(k=>!E.inBounds(map,v.points[k]?.c,v.points[k]?.r)))throw Error('中土目标格无效');
  const waveKeys=new Set();
  for(const w of v.waves){
    if(!w||typeof w.key!=='string'||waveKeys.has(w.key)||![west,east].includes(w.team)||
       !Number.isInteger(w.turn)||w.turn<2||!Array.isArray(w.rows)||w.rows.length>20||
       w.rows.some(([kind,c,r])=>!meKind(kind)||!E.inBounds(map,c,r)))throw Error('中土增援配置无效');
    waveKeys.add(w.key);
  }
  validateArmy(map);
}
export function initializeMiddleEarth(s,seed=28647){
  const dual=isMorannon(s.map.scenarioId), final=s.map.scenarioId==='me_morannon_final';
  s.middleEarth={version:1,random:seed>>>0,events:{},withdrawn:[],hold:0,attention:0,alert:null,
    nextSearch:final?1:2,trace:null,ring:dual?'meFrodo':null,stealth:'normal',
    phase:dual?(final?'final':'prologue'):'battle',phaseTurn:1,view:dual?(final?'front':'pass'):'battle'};
  initializeArmy(s);
  if(dual&&final)planEye(s);
}
export function meRoll(s){
  const d=s.middleEarth;
  d.random=(Math.imul(d.random,1664525)+1013904223)>>>0;
  return d.random/4294967296;
}
function event(s,key,text){
  const d=s.middleEarth;
  if(d.events[key])return;
  d.events[key]={turn:s.turn,text};
  s.log.push(text);
}
function finish(s,winner,reason){
  s.over=true;s.winner=winner;s.victoryReason=reason;
  event(s,'ending',reason);
  return winner;
}
function held(s,point,team){
  return s.map.units.some(u=>active(u)&&u.team===team&&!meAir(u)&&u.kind!=='meDead'&&at(u,point));
}
export function meUnitActive(s,u){
  if(!s.middleEarth)return !u?.escaped;
  if(!u||u.escaped||u.meInTransit)return false;
  if(!isMorannon(s.map.scenarioId))return true;
  return s.middleEarth.phase==='prologue'?meZone(u.c,s.map)==='pass':meZone(u.c,s.map)!=='pass';
}
export function meMoveAllowed(s,u,c,r){
  if(!s.middleEarth)return true;
  if(!meUnitActive(s,u)||u.kind==='meBlackShip'||u.meStunnedUntil>=s.turn)return false;
  if(isMorannon(s.map.scenarioId)&&meZone(u.c,s.map)!==meZone(c,s.map))return false;
  const cave=s.map.victory.points.cave;
  if(meAir(u)&&cave&&E.distance({c,r},cave)<=1)return false;
  const p=s.map.victory.points.culvert;
  if(p&&(s.map.victory.layoutVersion===6?at({c,r},p):s.map.victory.layoutVersion>=4?Math.abs(c-p.c)<=1&&E.distance({c,r},p)<=(s.map.victory.layoutVersion>=5?2:4):at({c,r},p))){
    if(s.middleEarth.events.seal&&!s.middleEarth.events.breach)return false;
    if(!['meOrc','meOrcBow','meTracker','meRohanFoot','meRohanBow','meAragorn'].includes(u.kind))return false;
  }
  if(u.kind==='meDead'){const a=actor(s,'meAragorn');if(!alive(a)||E.distance(a,{c,r})>(s.map.victory.layoutVersion>=5?11:s.map.victory.layoutVersion===4?21:7))return false;}
  if(s.map.victory.layoutVersion>=2&&!meAir(u)){
    const terrain=E.tile(s.map,c,r)?.terrain??0;
    const cliff=s.map.victory.layoutVersion<6&&s.map.elevations?.[E.index(s.map,c,r)]>=5.8;
    const mounted=meMountedRole(s.map,u)||['meWarg','meWolf'].includes(u.kind);
    if(terrain&E.TERRAIN.MOUNTAIN&&!(terrain&E.TERRAIN.ROAD)&&(cliff||mounted))return false;
  }
  const terrain=E.tile(s.map,c,r)?.terrain??0;
  const rough=terrain&E.TERRAIN.MOUNTAIN&&!(s.map.victory.layoutVersion>=2&&terrain&E.TERRAIN.ROAD);
  if(meKind(u.kind)?.large&&(E.fortAt(s.map,c,r)||rough))return false;
  return true;
}
export function meAttackAllowed(s,u,target,melee){
  if(!s.middleEarth)return true;
  if(!meUnitActive(s,u)||!meUnitActive(s,target)||u.meStunnedUntil>=s.turn||u.kind==='meBlackShip'||target.kind==='meDead')return false;
  if(s.map.scenarioId==='me_pelennor'&&target.kind==='fort'&&target.cityId==='米那斯提力斯主城'&&
    (!target.gate||u.kind!=='meGrond'))return false;
  if(isMorannon(s.map.scenarioId)&&meZone(u.c,s.map)!==meZone(target.c,s.map))return false;
  if(u.kind==='meBlast')return false;
  if(u.kind==='meGrond'&&!(target.kind==='fort'&&target.gate&&at(target,s.map.victory.points.gate)))return false;
  if(meAir(target)&&!meAir(u)&&(!meKind(u.kind)?.ranged||melee))return false;
  return true;
}
export function meAfterAttack(s,u,target,result){
  if(!s.middleEarth||!result.ok)return;
  if(meAir(u))u.meLow=true;
  if(u.kind==='meDead'&&active(target))target.morale=Math.max(.21,(target.morale??1)-.14);
  if(u.kind==='meSam'&&['meShelob','meGollum'].includes(target?.kind)&&result.hit){
    if(target.kind==='meShelob'){
      const frodo=actor(s,'meFrodo');
      if(frodo)delete frodo.meStunnedUntil;
      event(s,'sam-rescue','山姆以刺叮驱退尸罗，解除弗罗多的麻痹。');
    }else if(s.middleEarth.ring==='meGollum'){
      s.middleEarth.ring='ground';s.middleEarth.drop={c:target.c,r:target.r};
      event(s,'ring-drop','咕噜松开了魔戒，可由弗罗多或山姆拾取。');
    }
  }
  if(target?.kind==='meWitchKing'&&target.hp<=0&&!s.middleEarth.events['witch-king']){
    for(const v of s.map.units)if(v.team===east&&active(v)&&E.distance(v,target)<=4)v.morale=Math.max(.22,(v.morale??1)-.22);
    event(s,'witch-king','巫王退场，附近魔多战团士气动摇。');
  }
}
export function setStealth(s,mode){
  const d=s.middleEarth,f=actor(s,'meFrodo');
  if(!d||!isMorannon(s.map.scenarioId)||s.over||s.side!==west||!active(f)||f.actionsLeft<=0||
     !['normal','careful','hidden'].includes(mode))return false;
  if(mode==='hidden'){
    if(!cover(s,f))return false;
    f.actionsLeft--;
  }
  d.stealth=mode;return true;
}
export function meMoveSteps(s,u,steps){
  return s.middleEarth&&u.kind==='meFrodo'&&s.middleEarth.stealth==='careful'?Math.min(s.map.victory.layoutVersion>=5?2:s.map.victory.layoutVersion===4?4:1,steps):steps;
}
export function siegeObjective(s,u){
  const p=s.map.victory.points;
  const site=u.kind==='meBlast'&&s.map.scenarioId==='me_hornburg'?p?.blast:
    u.kind==='meGrond'&&s.map.scenarioId==='me_pelennor'?p?.gate:null;
  return site?E.fortAt(s.map,site.c,site.r):null;
}
export function siegeContact(m,u,wall){
  if(!wall||E.distance(u,wall)!==1)return false;
  if(u.kind==='meBlast')return true;
  const works=usesFortificationLayout(m)?fortificationLayout(m):null;
  return !groundConnection(m,u,u,wall)&&(!works||works.gateConnects(wall,u)&&!works.blocksEdge(u,wall));
}
function readyBlast(s,device){
  const d=s.middleEarth;
  if(d.blastReady||!active(device)||!siegeContact(s.map,device,siegeObjective(s,device)))return;
  d.blastReady=s.turn;
  event(s,'blast-ready','爆破装置已抵达深谷墙。保持在原位，到下一个艾辛格阶段时引爆。');
}
export function meAfterMove(s,u,path){
  if(!s.middleEarth)return;
  if(u.kind==='meBlast'){
    if(siegeContact(s.map,u,siegeObjective(s,u)))readyBlast(s,u);
    else delete s.middleEarth.blastReady;
  }
  if(u.kind==='meFrodo'){
    if(s.middleEarth.stealth==='hidden')s.middleEarth.stealth='normal';
    s.middleEarth.noise=path.length>1&&s.middleEarth.stealth==='normal';
  }
  if(s.map.scenarioId==='me_hornburg'&&u.team===east&&path.some(p=>E.distance(p,s.map.victory.points.culvert)<=(s.map.victory.layoutVersion===6?0:s.map.victory.layoutVersion===5?1:s.map.victory.layoutVersion===4?2:0)))
    event(s,'infiltration','半兽人已穿过涵洞。守军可封堵涵洞，也可阻截爆破装置。');
}
export function sealCulvert(s){
  const p=s.map.victory.points.culvert;
  if(!p||s.side!==west||s.over||s.middleEarth.events.seal||s.map.victory.layoutVersion===6&&s.middleEarth.events.breach)return false;
  const u=s.map.units.find(u=>u.team===west&&active(u)&&u.actionsLeft>0&&!meAir(u)&&E.distance(u,p)===1);
  if(!u)return false;
  u.actionsLeft--;event(s,'seal','守军封住了溪流涵洞。');return true;
}

function cover(s,u){
  const t=E.tile(s.map,u.c,u.r)?.terrain;
  return !!(t&E.TERRAIN.MOUNTAIN)&&!(t&E.TERRAIN.ROAD)||E.houseAt(s.map,u.c,u.r);
}
export function chooseEyeArea(state,map){
  const pool=[[45,8],[48,12],[48,4],[52,9],[54,6],[59,5]].map(([c,r])=>morannonCell(c,r,map));
  const trace=state.trace;
  if(trace?.confidence>0)pool.push(...Array(Math.ceil(trace.confidence*3)).fill({c:trace.c,r:trace.r}));
  return pool[Math.min(pool.length-1,Math.floor(meRoll({middleEarth:state})*pool.length))];
}
const eyeRadius=map=>map.victory.layoutVersion>=5?4:map.victory.layoutVersion===4?8:2;
function planEye(s){
  const d=s.middleEarth;
  if(d.alert||s.turn<d.nextSearch||d.phase!=='final')return;
  d.alert={...chooseEyeArea(d,s.map),turn:s.turn,radius:eyeRadius(s.map)};
}
function observeRing(s){
  const d=s.middleEarth,f=actor(s,'meFrodo');
  if(!alive(f)||meZone(f.c,s.map)!=='doom')return;
  const ranges=s.map.victory.layoutVersion>=5?[5,2]:s.map.victory.layoutVersion===4?[9,3]:[3,1];
  const contact=ranges[d.stealth==='normal'?0:1];
  const sighted=s.map.units.some(u=>u.team===east&&!meIndependent(u)&&active(u)&&meZone(u.c,s.map)==='doom'&&
    E.distance(u,f)<=contact&&E.unitSightCells(s,u).has(E.key(f.c,f.r)));
  const a=d.alert, searched=a?.turn===s.turn&&E.distance(a,f)<=a.radius&&
    !(d.stealth==='hidden'&&cover(s,f))&&(!cover(s,f)||d.noise||E.distance(a,f)<=1);
  if(sighted||searched){
    d.trace={c:f.c,r:f.r,turn:s.turn,confidence:1};
    event(s,'detected','魔多已发现弗罗多的踪迹，巡逻队正在奔赴最后发现位置。');
  }
}
function findRing(s){
  const d=s.middleEarth, f=actor(s,'meFrodo'),sam=actor(s,'meSam'),g=actor(s,'meGollum');
  if(d.ring==='meGollum'&&!alive(g)){d.ring='ground';d.drop={c:g.c,r:g.r};}
  if(d.ring==='meSam'&&!alive(sam)){d.ring='ground';d.drop={c:sam.c,r:sam.r};}
  if(d.ring==='mordor'){
    const keeper=s.map.units.find(u=>u.id===d.keeper);
    if(!alive(keeper)&&keeper){d.ring='ground';d.drop={c:keeper.c,r:keeper.r};delete d.keeper;}
  }
  if(d.ring==='ground'){
    const enemy=s.map.units.find(u=>u.team===east&&active(u)&&!meIndependent(u)&&!meAir(u)&&at(u,d.drop));
    if(enemy){
      d.ring='mordor';d.keeper=enemy.id;delete d.drop;
      event(s,'mordor-ring','魔多已拾取魔戒。在它带回巡逻营地前可以截回。');
      return;
    }
    const u=[f,sam].find(u=>alive(u)&&E.distance(u,d.drop)<=1);
    if(u){d.ring=u.kind;delete d.drop;}
  }
  if(d.ring==='meSam'&&alive(f)&&alive(sam)&&E.distance(f,sam)<=1)d.ring='meFrodo';
}
export function checkMiddleEarth(s){
  const d=s.middleEarth,id=s.map.scenarioId,p=s.map.victory.points;
  if(!d||s.over)return s.winner;
  if(isMorannon(id)){
    const f=actor(s,'meFrodo'),g=actor(s,'meGollum');
    findRing(s);
    if(!alive(f))return finish(s,east,'弗罗多阵亡，护戒任务失败。');
    if(d.phase==='final'&&d.ring==='meFrodo'&&at(f,p.crack)&&!(f.meStunnedUntil>=s.turn))
      return finish(s,west,alive(g)?'魔戒在末日裂隙毁灭。':'本局改写结局：弗罗多在末日裂隙毁戒。');
    if(d.phase==='final'&&d.ring==='mordor'){
      const keeper=s.map.units.find(u=>u.id===d.keeper);
      if(alive(keeper)&&E.distance(keeper,morannonCell(47,3,s.map))<=1)
        return finish(s,east,'魔多已将魔戒带回巡逻营地。');
    }
    if(d.phase==='final'&&d.ring==='meGollum'&&at(g,p.flee))return finish(s,east,'咕噜已带戒逃离，无法追回。');
    if(d.phase==='final'&&!s.map.units.some(u=>u.team===west&&active(u)&&meZone(u.c,s.map)==='front')&&!armyReservePending(s,west))
      return finish(s,east,'西方联军已失去全部有效抵抗力量。');
    if(d.phase==='prologue'&&d.ring==='meFrodo'&&at(f,p.pass)&&!(f.meStunnedUntil>=s.turn)){
      Object.assign(f,p.ash);f.actionsLeft=0;
      const sam=actor(s,'meSam');if(alive(sam)){Object.assign(sam,morannonCell(44,10,s.map));sam.actionsLeft=0;}
      if(alive(g))Object.assign(g,morannonCell(46,12,s.map));
      d.phase='final';d.phaseTurn=s.turn;d.view='doom';d.nextSearch=s.turn+1;
      event(s,'timeskip','时间跳转：弗罗多抵达末日山，西方联军开始牵制黑门。');
      E.recomputeFog(s);
    }
    return;
  }
  if(id.startsWith('me_isen')){
    const first=id.endsWith('first'),ready=first?d.events.rescue:d.events.delay;
    if(ready)for(const u of s.map.units){
      if(u.team!==west||!active(u)||E.distance(u,p.exit)>1)continue;
      u.escaped=true;u.actionsLeft=0;d.withdrawn.push(u.id);
      if(first&&u.kind==='meRiderLord')event(s,'theodred','本局改写：希奥杰德撤出了渡口。');
    }
    if(d.withdrawn.length>=(first?3:4))return finish(s,west,'洛汗完成接应与撤离。');
  }else if(id==='me_pelargir'){
    const a=actor(s,'meAragorn');
    const ships=s.map.units.filter(u=>u.kind==='meBlackShip'&&alive(u));
    if(!alive(a)||ships.length<2)return finish(s,east,'阿拉贡未能履约，或可接管的黑船不足。');
    d.docks=ships.filter(ship=>s.map.units.some(u=>u.team===west&&active(u)&&u.kind!=='meDead'&&E.distance(u,ship)===1)&&
      !s.map.units.some(u=>u.team===east&&u.kind!=='meBlackShip'&&active(u)&&E.distance(u,ship)===1)).map(u=>u.r);
    for(const ship of ships)ship.meDockTeam=d.docks.includes(ship.r)?west:east;
    if(d.docks.length>=2&&E.distance(a,p.core)<=1){
      for(const u of s.map.units)if(u.kind==='meDead')u.escaped=true;
      event(s,'oath','亡者在佩拉基尔履约后离去。');
      return finish(s,west,'活人已接管黑船，阿拉贡释放亡者。');
    }
  }else if(id==='me_erebor'){
    const foes=s.map.units.filter(u=>u.team===east&&active(u));
    const scattered=d.army?Math.ceil(s.map.victory.army.total[1]*.28):5;
    if(!alive(actor(s,'meBolg'))&&foes.length<=scattered&&!armyReservePending(s,east)&&held(s,p.counter,west))return finish(s,west,'联军打通山门并瓦解波尔格军团。');
  }else{
    const ready=id==='me_hornburg'?d.events.dawn:d.events.ships;
    const leader=id==='me_hornburg'?'meGandalf':'meAragorn';
    const reliefArrived=!d.army||s.map.units.some(u=>u.kind===leader&&u.team===west);
    const lostCore=held(s,p.core,east)&&(!p.cave||held(s,p.cave,east));
    if(ready&&reliefArrived&&!lostCore&&held(s,p.counter,west))return finish(s,west,'守军接应援军并夺回反击节点。');
  }
  if(!s.map.units.some(u=>u.team===west&&active(u))&&!armyReservePending(s,west))return finish(s,east,'守军已无可用战斗力量。');
}
function spawnWave(s,w){
  let count=0;
  for(const [kind,c,r,name] of w.rows){
    const origin={c,r},cells=[origin,...E.neighbors(c,r),...E.neighbors(c,r).flatMap(p=>E.neighbors(p.c,p.r))];
    const p=cells.find(p=>E.inBounds(s.map,p.c,p.r)&&!E.mobileAt(s.map,p.c,p.r)&&!E.fortAt(s.map,p.c,p.r)&&E.addUnit(s.map,kind,w.team,p.c,p.r));
    if(p){const u=s.map.units.at(-1);if(name)u.customName=name;count++;}
  }
  event(s,w.key,`${w.label}（${count} 队）`);
}
function applyFear(s){
  const sources=s.map.units.filter(u=>active(u)&&meUnitActive(s,u)&&meKind(u.kind)?.fear);
  for(const u of s.map.units){
    if(u.team!==s.side||!active(u)||!meUnitActive(s,u)||meKind(u.kind)?.story||u.meFearTurn===s.turn)continue;
    if(sources.some(v=>v.team!==u.team&&E.distance(v,u)<=2)){
      u.meFearTurn=s.turn;
      u.morale=Math.max(0,(u.morale??1)-(meKind(u.kind)?.elite?.06:.18));
      if(u.morale<.24){u.routed=true;u.actionsLeft=0;}
    }
  }
}
export function middleEarthBeforeSide(s){
  const d=s.middleEarth;
  if(s.side===west&&d.phase==='final'){
    observeRing(s);
    if(d.alert?.turn===s.turn){
      d.alert=null;
      d.nextSearch=s.turn+(d.trace?.confidence>.5?1:d.attention>=.67?3:d.attention>=.32?2:1);
    }
  }
}
export function middleEarthAfterSide(s,priorSide){
  const d=s.middleEarth,id=s.map.scenarioId,p=s.map.victory.points;
  if(s.over||s.battlePhase==='pursuit')return;
  for(const u of s.map.units)if(u.team===s.side&&meAir(u))u.meLow=false;
  if(priorSide===east){
    if(id==='me_isen_second'&&s.turn===4&&s.map.units.some(u=>u.team===west&&active(u)&&E.distance(u,p.ford)<=2))
      event(s,'delay','渡口已完成迟滞，东南撤离路线开放。');
    if(id==='me_isen_second'&&s.turn===4&&!d.events.delay)return finish(s,east,'洛汗过早放弃渡口，未能完成迟滞。');
    if(['me_hornburg','me_pelennor','me_erebor'].includes(id)){
      d.hold=held(s,p.core,east)&&(!p.cave||held(s,p.cave,east))?d.hold+1:0;
      if(d.hold>=2)return finish(s,east,'敌军连续两回合控制内层目标。');
    }
    if(d.phase==='final'){
      const nazgul=actor(s,'meNazgul');
      if(alive(nazgul)&&d.trace?.confidence>=.5&&meZone(nazgul.c,s.map)==='front'&&!nazgul.meInTransit){
        nazgul.meInTransit=s.turn+2;nazgul.actionsLeft=0;
        event(s,'nazgul-depart','一名戒灵离开黑门，正赶往末日山。');
      }
      if(alive(nazgul)&&nazgul.meInTransit&&s.turn>=nazgul.meInTransit){
        const cell=[47,48,49].map(c=>morannonCell(c,3,s.map)).find(p=>!s.map.units.some(u=>alive(u)&&meAir(u)&&at(u,p)));
        if(cell){
          Object.assign(nazgul,cell);delete nazgul.meInTransit;
          event(s,'nazgul-arrive','黑门调来的戒灵已抵达巡逻营地。');
        }
      }
      const visible=s.fog[east].visible;
      const front=s.map.units.filter(u=>u.team===west&&active(u)&&meZone(u.c,s.map)==='front'&&
        visible.has(E.key(u.c,u.r))&&E.distance(u,p.front)<=4);
      const engaged=front.filter(u=>u.meEngagedTurn>=s.turn-2).length;
      d.attention=d.attention*.55+Math.min(1,front.length*.09+engaged*.14)*.45;
      if(d.trace){d.trace.confidence=Math.max(0,1-(s.turn-d.trace.turn)*.28);if(!d.trace.confidence)d.trace=null;}
      planEye(s);
    }
    if(s.turn>s.map.victory.turnLimit)return finish(s,east,'超过剧本回合上限，任务失败。');
  }
  const waveTurn=d.phase==='final'?s.turn-d.phaseTurn+1:s.turn;
  if(d.phase!=='prologue'){
    const waves=s.map.victory.waves.filter(w=>w.team===s.side&&w.turn<=waveTurn);
    if(d.army)for(const w of [...waves].sort((a,b)=>Number(b.story)-Number(a.story)))deployArmyWave(s,w,event);
    else for(const w of waves)if(!d.events[w.key])spawnWave(s,w);
  }
  if(id==='me_hornburg'&&s.side===east){
    const device=actor(s,'meBlast'),wall=device&&siegeObjective(s,device);
    if(active(device)&&siegeContact(s.map,device,wall)&&!d.events.breach){
      if(d.blastReady&&d.blastReady<s.turn){detonate(s,device,wall);delete d.blastReady;}
      else readyBlast(s,device);
    }else delete d.blastReady;
  }
  if(id==='me_hornburg'&&d.events.dawn&&s.side===east){
    for(const u of s.map.units)if(u.team===east&&E.isRouted(u)&&alive(u)){
      if(u.c>=projectMiddleEarthCell(s.map,31,0).c){u.escaped=true;event(s,'huorns','胡恩树群封住退路，溃散敌军已退出战斗。');}
      if(u.kind==='meDunland'){u.escaped=true;event(s,'dunland-surrender','失去组织的登兰德战士投降。');}
    }
  }
  applyFear(s);E.recomputeFog(s);E.checkVictory(s);
}

export function objectiveDistances(s,u,goal){
  const m=E.observedMap(s,u.team),view={...s,map:m},queue=[goal],steps=new Map([[E.key(goal.c,goal.r),0]]);
  const large=m.victory.layoutVersion>=3&&m.victory.layoutVersion<6;
  const margin=m.victory.layoutVersion===4?28:large?20:Math.max(m.cols,m.rows);
  const forts=new Map(m.units.filter(v=>v.kind==='fort'&&v.hp>0).map(v=>[E.key(v.c,v.r),v]));
  const works=usesFortificationLayout(m)?fortificationLayout(m):null;
  const left=Math.min(goal.c,u.c)-margin,right=Math.max(goal.c,u.c)+margin;
  const top=Math.min(goal.r,u.r)-margin,bottom=Math.max(goal.r,u.r)+margin;
  for(let i=0;i<queue.length;i++){
    const at=queue[i],n=steps.get(E.key(at.c,at.r))+1;
    if(large&&at.c===u.c&&at.r===u.r)break;
    for(const p of E.neighbors(at.c,at.r)){
      const key=E.key(p.c,p.r);
      if(steps.has(key)||!E.inBounds(m,p.c,p.r)||p.c<left||p.c>right||p.r<top||p.r>bottom)continue;
      if(!meMoveAllowed(view,u,at.c,at.r)||groundConnection(m,u,p,at)||E.fortificationStep(m,u,p,at,works))continue;
      const t=m.terrain[E.index(m,p.c,p.r)],f=forts.get(key);
      const groundRoute=works&&isSolidWall(f)&&!(p.c===u.c&&p.r===u.r);
      if(!meAir(u)&&(t===E.TERRAIN.SEA||t&E.TERRAIN.RIVER&&!(t&E.TERRAIN.ROAD)||f&&!E.canPassFort(u,f)||groundRoute))continue;
      steps.set(key,n);queue.push(p);
    }
  }
  return steps;
}
export function middleEarthAi(s){
  const d=s.middleEarth,team=s.side,p=s.map.victory.points,id=s.map.scenarioId,actions=[];
  const force=s.map.units.filter(u=>u.team===team&&active(u)&&meUnitActive(s,u)&&
    !meIndependent(u)&&u.kind!=='meBlackShip');
  const priority=u=>['meBlast','meGrond'].includes(u.kind)?-1:u.kind==='meAragorn'&&id==='me_pelargir'?2:Number(!!meKind(u.kind)?.range);
  const ids=(d.army?[...force].sort((a,b)=>priority(a)-priority(b)):force).map(u=>u.id);
  const maps=new Map();
  for(const uid of ids){
    const u=s.map.units.find(v=>v.id===uid);
    for(let n=0;n<2&&active(u)&&u.actionsLeft>0&&!s.over;n++){
      const visible=s.fog[team].visible;
      const foes=s.map.units.filter(v=>alive(v)&&v.team!==team&&meUnitActive(s,v)&&
        visible.has(E.key(v.c,v.r))&&(!isMorannon(id)||meZone(u.c,s.map)===meZone(v.c,s.map))&&
        (v.kind!=='meFrodo'||(d.trace&&at(v,d.trace))));
      foes.sort((a,b)=>E.distance(u,a)-E.distance(u,b));
      const target=foes.find(v=>E.attackPreview(s,u,v.c,v.r)?.target.id===v.id);
      if(target&&u.kind!=='meBlast'&&d.keeper!==u.id){
        const result=E.attack(s,u.id,target.c,target.r,meRoll(s),meRoll(s),meRoll(s),meRoll(s));
        if(result.ok){if(target.kind==='fort'&&target.hp<=0)maps.clear();actions.push({id:u.id,type:'attack',...result,result});continue;}
      }
      const siege=['meBlast','meGrond'].includes(u.kind);
      const wall=siege?siegeObjective(s,u):null;
      if(siege&&(!wall||siegeContact(s.map,u,wall)))break;
      let goal=foes.find(v=>v.kind!=='fort');
      if(id.startsWith('me_isen'))goal=team===east?(d.withdrawn.length?p.exit:p.ford):d.events.delay||d.events.rescue?p.exit:p.ford;
      else if(id==='me_hornburg')goal=team===west?(d.events.dawn?p.counter:p.core):u.kind==='meBlast'?p.blast:
        ['meOrc','meOrcBow'].includes(u.kind)&&!d.events.seal?p.culvert:goal||p.core;
      else if(id==='me_pelennor')goal=team===east?(u.kind==='meGrond'?p.gate:goal||p.core):d.events.ships?p.counter:goal||p.core;
      else if(id==='me_erebor')goal=team===west?goal||p.counter:goal||p.core;
      else if(id==='me_pelargir')goal=team===west?u.kind==='meAragorn'?p.core:p['dock'+(Number(uid.slice(1))%3)]:goal||p.core;
      else if(meZone(u.c,s.map)==='doom'){
        if(team===east)goal=d.keeper===u.id?morannonCell(47,3,s.map):d.trace||morannonCell(47+(Number(uid.slice(1))%3),s.turn%4<2?7:12,s.map);
        else goal=u.kind==='meFrodo'?p.crack:actor(s,'meFrodo');
      }else if(d.phase==='prologue')goal=u.kind==='meFrodo'?p.pass:actor(s,'meFrodo');
      else goal=goal||p.front;
      const lane=d.army?.roles[u.id], ranged=!!meKind(u.kind)?.range;
      if(lane&&u.kind!=='meBlast'&&u.kind!=='meGrond'){
        const rally=lane.goal;
        const withdrawing=team===west&&id.startsWith('me_isen')&&(d.events.delay||d.events.rescue);
        const relief=team===west&&(id==='me_hornburg'&&d.events.dawn||id==='me_pelennor'&&d.events.ships);
        if(!withdrawing&&!relief){
          const local=foes.find(v=>v.kind!=='fort'&&E.distance(v,rally)<=5&&E.distance(u,v)<=6);
          goal=local||rally;
        }
      }
      const oathBearer=d.army&&id==='me_pelargir'&&team===west&&u.kind==='meAragorn';
      if(oathBearer&&(d.docks?.length??0)<2)goal={c:26,r:p.core.r};
      let siegeRoute;
      if(siege){
        const known=E.observedMap(s,u.team);
        const approaches=E.neighbors(wall.c,wall.r).filter(p=>E.inBounds(s.map,p.c,p.r)&&
          siegeContact(s.map,{...u,...p},wall)&&!E.mobileAt(known,p.c,p.r));
        const routes=approaches.map(p=>({p,steps:objectiveDistances(s,u,p)}));
        routes.sort((a,b)=>(a.steps.get(E.key(u))??Infinity)-(b.steps.get(E.key(u))??Infinity));
        goal=routes[0]?.p;
        siegeRoute=routes[0]?.steps;
      }
      if(!goal)break;
      const cacheKey=d.army&&u.kind!=='meDead'?`${goal.c},${goal.r}:${u.kind}:${isMorannon(id)?meZone(u.c,s.map):''}`:null;
      let distances=siegeRoute||(cacheKey&&maps.get(cacheKey));
      if(!distances){distances=objectiveDistances(s,u,goal);if(cacheKey)maps.set(cacheKey,distances);}
      const estimate=v=>distances.get(E.key(v.c,v.r))??Infinity;
      const candidates=[...E.reachable(s,u).values()].filter(v=>{
        if(!(estimate(v)<estimate(u)))return false;
        const blast=d.army&&id==='me_hornburg'&&team===east&&!d.events.breach&&actor(s,'meBlast');
        if(alive(blast)&&u.id!==blast.id&&E.distance(v,p.blast)<=1)return false;
        const ram=id==='me_pelennor'&&team===east&&actor(s,'meGrond');
        const gate=alive(ram)&&siegeObjective(s,ram);
        if(gate&&ram.id!==u.id&&siegeContact(s.map,{...ram,...v},gate))return false;
        if(oathBearer&&foes.some(foe=>E.distance(v,foe)<=2))return false;
        if(d.army&&ranged&&u.ammo>0&&foes.length&&foes.some(foe=>foe.kind!=='fort'&&E.distance(v,foe)<=1))return false;
        return true;
      });
      candidates.sort((a,b)=>estimate(a)-estimate(b)||a.cost-b.cost);
      const dest=candidates[0],from={c:u.c,r:u.r};
      if(!dest)break;
      const result=E.move(s,u.id,dest.c,dest.r);
      if(!result.ok)break;
      actions.push({id:u.id,type:'move',from,...result,to:{c:u.c,r:u.r,path:result.path}});
    }
  }
  if(!s.over)E.endSide(s);
  return actions;
}

export function independentMiddleEarth(s){
  const d=s.middleEarth,f=actor(s,'meFrodo'),sam=actor(s,'meSam');
  if(!active(f)||s.over)return;
  for(const u of s.map.units.filter(meIndependent)){
    if(!active(u)||!meUnitActive(s,u)||u.meActed===s.turn||s.over)continue;
    u.meActed=s.turn;
    d.npcActing=u.id;
    try{
      const target=u.kind==='meShelob'&&active(sam)&&E.distance(sam,u)===1?sam:f;
      const sees=E.unitSightCells(s,u).has(E.key(target.c,target.r));
      if(sees&&E.distance(u,target)===1&&u.kind==='meShelob'){
        const result=E.attack(s,u.id,target.c,target.r,meRoll(s),meRoll(s),meRoll(s),meRoll(s));
        if(result.hit&&target===f&&alive(f)){
          f.meStunnedUntil=s.turn+1;
          event(s,'paralysis','尸罗刺伤弗罗多。下一回合可用山姆攻击尸罗解除麻痹。');
        }
        continue;
      }
      if(u.kind==='meGollum'&&d.phase==='final'&&d.ring==='meFrodo'&&sees&&
        E.distance(u,f)===1&&(!alive(sam)||E.distance(u,sam)>1)){
        d.ring='meGollum';
        event(s,'ring-stolen','咕噜夺走魔戒，正赶往逃离口。击退他可拾回魔戒。');
        continue;
      }
      const goal=d.ring==='meGollum'&&u.kind==='meGollum'?s.map.victory.points.flee:
        sees?target:u.kind==='meShelob'?morannonCell(32,7,s.map):{c:u.c,r:Math.min(u.r+1,morannonCell(32,12,s.map).r)};
      const moves=[...E.reachable(s,u).values()].filter(p=>E.distance(p,goal)<E.distance(u,goal));
      moves.sort((a,b)=>E.distance(a,goal)-E.distance(b,goal));
      if(moves.length)E.move(s,u.id,moves[0].c,moves[0].r);
    }finally{delete d.npcActing;}
  }
}

export function validateMiddleEarthSave(scenario,game){
  const d=game?.middleEarth;
  if(!ME_IDS.has(scenario.scenarioId)){if(d)throw Error('历史战役不能加载中土任务状态');return;}
  if(!d||d.version!==1||!Number.isInteger(d.random)||d.random<0||d.random>0xffffffff||
     !['battle','prologue','final'].includes(d.phase)||!['battle','pass','front','doom'].includes(d.view)||
     !d.events||typeof d.events!=='object'||!Array.isArray(d.withdrawn)||d.npcActing||
     (d.alert&&(!E.inBounds(scenario,d.alert.c,d.alert.r)||!Number.isInteger(d.alert.turn)||d.alert.radius!==eyeRadius(scenario))))
    throw Error('中土章节存档状态无效');
  validateArmySave(scenario,d,game.map.units);
}
