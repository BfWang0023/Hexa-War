import {planningState} from './fog-policy.mjs';
import {buildUnitRegistry,matchUnitEntities,stripEntities} from './unit-registry.mjs';
import {STATS} from './engine.mjs';
import {ROLE_KINDS} from './tactical-units.mjs';
import {parseMilitaryOrder} from './order-military-parser.mjs';
const numbers={一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9,十:10};
export const number=s=>/^\d+$/.test(s)?Number(s):s==='二十'?20:s?.startsWith('十')?10+(numbers[s[1]]||0):numbers[s];
const kindAliases=Object.fromEntries([...Object.entries(STATS).filter(([k])=>!['fort','archer','cavalry'].includes(k)).map(([k,v])=>[v.name,k]),['骑射手','parthianHorseArcher'],['具装骑兵','parthianCataphract'],['马其顿长枪方阵','phalangite'],['攻城槌','siegeRam'],['中国重战车','chinaHeavyChariot']]);
const roles=[['斥候|侦察兵','scout'],['重型战车|重战车','heavyChariot'],['弩兵|弩手|弩箭手','crossbow'],['骑兵|骑士|骑射手','cavalry'],['弓箭手|弓兵|弓手','archer'],['长矛兵|长枪兵|枪兵|矛兵|长枪方阵','spear'],['剑盾步兵|剑盾兵|剑兵','sword'],['步兵','infantry'],['战车兵|战车','chariot'],['战象|象兵','elephant'],['攻城槌|攻城器械|器械','siege'],['粮车|运输队','supply'],['战船|舰船|船只|舰队','ship'],['工程兵|工兵','engineer'],['卫兵|卫队','guard'],['统帅|将军|英雄','commander'],['火牛','ox']];
const result=(orders,clarification='',confidence=1)=>({v:1,confidence,clarification,orders});
export function parseSelector(text,{enemy=false,inherit}={}){
 const select={scope:enemy?'all':/选中|已选|当前选择/.test(text)?'selected':/所有|全部|全军|全体|左翼|右翼|中央|前锋|后卫|预备队|前线|后方|第.*战线|第一|第二|第[一二三四五\d]+排|城墙|最近/.test(text)?'all':inherit?.scope||'selected'};
 for(const [re,role] of roles)if(new RegExp(re).test(text)){select.role=role;break;}
 const exact=Object.keys(kindAliases).sort((a,b)=>b.length-a.length).find(n=>text.includes(n));if(exact){select.kind=kindAliases[exact];delete select.role;}
 if(!enemy&&/所有|全部|全军|全体/.test(text)&&!/(兵|手|车|队|船|舰|象|牛|将军|统帅)/.test(text))delete select.role;
 if(/全军|全体部队|所有部队|全部单位/.test(text))delete select.role;
 if(/左翼/.test(text))select.wing='left';else if(/右翼/.test(text))select.wing='right';else if(/中央|中军/.test(text))select.wing='center';
 if(/前线|前排|前锋|第一线/.test(text))select.zone='front';else if(/预备队/.test(text))select.zone='reserve';else if(/纵深/.test(text))select.zone='depth';else if(/后方|后排|后卫/.test(text))select.zone='rear';const front=text.match(/第([一二三四五六七八九十\d]+)战线/);if(front)select.front=number(front[1]);const line=text.match(/第([一二三四五六七八九十\d]+)线/);if(line){select.rank=number(line[1]);delete select.zone;}
 const rank=text.match(/第([一二三四五六七八九十\d]+)排/);if(rank){select.rank=number(rank[1]);delete select.zone;}
 if(/城墙附近|城墙旁/.test(text))select.nearWall=true;
 if(/(?:生命|血量|耐久).*(?:低于|不足|少于).*(?:一半|半数|50\s*%)/.test(text))select.hpBelow=.5;
 const near=text.match(/最近的?([一二三四五六七八九十\d]+)[名支队个]?/);if(near)select.nearest=number(near[1]);
 if((select.role||select.kind)&&!enemy&&select.scope==='selected'&&!/选中|已选|当前选择/.test(text))select.scope='all';
 return select;
}
function direction(text){for(const [name,id] of [['东北偏东','ENE'],['西北偏西','WNW'],['西南偏西','WSW'],['东南偏东','ESE'],['向北','N'],['向南','S'],['东北','NE'],['西北','NW'],['东南','SE'],['西南','SW'],['向东','E'],['向西','W'],['向前','forward'],['前进','forward'],['推进','forward'],['向后','back'],['后撤','back'],['撤退','back'],['向左','left'],['向右','right']])if(text.includes(name))return id;return null;}
export function unknownSelector(text){let rest=text.replace(/仅(?=选中|已选)/g,'');for(const name of Object.keys(kindAliases).sort((a,b)=>b.length-a.length))rest=rest.split(name).join('');for(const [re] of roles)rest=rest.replace(new RegExp(re,'g'),'');rest=rest.replace(/(?:生命值|血量|耐久)(?:低于|不足|少于)(?:一半|半数|50\s*%)/g,'').replace(/第[一二两三四五六七八九十\d]+(?:战线|线|排)|最近的?[一二两三四五六七八九十\d]+[名支队个]?/g,'').replace(/距离敌军|距离敌人|选中|当前选择|当前|已选|的|全部|所有|全军|全体|单位|部队|士兵|左翼|右翼|前线|前排|后方|后排|城墙附近|城墙旁|中央|中军|前锋|后卫|预备队|纵深|集中|敌军|敌人|对方|敌方|[\s，,。]/g,'');return rest.length>0;}
function stepsFor(text){
 const steps=[];let rest=text,coord=text.match(/(?:坐标|格子|地格|位置|区域)\s*[（(]?\s*(\d+)\s*[,，、]\s*(\d+)\s*[)）]?/),dir=direction(text),n=text.match(/([一二两三四五六七八九十\d]+)\s*(?:个)?\s*(?:六边形|六角格|格)/),distance=n?number(n[1]):1;
 if(/撤退到|移动到|前往|移至|撤至|移动至|推进至/.test(text)&&!coord)return {clarification:'请给出目标坐标，例如“移动到坐标20,15”。'};
 if(/破坏|拆除|摧毁/.test(text)){if(!coord||!/(桥|城墙)/.test(text))return {clarification:'请明确要破坏的桥梁或城墙坐标。'};return {steps:[{type:'demolish',structure:text.includes('桥')?'bridge':'wall',position:{c:+coord[1],r:+coord[2]}}]};}
 if(/停止$/.test(text))return {steps:[{type:'stop',mode:'all'}]};
 if(/停止攻击|停火|停止射击/.test(text))return {steps:[{type:'stop',mode:'attack'}]};
 if(/停止移动|停止前进|停止行军/.test(text))return {steps:[{type:'stop',mode:'move'},...(/防御/.test(text)?[{type:'defend'}]:[])]};
 if(/取消.*(?:命令|指令|行动)|停止一切|全部停止/.test(text))return {steps:[{type:'stop',mode:'all'}]};
 const release=/解除.*(?:阵|队形)|解散.*阵|取消.*列阵/.test(text),form=/列阵|组成防御阵型|组成方阵|结成.*阵型/.test(text)&&!release;
 if(release)steps.push({type:'form',formed:false});
 if(/移动|推进|前进|后撤|撤退|行军/.test(text)){
  if(!dir&&!coord)return {clarification:'请指定移动方向、距离或目标坐标。'};
  steps.push({type:'move',...(coord?{position:{c:+coord[1],r:+coord[2]}}:{direction:dir,distance}),keepFormation:/保持.*(?:阵|队形)/.test(text)});
 }
 if(/自由射击|自由攻击|攻击|进攻|射击|冲锋|冲击/.test(text)&&!/停止/.test(text)){
  const free=/自由射击|自由攻击/.test(text),targetText=free?'全部敌军':text.split(/攻击|进攻|射击|冲锋|冲击/).at(-1);if(unknownSelector(targetText))return {unknown:true};
  if(!free&&!/敌|对方|敌军/.test(targetText))return {clarification:'请明确攻击哪类可见敌军，例如“攻击敌军弓箭手”。'};
  steps.push({type:'attack',target:parseSelector(targetText,{enemy:true}),advance:!free,repeat:true,fireOnly:/自由射击/.test(text),focus:/集中/.test(text),...(/冲锋|冲击/.test(text)?{charge:true,repeat:false}:{})});
 }
 if(form)steps.push({type:'form',formed:true,...(dir?{direction:dir}:{})});
 if(/原地防御|就地防御/.test(text)&&!steps.length)steps.push({type:'defend'});
 if(/保持原位|保持不动|原地待命|保持阵型/.test(text)&&!steps.length)steps.push({type:'hold'});
 return steps.length?{steps}:{unknown:true};
}
export function parseLocalOrder(input,context={}){
 if(context.state)context={...context,state:planningState(context.state,context.team)};
 const registry=buildUnitRegistry(context.state?.map,context.team,context.state?.rulesVersion);
 const entities=t=>matchUnitEntities(t,registry);
 const groups=[...new Set(context.state?.map.units.filter(u=>u.team===context.team).map(u=>u.formation).filter(Boolean)||[])].sort((a,b)=>b.length-a.length);
 const selectorFor=(t,options={})=>{const group=groups.find(g=>t.includes(g)),es=entities(t),clean=stripEntities(t,es).replace(group||'\u0000',''),select=parseSelector(clean,options);if(group){select.group=group;select.scope=/选中|已选/.test(t)?'selected':'all';}const named=context.state?.map.units.filter(u=>u.team===context.team&&u.customName&&t.includes(u.customName));if(named?.length)select.ids=named.map(u=>u.id);if(es.length){const kinds=[...new Set(es.flatMap(e=>e.kinds))];delete select.role;delete select.kind;if(kinds.length===1)select.kind=kinds[0];else select.kinds=kinds;if(!options.enemy&&!/选中|已选|当前选择|仅选/.test(t))select.scope="all";}return select;};
 const unknown=t=>unknownSelector(groups.reduce((a,g)=>a.split(g).join(''),stripEntities(t,entities(t))).replace(/[、]/g,""));
 if(typeof input!=='string'||!input.trim()||input.length>500)return {status:'clarify',command:result([],'请输入不超过500字的部队指令。',0)};
 const text=input.trim().replace(/[。！!]+$/,'').replace(/格后(?=冲锋|冲击|攻击)/g,'格然后');
 if(/^(取消(?:所有|全部|当前)?(?:命令|指令)|全部停止|停止|停)$/.test(text))return {status:'local',command:result([{select:{scope:/所有|全部/.test(text)?'all':'selected'},steps:[{type:'stop',mode:'all'}]}])};
 if(/自行|自己决定|最佳|看着办|赢下|制定.*(?:战略|战术)|你来指挥|随便/.test(text))return {status:'clarify',command:result([],'我只传达你的命令。请指定部队、动作和目标。',0)};
 if(/除了/.test(text)){
 const parts=text.split(/除了/),base=parts[0].replace(/[，,；;]+$/,''),exception=parts[1],a=parseLocalOrder(base,context),b=parseLocalOrder(exception.replace(/继续/,'向前'),context);
 if(a.status==='local'&&b.status==='local'){for(const o of a.command.orders)o.select.exclude=b.command.orders[0].select;return {status:'local',command:result([...a.command.orders,...b.command.orders])};}
 }
 const ambiguous=entities(text.split(/向|攻击|进攻|冲锋|冲击|列成|排成|组成|保持|集结|停止/)[0]).find(e=>e.kinds.length>1);
 if(ambiguous){const narrowed=context.selectedIds?.map(id=>context.state?.map.units.find(u=>u.id===id)).filter(u=>u&&ambiguous.kinds.includes(u.kind));if(!/选中|已选/.test(text)||new Set(narrowed?.map(u=>u.kind)).size!==1)return {status:'clarify',command:result([],`“${ambiguous.fragment}”对应多个真实兵种：${ambiguous.kinds.map(k=>STATS[k].name).join('、')}。请指定兵种或仅选中其中一种。`,0)};}
 const incomplete=text.split(/[；;]/).find(t=>/列$/.test(t)&&entities(t).length);
 if(incomplete){const e=entities(incomplete);return {status:'clarify',bindings:e,command:result([],`已识别：${e.map(x=>x.registeredName).join('、')}。请补全“列”的动作，例如“列成两排横队”；协同部署等待完整命令。`,0)};}
 const occupation=text.match(/^(.*?)(重新占领|占领|夺取|收复|夺回)(.+)$/);
 if(occupation&&!/[；;]|然后|随后|接着/.test(text)){
  const subject=occupation[1].replace(/请让|请将|请|让|把|将/g,'').trim(),target=occupation[3],select=selectorFor(subject),coord=target.match(/(?:坐标|地格|位置)\s*[（(]?\s*(\d+)\s*[,，、]\s*(\d+)/);
  if(unknown(subject))return {status:'remote',reason:'需要进一步理解部队描述'};
  if(!/堡垒|营地|工事|城墙|防线|城池/.test(target))return {status:'clarify',command:result([],'请明确堡垒、城墙或工事目标。',0)};
  const name=target.replace(/(?:坐标|地格|位置)\s*[（(]?\s*\d+\s*[,，、]\s*\d+[)）]?/g,'').replace(/无人驻守的?|敌军|敌方|我方|己方|对方|的|堡垒|营地|工事|城墙|防线|城池|\s/g,'');
  return {status:'local',command:result([{select,steps:[{type:'capture',kind:/堡垒|城池/.test(target)?'fortress':/城墙|防线/.test(target)?'segment':'any',...(coord?{position:{c:+coord[1],r:+coord[2]}}:{}),...(name?{name}:{})}]}])};
 }
 const military=parseMilitaryOrder(text,{parseSelector:selectorFor,unknownSelector:unknown,number,markText:stripEntities(text,entities(text))});if(military)return military;
 const clauses=text.split(/[；;]|，(?=(?:所有|全部|左翼|右翼|第一|第二|第\d|其他|后方|前线))|,(?=(?:所有|全部|左翼|右翼|其他))/).filter(Boolean),orders=[];
 for(const clause of clauses){
  if(/其他部队/.test(clause)&&/保持原位|保持不动|原地待命|停止攻击|停止移动/.test(clause)){if(!orders.length)return {status:'clarify',command:result([],'请先明确“其他部队”相对于哪组部队。',0)};const rest=stepsFor(clause);orders.push({select:{scope:'all',exceptPrior:true},steps:rest.steps});continue;}
  const segments=clause.split(/然后|随后|接着|，再|,再/),subject=segments[0].split(/向|攻击|进攻|冲锋|冲击|自由射击|自由攻击|停止|原地|保持|解除|列阵|组成|撤退|后撤|移动|前进|推进|前往|移至|撤至|破坏|拆除|摧毁/)[0],select=selectorFor(subject||segments[0]),steps=[];if(/冲锋|冲击/.test(clause)&&subject.replace(/所有|全部|全体|选中|当前|已选|左翼|右翼|中央|前线|后方|的|\s/g,'')==='骑兵'){delete select.kind;delete select.kinds;select.role='cavalry';}
  for(const segment of segments){const parsed=stepsFor(segment);if(parsed.clarification)return {status:'clarify',command:result([],parsed.clarification,0)};if(parsed.unknown)return {status:'remote',reason:'超出本地语法'};steps.push(...parsed.steps);}
  // A selector cannot silently turn an unrecognised troop/positional phrase into the current selection.
  if(/法术|飞机|坦克|随意|包抄|迂回|突袭/.test(subject))return {status:'clarify',command:result([],'这条指令的部队或动作不明确，请使用现有兵种和明确方向。',0)};
  if(unknown(subject))return {status:'remote',reason:'需要进一步理解部队描述'};
  orders.push({select,steps});
 }
 return {status:'local',command:result(orders)};
}
