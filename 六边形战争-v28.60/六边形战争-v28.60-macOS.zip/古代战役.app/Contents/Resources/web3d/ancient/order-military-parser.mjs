// Literal military vocabulary -> parameterized templates. No strategic inference or LLM coordinates.
const shapeOf=t=>/楔形/.test(t)?'wedge':/散兵/.test(t)?'skirmish':/密集/.test(t)?'dense':/纵队/.test(t)?'column':/方阵/.test(t)?'square':/横队|防御阵线|防御横队/.test(t)?'line':null;
const command=orders=>({status:'local',command:{v:1,confidence:1,clarification:'',orders}});
const clarify=text=>({status:'clarify',command:{v:1,confidence:0,clarification:text,orders:[]}});
export function parseMilitaryOrder(text,{parseSelector,unknownSelector,number,markText=text}){
 const marked=/横队|纵队|楔形|散兵阵|密集防御|排成方阵|部署|集结|保护|火力支援|重组|补给|仓库|装粮|输送|第.*战线|沿道路|桥梁后方|敌后|纵深/.test(markText)||/取消刚才/.test(markText);if(!marked)return null;
 const location=t=>{const line=t.match(/第([一二两三四五六七八九十\d]+)线/);if(line)return {side:'own',select:{scope:'all',role:'infantry',zone:'front'},relation:'rear',distance:Math.max(0,(number(line[1])-1)*2)};
  const relation=/前方/.test(t)?'front':/后方|敌后/.test(t)?'rear':/左(?:翼|侧)/.test(t)?'left':/右(?:翼|侧)/.test(t)?'right':'center';
  let feature=/桥/.test(t)?'bridge':/仓库/.test(t)?'depot':/城墙/.test(t)?'wall':/补给通道|补给线/.test(t)?'route':null;
  if(feature)return {side:'own',feature,relation,distance:relation==='center'?0:2};
  const stripped=t.replace(/在|前方|后方|左侧|右侧|敌后|组成|排成|两排|横队|纵队|集结|部署|至|到|沿道路/g,'');
  const select=parseSelector(stripped,{enemy:/敌军|敌方|敌人|敌后/.test(t)});if(unknownSelector(stripped.replace(/步兵阵线/g,'步兵')))return null;
  if(!select.role&&!select.kind&&!select.wing&&!select.zone&&!select.front)return null;
  return {side:/敌军|敌方|敌人|敌后/.test(t)?'enemy':'own',select:{...select,scope:'all'},relation,distance:relation==='center'?0:2};
 };
 if(/就近.*两翼.*集结/.test(text)&&!/[；;]/.test(text)){
  const subject=text.split(/就近|向两翼/)[0],select=parseSelector(subject);if(unknownSelector(subject))return {status:'remote',reason:'需要识别受令对象'};
  delete select.wing;const refText=text.match(/向(.+?)两翼/ )?.[1]?.replace(/(?:的)?$/,'');let reference;
  if(refText){if(unknownSelector(refText))return clarify('请明确两翼集结所参照的战线或编组');reference={side:'own',select:{...parseSelector(refText),scope:'all'},relation:'center',distance:0};}
  return command([{select,steps:[{type:'rally',wings:'both',allocation:'nearest',...(reference?{reference}:{})}]}]);
 }
 const clauses=text.split(/[；;]|[，,](?=(?:中央|中军|左翼|右翼|所有|全部|前锋|后卫|弓箭手|步兵|骑兵|长矛兵|第[一二三四\d]+战线))/).map(t=>t.trim()).filter(Boolean),orders=[];
 for(let i=0;i<clauses.length;i++){
  let clause=clauses[i].replace(/^取消刚才(?:的)?/,'').replace(/(?:的)?(?:进攻|攻击)[，,]?改为/,'');const segments=clause.split(/然后|随后|接着/),first=segments[0],subject=first.split(/在|沿道路|排成|组成|列成|保护|部署|集结|向|停止|原地|后撤|撤退|返回|回仓|装粮|建立|连接|输送|补给/)[0],select=parseSelector(subject||first),steps=[];if(/取消刚才|刚才.*改为/.test(clauses[i]))select.lastOrder=true;
  if(/转移.*(?:仓库|节点)|迁移.*(?:仓库|节点)/.test(clause)){orders.push({select:{scope:'all',role:'supply'},steps:[{type:'logistics',mode:'relocate'}]});continue;}
  if(/调整补给(?:线|路径)|改写补给线/.test(clause)){orders.push({select:{scope:'all',role:'supply'},steps:[{type:'logistics',mode:'reroute'}]});continue;}
  if(/保护补给(?:通道|线)/.test(clause)){orders.push({select,steps:[{type:'logistics',mode:'guard'}]});continue;}
  if(/回仓装粮|回仓库补粮|返回仓库.*装粮|补满粮车/.test(clause)){orders.push({select:{scope:'all',role:'supply'},steps:[{type:'logistics',mode:'refill'}]});continue;}
  if(/建立.*补给线|连接.*(?:补给源|仓库)|输送补给|运粮|送粮/.test(clause)){
   const targetText=clause.match(/(?:通往|向|给|至)(.+?)(?:建立|输送|运粮|送粮|补给|的补给线|$)/)?.[1]?.replace(/前线/g,'前线')||(/左翼/.test(clause)?'左翼前线部队':/右翼/.test(clause)?'右翼前线部队':'前线部队');
   if(unknownSelector(targetText))return {status:'remote',reason:'需要理解受补给部队'};
   orders.push({select:{scope:'all',role:'supply'},steps:[{type:'logistics',mode:/建立|连接/.test(clause)?'connect':'deliver',target:parseSelector(targetText)}]});continue;
  }
  if(/步兵.*(?:防御阵线|前线).*[弓箭手兵]+.*(?:后方|后线).*火力支援/.test(clause)){orders.push({select:{scope:'all'},steps:[{type:'template',template:'front_support'}]});continue;}
  if(unknownSelector(subject))return {status:'remote',reason:'需要理解军事部队描述'};
  if(/保护/.test(first)&&/弓|弩|远程/.test(first)){
   const target=first.split('保护').at(-1),reference={side:'own',select:parseSelector(target),relation:'front',distance:2};if(unknownSelector(target))return {status:'remote',reason:'需要理解保护对象'};reference.select.scope='all';const n=first.match(/([一二两三四五六七八九十\d]+)排/);steps.push({type:'template',template:'protect_ranged',reference,rows:n?number(n[1]):2});
  }else for(const segment of segments){
   const actionText=segment===first&&subject?segment.slice(subject.length):segment;
   const rows=actionText.match(/([一二两三四五六七八九十\d]+)排/),shape=shapeOf(actionText),n=segment.match(/([一二两三四五六七八九十\d]+)格/),direction=/东北/.test(segment)?'NE':/西北/.test(segment)?'NW':/东南/.test(segment)?'SE':/西南/.test(segment)?'SW':/向东/.test(segment)?'E':/向西/.test(segment)?'W':/后撤|后退|撤退/.test(segment)?'back':/推进|向前/.test(segment)?'forward':undefined;
   if(/原地防守|原地防御/.test(segment)){steps.push({type:'defend'});continue;}
   if(/后撤|撤退/.test(segment)&&/重组/.test(segment)){steps.push({type:'template',template:'retreat_reform',distance:n?number(n[1]):2,...(rows?{rows:number(rows[1])}:{})});continue;}
   const relationText=segment.match(/(?:在|至|到)(.+?)(?:组成|排成|部署|集结|$)/)?.[1];let anchor=relationText?location(relationText):null;
   if(!anchor&&/敌后/.test(segment))anchor={side:'enemy',select:{scope:'all'},relation:'rear',distance:2};
   if(relationText&&!anchor)return {status:'remote',reason:'需要理解参考区域'};
   if(/沿道路/.test(segment)){if(!anchor)return clarify('请指定沿道路行军的已知目标区域或坐标');steps.push({type:'move',anchor,alongRoad:true,keepFormation:true});continue;}
   if(shape||/集结|部署/.test(segment)){steps.push({type:'deploy',shape:shape||'line',...(anchor?{anchor}:{}),...(rows?{rows:number(rows[1])}:{}),...(direction?{direction}:{}),...(/防御|密集/.test(segment)?{formed:true}:{})});continue;}
   if(/撤退|后撤/.test(segment)&&anchor){steps.push({type:'move',anchor,keepFormation:true});continue;}
   if(/向|推进|移动|前进/.test(segment)&&direction){steps.push({type:'move',direction,distance:n?number(n[1]):1,keepFormation:/保持/.test(segment)});continue;}
   return {status:'remote',reason:'需要理解复合军事动作'};
  }
  if(!steps.length)return {status:'remote',reason:'需要理解军事动作'};orders.push({id:'order'+(orders.length+1),select,steps});
 }
 return command(orders);
}
