import {hasCliffNavigation} from './cliff-navigation.mjs';
import {createMiddleEarthHorizon} from './middle-earth-horizon.mjs';
import {refreshKnowledgeMist,releaseKnowledgeMist} from './knowledge-mist.mjs';
import * as THREE from '../vendor/three/three.module.js';
import { createAncientTerrain, terrainHeight, tileBase } from './terrain.mjs';
import {bridgeDeckContains,bridgeDeckSpans,crossingAxis} from './terrain-adjacency.mjs';
import {offsetToWorld,worldToOffset} from '../js/core/hex.js';
import { createTerrainForts } from './terrain-forts.mjs';
import { usesFortificationLayout } from './fortification-layout.mjs';
import { WATER_Y } from './terrain-surface.mjs';
import { bounds, contains } from './terrain-adjacency.mjs';
import { neighbors, inBounds, index, TERRAIN, bridgeAt } from './engine.mjs';

function dispose(group) {
  group?.removeFromParent();
  group?.traverse(o=>{
    if(o.isInstancedMesh)o.dispose();
    if(o.geometry && !o.geometry.userData.sharedTerrain)o.geometry.dispose();
    for(const m of o.material?(Array.isArray(o.material)?o.material:[o.material]):[])
      if(!m.userData.sharedTerrain)m.dispose();
  });
}
// Chunk-level static cache. A cell change invalidates its four-ring dependency halo,
// including cross-chunk corner heights, road sampling and wall transitions.
export function createTerrainRefresh(chunkSize=16) {
  const group=new THREE.Group(),forts=new THREE.Group(),grid={visible:true,board:false};
  const chunks=new Map();let map=null,snapshot=null,meta='',quality='standard',horizon=null;
  let size=chunkSize,deckShapes=new Map();
  const id=(c,r)=>`${Math.floor(c/size)},${Math.floor(r/size)}`;
  function applyGrid(terrain){
    const line=terrain.grid;
    line.visible=grid.visible;
    const opacity=line.userData.gridOpacity;
    if(opacity)line.material.opacity=grid.board?opacity.board:opacity.tactical;
    const color=line.userData.gridColor;
    if(color)line.material.color.setHex(grid.board?color.board:color.tactical);
  }
  const api={group,forts,grid,pickables:[],lastUpdate:null,chunks,
    refresh(m,window=null){
      size=m.victory?.layoutVersion>=3?32:chunkSize;
      refreshKnowledgeMist(m);
      const worksAffectRoads=usesFortificationLayout(m);
      const nextMeta=JSON.stringify([m.scenarioId,m.cols,m.rows,m.garden,m.victory,window,worksAffectRoads]);
      const reset=map!==m||meta!==nextMeta;
      if(reset){if(map&&map!==m)releaseKnowledgeMist(map);for(const x of chunks.values()){dispose(x.terrain?.group);dispose(x.forts);}chunks.clear();snapshot=null;}
      const walls=m.units.filter(u=>u.kind==='fort'),byCell=new Map(walls.map(u=>[`${u.c},${u.r}`,u]));
      deckShapes=new Map((m.bridges||[]).map(({c,r})=>[index(m,c,r),bridgeDeckSpans(m,c,r)]));
      const bridges=new Set((m.bridges||[]).map(p=>`${p.c},${p.r}`));
      const c0=window?.[0]??0,c1=window?.[1]??m.cols;
      const next=[],dirtyTerrain=new Set(),dirtyForts=new Set(),dirtyVegetation=new Set(),changed=[];
      for(let r=0;r<m.rows;r++)for(let c=c0;c<c1;c++) {
        const i=index(m,c,r),wall=byCell.get(`${c},${r}`);
        const value=[m.terrain[i],m.houses?.[i]||0,bridges.has(`${c},${r}`)?1:0,
          wall?`${wall.id}:${wall.level}:${wall.hp}:${wall.team}`:'',wall?.hp>0?1:0,m.elevations?.[i]??null,m.unknown?.[i]||0,m.staleMask?.[i]||0,
          wall?[wall.gate,wall.level,wall.team,wall.cityId].join(':'):''];next[i]=value;
        if(snapshot && value.every((v,j)=>snapshot[i][j]===v))continue;
        changed.push({c,r});if(!snapshot)continue;const ground=!snapshot||value[5]!==snapshot[i][5]||value[6]!==snapshot[i][6]||value[7]!==snapshot[i][7]||value.slice(0,3).some((v,j)=>snapshot[i][j]!==v);if(snapshot[i][4]!==value[4])dirtyVegetation.add(id(c,r));
        const haloMap=new Map([[`${c},${r}`,{c,r}]]);let edge=[{c,r}];for(let j=0;j<4;j++){const nextEdge=[];for(const v of edge)for(const p of neighbors(v.c,v.r)){const k=`${p.c},${p.r}`;if(!haloMap.has(k)){haloMap.set(k,p);nextEdge.push(p);}}edge=nextEdge;}const halo=[...haloMap.values()];
        for(const p of halo)if(inBounds(m,p.c,p.r)&&p.c>=c0&&p.c<c1){dirtyForts.add(id(p.c,p.r));if(ground||worksAffectRoads&&(snapshot[i][4]!==value[4]||value[8]!==snapshot[i][8]))dirtyTerrain.add(id(p.c,p.r));}
      }
      // Initial generation includes empty chunks, so future insertions are local.
      if(reset)for(let r=0;r<m.rows;r+=size)for(let c=Math.floor(c0/size)*size;c<c1;c+=size){dirtyTerrain.add(id(c,r));dirtyForts.add(id(c,r));}
      for(const key of new Set([...dirtyTerrain,...dirtyForts,...dirtyVegetation])) {
        const [x,y]=key.split(',').map(Number),region=bounds(m,{c0:Math.max(c0,x*size),r0:y*size,c1:Math.min(c1,(x+1)*size),r1:(y+1)*size});
        const chunk=chunks.get(key)||{region};
        if(dirtyTerrain.has(key)){
          dispose(chunk.terrain?.group);chunk.terrain=createAncientTerrain(m,null,false,region);
          chunk.terrain.setQuality(quality);applyGrid(chunk.terrain);group.add(chunk.terrain.group);
        }
        if(!dirtyTerrain.has(key)&&dirtyVegetation.has(key))chunk.terrain.refreshVegetation(quality);
        chunks.set(key,chunk);
      }
      for(const key of dirtyForts){
        const chunk=chunks.get(key),region=chunk.region;
        const height=(map,c,r,x,z)=>{
          const center=offsetToWorld(c,r);
          x??=center.x;z??=center.z;
          const q=worldToOffset(x,z);
          const source=chunks.get(id(q.col,q.row));
          return source?.terrain.sample(q.col,q.row,x,z)??chunk.terrain.sample(c,r,x,z);
        };
        dispose(chunk.forts);
        chunk.forts=createTerrainForts(m,walls.filter(u=>contains(region,u.c,u.r)),height);
        forts.add(chunk.forts);
      }
      const borderChanged=changed.some(({c,r})=>{
        if(c>=c0+4&&c<c1-4&&r>=4&&r<m.rows-4)return false;
        const i=index(m,c,r);
        return !snapshot||[0,5,6].some(field=>snapshot[i][field]!==next[i][field]);
      });
      if(reset||borderChanged){
        dispose(horizon);horizon=null;
        const sample=(c,r,x,z)=>chunks.get(id(c,r)).terrain.sample(c,r,x,z);
        const edgeColor=m.victory?.layoutVersion>=2?null:(terrain,c,r)=>tileBase(terrain&~TERRAIN.ROAD,c,r,m);
        horizon=createMiddleEarthHorizon(m,window,sample,edgeColor);
        group.add(horizon);
      }
      map=m;meta=nextMeta;snapshot=next;
      api.pickables=[...chunks.values()].flatMap(x=>x.terrain.pickables);
      api.lastUpdate={reset,changedCells:changed,terrainChunks:[...dirtyTerrain],fortChunks:[...dirtyForts],vegetationChunks:[...dirtyVegetation],totalChunks:chunks.size};
      return api.lastUpdate;
    },
    sample(x,z){
      if(!map)return 0;
      const {col:c,row:r}=worldToOffset(x,z),chunk=chunks.get(id(c,r));
      const inside=inBounds(map,c,r),terrain=inside?map.terrain[index(map,c,r)]:TERRAIN.PLAIN;
      const ground=()=>chunk?.terrain.sample(c,r,x,z)??(inside?terrainHeight(map,c,r):0);
      if(!(terrain&(TERRAIN.RIVER|TERRAIN.SEA)))return ground();
      if(!(terrain&TERRAIN.ROAD))return WATER_Y;
      const spans=deckShapes.get(index(map,c,r));
      if(spans?.length)return bridgeDeckContains(spans,x,z)?.5:WATER_Y;
      const bridge=bridgeAt(map,c,r);
      if(hasCliffNavigation(map)&&!bridge)return chunk?.terrain.sample(c,r,x,z)??-.12;
      const center=offsetToWorld(c,r),angle=crossingAxis(map,c,r);
      const lateral=(x-center.x)*Math.sin(angle)+(z-center.z)*Math.cos(angle);
      return Math.abs(lateral)<(bridge?2:1.45)?(bridge ? .5 : -.12):WATER_Y;
    },
    height(c,r){const p=offsetToWorld(c,r);return api.sample(p.x,p.z);},
    updateLOD(camera){for(const chunk of chunks.values())chunk.terrain.updateLOD?.(camera);},
    invalidate(){map=null;},
    setQuality(value){quality=value;for(const x of chunks.values())x.terrain.setQuality(value);},
    setGrid(value,board=false){grid.visible=value;grid.board=board;for(const x of chunks.values())applyGrid(x.terrain);},
    update(time){
      for(const x of chunks.values())x.terrain.update(time);
      const water=horizon?.getObjectByName('historical-horizon-water');
      if(water)water.material.userData.clock.value=time*.001;
    },
    dispose(){if(map)releaseKnowledgeMist(map);dispose(horizon);horizon=null;for(const x of chunks.values()){dispose(x.terrain.group);dispose(x.forts);}chunks.clear();group.removeFromParent();forts.removeFromParent();},
  };
  return api;
}
