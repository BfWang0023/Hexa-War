import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {STATS,isShip,neighbors} from './engine.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {createUnitModel,UNIT_SCENE_SCALE} from './unit-presentation.mjs';
import {createUnitAnimator,headingBetween,angleDelta} from './unit-animation.mjs';
const kinds=Object.keys(STATS).filter(kind=>isShip({kind}));
const point=p=>{const w=offsetToWorld(p.c,p.r);return new T.Vector3(w.x,0,w.z);};
function fixture(kind='athenianTrireme'){
 const u={id:'u1',kind,team:'egypt',hp:100,c:4,r:4,facing:0,morale:1},model=createUnitModel(u,'salamis'),group=new T.Group(),camera=new T.PerspectiveCamera(),anim=createUnitAnimator();model.userData.unitId=u.id;model.scale.setScalar(UNIT_SCENE_SCALE);model.position.copy(point(u));group.add(model);camera.position.copy(model.position).add(new T.Vector3(0,10,20));anim.observe([u],0,{scenarioId:'salamis'});return {u,model,group,camera,anim,tick(t){anim.update(group,camera,t);model.updateMatrixWorld(true);}};
}
for(const kind of kinds)test(`${kind}: oars and deck feet stay still while the whole enlarged ship glides`,()=>{
 const f=fixture(kind),to=neighbors(f.u.c,f.u.r)[0],before=JSON.stringify(f.u),parts=[];f.tick(0);f.model.getObjectByName('near').traverse(o=>{if(o.name==='oar'||o.name==='visual'||o.name.startsWith('leg'))parts.push([o,o.position.clone(),o.rotation.clone()]);});assert.ok(parts.length);
 f.anim.move(f.u.id,f.u,[to],0);f.anim.observe([{...f.u,...to}],1,{scenarioId:'salamis'});f.model.position.copy(point(to));for(const t of [16,45,90,170,250,339]){f.tick(t);for(const [o,p,r] of parts){assert.ok(o.position.distanceTo(p)<1e-9);assert.deepEqual(o.rotation.toArray(),r.toArray());}const expected=point(f.u).lerp(point(to),t/340);assert.ok(f.model.position.distanceTo(expected)<1e-7);assert.equal(f.model.getObjectByName('near').visible,true);assert.equal(f.model.getObjectByName('far').visible,false);}
 f.tick(340);assert.ok(f.model.position.distanceTo(point(to))<1e-7);assert.equal(JSON.stringify(f.u),before);
});
test('ships move through multi-cell paths at continuous speed without pausing at hex boundaries',()=>{
 const f=fixture(),a=neighbors(f.u.c,f.u.r)[0],b=neighbors(a.c,a.r)[0];f.anim.move(f.u.id,f.u,[a,b],0);f.anim.observe([{...f.u,...b}],1,{scenarioId:'salamis'});f.model.position.copy(point(b));let previous;const steps=[];for(let t=0;t<=680;t+=10){f.tick(t);if(previous)steps.push(previous.distanceTo(f.model.position));previous=f.model.position.clone();}assert.ok(Math.max(...steps)-Math.min(...steps)<1e-7);assert.ok(steps.every(d=>d>0));
});
test('ship LOD remains stable around the old threshold and always shows exactly one model',()=>{
 const f=fixture();for(const [i,d] of [110,116,114,117,112,129,131,125,114,103,101,99,112].entries()){f.camera.position.copy(point(f.u)).add(new T.Vector3(d,0,0));f.tick(i*16);const near=f.model.getObjectByName('near').visible,far=f.model.getObjectByName('far').visible;assert.equal(Number(near)+Number(far),1);assert.equal(far,i>=6&&i<11);}
 f.anim.setQuality('low');f.camera.position.copy(point(f.u));f.tick(500);assert.equal(f.model.getObjectByName('far').visible,true);f.anim.setQuality('standard');f.tick(516);assert.equal(f.model.getObjectByName('near').visible,true);
});
test('ship facing orders turn smoothly without changing the immediate rule facing',()=>{
 const f=fixture();f.tick(0);const next={...f.u,facing:2};f.anim.observe([next],10,{scenarioId:'salamis'});f.tick(10);assert.ok(Math.abs(f.model.rotation.y)<1e-8);f.tick(100);assert.ok(Math.abs(f.model.rotation.y)>.1);assert.ok(Math.abs(f.model.rotation.y)<Math.abs(headingBetween(f.u,neighbors(f.u.c,f.u.r)[2])));f.tick(210);assert.ok(Math.abs(angleDelta(f.model.rotation.y,headingBetween(f.u,neighbors(f.u.c,f.u.r)[2])))<1e-8);assert.equal(next.facing,2);
});
test('ranged ship weapons still animate and launch while oars remain motionless',()=>{
 const f=fixture(),to=neighbors(f.u.c,f.u.r)[0],launched=[];f.anim.setEffects({launch(...x){launched.push(x);},update(){},clear(){}});f.anim.attack({ok:true,visual:{attackerId:f.u.id,attackerKind:f.u.kind,attackerTeam:f.u.team,melee:false,from:f.u,to}},0,{scenarioId:'salamis'});f.tick(300);const bow=f.model.getObjectByName('near').getObjectByName('loaded-arrow');assert.ok(bow);f.tick(400);f.tick(500);assert.equal(launched.length,1);f.model.getObjectByName('near').traverse(o=>{if(o.name==='oar')assert.equal(o.rotation.y,0);});
});
