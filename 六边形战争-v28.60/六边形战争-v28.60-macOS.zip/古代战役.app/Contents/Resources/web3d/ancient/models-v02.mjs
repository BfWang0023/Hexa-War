import {applyHitFlash} from './hit-feedback.mjs';
import * as T from '../vendor/three/three.module.js';
import {addHeroRegalia} from './hero-regalia.mjs';
import {panel} from './historical-geometry.mjs';
import {historicalDress,dressSleeve,historicalShield} from './historical-dress.mjs';
// Original procedural artwork. Metres are miniature/map units, forward is +X.
const mat = (color, roughness=.85, metalness=0) => new T.MeshStandardMaterial({color,roughness,metalness});
export const materials = {
 wood:mat(0x805638), darkWood:mat(0x3f2c21), bronze:mat(0xb38c50,.4,.65), iron:mat(0x657077,.43,.72),
 leather:mat(0x4f3223), linen:mat(0xd9c7a0), skin:mat(0xbc8963), mane:mat(0x30251e),
 bay:mat(0x855339), chestnut:mat(0xa7744d), pale:mat(0xbbaa8a), hoof:mat(0x34302a),
 blue:mat(0x256b80), red:mat(0x963e32), shieldBlue:mat(0x367e91), shieldRed:mat(0xb45c41)
};
// One original 128x128 atlas: deterministic grain, weave, pores and hammer marks.
const atlasData=new Uint8Array(128*128*4);
for(let y=0;y<128;y++)for(let x=0;x<128;x++) {const cell=(y>>5)*4+(x>>5), n=((x*73+y*151+x*y*7)%29)-14;
 const grain=cell<2?Math.sin(x*.7+Math.sin(y*.13))*15:cell===5||cell>9?((x%3===0||y%3===0)?-12:4):n*.5;
 const v=Math.max(180,Math.min(255,236+n*.35+grain)),i=(y*128+x)*4;atlasData.set([v,v,v,255],i);}
export const materialAtlas=new T.DataTexture(atlasData,128,128,T.RGBAFormat);materialAtlas.colorSpace=T.SRGBColorSpace;materialAtlas.needsUpdate=true;
materialAtlas.magFilter=T.LinearFilter;materialAtlas.minFilter=T.LinearFilter;
Object.values(materials).forEach((m,i)=>{m.map=materialAtlas;m.userData.atlasCell=i;});
// Dedicated matte animal hides and lacquer/cloth; reuse existing atlas tiles.
for(const [name,color,cell,rough,metal] of [['elephantHide',0x79776e,6,.97,0],['camelHide',0xb69464,10,.98,0],['ivory',0xd9cba4,5,.72,0],['gold',0xc59b48,2,.44,.5],['royalBlue',0x225a91,12,.8,0],['indigo',0x394b59,5,.98,0],['cinnabar',0x823c30,5,.98,0],['lacquer',0x402b27,4,.65,0],['lamellar',0x3a403d,3,.78,.15]]){const m=mat(color,rough,metal);m.map=materialAtlas;m.userData.atlasCell=cell;m.side=T.DoubleSide;materials[name]=m;}
const hideData=new Uint8Array(64*64*4);for(let i=0;i<64*64;i++){const v=243+((i*73+(i>>6)*19)%13);hideData.set([v,v,v,255],i*4);}const hideTexture=new T.DataTexture(hideData,64,64,T.RGBAFormat);hideTexture.colorSpace=T.SRGBColorSpace;hideTexture.magFilter=T.LinearFilter;hideTexture.needsUpdate=true;materials.elephantHide.map=hideTexture;materials.camelHide.map=hideTexture;
const templates = new Map();
let low = false;
const ball = () => new T.SphereGeometry(1,low?7:12,low?5:8);
function part(g,geo,m,p,s=[1,1,1]) {const o=new T.Mesh(geo,m);o.position.set(...p);o.scale.set(...s);g.add(o);return o;}
const oval=(g,m,p,s)=>part(g,ball(),m,p,s);
const box=(g,m,p,s)=>part(g,new T.BoxGeometry(1,1,1),m,p,s);
function rod(g,m,a,b,r=.05,r2=r) {const v=new T.Vector3(...b).sub(new T.Vector3(...a)); const o=part(g,new T.CylinderGeometry(r2,r,v.length(),low?5:8),m,a);o.position.addScaledVector(v,.5);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;}
function joint(g,name,p) {const o=new T.Group();o.name=name;o.position.set(...p);g.add(o);return o;}
function human(g,team,era,{rider=false,crew=false,profile=null}={}) {
 const cloth=team==='egypt'?materials.blue:materials.red, skin=materials.skin;
 const custom=profile&&(profile.culture==='china'||profile.royalStyle),chinese=profile?.culture==='china';
 const body=joint(g,'breath',[0,0,0]);
 oval(body,era==='bronze'?skin:cloth,[0,2.18,0],[.34,.53,.23]);
 if(!custom)part(body,new T.CylinderGeometry(.28,.44,.66,low?6:10),materials.linen,[0,1.57,0]);
 box(body,materials.leather,[0,1.87,0],[.62,.1,.49]);
 if(!custom&&era!=='bronze'&&(!profile||profile.armor>0)) {
  oval(body,materials.leather,[0,2.19,-.005],[.35,.43,.245]);
  if(!low) for(let row=0;row<4;row++)for(let col=0;col<5;col++)box(body,materials.bronze,[(col-2)*.12,1.98+row*.13,.238],[.105,.105,.028]);
 }
 rod(body,skin,[0,2.56,0],[0,2.73,0],.12);
 oval(body,skin,[0,2.92,.018],[.23,.30,.22]);
 oval(body,skin,[0,2.9,.229],[.055,.075,.06]);
 // Hemispherical helmet and neck guard, without hiding the face.
 if(!custom)part(body,new T.SphereGeometry(.25,low?8:12,6,0,Math.PI*2,0,Math.PI*.54),era==='bronze'?materials.mane:materials.bronze,[0,3.03,0]);
 if(!custom&&era!=='bronze') box(body,materials.leather,[0,2.87,-.205],[.43,.32,.07]);
 for(const side of [-1,1]) {
  const leg=joint(g,'leg'+side,[side*.19,1.39,0]);
  if(rider){rod(leg,cloth,[0,0,0],[side*.22,-.32,.3],.12,.145);rod(leg,materials.leather,[side*.22,-.32,.3],[side*.25,-.9,.14],.075,.1);oval(leg,materials.leather,[side*.25,-.95,.23],[.1,.08,.21]);}
  else {rod(leg,chinese?(team==='egypt'?materials.indigo:materials.cinnabar):skin,[0,0,0],[side*.025,-.50,.04],.09,.135);oval(leg,skin,[side*.025,-.5,.04],[.1,.12,.1]);rod(leg,chinese?materials.linen:skin,[side*.025,-.5,.04],[side*.04,-1.04,.0],.065,.09);oval(leg,materials.leather,[side*.04,-1.08,.09],[.105,.07,.21]);}
  const arm=joint(body,side===1?'weapon':'shield', [side*.34,2.49,0]);
  if(profile){
   arm.userData.armSide=side;
   const upper=joint(arm,'upper-arm',[0,0,0]);rod(upper,skin,[0,0,0],[0,-1,0],.075,.105);
   const lower=joint(arm,'lower-arm',[0,0,0]);rod(lower,skin,[0,0,0],[0,-1,0],.065,.078);
   const grip=joint(arm,'hand-grip',[side*.13,-.43,.37]);oval(grip,skin,[0,0,0],[.08,.09,.09]);
   poseHumanArm(arm,new T.Vector3(side*.13,-.43,.37));
   dressSleeve(arm,profile,team,{M:materials,rod,low});
  }else {rod(arm,skin,[0,0,0],[side*.16,-.35,.06],.075,.105);rod(arm,skin,[side*.16,-.35,.06],[side*.13,-.43,.37],.065,.078);oval(arm,skin,[side*.13,-.43,.37],[.08,.09,.09]);}
  if(side===-1&&!crew&&!rider&&!profile?.rangedWeapon&&profile?.weapon!=='none'){
   if(chinese)historicalShield(arm,team,{M:materials,box,rod,oval});else {
   (['rect','chinese'].includes(profile?.shieldShape)?box:oval)(arm,materials.wood,[-.13,-.38,.43],['rect','chinese'].includes(profile?.shieldShape)?[.76,1.3,.1]:[.39,.65,.065]);
   (['rect','chinese'].includes(profile?.shieldShape)?box:oval)(arm,team==='egypt'?materials.shieldBlue:materials.shieldRed,[-.13,-.38,.48],['rect','chinese'].includes(profile?.shieldShape)?[.68,1.2,.045]:[.35,.60,.04]);
   oval(arm,materials.bronze,[-.13,-.38,.53],[.13,.15,.055]);
   if(chinese){box(arm,materials.lacquer,[-.13,-.38,.535],[.06,1.14,.025]);for(const side of [-1,1]){const stripe=box(arm,materials.lacquer,[-.13+side*.14,-.13,.535],[.045,.42,.025]);stripe.rotation.z=side*-.55;}}
   if(!low)for(const dy of [-.43,.43])oval(arm,materials.bronze,[-.13,-.38+dy,.53],[.035,.035,.02]);}
  }
  if(side===1&&!crew&&!profile){rod(arm,materials.wood,[.13,-1.6,.37],[.13,1.15,.37],.029);part(arm,new T.ConeGeometry(.09,.34,4),materials.bronze,[.13,1.3,.37]);}
 }
 if(profile&&!crew) equipHuman(body,profile);
 if(custom)historicalDress(body,profile,team,{M:materials,box,oval,rod,part,joint,low});
 if(profile&&!crew)addHeroRegalia(g,body,profile,team,{M:materials,box,oval,rod,part,joint,low},{rider});
 if(profile?.commander&&!custom){rod(body,materials.bronze,[-.27,3.1,0],[.27,3.1,0],.04);box(body,cloth,[0,2.18,-.3],[.55,.9,.07]);}
 return g;
}
function horse(g,z,index=0,harness=false){
 const h=joint(g,'horse',[.75,0,z]), coat=[materials.bay,materials.chestnut,materials.pale,materials.bay][index%4];
 oval(h,coat,[0,1.39,0],[.85,.42,.33]);oval(h,coat,[.48,1.43,0],[.39,.47,.35]);oval(h,coat,[-.57,1.41,0],[.38,.41,.34]);
 const neck=oval(h,coat,[.69,1.91,0],[.25,.65,.27]);neck.rotation.z=-.43;
 oval(h,coat,[1.0,2.33,0],[.29,.27,.23]);const muzzle=oval(h,coat,[1.24,2.17,0],[.33,.17,.19]);muzzle.rotation.z=-.35;
 oval(h,materials.leather,[1.45,2.08,0],[.12,.13,.18]);
 for(const side of [-1,1]){
  oval(h,materials.mane,[1.08,2.38,side*.207],[.035,.04,.02]);
  const ear=oval(h,coat,[.88,2.55,side*.15],[.05,.115,.055]);ear.rotation.z=.08;
  rod(h,materials.leather,[.9,2.51,side*.23],[1.36,2.1,side*.19],.023);
  for(const x of [-.59,.52]){
   const leg=joint(h,`horseleg:${side}:${x}`,[x,1.27,side*.24]);
   rod(leg,coat,[0,0,0],[x<0?-.12:.03,-.47,0],.075,.12);
   oval(leg,coat,[x<0?-.12:.03,-.47,0],[.09,.11,.09]);
   rod(leg,coat,[x<0?-.12:.03,-.47,0],[.01,-.91,0],.045,.065);
   oval(leg,materials.hoof,[.035,-.97,.0],[.095,.09,.08]);
  }
  rod(h,materials.leather,[.45,1.65,side*.33],[.63,1.08,side*.28],.035);
 }
 const mane=oval(h,materials.mane,[.46,2.0,0],[.10,.53,.29]);mane.rotation.z=-.43;
 const tail=joint(h,'tail',[-.81,1.61,0]);rod(tail,materials.mane,[0,0,0],[-.28,-.77,0],.09,.13);
 if(!harness)box(h,materials.linen,[-.1,1.77,0],[.67,.10,.7]);if(!harness)oval(h,materials.leather,[-.12,1.83,0],[.35,.11,.31]);
 return h;
}
function wheel(g,z){const w=joint(g,'wheel',[-1.22,.92,z]);part(w,new T.TorusGeometry(.66,.065,low?4:6,low?12:20),materials.darkWood,[0,0,0]);
 part(w,new T.TorusGeometry(.67,.024,4,low?12:20),materials.bronze,[0,0,0]);
 for(let i=0;i<8;i++){const a=i*Math.PI/4;rod(w,materials.wood,[0,0,0],[.63*Math.cos(a),.63*Math.sin(a),0],.032);}
 oval(w,materials.bronze,[0,0,0],[.13,.13,.12]);}
function build(kind,team,era,simple){low=simple;const root=new T.Group();const g=joint(root,'visual',[0,0,0]);
 if(kind==='heavy') {for(const [x,z,scale] of [[.43,-.34,1],[-.77,.56,1]]){const man=joint(g,'soldier',[x,0,z]);human(man,team,era);man.rotation.y=Math.PI/2;man.scale.setScalar(scale);}}
 if(kind==='cavalry'){horse(g,0,team==='egypt'?0:1);const rider=joint(g,'rider',[.66,.78,0]);human(rider,team,era,{rider:true});rider.scale.setScalar(.76);rider.rotation.y=Math.PI/2;
 for(const z of [-.2,.2])rod(g,materials.leather,[1.95,2.17,z],[.95,2.67,z],.018);}
 if(kind==='chinaHeavyChariot'){
  [-1.83,-.61,.61,1.83].forEach((z,i)=>horse(g,z,i,true));
  box(g,materials.wood,[-1.3,1.13,0],[1.52,.18,1.60]);
  rod(g,materials.iron,[-1.22,.92,-1.04],[-1.22,.92,1.04],.09);
  wheel(g,-.96);wheel(g,.96);
  for(const z of [-.8,.8]){box(g,materials.wood,[-1.28,1.48,z],[1.5,.6,.09]);rod(g,materials.bronze,[-2,1.82,z],[-.55,1.82,z],.045);}
  box(g,materials.wood,[-.56,1.48,0],[.09,.6,1.60]);
  if(!low)for(const x of [-1.9,-1.5,-1.1,-.7])for(const z of [-.85,.85]){box(g,materials.darkWood,[x,1.48,z],[.035,.55,.018]);oval(g,materials.bronze,[x,1.68,z],[.035,.035,.025]);}
  rod(g,materials.wood,[-1.2,1.16,0],[1.4,1.16,0],.07);
  rod(g,materials.wood,[1.3,1.35,-2.1],[1.3,1.35,2.1],.06);
  for(const z of [-1.83,-.61,.61,1.83]){rod(g,materials.leather,[1.3,1.35,z],[1.28,1.67,z],.04);for(const dz of [-.16,.16])rod(g,materials.leather,[2.12,2.15,z+dz],[-.9,2.2,dz],.014);}
  for(const z of [-.43,.43]){const crew=joint(g,'crew',[-1.3,.98,z]);human(crew,team,'china',{crew:z<0});crew.scale.setScalar(.64);crew.rotation.y=Math.PI/2;}
 }
 // Merge immutable meshes by material within each joint. Articulation stays independent.
 bake(root);return root;}
function bake(g){for(const c of [...g.children])if(c.isGroup)bake(c);const buckets=new Map();
 for(const c of [...g.children])if(c.isMesh){c.updateMatrix();let geo=c.geometry.index?c.geometry.toNonIndexed():c.geometry.clone();geo.applyMatrix4(c.matrix);const cell=c.material.userData.atlasCell,uv=geo.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,((cell%4)*32+1+uv.getX(i)*30)/128,(Math.floor(cell/4)*32+1+uv.getY(i)*30)/128);const b=buckets.get(c.material)||[];b.push(geo);buckets.set(c.material,b);c.geometry.dispose();g.remove(c);}
 for(const [material,geos] of buckets){const merged=new T.BufferGeometry();for(const key of ['position','normal','uv']){const arrays=geos.map(x=>x.attributes[key]);const a=new Float32Array(arrays.reduce((n,x)=>n+x.array.length,0));let offset=0;for(const attr of arrays){a.set(attr.array,offset);offset+=attr.array.length;}merged.setAttribute(key,new T.BufferAttribute(a,arrays[0].itemSize));}geos.forEach(x=>x.dispose());merged.userData.sharedUnitV02=true;merged.computeBoundingSphere();g.add(new T.Mesh(merged,material));}}
export function supportsV02(unit,scenario){return unit.kind==='heavy'||unit.kind==='cavalry'||unit.kind==='chinaHeavyChariot'&&scenario?.startsWith('china_');}
export function createV02(unit,scenario){const era=scenario?.startsWith('china_')?'china':['megiddo','kadesh','troy'].includes(scenario)?'bronze':'iron';const root=new T.Group();root.userData.v02=true;
 for(const simple of [false,true]){const key=[unit.kind,unit.team,era,simple].join(':');if(!templates.has(key))templates.set(key,build(unit.kind,unit.team,era,simple));const child=templates.get(key).clone(true);child.name=simple?'far':'near';child.visible=!simple;root.add(child);}
 root.rotation.y=unit.team==='egypt'?0:Math.PI;root.userData.rig=[];root.traverse(o=>{if(o.isGroup&&o.name)root.userData.rig.push({o,y:o.position.y,rz:o.rotation.z});});return root;}
export function animateV02(root,time,{moving=false,routed=false,attack=0,ranged=false,hit=0,distance=0,complex=true}={}){if(!root.userData.v02)return;
 const far=distance>115;root.children[0].visible=!far;root.children[1].visible=far;const t=time/1000,walk=moving||routed;const phase=t*(routed?12:8);
 for(const {o,y,rz} of root.userData.rig){o.position.y=y;o.rotation.z=rz;if(!o.parent.visible)continue;
 if(o.name==='visual'){o.position.y=y+(walk?.035*Math.abs(Math.sin(phase)):0);}
 if(!complex||far)continue;
 if(o.name.startsWith('horseleg'))o.rotation.z=rz+(walk?.32*Math.sin(phase+(o.name.includes('-1')?Math.PI:0)+(o.name.includes('-0.59')?Math.PI:0)):0);
 if(o.name.startsWith('leg')&&o.parent.name==='soldier')o.rotation.x=walk?.38*Math.sin(phase+(o.name==='leg-1'?Math.PI:0)):0;
 if(o.name==='breath')o.position.y=y+.015*Math.sin(t*2.3);
 if(o.name==='weapon')o.rotation.x=attack*(ranged?-.3:-.85);
 if(o.name==='wheel')o.rotation.z=walk?-phase:0;
 if(o.name==='tail')o.rotation.x=.08*Math.sin(t*3);
 }
 applyHitFlash(root,hit>0);
}

export function setModelDetail(value){low=value;}
export {part,oval,box,rod,joint,human,horse,wheel,bake};
function equipHuman(body,p){
 const right=body.getObjectByName('weapon').getObjectByName('hand-grip'),left=body.getObjectByName('shield').getObjectByName('hand-grip');
 const hand=joint(right,'melee-tool',[0,0,0]);hand.userData.hasRangedWeapon=!!p.rangedWeapon;
 if(p.weapon==='spear') {rod(hand,materials.wood,[0,-.95,0],[0,p.pike?2.6:1.2,0],.03);part(hand,new T.ConeGeometry(.09,.3,4),materials.bronze,[0,p.pike?2.75:1.35,0]);
  if(p.polearm==='ji'){const head=joint(hand,'ji-dagger-axe',[0,1.05,0]);const blade=panel(head,materials.bronze,[[-.05,-.08],[.35,-.03],[.48,.10],[.28,.08],[0,.09],[-.12,.05]],.032);blade.position.z=-.016;for(const y of [-.1,0,.1])rod(head,materials.leather,[-.045,y,0],[.045,y,0],.017);}
 }
 if(p.weapon==='sword') {box(hand,materials.leather,[0,-.1,0],[.08,.25,.08]);box(hand,materials.bronze,[0,.05,0],[.3,.065,.09]);box(hand,materials.iron,[0,.48,0],[.13,.85,.045]);part(hand,new T.ConeGeometry(.09,.2,4),materials.iron,[0,1,0]);}
 const ranged=p.rangedWeapon;if(!ranged)return;
 const tool=joint(ranged==='bow'||ranged==='crossbow'?left:right,'ranged-tool',[0,0,0]);
 tool.userData.weaponType=ranged;
 if(ranged==='bow') {
  for(const sign of [-1,1]) {rod(tool,materials.wood,[0,0,0],[0,sign*.42,.14],.035);rod(tool,materials.wood,[0,sign*.42,.14],[0,sign*.76,-.03],.025);}
  const string=joint(tool,'bow-string',[0,0,0]);for(const sign of [-1,1]){const segment=joint(string,'string-half'+sign,[0,sign*.76,-.03]);rod(segment,materials.linen,[0,0,0],[0,-1,0],.008);poseSegment(segment,segment.position,new T.Vector3(0,0,-.12));}
  const arrow=joint(tool,'loaded-arrow',[0,0,-.2]);rod(arrow,materials.wood,[0,0,-.35],[0,0,.65],.012);part(arrow,new T.ConeGeometry(.045,.15,4),materials.bronze,[0,0,.72]).rotation.x=Math.PI/2;
  joint(tool,'muzzle',[0,0,.78]);
  const quiver=part(body,new T.CylinderGeometry(.13,.13,.65,6),materials.leather,[-.2,2.1,-.32]);quiver.rotation.z=.2;
 }else if(ranged==='crossbow'||ranged==='ballista') {
  box(tool,materials.wood,[0,0,.1],[.12,.12,.95]);rod(tool,materials.iron,[-.42,0,.25],[.42,0,.25],.035);
  for(const sign of [-1,1])rod(tool,materials.linen,[sign*.42,0,.25],[0,0,-.1],.008);
  const arrow=joint(tool,'loaded-arrow',[0,.08,.1]);rod(arrow,materials.iron,[0,0,-.3],[0,0,.4],.018);joint(tool,'muzzle',[0,.08,.6]);
 }else if(ranged==='javelin') {rod(tool,materials.wood,[0,-.6,0],[0,.9,0],.027);part(tool,new T.ConeGeometry(.07,.24,4),materials.bronze,[0,1,0]);joint(tool,'muzzle',[0,.6,0]);}
 else if(ranged==='sling'){const sling=joint(tool,'sling',[0,0,0]);rod(sling,materials.leather,[0,0,0],[0,.5,0],.014);oval(sling,materials.leather,[0,.52,0],[.08,.05,.06]);joint(tool,'muzzle',[0,.5,0]);}
}

export function poseSegment(segment,a,b){const direction=b.clone().sub(a);segment.position.copy(a);segment.scale.y=direction.length();segment.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),direction.normalize());}
export function poseHumanArm(arm,target){
 const side=arm.userData.armSide,upper=arm.getObjectByName('upper-arm'),lower=arm.getObjectByName('lower-arm'),grip=arm.getObjectByName('hand-grip');if(!upper)return;
 const direction=target.clone(),distance=Math.min(.759,Math.max(.05,direction.length()));direction.normalize();const wrist=direction.clone().multiplyScalar(distance);
 const along=(.4*.4-.36*.36+distance*distance)/(2*distance),bend=new T.Vector3(side,-.55,-.2);bend.addScaledVector(direction,-bend.dot(direction)).normalize();
 const elbow=direction.clone().multiplyScalar(along).addScaledVector(bend,Math.sqrt(Math.max(0,.4*.4-along*along)));
 poseSegment(upper,new T.Vector3(),elbow);poseSegment(lower,elbow,wrist);grip.position.copy(wrist);
}
