// Parameterized execution patterns, selected only by explicit player intent.
export const ORDER_TEMPLATES=Object.freeze({
 protect_ranged:{name:'长矛保护远程部队',reference:'己方远程部队前方',actions:['deploy','form'],parameters:['reference','rows','direction']},
 flank_assembly:{name:'侧翼集结',reference:'参考步兵侧翼',actions:['deploy'],parameters:['reference','direction','shape']},
 front_support:{name:'步兵前线与弓兵后线',reference:'共同锚点与朝向',actions:['deploy','attack'],parameters:['reference','rows','direction']},
 advance_formation:{name:'多兵种保持阵型推进',actions:['move'],parameters:['direction','distance']},
 column_to_line:{name:'纵队转防御横队',actions:['deploy','deploy'],parameters:['reference','rows','direction']},
 retreat_reform:{name:'后撤重组',actions:['move','deploy'],parameters:['direction','distance','rows']},
 road_march:{name:'沿道路行军',actions:['deploy','move'],parameters:['reference','direction']},
 assemble:{name:'指定阵位集结',actions:['deploy'],parameters:['reference','shape','rows','direction']},
});
const ref=(role,relation='center',distance=0)=>({side:'own',select:{scope:'all',role},relation,distance});
export function expandTacticalTemplates(command){
 const result=structuredClone(command),expanded=[];
 for(let oi=0;oi<result.orders.length;oi++){const order=result.orders[oi],steps=[];for(const s of order.steps){if(s.type!=='template'){steps.push(s);continue;}
  const orient=s.direction?{direction:s.direction}:{},deploy=(shape,anchor,extra={})=>({type:'deploy',shape,...orient,...(anchor?{anchor}:{}),...extra});
  if(s.template==='protect_ranged')steps.push(deploy('line',s.reference||ref('archer','front',2),{rows:s.rows||2,formed:true}));
  if(s.template==='flank_assembly')steps.push(deploy(s.shape||'column',s.reference||ref('infantry','right',2)));
  if(s.template==='advance_formation')steps.push({type:'move',direction:s.direction||'forward',distance:s.distance||1,keepFormation:true});
  if(s.template==='column_to_line')steps.push(deploy('column',s.reference),deploy('line',undefined,{rows:s.rows||2,formed:true}));
  if(s.template==='retreat_reform')steps.push({type:'move',direction:s.direction||'back',distance:s.distance||2,keepFormation:true},deploy('line',undefined,{rows:s.rows||2,formed:true}));
  if(s.template==='road_march'){if(!s.reference)throw Error('沿道路行军需要指定已知目标区域');steps.push(deploy('column',undefined,{alongRoad:true}),{type:'move',anchor:s.reference,alongRoad:true,keepFormation:true});}
  if(s.template==='assemble')steps.push(deploy(s.shape||'line',s.reference,{rows:s.rows||2}));
  if(s.template==='front_support'){
   if(order.steps.length!==1)throw Error('前后线协同模板须独立成组，避免重复指挥');const id=order.id||'support'+(oi+1),anchor=s.reference;
   expanded.push({id:id+'_front',...(order.after?{after:order.after}:{}),select:{...order.select,scope:'all',role:['spear','sword','infantry'].includes(order.select.role)?order.select.role:'infantry'},steps:[deploy('line',anchor,{rows:s.rows||2,formed:true})]});
   expanded.push({id,after:[id+'_front'],select:{...order.select,scope:'all',role:'archer'},steps:[deploy('line',anchor||ref('infantry','rear',2),{rows:1}),{type:'attack',target:{scope:'all'},advance:false,repeat:true,fireOnly:true}]});
  }
 }
 if(steps.length)expanded.push({...order,steps});}
 result.orders=expanded;return result;
}
