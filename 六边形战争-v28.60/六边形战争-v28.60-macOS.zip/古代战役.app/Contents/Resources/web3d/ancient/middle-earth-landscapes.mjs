import * as E from './engine.mjs';
import {MORANNON_WINDOWS, expandedMorannonCell, morannonWindows, meKind} from './middle-earth-data.mjs';

const {PLAIN,ROAD,MOUNTAIN,RIVER,SEA}=E.TERRAIN;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const relief=(x,y,w,h)=>Math.exp(-((x/w)**2+(y/h)**2));
const texture=(c,r)=>.18*Math.sin(c*.72+r*.43)+.10*Math.cos(r*1.17-c*.48);

function landscape(base,cols,rows,turnLimit,compact){
  const map=E.newMap(cols,rows);
  for(const key of ['scenarioId','name','intro','factions','gateRules'])map[key]=base[key];
  map.elevations=Array(cols*rows).fill(0);
  map.victory={mode:'middle-earth',layoutVersion:compact?6:2,turnLimit,points:{},waves:[]};
  const paint=(c,r,t,h=map.elevations[E.index(map,c,r)])=>{
    if(E.setTerrain(map,c,r,t))map.elevations[E.index(map,c,r)]=h;
  };
  const ground=(height)=>{
    for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
      const h=height(c,r)+texture(c,r);
      paint(c,r,h>=1.25?MOUNTAIN:PLAIN,h);
    }
  };
  const path=(stops,{water=false,ford=false,bridge=false,width=0}={})=>{
    for(let i=1;i<stops.length;i++){
      const [c0,r0]=stops[i-1], [c1,r1]=stops[i];
      let cell={c:c0,r:r0};
      const end={c:c1,r:r1};
      const steps=E.distance(cell,end);
      for(let j=0;j<=steps;j++){
        if(j){
          const x=c0+(c1-c0)*j/steps,y=r0+(r1-r0)*j/steps;
          cell=E.neighbors(cell.c,cell.r)
            .filter(p=>E.distance(p,end)===steps-j)
            .sort((a,b)=>Math.hypot(a.c-x,a.r-y)-Math.hypot(b.c-x,b.r-y))[0];
        }
        const {c,r}=cell;
        for(let d=-width;d<=width;d++){
          const x=Math.abs(r1-r0)>=Math.abs(c1-c0)?c+d:c;
          const y=Math.abs(r1-r0)>=Math.abs(c1-c0)?r:r+d;
          if(!E.inBounds(map,x,y))continue;
          const t=E.tile(map,x,y).terrain;
          if(water)paint(x,y,RIVER,-.46);
          else if(t&RIVER){
            if(!ford&&!bridge)continue;
            paint(x,y,RIVER|ROAD,-.46);
            if(bridge)E.setBridge(map,x,y);
          }else paint(x,y,t===SEA?SEA:t|ROAD);
        }
      }
    }
  };
  const label=(c,r,name)=>map.landmarks.push({c,r,label:name});
  const point=(key,c,r,name)=>{map.victory.points[key]={c,r};if(name)label(c,r,name);};
  const fort=(c,r,name,{team='egypt',level=2,gate=false}={})=>{
    if(!E.setFort(map,c,r,level,team,name))throw Error(`工事位置无效 ${map.scenarioId}: ${c},${r}`);
    if(gate){
      const u=E.fortAt(map,c,r);
      u.gate=true;
      u.hp=Math.round(E.FORT_HP[level]*.7);
    }
  };
  const deploy=(team,positions)=>{
    const army=base.units.filter(u=>u.team===team&&u.kind!=='fort');
    if(army.length!==positions.length)throw Error(`兵团编组数错误 ${map.scenarioId} ${team}`);
    army.forEach((u,i)=>{
      const [c,r]=positions[i];
      if(E.mobileAt(map,c,r)||!E.addUnit(map,u.kind,team,c,r))throw Error(`部署失败 ${map.scenarioId} ${u.kind} ${c},${r}`);
      if(u.customName)map.units.at(-1).customName=u.customName;
    });
  };
  const wave=(key,positions,turn)=>{
    const w=base.victory.waves.find(w=>w.key===key);
    if(w.rows.length!==positions.length)throw Error(`增援编组数错误 ${key}`);
    map.victory.waves.push({...w,turn:turn??w.turn,rows:w.rows.map(([kind,,,name],i)=>[kind,...positions[i],name])});
  };
  const buildings=(c0,r0,c1,r1,skip=()=>false)=>{
    for(let r=r0;r<=r1;r++)for(let c=c0;c<=c1;c++)
      if(!skip(c,r)&&(c+2*r)%5!==0)E.setHouse(map,c,r);
  };
  return {map,paint,ground,path,label,point,fort,deploy,wave,buildings};
}

function hornburg(base,compact){
  const l=landscape(base,58,36,24,compact);
  const {map,paint,ground,path,label,point,fort,deploy,wave}=l;
  const stream=[[0,24],[8,23],[16,23],[23,22],[28,22],[34,21],[43,23],[50,24],[57,25]];
  ground((c,r)=>{
    const throat=clamp((29-c)/27,0,1);
    const north=9+11*throat+1.4*Math.sin(c*.23);
    const south=29-5*throat+1.3*Math.cos(c*.18);
    const shelves=5.8*relief(c-22,r-12,5,4.6);
    const cliff=10*clamp((north-r)/8,0,1)+11*clamp((r-south)/7,0,1);
    const dike=r>10&&r<30?.98*relief(c-38,0,.8,1)-.49*relief(c-39.6,0,1.05,1):0;
    const buttress=relief(c-27,0,5.0,1)*Math.max(7.8*clamp((11-r)/2.6,0,1),7.6*clamp((r-27)/2.8,0,1));
    return Math.max(shelves,cliff,buttress)+dike;
  });
  path(stream,{water:true});
  path([[14,19],[21,16],[26,16],[31,16],[40,16],[49,18],[57,17]]);
  path([[14,19],[10,21],[6,22],[3,22]],{ford:true});
  path([[22,19],[26,20],[30,19],[35,18]]);
  path([[51,3],[48,8],[47,12],[48,17]]);
  path([[27,24],[27,22],[30,22]],{ford:true});
  if(compact){
    // Terrace the inner court, three gate approaches and the river tunnel floor.
    for(let r=13;r<=20;r++)for(let c=22;c<=31;c++){
      const t=E.tile(map,c,r).terrain;
      if(!(t&(RIVER|SEA)))paint(c,r,t&(ROAD|PLAIN),1.14);
    }
    for(let r=20;r<=23;r++)for(let c=24;c<=30;c++){
      const t=E.tile(map,c,r).terrain;
      if(!(t&(RIVER|SEA)))paint(c,r,t&ROAD,.30);
    }
    paint(26,21,ROAD,.30);
    for(let c=6;c<=20;c++){
      const r=c<11?21:20,t=E.tile(map,c,r).terrain;
      if(!(t&(RIVER|SEA)))paint(c,r,t|ROAD,.34);
    }
  }
  for(let r=10;r<=28;r++){
    if(r===22)continue;
    fort(27,r,r<=16?'号角堡':'深谷墙',{level:r===12||r===15||compact&&r>16&&r!==19?3:2,gate:r===16||r===19});
  }
  for(let c=21;c<27;c++)fort(c,12,'号角堡',{level:c===21?3:2});
  for(let r=13;r<=16;r++)fort(21,r,'号角堡',{level:r===16?3:2});
  for(let r=11;r<=29;r++){
    if(r===16||r>=21&&r<=23)continue;
    fort(38,r,'外堤',{level:1});
  }
  point('core',24,15,'号角堡内院');point('cave',6,22,'后方洞窟');
  point('counter',39,16,'外堤反击点');point('culvert',27,22,'溪流涵洞');
  point('blast',27,23,'爆破墙段');point('sally',27,19,'侧门');
  if(compact)point('gate',27,16,'号角堡正门');else label(27,16,'号角堡正门');label(10,21,'后方狭谷');
  deploy('egypt',[[25,16],[26,15],[24,15],[25,18],[27,17],[26,20],[26,16],[24,16],[25,21]]);
  deploy('coalition',[[34,14],[35,15],[34,16],[35,17],[35,18],[36,14],[36,17],[36,19],[42,14],[42,16],[43,18],[32,23],[29,22]]);
  wave('dawn',compact?[[43,12],[43,13],[44,12],[44,13],[45,12],[45,13]]:[[48,9],[47,10],[48,10],[49,10],[47,11],[48,11]]);
  return map;
}

function erebor(base,compact){
  const {map,ground,path,label,point,fort,deploy,wave,buildings}=landscape(base,52,40,26,compact);
  ground((c,r)=>{
    const west=21-r*.45+1.1*Math.sin(r*.32),east=29+r*.40+1.05*Math.sin(r*.21);
    const spurs=(8.3*relief(c-west,0,4.8,1)+8.0*relief(c-east,0,5.2,1))*clamp((35-r)/21,0,1);
    const north=14*relief(c-25,r+2,19,9);
    const raven=4.5*relief(c-9,r-25,3.6,4.2);
    return Math.max(north,spurs)+raven;
  });
  path([[26,7],[26,11],[27,16],[25,22],[26,27],[28,31],[29,39]],{water:true});
  path([[25,8],[25,12],[24,18],[23,22],[21,28],[20,39]]);
  path([[24,14],[20,16],[16,20],[13,24],[9,25],[5,24],[4,18],[8,13],[13,10]]);
  path([[27,14],[29,16],[34,18],[37,24],[42,27],[46,21],[44,16],[39,12],[36,9]]);
  path([[21,28],[25,28],[30,28],[34,31]],{bridge:true});
  path([[22,21],[25,21],[31,21]],{ford:true});
  path([[29,29],[31,24],[30,19],[27,15],[27,10]]);
  path([[20,32],[25,32],[28,32]],{ford:true});
  buildings(15,25,24,33,(c,r)=>c===18||r===28||r===31||map.elevations[E.index(map,c,r)]>1.25);
  buildings(29,25,34,30,(c,r)=>r===27||c===32);
  for(const c of [22,23,24,25])fort(c,8,'孤山正门',{level:c===25?3:2,gate:c===25});
  for(const c of [27,28,29])fort(c,8,'孤山正门',{level:c===27?3:2});
  point('core',25,9,'孤山正门');point('counter',24,18,'山门通路');
  label(9,25,'乌鸦岭');label(34,18,'东侧山脊');label(18,29,'河谷邦废墟');
  deploy('egypt',[[25,9],[30,17],[31,18],[32,18],[33,19],[31,20],[34,20],[32,21],[33,21],
    [12,23],[13,24],[11,25],[10,25],[21,22],[22,23]]);
  deploy('coalition',[[25,28],[24,24],[23,25],[21,26],[22,26],[23,26],[24,26],[24,27],[25,27],[21,27],[22,27],[23,27],[24,28],
    [6,29],[7,29],[43,27],[44,27]]);
  wave('eagles',[[12,22],[35,19]]);wave('beorn',[[16,30]]);
  return map;
}


function isen(base,compact){
  const {map,ground,path,label,point,deploy,wave}=landscape(base,51,32,24,compact);
  const first=base.scenarioId.endsWith('first');
  ground((c,r)=>1.3*relief(c-24,r-14,2.6,4.5)+2.2*relief(c-6,r-4,10,7)+1.9*relief(c-44,r-27,9,7));
  path([[25,0],[24,7],[21,12],[20,17],[22,22],[25,26],[27,31]],{water:true,width:1});
  path([[25,0],[25,7],[27,12],[28,17],[29,21],[27,25],[27,31]],{water:true,width:1});
  path([[0,17],[13,17],[21,17],[30,17],[38,17],[50,20]],{ford:true});
  path([[9,0],[12,9],[13,17],[13,24],[9,31]]);
  path([[38,0],[35,9],[35,17],[39,23],[43,28],[48,31]]);
  path([[17,20],[21,20],[27,20],[35,20]],{ford:true});
  label(24,14,'艾辛河中洲低丘');
  point('ford',24,17,'艾辛河渡口');point('exit',43,28,'东南撤离路');
  deploy('egypt',[[first?24:32,first?16:17],[first?32:17,17],[24,17],[31,18],[32,18],[33,19],[32,20]]);
  deploy('coalition',[[13,12],[14,13],[15,14],[16,12],[15,13],[16,14],[33,8],[34,9],[36,10],[34,11],[35,8],[35,10]]);
  if(first)wave('rescue',[[41,26],[42,26],[43,26]]);
  else wave('flank',compact?[[39,7],[40,7],[41,8]]:[[41,10],[42,11],[42,12]]);
  return map;
}

function pelennor(base,compact){
  const {map,ground,path,label,point,fort,deploy,wave,buildings}=landscape(base,54,35,25,compact);
  ground((c,r)=>9*relief(c-3,r-27,8.5,13)+.99*relief(c-19,r-15,15,10)+.66*relief(c-34,r-24,8,10));
  path([[47,0],[46,10],[48,18],[45,27],[47,34]],{water:true,width:3});
  path([[23,5],[30,6],[37,5],[45,7]],{water:true});
  path([[27,30],[34,31],[40,29],[46,29]],{water:true});
  path([[11,27],[17,27],[23,24],[32,18],[43,14],[compact?53:47,13]],{bridge:true});
  path([[12,27],[18,21],[20,13],[21,5],[18,0]],{ford:true});
  path([[23,24],[26,27],[31,29],[38,32],[44,32]],{ford:true});
  path([[14,23],[13,27],[14,31]]);
  for(let r=20;r<=33;r++)fort(14,r,'米那斯提力斯主城',{gate:r===27,level:r%4===1||r===27?3:2});
  for(const r of [19,34])for(let c=8;c<=14;c++)fort(c,r,'米那斯提力斯主城');
  for(let r=7;r<29;r++)if(![14,15,16,22,23].includes(r))fort(41,r,'兰马斯残墙',{level:1});
  buildings(24,9,31,15,(c,r)=>r===11||c===27||r===13);
  buildings(33,23,38,27,(c,r)=>c===36||r===25);
  point('core',12,27,'米那斯提力斯城心');point('gate',14,27,'王城大门');point('counter',23,24,'佩兰诺大道');
  label(44,32,'哈隆德港');label(21,4,'洛汗北来');
  deploy('egypt',[[13,22],[13,23],[13,24],[13,25],[13,26],[13,28],[13,29],[13,30],[16,27],[16,26],[17,24]]);
  deploy('coalition',[[24,24],[24,23],[25,24],[26,23],[26,22],[25,22],[24,21],[26,21],[27,23],[27,24],[27,22],[27,21],[19,26],[30,25],[24,20]]);
  wave('rohan',compact?[[21,10],[20,11],[21,11],[22,10],[22,11],[23,10],[23,9]]:[[21,4],[20,5],[21,5],[22,4],[22,5],[23,4],[23,3]]);
  wave('harad',[[38,23],[39,23],[39,24],[38,24]]);
  wave('ships',[[43,32],[42,32],[42,33],[43,33],[44,33]]);
  return map;
}

function pelargir(base,compact){
  const {map,paint,ground,path,label,point,deploy,buildings}=landscape(base,51,33,24,compact);
  const shore=r=>36+Math.round(1.6*Math.sin((r-3)*.22));
  ground((c,r)=>2.2*relief(c-4,r-15,9,16)+.54*relief(c-23,r-5,11,7));
  for(let r=0;r<map.rows;r++)for(let c=shore(r);c<map.cols;c++)paint(c,r,SEA,-.46);
  path([[30,0],[32,7],[32,15],[32,25],[29,32]]);
  path([[2,17],[18,17],[30,17],[34,17]]);
  path([[16,17],[20,9],[30,7]]);
  path([[17,17],[20,24],[30,25]]);
  if(compact){
    path([[24,13],[27,10],[30,8],[32,7]]);
    path([[24,21],[27,24],[30,25],[32,25]]);
  }
  const rows=[7,16,25];
  const berths=rows.map(r=>[shore(r)-1,r]);
  for(const [i,[c,r]] of berths.entries()){
    path([[32,r],[c,r]]);
    point('dock'+i,c,r,'黑船泊位 '+(i+1));
  }
  for(const r of rows)buildings(25,r-3,34,r+3,(c,y)=>y===r||c===31||y===17||c===30);
  point('core',34,17,'履约码头');label(25,21,'南岸仓储街');
  deploy('egypt',compact?[[22,17],[24,13],[23,16],[22,16],[24,21],[25,15],[25,17],[24,18],[25,19]]:
    [[23,17],[23,15],[23,16],[22,17],[23,18],[25,16],[24,16],[24,17],[24,18]]);
  deploy('coalition',[[30,6],[30,7],[30,8],[31,8],[30,15],[31,15],[31,16],[31,17],[30,24],[30,25],[31,25],[31,26],...berths]);
  return map;
}

function morannon(base,compact){
  const l=landscape(base,105,31,34,compact);
  const {map,paint,ground,path,label,point,fort,deploy,wave}=l;
  const windows=morannonWindows(map);
  const relocate=p=>expandedMorannonCell(p.c,p.r);
  ground((c,r)=>{
    if(c<windows.front[1]){
      const cliffs=10*Math.max(relief(c-32,r-1,7,7),relief(c-32,r-30,7,7));
      const hills=4.25*relief(c-13,r-11,5.6,3.7)+4.15*relief(c-13,r-19,5.8,3.6);
      return cliffs+hills+1.42*relief(c-2,r-22,8,16);
    }
    if(c<windows.pass[1]){
      const channel=16+.85*Math.sin(c*.47);
      const pinch=2.4*relief(c-55,0,3.1,1);
      return 9.6*clamp((Math.abs(r-channel)-4.6+pinch)/11.5,0,1)+2.0*relief(c-55,r-11,4,3);
    }
    const cone=11.5*relief(c-101,r-13,8.1,12.8);
    const ravines=1.35*Math.sin(r*.48+c*.68)*Math.max(0,1-relief(c-103,r-13,4,10));
    return Math.max(0,cone+ravines+2.0*relief(c-78,r-4,9,8));
  });
  for(let r=0;r<map.rows;r++)for(let c=0;c<map.cols;c++)
    if(!Object.values(windows).some(([a,b])=>c>=a&&c<b))paint(c,r,SEA,-.46);
  for(let r=0;r<base.rows;r++)for(let c=0;c<base.cols;c++){
    if(!Object.values(MORANNON_WINDOWS).some(([a,b])=>c>=a&&c<b))continue;
    const t=E.tile(base,c,r).terrain;
    const p=expandedMorannonCell(c,r);
    if(t&RIVER)paint(p.c,p.r,t,-.46);
    if(t&ROAD)paint(p.c,p.r,t|(E.tile(map,p.c,p.r).terrain&MOUNTAIN));
  }
  path([[2,15],[11,15],[20,15],[28,15],[35,15]]);
  path([[10,12],[13,11],[16,12],[18,13]]);
  path([[10,19],[13,20],[16,19],[18,17]]);
  path([[13,15],[14,8],[19,5],[26,7],[29,11]]);
  path([[13,15],[15,22],[20,25],[26,23],[29,19]]);
  path([[80,16],[84,17],[88,16],[92,16]]);
  path([[76,16],[81,21],[88,24],[94,23],[96,19],[97,14]]);
  path([[78,14],[83,12],[87,14],[91,13]]);
  if(compact){
    // Ash banks mask the southern detour. The central road remains quicker
    // but exposes a noisy march to both the camp and the Eye.
    for(let c=78;c<=93;c++)for(let r=22;r<=25;r++){
      if(E.tile(map,c,r).terrain&ROAD)continue;
      paint(c,r,MOUNTAIN,Math.max(1.25,map.elevations[E.index(map,c,r)]));
    }
  }
  for(const u of base.units.filter(u=>u.kind==='fort')){
    const p=relocate(u);
    fort(p.c,p.r,'黑门',{team:u.team,gate:u.gate,level:u.level});
  }
  const gate=map.units.find(u=>u.gate);
  for(const r of [gate.r-6,gate.r-5,gate.r-4,gate.r+4,gate.r+5,gate.r+6])
    fort(gate.c,r,'黑门',{team:'coalition',level:3});
  for(const p of base.landmarks){const q=relocate(p);label(q.c,q.r,p.label);}
  for(const [k,p] of Object.entries(base.victory.points)){
    const q=relocate(p);point(k,q.c,q.r);
  }
  const frontDefenders=[[13,15],[12,17],[12,13],[14,12],[14,13],[13,12],[13,13],[13,17],[14,18],[13,18],[12,18]];
  for(const team of ['egypt','coalition']){
    let defender=0;
    const positions=base.units.filter(u=>u.team===team&&u.kind!=='fort').map(u=>{
      const origin=relocate(u);
      const patrolPost=compact&&origin.c>=windows.doom[0]&&team==='coalition'?
        (u.kind==='meTracker'?(origin.r<16?[86,8]:[90,18]):u.kind==='meOrc'?[84,9]:u.kind==='meGollum'?[85,20]:null):null;
      const [c,r]=patrolPost??(team==='egypt'&&origin.c<windows.front[1]?frontDefenders[defender++]:[origin.c,origin.r]);
      const t=E.tile(map,c,r).terrain;
      if(t&RIVER)paint(c,r,t|ROAD);
      if(!meKind(u.kind)?.air&&(map.elevations[E.index(map,c,r)]>=5.8||meKind(u.kind)?.large&&t&MOUNTAIN))
        paint(c,r,t&MOUNTAIN?t&~MOUNTAIN:t,Math.min(1.18,map.elevations[E.index(map,c,r)]));
      return [c,r];
    });
    deploy(team,positions);
  }
  for(const w of base.victory.waves)wave(w.key,w.rows.map(([,c,r])=>{
    const p=expandedMorannonCell(c,r);
    const t=E.tile(map,p.c,p.r).terrain;
    if(map.elevations[E.index(map,p.c,p.r)]>=5.8)paint(p.c,p.r,t&~MOUNTAIN,1.18);
    return [p.c,p.r];
  }));
  return map;
}

export function expandedMiddleEarthMap(base,{compact=false}={}){
  const id=base.scenarioId;
  if(id.startsWith('me_isen'))return isen(base,compact);
  if(id.startsWith('me_morannon'))return morannon(base,compact);
  return {me_hornburg:hornburg,me_erebor:erebor,me_pelennor:pelennor,me_pelargir:pelargir}[id](base,compact);
}
