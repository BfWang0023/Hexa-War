import {planningState,authoritativeState} from './fog-policy.mjs';
// Shared identity/selection vocabulary. No tactical scoring, hidden enemy data or rule changes.
import {STATS,isShip,isFormableInfantry,unitMaxHp,visibleTo,isRouted,fortAt,neighbors,distance} from './engine.mjs';
import {selectable,axial,offset} from './group-command.mjs';
import {oppositeFrame,selectSpatial} from './battlefield-space.mjs';
export const ROLE_KINDS=Object.freeze({
 scout:['scout'],
 infantry:['scout','light','heavy','guard','greekHoplite','phalangite','romanHastati','romanPrincipes','romanTriarii','romanLegion','caesarReserve','pompeyLegion','gaulInfantry','iberianInfantry','africanInfantry','zamaVeteran'],
 sword:['guard','romanHastati','romanPrincipes','romanLegion','caesarReserve','pompeyLegion','gaulInfantry','iberianInfantry','zamaVeteran'],
 spear:['light','heavy','greekHoplite','phalangite','romanTriarii','africanInfantry'],
 archer:['archer','romanArcher'],crossbow:['chinaCrossbow'],
 cavalry:['cavalry','companionCavalry','romanHorse','romanAlliedHorse','punicHeavyHorse','numidianHorse','masinissa','masinissaHorse','zamaPunicHorse','pompeyHorse','parthianHorseArcher','parthianCataphract'],
 heavyChariot:Object.keys(STATS).filter(k=>STATS[k].chargeClass==='heavyChariot'),
 chariot:['chariot','hittiteChariot','chinaHeavyChariot','scythedChariot','pharaoh'],
 elephant:['warElephant'],ship:['warship','transport','siegeGalley','athenianTrireme','alliedTrireme','phoenicianTrireme','imperialTrireme','octavianLiburnian','antonyHeavyGalley','cleopatraGalley','moraleFlagship'],
 siege:['siegeRam','romanOnager','siegeTower','siegeGalley'],supply:['supplyWagon','arrowCamel'],engineer:['engineer'],
 commander:['pharaoh','hittiteKing','hero','chinaGeneral','hannibal','paullus','varro','scipio','masinissa'],guard:['guard','moraleGuard','moraleFlagship'],ox:['chinaFireOx'],
});
export const DIRECTIONS=Object.freeze({E:0,NE:1,NW:2,W:3,SW:4,SE:5,ENE:.5,N:1.5,WNW:2.5,WSW:3.5,S:4.5,ESE:5.5});
export const world=p=>({x:p.c+(p.r&1)*.5,z:p.r*Math.sqrt(3)/2});
const center=xs=>xs.reduce((a,p)=>({x:a.x+p.x/xs.length,z:a.z+p.z/xs.length}),{x:0,z:0});
export function commandFrame(state,team){state=planningState(state,team);
 const own=state.map.units.filter(u=>selectable(u,team)),a=center(own.map(world));
 const visible=state.map.units.filter(u=>(u.team!==team||u.mutinous)&&u.hp>0&&u.kind!=='fort'&&visibleTo(state,team,u.c,u.r));
 const b=visible.length?center(visible.map(world)):world({c:Math.floor(state.map.cols/2),r:Math.floor(state.map.rows/2)});
 const p={c:Math.floor(a.x),r:0},v=world(p),dirs=neighbors(p.c,p.r).map(n=>{const q=world(n);return {x:q.x-v.x,z:q.z-v.z}});
 const dx=b.x-a.x,dz=b.z-a.z;let heading=Math.hypot(dx,dz)<.5?(team==='egypt'?0:3):dirs.map(d=>d.x*dx+d.z*dz).indexOf(Math.max(...dirs.map(d=>d.x*dx+d.z*dz)));
 return {heading,forward:dirs[heading],origin:a};
}
export function directionIndex(direction,frame){if(Object.hasOwn(DIRECTIONS,direction))return DIRECTIONS[direction];return ({forward:frame.heading,back:(frame.heading+3)%6,left:(frame.heading+2)%6,right:(frame.heading+5)%6})[direction];}
export function translate(p,heading,steps){let q={...p};for(let i=0;i<steps;i++)q=neighbors(q.c,q.r)[Number.isInteger(heading)?heading:(Math.floor(heading)+(i%2))%6];return q;}
export function observedUnits(state,team){state=planningState(state,team);return state.map.units.filter(u=>u.hp>0&&!u.aboard&&(u.team===team||visibleTo(state,team,u.c,u.r)));}
export function resolveUnits(state,selector,context,{enemy=false}={}){state=planningState(state,context.team);
 const {team,frame}=context,known=observedUnits(state,team),pool=known.filter(u=>enemy?(u.team!==team||u.mutinous)&&u.kind!=='fort':selectable(u,team));
 let xs=pool.filter(u=>!selector.ids||selector.ids.includes(u.id));
 if(selector.scope==='selected')xs=xs.filter(u=>context.selectedIds.includes(u.id));
 if(selector.role)xs=xs.filter(u=>ROLE_KINDS[selector.role].includes(u.kind));
 if(selector.kinds)xs=xs.filter(u=>selector.kinds.includes(u.kind));
 if(selector.exclude)xs=xs.filter(u=>!resolveUnits(state,selector.exclude,context,{enemy}).some(v=>v.id===u.id));
 if(selector.kind)xs=xs.filter(u=>u.kind===selector.kind);
 if(selector.lastOrder){const ids=new Set(xs.map(u=>u.id)),prior=[...(context.recentOrders||[])].reverse().find(r=>r.team===team&&r.turn===state.turn&&r.map===authoritativeState(state).map&&r.ids.some(id=>ids.has(id)));xs=prior?xs.filter(u=>prior.ids.includes(u.id)):[];}
 if(selector.name)xs=xs.filter(u=>[u.customName,u.formation,STATS[u.kind].name,state.map.unitNames?.[u.kind],state.map.unitNames?.[`${u.team}:${u.kind}`]].some(n=>n?.includes(selector.name)));
 const spatial=enemy?oppositeFrame(frame,pool):frame;
 const opponents=known.filter(u=>enemy?!u.mutinous&&u.team===team&&u.kind!=='fort':(u.team!==team||u.mutinous)&&u.kind!=='fort');
 const reserve=selector.zone==='reserve'?pool.filter(u=>/预备|后备|reserve/i.test(u.formation||u.customName||'')):[];const allowed=new Set((reserve.length?reserve:selectSpatial(pool,selector,spatial,opponents)).map(u=>u.id));xs=xs.filter(u=>allowed.has(u.id));
 if(selector.group)xs=xs.filter(u=>u.formation===selector.group||u.customName===selector.group);
 if(selector.zone==='reserve'){const named=xs.filter(u=>/预备|后备|reserve/i.test(u.formation||u.customName||''));if(named.length)xs=named;}
 if(selector.hpBelow!==undefined)xs=xs.filter(u=>u.hp/unitMaxHp(state.map,u)<selector.hpBelow);
 if(selector.nearWall){const walls=known.filter(u=>u.kind==='fort');xs=xs.filter(u=>walls.some(w=>distance(u,w)<=2));}
 if(selector.nearest){const targets=known.filter(u=>enemy?!u.mutinous&&u.team===team&&u.kind!=='fort':(u.team!==team||u.mutinous)&&u.kind!=='fort');if(!targets.length)return [];xs.sort((a,b)=>Math.min(...targets.map(e=>distance(a,e)))-Math.min(...targets.map(e=>distance(b,e)))||a.id.localeCompare(b.id));xs=xs.slice(0,selector.nearest);}
 return xs.sort((a,b)=>a.id.localeCompare(b.id));
}
export function compactObservation(state,context){state=planningState(state,context.team);
 const counts=xs=>Object.fromEntries([...new Set(xs.map(u=>u.kind))].map(k=>[k,xs.filter(u=>u.kind===k).length]));
 const units=observedUnits(state,context.team);return {team:context.team,turn:state.turn,selectedCount:context.selectedIds.length,forward:Object.keys(DIRECTIONS)[context.frame.heading],ownKinds:counts(units.filter(u=>u.team===context.team&&u.kind!=='fort')),visibleEnemyKinds:counts(units.filter(u=>u.team!==context.team&&u.kind!=='fort')),landmarks:(state.map.landmarks||[]).filter(p=>visibleTo(state,context.team,p.c,p.r)).slice(0,12).map(p=>({name:p.label,c:p.c,r:p.r})),coordinates:'All displayed, spoken and structured positions use zero-based c,r.'};
}
