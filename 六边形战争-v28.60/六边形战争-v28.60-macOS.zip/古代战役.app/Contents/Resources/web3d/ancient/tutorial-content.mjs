import {newMap,importMap,exportMap,addUnit,mobileAt,setTerrain,setBridge,setFort,TERRAIN,knownUnitAt,isRouted,fortAt,formationSupport} from './engine.mjs';
export const TUTORIALS=Object.freeze([
 {id:'basics',name:'基础操作',summary:'镜头、选择与属性 · 建议先学',next:'movement'},
 {id:'movement',name:'移动与攻击',summary:'移动、攻击、行动力和回合'},
 {id:'terrain',name:'地形与道路',summary:'山地、山路和跨河桥梁'},
 {id:'morale',name:'士气与战斗',summary:'侧翼配合、击溃和自动撤退'},
 {id:'formation',name:'阵型与朝向',summary:'列阵、钟面转向与解除阵型'},
 {id:'recon',name:'侦察与迷雾',summary:'斥候发现敌军、工事和地图记忆'},
 {id:'command',name:'军队指挥',summary:'框选、批量行军、传令官和委托'},
 {id:'naval',name:'海战基础',summary:'航向、两格冲角、接舷与机动'}
]);
export function createTutorialMap(id){
 const info=TUTORIALS.find(x=>x.id===id);if(!info)throw Error('未知教学模块');
 const m=newMap(22,15);m.scenarioId='custom_tutorial_'+id;m.name='训练：'+info.name;m.factions={egypt:'训练蓝军',coalition:'训练红军'};
 const actors={};const put=(tag,kind,team,c,r)=>{if(!addUnit(m,kind,team,c,r))throw Error('训练部署不合法：'+tag);const u=mobileAt(m,c,r);actors[tag]=u.id;return u;};
 if(id==='naval'){
  m.scenarioId='salamis';m.terrain.fill(TERRAIN.SEA);m.weather={windDir:0,clouds:[]};m.victory={mode:'salamis',bay:{cMin:17,rMin:10,cMax:20,rMax:13},greekLosses:1,persianLosses:1,bayShips:1};
  put('hero','athenianTrireme','egypt',4,7).facing=1.5;put('enemy','phoenicianTrireme','coalition',7,7).facing=1.5;
 }else{
  put('leader','pharaoh','egypt',0,0);
  if(id==='recon'){
   put('hero','scout','egypt',4,7);put('enemy','heavy','coalition',15,7);setFort(m,15,8,2,'coalition');actors.fort=fortAt(m,15,8).id;
  }else if(id==='morale'){
   put('hero','light','egypt',7,7);put('support','light','egypt',8,6);put('enemy','light','coalition',8,7).morale=.32;put('reserve','heavy','coalition',20,12);
  }else if(id==='command'){
   put('hero','light','egypt',7,7);put('wing1','light','egypt',7,6);put('wing2','light','egypt',7,8);put('enemy','heavy','coalition',20,12);
  }else if(id==='terrain'){
   put('hero','light','egypt',6,7);put('enemy','heavy','coalition',20,12);
   setTerrain(m,7,6,TERRAIN.MOUNTAIN);setTerrain(m,8,6,TERRAIN.MOUNTAIN|TERRAIN.ROAD);setTerrain(m,9,6,TERRAIN.ROAD);
   for(let r=0;r<m.rows;r++)setTerrain(m,10,r,TERRAIN.RIVER);
   setTerrain(m,10,6,TERRAIN.RIVER|TERRAIN.ROAD);setBridge(m,10,6);setTerrain(m,11,6,TERRAIN.ROAD);
  }else{
   put('hero',id==='formation'?'greekHoplite':'light','egypt',7,7);if(id==='formation')put('partner','greekHoplite','egypt',7,8);put('enemy','heavy','coalition',id==='movement'?9:16,7);
  }
 }
 const normalized=importMap(exportMap(m));
 for(const key of Object.keys(actors)){const old=m.units.find(u=>u.id===actors[key]);actors[key]=normalized.units.find(u=>u.c===old.c&&u.r===old.r&&u.kind===old.kind).id;}
 return {map:normalized,actors,focus:id==='recon'?{c:9,r:7}:id==='naval'?{c:6,r:7}:{c:9,r:7},fog:{unitFog:true,terrainFog:id==='recon',initialKnowledge:id==='recon'?'unknown':'full'}};
}
export function tutorialSteps(id){
 const step=(key,title,text,test,options={})=>({key,title,text,test,...options});
 const select=()=>step('select','选中蓝军',()=> '左键点击金色提示圈中的蓝色部队。右侧会显示真实属性，血条左侧数字代表剩余行动次数。',x=>x.selected===x.actors.hero,{actor:'hero',rule:'units'});
 const at=(x,c,r)=>{const u=x.unit('hero');return u?.c===c&&u.r===r;};
 const moved=(c,r,title,text)=>step('move-'+c+'-'+r,title,()=>text,(x,b)=>at(x,c,r)&&x.unit('hero').movesUsed>b.units[x.actors.hero].movesUsed,{cell:{c,r},rule:'terrain'});
 const attacked=(ram)=>step(ram?'ram':'attack',ram?'冲击敌船侧舷':'攻击红军',()=>ram?'左键点击相邻红船。真实连续航行满足条件时才有冲角；本练习使用固定随机序列。':'左键点击金圈中的红军，发动一次合法攻击。命中或落空都消耗行动力；无需击杀目标。',(x,b)=>x.events.some(e=>e.serial>b.serial&&e.type==='attack'&&e.ok&&e.id===x.actors.hero&&(ram===undefined||!!e.ram===ram)),{actor:'enemy',rule:ram?'naval':'combat'});
 const turn=()=>step('turn','恢复下一回合行动',()=> '点击上方“结束回合”。教学红军不会自主进攻，双方仍正常结算回合、行动力及溃退。',(x,b)=>x.game.turn>b.turn&&x.game.side==='egypt'&&x.unit('hero').actionsLeft>0,{element:'end-turn',rule:'movement'});
 switch(id){
 case 'basics':return [step('pan','平移镜头',()=> '按住鼠标右键拖动战场。单击右键不会移动或攻击部队。',(x,b)=>Math.hypot(x.camera.x-b.camera.x,x.camera.z-b.camera.z)>1,{rule:'controls'}),step('rotate','旋转镜头',()=> '按住鼠标中键拖动，改变观察方向或俯仰角。',(x,b)=>Math.abs(x.camera.yaw-b.camera.yaw)+Math.abs(x.camera.pitch-b.camera.pitch)>.04,{rule:'controls'}),step('zoom','缩放战场',()=> '在战场上滚动鼠标滚轮，拉近或拉远观察。',(x,b)=>Math.abs(x.camera.distance-b.camera.distance)>1,{rule:'controls'}),step('top','切换棋盘视角',x=>`按 ${x.key('top')} 或点击“正上方棋盘”，从正上方观察六边形。自定义按键会同步显示。`,x=>x.camera.board,{element:'board-view',rule:'controls'}),select(),step('details','查看单位属性',()=> '在右侧单位卡片点击“属性规则”。查看生命、护甲与行动力的区别，手册不暂停或遮住整个战场。',x=>x.manual==='units',{element:'unit-rules-link',rule:'units'})];
 case 'movement':return [select(),moved(8,7,'移动一格','左键点击金圈标记的可达地格（8,7）。实际移动后，行动力徽章从2变为1。'),attacked(),turn()];
 case 'terrain':return [select(),moved(7,6,'走进山地','左键点击山地（7,6）。普通步兵在无路山地每次移动最多一格，但每回合仍可行动两次。'),moved(8,6,'进入山区道路','左键点击山路（8,6）。山路恢复平地移动能力，不额外增加一格；地形提示显示实际路径成本。'),turn(),moved(10,6,'跨过河流','左键点击桥梁（10,6），沿道路跨河。桥梁使用原有合法通行规则，不能直接走过普通河面。')];
 case 'morale':return [select(),step('flank','配合友军击溃敌人',()=> '左键攻击红军。另一支蓝军已在侧翼；红军预设为低士气，观察受伤后士气条与溃逃状态。',x=>isRouted(x.unit('enemy')),{actor:'enemy',rule:'morale'}),step('retreat','观察真实溃退',()=> '点击“结束回合”。溃兵将在自身回合按既有规则逃离，不能再接受正常指挥。',(x,b)=>{const u=x.unit('enemy'),old=b.units[x.actors.enemy];return x.game.turn>b.turn&&(u.c!==old.c||u.r!==old.r);},{element:'end-turn',rule:'morale'})];
 case 'formation':return [select(),step('form','组成防御阵型',()=> '点“列阵”，选3点并确认。绿色半圆是正面180°（含边界），红色背面防御为0；列阵消耗一次行动。',x=>x.unit('hero').formed&&x.unit('hero').facing===0,{element:'selected-card',actor:'hero',rule:'formation'}),step('partner','选择相邻友军',()=> '左键选择另一支蓝色重步兵。任意相邻有效列阵友军都能协同，不要求朝向相同。',x=>x.selected===x.actors.partner,{actor:'partner',rule:'formation'}),step('opposite','背靠背列阵',()=> '让第二支部队朝9点（西）列阵。两人都获得攻防+1，但每人背面仍为0，不会替邻军格挡。',x=>x.unit('partner').formed&&x.unit('partner').facing===3&&formationSupport(x.game,x.unit('hero')).some(a=>a.id===x.actors.partner),{actor:'partner',rule:'formation'}),step('group','批量选择阵线',()=> '按Shift点另一支重步兵，或左键框住两人。方阵面板会标出协同与孤立状态，连线只在选中时出现。',x=>['hero','partner'].every(k=>x.group.includes(x.actors[k])),{actors:['hero','partner'],rule:'formation'}),step('north','统一调整到世界正北',()=> '点“批量转向”，选12点并确认。每人独立消耗一次行动；12点永远是世界北，不随镜头改变。',x=>['hero','partner'].every(k=>x.unit(k).facing===1.5),{rule:'formation'}),turn(),step('unform','批量解除列阵',()=> '重新框选两人，点“批量解除列阵”。每人消耗一次行动，协同与半圆立即消失。',x=>['hero','partner'].every(k=>!x.unit(k).formed),{actors:['hero','partner'],rule:'formation'})];
 case 'recon':return [select(),step('discover','向前侦察',()=> '左键移动到（8,7）。斥候能看到更远；进入视野后才能发现红军及敌方城墙。',x=>at(x,8,7)&&!!knownUnitAt(x.game,'egypt',15,7)&&!!x.known.units.find(u=>u.id===x.actors.fort),{cell:{c:8,r:7},rule:'recon'}),step('memory','离开视野，保留地图记忆',()=> '左键返回（4,7）。敌军应消失，已侦察城墙仍保留上次情报，不实时透露隐藏守军。',x=>at(x,4,7)&&!knownUnitAt(x.game,'egypt',15,7)&&!!x.known.units.find(u=>u.id===x.actors.fort),{cell:{c:4,r:7},rule:'recon'})];
 case 'command':return [step('group','框选三支部队',()=> '用左键拖出矩形，圈住三支蓝军。也可按Shift逐个加入；不要选远处指挥官。',x=>['hero','wing1','wing2'].every(k=>x.group.includes(x.actors[k])),{actors:['hero','wing1','wing2'],rule:'command'}),step('group-move','批量行军',()=> '左键点击（9,7）批量行军。三支部队分别向目标附近的可达格移动。',(x,b)=>['hero','wing1','wing2'].every(k=>x.unit(k).movesUsed>b.units[x.actors[k]].movesUsed),{cell:{c:9,r:7},rule:'command'}),step('officer','用一句话继续行军',x=>`按 ${x.key('officer')} 打开传令官，输入“选中的部队向东移动一格”并回车。保持当前三支部队选中。`,(x,b)=>['hero','wing1','wing2'].every(k=>x.unit(k).movesUsed>b.units[x.actors[k]].movesUsed)&&x.officer.some(v=>v.record?.completed>0),{rule:'command'}),step('delegate-select','选中需要委托的部队',()=> '左键选中金圈蓝军，或框选三支蓝军；行动力为0也可以接受委托。',x=>['hero','wing1','wing2'].some(k=>x.selected===x.actors[k]||x.group.includes(x.actors[k])),{actors:['hero','wing1','wing2'],rule:'command'}),step('delegate','下达跨回合委托',x=> '输入“要求选中部队在3个回合内抵达坐标(14,7)附近”。'+(['hero','wing1','wing2'].filter(k=>x.selected===x.actors[k]||x.group.includes(x.actors[k])).some(k=>x.unit(k).actionsLeft>0)?'仍有行动力的部队可先行军。':'当前行动力已耗尽，任务会等待后续回合。'),(x,b)=>x.game.delegatedOrders?.length>(b.tasks||0),{rule:'command'}),step('finish-task','让委托继续执行',()=> '点击“结束回合”，等待委托部队行军停下；必要时再结束一回合。任务列表可暂停或取消；不要连续快速结束回合。',x=>x.game.delegatedOrders?.some(t=>t.status==='completed'),{element:'end-turn',rule:'command'})];
 case 'naval':return [select(),step('bow','将船首朝向东方',()=> '点“转向”，在钟面选3点并确认。转向消耗行动，原地旋转不会积累冲角动量。',x=>x.unit('hero').facing===0&&x.unit('hero').actionsLeft===1,{actor:'hero',rule:'naval'}),turn(),moved(6,7,'沿船首连续航行两格','左键点击（6,7），连续接近红船两格。航行后船首应与最后一步方向一致。'),attacked(true),turn(),attacked(false),moved(5,8,'接舷后调整舰位','左键移动到（5,8）。接舷后的剩余行动仍可用于合法机动；航向与移动距离由引擎计算。')];
 default:throw Error('未知教学模块');
 }
}
export function displayBinding(value){return value.replaceAll('Key','').replaceAll('Digit','').replace('Space','空格').replace('Escape','Esc').replace('Comma',',').replace('Enter','Enter');}
