import * as T from '../vendor/three/three.module.js';

const cache=new Map();
const data=new Set(['grass','stone','wood']);
export function middleEarthTexture(name,channel='color'){
  if(typeof document==='undefined')return undefined;
  const key=name+'-'+channel;
  if(!cache.has(key)){
    const file=new URL('./assets/middle-earth/materials/'+key+'.jpg',import.meta.url).href;
    const texture=new T.TextureLoader().load(file);
    texture.name='middle-earth-'+key;
    texture.colorSpace=channel==='color'?T.SRGBColorSpace:T.NoColorSpace;
    texture.wrapS=texture.wrapT=T.RepeatWrapping;
    texture.anisotropy=4;
    cache.set(key,texture);
  }
  return cache.get(key);
}
export function surfaceMaps(name,{repeat=null}={}){
  const map=middleEarthTexture(name);
  if(!map)return {};
  const maps={map};
  if(data.has(name)){
    maps.normalMap=middleEarthTexture(name,'normal');
    maps.roughnessMap=middleEarthTexture(name,'rough');
    maps.normalScale=new T.Vector2(.36,.36);
  }
  if(repeat){
    // Shared source images; only this UV transform differs from the standard tile.
    for(const key of ['map','normalMap','roughnessMap'])if(maps[key]){
      const cloneKey=name+':'+key+':'+repeat.join(',');
      if(!cache.has(cloneKey)){
        const tex=maps[key].clone();tex.repeat.set(...repeat);tex.needsUpdate=true;cache.set(cloneKey,tex);
      }
      maps[key]=cache.get(cloneKey);
    }
  }
  return maps;
}
export function worldUv(geometry,period){
  const positions=geometry.attributes.position,uv=[];
  for(let i=0;i<positions.count;i++)uv.push(positions.getX(i)/period,positions.getZ(i)/period);
  geometry.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
}

// Construction parts share one world-scale texture per finish. A long wall,
// a tower and individual coping stones all retain the same masonry courses.
export function projectConstructionMaps(material,period){
  if(!material.map)return;
  const original=material.onBeforeCompile;
  const programKey=material.customProgramCacheKey();
  material.onBeforeCompile=shader=>{
    original?.(shader);
    shader.uniforms.constructionPeriod={value:period};
    shader.vertexShader='uniform float constructionPeriod;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <uv_vertex>',`#include <uv_vertex>
      vec4 constructionPoint=vec4(position,1.0);
      vec3 constructionNormal=normal;
      #ifdef USE_INSTANCING
        constructionPoint=instanceMatrix*constructionPoint;
        constructionNormal=mat3(instanceMatrix)*constructionNormal;
      #endif
      constructionPoint=modelMatrix*constructionPoint;
      constructionNormal=abs(normalize(mat3(modelMatrix)*constructionNormal));
      vec2 surfaceUv=constructionPoint.xz;
      if(constructionNormal.y<max(constructionNormal.x,constructionNormal.z)){
        surfaceUv=vec2(constructionNormal.x>constructionNormal.z?constructionPoint.z:constructionPoint.x,constructionPoint.y);
      }
      surfaceUv/=constructionPeriod;
      #ifdef USE_MAP
        vMapUv=surfaceUv;
      #endif
      #ifdef USE_NORMALMAP
        vNormalMapUv=surfaceUv;
      #endif
      #ifdef USE_ROUGHNESSMAP
        vRoughnessMapUv=surfaceUv;
      #endif
    `);
  };
  material.customProgramCacheKey=()=>programKey+'-construction-projection';
}
