import {meKind} from './middle-earth-data.mjs';
// Saved simulation data only: never sample renderer meshes or camera state.
export const RULES_VERSION = 22;
export const DEFAULT_ELEVATION_RULES = Object.freeze({ gain: 0.15, loss: 0.15, ceiling: 1.45, floor: 0.55 });
export function ruleConfig(config = DEFAULT_ELEVATION_RULES) {
  const result = { ...DEFAULT_ELEVATION_RULES, ...config };
  if (Object.keys(result).some(k => !Object.hasOwn(DEFAULT_ELEVATION_RULES,k)) ||
      Object.values(result).some(v => !Number.isFinite(v)) || result.gain < 0 || result.loss < 0 ||
      result.ceiling < 1 || result.ceiling > 3 || result.floor <= 0 || result.floor > 1)
    throw Error('高差规则参数无效');
  return result;
}
export const usesElevationRules = s => s.rulesVersion >= 11;
export function validateElevations(map) {
  if (map.elevations !== undefined && (!Array.isArray(map.elevations) || map.elevations.length !== map.cols * map.rows ||
      map.elevations.some(h => !Number.isFinite(h) || h < -100 || h > 100))) throw Error('地图逻辑高程无效');
}
export function groundElevation(map,c,r) {
  return map.elevations?.[r*map.cols+c] ?? ((map.terrain[r*map.cols+c] & 2) ? 1 : 0);
}
export function materializeElevations(map) {
  validateElevations(map);
  map.elevations = Array.from({length:map.cols*map.rows},(_,i)=>groundElevation(map,i%map.cols,Math.floor(i/map.cols)));
}
// A surviving wall is a logical platform, replacing the old independent +1 wall damage.
export function logicalElevation(map,c,r) {
  const wall = map.units.find(u=>u.kind==='fort'&&u.hp>0&&u.c===c&&u.r===r);
  return groundElevation(map,c,r)+(wall&&!wall.gate ? wall.level : 0);
}
export function elevationEffect(s,a,d) {
  const surface=u=>meKind(u.kind)?.air?groundElevation(s.map,u.c,u.r):logicalElevation(s.map,u.c,u.r);
  const from=surface(a),to=surface(d),delta=from-to;
  const config = ruleConfig(s.elevationRules);
  const multiplier = !usesElevationRules(s) ? 1 : delta>0 ? Math.min(config.ceiling,1+delta*config.gain) : Math.max(config.floor,1+delta*config.loss);
  return {from,to,delta,multiplier,label:delta>0?'高打低':delta<0?'低打高':'同高'};
}
export const elevationText = effect => `${effect.label}（逻辑高程 ${effect.from}→${effect.to}，伤害 ×${effect.multiplier.toFixed(2)}）`;

export const usesMountainMarchRules = s => s.rulesVersion >= 12;
