import {fortificationLayout,isSolidWall,usesFortificationLayout} from './fortification-layout.mjs';
import {isMorannon} from './middle-earth-data.mjs';
import {middleEarthTexture,worldUv} from './middle-earth-materials.mjs';
import {roadPaths} from './road-visual.mjs';
import {mountainSurfaceColor,usesMountainPalette} from './mountain-visual.mjs';
import {attachKnowledgeMist} from './knowledge-mist.mjs';
import {createContinuousSurface} from './continuous-landform.mjs';
// Visual geometry only. All connectivity comes from existing terrain bits.
import * as THREE from '../vendor/three/three.module.js';
import { hexCorners, offsetToWorld } from '../js/core/hex.js';
import { TERRAIN, index, neighbors, inBounds } from './engine.mjs';

import { bounds, contains } from './terrain-adjacency.mjs';
import {mountainReliefEnabled,ridgeRise} from './mountain-relief.mjs';

export const WATER_Y = -.42;
export const noise = (c, r, salt = 0) => {
  const n = Math.sin(c * 127.1 + r * 311.7 + salt * 74.7) * 43758.5453;
  return n - Math.floor(n);
};
const vertexKey = (x, z) => `${Math.round(x * 100)},${Math.round(z * 100)}`;

const detailMaterials = new Map();
function detailMaterial(water = false, remaster=false, ash=false, horizon=false) {
  const key=water+':'+remaster+':'+ash+':'+horizon;
  if(detailMaterials.has(key))return detailMaterials.get(key);
  const textures=remaster&&!water&&middleEarthTexture('grass')?{
    grass:middleEarthTexture('grass'),mud:middleEarthTexture('mud'),rock:middleEarthTexture('rock'),
    normalMap:middleEarthTexture('grass','normal'),roughnessMap:middleEarthTexture('grass','rough'),
  }:null;
  const common = { vertexColors: true, side: THREE.DoubleSide, transparent: water&&!remaster, opacity: water&&!remaster?.9:1, depthWrite: !water||remaster };
  // Opaque earth needs diffuse lighting only; reserve PBR for the small water layer.
  const material = water ? new THREE.MeshStandardMaterial({ ...common, roughness: .52, metalness: 0 }) : textures ? new THREE.MeshStandardMaterial({...common,roughness:.96,normalMap:textures.normalMap,roughnessMap:textures.roughnessMap,normalScale:new THREE.Vector2(.22,.22)}) : new THREE.MeshLambertMaterial(common);
  const clock = { value: 0 }, detail = { value: 1 };
  material.onBeforeCompile = shader => {
    shader.uniforms.terrainTime = clock; shader.uniforms.terrainDetail = detail;
    if(textures)for(const name of ['grass','mud','rock'])shader.uniforms['earth'+name]={value:textures[name]};
    shader.vertexShader = 'varying vec3 terrainWorld;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>',
      '#include <begin_vertex>\nterrainWorld = (modelMatrix * vec4(position, 1.0)).xyz;');
    shader.fragmentShader = `varying vec3 terrainWorld;
      uniform float terrainTime; uniform float terrainDetail;
      ${textures?'uniform sampler2D earthgrass, earthmud, earthrock;':''}
      float grain(vec2 p) { vec3 q=fract(vec3(p.xyx)*.1031);q+=dot(q,q.yzx+33.33);return fract((q.x+q.y)*q.z); }
      float field(vec2 p) { vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
        return mix(mix(grain(i),grain(i+vec2(1,0)),f.x),mix(grain(i+vec2(0,1)),grain(i+vec2(1)),f.x),f.y); }
    ` + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
      ${water ? `float ripple=sin(terrainWorld.x*1.3+terrainWorld.z*.7-terrainTime*.65)*sin(terrainWorld.z*2.1-terrainTime*.35);
      diffuseColor.rgb *= 1.0 + ripple*.045*terrainDetail;` : textures ? `
      vec2 p=terrainWorld.xz;
      float macro=field(p*.024)+.24*field(p*.078+vec2(7.6));
      float soil=smoothstep(.56,1.03,macro);
      vec3 grass=texture2D(earthgrass,p/18.0).rgb*vec3(.81,.87,.72);
      grass=mix(grass,texture2D(earthgrass,mat2(.85,.53,-.53,.85)*p/37.0).rgb*.74,.35);
      vec3 mud=texture2D(earthmud,p/14.0).rgb*vec3(1.02,.90,.76);
      float rock=smoothstep(.045,.36,1.0-abs(normalize(cross(dFdx(terrainWorld),dFdy(terrainWorld))).y));
      vec3 stone=texture2D(earthrock,vec2(p.x+p.y,terrainWorld.y+.13*p.y)/11.0).rgb;
      ${ash?`
      float dust=dot(texture2D(earthmud,p/20.0).rgb,vec3(.299,.587,.114));
      float grit=dot(stone,vec3(.299,.587,.114));
      vec3 land=mix(vec3(.39,.35,.32)*(.55+dust*1.8),vec3(.42,.41,.43)*(.48+grit*1.35),
        max(rock*.88,smoothstep(.38,.92,macro)*.63));
      diffuseColor.rgb=mix(diffuseColor.rgb,land,.64*terrainDetail);
      `:`
      vec3 land=mix(mix(grass,mud,soil*.83),stone,rock*.86);
      diffuseColor.rgb=mix(diffuseColor.rgb,land*(.80+.27*macro),.78*terrainDetail);
      `}
      ` : `float mottling=field(terrainWorld.xz*.17);
      float grit=field(terrainWorld.xz*3.0)-.5;
      float fade=1.0-smoothstep(.3,1.5,length(fwidth(terrainWorld.xz)));
      diffuseColor.rgb *= .92 + mottling*.16 + grit*.10*fade*terrainDetail;
      float shore=1.0-smoothstep(-.2,.16,terrainWorld.y+(mottling-.5)*.16);
      diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.30,.28,.18),shore*.3);`}
    `);
  };
  material.customProgramCacheKey = () => 'ancient-ground-'+key+':'+!!textures;
  material.userData.clock = clock; material.userData.detail = detail;
  material.userData.sharedTerrain = true;
  detailMaterials.set(key,material);
  return material;
}

export function historicalHorizonMaterials(){
  const ground=detailMaterial(false,false,false,true),water=detailMaterial(true,false,false,true);
  return {ground,water};
}

export function createSurface(m, height, tileBase, region = null) {
  if(m.autoElevation||m.victory?.layoutVersion>=2||mountainReliefEnabled()){const v=createContinuousSurface(m,height,tileBase,region,detailMaterial(false,!!m.victory?.army,isMorannon(m.scenarioId)),detailMaterial(true,!!m.victory?.army),mountainReliefEnabled());attachKnowledgeMist(v.surface,m);attachKnowledgeMist(v.grid,m,true);if(v.water)attachKnowledgeMist(v.water,m);return v;}
  const relief=mountainReliefEnabled(),area=bounds(m,region),build=relief?bounds(m,region,1):area,halo=bounds(m,region,relief?2:1);
  const group = new THREE.Group(), pos = [], colors = [], ids = [],normalIds=[], shared = new Map(), cells = [];
  const push = (x, y, z, color) => { const i=pos.length/3;pos.push(x,y,z);colors.push(color.r,color.g,color.b);return i; };
  const ground = (c,r) => m.terrain[index(m,c,r)] & (TERRAIN.RIVER|TERRAIN.SEA) ? -.95 : height(m,c,r);
  for(let r=halo.r0;r<halo.r1;r++)for(let c=halo.c0;c<halo.c1;c++) {
    const p=offsetToWorld(c,r), g=ground(c,r),h=Math.min(g,1.9),t=m.terrain[index(m,c,r)];
    for(const [x,z] of hexCorners(p.x,p.z)) { const k=vertexKey(x,z),a=shared.get(k)||[0,0,0,false,0]; a[4]+=g;a[0]+=h;a[1]++;if(t&TERRAIN.MOUNTAIN)a[2]++;if(t&(TERRAIN.ROAD|TERRAIN.RIVER|TERRAIN.SEA))a[3]=true;shared.set(k,a); }
  }
  const edgeHeight=(x,z,a)=>relief&&a[1]>=2&&a[2]===a[1]&&!a[3]?a[4]/a[1]+ridgeRise(x,z):a[0]/a[1];
  const gridPos=[], edgeSet=new Set(), waterPos=[], waterColors=[];
  for(let r=build.r0;r<build.r1;r++)for(let c=build.c0;c<build.c1;c++) {
    const draw=contains(region,c,r),p=offsetToWorld(c,r),t=m.terrain[index(m,c,r)],h=ground(c,r), corners=hexCorners(p.x,p.z),base=tileBase(t,c,r,m);
    // Roads are narrow ribbons over the same earth palette, instead of full yellow hexagons.
    const earth=t&TERRAIN.RIVER ? tileBase(TERRAIN.PLAIN,c,r,m).lerp(new THREE.Color(0x9f9474),.4) : t&TERRAIN.ROAD && !(t&(TERRAIN.RIVER|TERRAIN.SEA)) ? tileBase(t&~TERRAIN.ROAD,c,r,m) : base;
    const center=push(p.x,h,p.z,earth.clone().multiplyScalar(1.02)), ring=[], outer=[],shoulders=[];
    for(let i=0;i<6;i++) {
      const [x,z]=corners[i], a=shared.get(vertexKey(x,z)),y=edgeHeight(x,z,a);
      if(t&TERRAIN.MOUNTAIN) ring.push(push(p.x+(x-p.x)*.46,h,p.z+(z-p.z)*.46,earth.clone().multiplyScalar(.98+noise(c,r,i+20)*.05)));
      if(t&TERRAIN.MOUNTAIN){const raised=y>a[0]/a[1]+.01,sy=raised?y-.22:h+(y-h)*(.78-.46)/(1-.46);shoulders.push(push(p.x+(x-p.x)*.78,sy,p.z+(z-p.z)*.78,earth.clone()));}
      const rock=t&TERRAIN.MOUNTAIN ? earth.clone().lerp(new THREE.Color(0x8d8875),.35) : earth.clone();
      outer.push(push(x,y,z,rock.multiplyScalar(.91+noise(c,r,i+30)*.06)));
    }
    const faces=[];
    for(let i=0;i<6;i++) { const j=(i+1)%6;
      const midpoint=[(corners[i][0]+corners[j][0])/2,(corners[i][1]+corners[j][1])/2];
      const wet=!!(t&(TERRAIN.RIVER|TERRAIN.SEA));
      const connectedWater=wet && neighbors(c,r).some(n=>{
        if(!inBounds(m,n.c,n.r)||!(m.terrain[index(m,n.c,n.r)]&(TERRAIN.RIVER|TERRAIN.SEA)))return false;
        const q=offsetToWorld(n.c,n.r);return Math.hypot((p.x+q.x)/2-midpoint[0],(p.z+q.z)/2-midpoint[1])<.01;
      });
      // A shared low edge midpoint keeps a stream open even between high mountain banks.
      const mid=connectedWater?push(midpoint[0],-.95,midpoint[1],earth):null;
      const ai=shared.get(vertexKey(...corners[i])),aj=shared.get(vertexKey(...corners[j]));
      const hasRidge=ring.length&&relief&&(edgeHeight(...corners[i],ai)>ai[0]/ai[1]+.01||edgeHeight(...corners[j],aj)>aj[0]/aj[1]+.01);
      const floor=Math.min(ai[0]/ai[1],aj[0]/aj[1]);
      const portals=hasRidge?[.32,.68].map(t=>push(corners[i][0]+(corners[j][0]-corners[i][0])*t,floor,corners[i][1]+(corners[j][1]-corners[i][1])*t,earth)):null;
      // Broad shoulder caps remove the repeated needle silhouette while leaving the
      // old center-to-center walking corridor open. Only static mountain edges add faces.
      const caps=portals?[.12,.88].map((t,k)=>{const v=k?outer[j]:outer[i];return push(corners[i][0]+(corners[j][0]-corners[i][0])*t,pos[v*3+1]-.12,corners[i][1]+(corners[j][1]-corners[i][1])*t,earth);}):null;
      const triangles=portals?[[center,ring[j],ring[i]],[ring[i],ring[j],portals[0]],[ring[j],portals[1],portals[0]],[ring[i],portals[0],caps[0]],[ring[i],caps[0],shoulders[i]],[shoulders[i],caps[0],outer[i]],[shoulders[j],outer[j],caps[1]],[ring[j],shoulders[j],caps[1]],[ring[j],caps[1],portals[1]]]:ring.length ? (mid===null?[[center,ring[j],ring[i]],[ring[i],ring[j],outer[i]],[ring[j],outer[j],outer[i]]]:[[center,ring[j],ring[i]],[ring[i],ring[j],mid],[ring[i],mid,outer[i]],[ring[j],outer[j],mid]]) :
        mid===null?[[center,outer[j],outer[i]]]:[[center,outer[j],mid],[center,mid,outer[i]]];
      for(const f of triangles) {normalIds.push(...f);if(draw)ids.push(...f); faces.push(f);}
      const a=corners[i],b=corners[j],ka=vertexKey(...a),kb=vertexKey(...b),k=[ka,kb].sort().join(':');
      if(draw&&!edgeSet.has(k)) {
        edgeSet.add(k);
        const portalPoints=hasRidge?[a,[a[0]+(b[0]-a[0])*.12,a[1]+(b[1]-a[1])*.12],[a[0]+(b[0]-a[0])*.12,a[1]+(b[1]-a[1])*.12],[a[0]+(b[0]-a[0])*.32,a[1]+(b[1]-a[1])*.32],[a[0]+(b[0]-a[0])*.32,a[1]+(b[1]-a[1])*.32],[a[0]+(b[0]-a[0])*.68,a[1]+(b[1]-a[1])*.68],[a[0]+(b[0]-a[0])*.68,a[1]+(b[1]-a[1])*.68],[a[0]+(b[0]-a[0])*.88,a[1]+(b[1]-a[1])*.88],[a[0]+(b[0]-a[0])*.88,a[1]+(b[1]-a[1])*.88],b]:null;
        const points=connectedWater?[a,midpoint,midpoint,b]:portalPoints||[a,b];
        for(const [x,z] of points) {
          const acc=shared.get(vertexKey(x,z));
          const frac=Math.hypot(x-a[0],z-a[1])/Math.hypot(b[0]-a[0],b[1]-a[1]);
          const y=acc?edgeHeight(x,z,acc):hasRidge?(Math.abs(frac-.12)<.001?pos[caps[0]*3+1]:Math.abs(frac-.88)<.001?pos[caps[1]*3+1]:floor):-.95;
          gridPos.push(x,Math.max(y,wet?WATER_Y:-Infinity)+.055,z);
        }
      }
    }
    cells[index(m,c,r)]=faces;
    if(draw&&t&(TERRAIN.RIVER|TERRAIN.SEA)) {
      for(let i=0;i<6;i++) {
        const j=(i+1)%6;
        for(const [x,z] of [[p.x,p.z],corners[j],corners[i]]) {waterPos.push(x,WATER_Y,z);const col=new THREE.Color(t&TERRAIN.ROAD?0x669389:t&TERRAIN.SEA?0x315e70:0x426f76);waterColors.push(col.r,col.g,col.b);}
      }
    }
  }
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.setIndex(normalIds);geo.computeVertexNormals();
  // Smooth duplicated corner/portal vertices across cells. A one-cell geometry halo
  // gives both chunks the same neighboring faces at their shared border.
  if(relief){const sums=new Map(),normal=geo.attributes.normal;for(let i=0;i<pos.length/3;i++){const k=vertexKey(pos[i*3],pos[i*3+2])+','+Math.round(pos[i*3+1]*1000),v=sums.get(k)||new THREE.Vector3();v.add(new THREE.Vector3(normal.getX(i),normal.getY(i),normal.getZ(i)));sums.set(k,v);}for(let i=0;i<pos.length/3;i++){const v=sums.get(vertexKey(pos[i*3],pos[i*3+2])+','+Math.round(pos[i*3+1]*1000)).normalize();normal.setXYZ(i,v.x,v.y,v.z);}}
  geo.setIndex(ids);
  const surface=new THREE.Mesh(geo,detailMaterial());surface.name='ancient-terrain';surface.receiveShadow=true;surface.castShadow=true;group.add(surface);
  const grid=new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute(gridPos,3)),
    new THREE.LineBasicMaterial({color:0x263b2f,transparent:true,opacity:.23,depthWrite:false}));grid.name='hex-grid';grid.renderOrder=2;group.add(grid);
  let water=null;
  if(waterPos.length) {const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(waterPos,3));g.setAttribute('color',new THREE.Float32BufferAttribute(waterColors,3));g.computeVertexNormals();
    water=new THREE.Mesh(g,detailMaterial(true));water.name='continuous-water';water.renderOrder=1;group.add(water);}
  // Sample the actual triangles for roads and props; do not raycast thousands of times at build time.
  const point=new THREE.Vector3(),a=new THREE.Vector3(),b=new THREE.Vector3(),d=new THREE.Vector3(),bary=new THREE.Vector3();
  function sample(c,r,x,z) {
    point.set(x,0,z);
    for(const f of cells[index(m,c,r)]||[]) {
      a.set(pos[f[0]*3],0,pos[f[0]*3+2]);b.set(pos[f[1]*3],0,pos[f[1]*3+2]);d.set(pos[f[2]*3],0,pos[f[2]*3+2]);
      THREE.Triangle.getBarycoord(point,a,b,d,bary);
      if(Math.min(bary.x,bary.y,bary.z)>=-1e-5)return pos[f[0]*3+1]*bary.x+pos[f[1]*3+1]*bary.y+pos[f[2]*3+1]*bary.z;
    }
    return height(m,c,r);
  }
  return {group,surface,grid,water,sample};
}

export function createRoads(m,sample,region=null){
 const works=usesFortificationLayout(m)?fortificationLayout(m):null;
 const remaster=!!m.victory?.army,area=bounds(m,region),p=[],colors=[],indices=[],opacity=[],dirt=new THREE.Color(0xaf9b76),edge=new THREE.Color(0x8c8b60),tone=new THREE.Color();
 function vertex(x,z,c,r,width){const h=sample(c,r,x,z),id=p.length/3;p.push(x,h+.06,z);opacity.push(Math.abs(width)>2?0:1);if(Math.abs(width)>2&&usesMountainPalette(m))mountainSurfaceColor(tone,Math.max(0,h/4.6),0,1,0);else tone.copy(Math.abs(width)>2?edge:dirt);colors.push(tone.r,tone.g,tone.b);return id;}
 for(let r=area.r0;r<area.r1;r++)for(let c=area.c0;c<area.c1;c++){
 const t=m.terrain[index(m,c,r)],plan=works?.at(c,r);
 if(!(t&TERRAIN.ROAD)||t&(TERRAIN.RIVER|TERRAIN.SEA)||isSolidWall(plan?.fort))continue;
 const roadConnects=p=>{
   const next=works?.at(p.c,p.r)?.fort;
   return !isSolidWall(next)&&(!(next?.gate&&next.hp>0)||works.gateConnects(next,{c,r}));
 };
 let paths=roadPaths(m,c,r,roadConnects),center=offsetToWorld(c,r);
 const width=m.victory?.layoutVersion>=2?.74:1;
 if(plan?.fort.hp>0&&plan.fort.gate&&plan.openings.size){
   const logical=center;
   center=plan.p;
   paths=[...plan.openings].map(key=>{
     const [rr,cc]=key.split(':').map(Number),p=offsetToWorld(cc,rr);
     const dx=(p.x+logical.x)/2-center.x,dz=(p.z+logical.z)/2-center.z;
     return {steps:3,point:t=>({x:center.x+dx*t,z:center.z+dz*t,dx,dz})};
   });
 }
 if(paths.length!==1||paths[0].steps===3){const corners=hexCorners(center.x,center.z,1.65*width),ci=vertex(center.x,center.z,c,r,0);for(let j=0;j<6;j++)indices.push(ci,vertex(...corners[(j+1)%6],c,r,0),vertex(...corners[j],c,r,0));}
 for(const path of paths){const rows=[];for(let j=0;j<=path.steps;j++){const q=path.point(j/path.steps),length=Math.hypot(q.dx,q.dz)||1;rows.push([-2.1,-1.5,1.5,2.1].map(w=>vertex(q.x-q.dz/length*w*width,q.z+q.dx/length*w*width,c,r,w)));}for(let j=0;j<path.steps;j++)for(let k=0;k<3;k++){const a=rows[j],b=rows[j+1];indices.push(a[k],a[k+1],b[k],a[k+1],b[k+1],b[k]);}}
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(p,3));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.setIndex(indices);geometry.computeVertexNormals();const mud=remaster&&middleEarthTexture('mud');
 let material=detailMaterial();
 if(mud){
   worldUv(geometry,12);geometry.setAttribute('roadOpacity',new THREE.Float32BufferAttribute(opacity,1));
   material=new THREE.MeshLambertMaterial({map:mud,color:0xbeb2a3,transparent:true,depthWrite:false,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1});
   material.onBeforeCompile=shader=>{
     shader.vertexShader='attribute float roadOpacity; varying float blendRoad;\n'+shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nblendRoad=roadOpacity;');
     shader.fragmentShader='varying float blendRoad;\n'+shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\ndiffuseColor.rgb *= 1.38; diffuseColor.a *= blendRoad*.82;');
   };
 }
 const mesh=new THREE.Mesh(geometry,material);mesh.name='connected-roads';mesh.receiveShadow=true;return mesh;
}
