// Deterministic local tactics; inputs are ALWAYS the faction's observation map.
import * as E from './engine.mjs';
import {planningState} from './fog-policy.mjs';
import {formationFront} from './phalanx-geometry.mjs';
const live=u=>u.hp>0&&!u.aboard&&!u.uncontrolled&&!E.isRouted(u);
const adjacent=(a,b)=>E.distance(a,b)===1;
export function formationFacingPlan(s,u,foes){
 const allies=s.map.units.filter(a=>a.id!==u.id&&a.team===u.team&&live(a)&&E.isFormableInfantry(a)&&a.formed&&adjacent(a,u));
 const threats=foes.filter(e=>live(e)&&e.team!==u.team&&!E.isShip(e)&&e.kind!=='fort'&&E.distance(e,u)<=4);
 const score=f=>threats.reduce((n,e)=>{const d=E.distance(u,e),covered=allies.some(a=>formationFront(a,e)&&E.distance(a,e)<=d);return n+(formationFront({...u,facing:f},e)?1:-1)*(5/(d*d))*(covered?.55:1);},0);
 const choices=Array.from({length:12},(_,i)=>({facing:i/2,score:score(i/2)})).sort((a,b)=>b.score-a.score||Number(b.facing===u.facing)-Number(a.facing===u.facing)||a.facing-b.facing);
 return {facing:choices[0].facing,score:choices[0].score,current:score(u.facing??0),threats};
}
export function phalanxTacticalAction(state,actor){
 const s=planningState(state,actor.team),u=s.map.units.find(x=>x.id===actor.id);
 if(s.rulesVersion<22||!u||!live(u)||u.actionsLeft<1||s.side!==u.team||s.over||s.deploying)return null;
 const enemies=s.map.units.filter(e=>e.team!==u.team&&live(e)&&e.kind!=='fort'&&!E.isShip(e));
 if(!enemies.length)return null;
 const distance=p=>Math.min(...enemies.map(e=>E.distance(p,e)));
 if(E.isFormableInfantry(u)){
  const plan=formationFacingPlan(s,u,enemies);
  if(u.formed&&plan.threats.length&&plan.score>plan.current+.01&&plan.facing!==u.facing)return {type:'turn',facing:plan.facing,reason:'转向可见威胁，分担友军已覆盖方向'};
  const allies=s.map.units.filter(a=>a.id!==u.id&&a.team===u.team&&live(a)&&E.isFormableInfantry(a)&&a.formed);
  const support=p=>allies.filter(a=>adjacent(p,a)).length,current=support(u);
  if(distance(u)>1&&u.actionsLeft>=(u.formed?1:2)&&current<2){
   const gaps=[...E.reachable(s,u).values()].filter(p=>support(p)>=2&&support(p)>current&&distance(p)<=4&&distance(p)<=distance(u)+1&&p.actionCost<u.actionsLeft);
   gaps.sort((a,b)=>support(b)-support(a)||distance(a)-distance(b)||a.cost-b.cost||a.c-b.c||a.r-b.r);
   if(gaps[0])return {type:'move',to:gaps[0],reason:'填补相邻阵线缺口'};
  }
  if(!u.formed&&distance(u)<=3){const trial=structuredClone(s);if(E.setPhalanxMode(trial,u.id,true,plan.facing).ok)return {type:'form',facing:plan.facing,reason:'朝可见敌军列阵'};}
  if(u.formed&&distance(u)>=5&&!current)return {type:'unform',reason:'孤立远离接敌区，恢复行军队形'};
 }
 // Prefer a paid reachable rear strike to a weaker frontal strike. No hidden occupancies are inspected.
 if(E.meleePower(u,s.map)>0&&u.actionsLeft>=2){
  const targets=enemies.filter(e=>E.isFormableInfantry(e)&&e.formed&&E.distance(u,e)<=5),choices=[];
  for(const p of targets.length?E.reachable(s,u).values():[]){if(p.actionCost>=u.actionsLeft)continue;const moved={...u,c:p.c,r:p.r,actionsLeft:u.actionsLeft-p.actionCost},trial={...s,fogPolicy:null,map:{...s.map,units:s.map.units.map(v=>v.id===u.id?moved:v)}};
   for(const e of targets){if(!adjacent(p,e)||formationFront(e,p))continue;const preview=E.attackPreview(trial,moved,e.c,e.r),now=E.attackPreview(s,u,e.c,e.r);if(preview&&(!now||preview.damage>now.damage))choices.push({to:p,gain:preview.damage-(now?.damage||0),target:e.id});}
  }
  choices.sort((a,b)=>b.gain-a.gain||a.to.cost-b.to.cost||a.target.localeCompare(b.target));if(choices[0])return {type:'move',to:choices[0].to,reason:'合法绕向已发现方阵背面'};
 }
 return null;
}
