import test from 'node:test';
import assert from 'node:assert/strict';
import {makeImperialMap} from './imperial-campaigns.mjs';
import {attack,attackPreview,recomputeFog,setUnitStats,startGame,reachable,mobileAt,unitMaxHp,exportMap,importMap,endSide} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
function setup(kind='heavy'){
 const s=startGame(makeImperialMap('china_longxi'));
 const wagon=s.map.units.find(u=>u.team==='coalition'&&u.kind==='supplyWagon'&&u.c===53);
 const attacker=s.map.units.find(u=>u.team==='egypt'&&u.kind===kind);
 attacker.c=wagon.c-1;attacker.r=wagon.r-(kind==='chinaCrossbow'?1:0);
 setUnitStats(s.map,kind,{melee:30,ranged:30});wagon.hp=1;wagon.supplyStock=17;recomputeFog(s);
 return {s,wagon,attacker};
}
for(const kind of ['heavy','chinaCrossbow'])test(`${kind}: repeated takeovers reduce 9 to 5 to 1 to 0, with no resurrection`,()=>{
 const {s,wagon,attacker}=setup(kind);
 for(const hp of [50,10,0]){
  const former=wagon.team;s.side=former==='egypt'?'coalition':'egypt';attacker.team=s.side;attacker.actionsLeft=2;attacker.attacksUsed=0;attacker.ammo=999;recomputeFog(s);
  const result=attack(s,attacker.id,wagon.c,wagon.r,0);
  assert.ok(result.ok&&result.hit);assert.equal(wagon.hp,hp);assert.equal(result.capturedWagon,hp>0);assert.equal(result.visual.killed,hp===0);
  assert.equal(unitMaxHp(s.map,wagon),hp);assert.equal(wagon.supplyStock,17);assert.equal(wagon.actionsLeft,0);
  if(hp>0)assert.equal(wagon.team,attacker.team);
 }
 assert.equal(mobileAt(s.map,wagon.c,wagon.r),null);assert.equal(reachable(s,wagon).size,0);
 assert.equal(attack(s,attacker.id,wagon.c,wagon.r,0).ok,false);
});
test('capture wear is permanent, bounded at zero, and survives map export',()=>{
 const {s,wagon,attacker}=setup();attack(s,attacker.id,wagon.c,wagon.r,0);
 assert.equal(wagon.wagonCaptureLoss,40);assert.equal(unitMaxHp(s.map,wagon),50);
 const map=importMap(exportMap(s.map)),copy=map.units.find(u=>u.c===wagon.c&&u.r===wagon.r&&u.kind==='supplyWagon');
 assert.equal(copy.wagonCaptureLoss,40);assert.equal(unitMaxHp(map,copy),50);
 wagon.hp=40;wagon.actionsLeft=2;s.side='egypt';endSide(s);endSide(s);assert.equal(wagon.hp,50);assert.equal(wagon.wagonCaptureLoss,40);
});
test('a nonlethal hit or miss does not change ownership or apply takeover loss',()=>{
 const {s,wagon,attacker}=setup();wagon.hp=90;setUnitStats(s.map,attacker.kind,{melee:1});const before=wagon.hp,preview=attackPreview(s,attacker,wagon.c,wagon.r);
 assert.ok(preview.damage<before);const result=attack(s,attacker.id,wagon.c,wagon.r,0);assert.equal(wagon.hp,before-preview.damage);assert.equal(wagon.team,'coalition');assert.equal(result.capturedWagon,false);
 attacker.actionsLeft=2;const wounded=wagon.hp;attack(s,attacker.id,wagon.c,wagon.r,1);assert.equal(wagon.hp,wounded);assert.equal(wagon.team,'coalition');
});
test('save and restore preserve reduced wagon HP and the next takeover continues from it',()=>{
 const {s,wagon,attacker}=setup();attack(s,attacker.id,wagon.c,wagon.r,0);assert.equal(wagon.hp,50);
 const restored=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,'egypt')))).game;
 const v=restored.map.units.find(u=>u.id===wagon.id),a=restored.map.units.find(u=>u.id===attacker.id);
 assert.equal(v.hp,50);restored.side='coalition';a.team='coalition';a.actionsLeft=2;recomputeFog(restored);assert.ok(attack(restored,a.id,v.c,v.r,0).capturedWagon);assert.equal(v.hp,10);
});

test('invalid cumulative capture loss is rejected in map and battle saves',()=>{
 const {s,wagon}=setup();
 for(const loss of [-1,.5,999]){
  const saved=JSON.parse(JSON.stringify(createSave(s.map,s,'egypt')));
  saved.game.map.units.find(u=>u.id===wagon.id).wagonCaptureLoss=loss;
  assert.throws(()=>restoreSave(saved),/粮车争夺损耗/);
  const map=exportMap(s.map);map.units.find(u=>u.kind==='supplyWagon'&&u.c===wagon.c&&u.r===wagon.r).wagonCaptureLoss=loss;
  assert.throws(()=>importMap(map),/粮车争夺损耗/);
 }
});
