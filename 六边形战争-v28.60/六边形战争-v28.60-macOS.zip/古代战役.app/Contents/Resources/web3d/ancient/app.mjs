import {fortificationLayout,isSolidWall,usesFortificationLayout} from './fortification-layout.mjs';
import {createArmyFormationRenderer,isArmyFormation} from './army-formation-render.mjs';
import {groundCell,groundConnection,knownGroundEdge,hasCliffNavigation} from './cliff-navigation.mjs';
import {MIDDLE_EARTH,ME_IDS,isMorannon,morannonWindows,morannonCell,projectMiddleEarthCell} from './middle-earth-data.mjs';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {meAir,meZone,meUnitActive,meRoll,sealCulvert,siegeObjective,siegeContact,setStealth,blastOnlyWall,hornburgBlastRadius} from './middle-earth-rules.mjs';
import {DAWN_IDS} from './dawn-data.mjs';
import {makeDawnMap} from './dawn-maps.mjs';
import {growthLevel, GROWTH, PROMOTION_COSTS, controlledBy, hostile} from './unit-growth.mjs';
import {setVeteranLevel} from './engine.mjs';
import {syncUniformColors} from './uniform-colors.mjs';
import {factionColor,setFactionColors,DEFAULT_COLORS} from './faction-colors.mjs';
import {syncFactionMaterials} from './models.mjs';
import {bindLogisticsUI} from './logistics-ui.mjs';
import {presentationMap,isOmniscientObserver} from './battle-view.mjs';
import {assignCore,editorDefenseSites,editorFacilityPoints} from './editor-core-points.mjs';
let editorCoreSite=null;
import {coreMarkers} from './core-markers.mjs';
import {upgradeGates} from './gate-upgrade.mjs';
import {setGate} from './engine.mjs';
import {bindTileDetails} from './tile-details.mjs';
let tileDetails=null;
import {bindBattleLayout} from './battle-layout.mjs';
import {editLogisticsPoint} from './editor-facilities.mjs';
import {createPhalanxMeshes,appendFormationStatus,bindBatchPhalanxUI} from './phalanx-ui.mjs';
import {bindUnitEncyclopedia} from './unit-encyclopedia.mjs';
import {createTutorialMap} from './tutorial-content.mjs';
import {bindTutorialSystem} from './tutorial-system.mjs';
import {bindRulesManual} from './rules-manual.mjs';
let tutorialSystem=null,ruleManual=null;
import {ramText} from './naval-ram.mjs';
import {bindNavigation} from './navigation.mjs';
let navigationPaused=true, navigationLoaded=false, tutorialHP=0,tutorialArrows=0;
import {bindDirectionClock,facingName,facingYaw} from './directions12.mjs';
import {bindBattleInteraction} from './battle-interaction-ui.mjs';
import {bindInputSettings} from './input-map.mjs';
import {createCellOutline} from './hex-overlay.mjs';
import {appendCaptureControls} from './fortification-capture-ui.mjs';
import {bindBattleEndingUI} from './battle-ending-ui.mjs';
import {chargeUnitCopy,normalizeChargeCopy,updateChargeHelp} from './charge-copy.mjs';
import {chargeClass,chargeText} from './charge-rules.mjs';
import {knownMap,terrainKnown,planningState,STANDARD_FOG_POLICY,changeFogPolicy} from './fog-policy.mjs';
import {ensureAutoElevation} from './auto-elevation.mjs';
import {createTerrainHistory} from './terrain-history.mjs';
import {createTopographicMinimap} from './topographic-minimap.mjs';
import { logicalElevation, groundElevation, elevationText, usesElevationRules, usesMountainMarchRules } from './elevation-rules.mjs';
import { moveCost } from './engine.mjs';
import {visualProfile} from './visual-profiles.mjs';
import {setVegetation} from './terrain-vegetation.mjs';
import {createCasualtyLayer} from './casualty-layer.mjs';
import {setMountainRelief} from './mountain-relief.mjs';
import {createUnitHUD,symbolLegend} from './unit-hud.mjs';
import {bindOrderOfficer,bindBattleSettings} from './order-officer.mjs';
import {HELLENISTIC_IDS} from './hellenistic-data.mjs';
import {makeHellenisticMap} from './hellenistic-maps.mjs';
import {TACTICAL_IDS as CLASSICAL_IDS, tacticalInfo as classicalInfo, tacticalKinds as classicalKinds} from './classical-data.mjs';
import {makeClassicalMap} from './classical-maps.mjs';
import {classicalBrief} from './classical-rules.mjs';
import {classicalHelp} from './classical-ui.mjs';
import { createSoldierCamera, bindSoldierCamera, canFollowSoldier } from './soldier-camera.mjs';
import { createTerrainRefresh } from './terrain-refresh.mjs';
import { selectable, toggleSelection, rectangleSelection, gestureMode, executeArmyOrder } from './group-command.mjs';
import * as THREE from '../vendor/three/three.module.js';
import { offsetToWorld, worldToOffset } from '../js/core/hex.js';
import { createUnitModel, UNIT_SCENE_SCALE } from './unit-presentation.mjs';
import { createAncientTerrain, terrainHeight } from './terrain.mjs';
import { createTerrainForts, wallHeight, fortStandingHeight } from './terrain-forts.mjs';
import { createTerrainEnvironment } from './terrain-environment.mjs';
import { createWeaponEffects } from './weapon-effects.mjs';
import { createUnitAnimator } from './unit-animation.mjs';
const unitAnimator = createUnitAnimator();
import { BATTLE_MODES, createSave, restoreSave } from './save.mjs';
import { CHINA_CAMPAIGN_IDS, makeChinaMap } from './china-campaigns.mjs';
import { IMPERIAL_CAMPAIGN_IDS, makeImperialMap } from './imperial-campaigns.mjs';
import { isChinaIronAgeScenario } from './china-era.mjs';
import { mantineaMap, aegospotamiMap } from './greek-campaigns.mjs';
import { CAMPAIGN_CATALOG, CAMPAIGN_IDS, campaignTitle } from './campaign-catalog.mjs';
import { TERRAIN, STATS, EDITABLE_UNIT_STATS, KUNYANG_METEORS, KUNYANG_CITY_OBJECTIVE, armyRoutFraction, isChinaEliminationCampaign, hasChinaCaptureObjective, chinaHoldTurnLimit, unitStats, setUnitStats, movementAllowance, FORT_HP, FORT_ARMOR, WIND_NAMES, fmt, meleePower, meleeHitChance, rangedPower, unitMaxHp, unitArmor, unitName, moraleOf, usesMorale, isRouted, canPlaceKind, isShip, isTrireme, isPhalangite, isRomanLine, isFormableInfantry, crossbowAttackLimit, cargoOf, cargoLoad, embark, disembark, recruit, neighbors, distance, index, inBounds, tile, setTerrain, setFort, setSupplyPoint, addUnit,
  fortAt, fortificationStep, mobileAt, key, inDeployment, deployUnit, beginBattle, visibleTo, newMap, exportMap, importMap, bridgeAt, isFord, setBridge, destroyBridge, canDestroyBridge,
  canAffordRecruitment, recruitmentCost, recruitmentWait, carriedRationCapacity, logisticsRouteCut, recruitLogistics, replenishConvoy,
  houseAt, setHouse, megiddoMap, kadeshMap, troyMap, qarqarMap, babylonMap, salamisMap, gaugamelaMap, issusMap, tyreMap, cannaeMap, zamaMap, carthageMap, alesiaMap, pharsalusMap, actiumMap, teutoburgMap, jerusalemMap, carrhaeMap, syracuseMap, pydnaMap, alesiaWorkOptions, buildAlesiaWork, carthageSeaSecured, ensureMoraleGuards, startGame, startTroyTurn65, knownTo, knownUnitAt, reachable, attackArea, attackPreview, move as ruleMove, moleLanes, nextMoleCells, buildMole, turnShip, turnRomanLine, withdrawCenter, setPhalanxMode, turnPhalanx, attack as ruleAttack, endSide, aiTurn } from './engine.mjs';

function move(state, id, c, r) {
  const u = state.map.units.find(x => x.id === id), from = u ? {c:u.c,r:u.r} : null;
  const result = ruleMove(state,id,c,r);
  tutorialSystem?.record('move',{id,c,r,ok:result.ok});
  if(result.ok)orderOfficer?.delegates.cancelUnits([id]);
  if (result.ok && from) unitAnimator.move(id,from,result.path,performance.now());
  return result;
}
function attack(state,id,c,r,...rolls){
 const result=ruleAttack(state,id,c,r,...(tutorialSystem?.active?[.05,.5,.5,.5]:rolls));
 tutorialSystem?.record('attack',{id,c,r,ok:result.ok,hit:result.hit,ram:!!result.visual?.ram});
 return result;
}
const $ = id => document.getElementById(id);
for (const campaign of [...CAMPAIGN_CATALOG,...MIDDLE_EARTH]) {
  const option = document.createElement('option');
  option.value = campaign.id;
  option.textContent = campaign.title;
  $('scenario-select').append(option);
}
const CANNAE_KINDS = new Set(['romanVelites', 'romanHastati', 'romanPrincipes', 'romanTriarii',
  'romanHorse', 'romanAlliedHorse', 'gaulInfantry', 'iberianInfantry', 'africanInfantry',
  'punicSkirmisher', 'punicHeavyHorse', 'numidianHorse', 'hannibal', 'paullus', 'varro']);
const ZAMA_KINDS = new Set(['romanVelites', 'romanHastati', 'romanPrincipes', 'romanTriarii',
  'romanHorse', 'masinissaHorse', 'scipio', 'masinissa', 'warElephant', 'gaulInfantry',
  'iberianInfantry', 'africanInfantry', 'zamaVeteran', 'numidianHorse', 'zamaPunicHorse', 'hannibal']);
const CARTHAGE_KINDS = new Set(['romanVelites', 'romanLegion',
  'scipio', 'siegeRam', 'romanOnager', 'romanArcher', 'engineer', 'siegeGalley', 'alliedTrireme', 'transport',
  'africanInfantry', 'iberianInfantry', 'punicSkirmisher', 'hannibal', 'phoenicianTrireme', 'defenseTower']);
const ALESIA_KINDS = new Set(['scipio', 'engineer', 'romanLegion', 'romanVelites', 'romanArcher',
  'romanHorse', 'romanAlliedHorse', 'hannibal', 'gaulInfantry', 'archer', 'cavalry']);
const PHARSALUS_KINDS = new Set(['scipio', 'romanLegion', 'caesarReserve', 'romanVelites',
  'romanHorse', 'hannibal', 'pompeyLegion', 'pompeyHorse', 'punicSkirmisher']);
const ACTIUM_KINDS = new Set(['octavianLiburnian', 'antonyHeavyGalley', 'cleopatraGalley']);
const TEUTOBURG_KINDS = new Set(['scipio', 'romanLegion', 'romanVelites', 'romanHorse',
  'hannibal', 'gaulInfantry', 'punicSkirmisher']);
const JERUSALEM_KINDS = new Set(['scipio', 'romanLegion', 'romanVelites', 'romanArcher',
  'romanOnager', 'siegeTower', 'siegeRam', 'engineer', 'hannibal', 'africanInfantry',
  'iberianInfantry', 'punicSkirmisher', 'archer']);
const CARRHAE_KINDS = new Set(['scipio','romanLegion','romanArcher','romanVelites','romanHorse',
  'hannibal','parthianHorseArcher','parthianCataphract','arrowCamel']);
const SYRACUSE_KINDS = new Set(['scipio','romanLegion','romanVelites','romanArcher','siegeGalley','romanOnager','siegeRam','hannibal','defenseTower','africanInfantry','iberianInfantry','archer','punicSkirmisher','phoenicianTrireme']);
const PYDNA_KINDS = new Set(['scipio','romanLegion','romanVelites','romanHorse','romanAlliedHorse','hannibal','phalangite','companionCavalry','archer','light']);
const CHINA_KINDS = new Set(['chinaGeneral', 'chinaCrossbow', 'chinaFireOx', 'chinaHeavyChariot', 'heavy', 'light',
  'archer', 'guard', 'cavalry', 'siegeRam', 'supplyWagon', 'moraleGuard']);
const MANTINEA_KINDS = new Set(['greekHoplite', 'guard', 'cavalry', 'archer', 'light']);
const AEGOSPOTAMI_KINDS = new Set(['athenianTrireme', 'phoenicianTrireme']);
const availableBrushes = new Set([...document.querySelectorAll('[data-brush]')].map(button => button.dataset.brush));
const unitBrushRow = $('unit-team').parentElement;
for (const [kind, stats] of Object.entries(STATS)) {
  if (kind === 'fort' || availableBrushes.has(kind)) continue;
  const button = document.createElement('button');
  button.dataset.brush = kind;
  button.textContent = stats.name;
  unitBrushRow.append(button);
}
const canvas = $('scene'), stage = $('stage');
const unitHUD=createUnitHUD($('unit-status'));
let orderOfficer=null,battleInteraction=null;
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
renderer.setClearColor(0x05070a);
const scene = new THREE.Scene();
let terrainObj;
const meteorGroup = new THREE.Group(); scene.add(meteorGroup);
scene.background = new THREE.Color(0x05070a);
scene.fog = new THREE.Fog(0x05070a, 260, 700);
const terrainEnvironment = createTerrainEnvironment(scene, renderer);

let terrainQuality = 'standard', animationQuality = 'standard';
let showHexGrid = true,showCasualties=true;
try {
  terrainQuality = localStorage.getItem('ancient-terrain-quality') === 'low' ? 'low' : 'standard';
  showHexGrid = localStorage.getItem('ancient-hex-grid') !== 'off';
  animationQuality=localStorage.getItem('ancient-animation-quality')==='low'?'low':'standard';
} catch {}
try{showCasualties=localStorage.getItem('ancient-casualties')!=='off';setVegetation(localStorage.getItem('ancient-vegetation')!=='off');}catch{}
try{setMountainRelief(localStorage.getItem('ancient-mountain-relief')!=='off');}catch{}
terrainEnvironment.setQuality(terrainQuality);
const casualtyLayer=createCasualtyLayer({renderer,scene,createModel:(u,m)=>{const model=createUnitModel(u,m.scenarioId,{map:m,casualty:true,withoutBase:true});model.scale.setScalar(UNIT_SCENE_SCALE);return model;},heightOf:unitY});
const perspectiveCamera = new THREE.PerspectiveCamera(45, 1, 0.8, 2200);
const boardCamera = new THREE.OrthographicCamera(-100,100,100,-100,.8,2200);
let camera=perspectiveCamera,boardView=false,cameraYaw=0,cameraPitch=Math.atan2(.68,.73);
let beforePanorama=null,shownBreach=null,breachFlash=null;
const inputMapping=bindInputSettings(document,localStorage);
const params = new URLSearchParams(location.search);
const chosenScenario = CAMPAIGN_IDS.has(params.get('scenario')) || ME_IDS.has(params.get('scenario')) || /^custom_[a-z0-9]+$/.test(params.get('scenario') || '') ? params.get('scenario') : 'megiddo';
const troyTrial = chosenScenario === 'troy' && params.get('trial') === 'troy65';
let playerTeam = troyTrial ? 'egypt' : params.get('side') === 'coalition' ? 'coalition' : 'egypt';
let preferredHumanTeam = playerTeam;
let aiDifficulty = ['easy', 'normal', 'hard'].includes(params.get('ai')) ? params.get('ai') : 'normal';
let battleMode = BATTLE_MODES.includes(params.get('mode')) ? params.get('mode') : 'human-ai';
const makeScenario = id => {
  if(ME_IDS.has(id))return makeMiddleEarthMap(id);
  const m = DAWN_IDS.has(id) ? makeDawnMap(id) : HELLENISTIC_IDS.has(id) ? makeHellenisticMap(id) : CLASSICAL_IDS.has(id) ? makeClassicalMap(id) : CHINA_CAMPAIGN_IDS.has(id) ? makeChinaMap(id) : IMPERIAL_CAMPAIGN_IDS.has(id) ? makeImperialMap(id) : id === 'kadesh' ? kadeshMap() : id === 'troy' ? troyMap() :
  id === 'qarqar' ? qarqarMap() : id === 'babylon' ? babylonMap() : id === 'salamis' ? salamisMap() :
    id === 'mantinea' ? mantineaMap() : id === 'aegospotami' ? aegospotamiMap() :
    id === 'gaugamela' ? gaugamelaMap() : id === 'issus' ? issusMap() : id === 'tyre' ? tyreMap() :
      id === 'cannae' ? cannaeMap() : id === 'zama' ? zamaMap() : id === 'carthage' ? carthageMap() : id === 'alesia' ? alesiaMap() : id === 'pharsalus' ? pharsalusMap() : id === 'actium' ? actiumMap() : id === 'teutoburg' ? teutoburgMap() : id === 'jerusalem' ? jerusalemMap() : id === 'carrhae' ? carrhaeMap() : id === 'syracuse' ? syracuseMap() : id === 'pydna' ? pydnaMap() : megiddoMap();
  m.name = campaignTitle(m.scenarioId, m.name);
  return m;
};
function middleEarthFocus(m){
  if(isMorannon(m.scenarioId))return Object.values(morannonCell(m.scenarioId.endsWith('final')?12:29,8,m));
  if(m.victory.layoutVersion===undefined)return [Math.floor(m.cols/2),Math.floor(m.rows/2)];
  const base={me_hornburg:[32,17],me_erebor:[24,17],me_pelennor:m.victory?.army?[14,25]:[21,25],me_pelargir:[30,17]}[m.scenarioId];
  if(!base)return Object.values(m.victory.points.ford);
  return Object.values(projectMiddleEarthCell(m,...base));
}
const scenarioFocus = (m, team = playerTeam) => ME_IDS.has(m.scenarioId) ? middleEarthFocus(m) : CLASSICAL_IDS.has(m.scenarioId) ? classicalInfo(m.scenarioId).focus : m.scenarioId === 'troy' ?
  team === 'egypt' ? [25, 18] : [43, 18] : m.scenarioId === 'kadesh' ?
  team === 'egypt' ? [38, 17] : [43, 19] :
  m.scenarioId === 'qarqar' ? team === 'egypt' ? [43, 19] : [29, 25] :
  m.scenarioId === 'babylon' ? team === 'egypt' ? [32, 35] : [65, 36] :
  m.scenarioId === 'salamis' ? team === 'egypt' ? [37, 28] : [43, 40] :
  m.scenarioId === 'mantinea' ? [36, 23] :
  m.scenarioId === 'aegospotami' ? [41, 23] :
  m.scenarioId === 'gaugamela' ? team === 'egypt' ? [42, 25] : [53, 25] :
  m.scenarioId === 'issus' ? team === 'egypt' ? [48, 28] : [43, 21] :
  m.scenarioId === 'tyre' ? [31, 19] :
  m.scenarioId === 'cannae' ? [39, 31] :
  m.scenarioId === 'zama' ? [46, 36] :
  m.scenarioId === 'carthage' ? team === 'egypt' ? [39, 26] : [51, 24] :
  m.scenarioId === 'alesia' ? [40, 26] :
  m.scenarioId === 'pharsalus' ? [43, 26] :
  m.scenarioId === 'actium' ? team === 'egypt' ? [36, 25] : [46, 25] :
  m.scenarioId === 'teutoburg' ? [39, 24] :
  m.scenarioId === 'jerusalem' ? team === 'egypt' ? [45, 24] : [48, 36] :
  m.scenarioId === 'carrhae' ? team === 'egypt' ? [26, 21] : [46, 21] :
  m.scenarioId === 'syracuse' ? team === 'egypt' ? [28, 25] : [44, 25] :
  m.scenarioId === 'pydna' ? [31, 22] :
  m.scenarioId === 'china_changping' ? [31, 26] :
  m.scenarioId === 'china_qin_chu' ? [37, 27] :
  m.scenarioId === 'china_eyu' ? [30, 20] :
  m.scenarioId === 'china_xiao' || m.scenarioId === 'china_tian_dan' ? [42, 22] :
  m.scenarioId === 'china_jin_partition' || m.scenarioId === 'china_handan' ? [38, 22] :
  m.scenarioId?.startsWith('custom_') ? [Math.floor(m.cols / 2), Math.floor(m.rows / 2)] :
  m.victory.mode === 'china' ? [28, 22] :
  team === 'egypt' && m.deployment ? [12, 35] : team === 'coalition' ? [58, 22] : [45, 33];
const initialScenario=makeScenario(chosenScenario);
const startCenter = offsetToWorld(...scenarioFocus(initialScenario));
const target = new THREE.Vector3(startCenter.x, 0, startCenter.z);
const initialCameraDistanceForScenario = id => ME_IDS.has(id)?({me_hornburg:212,me_erebor:248,me_pelennor:195,me_pelargir:191}[id]||158): CLASSICAL_IDS.has(id) ? classicalInfo(id).camera : id === 'kadesh' ? 210 : id === 'troy' ? 175 :
  id === 'qarqar' ? 185 : id === 'babylon' ? 220 : id === 'salamis' ? 225 :
    id === 'mantinea' ? 215 : id === 'aegospotami' ? 220 :
    id === 'gaugamela' ? 195 : id === 'issus' ? 205 : id === 'tyre' ? 235 :
      id === 'cannae' || id === 'zama' ? 195 : id === 'carthage' ? 205 : id === 'alesia' ? 220 : id === 'pharsalus' ? 190 : id === 'actium' ? 205 : id === 'teutoburg' ? 205 : id === 'jerusalem' ? 230 : id === 'carrhae' ? 190 : id === 'syracuse' ? 210 : id === 'pydna' ? 185 : id === 'china_changping' || id === 'china_qin_chu' ? 300 : id === 'china_eyu' ? 250 : CHINA_CAMPAIGN_IDS.has(id) ? 225 : 112;
const initialCameraDistance=(id,map)=>initialCameraDistanceForScenario(id)*(map?.victory?.layoutVersion===5?1.05:map?.victory?.layoutVersion===4?2.1:1);
let cameraDistance = initialCameraDistance(chosenScenario,initialScenario);
const raycaster = new THREE.Raycaster(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const pointer = new THREE.Vector2();
let scenario = initialScenario, game, editing = false, selectedId = null, editorSelectedId = null;
const unitModels = new Map();
const armyFormations=createArmyFormationRenderer();
scene.add(armyFormations.group);
const soldierCamera = createSoldierCamera(perspectiveCamera, reason => soldierCameraUI.lost(reason));
const soldierCameraUI = bindSoldierCamera(soldierCamera, {
  document, candidates: () => liveUnits().filter(u => canFollowSoldier(u, playerTeam, battleMode === 'ai-ai') && unitModels.has(u.id)),
  getSelected: () => selectedId, getModel: id => unitModels.get(id), nameOf: u => unitName(currentMap(), u),
  overview: () => { updateCamera(); if (game) syncGroupControls(); }, selected: id => { camera=perspectiveCamera;boardView=false;camera.up.set(0,1,0); clearGroup(); selectedId = id;  refresh(); }, isEditing: () => editing,
});
let lastFollowShadowId = null;
const followShadowCenter = new THREE.Vector3();
let batchPhalanx=null;const formationPreviews=new Map();
function previewPhalanx(ids,facing){for(const id of ids){if(facing==null)formationPreviews.delete(id);else formationPreviews.set(id,facing);const model=unitModels.get(id);if(model){if(facing==null)delete model.userData.previewFacing;else model.userData.previewFacing=facing;}}rebuildMarks();}
let groupIds = new Set(), boxSelect = false, groupMap = null;
let armyArea=false; const armyGroups=new Map();
function clearGroup() { for(const id of formationPreviews.keys()){const model=unitModels.get(id);if(model)delete model.userData.previewFacing;}formationPreviews.clear();groupIds.clear(); boxSelect=false; armyArea=false; }
function groupAvailable() {return !soldierCamera.active && !editing && !game.deploying && !game.over && humanCanAct();}
function syncGroupControls() {
  if(groupMap!==game.map){armyGroups.clear();groupMap=game.map;clearGroup();}
  const available=groupAvailable();
  if(!available)clearGroup();
  for(const id of groupIds)if(!selectable(game.map.units.find(u=>u.id===id),playerTeam))groupIds.delete(id);
  $('army-area').classList.toggle('active',armyArea);
  $('army-area').setAttribute('aria-pressed',String(armyArea));
  $('army-area').disabled=!groupIds.size&&!selectable(selectedUnit(),playerTeam);
  if(available){
    const select=$('army-group'), selected=select.value;
    const groups=new Set(game.map.units.filter(u=>selectable(u,playerTeam)&&seen(u)).map(u=>armyLane(u)));
    for(const k of armyGroups.get(playerTeam)?.keys()||[])groups.add(k);
    select.replaceChildren(new Option('战团编组',''),...[...groups].map(k=>new Option(k,k)));
    if(groups.has(selected))select.value=selected;
  }
  $('group-controls').classList.toggle('hidden',!available);
  $('box-select').classList.toggle('active',boxSelect);
  $('box-select').setAttribute('aria-pressed',String(boxSelect));
  const ready=[...groupIds].filter(id=>game.map.units.find(u=>u.id===id)?.actionsLeft>0).length;
  $('group-count').textContent=`已选 ${groupIds.size} · 可行动 ${ready}`;
  $('group-cancel').classList.toggle('hidden',!groupIds.size&&!boxSelect);
  $('group-preview').textContent=armyArea?'点选半径 3 格的交战区':boxSelect?'拖动框选 · Shift 点击增减':'左键移至区域 · 点敌军集火 · Alt+1–5 保存编组';
}
function armyLane(u){
  const stats=unitStats(game.map,u);
  return game.middleEarth?.army?.roles[u.id]?.lane||
    (isShip(u)?'舰船':stats.mountedRole?'骑兵':stats.range?'远程支援':'预备队');
}
function selectArmyGroup(name){
  const saved=armyGroups.get(playerTeam)?.get(name);
  groupIds=new Set(game.map.units.filter(u=>selectable(u,playerTeam)&&seen(u)&&
    (saved?saved.has(u.id):armyLane(u)===name)).map(u=>u.id));
  armyArea=false;groupSelectionChanged();
}
function groupSelectionChanged() {for(const id of formationPreviews.keys()){const model=unitModels.get(id);if(model)delete model.userData.previewFacing;}formationPreviews.clear();selectedId=groupIds.values().next().value||null;refresh();}
function unitScreen(u) {
  const p=offsetToWorld(u.c,u.r),rect=canvas.getBoundingClientRect();
  const v=new THREE.Vector3(p.x,unitY(currentMap(),u)+.3,p.z).project(camera);
  return {x:rect.left+(v.x+1)*rect.width/2,y:rect.top+(1-v.y)*rect.height/2,visible:v.z>=-1&&v.z<=1};
}
const savedMapIds = new Set();
function registerSavedMap(id, name) {
  savedMapIds.add(id);
  let option = [...$('scenario-select').options].find(item => item.value === id);
  if (!option) { option = document.createElement('option'); option.value = id; $('scenario-select').append(option); }
  option.textContent = CAMPAIGN_IDS.has(id) ? campaignTitle(id) : `${name} · 自制战役`;
}
async function readScenario(id) {
  const response = await fetch(`/api/ancient/maps/${encodeURIComponent(id)}`, { cache: 'no-store' });
  if (response.status === 404 && (CAMPAIGN_IDS.has(id)||ME_IDS.has(id))) return makeScenario(id);
  if (!response.ok) throw new Error(`读取战役地图失败（${response.status}）`);
  const map = importMap(await response.json());
  if (map.scenarioId !== id) throw new Error('战役地图编号不匹配');
  return map;
}
async function storeScenario() {
  scenario.name = $('map-name').value.trim() || '古代战役地图';
  scenario.factions.egypt = $('faction-egypt').value.trim() || '阵营一';
  scenario.factions.coalition = $('faction-coalition').value.trim() || '阵营二';
  const payload = exportMap(scenario);
  const response = await fetch(`/api/ancient/maps/${encodeURIComponent(scenario.scenarioId)}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error(`保存战役地图失败（${response.status}）`);
  registerSavedMap(scenario.scenarioId, scenario.name);
  $('scenario-select').value = scenario.scenarioId;
  return scenario.name;
}
let hiddenLogIndices = new Set();
let logOwnerCursor = 0;
let combatFx = null;
let autoRunning = battleMode === 'ai-ai', autoTimer = null;
const humanCanAct = () => !navigationPaused && battleMode !== 'ai-ai' && game.side === playerTeam;
function cancelAutoTurn() { if (autoTimer !== null) clearTimeout(autoTimer); autoTimer = null; }
function sealHotseatLogs(owner) {
  if (battleMode !== 'human-human') return;
  game.logOwners ||= [];
  for (let i = logOwnerCursor; i < game.log.length; i++)
    game.logOwners[i] = game.log[i].includes('天降陨石') ? null : owner;
  logOwnerCursor = game.log.length;
}
function playComputerTurn(before = game.log.length) {
  const actions = aiTurn(game);
  unitAnimator.actions(actions.filter(a=>{const u=game.map.units.find(u=>u.id===a.id);return observerView()||u?.kind!=='scout'||knownTo(game,playerTeam,u);}),performance.now(),game.map,p=>!!p&&(observerView()||visibleTo(game,playerTeam,p.c,p.r)));
  if (battleMode === 'human-ai'||game.battlePhase==='pursuit') for (let i = before; i < game.log.length; i++)
    if (!(game.over && i === game.log.length - 1) &&
        !game.log[i].includes('首次攻入巴比伦') && !game.log[i].includes('天降陨石')) hiddenLogIndices.add(i);
}
let pendingFog={...STANDARD_FOG_POLICY};
function startForPlayer() {
  if(isMorannon(scenario.scenarioId)){battleMode='human-ai';preferredHumanTeam='egypt';}
  editorCoreSite=null;
  beforePanorama=null;
  tileDetails?.hide();
  casualtyLayer.clear();
  orderOfficer?.reset();
  soldierCameraUI.reset();
  unitModels.clear();
  clearGroup();
  cancelAutoTurn();
  combatFx?.clear(); unitAnimator.clear();
  playerTeam = battleMode === 'human-ai' ? preferredHumanTeam : 'egypt';
  game = troyTrial && scenario.scenarioId === 'troy' && playerTeam === 'egypt' ? startTroyTurn65(scenario) : startGame(scenario,{manualCores:true,reserveResponses:true,gateRules:1,fogPolicy:pendingFog,addScouts:CAMPAIGN_IDS.has(scenario.scenarioId)});
  game.aiDifficulty = aiDifficulty;
  hiddenLogIndices = new Set();
  game.logOwners = game.log.map(() => null);
  logOwnerCursor = game.log.length;
  autoRunning = battleMode === 'ai-ai';
  if (battleMode === 'ai-ai' && game.deploying) beginBattle(game);
  if (battleMode === 'human-ai' && playerTeam === 'coalition') {
    if (game.deploying) beginBattle(game);
    game.log[0] = `${scenario.factions.egypt}由电脑指挥；你指挥${scenario.factions.coalition}。`;
    playComputerTurn();
  }
}
function stepComputerBattle() {
  if (navigationPaused || battleMode !== 'ai-ai' || editing || game.over) return;
  if (game.deploying) beginBattle(game);
  const acting = game.side;
  playComputerTurn();
  if (game.over) autoRunning = false;
  selectedId = null;
  // Observer view stays omniscient; AI decisions still use their own planningState.
  hint(game.over ? game.winner ? `${game.map.factions[game.winner]}获胜：${victoryLabel(game)}。` : '双方平局。' :
    `${game.map.factions[acting]}行动完成；轮到${game.map.factions[game.side]}。`);
  refresh();
}
function scheduleAutoTurn() {
  if (navigationPaused || autoTimer !== null || !autoRunning || battleMode !== 'ai-ai' || editing || game.over) return;
  autoTimer = window.setTimeout(() => { autoTimer = null; stepComputerBattle(); }, Number($('auto-speed').value));
}
startForPlayer();
combatFx = createWeaponEffects(scene,camera,stage,(result,now,map)=>unitAnimator.attack(result,now,map));
unitAnimator.setEffects(combatFx);
unitAnimator.setHeightResolver(p=>unitY(currentMap(),p));
unitAnimator.setSurfaceResolver((x,z)=>terrainObj?.sample(x,z)??0);
unitAnimator.setWorksResolver(()=>sceneWorks);
let brush = 'road', gesture = null, lastPaint = '', spaceHeld = false;
let unitGroup, fortGroup, markGroup, weatherGroup, labels = [];
let shownMeteorEvent = null, meteorFall = null;
let rebuildQueued = false;
const escapeHTML = s => String(s).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
function observerView(){return isOmniscientObserver(battleMode,editing);}
function currentMap() { return presentationMap(game,playerTeam,battleMode,editing,scenario); }
function seen(u) { if(!editing&&game?.middleEarth&&(!meUnitActive(game,u)||isMorannon(game.map.scenarioId)&&meZone(u.c,game.map)!==game.middleEarth.view))return false; return editing || observerView() || (['fort','defenseTower'].includes(u.kind)&&currentMap().units.includes(u)) || knownTo(game, playerTeam, u); }
function liveUnits() { return currentMap().units.filter(u => u.hp > 0 && !u.aboard && (editing||meUnitActive(game,u)&&(!isMorannon(game.map.scenarioId)||meZone(u.c,game.map)===game.middleEarth.view)) && seen(u)); }
const maxCameraDistance=m=>hasCliffNavigation(m)?1150:m?.victory?.layoutVersion===5?3800:m?.victory?.layoutVersion>=3?7600:m?.victory?.layoutVersion===2?960:450;
function syncTerrainGrid(){
  const m=editing?scenario:game?.map;
  const large=m?.victory?.layoutVersion>=3&&!hasCliffNavigation(m);
  terrainObj?.setGrid(showHexGrid&&(!large||boardView||cameraDistance<(m.victory.layoutVersion===4?330:470)),boardView||editing);
}
function updateCamera() {
  if (soldierCamera.engaged) return;
  lastFollowShadowId = null;
  camera=boardView?boardCamera:perspectiveCamera;
  camera.aspect=stage.clientWidth/Math.max(1,stage.clientHeight);
  const large=game?.map.victory?.layoutVersion>=3&&!hasCliffNavigation(game?.map);
  camera.far=game?.map.victory?.layoutVersion===5?6500:large?12500:2200;
  if(large){scene.fog.near=Math.max(820,cameraDistance*.83);scene.fog.far=Math.max(2700,cameraDistance*1.85);}
  syncTerrainGrid();
  if(boardView){const span=cameraDistance*Math.tan(Math.PI/8);Object.assign(camera,{left:-span*camera.aspect,right:span*camera.aspect,top:span,bottom:-span});camera.up.set(-Math.sin(cameraYaw),0,-Math.cos(cameraYaw));camera.position.set(target.x,target.y+cameraDistance,target.z);}
  else {camera.up.set(0,1,0);camera.position.set(target.x+Math.sin(cameraYaw)*cameraDistance*Math.cos(cameraPitch),target.y+cameraDistance*Math.sin(cameraPitch),target.z+Math.cos(cameraYaw)*cameraDistance*Math.cos(cameraPitch));}
  camera.updateProjectionMatrix();
  camera.lookAt(target);
  terrainEnvironment.focus(target, cameraDistance); camera.updateMatrixWorld();
}
function groundAt(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return null;
  pointer.set((clientX - rect.left) / rect.width * 2 - 1, -(clientY - rect.top) / rect.height * 2 + 1);
  raycaster.setFromCamera(pointer, camera);
  return raycaster.ray.intersectPlane(plane, new THREE.Vector3());
}
function clampCameraTarget() {
  const m = currentMap();
  const window=!editing&&isMorannon(game.map.scenarioId)?morannonWindows(game.map)[game.middleEarth.view]:null;
  const a = offsetToWorld(window?.[0]??0, 0), b = offsetToWorld((window?.[1]??m.cols)-1, m.rows-1);
  target.x = THREE.MathUtils.clamp(target.x, Math.min(a.x, b.x) - 24, Math.max(a.x, b.x) + 24);
  target.z = THREE.MathUtils.clamp(target.z, Math.min(a.z, b.z) - 24, Math.max(a.z, b.z) + 24);
}
function panTo(clientX, clientY) {
  const before = groundAt(gesture.x, gesture.y);
  const after = groundAt(clientX, clientY);
  if (before && after) {
    target.x += before.x - after.x;
    target.z += before.z - after.z;
  } else {
    const scale = cameraDistance * 0.002;
    target.x -= (clientX - gesture.x) * scale;
    target.z -= (clientY - gesture.y) * scale;
  }
  clampCameraTarget(); updateCamera();
  gesture.x = clientX; gesture.y = clientY;
}
function zoomAt(clientX, clientY, factor) {
  const before = groundAt(clientX, clientY);
  cameraDistance = THREE.MathUtils.clamp(cameraDistance * factor, 42, maxCameraDistance(game?.map));
  updateCamera();
  const after = groundAt(clientX, clientY);
  if (before && after) {
    target.x += before.x - after.x;
    target.z += before.z - after.z;
    clampCameraTarget(); updateCamera();
  }
}
function resizeViewport() {
  renderer.setSize(stage.clientWidth, stage.clientHeight, false);
  camera.aspect = stage.clientWidth / Math.max(1, stage.clientHeight);
  camera.updateProjectionMatrix(); updateCamera();
}
new ResizeObserver(resizeViewport).observe(stage);
resizeViewport();
function disposeGroup(g, sharedMaterials = false) {
  if (!g) return;
  scene.remove(g);
  const geometries = new Set(), materials = new Set();
  g.traverse(o => {
    if (o.isInstancedMesh) o.dispose();
    if (o.geometry && !geometries.has(o.geometry)) { geometries.add(o.geometry); if (!o.geometry.userData.sharedUnitV02) o.geometry.dispose(); }
    if (!sharedMaterials && o.material) {
      for (const material of Array.isArray(o.material) ? o.material : [o.material])
        if (!materials.has(material)) { materials.add(material); material.dispose(); }
    }
  });
}
function visualHeight(m,c,r){return terrainObj&&m===currentMap()?terrainObj.height(c,r):terrainHeight(m,c,r);}
function unitY(m, u) {
  const fort = u.kind === 'fort' ? null : fortAt(m, u.c, u.r);
  if(meAir(u))return visualHeight(m,u.c,u.r)+(u.meLow?2.0:5.4);
  if(fort?.gate&&usesFortificationLayout(m)){
    const p=fortificationLayout(m).position(u);
    return terrainObj?.sample(p.x,p.z)??visualHeight(m,u.c,u.r);
  }
  return visualHeight(m,u.c,u.r)+(u.gateTransit&&fort?.gate?0:fortStandingHeight(fort));
}
let casualtyBudget=256,casualtyAge=8;
try{casualtyBudget=Number(localStorage.getItem('ancient-casualty-budget'))||256;const savedAge=localStorage.getItem('ancient-casualty-age');casualtyAge=savedAge!==null&&[0,4,8,16,32].includes(Number(savedAge))?Number(savedAge):8;}catch{}
let unitSceneMap=null,sceneWorks=null;
function rebuildScene() {
  const m = currentMap();
  sceneWorks=usesFortificationLayout(m)?fortificationLayout(m):null;
  const authored=!editing&&m.victory?.layoutVersion>=2;
  document.body.classList.toggle('middle-earth-layout',authored);
  document.body.classList.toggle('middle-earth-compact',authored&&hasCliffNavigation(m));
  scene.background.setHex(authored?isMorannon(m.scenarioId)?0x514c53:m.victory.army?0x899ca9:0x879792:0x89969a);
  scene.fog.color.copy(scene.background);
  const large=m.victory?.layoutVersion>=3&&!hasCliffNavigation(m);
  scene.fog.near=large?Math.max(820,cameraDistance*.83):authored?590:320;
  scene.fog.far=large?Math.max(2700,cameraDistance*1.85):authored?1520:1400;
  unitAnimator.observe(liveUnits(),performance.now(),m);
  if (!terrainObj) {
    terrainObj=createTerrainRefresh();scene.add(terrainObj.group,terrainObj.forts);
  }
  const zoneWindow=!editing&&isMorannon(game.map.scenarioId)?morannonWindows(game.map)[game.middleEarth.view]:null;
  const terrainUpdate=terrainObj.refresh(m,zoneWindow);
  if(m.victory?.layoutVersion>=4&&terrainUpdate.reset&&cameraDistance<1100){
    target.y=terrainObj.sample(target.x,target.z);
    updateCamera();
  }
  casualtyLayer.sync(m,u=>seen(u)&&(!zoneWindow||u.c>=zoneWindow[0]&&u.c<zoneWindow[1]),{editing,show:showCasualties,detail:terrainQuality,budget:casualtyBudget,maxAgeTurns:casualtyAge,currentTurn:game?.turn||1});terrainObj.setQuality(terrainQuality);syncTerrainGrid();
  fortGroup=terrainObj.forts;
  syncBreachFlash(m);
  // Moving pieces keep their existing body/base object and animator anchor. Recreate
  // only changed appearances; full rebuilds remain available for map/editor/legacy changes.
  const previous=new Map(unitModels),reuse=unitSceneMap===m&&!editing&&params.get('models')!=='legacy';
  for(const model of previous.values())model.removeFromParent();
  disposeGroup(unitGroup,true);disposeGroup(markGroup);disposeGroup(weatherGroup);
  unitGroup=new THREE.Group();markGroup=new THREE.Group();weatherGroup=new THREE.Group();
  scene.add(unitGroup,markGroup,weatherGroup);
  unitModels.clear();
  for (const u of liveUnits()) {
    if (u.kind === 'fort') continue;
    const cacheKey=JSON.stringify([u.kind,u.team,!!u.onFoot,!!u.mutinous,isRouted(u),visualProfile(u,m.scenarioId,m)]),old=previous.get(u.id);
    const mass=!editing&&m.victory.army&&isArmyFormation(u)&&params.get('models')!=='legacy';
    const cached=reuse&&old?.userData.unitCacheKey===cacheKey,model=cached?old:mass?new THREE.Group():createUnitModel(u,m.scenarioId,{map:m,legacy:params.get('models')==='legacy',withoutBase:true});
    if(mass)model.userData.armyFormation=true;
    if(cached)previous.delete(u.id);
    if(!cached){const p=!meAir(u)&&sceneWorks?sceneWorks.position(u):offsetToWorld(u.c,u.r);model.scale.setScalar(UNIT_SCENE_SCALE);
    if (isTrireme(u) || (isFormableInfantry(u) && u.formed)) {
      model.rotation.y = facingYaw(u.facing);
    }
    model.position.set(p.x, unitY(m, u) + 0.08, p.z);
    model.userData.unitCacheKey=cacheKey;}
    model.userData.unitId = u.id; unitGroup.add(model); unitModels.set(u.id, model);
  }
  for(const model of previous.values())disposeGroup(model,true);unitSceneMap=m;
  armyFormations.bind(m,liveUnits(),unitModels,(x,z)=>terrainObj.sample(x,z));
  terrainEnvironment.invalidate();
  const clouds = editing ? m.weather?.clouds : game.weather?.clouds;
  for (const cloud of clouds || []) {
    const p = offsetToWorld(cloud.c, cloud.r);
    const body = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 8),
      new THREE.MeshBasicMaterial({ color: 0xdce8eb, transparent: true, opacity: 0.18,
        depthWrite: false, side: THREE.DoubleSide }));
    body.scale.set(9 + cloud.radius * 8, 1.4, 9 + cloud.radius * 8);
    body.position.set(p.x, 5.5, p.z);
    weatherGroup.add(body);
  }
  rebuildMarks(); rebuildLabels();
  if ($('camera-dialog').open) soldierCameraUI.sync();
}
function scheduleRebuild() {
  if (rebuildQueued) return;
  rebuildQueued = true;
  requestAnimationFrame(() => { rebuildQueued = false; rebuildScene(); });
}
function marker(c, r, color, radius = 4.8, opacity = 0.86, inset=0) {
  const m = currentMap();
  if (!editing && !observerView() && !terrainKnown(game,playerTeam,c,r)) return;
  const work=sceneWorks?.at(c,r),wall=isSolidWall(work?.fort);
  const center=wall?work.p:undefined;
  const top=wall?visualHeight(m,c,r)+wallHeight(work.fort.level):null;
  const geometry=createCellOutline(c,r,{center,inset:wall?Math.max(3.7,inset):inset,
    sample:(x,z)=>top??terrainObj?.sample(x,z)??visualHeight(m,c,r)});
  const mesh=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide,transparent:true,opacity,depthTest:!!sceneWorks,depthWrite:false}));
  mesh.renderOrder=20;markGroup.add(mesh);
  return mesh;
}
let previewedFormation = null;
function showFormationPreview(plan = null) {
  if (plan === previewedFormation) return;
  previewedFormation = plan;
  for (const mesh of [...markGroup.children]) {
    if (!mesh.userData.formationPreview) continue;
    markGroup.remove(mesh);
    mesh.geometry.dispose();
    mesh.material.dispose();
  }
  if (!plan) return;

  const points = [];
  const point = (x, z) => new THREE.Vector3(x, (terrainObj?.sample(x, z) ?? 0) + .25, z);
  for (const {from, to, path} of plan.entries) {
    const frame = marker(to.c, to.r, 0xffd766, 4.75, 1, .28);
    if (frame) frame.userData.formationPreview = true;
    const nodes=[from,...path].map(p=>sceneWorks?.position(p)??offsetToWorld(p.c,p.r));
    for (let i = 1; i < nodes.length; i++) {
      const a = nodes[i - 1], b = nodes[i];
      for (let step = 0; step < 4; step++) {
        const t = step / 4, next = (step + 1) / 4;
        points.push(point(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t),
          point(a.x + (b.x - a.x) * next, a.z + (b.z - a.z) * next));
      }
    }
    const tip = nodes.at(-1), previous = nodes.at(-2);
    const length = Math.hypot(tip.x - previous.x, tip.z - previous.z);
    const dx = (tip.x - previous.x) / length, dz = (tip.z - previous.z) / length;
    for (const side of [-1, 1]) {
      points.push(point(tip.x, tip.z),
        point(tip.x - dx * 1.25 + dz * side * .72, tip.z - dz * 1.25 - dx * side * .72));
    }
  }
  const arrows = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(points),
    new THREE.LineBasicMaterial({color: 0xffdb70, transparent: true, depthTest: !!sceneWorks, depthWrite: false, toneMapped: false}));
  arrows.renderOrder = 21;
  arrows.userData.formationPreview = true;
  markGroup.add(arrows);
}
function selectedUnit() { return currentMap().units.find(u => u.id === selectedId && u.hp > 0 && seen(u)) || null; }
function markCliffEdges(m,u,movement){
  if(!hasCliffNavigation(m)||meAir(u)||u.kind==='fort'||u.kind==='meBlackShip')return;
  const origins=[u,...[...movement.values()].filter(p=>distance(p,u)<=2)];
  const drawn=new Set(),vertices=[];
  for(const p of origins){
    const cell=groundCell(m,p.c,p.r);
    for(let i=0;i<6;i++){
      const q=cell.sides[i];
      if(!q||!knownGroundEdge(m,p,q)||!groundConnection(m,u,p,q))continue;
      const pair=[key(p.c,p.r),key(q.c,q.r)].sort().join('/');
      if(drawn.has(pair))continue;
      drawn.add(pair);
      const a=cell.rim[2*i],b=cell.rim[2*i+1],d=cell.rim[(2*i+2)%12];
      for(const [start,end] of [[a,b],[b,d]]){
        const length=Math.hypot(end[0]-start[0],end[2]-start[2]);
        const dx=(end[2]-start[2])*.22/length,dz=(start[0]-end[0])*.22/length;
        const ends=[start,end].flatMap(([x,y,z])=>[[x+dx,y+.19,z+dz],[x-dx,y+.19,z-dz]]);
        for(const j of [0,1,2,2,1,3])vertices.push(...ends[j]);
      }
    }
  }
  if(!vertices.length)return;
  const geometry=new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
  const material=new THREE.MeshBasicMaterial({color:0xffb552,side:THREE.DoubleSide,depthWrite:false});
  const edges=new THREE.Mesh(geometry,material);
  edges.name='known-cliff-edges';edges.renderOrder=11;markGroup.add(edges);
}
function rebuildMarks() {
  if (!markGroup) return;
  previewedFormation = null;
  while (markGroup.children.length) { const o = markGroup.children[0]; markGroup.remove(o); if (!o.geometry.userData.sharedUnitV02) o.geometry.dispose(); o.material.dispose(); }
  if(!editing&&game.middleEarth?.view==='doom'&&game.middleEarth.alert){
    const eye=game.middleEarth.alert;
    for(let r=eye.r-2;r<=eye.r+2;r++)for(let c=eye.c-2;c<=eye.c+2;c++)
      if(inBounds(game.map,c,r)&&meZone(c,game.map)==='doom'&&distance(eye,{c,r})<=eye.radius)marker(c,r,0xc68637,4.2,.52);
  }
  const m = currentMap(), u = selectedUnit();
  const blast=m.victory.points?.blast;
  if(hasCliffNavigation(m)&&!editing&&blast&&game.middleEarth.blastReady&&!game.middleEarth.events.breach&&
    (observerView()||visibleTo(game,playerTeam,blast.c,blast.r))){
    for(let r=blast.r-hornburgBlastRadius;r<=blast.r+hornburgBlastRadius;r++)
      for(let c=blast.c-hornburgBlastRadius;c<=blast.c+hornburgBlastRadius;c++)
        if(inBounds(m,c,r)&&distance(blast,{c,r})===hornburgBlastRadius&&
          (observerView()||terrainKnown(game,playerTeam,c,r)))marker(c,r,0xe77442,4.6,.82);
  }
  if(!editing)for(const mesh of coreMarkers(observerView()?game:planningState(game,playerTeam),(c,r)=>visualHeight(m,c,r)))markGroup.add(mesh);
  if(!editing)for(const mesh of createPhalanxMeshes({...game,map:m},[...groupIds,...(selectedId?[selectedId]:[])],(x,z)=>terrainObj?.sample(x,z)??0,formationPreviews))markGroup.add(mesh);
  if (!editing && game.deploying) {
    const d = m.deployment;
    for (let r = d.rMin; r <= d.rMax; r++) for (let c = d.cMin; c <= d.cMax; c++) {
      if ((r === d.rMin || r === d.rMax || c === d.cMin || c === d.cMax) &&
          !(tile(m, c, r).terrain & TERRAIN.RIVER)) marker(c, r, 0x6ab8d3, 4.7, 0.48);
    }
  }
  if (!editing && ['troy', 'tyre'].includes(m.victory.mode)) marker(m.victory.capture.c, m.victory.capture.r, 0xffd35d, 4.25);
  if (!editing && hasChinaCaptureObjective(m))
    marker(m.victory.objective.c, m.victory.objective.r, 0xffd35d, 4.35);
  if (!editing && m.scenarioId === 'china_kunyang')
    marker(KUNYANG_CITY_OBJECTIVE.c, KUNYANG_CITY_OBJECTIVE.r, 0xffd35d, 4.35);
  if (!editing && m.scenarioId === 'china_kunyang' && game.kunyangMeteor?.turn === game.turn)
    for (const p of game.kunyangMeteor.strikes) marker(p.c, p.r, 0xff6835, 4.7, 0.92);
  if (!editing && m.victory.mode === 'carthage') {
    const goal = game.carthageHarborTaken ? m.victory.byrsa : m.victory.harbor;
    marker(goal.c, goal.r, 0xffd35d, 4.25);
  }
  if (!editing && m.victory.mode === 'classical') {
    if (m.victory.capture) marker(m.victory.capture.c,m.victory.capture.r,0xffd35d,4.35);
    for (const a of m.victory.escape||[]) for (const [c,r] of [[a.cMin,a.rMin],[a.cMax,a.rMin],[a.cMin,a.rMax],[a.cMax,a.rMax]]) marker(c,r,0xffd35d,4.35);
  }
  if (!editing && m.victory.mode === 'syracuse') marker(m.victory.capture.c, m.victory.capture.r, 0xffd35d, 4.35);
  if (!editing && m.victory.mode === 'jerusalem') {
    const goal = m.victory.stages[game.jerusalemStage];
    if (goal) marker(goal.c, goal.r, 0xffd35d, 4.35);
  }
  if (!editing && m.victory.mode === 'tyre') {
    for (const next of nextMoleCells(m)) marker(next.c, next.r, 0x78c7e1, 4.2, .7);
  }
  if (!editing && m.victory.mode === 'alesia') {
    for (const ring of [m.victory.inner, m.victory.outer])
      for (const [c, r] of ring) if (!fortAt(m, c, r)) marker(c, r, 0x78c7e1, 4.15, 0.38);
  }
  if (!editing && m.victory.mode === 'qarqar') marker(m.victory.objective.c, m.victory.objective.r, 0xffd35d, 4.25);
  if (!editing && m.victory.mode === 'babylon') marker(m.victory.rescue.c, m.victory.rescue.r, 0xffd35d, 4.25);
  if (!editing && m.victory.mode === 'salamis') {
    const bay = m.victory.bay;
    for (let r = bay.rMin; r <= bay.rMax; r++) for (let c = bay.cMin; c <= bay.cMax; c++)
      if ((r === bay.rMin || r === bay.rMax || c === bay.cMin || c === bay.cMax) &&
          tile(m, c, r).terrain === TERRAIN.SEA) marker(c, r, 0xf2c375, 4.35, 0.48);
  }
  if (!editing && m.victory.mode === 'actium')
    for (let r = m.victory.escape.rMin; r <= m.victory.escape.rMax; r += 2)
      if (tile(m, m.victory.escape.cMax, r).terrain === TERRAIN.SEA)
        marker(m.victory.escape.cMax, r, 0xf2c375, 4.25, 0.5);
  if (!editing && m.scenarioId === 'aegospotami')
    for (let r = m.victory.escape.rMin; r <= m.victory.escape.rMax; r += 2)
      if (tile(m, m.victory.escape.cMax, r).terrain === TERRAIN.SEA)
        marker(m.victory.escape.cMax, r, 0xf2c375, 4.25, 0.5);
  if (!editing && m.victory.mode === 'carrhae')
    for (let r = m.victory.escape.rMin; r <= m.victory.escape.rMax; r += 2)
      marker(m.victory.escape.cMax, r, 0xf2c375, 4.25, 0.5);
  if (!editing && m.victory.mode === 'teutoburg')
    for (let r = m.victory.escape.rMin; r <= m.victory.escape.rMax; r += 2)
      marker(m.victory.escape.cMax, r, 0xf2c375, 4.25, 0.5);
  for (const p of m.supplyPoints) marker(p.c, p.r, factionColor(p.team), 4.15);
  if (!editing && m.logistics) for (const team of ['egypt', 'coalition']) {
    const color = factionColor(team);
    for (const p of m.logistics.depots[team]) marker(p.c, p.r, color, 4.3);
    for (const p of m.logistics.musters[team]) marker(p.c, p.r, color, 4.1, 0.65);
    for (const p of m.logistics.routes[team]) marker(p.c, p.r, color, 3.8, 0.28);
  }
  if (!editing && m.recruitment) {
    for (const team of ['egypt', 'coalition']) {
      const point = m.recruitment.muster[team].sea;
      marker(point.c, point.r, factionColor(team), 4.3);
    }
    const land = m.recruitment.muster.coalition.land;
    marker(land.c, land.r, 0xf29b83, 4.3);
    const horseWorkshop = m.recruitment.muster.egypt.land;
    marker(horseWorkshop.c, horseWorkshop.r, 0x75c7ec, 4.3);
  }
  if (!editing && groupIds.size) {
    for(const id of groupIds){const v=m.units.find(x=>x.id===id);if(v)marker(v.c,v.r,v.actionsLeft>0?0xffdc6e:0xa0a3a6,3.15,.95);}
    if (groupIds.size > 1) return;
  }
  if (!u) return;
  marker(u.c, u.r, 0xffd783, 5.25);
  if (!editing && !game.deploying && controlledBy(u,playerTeam) && humanCanAct() && !game.over) {
    const movement=reachable(game,u);
    markCliffEdges(m,u,movement);
    for (const p of movement.values()) marker(p.c, p.r, 0x69b9f5, 4.75, 0.65);
    if (u.kind === 'transport' || u.aboard) {
      const ship = u.aboard ? m.units.find(v => v.id === u.aboard) : u;
      if (ship && cargoOf(m, ship).some(v => v.actionsLeft > 0))
        for (const p of neighbors(ship.c, ship.r))
          if (inBounds(m, p.c, p.r) && (tile(m, p.c, p.r).terrain & TERRAIN.BEACH) &&
              !mobileAt(m, p.c, p.r)) marker(p.c, p.r, 0x69b9f5, 4.75, .65);
    }
    for (const p of attackArea(game,u)) marker(p.c,p.r,0xec4039,5.2,p.occupied?1:.9,.55);
  }
}
function rebuildLabels() {
  $('labels').replaceChildren(); labels = [];
  if (editing) {unitHUD.clear();return;}
  unitHUD.sync(liveUnits().filter(u=>u.kind!=='fort'||u.id===selectedId),currentMap(),unitModels,u=>unitY(currentMap(),u));
  for (const place of currentMap().landmarks || []) {
    if(game.middleEarth&&isMorannon(game.map.scenarioId)&&meZone(place.c,game.map)!==game.middleEarth.view)continue;
    const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = place.label;
    const m=currentMap();
    const priority=hasCliffNavigation(m)?Object.entries(m.victory.points).some(([k,p])=>
      !['culvert','blast','sally','start','ash','flee','dock1'].includes(k)&&p.c===place.c&&p.r===place.r):null;
    $('labels').append(el); labels.push({ c: place.c, r: place.r, y: visualHeight(m, place.c, place.r) + 7, middleEarth:!!game.middleEarth, priority, el });
  }
  if(hasCliffNavigation(currentMap()))labels.sort((a,b)=>Number(b.priority)-Number(a.priority));
  if (hasChinaCaptureObjective(currentMap())) {
    const goal = currentMap().victory.objective;
    const el = document.createElement('div'); el.className = 'landmark-label';
    el.textContent = `★ ${currentMap().victory.objectiveName}`;
    $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
  }
  if (currentMap().scenarioId === 'china_kunyang') {
    const goal = KUNYANG_CITY_OBJECTIVE, el = document.createElement('div');
    el.className = 'landmark-label'; el.textContent = '★ 昆阳城';
    $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
  }
  if(editing)for(const point of editorFacilityPoints(currentMap())){const el=document.createElement('div');el.className='landmark-label';el.textContent=`◆ ${point.team?currentMap().factions[point.team]+' ':''}${point.label}`;$('labels').append(el);labels.push({c:point.c,r:point.r,y:visualHeight(currentMap(),point.c,point.r)+6,el});}
  for (const point of currentMap().supplyPoints) {
    const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = '✚ 补给';
    $('labels').append(el); labels.push({ c: point.c, r: point.r, y: visualHeight(currentMap(), point.c, point.r) + 4, el });
  }
  if (currentMap().logistics) for (const team of ['egypt', 'coalition']) {
    for (const [kind, points, symbol] of [['后方补给点', currentMap().logistics.depots[team], '◆'],
      ['召集点', currentMap().logistics.musters[team], '✚']]) for (const point of points) {
      const el = document.createElement('div'); el.className = 'landmark-label';
      el.textContent = `${symbol} ${currentMap().factions[team]}${kind}`;
      $('labels').append(el); labels.push({ c: point.c, r: point.r,
        y: visualHeight(currentMap(), point.c, point.r) + 5, el });
    }
  }
  if (currentMap().victory.mode === 'troy') {
    const goal = currentMap().victory.capture;
    const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = '★ 阿开亚占领目标';
    $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
  }
  if (currentMap().victory.mode === 'tyre') {
    const goal = currentMap().victory.capture;
    const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = '★ 推罗内城目标';
    $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
  }
  if (currentMap().victory.mode === 'carthage') {
    for (const [goal, label] of [[currentMap().victory.harbor, '★ 先占科通港区'],
      [currentMap().victory.byrsa, '★ 再夺比尔萨城堡']]) {
      const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = label;
      $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
    }
  }
  if (currentMap().victory.mode === 'qarqar') {
    const goal = currentMap().victory.objective;
    const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = '★ 南向道路目标';
    $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
  }
  if (currentMap().victory.mode === 'babylon') {
    const goal = currentMap().victory.rescue;
    const el = document.createElement('div'); el.className = 'landmark-label'; el.textContent = '★ 解救犹大流亡者';
    $('labels').append(el); labels.push({ c: goal.c, r: goal.r, y: visualHeight(currentMap(), goal.c, goal.r) + 8, el });
  }
}
function updateLabels() {
  const w = stage.clientWidth, h = stage.clientHeight;
  const occupied=[];
  for (const label of labels) {
    const p = offsetToWorld(label.c, label.r);
    const v = new THREE.Vector3(p.x, label.y, p.z).project(camera);
    const x = (v.x * .5 + .5) * w, y = (-v.y * .5 + .5) * h;
    const compactHidden=label.priority!==null&&label.priority!==undefined&&
      ((!label.priority&&cameraDistance>190)||occupied.some(p=>Math.abs(x-p.x)<p.width+(label.el.textContent.length*6)&&Math.abs(y-p.y)<23));
    label.el.style.display = compactHidden || (!editing&&!observerView()&&!terrainKnown(game,playerTeam,label.c,label.r)) || (label.middleEarth&&!boardView&&cameraDistance<88) || v.z < -1 || v.z > 1 || x < -50 || x > w + 50 || y < -30 || y > h + 30 ? 'none' : '';
    if(label.priority!=null&&label.el.style.display!=='none')occupied.push({x,y,width:label.el.textContent.length*6});
    label.el.style.left = `${x}px`; label.el.style.top = `${y}px`;
  }
}
function playMeteorFall(event) {
  if (meteorFall) { meteorFall.geometry.dispose(); meteorFall.material.dispose(); meteorFall = null; }
  meteorGroup.clear();
  const geometry = new THREE.SphereGeometry(0.85, 7, 5);
  const material = new THREE.MeshBasicMaterial({ color: 0xff8940 });
  const shots = event.strikes.map((p, i) => {
    const world = offsetToWorld(p.c, p.r), ground = visualHeight(game.map, p.c, p.r) + 1;
    const body = new THREE.Mesh(geometry, material);
    body.position.set(world.x, ground + 40, world.z); meteorGroup.add(body);
    return { body, ground, delay: (i % 5) * 65 };
  });
  meteorFall = { started: performance.now(), shots, geometry, material };
}
function updateMeteorFall(time) {
  if (!meteorFall) return;
  let finished = true;
  for (const { body, ground, delay } of meteorFall.shots) {
    const progress = Math.max(0, Math.min(1, (time - meteorFall.started - delay) / 650));
    body.visible = progress < 1;
    body.position.y = ground + 40 * (1 - progress) * (1 - progress);
    if (progress < 1) finished = false;
  }
  if (finished) {
    meteorGroup.clear(); meteorFall.geometry.dispose(); meteorFall.material.dispose(); meteorFall = null;
  }
}
function updateSoldierCamera(time = performance.now()) {
  soldierCameraUI.tick();
  if (!soldierCamera.active) return;
  const u = game.map.units.find(u => u.id === soldierCamera.id);
  if (soldierCamera.update(u, unitModels.get(soldierCamera.id), canFollowSoldier(u, playerTeam, battleMode === 'ai-ai') && seen(u), time)) {
    if (lastFollowShadowId !== soldierCamera.id || followShadowCenter.distanceToSquared(soldierCamera.anchor) > 400) {
      terrainEnvironment.focus(soldierCamera.anchor, 80); followShadowCenter.copy(soldierCamera.anchor); lastFollowShadowId = soldierCamera.id;
    }
  }
}
function clearBreachFlash(){
  if(!breachFlash)return;
  scene.remove(breachFlash.mesh);
  breachFlash.mesh.geometry.dispose();
  breachFlash.mesh.material.dispose();
  breachFlash=null;
}
function syncBreachFlash(m){
  const event=game?.middleEarth?.events?.breach,p=m.victory.points?.blast;
  if(editing||!hasCliffNavigation(m)||!event||game.turn-event.turn>1){clearBreachFlash();return;}
  if(event===shownBreach||!p)return;
  shownBreach=event;
  if(!observerView()&&!visibleTo(game,playerTeam,p.c,p.r))return;
  clearBreachFlash();
  const w=offsetToWorld(p.c,p.r);
  const material=new THREE.MeshBasicMaterial({color:0xffa252,transparent:true,opacity:.74,depthWrite:false,toneMapped:false});
  const mesh=new THREE.Mesh(new THREE.RingGeometry(.87,1,48),material);
  mesh.rotation.x=-Math.PI/2;mesh.position.set(w.x,visualHeight(m,p.c,p.r)+1.5,w.z);
  scene.add(mesh);breachFlash={mesh,start:performance.now()};
}
function updateBreachFlash(time){
  if(!breachFlash)return;
  const t=Math.max(0,(time-breachFlash.start)/900);
  if(t>=1){clearBreachFlash();return;}
  breachFlash.mesh.scale.setScalar(2+19*Math.sqrt(t));
  breachFlash.mesh.material.opacity=.82*(1-t);
}
function frame(time) { requestAnimationFrame(frame);battleInteraction?.compass(); unitAnimator.setQuality(params.get('animation')==='low'?'low':animationQuality); if(!navigationPaused){unitAnimator.update(unitGroup,camera,time); updateSoldierCamera(time); updateMeteorFall(time); updateBreachFlash(time);} terrainObj?.update(time); armyFormations.update(camera,time); casualtyLayer.update(camera); renderer.render(scene, camera); updateLabels(); unitHUD.render(camera,{w:stage.clientWidth,h:stage.clientHeight,selectedId,selectedIds:groupIds,following:soldierCamera.active}); }
rebuildScene(); frame(performance.now());
if (troyTrial) $('hint').textContent = '临时体验：特洛伊第 65 回合，阿开亚军费 1000 金；现在即可购买木马。';
else if (battleMode === 'ai-ai') $('hint').textContent = '电脑对电脑观战中，可暂停、单步或调整速度。';
else if (battleMode === 'human-human') $('hint').textContent = '双人轮流操作；结束回合后将设备交给另一位玩家。';
else if (playerTeam === 'coalition') $('hint').textContent = `现在操控${scenario.factions.coalition}；${scenario.factions.egypt}由电脑指挥。右键拖动地图，滚轮缩放`;
else if (scenario.scenarioId === 'china_handan') $('hint').textContent = '邯郸之战：联军须击溃秦军，占领秦军主营地不判胜。';
else if (scenario.victory.mode === 'china') $('hint').textContent = `${scenario.name}：向黄色星标推进${scenario.victory.breach ? '，围城须先打破城墙' : ''}。规则中可查看本战役目标。`;
else if (CLASSICAL_IDS.has(scenario.scenarioId)) $('hint').textContent=classicalInfo(scenario.scenarioId).deployment;
else if (scenario.scenarioId === 'mantinea') $('hint').textContent = '曼提尼亚：斯巴达与特该亚迎战曼提尼亚、阿尔戈斯和雅典联军；重装步兵可切换列阵。';
else if (scenario.scenarioId === 'aegospotami') $('hint').textContent = '羊河口：斯巴达突袭雅典锚地；雅典可护送四支分舰队驶往西侧黄色撤离航道。';
else if (scenario.scenarioId === 'kadesh') $('hint').textContent = '卡迭石：双方后队将陆续入场；右键拖动地图，滚轮以光标为中心缩放';
else if (scenario.scenarioId === 'troy') $('hint').textContent = '特洛伊：赫克托第 21 回合出城，阿喀琉斯第 25 回合参战；第 61 回合起可花 600 金购买一次木马';
else if (scenario.scenarioId === 'qarqar') $('hint').textContent = '卡尔卡尔：攻城后争夺南向道路；低士气士兵会失控溃逃';
else if (scenario.scenarioId === 'babylon') $('hint').textContent = '巴比伦：波斯军分布在河流两岸，可点击右侧部队列表定位东岸军；步兵可登墙救援流亡者';
else if (scenario.scenarioId === 'gaugamela') $('hint').textContent = '高加米拉：方阵可切换行动与列阵，列阵时正面强、背面弱；受惊战象会无差别踩踏';
else if (scenario.scenarioId === 'issus') $('hint').textContent = '伊苏斯：海岸与山麓之间渡河交战；方阵正面强，波斯骑兵集中于海岸';
else if (scenario.scenarioId === 'tyre') $('hint').textContent = '推罗：工程队可同时修筑同一条宽堤道的三列；第 4 回合马其顿舰队抵达';
else if (scenario.scenarioId === 'cannae') $('hint').textContent = '坎尼：罗马军团可转向；迦太基中央步兵可有序后撤，骑兵须从两翼合围';
else if (scenario.scenarioId === 'zama') $('hint').textContent = '扎马：罗马三线军团留出战象通道；选中军团可切换行动与列阵，并选择列阵方向';
else if (scenario.scenarioId === 'pharsalus') $('hint').textContent = '法萨卢斯：庞培骑兵集中于一翼；恺撒第四线精锐反击骑兵时伤害增加';
else if (scenario.scenarioId === 'teutoburg') $('hint').textContent = '条顿森林：罗马纵队沿林道向西突围；林地山坡遮挡视线并拖慢行军';
else if (scenario.scenarioId === 'jerusalem') $('hint').textContent = '耶路撒冷：提图斯率军逐层突破三道城墙；黄色星标指向当前攻城目标';
else if (scenario.scenarioId === 'syracuse') $('hint').textContent = '叙拉古：陆海夹攻，打破外墙与内墙后占领黄色目标；机械塔压制舰船';
else if (scenario.scenarioId === 'pydna') $('hint').textContent = '彼得那：方阵平地正面强；罗马军在崎岖地形攻击方阵可利用缺口';
else if (scenario.scenarioId === 'carrhae') $('hint').textContent = '卡莱：罗马向西突围；帕提亚骑射手佯退回射，靠近骆驼补箭';
else if (scenario.scenarioId === 'actium') $('hint').textContent = '亚克兴角：屋大维守住海口；安东尼护送两艘指挥舰和三支护航舰突破西侧出口';
else if (scenario.scenarioId === 'carthage') $('hint').textContent = '迦太基：舰队压制军港，运兵船可驶入港内登陆；弓箭手与扭力抛石机支援陆军攻城';
else if (scenario.scenarioId === 'alesia') $('hint').textContent = '阿莱西亚：电脑罗马优先修筑双环工事，守住24回合；三级城墙极难突破，高卢援军第8回合起增加';
function eventHex(ev) {
  const rect = canvas.getBoundingClientRect();
  if(!editing){const id=unitHUD.pick(ev.clientX-rect.left,ev.clientY-rect.top),u=currentMap().units.find(u=>u.id===id&&u.hp>0&&seen(u));if(u)return {c:u.c,r:u.r,unitId:u.id};}
  pointer.set((ev.clientX - rect.left) / rect.width * 2 - 1, -(ev.clientY - rect.top) / rect.height * 2 + 1);
  raycaster.setFromCamera(pointer, camera);
  const groundHit = raycaster.intersectObjects(terrainObj.pickables, false)[0];
  if (!editing && unitGroup && fortGroup) {
    const hit = raycaster.intersectObjects([unitGroup,fortGroup,...(armyFormations.group.visible?[armyFormations.group]:[])], true)[0];
    if(hit?.object.userData.formationIds&&hit.instanceId!==undefined){
      const u=currentMap().units.find(v=>v.id===hit.object.userData.formationIds[hit.instanceId]);
      if(u&&(!groundHit||hit.distance<=groundHit.distance))return {c:u.c,r:u.r,unitId:u.id};
    }
    if (hit?.object?.userData?.unitIds && hit.instanceId !== undefined) {
      const id = hit.object.userData.unitIds[hit.instanceId];
      const wall=currentMap().units.find(u=>u.id===id&&u.hp>0&&seen(u));
      if(wall&&(!groundHit||hit.distance<=groundHit.distance))return {c:wall.c,r:wall.r,unitId:wall.id};
    }
    let object = hit && (!groundHit || hit.distance <= groundHit.distance) ? hit.object : null;
    while (object && !object.userData.unitId) object = object.parent;
    const piece = object && currentMap().units.find(u => u.id === object.userData.unitId);
    if (piece) return { c: piece.c, r: piece.r, unitId:piece.id };
  }
  const point = groundHit?.point || raycaster.ray.intersectPlane(plane, new THREE.Vector3());
  if (!point) return null;
  const p = worldToOffset(point.x, point.z);
  return inBounds(currentMap(), p.col, p.row) ? { c: p.col, r: p.row } : null;
}
function hint(message) { $('hint').textContent = message;battleInteraction?.notice(message);tutorialSystem?.feedback(message); }
function clickCell(c, r, shift = false, unitId = null) {
  tileDetails?.show(currentMap(),c,r,selectedUnit(),editing||observerView()?null:planningState(game,playerTeam));
  if(!editing && groupAvailable()) {
    const own=mobileAt(game.map,c,r);
    if(shift){if(!groupIds.size&&selectable(selectedUnit(),playerTeam))groupIds.add(selectedId);groupIds=toggleSelection(groupIds,own,playerTeam);groupSelectionChanged();return;}
    if(groupIds.size>1||armyArea){
      if(isMorannon(game.map.scenarioId)&&meZone(c,game.map)!==game.middleEarth.view)return;
      const target=(unitId&&liveUnits().find(v=>v.id===unitId))||knownUnitAt(game,playerTeam,c,r);
      if(!armyArea&&target&&selectable(target,playerTeam)){clearGroup();selectedId=target.id;refresh();return;}
      const ids=groupIds.size?[...groupIds]:[selectedId];
      const mode=armyArea?'area':target&&target.team!==playerTeam?'target':'move';
      orderOfficer?.delegates.cancelUnits(ids);
      const result=executeArmyOrder(game,ids,{c,r},{mode,targetId:target?.id,mover:move,
        strike:(...args)=>{const hit=attack(...args);if(hit.ok&&hit.visual)combatFx.play(hit,game.map);return hit;}});
      armyArea=false;
      const reason=result.results.find(v=>v.reason&&!v.finished)?.reason;
      hint(`批量命令 · ${result.moved} 团移动 · ${result.attacked} 团交战 · ${result.completed} 团到位 · ${result.blocked} 团受阻${reason?'：'+reason:''}`);
      refresh();return;
    }
    groupIds.clear();
  }
  if (editing) { paintCell(c, r); return; }
  if(isMorannon(game.map.scenarioId)&&meZone(c,game.map)!==game.middleEarth.view)return;
  const picked=unitId?liveUnits().find(v=>v.id===unitId):null;
  const u = picked||(observerView()?(mobileAt(game.map,c,r)||fortAt(game.map,c,r)):knownUnitAt(game, playerTeam, c, r)), selected = selectedUnit();
  if (game.deploying) {
    if (selected?.team === 'egypt' && selected.kind !== 'fort' && !u && deployUnit(game, selected.id, c, r)) {
      hint(`${unitName(game.map, selected)}部署到 ${c},${r}`); refresh(); return;
    }
    if (u?.team === 'egypt') { selectedId = u.id; refresh(); }
    else hint('只能在蓝色部署区放置埃及棋子。');
    return;
  }
  if (selected && controlledBy(selected,playerTeam) && selected.id !== u?.id && humanCanAct()) {
    const work = game.map.victory.mode === 'alesia' && playerTeam === 'egypt' &&
      alesiaWorkOptions(game, selected).find(p => p.c === c && p.r === r);
    // Clicking a reachable damaged friendly wall moves onto it. Its card button repairs it.
    if (work && !work.blocked && (work.build || !reachable(game, selected).has(key(c, r)))) {
      const result = buildAlesiaWork(game, selected.id, c, r);
      hint(result.ok ? `${result.build ? '新建' : '修复'}${result.ringName}工事，剩余行动 ${selected.actionsLeft}` : result.reason);
      refresh(); return;
    }
    if (selected.aboard && !u && disembark(game, selected.aboard, c, r, selected.id)) {
      hint(`${unitName(game.map, selected)}已登陆`); refresh(); return;
    }
    if (selected.kind === 'transport' && !u && disembark(game, selected.id, c, r)) {
      hint('船上士兵已登陆滩头'); refresh(); return;
    }
    if (u?.kind === 'transport' && controlledBy(u,playerTeam) && embark(game, selected.id, u.id)) {
      hint(`${unitName(game.map, selected)}已登船`); refresh(); return;
    }
    if (u && (!controlledBy(u,playerTeam) || isRouted(u))) {
      if (selected.kind === 'trojanHorse' && reachable(game, selected).has(key(c, r))) {
        const result = move(game, selected.id, c, r);
        if (result.ok) { hint(`木马碾过${unitName(game.map, u)}，敌军被消灭；本回合已移动 1 格`); refresh(); return; }
      }
      if(picked?.kind==='fort')game.preferredFort=picked.id;
      if(game.middleEarth&&picked)game.middleEarth.preferredTarget=picked.id;
      let result;
      try{result=attack(game,selected.id,c,r);}
      finally{delete game.preferredFort;if(game.middleEarth)delete game.middleEarth.preferredTarget;}
      if (result.ok) { orderOfficer?.delegates.cancelUnits([selected.id]);combatFx.play(result, game.map); hint(result.hit ? `命中：城墙 −${fmt(result.fortDamage)}，守军 −${fmt(result.unitDamage)}${result.actionRefunded ? '；英雄击杀，行动力返还' : ''}` : '攻击未命中'); refresh(); return; }
      hint(result.reason); return;
    }
    if (!u || (u.kind === 'fort' && controlledBy(u,playerTeam) && selected.kind !== 'fort')) {
      if(!reachable(game,selected).has(key(c,r))){
        const m=currentMap(),to={c,r};
        const adjacent=distance(selected,to)===1;
        const work=adjacent&&fortificationStep(m,selected,selected,to,sceneWorks);
        const cliff=adjacent&&knownGroundEdge(m,selected,to)&&groundConnection(m,selected,selected,to);
        if(work||cliff){hint(work||cliff);return;}
        clearGroup();selectedId=null;refresh();return;
      }
      const result = move(game, selected.id, c, r);
      if (result.ok) { hint(`移动到 ${c},${r}，剩余行动 ${selected.actionsLeft}${result.riverMove ? selected.kind === 'supplyWagon' ? '；水路慢行耗尽本回合行动' : '；渡口通行耗尽本回合行动' : ''}`); refresh(); return; }
      hint(result.reason); return;
    }
  }
  selectedId = u?.id || null; refresh();
}
function paintCell(c, r) {
  const m = scenario, k = `${c},${r}:${brush}`;
  if(brush==='control-core'){if(gesture?.coreHandled)return;if(gesture)gesture.coreHandled=true;terrainHistory.record(m);const wall=m.units.find(u=>u.kind==='fort'&&u.c===c&&u.r===r);if(wall){editorCoreSite=editorDefenseSites(m).find(t=>t.fortIds.includes(wall.id));$('editor-note').textContent=editorCoreSite?`已选择${editorCoreSite.name}，共${editorCoreSite.fortIds.length}段工事；点击陆地指定唯一核心`:'未找到可绑定工事';}else{const result=assignCore(m,editorCoreSite,c,r);$('editor-note').textContent=result.ok?'核心已设置，整段工事仅由此核心控制':result.reason;if(result.ok){editorCoreSite=null;rebuildScene();}}return;}
  if(brush==='erase-core'){terrainHistory.record(m);m.controlCores=(m.controlCores||[]).filter(p=>p.c!==c||p.r!==r);rebuildScene();return;}
  if (lastPaint === k) return;
  lastPaint = k;
  if (brush === 'select-unit') {
    editorSelectedId = mobileAt(m, c, r)?.id || null;
    syncSelectedEditorUnit();
    return;
  }
  if(!gesture||!gesture.historyRecorded){terrainHistory.record(m);if(gesture)gesture.historyRecorded=true;}
  if (brush === 'plain') { setTerrain(m, c, r, TERRAIN.PLAIN); setHouse(m, c, r, false); }
  else if (brush === 'road') setTerrain(m, c, r, TERRAIN.ROAD);
  else if (brush === 'mountain') setTerrain(m, c, r, TERRAIN.MOUNTAIN);
  else if (brush === 'river') setTerrain(m, c, r, TERRAIN.RIVER);
  else if (brush === 'pass') setTerrain(m, c, r, TERRAIN.ROAD | TERRAIN.MOUNTAIN);
  else if (brush === 'ford') { setTerrain(m, c, r, TERRAIN.ROAD | TERRAIN.RIVER); setBridge(m, c, r, false); }
  else if (brush === 'bridge') { setTerrain(m, c, r, TERRAIN.ROAD | TERRAIN.RIVER); setBridge(m, c, r); }
  else if (brush === 'sea') setTerrain(m, c, r, TERRAIN.SEA);
  else if (brush === 'beach') setTerrain(m, c, r, TERRAIN.BEACH);
  else if (brush === 'house') {
    if (!setHouse(m, c, r)) $('editor-note').textContent = '房屋只能建在平地空格，不能占用道路、城墙或机动兵种位置。';
  } else if (brush === 'erase-house') setHouse(m, c, r, false);
  else if(brush.startsWith('gate')){const wall=currentMap().units.find(u=>u.kind==='fort'&&u.c===c&&u.r===r);if(!setGate(m,c,r,Number(brush.at(-1)),$('unit-team').value,wall?.cityId))$('editor-note').textContent='城门需合法陆地及相同归属的墙段';}
  else if (brush.startsWith('fort')) {
    if (!setFort(m, c, r, Number(brush.at(-1)), $('unit-team').value)) $('editor-note').textContent = m.scenarioId === 'troy' ?
      '城墙不能放在海域或敌方守军所在格；1 级城墙不能容纳战车。' :
      '城墙不能放在河流或敌方守军所在格；1 级城墙不能容纳战车或乘战车的法老。';
  } else if (brush === 'supply') {
    const team = $('unit-team').value;
    const nearest = m.units.filter(u => u.kind === 'fort' && u.team === team && u.hp > 0)
      .sort((a, b) => distance(a, { c, r }) - distance(b, { c, r }))[0];
    if (!nearest || !setSupplyPoint(m, c, r, team, nearest.cityId || null))
      $('editor-note').textContent = '补给点需放在己方城墙围出的陆地上；无城名的自建城墙须在 4 格内。';
  } else if (brush === 'erase-supply') {
    m.supplyPoints = m.supplyPoints.filter(p => p.c !== c || p.r !== r);
  } else if (['depot','muster','sea-muster','erase-depot','erase-muster'].includes(brush)) {
    const result=editLogisticsPoint(m,brush,$('unit-team').value,c,r);$('editor-note').textContent=result.ok?'后勤设施已更新；使用新增后删除可移动陆地设施，支持撤销/重做。':result.reason;
  } else if (brush === 'erase-unit') {
    if (mobileAt(m, c, r)) m.units = m.units.filter(u => u.kind === 'fort' || u.c !== c || u.r !== r);
    else setFort(m, c, r, 0);
  } else if (STATS[brush] && brush !== 'fort') {
    if (!addUnit(m, brush, $('unit-team').value, c, r)) $('editor-note').textContent = m.scenarioId === 'troy' ?
      '此处无法放置该棋子；战车只能驻守 2／3 级己方城墙。' :
      '此处无法放置该棋子；战车和乘战车的法老只能驻守 2／3 级己方城墙。';
    else { editorSelectedId = mobileAt(m, c, r)?.id || null; syncSelectedEditorUnit(); }
  }
  scheduleRebuild();
}
canvas.addEventListener('contextmenu', ev => ev.preventDefault());
canvas.addEventListener('pointerdown', ev => {
  if (!['Battle','Tutorial','MapEditor'].includes(document.body.dataset.page) || gesture || ![0, 1, 2].includes(ev.button)) return;
  const mode=soldierCamera.active ? (ev.button===0&&!spaceHeld?'look-pending':'look') : gestureMode({button:ev.button,editing,space:spaceHeld,shift:ev.shiftKey,box:boxSelect,canSelect:groupAvailable()});
  gesture = { pointerId: ev.pointerId, button: ev.button, mode, x: ev.clientX, y: ev.clientY,
    startX: ev.clientX, startY: ev.clientY,shift:ev.shiftKey,ctrl:ev.ctrlKey||ev.metaKey };
  showFormationPreview();
  canvas.setPointerCapture(ev.pointerId);
  if (mode === 'paint') { lastPaint = ''; const p = eventHex(ev); if (p) paintCell(p.c, p.r); }
  if (ev.button !== 0) ev.preventDefault();
});
const terrainRuleTip = document.createElement('div');
terrainRuleTip.id = 'terrain-rule-tip';
terrainRuleTip.style.cssText = 'position:absolute;right:12px;bottom:12px;pointer-events:none;max-width:360px;padding:7px 10px;background:#14231ed9;color:#eee4c4;font-size:12px;z-index:4;border-radius:5px;white-space:pre-line';
stage.append(terrainRuleTip);let ruleTipAt = 0;
canvas.addEventListener('pointerleave',()=>{terrainRuleTip.textContent='';showFormationPreview();});
canvas.addEventListener('pointermove', ev => {
  const showTip = !gesture && game && performance.now() - ruleTipAt > 100;
  const p = showTip ? eventHex(ev) : null;
  if(showTip){
    const unit=selectedUnit(),to=p&&unit&&!editing&&!navigationPaused&&sceneWorks&&groupIds.size<2&&!armyArea&&reachable(game,unit).get(key(p.c,p.r));
    showFormationPreview(to?{entries:[{from:unit,to,path:to.path}]}:null);
  }
  if (showTip) {
    ruleTipAt=performance.now(); const u=selectedUnit();battleInteraction?.coordinate(p);
    if(p && tile(currentMap(),p.c,p.r) && (editing || observerView() || terrainKnown(game,playerTeam,p.c,p.r))) {
      const m=currentMap(),cost=u?moveCost(planningState(game,playerTeam),u,p.c,p.r):null;
      const destination=!editing&&u?reachable(game,u).get(key(p.c,p.r)):null;
      const preview=!editing&&u?attackPreview(game,u,p.c,p.r):null;
      terrainRuleTip.textContent=`规则 v${game.rulesVersion??10} · 地面高程 ${groundElevation(m,p.c,p.r)} · 含工事平台 ${logicalElevation(m,p.c,p.r)}`+
        (u?`\n本兵种通行成本：${Number.isFinite(cost)?cost:'不可通行'}`:'\n选择部队可查看通行成本与行动力；山区道路不增加距离')+
        (destination?` · 路径成本 ${destination.cost} · 消耗 ${destination.actionCost} 行动力`:'')+
        (preview?.elevation?'\n'+elevationText(preview.elevation):'')+
        (preview?.ramBonus&&isShip(u)?'\n'+ramText(preview.ramBonus):'')+
        (game.rulesVersion>=15&&chargeClass(m,u,game.rulesVersion)?'\n'+(preview?.chargeBonus?chargeText(preview.chargeBonus):'冲锋：本回合连续接近目标至少两格后立即近战；不能累积往返距离'):'');
    }else terrainRuleTip.textContent='';
  }
  if(soldierCamera.active&&soldierCamera.pointerFollow&&!gesture&&!document.querySelector('dialog[open]')){const rect=canvas.getBoundingClientRect();soldierCamera.pointPointer((ev.clientX-rect.left)/rect.width*2-1,(ev.clientY-rect.top)/rect.height*2-1);}
  if (!gesture || ev.pointerId !== gesture.pointerId) return;
  if(gesture.mode==='rotate'){cameraYaw-=(ev.clientX-gesture.x)*.006;cameraPitch=THREE.MathUtils.clamp(cameraPitch+(ev.clientY-gesture.y)*.006,.2,1.48);gesture.x=ev.clientX;gesture.y=ev.clientY;updateCamera();return;}
  if (gesture.mode === 'look-pending' && Math.hypot(ev.clientX-gesture.startX,ev.clientY-gesture.startY)>=6) gesture.mode='look';
  if (gesture.mode === 'look') { soldierCamera.rotate(ev.clientX-gesture.x,ev.clientY-gesture.y); gesture.x=ev.clientX;gesture.y=ev.clientY;soldierCameraUI.sync();return; }
  if (gesture.mode === 'select-pending') {
    if(Math.hypot(ev.clientX-gesture.startX,ev.clientY-gesture.startY)<6)return;
    gesture.mode='select';
  }
  if (['pending','pan-pending'].includes(gesture.mode)) {
    if (Math.hypot(ev.clientX - gesture.startX, ev.clientY - gesture.startY) < 6) return;
    gesture.mode = 'pan';
  }
  if(gesture.mode==='select'){
    const b=$('selection-box'),rect=stage.getBoundingClientRect();b.classList.remove('hidden');
    Object.assign(b.style,{left:`${Math.min(ev.clientX,gesture.startX)-rect.left}px`,top:`${Math.min(ev.clientY,gesture.startY)-rect.top}px`,width:`${Math.abs(ev.clientX-gesture.startX)}px`,height:`${Math.abs(ev.clientY-gesture.startY)}px`});
  }
  if (gesture.mode === 'pan') panTo(ev.clientX, ev.clientY);
  else if (gesture.mode === 'paint' && editing) { const p = eventHex(ev); if (p) paintCell(p.c, p.r); }
});
function endGesture(ev) {
  if (!gesture || ev.pointerId !== gesture.pointerId) return;
  if(ev.type==='pointerup' && gesture.mode==='select' && groupAvailable()) {
    groupIds=rectangleSelection(game.map.units,playerTeam,{x1:gesture.startX,y1:gesture.startY,x2:ev.clientX,y2:ev.clientY},unitScreen,gesture.shift?groupIds:[]);groupSelectionChanged();
  } else if(ev.type==='pointerup' && ['pending','select-pending','look-pending'].includes(gesture.mode) && gesture.button===0) {
    // A click issues orders only below the same drag threshold used by pointermove.
    // Check release distance too: pointermove events can be coalesced or omitted.
    if(Math.hypot(ev.clientX-gesture.startX,ev.clientY-gesture.startY)<6){
      const p=eventHex(ev);
      if(p){
        tileDetails?.show(currentMap(),p.c,p.r,selectedUnit(),editing||observerView()?null:planningState(game,playerTeam));
        const picked=game.middleEarth&&p.unitId?liveUnits().find(v=>v.id===p.unitId):null;
        const u=picked||(observerView()?(mobileAt(game.map,p.c,p.r)||fortAt(game.map,p.c,p.r)):knownUnitAt(game,playerTeam,p.c,p.r));
        if(gesture.ctrl&&groupAvailable()&&selectable(u,playerTeam)){
          groupIds=new Set(game.map.units.filter(v=>v.kind===u.kind&&selectable(v,playerTeam)&&seen(v)).map(v=>v.id));
          selectedId=u.id;groupSelectionChanged();
        }else if(gesture.shift)clickCell(p.c,p.r,true);
        else if(groupIds.size>1||armyArea)clickCell(p.c,p.r,false,p.unitId);
        else if(u&&controlledBy(u,playerTeam)&&u.kind!=='fort'){
          clearGroup();selectedId=u.id;refresh();
        }else{
          clickCell(p.c,p.r,false,p.unitId);
        }
      }else{clearGroup();selectedId=null;refresh();}
    }
  }
  $('selection-box').classList.add('hidden');
  if (canvas.hasPointerCapture(ev.pointerId)) canvas.releasePointerCapture(ev.pointerId);
  gesture = null; lastPaint = '';
}
canvas.addEventListener('pointerup', endGesture);
canvas.addEventListener('pointercancel', endGesture);
canvas.addEventListener('wheel', ev => { ev.preventDefault(); if(!['Battle','Tutorial','MapEditor'].includes(document.body.dataset.page))return; if(soldierCamera.active){soldierCamera.setHeight(soldierCamera.height*Math.exp(ev.deltaY*.0012));soldierCameraUI.sync();}else zoomAt(ev.clientX, ev.clientY, Math.exp(ev.deltaY * 0.0012)); }, { passive: false });
canvas.addEventListener('dblclick', ev => {
  if (!['Battle','Tutorial'].includes(document.body.dataset.page) || editing || groupIds.size>1 || boxSelect) return;
  const p = groundAt(ev.clientX, ev.clientY);
  if (p) { target.set(p.x, 0, p.z); clampCameraTarget(); updateCamera(); }
});

function victoryLabel(s) {
  if(s.middleEarth)return s.victoryReason||'中土章节结束';
  if (s.map.victory.mode==='classical') return ({classical_rout:'敌军主力崩溃',classical_capture:'突破关后出口',classical_escape:'撤离目标达成',classical_hold:'坚守至时限',classical_attrition:'较低损失率',classical_draw:'战场僵持'})[s.victoryReason]||'战役结束';
  if (s.map.victory.mode === 'peloponnesian') return s.victoryReason === 'aegospotami_escape' ? '雅典舰队突围' :
    s.victoryReason === 'aegospotami_blockade' ? '斯巴达完成封锁' :
    s.victoryReason === 'mantinea_draw' ? '战场僵持' :
    s.victoryReason === 'mantinea_attrition' ? '较低损失率' : '敌军主力崩溃';
  if (s.map.victory.mode === 'china') return s.victoryReason === 'kunyang_capture' ? '占领昆阳城' : s.victoryReason === 'china_elimination' ? '击溃敌军至少 80%' :
    s.victoryReason === 'china_rout' ? '击溃秦军' :
    s.victoryReason === 'china_hold' ? '抵挡进攻至回合期限' :
    s.victoryReason === 'china_capture' ? `夺取${s.map.victory.objectiveName}或击溃守军` : '击退进攻军';
  if (s.map.victory.mode === 'syracuse') return s.victoryReason === 'syracuse_capture' ? '攻占叙拉古城心' : '守住叙拉古';
  if (s.map.victory.mode === 'pydna') return s.victoryReason === 'pydna_draw' ? '战场僵持' : s.victoryReason === 'pydna_attrition' ? '较低损失率' : '敌军主力崩溃';
  if (s.map.victory.mode === 'carrhae') return s.victoryReason === 'carrhae_escape' ? '罗马军突围' :
    s.victoryReason === 'carrhae_rout' ? '击退帕提亚骑兵' : '帕提亚完成包围';
  if (s.map.victory.mode === 'jerusalem') return s.victoryReason === 'jerusalem_capture' ? '占领圣殿区与上城' :
    s.victoryReason === 'jerusalem_hold' ? '坚守上城' : '击退攻城军';
  if (s.map.victory.mode === 'teutoburg') return s.victoryReason === 'teutoburg_escape' ? '纵队突破林道' :
    s.victoryReason === 'teutoburg_hold' ? '伏击阻断道路' : '敌方主力崩溃';
  if (s.map.victory.mode === 'actium') return s.victoryReason === 'actium_escape' ? '突破海上封锁' :
    s.victoryReason === 'actium_hold' ? '守住海口' : '敌方舰队崩溃';
  if (s.map.victory.mode === 'pharsalus') return s.victoryReason === 'pharsalus_draw' ? '战场僵持' :
    s.victoryReason === 'pharsalus_attrition' ? '较低损失率' : '敌军主力崩溃';
  if (s.map.victory.mode === 'alesia') return s.victoryReason === 'alesia_join' ? '城内外高卢军会合' : '罗马坚守24回合';
  if (s.map.victory.mode === 'carthage') return s.victoryReason === 'carthage_byrsa' ? '攻占比尔萨' :
    s.victoryReason === 'carthage_clear' ? '击溃罗马攻城军' : '坚守迦太基';
  if (['cannae', 'zama'].includes(s.map.victory.mode)) return s.victoryReason?.endsWith('_draw') ? '战场僵持' :
    s.victoryReason?.endsWith('_attrition') ? '较低损失率' : '敌军主力崩溃';
  if (s.map.victory.mode === 'tyre') return s.victoryReason === 'tyre_capture' ? '攻入推罗内城' :
    s.victoryReason === 'tyre_alexander' ? '亚历山大阵亡' : '坚守推罗';
  if (['gaugamela', 'issus'].includes(s.map.victory.mode)) return s.victoryReason?.endsWith('_alexander') ? '亚历山大阵亡' :
    s.victoryReason?.endsWith('_phalanx') ? '方阵主力崩溃' :
      s.victoryReason?.endsWith('_darius_retreat') ? '大流士撤离' : '波斯军败退';
  if (s.map.victory.mode === 'salamis') return s.victoryReason === 'salamis_bay' ? '稳控安贝拉基湾' :
    s.winner === 'egypt' ? '击溃波斯舰队' : '击溃希腊舰队';
  if (s.map.victory.mode === 'babylon') return s.victoryReason === 'babylon_rescue' ? '解救犹大流亡者' :
    s.victoryReason === 'babylon_cyrus' ? '居鲁士阵亡' :
    s.victoryReason === 'babylon_captive' ? '流亡者遇害' : '战斗结束';
  if (s.map.victory.mode === 'qarqar') return s.victoryReason === 'qarqar_road' ? '控制南向道路' :
    s.victoryReason === 'qarqar_hold' ? '守住南向道路' : '敌军战斗部队全灭';
  if (s.map.victory.mode === 'troy') return s.winner === 'egypt' ? '占领特洛伊' : '滩头清除';
  if (s.map.victory.mode === 'leader_duel') return '敌方君主阵亡';
  return s.winner === 'egypt' ? '联军全灭' : '法老阵亡';
}
function refresh() {
  for(const model of unitModels.values())delete model.userData.previewFacing;
  battleInteraction?.sync();ruleManual?.sync();
  if(editing)ensureAutoElevation(scenario);
  document.getElementById('terrain-rule-tip')?.replaceChildren();
  orderOfficer?.sync();
  soldierCameraUI.sync();
  syncGroupControls();
  batchPhalanx?.sync();
  if (selectedId && !selectedUnit()) selectedId = null;
  const m = currentMap(), factions = m.factions;
  updateMiddleEarthPanel();
  if (!editing && game.kunyangMeteor && shownMeteorEvent !== game.kunyangMeteor) {
    shownMeteorEvent = game.kunyangMeteor;
    playMeteorFall(game.kunyangMeteor);
  }
  $('scenario-select').value = CAMPAIGN_IDS.has(m.scenarioId) || ME_IDS.has(m.scenarioId) || savedMapIds.has(m.scenarioId) ? m.scenarioId : 'megiddo';
  $('battle-mode').value = battleMode;
  $('side-select').value = playerTeam;
  $('side-select').disabled = battleMode !== 'human-ai';
  $('side-picker-label').textContent = battleMode === 'human-ai' ? '操控' : battleMode === 'human-human' ? '轮到' : '观战';
  document.querySelector('.ai-picker').classList.toggle('hidden', battleMode === 'human-human');
  $('auto-speed-picker').classList.toggle('hidden', battleMode !== 'ai-ai');
  $('auto-toggle').classList.toggle('hidden', battleMode !== 'ai-ai');
  $('auto-step').classList.toggle('hidden', battleMode !== 'ai-ai');
  $('auto-toggle').textContent = autoRunning ? '暂停观战' : '继续观战';
  $('auto-toggle').disabled = game.over || editing;
  $('auto-step').disabled = game.over || editing || autoRunning;
  $('ai-difficulty').value = aiDifficulty;
  $('side-select').options[0].textContent = factions.egypt;
  $('side-select').options[1].textContent = factions.coalition;
  $('egypt-name').textContent = factions.egypt;
  $('coalition-name').textContent = factions.coalition;
  $('unit-team').options[0].textContent = factions.egypt;
  $('unit-team').options[1].textContent = factions.coalition;
  const editorTeam = $('unit-team').value;
  for (const btn of document.querySelectorAll('[data-brush]')) if (STATS[btn.dataset.brush]) {
    if (CLASSICAL_IDS.has(m.scenarioId)) {
      btn.hidden=!canPlaceKind(btn.dataset.brush,editorTeam,m.scenarioId)||(!classicalKinds(m.scenarioId,editorTeam).includes(btn.dataset.brush)&&!(['moraleGuard','moraleFlagship'].includes(btn.dataset.brush)&&m.units.some(u=>u.team===editorTeam&&u.kind===btn.dataset.brush)));
      if(!btn.hidden)btn.textContent=unitName(m,{kind:btn.dataset.brush,team:editorTeam});
      continue;
    }
    if (m.scenarioId?.startsWith('custom_') || ['moraleGuard', 'moraleFlagship'].includes(btn.dataset.brush)) {
      btn.hidden = !canPlaceKind(btn.dataset.brush, editorTeam, m.scenarioId) ||
        (!m.scenarioId?.startsWith('custom_') &&
          !m.units.some(u => u.team === editorTeam && u.kind === btn.dataset.brush));
      if (!btn.hidden) btn.textContent = unitName(m, { kind: btn.dataset.brush, team: editorTeam });
      continue;
    }
    btn.hidden = !canPlaceKind(btn.dataset.brush, editorTeam, m.scenarioId) ||
      (m.victory.mode === 'china' ? !CHINA_KINDS.has(btn.dataset.brush) ||
        (btn.dataset.brush === 'chinaFireOx' && m.scenarioId !== 'china_tian_dan') :
        m.scenarioId === 'mantinea' ? !MANTINEA_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'aegospotami' ? !AEGOSPOTAMI_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'cannae' ? !CANNAE_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'zama' ? !ZAMA_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'carthage' ? !CARTHAGE_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'alesia' ? !ALESIA_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'pharsalus' ? !PHARSALUS_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'actium' ? !ACTIUM_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'teutoburg' ? !TEUTOBURG_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'jerusalem' ? !JERUSALEM_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'carrhae' ? !CARRHAE_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'syracuse' ? !SYRACUSE_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'pydna' ? !PYDNA_KINDS.has(btn.dataset.brush) :
        CANNAE_KINDS.has(btn.dataset.brush) || ZAMA_KINDS.has(btn.dataset.brush) || PHARSALUS_KINDS.has(btn.dataset.brush) || ACTIUM_KINDS.has(btn.dataset.brush) || TEUTOBURG_KINDS.has(btn.dataset.brush) || JERUSALEM_KINDS.has(btn.dataset.brush) || CARRHAE_KINDS.has(btn.dataset.brush) || SYRACUSE_KINDS.has(btn.dataset.brush) || PYDNA_KINDS.has(btn.dataset.brush)) ||
      (m.scenarioId === 'actium' ? !ACTIUM_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'aegospotami' ? !AEGOSPOTAMI_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'salamis' ? !['athenianTrireme', 'alliedTrireme', 'phoenicianTrireme', 'imperialTrireme'].includes(btn.dataset.brush) :
        m.scenarioId === 'tyre' ? btn.dataset.brush === 'athenianTrireme' :
        m.scenarioId === 'carthage' ? !CARTHAGE_KINDS.has(btn.dataset.brush) :
        m.scenarioId === 'syracuse' ? !SYRACUSE_KINDS.has(btn.dataset.brush) : isTrireme({ kind: btn.dataset.brush })) ||
      (['phalangite', 'companionCavalry'].includes(btn.dataset.brush) && !['gaugamela', 'issus', 'tyre', 'pydna'].includes(m.scenarioId)) ||
      (btn.dataset.brush === 'engineer' && !['tyre', 'carthage', 'alesia', 'jerusalem'].includes(m.scenarioId)) ||
      (btn.dataset.brush === 'siegeGalley' && !['tyre', 'carthage', 'alesia'].includes(m.scenarioId)) ||
      (['scythedChariot', 'warElephant'].includes(btn.dataset.brush) && !['gaugamela', 'zama'].includes(m.scenarioId)) ||
      (btn.dataset.brush === 'captive' && m.scenarioId !== 'babylon');
    if (!btn.hidden) btn.textContent = unitName(m, { kind: btn.dataset.brush, team: editorTeam });
  }
  if (STATS[brush] && !canPlaceKind(brush, editorTeam, m.scenarioId)) {
    brush = 'road';
    document.querySelectorAll('[data-brush]').forEach(btn => btn.classList.toggle('active', btn.dataset.brush === brush));
  }
  document.querySelector('.title strong').textContent = m.name;
  $('phase').textContent = editing ? '编辑地图' : game.deploying ? '部署阶段 · 山口以西' : game.over ?
    `${game.winner ? `${factions[game.winner]}获胜` : '双方平局'} · ${victoryLabel(game)}` : `${tutorialSystem?.active ? '互动教学 · ' : battleMode === 'ai-ai' ? '电脑对战 · ' : battleMode === 'human-human' ? '双人对战 · ' : ''}${factions[battleMode === 'human-ai' ? playerTeam : game.side]} · 第 ${game.turn} 回合${m.victory.mode === 'qarqar' ? ` · 亚述控路 ${game.qarqarHold}/${m.victory.holdTurns}` :
      m.victory.mode === 'babylon' ? ` · ${game.babylonAlarm ? '城内守军正赶往围院' : '围院尚未遭追击'}` :
      m.victory.mode === 'tyre' ? ` · 宽堤道 ${moleLanes(m).reduce((n,lane) => n + lane.filter(([c,r]) => tile(m,c,r).terrain === TERRAIN.ROAD).length, 0)}/${moleLanes(m).reduce((n,lane) => n + lane.length, 0)}` :
      m.victory.mode === 'carthage' ? ` · ${carthageSeaSecured(game) ? '制海权已取得' : '军港仍有威胁'} · ${game.carthageHarborTaken ? '进攻比尔萨' : '进攻科通港区'}` :
      m.victory.mode === 'alesia' ? ` · 内环 ${m.victory.inner.filter(([c,r]) => !!fortAt(m,c,r)).length}/${m.victory.inner.length} · 外环 ${m.victory.outer.filter(([c,r]) => !!fortAt(m,c,r)).length}/${m.victory.outer.length} · 援军第8回合起` :
      m.victory.mode === 'actium' ? ` · ${playerTeam === 'egypt' ? '守住海口' : '突破封锁'} · 第 ${m.victory.turnLimit} 回合` :
      m.victory.mode === 'carrhae' ? ` · ${playerTeam === 'egypt' ? '向西突围' : '完成包围'} · 第 ${m.victory.turnLimit} 回合` :
      m.victory.mode === 'teutoburg' ? ` · ${playerTeam === 'egypt' ? '向西突围' : '阻断林道'} · 第 ${m.victory.turnLimit} 回合` :
      m.victory.mode === 'syracuse' ? ` · 攻占叙拉古城心 · 第 ${m.victory.turnLimit} 回合` :
      m.victory.mode === 'pydna' ? ` · 崎岖地形中的方阵缺口 · 第 ${m.victory.turnLimit} 回合` :
      m.victory.mode === 'jerusalem' ? ` · 目标 ${Math.min(game.jerusalemStage + 1,m.victory.stages.length)}/${m.victory.stages.length}：${m.victory.stages[Math.min(game.jerusalemStage,m.victory.stages.length-1)].name}` :
      m.scenarioId === 'china_maling' ? ' · 双方歼敌75%获胜（仅阵亡计入）' : m.victory.mode === 'china' ? isChinaEliminationCampaign(m) ?
        ` · 歼敌 80%${m.scenarioId === 'china_kunyang' ? ` · 每${KUNYANG_METEORS.interval}回合${KUNYANG_METEORS.count}颗陨石` : ''}` :
        ` · ${hasChinaCaptureObjective(m) ? `目标 ${m.victory.objectiveName}` : '击溃秦军'}${chinaHoldTurnLimit(m) ? ` · 第 ${chinaHoldTurnLimit(m)} 回合` : ''}` :
      m.victory.mode === 'classical' ? ` · 固定兵力 · 第 ${m.victory.turnLimit} 回合时限` :
      m.victory.mode === 'peloponnesian' ? ` · ${m.scenarioId === 'aegospotami' ? '突袭与西侧撤离航道' : '重装步兵两翼交战'} · 第 ${m.victory.turnLimit} 回合` :
      m.victory.mode === 'salamis' ? ` · 风向${WIND_NAMES[game.weather.windDir]} · 湾区${game.salamisBayThreat ? '受到威胁' : '安全'}` : ''}`;
  $('end-turn').title='快捷键：'+inputMapping.bindings.endTurn.replace('Key','');
  $('end-turn').textContent = game.deploying ? '完成部署 · 开始战斗' : tutorialSystem?.active ? '结束回合 · 继续练习' : battleMode === 'human-human' ? '结束回合 · 交给对方' : '结束回合 · 对方行动';
  $('end-turn').disabled = editing || game.over || battleMode === 'ai-ai' || (!game.deploying && !humanCanAct());
  $('saves').disabled = editing;
  const card = $('selected-card'); card.replaceChildren();
  const u = selectedUnit(), h = document.createElement('h2');
  card.hidden=hasCliffNavigation(m)&&!u&&!editing;
  h.textContent = u ? (u.kind === 'fort' ? `${u.level} 级${u.gate?'城门':'城墙'}` :
    `${unitName(m, u)}${u.formation ? ` · ${u.formation}` : ''}`) : '选择一枚棋子'; card.append(h);
  const lines = u ? [
    ...(u.kind==='fort'?[]:[`等级 LV${growthLevel(u)} · 真正击杀 ${u.kills||0} · ${growthLevel(u)===4?'已满级':`普通晋升 ${u.promotionProgress||0}/${PROMOTION_COSTS[growthLevel(u)]}`}`,u.mutinous?'哗变失控 · 对双方敌对 · 原属 '+factions[u.originalTeam||u.team]:'受本阵营指挥']),
    ...(u.kind==='fort'?[u.gate?'城门 · 仅控制方可经门洞通行':isSolidWall(u)?'完整城墙 · 阻挡地面通行，步兵可按规则登墙':'土堤 · 可驻守工事']:[]),
    `${factions[u.team]} · 位置 ${u.c},${u.r}${u.scout ? ' · 侦察部队' : ''}`,
    `${u.kind === 'trojanHorse' ? '不可破坏（标称耐久 40.0）' : `耐久 ${fmt(u.hp)}/${fmt(u.kind === 'fort' ? FORT_HP[u.level]*(u.gate?.7:1) : u.routed ? 10 : unitMaxHp(m, u))}`} · 护甲 ${u.kind === 'fort' ? FORT_ARMOR[u.level] :
      isFormableInfantry(u) && u.formed ? `正面 ${unitArmor(m, u) + (isRomanLine(u) && m.scenarioId === 'zama' ? 1 : 0)}${game.rulesVersion>=22?'（相邻有效列阵友军另+1）':m.scenarioId === 'zama' ? '' : '（同向相邻友阵可增强）'}／背面 0` :
        unitArmor(m, u)} · 视野 ${unitStats(m, u).vision + (u.scout ? 2 : 0)+(hasCliffNavigation(m)?2:0)}`,
    u.kind === 'fort' ? '' : usesMorale(u) ? `士气 ${moraleOf(u).toFixed(2)}/1.50 · 攻击伤害 ×${moraleOf(u).toFixed(2)}${isRouted(u) ? ' · 已溃逃，底座变灰，双方均可攻击' : ''}${u.moraleBoosts?.length ? ` · 临时加成还剩 ${Math.max(...u.moraleBoosts.map(b => b.remaining))} 回合` : ''}` : '不受士气影响',
    hasCliffNavigation(m)&&!meAir(u)&&u.kind!=='fort'?'蓝色标记可达格 · 琥珀色线标记不可通过的地形边':'',
    m.logistics && u.kind === 'supplyWagon' ? `粮秣 ${((u.supplyStock || 0) + (u.supplyCredit || 0) / 5).toFixed(1)}/24 点 · 累计行军 ${u.supplyTravel || 0}/6 格；近旁士兵逐级传粮，最终距离不限` :
      m.logistics && u.kind==='scout' ? '斥候免补给：不消耗口粮，不受饥饿影响；正常战斗士气仍生效。' : m.logistics && u.kind !== 'fort' ? `饥饿 ${u.hunger || 0}/5 · 饥饿积累 ${u.hungerClock || 0}/2 · 随身口粮 ${u.fedTurns || 0}/${carriedRationCapacity(u)} 回合${u.deepRaider ? ' · 奇袭绕后精锐' : ''} · 满饥持续 ${u.maxHungerTurns || 0}/5` : '',
    u.routed ? '已溃逃：每回合自动移动最多 1 格；攻击和防御为 0，生命值为 1.0；双方都可消耗一次攻击将其击杀。邻近至少三支己方或敌方溃兵时，分别触发一次士气下降或上升；阵势持续时不重复结算。' :
    ['moraleGuard', 'moraleFlagship'].includes(u.kind) ? `${u.kind === 'moraleFlagship' ? '督战舰' : '督战队'}：每个本方回合开始时，自动收拢两格内最多 2 支未贴近敌军的己方${u.kind === 'moraleFlagship' ? '溃船' : '溃兵'}。收拢后士气至少 0.70、耐久为兵种上限的一半，当回合不能行动。` :
    u.kind === 'fort' ? (blastOnlyWall(m,u)?'三级深谷墙 · 只能用萨鲁曼炸药彻底炸毁。':'不可移动、不可主动攻击；护甲只抵消城墙分摊到的伤害。摧毁此段后可以从缺口进入。') :
      u.kind === 'captive' ? '救援目标：不能移动或攻击，也不会自行恢复耐久。居鲁士或流亡者阵亡，巴比伦立即获胜。' :
      u.aboard ? `船上待登陆 · 本回合剩余行动 ${u.actionsLeft} · 选中后点击相邻滩头` :
      hasCliffNavigation(m)?`剩余行动 ${u.actionsLeft} · 当前出发格单次最多 ${movementAllowance({...game,map:m},u).maxSteps} 格`:
      `每回合剩余行动 ${u.actionsLeft}/${u.kind === 'defenseTower' ? 3 : isFord(m, u.c, u.r) ? 1 : 2} · ${u.kind === 'defenseTower' ?
        '固定在城墙上，不能移动' : u.kind==='scout' ? '平地4格 / 道路5格 / 山地2格 / 山地道路4格；混合路线逐格累计成本'+(game.scoutDetectionRadius===3?'。隐蔽：敌方须在3格内且具有有效视野才能发现，离开后不再实时可见。':'') : isFormableInfantry(u) && u.formed ?
        `列阵整回合最多移动 1 格（已移动 ${u.formationSteps || 0} 格）` :
        `每次基础移动最多 ${u.alexander ? 3 : isRomanLine(u) ? STATS.light.move : unitStats(m, u).move} 格${u.kind === 'trojanHorse' ? '；每回合总共只能移动 1 格，道路不加速' : isShip(u) ? '，仅限海域' : '；从道路出发 +1 格（地形影响通行）'}`}`,
    ['fort', 'captive'].includes(u.kind) ? '' : u.kind === 'arrowCamel' ?
      '非战斗补给单位：每个帕提亚回合开始时，为两格内骑射手补充最多 3 支箭。' :
      u.kind === 'parthianHorseArcher' ?
      `骑射射程 3 格，每回合最多射击一次；现有箭矢 ${u.ammo}/6。从相邻罗马军身边撤到两格外后，本回合回射伤害 +1.5。靠近驮箭骆驼可补箭。` :
      u.kind === 'parthianCataphract' ? '具装骑兵：移动至少 2 格后发动近战冲击，额外造成伤害。' : u.kind === 'romanOnager' ?
      '扭力抛石机射程 2—5 格，每回合最多发射一次；不能入城墙或房屋。' : u.kind === 'siegeTower' ?
      '大型木制攻城塔：远程攻击射程 4 格，每回合最多发射一次；可压制城墙守军，但不能进入城墙、房屋或无路山地。' : u.kind === 'defenseTower' ?
      `固定城墙设施；弩炮远程攻击 ${unitStats(m, u).ranged}，对舰攻击力额外 +2，射程 ${unitStats(m, u).range}，每回合最多开火三次（已开火 ${u.attacksUsed || 0} 次）。所在城墙被击毁时防御塔一同倒塌。` : u.kind === 'engineer' ?
      '无攻击能力；耐久 6.0、护甲 0，需要作战部队保护。' : u.kind === 'siegeRam' ?
      '仅能撞击相邻城墙；车内自带操作人员，基础破墙伤害 12.0，城墙护甲照常抵消。' : u.kind === 'trojanHorse' ?
      '基础攻击属性 8；只能主动攻击相邻城墙，每次固定造成 40.0 耐久伤害，命中率 100%，无视城墙护甲与驻军分伤。前进到相邻敌军所在格时自动消灭该单位。' : u.kind === 'hero' ?
      `近战随机攻击 6—12（高值更稀少）/ ${unitStats(m, u).meleeHit}% · 一次投矛，射程 2 / ${unitStats(m, u).rangedHit}% · 剩余投矛 ${u.ammo}` :
      `近战 ${meleePower(u, m)} / ${meleeHitChance(u, m)}% · 远程 ${rangedPower(m, u)} / ${unitStats(m, u).rangedHit}% · 射程 ${unitStats(m, u).range} · ${u.kind === 'hittiteChariot' ? '投矛' : u.kind === 'chinaCrossbow' ? '弩矢' : isShip(u) ? '齐射' : '箭矢'} ${u.ammo}`,
    u.kind === 'chinaFireOx' ? '火牛阵移动至少两格后的近战额外造成3.0伤害；仅用于即墨反击剧本。' : '',
    u.kind === 'chinaCrossbow' ? `弩兵本回合已攻击 ${u.attacksUsed || 0}/${crossbowAttackLimit(m, u)} 次。未移动时，每名相邻且未溃逃的己方弩兵使攻击上限 +1，最多 3 次；前两次攻击各消耗一次基础行动，第三次可在行动耗尽后追加。移动一次后只可攻击一次，移动两次后不能攻击；近战、防护与耐久较弱。` : '',
    u.kind === 'chinaHeavyChariot' ? '四马重战车：可在平原、道路、渡口及桥梁部署、移动和作战，不能入山地、无渡口河道、滩头或城墙；相邻近战、距离两格内射击，移动至少两格后近战冲击额外造成2.0伤害。' : '',
    u.kind === 'transport' ? `载重 ${cargoLoad(m, u)}/2：${cargoOf(m, u).map(v => unitName(m, v)).join('、') || '空船'}；点相邻滩头让第一名载员登陆。` : '',
    u.kind === 'warship' ? `每回合最多攻击 1 次；本回合已攻击 ${u.attacksUsed || 0} 次。海上近战，向岸上或远处目标齐射。` : '',
    u.kind === 'trojanHorse' ? '特洛伊木马不可被攻击或踩踏损坏；每局只能购买一次，购入后下一次本方回合起行动。' : '',
    isTrireme(u) ? `舰首朝${facingName(u.facing)}；${u.kind === 'siegeGalley' ?
      '攻城船以远程投射为主，近战没有冲角伤害加成。' :
      `${game.rulesVersion>=20?'本回合沿船首连续接近至少两格后立即近战，船首±30°内撞击侧舷或船尾，默认伤害×2；正面×1并承受普通伤害25%的反作用。原地转向、射箭不获加成。':'旧规则：相邻船首对侧舷伤害×3。'}`}航行后朝向最后一步的方向；主动转向消耗 1 次行动。每回合最多攻击 1 次。${u.commander ? '指挥舰增加视野，附近友舰士气 +0.1；指挥舰不受士气影响。' : ''}` : '',
    u.cloudCovered ? '位于云团下：视野缩短 2 格，移动上限减少 1 格，普通单位有效士气最高 0.90。' : '',
    u.kind === 'chariot' ? '战车弓兵可在 1—2 格射箭；普通地形一次移动走满 3 格后，仍可用剩余行动射击。' : '',
    u.kind === 'hero' ? '直接击杀目标棋子会返还本次攻击的 1 点行动力，可连续攻击；击毁城墙不触发。普通兵种对英雄的伤害减半；英雄互斗无额外减伤。每次本方回合开始在平地／道路／滩头恢复 3.0 耐久，己方城墙恢复 4.0；补给点另加 2.0。英雄恢复无需保留行动力。' : '',
    u.kind === 'hero' && m.heroRelease?.team === u.team && game.turn < m.heroRelease.turn ?
      `海边驻留中：第 ${m.heroRelease.turn} 回合开始才能移动、攻击或受到攻击；此前对其攻击无效。` : '',
    u.kind === 'hero' && m.scenarioId === 'troy' && u.team === 'coalition' && game.turn < m.hectorSortieTurn ?
      `城内待命：第 ${m.hectorSortieTurn} 回合起赫克托出城野战；此前不能主动行动，但可以受到攻击。` : '',
    u.kind === 'fort' ? '' : (fortAt(m, u.c, u.r) ?
      `驻守 ${fortAt(m, u.c, u.r).level} 级城墙 · 对墙外敌军伤害 +1.0` :
      houseAt(m, u.c, u.r) ? '驻守房屋 · 所受伤害减少 40% · 房屋没有耐久' : '无城墙'),
    u.kind !== 'fort' && !u.aboard && isFord(m, u.c, u.r) ? '渡口中每回合只有 1 次行动，移动只能前进 1 格；入水、水中前进和上岸都会耗尽本回合行动。输出伤害 −10%，承受伤害 +10%。' : '',
    u.kind !== 'fort' && bridgeAt(m, u.c, u.r) ? '桥梁上按普通道路行动；桥被摧毁后此格恢复为渡口。' : '',
    isFormableInfantry(u) ? u.formed ? game.rulesVersion>=22?'列阵正面180°（含±90°）攻防增强，背面有效防御为0且不能主动攻击。任意朝向的相邻有效列阵友军提供攻防+1，不叠加。主动转向付费。':`列阵模式 · 朝${facingName(u.facing)}。正面±60°攻防增强，其余朝向不能攻击且护甲为 0；整回合最多移动 1 格。${isRomanLine(u) ? m.scenarioId === 'zama' ? '罗马军团正面攻击、护甲各 +1。' : m.scenarioId === 'cannae' ? '同向相邻军团正面攻击 +0.5、护甲 +1。' : '' : '同向相邻方阵正面攻击与护甲各 +1。'}主动转向消耗一次行动。` :
      '行动模式 · 六个方向均可近战，攻防不受朝向影响；攻防、命中率和移动按轻步兵。切换列阵时消耗一次行动，并可同时选择朝向。' : '',
    m.scenarioId === 'cannae' && ['gaulInfantry', 'iberianInfantry'].includes(u.kind) ?
      `可用一次行动有序后撤一格，单回合限一次；后撤后首次承受近战伤害 −20%。${u.withdrawalGuard ? '当前处于后撤掩护。' : ''}` : '',
    u.kind === 'warElephant' ? u.uncontrolled ? '已失控：护甲降为 0、踩踏攻击基数降为 3；无法下令，双方交接回合时无差别踩踏邻兵并自动逃离战场。' :
      '耐久 32.0、近战 8。每次受伤后失控几率：剩余耐久过半 5%，剩余不超过一半 15%，不超过四分之一 55%；扎马的罗马投枪轻兵命中额外 +10 个百分点。' : '',
    u.kind === 'scythedChariot' ? '移动至少 2 格后冲击未以方阵正面迎击的敌人，近战额外伤害 +3.0。' : '',
    u.kind === 'hittiteChariot' ? '仅能投矛一次，命中或落空后均不能再次投掷；移动至少 2 格后，近战步兵额外造成 2.0 伤害。' : '',
    u.kind === 'engineer' ? m.scenarioId === 'tyre' ? '宽堤道的北、中、南三列可以同时推进。紧邻任一蓝色目标时，点击对应列的修筑按钮，消耗一次行动将海面变为可通行道路。' : m.scenarioId === 'alesia' ? '可在蓝色空缺处新建工事；修复尚存的受损工事，每次恢复8.0耐久。敌军邻近不妨碍施工；目标格被敌军占据时不能施工。' : '攻城工程队可进入城墙破口和巷道；本战役的攻城槌车自带操作人员。' : '',
    u.kind === 'siegeGalley' ? '舰载攻城器械远程攻击 13.0、射程 5；适于从海面摧毁城墙。每回合最多攻击一次。' : '',
  ].filter(Boolean) : [battleMode === 'ai-ai' ? '电脑对电脑观战：观察者全图可见，双方AI仍受各自迷雾限制；可暂停、单步或调整速度。' :
    tutorialSystem?.active ? '教学红军不主动进攻。结束回合后，你继续指挥蓝军；真实规则仍然生效。' : battleMode === 'human-human' ? '双人轮流操作：结束回合后交给对方，双方各自查看本方视野。' : '',
    game.deploying ? '选择埃及棋子，在蓝色部署区域重新布阵；准备好后点击「开始战斗」。' :
    m.victory.mode === 'classical' ? classicalBrief(m) :
    m.scenarioId === 'alesia' ? '阿莱西亚城内有高卢骑兵，完整三级城墙极难突破。电脑罗马以双环工事施工、修复与防守为先，坚守24回合，不让城内外高卢军在两道工事之间相邻会合；高卢外援第8回合起每回合增加一支。工兵能新建并快速修复，普通罗马士兵只能修复未被摧毁的受损工事，军团重步兵需先解除列阵。高卢兵邻近不妨碍施工，但不能占据施工目标格。点击受损己方工事可正常移动，修复请使用棋子信息卡上的按钮。' :
    m.scenarioId === 'actium' ? `屋大维舰队击溃 ${m.victory.antonyLosses} 支安东尼分舰队、击毁安东尼或克娄巴特拉的指挥舰，或阻止突围至第 ${m.victory.turnLimit} 回合获胜。安东尼一方击溃 ${m.victory.octavianLosses} 支屋大维分舰队，或让两艘指挥舰与 ${m.victory.escortShips} 支护航舰驶过西侧黄色出口获胜。` :
    m.scenarioId === 'syracuse' ? `罗马军须击破厄庇波莱外墙与阿克拉迪纳内墙各一段，并让步兵占领黄色目标。叙拉古守军击溃 ${m.victory.romanLosses} 支罗马陆军，或坚守至第 ${m.victory.turnLimit} 回合获胜。机械塔可从海墙射击罗马舰船。` :
    m.victory.mode === 'china' ? `${m.intro} ${m.factions[m.victory.attacker]}须${hasChinaCaptureObjective(m) ? `占领${m.victory.objectiveName}或击溃敌军` : '击溃秦军'}${hasChinaCaptureObjective(m) && m.victory.breach ? '，围城时先打开城墙缺口' : ''}；守军可击溃进攻军或击杀进攻军统帅${chinaHoldTurnLimit(m) ? `，或坚守至第${chinaHoldTurnLimit(m)}回合` : ''}。` :
    m.victory.mode === 'peloponnesian' ? m.intro :
    m.scenarioId === 'pydna' ? `罗马军击溃 ${m.victory.macedonianLosses} 支马其顿作战单位获胜；马其顿军击溃 ${m.victory.romanLosses} 支罗马作战单位获胜。罗马重步兵在崎岖地形近战攻击方阵额外获得 2.0 伤害。第 ${m.victory.turnLimit} 回合比较双方损失比例。` :
    m.scenarioId === 'carrhae' ? `罗马护送克拉苏与 ${m.victory.escapeUnits} 支作战部队到西侧黄色出口，或击溃 ${m.victory.parthianLosses} 支帕提亚骑兵获胜。帕提亚击杀克拉苏、击溃 ${m.victory.romanLosses} 支罗马部队，或阻止突围至第 ${m.victory.turnLimit} 回合获胜。骑射手靠近驮箭骆驼自动补箭。` :
    m.scenarioId === 'teutoburg' ? `罗马护送瓦卢斯与 ${m.victory.escapeUnits} 支作战部队到达西侧黄色出口，或击溃 ${m.victory.germanLosses} 支伏击部队获胜。日耳曼军击杀瓦卢斯、击溃 ${m.victory.romanLosses} 支罗马部队，或阻断道路至第 ${m.victory.turnLimit} 回合获胜。` :
    m.scenarioId === 'jerusalem' ? `提图斯须依次突破第三道城墙、第二道城墙、安东尼亚堡、第一道城墙与圣殿区围墙，派步兵占领黄色星标，最终控制上城。守军击杀提图斯、击溃 ${m.victory.romanLosses} 支罗马部队，或坚守至第 ${m.victory.turnLimit} 回合获胜。` :
    m.scenarioId === 'pharsalus' ? `恺撒军击溃 ${m.victory.pompeyLosses} 支庞培作战单位获胜；庞培军击溃 ${m.victory.caesarLosses} 支恺撒作战单位获胜。第四线精锐近战攻击庞培骑兵额外造成伤害。第 ${m.victory.turnLimit} 回合后比较双方损失比例。` :
    m.scenarioId === 'carthage' ? `罗马舰队须压制军港战船和两座弩炮塔；运兵船载有四支罗马步兵，取得制海权后可驶入军港并在港内岸边登陆，也可由玩家选择南岸滩头。弓箭手和扭力抛石机支援攻城。陆军先占科通港区，再占比尔萨城堡获胜。迦太基守军清除罗马陆上攻城部队，或坚守到第 ${m.victory.turnLimit} 回合结束获胜。黄色星标显示当前目标。` :
    ['cannae', 'zama'].includes(m.scenarioId) ? `迦太基击溃 ${m.victory.romanLosses} 支罗马作战部队获胜；罗马击溃 ${m.victory.punicLosses} 支迦太基作战部队获胜。第 ${m.victory.turnLimit} 回合结束后比较损失比例。指挥官阵亡打击士气，不直接判负。` :
    m.scenarioId === 'salamis' ? `希腊击溃 ${m.victory.persianLosses} 支波斯分舰队获胜；波斯击溃 ${m.victory.greekLosses} 支希腊分舰队，或以 ${m.victory.bayShips} 支战船稳控安贝拉基湾一整轮获胜。云团随每轮风向移动。` :
    m.scenarioId === 'tyre' ? `马其顿工程队可同时修筑一条三列宽的堤道，舰队第 4 回合抵达；占领推罗内城获胜。推罗击杀亚历山大或坚守至第 ${m.victory.turnLimit} 回合获胜。` :
    m.scenarioId === 'gaugamela' ? `马其顿迫使大流士退出战场或击溃波斯军获胜；波斯击杀亚历山大或击溃 ${m.victory.phalanxLosses} 支方阵获胜。` :
    m.scenarioId === 'issus' ? `马其顿渡过皮纳鲁斯河，迫使大流士撤离或击溃波斯军获胜；波斯击杀亚历山大或击溃 ${m.victory.phalanxLosses} 支方阵获胜。` :
    m.scenarioId === 'babylon' ? '波斯步兵须在流亡者存活时进入围院完成救援；居鲁士或流亡者阵亡，巴比伦立即获胜。' :
    m.scenarioId === 'qarqar' ? `亚述军连续 ${m.victory.holdTurns} 回合控制南向道路获胜；诸王联军坚守到第 ${m.victory.turnLimit} 回合获胜。` :
    m.scenarioId === 'troy' ? `阿开亚军占领城内星形标记获胜；特洛伊守军清除全部参战的陆上阿开亚棋子获胜。赫克托第 ${m.hectorSortieTurn} 回合出城，阿喀琉斯第 ${m.heroRelease.turn} 回合参战；第 ${m.victory.horseUnlockTurn} 回合起可花 ${m.recruitment?.costs?.trojanHorse ?? 600} 金购买一次木马。没有回合数自动胜利。` :
    m.scenarioId === 'kadesh' ? '拉神军团已遭突袭。双方固定援军将陆续抵达；击杀敌方君主即胜。' :
      battleMode === 'ai-ai' ? '观察者全图可见；双方AI按本局各自侦察情报行动。' :
      '每枚棋子每回合有 2 次行动。移动或攻击各消耗 1 次。未发现的敌军隐藏在战争迷雾中。'].filter(Boolean);
  const chargeLine=chargeUnitCopy(game,u);if(chargeLine)lines.push(chargeLine);
  for (const line of lines.map(line=>normalizeChargeCopy(game,line)).filter(Boolean)) { const p = document.createElement('p'); p.className = 'statline'; p.textContent = line; card.append(p); }
  if (u && !editing && humanCanAct() && controlledBy(u,playerTeam) && !['fort', 'captive', 'defenseTower'].includes(u.kind) && !isShip(u) && !u.aboard) {
    for (const bridge of m.bridges || []) if (distance(u, bridge) <= 1) {
      const button = document.createElement('button');
      button.textContent = `拆桥 · 消耗1次行动（${bridge.c},${bridge.r}）`;
      button.disabled = !canDestroyBridge(game,u,bridge.c,bridge.r);
      button.onclick = () => {
        const result = destroyBridge(game, u.id, bridge.c, bridge.r);
        hint(result.ok ? '桥梁已毁，原址留下渡口' : result.reason);
        refresh();
      };
      card.append(button);
    }
  }
  if(u&&!editing&&controlledBy(u,playerTeam)){const available=humanCanAct()&&!game.deploying&&!game.over,steps=available?reachable(game,u).size:0,targets=available?currentMap().units.filter(v=>hostile(u,v)&&v.hp>0&&attackPreview(game,u,v.c,v.r)).length:0;for(const [label,enabled,reason]of [['移动 · 左键单击高亮地格',steps>0,available?'行动力不足或周围无合法落点':'当前不可指挥'],['攻击 · 左键单击红色目标',targets>0,available?'没有合法攻击目标（射程、视线或行动资源受限）':'当前不可指挥']]){const button=document.createElement('button');button.textContent=label;button.disabled=!enabled;button.title=enabled?label:reason;button.onclick=()=>{rebuildMarks();hint(label);};card.append(button);if(!enabled){const why=document.createElement('small');why.textContent=reason;card.append(why);}}}
  if(u)appendFormationStatus(document,card,{...game,map:m},u);
  if(u){const rules=document.createElement('button');rules.id='unit-rules-link';rules.textContent='属性规则';rules.onclick=()=>ruleManual?.open('units');card.append(rules);const encyclopediaLink=document.createElement('button');encyclopediaLink.id='unit-encyclopedia-link';encyclopediaLink.textContent='查看图鉴';encyclopediaLink.onclick=()=>unitEncyclopedia.open(u.kind,u);card.append(encyclopediaLink);}
  if(u){const close=document.createElement('button');close.textContent='关闭详情';close.onclick=()=>{selectedId=null;clearGroup();refresh();};card.append(close);}
  if(u&&!editing&&humanCanAct()&&controlledBy(u,playerTeam))appendCaptureControls({document,card,state:game,u,hint,refresh});
  if (u && !editing && humanCanAct() && controlledBy(u,playerTeam) && m.victory.mode === 'alesia' && playerTeam === 'egypt') {
    for (const option of alesiaWorkOptions(game, u)) {
      const button = document.createElement('button');
      button.textContent = `${option.build ? '修建' : '修复'}${option.ringName}（${option.c},${option.r}）`;
      button.disabled = game.side !== playerTeam || game.over || u.actionsLeft < 1 || option.blocked || isRouted(u);
      button.onclick = () => {
        const result = buildAlesiaWork(game, u.id, option.c, option.r);
        hint(result.ok ? `${option.build ? '新建' : '修复'}${option.ringName}工事成功` : result.reason);
        refresh();
      };
      card.append(button);
    }
  }
  if (u?.kind === 'engineer' && !editing && humanCanAct() && controlledBy(u,playerTeam) && m.victory.mode === 'tyre') {
    for (const next of nextMoleCells(m)) {
      const button = document.createElement('button');
      const name = moleLanes(m).length === 3 ? ['中列', '北列', '南列'][next.laneIndex] : '堤道';
      button.textContent = `修筑${name}（${next.c},${next.r}）`;
      button.disabled = game.side !== playerTeam || game.over || u.actionsLeft < 1 ||
        distance(u, next) !== 1 || !!mobileAt(m, next.c, next.r);
      button.onclick = () => {
        const result = buildMole(game, u.id, next.c, next.r);
        hint(result.ok ? `${name}延长到 ${result.cell.c},${result.cell.r}；工程队还剩 ${u.actionsLeft} 次行动` : result.reason);
        refresh();
      };
      card.append(button);
    }
  }
  if (u && isTrireme(u) && !editing && humanCanAct() && controlledBy(u,playerTeam)) {
    const controls = document.createElement('div'); controls.className = 'turn-controls';
    const trigger = document.createElement('button'); trigger.textContent = '转向';
    trigger.disabled = game.side !== playerTeam || game.over || u.actionsLeft < 1 || isRouted(u);
    trigger.onclick = () => {
      const choices = document.createElement('div'); choices.className = 'turn-choices';
      bindDirectionClock(document,choices,{facing:u.facing??0,allowHalf:game.rulesVersion>=19,preview:f=>{const model=unitModels.get(u.id);if(model)model.userData.previewFacing=f;},apply:facing=>{const result=turnShip(game, u.id, facing);if(result.ok)orderOfficer?.delegates.cancelUnits([u.id]);const model=unitModels.get(u.id);if(model)delete model.userData.previewFacing;hint(result.ok?'朝向已更新：'+facingName(facing):result.reason);refresh();}});
      controls.replaceChildren(trigger, choices);
      trigger.textContent = '收起方向';
      trigger.onclick = () => { controls.replaceChildren(trigger); trigger.textContent = '转向'; refresh(); };
    };
    controls.append(trigger); card.append(controls);
  }
  if (u && isFormableInfantry(u) && !editing && humanCanAct() && controlledBy(u,playerTeam)) {
    const controls = document.createElement('div'); controls.className = 'turn-controls';
    const mode = document.createElement('button');
    mode.textContent = u.formed ? '解除列阵' : '列阵';
    mode.disabled = game.side !== playerTeam || game.over || u.actionsLeft < 1 || isRouted(u);
    const formationCheck=setPhalanxMode(structuredClone(game),u.id,!u.formed,u.facing??0);if(!formationCheck.ok){mode.disabled=true;mode.title=formationCheck.reason;const why=document.createElement('small');why.textContent=formationCheck.reason;controls.append(why);}
    mode.onclick = () => {
      if (!u.formed) {
        const choices = document.createElement('div'); choices.className = 'turn-choices';
        bindDirectionClock(document,choices,{facing:u.facing??0,formation:game.rulesVersion>=22,allowHalf:game.rulesVersion>=19,preview:f=>previewPhalanx([u.id],f),apply:facing=>{const result=setPhalanxMode(game, u.id, true, facing);if(result.ok)orderOfficer?.delegates.cancelUnits([u.id]);previewPhalanx([u.id],null);hint(result.ok?'朝向已更新：'+facingName(facing):result.reason);refresh();}});
        controls.append(choices); mode.disabled = true;
      } else {
        const result = setPhalanxMode(game, u.id, false);
        if(result.ok)orderOfficer?.delegates.cancelUnits([u.id]);
        hint(result.ok ? `${unitName(game.map, u)}改为行动队形` : result.reason);
        refresh();
      }
    };
    controls.append(mode);
    if (u.formed) {
      const turn = document.createElement('button'); turn.textContent = '转向';
      turn.disabled = mode.disabled;
      turn.onclick = () => {
        const choices = document.createElement('div'); choices.className = 'turn-choices';
        bindDirectionClock(document,choices,{facing:u.facing??0,formation:game.rulesVersion>=22,allowHalf:game.rulesVersion>=19,preview:f=>previewPhalanx([u.id],f),apply:facing=>{const result=turnPhalanx(game, u.id, facing);if(result.ok)orderOfficer?.delegates.cancelUnits([u.id]);previewPhalanx([u.id],null);hint(result.ok?'朝向已更新：'+facingName(facing):result.reason);refresh();}});
        controls.append(choices);
        turn.disabled = true;
      };
      controls.append(turn);
    }
    card.append(controls);
  }
  if (u && m.scenarioId === 'cannae' && ['gaulInfantry', 'iberianInfantry'].includes(u.kind) &&
      !editing && humanCanAct() && controlledBy(u,playerTeam)) {
    const button = document.createElement('button'); button.textContent = '中央有序后撤';
    button.disabled = game.side !== playerTeam || game.over || u.actionsLeft < 1 || isRouted(u) ||
      u.lastWithdrawalTurn === game.turn || u.r >= 42;
    button.onclick = () => {
      const result = withdrawCenter(game, u.id);
      hint(result.ok ? `${unitName(game.map, u)}后撤一格，首次承受近战伤害减少20%` : result.reason);
      refresh();
    };
    card.append(button);
  }
  if (u?.kind === 'supplyWagon' && m.logistics && !editing && humanCanAct() && controlledBy(u,playerTeam)) {
    const button = document.createElement('button'); button.textContent = '在后方补给点购买粮秣';
    button.disabled = game.over || game.side !== playerTeam ||
      !m.logistics.depots[playerTeam].some(p => distance(p, u) <= 1) ||
      (u.supplyStock || 0) >= 12 || game.money[playerTeam] < 2;
    button.onclick = () => { const result = replenishConvoy(game, u.id);
      hint(result.ok ? `运输队补充 ${result.amount} 点粮秣，花费 ${result.cost} 金` : result.reason); refresh(); };
    card.append(button);
  }
  const recruitCard = $('recruit-card');
  recruitCard.classList.toggle('hidden', !(m.recruitment || m.logistics) || editing || battleMode === 'ai-ai');
  if (m.logistics && !editing && battleMode !== 'ai-ai') {
    const l = m.logistics, other = playerTeam === 'egypt' ? 'coalition' : 'egypt';
    $('recruit-balance').textContent = `${factions[playerTeam]} ${game.money[playerTeam]} 金（每回合收入 ${l.income[playerTeam]}，另扣军费） · ${factions[other]} ${game.money[other]} 金`;
    $('recruit-status').textContent = logisticsRouteCut(game, playerTeam) ?
      '补给线被敌军切断，暂时无法召集或补充运输队。' :
      '招募须足额支付，不能透支；战车150金、攻城槌120金，各类召集后间隔3回合。粮车先供给近旁士兵，再沿相邻士兵逐级传粮，返回后方补给点可付费装粮。';
    const locate = $('recruit-locate'); locate.replaceChildren();
    for (const [label, p] of [['定位召集点', l.musters[playerTeam][0]],
      ['定位后方补给点', l.depots[playerTeam][0]]]) {
      const button = document.createElement('button'); button.textContent = label;
      button.onclick = () => { soldierCameraUI.reset(); const q = offsetToWorld(p.c, p.r); target.set(q.x, 0, q.z);
        cameraDistance = 105; updateCamera(); };
      locate.append(button);
    }
    const options = $('recruit-options'); options.replaceChildren();
    const buttons = document.createElement('div'); buttons.className = 'recruit-buttons'; options.append(buttons);
    for (const kind of ['light', 'heavy', 'archer', 'chinaCrossbow', 'cavalry', 'guard', 'moraleGuard', 'supplyWagon', 'chinaHeavyChariot', 'siegeRam']) {
      const button = document.createElement('button');
      const cost = recruitmentCost(game, kind), wait = recruitmentWait(game, kind, playerTeam);
      button.textContent = `${unitName(m, { kind, team: playerTeam })} · ${cost}金${wait ? ` · 再等${wait}回合` : ''}`;
      button.disabled = game.over || game.deploying || game.side !== playerTeam || logisticsRouteCut(game, playerTeam) ||
        !canPlaceKind(kind, playerTeam, m.scenarioId) || wait > 0 || !canAffordRecruitment(game, playerTeam, cost);
      button.onclick = () => { const result = recruitLogistics(game, kind);
        hint(result.ok ? `已召集${unitName(m, result.unit)}，花费 ${result.cost} 金` : result.reason); refresh(); };
      buttons.append(button);
    }
  }
  if (m.recruitment && !editing && battleMode !== 'ai-ai') {
    const r = m.recruitment, other = playerTeam === 'egypt' ? 'coalition' : 'egypt';
    $('recruit-balance').textContent = `${factions[playerTeam]} ${game.money[playerTeam]} 金（每回合 +${r.income[playerTeam]}） · ${factions[other]} ${game.money[other]} 金（每回合 +${r.income[other]}）`;
    if (playerTeam === 'egypt') {
      const at = r.muster.egypt.sea, ship = mobileAt(m, at.c, at.r);
      $('recruit-status').textContent = (ship?.kind === 'transport' && ship.team === playerTeam ?
        `海上召集点已有运兵船，载重 ${cargoLoad(m, ship)}/2。士兵在此登船后才能驶向滩头。` :
        '海上召集点需要己方运兵船；请先购买运兵船，或把现有运兵船驶来。') +
        ` 木马第 ${m.victory.horseUnlockTurn} 回合起可在海边工坊购买一次。`;
    } else {
      const at = r.muster.coalition.land, occupied = mobileAt(m, at.c, at.r);
      $('recruit-status').textContent = occupied ? '城内召集点已有士兵，移开后可继续召集。' : '城内召集点空闲，可以召集士兵。';
    }
    const locate = $('recruit-locate'); locate.replaceChildren();
    for (const [label, point] of playerTeam === 'egypt' ? [['定位海上召集点', r.muster.egypt.sea], ['定位木马工坊', r.muster.egypt.land]] :
      [['定位城内召集点', r.muster.coalition.land], ['定位海上召集点', r.muster.coalition.sea]]) {
      const button = document.createElement('button'); button.textContent = label;
      button.onclick = () => { soldierCameraUI.reset(); const p = offsetToWorld(point.c, point.r); target.set(p.x, 0, p.z);
        cameraDistance = 105; updateCamera(); hint(`${label}：${point.c},${point.r}`); };
      locate.append(button);
    }
    const options = $('recruit-options'); options.replaceChildren();
    for (const [label, kinds] of [['士兵', ['light', 'heavy', 'archer', 'guard', 'chariot', 'hittiteChariot']],
      ['船只', ['transport', 'warship']], ['攻城器械', ['trojanHorse']]]) {
      const title = document.createElement('div'); title.className = 'recruit-group'; title.textContent = label; options.append(title);
      const buttons = document.createElement('div'); buttons.className = 'recruit-buttons'; options.append(buttons);
      for (const kind of kinds) {
        if (!canPlaceKind(kind, playerTeam)) continue;
        const button = document.createElement('button');
        const cost = recruitmentCost(game, kind), wait = recruitmentWait(game, kind, playerTeam);
        button.textContent = `${unitName(m, { team: playerTeam, kind })} · ${cost}金${wait ? ` · 再等${wait}回合` : ''}`;
        button.disabled = game.over || game.deploying || game.side !== playerTeam || wait > 0 || !canAffordRecruitment(game, playerTeam, cost) ||
          (kind === 'trojanHorse' && (game.turn < m.victory.horseUnlockTurn || game.trojanHorsePurchased));
        if (kind === 'trojanHorse') button.title = game.trojanHorsePurchased ? '本局已经购买过木马' :
          `第 ${m.victory.horseUnlockTurn} 回合起可购买，仅限一次`;
        button.onclick = () => {
          const result = recruit(game, kind);
          hint(result.ok ? `已召集${unitName(game.map, result.unit)}，花费 ${result.cost} 金` : result.reason);
          refresh();
        };
        buttons.append(button);
      }
    }
  }
  for (const team of ['egypt', 'coalition']) {
    const list = $(`${team}-list`); list.replaceChildren();
    const units = m.units.filter(x => x.team === team && x.kind !== 'fort' && (team === playerTeam || seen(x)));
    const alive = units.filter(x => x.hp > 0);
    const walls = m.units.filter(x => x.team === team && x.kind === 'fort' && x.hp > 0 && seen(x)).length;
    $(`${team}-count`).textContent = team === playerTeam || editing || battleMode === 'ai-ai' ? `${alive.length} 枚 · ${walls} 墙` : `已发现 ${alive.length} 枚 · ${walls} 墙`;
    for (const v of units) {
      if (v.kind === 'fort' && v.hp <= 0) continue;
      const btn = document.createElement('button');
      btn.className = `${v.hp ? '' : 'dead'}${(editing ? editorSelectedId : selectedId) === v.id ? ' active' : ''}`;
      btn.innerHTML = `<span>${escapeHTML(v.kind === 'fort' ? `${v.level}级城墙` :
        `${unitName(m, v)}${v.formation ? ` · ${v.formation}` : ''}`)}${v.scout ? ' · 侦察' : ''}${v.aboard ? ' · 船上' : ''}${isRouted(v) ? ' · 溃逃' : ''}</span><span>${v.kind === 'trojanHorse' && v.hp > 0 ? '不可破坏' : fmt(v.hp)}${usesMorale(v) ? ` · 士${moraleOf(v).toFixed(2)}` : ''}</span>`;
      btn.onclick = () => {
        if (editing) { editorSelectedId = v.hp > 0 ? v.id : null; syncSelectedEditorUnit(); }
        else selectedId = v.hp > 0 ? v.id : null;
        const p = offsetToWorld(v.c, v.r); target.set(p.x, 0, p.z); updateCamera(); refresh();
      };
      list.append(btn);
    }
  }
  const log = $('log'); log.replaceChildren();
  for (const [i, line] of game.log.map((line, i) => [i, line]).filter(([i]) =>
    battleMode === 'human-human'&&!game.battleOutcome ? !game.logOwners?.[i] || game.logOwners[i] === playerTeam : !hiddenLogIndices.has(i)).slice(-24).reverse()) {
    const p = document.createElement('div'); p.textContent = line; log.append(p);
  }
  scheduleRebuild();
  scheduleAutoTurn();
}
async function showSaveSlots() {
  const list = $('save-slots');
  list.textContent = '正在读取存档…';
  try {
    const response = await fetch('/api/ancient/saves', { cache: 'no-store' });
    if (!response.ok) throw new Error(`存档服务返回 ${response.status}`);
    const slots = await response.json();
    list.replaceChildren();
    for (let i = 1; i <= 8; i++) {
      const record = slots.find(item => item.slot === i);
      const row = document.createElement('div'); row.className = 'save-slot';
      const label = document.createElement('span');
      const time = record?.savedAt ? new Date(record.savedAt).toLocaleString('zh-CN') : '';
      const modeName = { 'human-ai': '人机', 'human-human': '双人', 'ai-ai': '电脑对战' }[record?.battleMode] || '人机';
      label.textContent = record?.scenarioName ? `${i} · ${record.scenarioName} · ${modeName} · 第 ${record.turn} 回合 · ${time}` : `${i} · 空存档位`;
      const saveButton = document.createElement('button'); saveButton.textContent = record?.scenarioName ? '覆盖保存' : '保存';
      saveButton.onclick = async () => {
        try {
          sealHotseatLogs(game.side);
          const payload = createSave(scenario, game, playerTeam,
            { x: target.x, z: target.z, distance: cameraDistance,boardView,yaw:cameraYaw,pitch:cameraPitch }, hiddenLogIndices, battleMode);
          const result = await fetch(`/api/ancient/saves/${i}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
          });
          if (!result.ok) throw new Error(`保存失败（${result.status}）`);
          $('save-status').textContent = `已保存到位置 ${i}：${scenario.name}，第 ${game.turn} 回合。`;
          await showSaveSlots();
        } catch (e) { $('save-status').textContent = e.message; }
      };
      const loadButton = document.createElement('button'); loadButton.textContent = '读取';
      loadButton.disabled = !record?.scenarioName;
      loadButton.onclick = async () => {
        try {
          const response = await fetch(`/api/ancient/saves/${i}`, { cache: 'no-store' });
          if (!response.ok) throw new Error(`读取失败（${response.status}）`);
          const restored = restoreSave(await response.json());
          cancelAutoTurn();
          soldierCameraUI.reset(); unitModels.clear();
          combatFx?.clear(); unitAnimator.clear();
          ({ scenario, game, playerTeam, hiddenLogIndices } = restored);
          battleMode = restored.battleMode;
          if (battleMode === 'human-ai') preferredHumanTeam = playerTeam;
          if (battleMode !== 'human-ai') playerTeam = game.side;
          game.logOwners ||= game.log.map(() => null);
          logOwnerCursor = game.log.length;
          autoRunning = false;
          aiDifficulty = game.aiDifficulty;
          editing = false; selectedId = null; $('editor-panel').classList.add('hidden');
          const focus = offsetToWorld(...scenarioFocus(scenario));
          target.set(Number.isFinite(restored.camera?.x) ? restored.camera.x : focus.x, 0,
            Number.isFinite(restored.camera?.z) ? restored.camera.z : focus.z);
          cameraDistance = Number.isFinite(restored.camera?.distance) ?
            THREE.MathUtils.clamp(restored.camera.distance, 42, maxCameraDistance(game.map)) : initialCameraDistance(scenario.scenarioId,scenario);
          boardView=restored.camera?.boardView===true;cameraYaw=Number.isFinite(restored.camera?.yaw)?restored.camera.yaw:0;cameraPitch=Number.isFinite(restored.camera?.pitch)?THREE.MathUtils.clamp(restored.camera.pitch,.2,1.48):Math.atan2(.68,.73);
          clampCameraTarget(); updateCamera();
          const url = new URL(location.href);
          url.searchParams.set('scenario', scenario.scenarioId || 'megiddo');
          url.searchParams.set('side', playerTeam);
          url.searchParams.set('ai', aiDifficulty);
          url.searchParams.set('mode', battleMode);
          history.replaceState(null, '', url);
          navigationLoaded=true;$('save-dialog').close();
          hint(`已读取位置 ${i}：${scenario.name}，第 ${game.turn} 回合。${battleMode === 'ai-ai' ? '电脑对战已暂停，点击「继续观战」。' : ''}`);
          refresh();
        } catch (e) { $('save-status').textContent = e.message; }
      };
      row.append(label, saveButton, loadButton); list.append(row);
    }
  } catch (e) { list.textContent = `无法读取存档：${e.message}`; }
}
$('saves').onclick = () => {
  if (battleMode === 'ai-ai') { autoRunning = false; cancelAutoTurn(); refresh(); }
  $('save-status').textContent = ''; $('save-dialog').showModal(); showSaveSlots();
};
$('close-saves').onclick = () => $('save-dialog').close();
$('end-turn').onclick = () => {
  if (editing || game.over || battleMode === 'ai-ai') return;
  if (game.deploying) { beginBattle(game); hint('部署完成。每枚棋子可移动两次，攻击消耗一次行动。'); }
  else { const before = game.log.length, acting = game.side; endSide(game);
    if(tutorialSystem?.active&&!game.over){endSide(game,()=>.5);playerTeam='egypt';}
    else if (!game.over && (battleMode === 'human-ai'||game.battlePhase==='pursuit')) playComputerTurn(before);
    if (battleMode === 'human-human') sealHotseatLogs(acting);
    if (!tutorialSystem?.active && !game.over && !game.battleOutcome && battleMode === 'human-human') { playerTeam = game.side; }
    if(!tutorialSystem?.active)selectedId = null;
    hint(game.over ?
    game.winner ? `${game.map.factions[game.winner]}获胜：${victoryLabel(game)}。` : '双方平局：战场僵持。' :
    tutorialSystem?.active ? `第 ${game.turn} 回合：训练蓝军恢复行动。` : battleMode === 'human-human' ? `轮到${game.map.factions[game.side]}。` :
    game.map.scenarioId === 'troy' ? `第 ${game.turn} 回合：双方获得军费后，可在召集点购买兵源。` :
    game.map.scenarioId === 'qarqar' ? `第 ${game.turn} 回合：亚述已控制南向道路 ${game.qarqarHold}/${game.map.victory.holdTurns} 回合。` :
    game.map.scenarioId === 'babylon' ? game.babylonAlarm ? `第 ${game.turn} 回合：巴比伦守军正在赶往围院。` : `第 ${game.turn} 回合：波斯尚未攻入巴比伦外城。` :
    game.map.scenarioId === 'kadesh' || game.map.scenarioId === 'salamis' ? `第 ${game.turn} 回合：${nextReinforcementHint(game)}${game.weather ? `；风向${WIND_NAMES[game.weather.windDir]}` : ''}` : `对方行动完成，轮到${game.map.factions[playerTeam]}。`); }
  refresh();
};
$('auto-toggle').onclick = () => {
  if (battleMode !== 'ai-ai' || game.over || editing) return;
  autoRunning = !autoRunning;
  if (!autoRunning) cancelAutoTurn();
  hint(autoRunning ? '电脑对战继续。' : '电脑对战已暂停，可用「单步」推进一方。');
  refresh();
};
$('auto-step').onclick = () => { if (!autoRunning) stepComputerBattle(); };
$('auto-speed').onchange = () => { if (autoRunning) { cancelAutoTurn(); scheduleAutoTurn(); } };
function nextReinforcementHint(s) {
  const pending = s.map.reinforcements.map((wave, i) => ({ wave, i }))
    .filter(({ i }) => !s.arrivedReinforcements.includes(i));
  if (!pending.length) return '双方预设后队均已入场';
  const nextTurn = Math.min(...pending.map(({ wave }) => wave.turn));
  return pending.filter(({ wave }) => wave.turn === nextTurn)
    .map(({ wave }) => `${s.map.factions[wave.team]}第 ${wave.turn} 回合增援`).join('；');
}
$('restart').onclick = () => { if(!confirm('重新开始会放弃当前未保存的战局，确定重新开始？'))return;startForPlayer(); selectedId = null; const p = offsetToWorld(...scenarioFocus(scenario)); target.set(p.x, 0, p.z); cameraDistance = initialCameraDistance(scenario.scenarioId,scenario); updateCamera(); hint(game.deploying ? '已返回开局部署' : '已重新开始战役'); refresh(); };
$('scenario-select').onchange = async ev => {
  try { scenario = await readScenario(ev.target.value); startForPlayer(); }
  catch (e) { hint(e.message); refresh(); return; }
  editing = false; selectedId = null;
  $('editor-panel').classList.add('hidden');
  const url = new URL(location.href); url.searchParams.set('scenario', ev.target.value); history.replaceState(null, '', url);
  const p = offsetToWorld(...scenarioFocus(scenario)); target.set(p.x, 0, p.z); cameraDistance = initialCameraDistance(scenario.scenarioId,scenario); updateCamera();
  hint(game.deploying ? '先在蓝色区域部署埃及军。' : scenario.victory.mode === 'china' ?
    `${scenario.name}：${hasChinaCaptureObjective(scenario) ? `${scenario.factions.egypt}争夺${scenario.victory.objectiveName}；${scenario.factions.coalition}须守住目标` : `${scenario.factions.egypt}须击溃秦军，占领主营不判胜`}。` :
    CLASSICAL_IDS.has(scenario.scenarioId) ? classicalInfo(scenario.scenarioId).deployment :
    scenario.scenarioId === 'mantinea' ? '曼提尼亚：希腊重装步兵可切换行动和列阵；围绕两翼争夺战线。' :
    scenario.scenarioId === 'aegospotami' ? '羊河口：斯巴达突袭；雅典可向西侧黄色航道护送四支分舰队。' :
    scenario.scenarioId === 'troy' ? '特洛伊：赫克托第 21 回合出城；阿喀琉斯第 25 回合参战；木马第 61 回合起可花 600 金购买一次。' :
    scenario.scenarioId === 'gaugamela' ? '高加米拉：方阵可切换列阵与行动；镰刀战车冲击弱面，战象受伤可能失控。' :
    scenario.scenarioId === 'issus' ? '伊苏斯：马其顿须从海岸与山麓间跨越皮纳鲁斯河；波斯骑兵集中近海翼。' :
    scenario.scenarioId === 'tyre' ? '推罗：工程队可同时修筑一条三列宽的堤道；第 4 回合舰队抵达，可从海上攻墙登陆。' :
    scenario.scenarioId === 'carthage' ? '迦太基：军港弩炮塔可射击海上舰船；罗马运兵船夺取制海权后可驶入港内登陆，弓箭手和扭力抛石机支援陆军攻城。' :
    scenario.scenarioId === 'alesia' ? '阿莱西亚：电脑罗马优先修筑和维护双环工事，坚守24回合；三级城墙极难突破。' :
    scenario.scenarioId === 'actium' ? '亚克兴角：屋大维守住海口；安东尼护送指挥舰与三支护航舰通过西侧黄色出口。' :
    scenario.scenarioId === 'syracuse' ? '叙拉古：陆海两路攻城，破坏两道城墙后占领黄色目标。' :
    scenario.scenarioId === 'pydna' ? '彼得那：罗马军利用崎岖地形切入马其顿方阵缺口。' :
    scenario.scenarioId === 'carrhae' ? '卡莱：罗马军向西突围；帕提亚骑射手佯退回射，驮箭骆驼提供补给。' :
    scenario.scenarioId === 'teutoburg' ? '条顿森林：罗马军沿道路向西突围；日耳曼联军从林地两侧伏击。' :
    scenario.scenarioId === 'jerusalem' ? '耶路撒冷：使用大型攻城塔、撞城槌和扭力抛石机逐层破墙，步兵占领黄色星标。' :
    scenario.scenarioId === 'pharsalus' ? '法萨卢斯：庞培骑兵集结一翼；恺撒第四线精锐可迎击骑兵。' :
    scenario.scenarioId === 'cannae' ? '坎尼：罗马密集军团正面强劲；迦太基中央可有序后撤，骑兵与非洲步兵须完成合围。' :
    scenario.scenarioId === 'zama' ? '扎马：罗马三线军团留有战象通道；军团可切换队形，列阵时可选朝向。' :
    scenario.scenarioId === 'qarqar' ? '卡尔卡尔：亚述攻城后争夺南向道路；低士气部队会失控溃逃。' :
    scenario.scenarioId === 'babylon' ? '巴比伦：波斯步兵须解救围院中的流亡者；居鲁士阵亡则巴比伦获胜。' :
    scenario.scenarioId === 'salamis' ? '萨拉米斯：指挥分舰队争夺海峡与安贝拉基湾；云团每轮随随机风向移动。' :
    scenario.scenarioId === 'kadesh' ? '卡迭石：双方后队将陆续入场；击杀敌方君主即胜。' :
    scenario.scenarioId?.startsWith('custom_') ? `${scenario.name}：自制战役已载入。` : '美吉多：穿越山口击溃联军。'); refresh();
};
$('side-select').onchange = ev => {
  if (battleMode !== 'human-ai') return;
  playerTeam = ev.target.value; preferredHumanTeam = playerTeam;
  startForPlayer(); editing = false; selectedId = null;
  $('editor-panel').classList.add('hidden');
  const url = new URL(location.href); url.searchParams.set('side', playerTeam); history.replaceState(null, '', url);
  const p = offsetToWorld(...scenarioFocus(scenario)); target.set(p.x, 0, p.z); updateCamera();
  hint(game.deploying ? '先在蓝色区域部署埃及军。' : `现在操控${scenario.factions[playerTeam]}；${scenario.factions[playerTeam === 'egypt' ? 'coalition' : 'egypt']}由电脑指挥。`);
  refresh();
};
$('battle-mode').onchange = ev => {
  const previousMode=battleMode;
  battleMode = ev.target.value;
  // Spectating the live battle must retain its followed ID, animations and AP.
  // Starting an edited map or changing between human control modes keeps the
  // existing new-game behavior; neither is an internal spectator transition.
  const retainBattle=!editing&&(previousMode==='ai-ai'||battleMode==='ai-ai');
  cancelAutoTurn(); orderOfficer?.reset();
  if(!retainBattle){
    startForPlayer();editing=false;selectedId=null;
    $('editor-panel').classList.add('hidden');
    const p=offsetToWorld(...scenarioFocus(scenario));target.set(p.x,0,p.z);updateCamera();
  }
  autoRunning=battleMode==='ai-ai';
  if(retainBattle&&battleMode==='ai-ai'){
    const followed=game.map.units.find(u=>u.id===soldierCamera.id);
    playerTeam=followed?.team||playerTeam;
    if(game.deploying)beginBattle(game);
  }else if(retainBattle){
    playerTeam=battleMode==='human-human'?game.side:preferredHumanTeam;
    if(previousMode==='ai-ai'&&battleMode==='human-ai'&&!game.over&&!game.deploying&&game.side!==playerTeam)playComputerTurn();
  }
  const url = new URL(location.href); url.searchParams.set('mode', battleMode); url.searchParams.set('side', playerTeam);
  history.replaceState(null, '', url);
  hint(!retainBattle?'已按当前地图重新开始战役。':battleMode === 'human-human' ? '已退出观战，保留当前战局；双方轮流行动。' :
    battleMode === 'ai-ai' ? '已进入观战，保留当前战局与跟随视角；可暂停或单步。' :
    `已退出观战；你操控${scenario.factions[playerTeam]}，保留当前战局。`);
  refresh();
};
$('ai-difficulty').onchange = ev => {
  aiDifficulty = ev.target.value;
  game.aiDifficulty = aiDifficulty;
  const url = new URL(location.href); url.searchParams.set('ai', aiDifficulty);
  history.replaceState(null, '', url);
  hint(`电脑指挥强度：${ev.target.selectedOptions[0].textContent}。从电脑下一次行动起生效。`);
  refresh();
};
$('help').onclick = () => {
  if (battleMode === 'ai-ai') { autoRunning = false; cancelAutoTurn(); refresh(); }
  if (currentMap().victory.mode==='classical') {
    const m=currentMap();$('help-title').textContent=campaignTitle(m.scenarioId,m.name);$('help-body').innerHTML=classicalHelp(m);$('help-dialog').showModal();return;
  }
  if (currentMap().victory.mode === 'peloponnesian') {
    const m = currentMap(), v = m.victory;
    $('help-title').textContent = campaignTitle(m.scenarioId, m.name);
    $('help-body').innerHTML = `<p>${escapeHTML(m.intro)}</p>` +
      (m.scenarioId === 'mantinea' ?
        `<p>双方须击溃敌军至少四分之三，即 ${v.losses.coalition}／${v.losses.egypt} 支，方可获胜；第 ${v.turnLimit} 回合按损失比例判定。希腊重装步兵可列阵，正面有更强攻防，背面脆弱。左翼、中军、右翼的相对位置据修昔底德记述。</p>` :
        `<p>斯巴达击溃 ${v.losses.coalition} 支雅典分舰队，或封锁至第 ${v.turnLimit} 回合获胜。雅典击溃 ${v.losses.egypt} 支斯巴达分舰队，或护送 ${v.escapeShips} 支战船进入西侧黄色航道获胜。雅典靠岸舰船初始士气较低，表现人员分散；可切换船首方向，侧面撞击更有威力。</p>`) +
      '<p>战场坐标、棋子数、回合与伤亡门槛属于战棋缩放，不是古战场精确测绘。</p>';
    $('help-body').insertAdjacentHTML('beforeend', '<p>地图编辑器可保存战役地形、兵种数值与单支部队名称。溃逃士兵只有 1.0 生命值、每回合逃一格，双方均可消耗一次攻击将其击杀；相邻至少三名己方溃兵使士气下降，三名敌方溃兵使士气上升。</p>');
    $('help-body').insertAdjacentHTML('beforeend','<p>批量行军：左键单击己方部队选择，单击空格移动，单击敌军攻击；左键拖动框选，Shift 点击增减部队，Ctrl 点击选择同类。右键拖动或按住空格拖动平移，中键拖动旋转；右键单击不下令。选中多队后，点击地面批量移动，点击敌军集火。也可用“攻击区域”指定交战区。各队依次按可达落点和剩余行动力执行。按 Alt+1–5 保存编组，按 1–5 调用。</p>');
  if(usesElevationRules(game)) {
    $('help-body').innerHTML=$('help-body').innerHTML.replace('山地射向非山地伤害 +0.5，非山地向山地射击伤害 −1.0，同高度不变，近战不适用','新版近战及远程直接攻击统一按逻辑高差结算，不再叠加旧弓兵高地定值');
    const note=document.createElement('p');note.textContent=(usesMountainMarchRules(game)?'山地通行规则：步兵与补给队无路山地每次行动1格，仍可每回合行动两次；山区道路恢复平原能力，没有额外+1格。骑兵、战车、战象、器械和列阵步兵只可走山区道路。补给队山区及山区道路行程粮耗双倍。':'规则 v11：按路径成本换算行动力。')+'地形悬停提示显示路径与行动力消耗。逻辑地面高程加存活城墙平台等级后计算双方高差；倍率采用当前存档中的配置，同高×1。旧弓兵、阏与下坡和城墙定值伤害不再叠加，射程和阻挡不变。旧存档保留原规则版本。';note.textContent+=` 当前参数：每级增伤 ${game.elevationRules.gain*100}%、减伤 ${game.elevationRules.loss*100}%，倍率 ${game.elevationRules.floor}–${game.elevationRules.ceiling}。`;$('help-body').prepend(note);
  }
  updateChargeHelp(game,$('help-body'));
  $('help-dialog').showModal();
    return;
  }
  if (currentMap().victory.mode === 'china') {
    const m = currentMap(), v = m.victory;
    $('help-title').textContent = campaignTitle(m.scenarioId, m.name);
    $('help-body').innerHTML = `<p>${escapeHTML(m.intro)}</p>` +
      (m.scenarioId === 'china_maling' ? '<p>双方歼灭敌军作战单位至少75%获胜，仅阵亡计入。占领马陵道、击溃或单独击杀统帅不直接判胜。</p>' : isChinaEliminationCampaign(m) ?
        `<p>${m.scenarioId === 'china_kunyang' ? '新朝军占领昆阳城目标也可获胜。' : ''}本场歼敌判胜时阵亡或溃逃均计入。${escapeHTML(m.factions[v.attacker])}须击溃 ${v.losses.coalition} 支敌军作战编组；${escapeHTML(m.factions.coalition)}须击溃 ${v.losses.egypt} 支敌军作战编组，均为对方至少 80%。中军营地仅为地图地标，占领营地、单独击杀统帅或守到原回合期限都不会直接判胜。</p>` :
        `<p>击溃门槛为敌方作战编组的 ${Math.round(armyRoutFraction(m) * 100)}%（阵亡或溃逃均计入）：${escapeHTML(m.factions[v.attacker])}${hasChinaCaptureObjective(m) ? `须占领黄色星标「${escapeHTML(v.objectiveName)}」或击溃 ${v.losses.coalition} 支守军` : `须击溃 ${v.losses.coalition} 支秦军，占领秦军主营地不构成胜利条件`}。${hasChinaCaptureObjective(m) && v.breach ? '占领前须先击毁至少一段敌方城墙；攻城槌车只能攻击相邻城墙。' : ''}${escapeHTML(m.factions.coalition)}可击溃 ${v.losses.egypt} 支进攻军、击杀进攻军统帅${chinaHoldTurnLimit(m) ? `，或守至第 ${chinaHoldTurnLimit(m)} 回合` : ''}获胜。</p>`) +
      (isChinaIronAgeScenario(m.scenarioId) ? '<p>本场双方士兵使用铁器时代战斗规格：耐久 +6.0、护甲 +1、近战和已有远程攻击各 +1.5。攻城槌、城墙与火牛不享受加成。</p>' : '') +
      '<p>友方连续 2 级以上城墙可供墙上士兵按道路方式多移动一格；离墙或中途出现缺口、1 级墙则不享受加成。弓箭手与弩兵在山地或山地城墙上可正常观察和远程攻击射程内目标，射程按六角格距离计算，不计视觉高度；山地射向非山地伤害 +0.5，非山地向山地射击伤害 −1.0，同高度不变，近战不适用；敌军和敌方城墙仍会遮挡射线。先秦四马重战车只能在平原及平原道路行军和作战，不能进入山地、渡口、滩头或城墙；相邻近战与两格内射击都较强，平原冲击移动至少两格后近战伤害另加 2.0。弩兵远程攻击强于弓兵，弩矢 999；未移动时落单每回合只能攻击一次，每名相邻己方弩兵使上限增加一次，最多三次。前两次攻击各占一次行动，若未移动且有两名相邻弩兵，第三次攻击可在行动耗尽后追加；移动一次后仅能攻击一次，移动两次后不能攻击。即墨剧本的火牛阵移动至少两格后近战伤害增加 3.0。双方可在顶部选择操控阵营、电脑强度，并使用八个存档位。地图地形、单位比例和回合时限是游戏化的战术示意。</p>';
    $('help-body').insertAdjacentHTML('beforeend', '<p>地图编辑器可保存战役地形、兵种数值与单支部队名称。溃逃士兵只有 1.0 生命值、每回合逃一格，双方均可消耗一次攻击将其击杀；相邻至少三名己方溃兵使士气下降，三名敌方溃兵使士气上升。</p>');
    if (m.scenarioId === 'china_kunyang') $('help-body').insertAdjacentHTML('beforeend',
      `<p>王邑新军开局兵力已扩充，昆阳城墙提升至 3 级。第 ${KUNYANG_METEORS.interval}、${KUNYANG_METEORS.interval * 2}、${KUNYANG_METEORS.interval * 3}…回合开始时，昆阳交战区随机落下 ${KUNYANG_METEORS.count} 颗陨石；每颗对落点及相邻六格内的新军士兵造成固定 ${fmt(KUNYANG_METEORS.damage)} 耐久伤害，对攻城器械造成 ${fmt(KUNYANG_METEORS.damage * KUNYANG_METEORS.siegeMultiplier)}，重叠落点伤害可叠加。橙色标记显示本轮落点。刘秀军、城墙和双方统帅不受陨石伤害。弩兵可越过己方城墙射击。</p>`);
    $('help-body').insertAdjacentHTML('beforeend','<p>批量行军：左键单击己方部队选择，单击空格移动，单击敌军攻击；左键拖动框选，Shift 点击增减部队，Ctrl 点击选择同类。右键拖动或按住空格拖动平移，中键拖动旋转；右键单击不下令。选中多队后，点击地面批量移动，点击敌军集火。也可用“攻击区域”指定交战区。各队依次按可达落点和剩余行动力执行。按 Alt+1–5 保存编组，按 1–5 调用。</p>');
  if(usesElevationRules(game)) {
    $('help-body').innerHTML=$('help-body').innerHTML.replace('山地射向非山地伤害 +0.5，非山地向山地射击伤害 −1.0，同高度不变，近战不适用','新版近战及远程直接攻击统一按逻辑高差结算，不再叠加旧弓兵高地定值');
    const note=document.createElement('p');note.textContent=(usesMountainMarchRules(game)?'山地通行规则：步兵与补给队无路山地每次行动1格，仍可每回合行动两次；山区道路恢复平原能力，没有额外+1格。骑兵、战车、战象、器械和列阵步兵只可走山区道路。补给队山区及山区道路行程粮耗双倍。':'规则 v11：按路径成本换算行动力。')+'地形悬停提示显示路径与行动力消耗。逻辑地面高程加存活城墙平台等级后计算双方高差；倍率采用当前存档中的配置，同高×1。旧弓兵、阏与下坡和城墙定值伤害不再叠加，射程和阻挡不变。旧存档保留原规则版本。';note.textContent+=` 当前参数：每级增伤 ${game.elevationRules.gain*100}%、减伤 ${game.elevationRules.loss*100}%，倍率 ${game.elevationRules.floor}–${game.elevationRules.ceiling}。`;$('help-body').prepend(note);
  }
  updateChargeHelp(game,$('help-body'));
  $('help-dialog').showModal();
    return;
  }
  const kadesh = currentMap().scenarioId === 'kadesh';
  const troy = currentMap().scenarioId === 'troy';
  const qarqar = currentMap().scenarioId === 'qarqar';
  const babylon = currentMap().scenarioId === 'babylon';
  const salamis = currentMap().scenarioId === 'salamis';
  const gaugamela = currentMap().scenarioId === 'gaugamela';
  const issus = currentMap().scenarioId === 'issus';
  const tyre = currentMap().scenarioId === 'tyre';
  const cannae = currentMap().scenarioId === 'cannae';
  const zama = currentMap().scenarioId === 'zama';
  const carthage = currentMap().scenarioId === 'carthage';
  const alesia = currentMap().scenarioId === 'alesia';
  const pharsalus = currentMap().scenarioId === 'pharsalus';
  const actium = currentMap().scenarioId === 'actium';
  const teutoburg = currentMap().scenarioId === 'teutoburg';
  const jerusalem = currentMap().scenarioId === 'jerusalem';
  const carrhae = currentMap().scenarioId === 'carrhae';
  const syracuse = currentMap().scenarioId === 'syracuse';
  const pydna = currentMap().scenarioId === 'pydna';
  $('help-title').textContent = campaignTitle(currentMap().scenarioId, currentMap().name);
  $('help-body').innerHTML = syracuse ?
    '<p>前213—前212年，马塞卢斯指挥罗马军围攻叙拉古。波利比乌斯记载阿基米德设计的投射器械与抓船装置令罗马海上进攻受阻。本图为战术抽象：机械塔代表多种守城装置，并不表示真实单座塔。</p><p>罗马军须破坏厄庇波莱外墙与阿克拉迪纳内墙各至少一段，再由未溃逃步兵占领黄色城心目标。攻城舰从海上炮击，陆军以撞城槌和扭力抛石机破墙。机械塔对舰船有攻击加成。守军击溃罗马陆军四分之三，或坚守至第36回合获胜。地图与兵数不是精确复原。</p>' : pydna ?
    '<p>前168年，埃米利乌斯·保卢斯率罗马军战胜珀尔修斯的马其顿军。李维和普鲁塔克记载方阵推进至不平地面后阵线出现缺口，罗马人以较灵活的小部队切入。</p><p>马其顿方阵列阵时正面强，背面弱，行动较慢；罗马军团在崎岖山麓近战攻击方阵额外获得2.0伤害。任一方击溃敌军四分之三作战单位获胜。第20回合仍未决胜则比较损失比例。溪流、地形位置、兵数均为游戏示意。</p>' : carrhae ?
    '<p>前53年克拉苏率罗马军迎战苏雷纳的帕提亚骑兵。普鲁塔克记载骑射、具装骑兵，以及用骆驼运箭为骑射手补给。本图的地形、人数和突围出口为可玩性设计，不是战场精确测绘。</p><p>罗马军须护送克拉苏和10支未溃逃部队抵达西侧黄色出口，或击溃帕提亚骑兵四分之三。帕提亚军击杀克拉苏、击溃罗马部队四分之三，或阻止突围至第24回合获胜。双方均无招募。</p><p>骑射手每回合可射击一次，有6支箭；移动脱离相邻罗马部队后，本回合远射伤害额外+1.5。每个帕提亚回合开始时，距离存活驮箭骆驼两格内的骑射手补充最多3支箭。具装骑兵移动至少两格后的近战有冲击加成。保护或摧毁骆驼会改变长期火力。</p>' : jerusalem ?
    '<p>维斯帕芗在公元67年起指挥犹太战争的前期战役；公元70年围攻耶路撒冷的是他的儿子提图斯。约瑟夫斯记载北面有第三、第二、第一道城墙，罗马军使用高大的攻城塔、撞城槌与投石器。本图把北面防线、安东尼亚堡、圣殿区与上城浓缩为战术场景；并非精确测绘或真实作战日程。</p><p>罗马军须按黄色星标依次占领新城、中城、安东尼亚堡、圣殿区与上城。每一阶段须先至少破坏所需城墙的一段，再由存活且未溃逃的罗马步兵占领目标格。大型攻城塔可向4格内目标射击，每回合一次；扭力抛石机可从2—5格炮击，每回合一次；撞城槌仅能攻击相邻城墙。攻城器械不能代替步兵占领目标。</p><p>提图斯阵亡、罗马陆军损失四分之三，或守军坚持至第50回合结束，耶路撒冷守军获胜。双方没有招募或援军。塔、墙耐久、部队数量、目标顺序和回合时限均为游戏设计；提图斯阵亡的守军胜利是架空路线。</p>' : teutoburg ?
    '<p>公元9年，瓦卢斯率领的罗马军团在日耳曼地区遭阿尔米尼乌斯联军伏击。罗马史料记载了崎岖林地、受阻的行军纵队与恶劣天气。本图的道路、林坡、沼泽和阵位都是战术示意；卡尔克里泽遗址与整场战役的精确位置仍存在研究争议。</p><p>罗马有18支军团纵队、6支辅助步兵和3支骑兵，另有瓦卢斯；日耳曼联军有18支部族战士和12支投射兵，另有阿尔米尼乌斯。林地山坡使步兵移动变慢并遮挡视线；道路可加速行军；南侧低地沼泽不可通行。前三回合从林地山坡发起的日耳曼近战获得额外2.0攻击力。</p><p>罗马护送瓦卢斯与至少8支未溃逃部队进入西侧黄色出口，或击溃日耳曼部队四分之三获胜。日耳曼联军击杀瓦卢斯、击溃罗马部队四分之三，或阻断突围至第18回合结束获胜。双方没有招募或援军。第18回合、兵力数量和胜利门槛都是玩法设定。</p>' : actium ?
    '<p>公元前31年，安东尼与克娄巴特拉的舰队从安布拉基亚湾驶出，与屋大维、阿格里帕的舰队交战。本图以西侧爱奥尼亚海、狭窄湾口、北岸和亚克兴角表示战场关系；舰数、队形和航迹是玩法抽象。</p><p>屋大维有23支较快的轻型分舰队；安东尼有24支耐久和护甲较高的重型分舰队，克娄巴特拉有6支埃及快速分舰队。安东尼、克娄巴特拉、屋大维、阿格里帕各有一艘指挥舰。新规则要求本回合沿船首连续接近至少两格后立即近战；侧舷或船尾冲角默认×2，正面不享受完整加成并有反作用。旧存档保留旧规则。</p><p>屋大维击毁或击溃安东尼分舰队四分之三、击毁安东尼或克娄巴特拉的指挥舰，或守住湾口至第18回合获胜。安东尼一方击毁或击溃屋大维分舰队四分之三，或让安东尼与克娄巴特拉的指挥舰以及3支非指挥护航舰进入西侧黄色出口获胜。双方没有招募或援军。古代作者对撤离的动机与过程有不同记述，突围目标是游戏化表达。</p>' : pharsalus ?
    '<p>公元前48年，恺撒与庞培在法萨卢斯决战。恺撒军团较少，在骑兵薄弱的一翼抽出第四线；庞培将优势骑兵、弓手与投石兵集中于该翼。双方阵线、埃尼佩乌斯河及营垒的位置是战术示意，准确战场地点仍有争议。</p><p>恺撒有19支主线军团、4支第四线精锐、3支骑兵、4支轻兵；庞培有44支军团、10支骑兵、5支投射轻兵。指挥官另计。第四线精锐近战攻击庞培骑兵额外造成2.5伤害；庞培骑兵移动至少2格后冲击有额外伤害。双方军团可切换行动与列阵模式。</p><p>恺撒击毁或击溃庞培作战单位四分之三获胜；庞培击毁或击溃恺撒作战单位四分之三获胜。第20回合双方行动结束仍未决出胜负，损失比例较低者获胜，比例相同为平局。指挥官阵亡会打击士气，不直接判负。双方没有招募或援军。</p>' : alesia ?
    '<p>阿莱西亚城由完整的三级城墙包围，每段耐久100.0，普通罗马军团很难正面打开缺口。城内有高卢步兵、弓手、四支骑兵和房屋，城外还有可出击的小队。电脑高卢主力在外援到来前守城，城外小队可干扰罗马施工。电脑罗马优先修筑、修复双环工事，并拦截出城或来援的高卢军；须在第24回合双方行动结束前阻止两军在双重工事之间相邻会合。攻破城池不会使罗马提前获胜；若两军会合，高卢立即获胜。</p><p>罗马开局有29支军团重步兵、13支弓箭手、5支轻步兵和11支工兵，另有凯撒。两道罗马环形工事开局各完成一半，蓝色标记是未完工位置。罗马工兵可紧邻空缺新建1级工事，也可每次恢复8.0耐久；罗马军团重步兵解除列阵后、轻步兵、弓箭手和骑兵只能修复尚存的受损工事，每次恢复3.0耐久。工事完全摧毁后须由工兵重新修建。高卢兵邻近不妨碍施工，但目标格被敌军占据时不能施工。点击受损己方工事可正常进入；若需修复，请点击棋子信息卡上的修复按钮。</p><p>外部高卢援军第8回合开始出现，第8回合1支、第9回合2支，此后每回合比上一回合增加1支。援军到来后城内主力会尝试突围。可在上方切换罗马或高卢阵营。</p>' : carthage ?
    '<p>公元前146年迦太基陷落战术示意。罗马从陆上攻城，并在海上封锁；游戏用西侧外墙、科通港区、街巷和比尔萨城堡表现最后阶段。古城布局、战斗部队与回合比例均为可玩性抽象。</p><p>罗马军有三列桨战船、攻城舰和两艘载有四支步兵的运兵船。军港入口两座弩炮塔位于城墙上，射程4格，每回合最多开火三次；对敌舰攻击力额外+2，耐久24.0。城墙段被毁时塔也会倒塌。击毁迦太基战船与弩炮塔后，电脑罗马军会让运兵船经军港入口驶入，在港内岸边登陆。玩家也可选择南岸滩头或提前冒险登陆。运兵船选中后可让船上的第一支步兵登陆相邻空滩头；也可从部队列表选中指定载员登陆。</p><p>罗马必须先用未溃逃的陆军占领科通港区，再占领比尔萨城堡；黄色星标会转向当前目标。攻城槌只能撞击相邻城墙，罗马攻城舰可远距离炮击。罗马军团统一为可列阵的重步兵，不区分青年兵、壮年兵与后备枪兵。罗马陆军另有四队弓箭手和两台扭力抛石机；抛石机可隔2—5格射击，每回合最多发射一次。迦太基若清除全部罗马陆上攻城部队，或守至第24回合结束即获胜。双方没有招募与援军。指挥官阵亡影响士气，不会直接结束战斗。</p><p>城墙逐段受损，破口可通行；西南城角已闭合。房屋阻碍视线，步兵可入内防守；道路连接港区与比尔萨。可在上方切换罗马或迦太基阵营。</p>' : zama ?
    '<p>前202年扎马会战的可玩战术示意。罗马轻兵位于青年兵前，青年兵、壮年兵和后备枪兵排成三线，列与列之间留出战象通道；意大利骑兵在一翼，马西尼萨率努米底亚骑兵在另一翼。汉尼拔战象列前，雇佣兵、本土步兵、意大利老兵分三层，双方骑兵在侧翼。战场按开阔地表现，准确地点、方位与间距并无可靠的精确测绘。本剧本中双方各有53枚作战棋子，指挥官另计；没有招募或援军。</p><p>罗马击毁或击溃迦太基作战棋子四分之三获胜；迦太基击毁或击溃罗马作战棋子四分之三获胜。第22回合双方行动结束仍未分胜负，则损失比例较低者获胜；相同比例平局。指挥官阵亡影响士气，不会立即决出胜负。战象耐久32.0、护甲4、近战8；失控几率在剩余耐久不超过四分之一时才大幅上升，罗马投枪轻兵命中时额外增加10个百分点。失控战象会无差别踩踏。罗马骑兵绕到迦太基阵线后方进行近战获得额外冲击伤害，代表骑兵回击。</p><p>罗马青年兵、壮年兵和后备枪兵与马其顿方阵一样可切换行动／列阵。行动模式六向攻防一致，单次最多移动2格；列阵正面三向攻防增强、背面三向不能攻击且护甲为0，整回合最多移动1格。切换为列阵消耗一次行动，同时可直接选择六个朝向；已列阵后再转向则另耗一次行动。马其顿方阵也适用选方向规则。布阵、战象通道、骑兵回击与回合数都是游戏层面的战术抽象。</p>' : cannae ?
    '<p>公元前216年坎尼会战的可玩战术复原。罗马军朝南，右侧临奥菲杜斯河；汉尼拔军朝北，伊比利亚与高卢骑兵在河边，努米底亚骑兵在另一翼。高卢、伊比利亚步兵构成前凸中央，非洲重步兵居两侧；迦太基投射轻兵部署在中央主阵线后方。具体战场位置未获明确考古确认，本地图并非精确测绘。</p><p>罗马有58枚作战棋子，迦太基39枚（其中骑兵两翼各6枚）；另有保卢斯、瓦罗和汉尼拔三枚指挥官。双方没有招募、援军、战象、战车或舰船。任何一方击毁或击溃敌军至少四分之三作战棋子获胜：罗马须击溃30枚迦太基棋子，迦太基须击溃44枚罗马棋子。第20回合双方行动结束仍无人获胜，则损失比例较低者获胜，同率平局。指挥官阵亡触发士气打击，不直接结束战斗。</p><p>罗马青年兵、壮年兵和后备枪兵可切换行动／列阵模式：行动模式六向攻防一致、单次最多移动2格；列阵正面三向攻防更强、背面三向不能攻击且护甲为0，整回合最多移动1格。切换列阵消耗一次行动，可同时选择朝向；列阵后主动转向另耗一次行动。左右各有一支同向列阵军团时，正面近战攻击+0.5、护甲+1。后备枪兵抵御骑兵额外获得1.5护甲。迦太基中央高卢、伊比利亚步兵每回合可消耗一次行动向后退一格，下一次承受近战伤害减少20%。重骑兵移动至少2格后的近战冲击额外伤害+1.5。迦太基骑兵或非洲重步兵在罗马阵线两翼各形成至少三枚棋子的侧翼压力时，罗马军团每回合士气下降0.14；击退任意一翼即可停止这一效果。罗马单位有至少三名敌军邻接且后方无空格时，也会受到包围士气下降。原有视野、0.1耐久结算与溃逃机制继续有效。兵种与地形比例是游戏抽象。</p>' : tyre ?
    '<p>公元前332年，推罗是一座离岸岛城。亚历山大从大陆修筑堤道，推罗舰船袭击施工部队；马其顿后来得到腓尼基盟邦舰队支援，从海上封锁并攻破城墙。本地图参考这一地理关系与攻城过程，海岸、港口、城墙和回合数均为可玩性示意，并非精确测绘。</p><p>马其顿占领岛城内星形标记获胜；推罗击杀亚历山大，或坚守到第24回合结束获胜。双方无战场招募。工程队可以同时修筑同一条宽堤道的中、北、南三列：紧邻任一蓝色标记时，点击对应列的按钮，消耗一次行动延长该列一格。三列相接成为一条道路，可运送步兵与攻城槌车。攻城槌车自带操作人员，紧邻城墙即可撞击。马其顿盟邦战船、载兵船和舰载攻城器械船从第4回合起陆续抵达，可以从海上炮击城墙或在滩头登陆。城墙逐段受损，破口开放后方可入城。</p><p>方阵沿用伊苏斯的列阵／行动两种模式，陆军使用铁器时代耐久与攻防增幅。舰载攻城器械船远程攻击13.0、射程5、每回合最多攻击一次；其炮击是舰上投射器械的游戏抽象。推罗守军可从城墙射击，并以舰队截击来援的马其顿舰船。</p>' : issus ?
    '<p>前333年伊苏斯之战。本图是可玩的战术示意：地中海在西、阿马努斯山麓在东，皮纳鲁斯河横贯两军之间；古河道、河口与准确阵位仍有争议。马其顿从南侧进军，亚历山大率伙伴骑兵居右翼；波斯守北岸，希腊雇佣重步兵居中，主力骑兵在近海右翼。东侧山麓另有波斯轻步兵威胁马其顿右翼。</p><p>双方均无新兵招募或援军。马其顿使大流士三世耐久跌至一半并撤离、击杀大流士或击溃波斯战斗部队获胜；波斯击杀亚历山大或击溃马其顿方阵四分之三获胜。指挥官死亡、撤离和方阵崩溃是游戏判定，史实中大流士撤退，双方君主都未在此役阵亡。</p><p>只有近海浅滩、中央渡口与山麓渡口三处狭窄河段可以过河。每次入水、水中行进或上岸都会耗尽本回合行动；河中输出伤害降低10%，受到伤害增加10%。马其顿方阵可切换行动与列阵：行动模式六向攻防一致，近战4、命中率75%、护甲1，与轻步兵相同；列阵正面三向近战5、护甲3，同向友阵相邻再各加1；背面三向不能攻击、护甲0。列阵整回合只可移动1格。双方人类陆军采用铁器时代数值，相对青铜时代同类兵种耐久加6.0、护甲加1、近战及已有远程攻击各加1.5。伊苏斯不配置战象和镰刀战车。</p>' : gaugamela ?
    '<p>前331年高加米拉战术示意图，以波斯预先整平的开阔平原、马其顿中央方阵与两翼骑兵为核心。地图格数、部队数量和相对位置是游戏抽象，并非精确测绘。马其顿使大流士三世耐久跌至一半并撤离、击杀大流士或击溃波斯战斗部队获胜；波斯击杀亚历山大或击溃至少四分之三马其顿方阵获胜。双方不招募新兵。</p><p>本剧本将双方人类陆军设为较晚期的战斗规格：相对早期同类兵种，耐久增加6.0、护甲增加1、近战及已有远程攻击各增加1.5。马其顿方阵兵行动模式六向攻防一致，近战4.0、命中率75%、护甲1、每次行动移动2格，与轻步兵相同；列阵模式正面三向近战5.0、护甲3，背面三向不能进攻、护甲0。与同朝向列阵友军相邻时正面近战与护甲各+1，不叠加。列阵整回合总共只能移动1格，道路也不加速；切换模式或主动转向各消耗一次行动。山地、河流、城墙和房屋内不能新列阵。伙伴骑兵可从侧翼冲击，波斯镰刀战车移动至少2格后冲击未以方阵正面迎击的目标会额外造成3.0伤害。</p><p>阿里安记载大流士军中约有15头来自印度方向的战象，也记载了镰刀战车。镰刀战车投入战斗有较明确的记述；战象实际是否冲锋没有清楚战斗记载。本剧本把战象放在后方预备队，玩家主动投入是可玩性推演。战象耐久32.0、护甲4、近战8；每次受伤后剩余耐久过半时有5%几率失控，不超过一半时为15%，只剩四分之一或更低时才提高到55%。失控后无法下令，护甲降为0，踩踏攻击按基础3.0计算；每次双方交接回合会无差别踩踏所有相邻棋子，然后向远离部队的方向溃逃。</p>' : salamis ?
    '<p>公元前480年的萨拉米斯海战以海峡、安贝拉基湾、基诺苏拉海角、普西塔利亚岛和阿提卡海岸为依据绘成战术示意图。每枚船棋代表一支分舰队；具体船数、阵位与作战时序存在史料争议，地图不是精确测绘。开局希腊20支、波斯18支；波斯第2和第3回合各再进入6支。双方都不招募新船。</p><p>希腊击溃23支波斯分舰队获胜；波斯击溃15支希腊分舰队，或在本方回合结束时有至少4支未溃逃战船处于安贝拉基湾，且在希腊下一回合结束时仍保持至少4支，即获胜。舰船被击沉或因低士气溃逃均计作击溃。指挥舰阵亡只造成士气打击，不会直接决定战役。</p><p>雅典、希腊盟邦、腓尼基、波斯盟邦四类三列桨战船均提高耐久、护甲和攻击，双方同步调整；各类仍有不同速度与攻防。每船每回合最多攻击一次；海战伤害按0.1耐久计算。舰船有六个船首方向；航行后船首自动朝向最后一步。选中己方战船，点击「转向」并选择方向，可消耗1次行动主动修改朝向。只要攻击当时船首正对敌舰侧面，相邻攻击伤害就是普通接舷战的3倍，无需先移动。其他角度按普通伤害结算；较远目标仍可投射攻击。云团区域双方地形仍可见，但云内敌舰须贴近才能发现；云下舰船视野缩短2格，经过云团的单次航行上限减少1格，普通船员有效士气最高0.90。每轮随机刷新六向风，云团沿风向漂移一格。指挥舰不受士气影响，且附近友舰士气+0.1。</p>' : babylon ?
    `<p>本剧本是公元前539年巴比伦陷落的架空救援线。《那波尼德编年史》记载乌格巴鲁率波斯军未经过城内战斗便进入巴比伦，居鲁士稍后入城；没有已知史料证明城内存在犹大流亡者堡垒或此处的处决危机。地图借用已知的幼发拉底河、城墙、城门和王宫布局。空中花园作为「传说中的空中花园」呈现，其确切位置和是否位于巴比伦仍有争议。</p><p>波斯步兵须在犹大流亡者存活时进入围院，在本方回合结束时与其相邻，且流亡者身旁没有巴比伦士兵，才能获胜。围院城墙完全封闭，波斯步兵、弓手、卫队与徒步指挥官可登上己方一级城墙进入；战车、骑兵与攻城槌车不能翻越。流亡者不能移动、攻击或自行恢复耐久。居鲁士或流亡者被击杀，巴比伦立即获胜；本剧本不设回合上限。波斯首次击毁外墙一段或进入外城时，城内强硬派才开始向围院推进。在此之前，守军不能攻击流亡者或围院城墙。</p><p>房屋没有血条，不能被摧毁。步兵、弓手、卫队与徒步指挥官可进入空房屋；战车、骑兵、攻城槌车不能进入。驻屋单位受到攻击时，在普通攻防和士气结算后伤害减少40%，按0.1耐久结算。房屋会阻挡射线与视野；屋内单位可向外射击。驻屋不提高攻击力。波斯攻城槌车自带操作人员，只能破坏城墙。</p>` : qarqar ?
    '<p>前853年，亚述的撒缦以色三世向奥龙特斯河谷进军。《库尔赫石碑》称其攻毁卡尔卡尔城，继而与诸王联军交战；铭文没有说明卡尔卡尔围城时使用了何种器械，所记战果也不能直接视作双方公认的结果。本剧本把围城与野战连续表现，地形和抵达回合是可玩性推演，并非精确复原。</p><p>亚述军须由未溃逃的陆军连续两次在本方回合结束时控制南向道路；联军守到第20回合结束获胜。任一方战斗部队被击溃四分之三，则对方立即获胜。双方指挥官阵亡会打击己方普通单位士气，但不直接结束战役。亚述覆顶攻城槌车自带操作人员，只打相邻城墙，不能攻击士兵；攻城槌车属于依据同期亚述围城形象加入的推演。战车和骑兵用于野战，攻城槌车不计入歼灭条件。</p>' : troy ?
    '<p>这是一张依据希萨尔利克古城、周边平原及古代海岸环境设计的可玩地图，不是有精确测绘依据的特洛伊战争阵形图。城域按北部城堡高地、南部较广的下城绘成一圈不规则城墙；滩头平原设三座小堡垒，城内目标外还有一圈内城墙。下城增设房屋与集会庭院；房屋没有耐久，步兵驻屋受到的最终伤害减少40%，战车不能进入。阿开亚军须抵达城内星形目标；特洛伊守军须清除所有参战且仍在陆地上的阿开亚战斗棋子。驻留海边营帐的阿喀琉斯在第 25 回合前不计入参战陆军。舰船或船上士兵不能代替陆上兵力维持滩头。阿伽门农与普里阿摩斯是双方君主棋子，但其阵亡本身不是本剧本的胜负条件。</p><p>桨帆战船耐久 30.0、护甲 2、海域移动 2 格、近战 7.5、齐射 7.0、射程 2，每回合最多攻击一次。运兵船耐久 20.0、护甲 1、海域移动 1 格、不能攻击、可载 2 枚步兵或 1 枚战车。开局运兵船分布在远海至近岸；后续兵源需用军费购买，不再自动免费抵达。从相邻滩头选择步兵再点己方运兵船可登船；选择运兵船或船上士兵再点相邻空滩头可登陆。船沉则载员一同损失。</p><p>阿喀琉斯与赫克托是英雄棋子：耐久 40.0、护甲 5、移动 2 格；近战攻击和仅有的一次投矛，基础攻击在 6—12 间抽取，越高越少见。普通兵种攻击英雄时，扣除护甲后的伤害再减半；英雄互斗不受额外减伤。英雄攻击直接击杀敌方棋子时返还本次消耗的 1 点行动力，可连续攻击；未命中、击毁城墙和乘员随船覆没不触发，投矛仍会消耗。英雄在平地、道路、滩头每次本方回合开始恢复 3.0 耐久，在己方城墙恢复 4.0；站在补给点可额外恢复 2.0 耐久，英雄无需保留行动力。阿喀琉斯在第 25 回合前留在海边营帐，不能移动、攻击，也不会受到攻击；第 25 回合起参战并可受攻击。赫克托第 20 回合结束后率军出城，第 21 回合起在平原野战；此前城内待命，仍可受到攻击。此回合数是游戏节奏设计；史诗中他因争执退战，帕特罗克洛斯阵亡后才重新出战。</p>' : kadesh ?
    '<p>开局设在拉神军团遭赫梯战车突袭、战车追入阿蒙营地之际。拉美西斯二世率阿蒙军团先到，并非出征时只带少数卫队。双方各预设投入 34 枚战斗棋子：埃及开局 13 枚，第 3、5、6 回合增援；赫梯开局 22 枚，第 3、4、5 回合增援。回合数是游戏节奏设计，不是史料中的精确时刻。没有战场招募。</p><p>双方各有一枚君主：法老与穆瓦塔利二世。击杀敌方君主即获胜，君主可由邻近精锐卫队代挡一次攻击。史实中穆瓦塔利并未阵亡，刺杀胜利属于架空玩法。赫梯重战车近战攻击 4.5；移动至少 2 格后冲击步兵 +2.0 伤害。它还可投出一支长矛，远程攻击 3、射程 2 格、基础命中率 70%，命中或落空后均不能再投。一次性投矛是玩法设定，并非确定史实。</p><p>地形始终可见，敌军位置只有进入己方视野才显示。每枚战斗棋子每回合两次行动，移动或攻击各消耗一次。道路出发移动上限 +1。道路连续，所有兵种只能从渡口过河；水中棋子每回合只有 1 次行动，可移动 1 格或攻击一次；入水和上岸的移动也各只能走 1 格，并耗尽本回合行动。站在河流格时输出伤害降低 10%，承受伤害增加 10%。留有行动的棋子在平地或道路每回合恢复 1.0 耐久、己方城墙内恢复 2.0；山地和河流不恢复。</p>' :
    '<p>开局位于阿鲁纳山口以西。先在蓝色部署区摆放埃及棋子。双方兵力固定，没有招募或援军。</p><p>每枚战斗棋子每回合有 2 次行动。战车基础移动 3 格；重步兵、弓箭手 1 格；卫队、轻步兵、法老 2 格。道路出发上限 +1 格。一次攻击消耗一次行动。弓兵、战车弓兵和法老各有 999 支箭。地形可见，未进入视野的敌军隐藏。</p><p>道路连续，所有兵种只能从渡口过河；水中棋子每回合只有 1 次行动，可移动 1 格或攻击一次；入水和上岸的移动也各只能走 1 格，并耗尽本回合行动。站在河流格时输出伤害降低 10%，承受伤害增加 10%。留有行动的棋子在平地或道路恢复 1.0 耐久，山地和河流不恢复，己方堡垒恢复 2.0。法老阵亡则埃及失败；联军战斗棋子被击溃四分之三则埃及获胜。城墙被击破一段即可从该缺口进入。</p>';
  if (currentMap().victory.routLosses) $('help-body').insertAdjacentHTML('beforeend',
    '<p>各战役的军队击溃门槛按参战作战编组的四分之三计算，预定援军计入对应阵营；城墙、指挥官和无武装补给不充作战编组。占领、突围及指挥官目标仍各按本战役规则结算。</p>');
  $('help-body').insertAdjacentHTML('beforeend',
    '<p>顶部「电脑指挥」可随时切换强度：休闲模式每支电脑部队每回合最多执行一条指令；标准模式沿用原有指挥；精锐模式优先击溃受损目标，并在接近敌军时寻找可攻击和有掩护的位置。强度只改变电脑决策，不改变部队数值，且会随存档保存。</p>');
  $('help-body').insertAdjacentHTML('beforeend',
    '<p>桥梁叠放在渡口格上；完好的桥梁按道路速度通行，每回合保有普通行动次数。双方陆军都可以从桥上或相邻格消耗一次行动摧毁桥梁；桥毁后原格仍是渡口，恢复渡口的慢速与战斗规则。地图编辑器的「桥梁」笔刷会同时设置下层渡口。</p>');
  $('help-body').insertAdjacentHTML('beforeend',
    '<p>地图编辑器可保存战役地形、兵种数值与单支部队名称。溃逃士兵只有 1.0 生命值、每回合逃一格，双方均可消耗一次攻击将其击杀；相邻至少三名己方溃兵使士气下降，三名敌方溃兵使士气上升。</p>');
  $('help-body').insertAdjacentHTML('beforeend',
    '<p>未溃逃士兵留有行动力、未移动或攻击，并且三格内没有可战斗的敌军时，可在本方回合结束休整恢复 0.03 士气；附近四格内有己方指挥官时恢复 0.06，最多恢复至基础士气 1.00。单方超过 30 支作战部队的大型陆战配有督战队；有至少两艘受士气影响舰船的阵营配有督战舰，包括大型海战与围城舰队。督战单位在本方回合开始自动收拢两格内最多两支远离敌军的己方溃兵或溃船。收拢后兵种耐久恢复到一半、基础士气至少 0.70，当回合不能行动；之后可正常休整恢复耐久。饥饿达到 3 的部队须先得到粮秣补给。</p>');
  if (!actium && !teutoburg && !jerusalem && !carrhae && !syracuse && !pydna) $('help-body').insertAdjacentHTML('beforeend',
    '<p>所有具备列阵能力的重步兵开局均处于行动模式，玩家可自行下令列阵。电脑指挥官遭到敌军逼近时会优先撤到更安全的位置；附近卫兵会优先拦截威胁或贴身掩护。</p>');
  if (qarqar || babylon) $('help-body').insertAdjacentHTML('beforeend',
    '<p>铁器时代兵种规则：双方人类陆军相对早期同类兵种增加 6.0 耐久、1 点护甲，近战及已有远程攻击各增加 1.5。城墙、攻城槌、工程队和救援目标不按士兵增幅计算。</p>');
  if (salamis || gaugamela || issus || tyre || cannae || zama || carthage || alesia || pharsalus || actium || teutoburg || jerusalem || carrhae || syracuse || pydna) { $('help-dialog').showModal(); return; }
  if (troy) $('help-body').insertAdjacentHTML('beforeend',
    `<p>第 ${currentMap().victory.horseUnlockTurn} 回合起，阿开亚联军可花 ${currentMap().recruitment?.costs?.trojanHorse ?? 600} 金在海边工坊购买一次特洛伊木马。木马标称耐久 40.0、护甲 30，且不可破坏。基础攻击属性 8；只能主动攻击相邻城墙，每次固定造成 40.0 耐久伤害、命中率 100%，无视城墙护甲与驻军分伤。木马向相邻敌军所在格前进时会自动消灭该单位。每回合最多移动 1 格，道路不加速，购入后下个本方回合才能行动。第 40 回合没有自动胜利，双方仍按占城或清除陆上兵力判定胜负。</p>`);
  if (troy && currentMap().recruitment) {
    const r = currentMap().recruitment, c = r.costs;
    $('help-body').insertAdjacentHTML('beforeend', `<p>阿开亚初始 ${r.startingMoney.egypt} 金，每轮本方回合 +${r.income.egypt} 金；特洛伊初始 ${r.startingMoney.coalition} 金，每轮本方回合 +${r.income.coalition} 金。轻步兵 ${c.light}、重步兵 ${c.heavy}、弓手 ${c.archer}、近卫 ${c.guard}、弓战车 ${c.chariot}、特洛伊重战车 ${c.hittiteChariot}、运兵船 ${c.transport}、桨帆战船 ${c.warship}、特洛伊木马 ${c.trojanHorse} 金。君主和英雄不能购买。阿开亚士兵只能在海上召集点登上停靠的己方运兵船，船再驶向滩头登陆；战车独占一艘运兵船。特洛伊士兵在城内召集点入场，双方舰船在各自海上召集点入场。新买棋子从下一次本方回合起行动。木马在阿开亚海边工坊附近出现，每局只能购买一次。</p>`);
  }
  if (kadesh) $('help-body').insertAdjacentHTML('beforeend', '<p>重步兵、轻步兵的近战基础攻击分别为 3、2.5；法老卫队为 3.5，赫梯君主卫队为 5。伤害按 0.1 耐久结算。</p>');
  $('help-body').insertAdjacentHTML('beforeend', '<p>普通战斗单位的士气范围是 0—1.50，最终攻击伤害乘以当前士气。耐久首次跌破 50% 时士气 −0.10；首次遭到至少 3 名尚能战斗的敌军邻接、且邻接友军不超过 1 名时，士气 −0.12，同一包围状态不会重复扣减；附近友军覆灭每回合最多影响一次，士气 −0.03；本方指挥官阵亡时所有普通单位士气 −0.25。离开指挥官不会自动降低士气；邻近三支以上溃兵的士气影响也只在首次出现该阵势时触发。击杀普通敌军有 50% 概率使击杀者获得临时士气 +0.2；击杀敌方英雄使本方全体普通单位临时 +0.2，击杀敌方指挥官临时 +0.3。临时加成持续 3 个本方回合，士气最高 1.50。低于 0.20 的普通单位不接受移动或攻击指令，在本方回合开始自动远离敌军。英雄、指挥官、旧式桨帆船和攻城车不受士气影响；萨拉米斯普通三列桨战船受士气影响。</p>');
  $('help-body').insertAdjacentHTML('beforeend', '<p>每座堡垒内的绿色「✚ 补给」格可为己方陆军补给：普通士兵停在该格，结束本方回合时保留至少 1 点行动力，下次本方回合开始恢复最多 2.0 耐久；英雄在补给格无需保留行动力，也能在自身恢复之外再获得最多 2.0 耐久。堡垒城墙全部被毁后，该补给点失效。</p>');
  $('help-body').insertAdjacentHTML('beforeend', '<p>驻守己方未毁城墙的士兵攻击墙外敌军时，最终伤害增加 1.0；近战与远程均适用。攻击敌方城墙或墙上守军没有这项高地加成。</p>');
  $('help-body').insertAdjacentHTML('beforeend', `<p>城墙本身有护甲：1／2／3 级分别为 1／2／3，只抵消分摊给城墙的伤害，守军分摊的伤害另行计算。${troy ? '特洛伊外城、内城和三座滩头堡垒全部为 2 级城墙。' : ''}</p>`);
  $('help-body').insertAdjacentHTML('beforeend', '<p>双方始终看得到彼此的堡垒和城墙；驻守其中的士兵仍须进入己方视野才会显示。知道敌方建筑的位置不会扩大己方部队的视野或射程。</p>');
  if (currentMap().logistics) $('help-body').insertAdjacentHTML('beforeend',
    '<p>本战役启用财政与粮秣：存活且未溃逃的士兵每回合扣军费。普通士兵开局携带 3 个本方回合的口粮；只有指定执行奇袭绕后的精锐部队携带 10 回合口粮。口粮用尽后，每两个本方回合饥饿增加 1，最高为 5，达到 3 后损失耐久、士气和攻击力，满饥持续 5 回合会溃逃。粮车可装 24 点粮；先供给附近两格内的士兵，获得补给的士兵再供给相邻士兵，沿连续队列逐级传递，最终距离没有上限。每 1 点车载粮秣提供 5 点饱食度；清除 1 点饥饿或补充 1 回合随身口粮，各消耗 1 点饱食度，直到车上粮秣耗尽；断开的队列无法接力。获得补给会清空饥饿，普通士兵随身口粮补满至 3 回合，奇袭绕后精锐补满至 10 回合。粮车可沿河道或海域慢行，每次一格且不消耗行军粮，只能从水边道路或平地上岸；渡口和桥梁按正常陆路速度通行。陆路累计行军每超过 5 格耗粮 1 点。返回后方补给点可付费装粮；敌军切断补给线时不能召集或装粮。近战或远程击败敌方粮车时，每次缴获永久降低粮车耐久上限 4.0（例如 9→5→1→0），损耗不会因休整或再次易主而重置；上限仍大于 0 才易主并保留剩余粮秣，上限降至 0 则摧毁；电脑行军优先使用快速道路。</p>');
  $('help-body').insertAdjacentHTML('beforeend', '<p>远程攻击沿射手到目标的六角格线路判定：友军士兵不挡射线；弓箭手可以越过己方城墙射击，其他远程兵种仍会被己方城墙挡住。山地与敌方城墙会挡住后方目标；中间格有敌军时，只能先攻击前方敌军。平地、道路和渡口本身不挡箭矢或投矛；近战不受这条规则影响。</p>');
  $('help-body').insertAdjacentHTML('beforeend', troy || babylon ?
    '<p>己方空城墙可登上；步兵和徒步君主可登 1／2／3 级城墙，战车只能登 2／3 级。敌方城墙被击毁后方可从缺口进入。所有地形可见，未进入己方视野的敌军棋子隐藏。</p>' :
    '<p>己方空城墙可直接点击登上，之后也能下城再登。步兵、弓箭手、卫队和徒步君主可登 1／2／3 级城墙；战车弓兵、赫梯重战车及乘战车的法老只能登 2／3 级城墙。敌方城墙必须先击毁才能进入。</p>');
  $('help-body').insertAdjacentHTML('beforeend', '<p>骑兵、战车等不能驻守一级城墙的部队，可以穿过空置的己方一级城墙。请选择墙另一侧的可达地格作为终点，不能停在墙格上；穿越仍消耗正常移动距离，并受地形、占用和移动力限制。</p>');
  $('help-body').insertAdjacentHTML('beforeend','<p>批量行军：左键单击己方部队选择，单击空格移动，单击敌军攻击；左键拖动框选，Shift 点击增减部队，Ctrl 点击选择同类。右键拖动或按住空格拖动平移，中键拖动旋转；右键单击不下令。选中多队后，点击地面批量移动，点击敌军集火。也可用“攻击区域”指定交战区。各队依次按可达落点和剩余行动力执行。按 Alt+1–5 保存编组，按 1–5 调用。</p>');
  if(usesElevationRules(game)) {
    $('help-body').innerHTML=$('help-body').innerHTML.replace('山地射向非山地伤害 +0.5，非山地向山地射击伤害 −1.0，同高度不变，近战不适用','新版近战及远程直接攻击统一按逻辑高差结算，不再叠加旧弓兵高地定值');
    const note=document.createElement('p');note.textContent=(usesMountainMarchRules(game)?'山地通行规则：步兵与补给队无路山地每次行动1格，仍可每回合行动两次；山区道路恢复平原能力，没有额外+1格。骑兵、战车、战象、器械和列阵步兵只可走山区道路。补给队山区及山区道路行程粮耗双倍。':'规则 v11：按路径成本换算行动力。')+'地形悬停提示显示路径与行动力消耗。逻辑地面高程加存活城墙平台等级后计算双方高差；倍率采用当前存档中的配置，同高×1。旧弓兵、阏与下坡和城墙定值伤害不再叠加，射程和阻挡不变。旧存档保留原规则版本。';note.textContent+=` 当前参数：每级增伤 ${game.elevationRules.gain*100}%、减伤 ${game.elevationRules.loss*100}%，倍率 ${game.elevationRules.floor}–${game.elevationRules.ceiling}。`;$('help-body').prepend(note);
  }
  updateChargeHelp(game,$('help-body'));
  $('help-dialog').showModal();
};
$('close-help').onclick = () => $('help-dialog').close();
const statLabels = { hp: '耐久', armor: '护甲', move: '移动', vision: '视野', melee: '近战', meleeHit: '近战命中%',
  ranged: '远程', rangedHit: '远程命中%', range: '射程', ammo: '弹药' };
for (const [kind, stat] of Object.entries(STATS)) if (kind !== 'fort') {
  const option = document.createElement('option'); option.value = kind; option.textContent = stat.name;
  $('stat-kind').append(option);
}
for (const [field, [min, max]] of Object.entries(EDITABLE_UNIT_STATS)) {
  const label = document.createElement('label'); label.textContent = `${statLabels[field]} `;
  const input = document.createElement('input'); input.type = 'number'; input.dataset.stat = field;
  input.min = min; input.max = max; input.step = ['melee', 'ranged'].includes(field) ? '0.5' : '1';
  label.append(input); $('stat-fields').append(label);
}
function syncStatFields() {
  const kind = $('stat-kind').value;
  if (!kind) return;
  const stats = unitStats(scenario, { kind });
  $('type-name').value = scenario.unitNames?.[kind] || unitName(scenario, { kind, team: $('unit-team').value });
  for (const input of $('stat-fields').querySelectorAll('input')) input.value = stats[input.dataset.stat];
}
const veteranControl=document.createElement('label');veteranControl.textContent='初始士兵等级 ';
const veteranSelect=document.createElement('select');veteranSelect.id='editor-veteran-level';
for(let level=0;level<=4;level++){const option=document.createElement('option');option.value=level;option.textContent=`LV${level}`;veteranSelect.append(option);}
veteranControl.append(veteranSelect);$('apply-unit-name').after(veteranControl);
veteranSelect.onchange=()=>{const u=scenario.units.find(u=>u.id===editorSelectedId);if(!u||u.kind==='fort')return;
 terrainHistory.record(scenario);setVeteranLevel(scenario,u,Number(veteranSelect.value),{initial:true});u.promotionProgress=0;
 refresh();syncSelectedEditorUnit();};
function syncSelectedEditorUnit() {
  const u = scenario.units.find(v => v.id === editorSelectedId && v.kind !== 'fort');
  if($('editor-veteran-level')){$('editor-veteran-level').disabled=!u||u.kind==='fort';$('editor-veteran-level').value=String(growthLevel(u));}
  $('selected-editor-unit').textContent = u ? `${scenario.factions[u.team]} · ${unitName(scenario, u)} · ${u.c},${u.r}` : '未选择部队';
  $('unit-custom-name').value = u?.customName || '';
  $('unit-custom-name').disabled = !u;
  $('apply-unit-name').disabled = !u;
  if (u) { $('stat-kind').value = u.kind; syncStatFields(); }
}
function syncEditorFields() {
  ensureMoraleGuards(scenario);
  $('map-name').value = scenario.name;
  $('faction-egypt').value = scenario.factions.egypt;
  $('faction-coalition').value = scenario.factions.coalition;
  $('map-cols').value = scenario.cols; $('map-rows').value = scenario.rows;
  editorSelectedId = null; syncSelectedEditorUnit(); syncStatFields();
}
function toggleEditor(on) {
  if (on) {scenario.riverCrossing=1;soldierCameraUI.reset();ensureAutoElevation(scenario);}
  if (on) { cancelAutoTurn(); autoRunning = false; editing = true; selectedId = null; syncEditorFields(); $('editor-panel').classList.remove('hidden'); $('editor-note').textContent = '先选择地形或兵种在地图上绘制；数值与名称保存后只影响本战役。'; }
  else {
    $('exit-editor').disabled = true;
    storeScenario().then(() => {
      startForPlayer(); editing = false; selectedId = null; $('editor-panel').classList.add('hidden');
      hint(game.deploying ? '地图已保存，请先部署。' : '战役地图已保存并载入。'); refresh();
    }).catch(e => { $('editor-note').textContent = e.message; }).finally(() => { $('exit-editor').disabled = false; });
    return;
  }
  refresh();
}
$('editor').onclick = () => toggleEditor(!editing);
$('exit-editor').onclick = () => toggleEditor(false);
$('save-map').onclick = async () => {
  try { const name = await storeScenario(); $('editor-note').textContent = `已保存 ${name}；重新打开游戏仍可从战役列表读取。`; refresh(); }
  catch (e) { $('editor-note').textContent = e.message; }
};
$('stat-kind').onchange = syncStatFields;
$('apply-stats').onclick = () => {
  try {
    const kind = $('stat-kind').value, values = {};
    for (const input of $('stat-fields').querySelectorAll('input')) values[input.dataset.stat] = Number(input.value);
    setUnitStats(scenario, kind, values);
    const name = $('type-name').value.trim();
    scenario.unitNames ||= {};
    if (name) {
      scenario.unitNames[kind] = name;
      delete scenario.unitNames[`egypt:${kind}`];
      delete scenario.unitNames[`coalition:${kind}`];
    } else delete scenario.unitNames[kind];
    $('editor-note').textContent = `已修改${name || STATS[kind].name}的战役数值；点击「保存战役地图」使其永久生效。`;
    syncSelectedEditorUnit(); refresh();
  } catch (e) { $('editor-note').textContent = e.message; }
};
$('reset-stats').onclick = () => { setUnitStats(scenario, $('stat-kind').value, {}); syncStatFields(); refresh(); };
$('apply-unit-name').onclick = () => {
  const u = scenario.units.find(v => v.id === editorSelectedId && v.kind !== 'fort');
  if (!u) return;
  const name = $('unit-custom-name').value.trim();
  if (name) u.customName = name; else delete u.customName;
  syncSelectedEditorUnit(); $('editor-note').textContent = '这支部队的独立名称已更新；保存战役地图后会保留。'; refresh();
};
document.querySelectorAll('[data-brush]').forEach(btn => btn.onclick = () => {
  brush = btn.dataset.brush;
  document.querySelectorAll('[data-brush]').forEach(b => b.classList.toggle('active', b === btn));
});
$('unit-team').onchange = refresh;
document.querySelector('[data-brush="road"]').classList.add('active');
$('resize').onclick = () => {
  const cols = Number($('map-cols').value), rows = Number($('map-rows').value);
  try {
    const next = newMap(cols, rows); next.name = $('map-name').value.trim() || scenario.name;
    next.scenarioId = scenario.scenarioId; next.factions = { ...scenario.factions }; next.unitNames = scenario.unitNames ? { ...scenario.unitNames } : null; next.unitStats = structuredClone(scenario.unitStats || {}); next.victory = structuredClone(scenario.victory); next.intro = scenario.intro;
    next.heroRelease = scenario.heroRelease ? { ...scenario.heroRelease } : null;
    next.hectorSortieTurn = scenario.hectorSortieTurn;
    next.weather = scenario.weather ? { windDir: scenario.weather.windDir,
      clouds: scenario.weather.clouds.filter(p => inBounds(next, p.c, p.r)).map(p => ({ ...p })) } : null;
    next.recruitment = scenario.recruitment ? structuredClone(scenario.recruitment) : null;
    next.logistics = scenario.logistics ? structuredClone(scenario.logistics) : null;
    next.landmarks = scenario.landmarks.filter(x => inBounds(next, x.c, x.r));
    next.garden = scenario.garden && inBounds(next, scenario.garden.cMax, scenario.garden.rMax) ? { ...scenario.garden } : null;
    next.deployment = scenario.deployment && inBounds(next, scenario.deployment.cMax, scenario.deployment.rMax) ? { ...scenario.deployment } : null;
    next.reinforcements = scenario.reinforcements.map(e => ({ ...e, units: e.units.filter(u => inBounds(next, u.c, u.r)) }));
    for (let r = 0; r < Math.min(rows, scenario.rows); r++) for (let c = 0; c < Math.min(cols, scenario.cols); c++) {
      next.terrain[index(next, c, r)] = scenario.terrain[index(scenario, c, r)];
      if(scenario.elevations){next.elevations??=Array(cols*rows).fill(0);next.elevations[index(next,c,r)]=scenario.elevations[index(scenario,c,r)];}
      next.houses[index(next, c, r)] = scenario.houses[index(scenario, c, r)];
    }
    next.bridges = scenario.bridges.filter(p => inBounds(next, p.c, p.r)).map(p => ({ ...p }));
    next.units = scenario.units.filter(u => inBounds(next, u.c, u.r));
    next.supplyPoints = scenario.supplyPoints.filter(p => inBounds(next, p.c, p.r) &&
      next.units.some(u => u.kind === 'fort' && u.team === p.team &&
        (p.cityId ? u.cityId === p.cityId : distance(u, p) <= 4)));
    scenario = next; syncEditorFields();
    $('editor-note').textContent = `已调整为 ${cols}×${rows}；越界棋子与地形已移除。`;
    refresh();
  } catch (e) { $('editor-note').textContent = e.message; }
};
$('export').onclick = () => {
  scenario.name = $('map-name').value.trim() || scenario.name;
  try {
    const blob = new Blob([JSON.stringify(exportMap(scenario), null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${scenario.name}.json`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  } catch (e) { $('editor-note').textContent = e.message; }
};
$('import').onchange = async ev => {
  const file = ev.target.files?.[0]; if (!file) return;
  try { scenario = importMap(JSON.parse(await file.text())); if (!scenario.scenarioId) scenario.scenarioId = `custom_${Date.now().toString(36)}`; syncEditorFields(); $('editor-note').textContent = `已导入 ${scenario.name}；点击保存战役地图后会出现在战役列表。`; refresh(); }
  catch (e) { $('editor-note').textContent = `导入失败：${e.message}`; }
  ev.target.value = '';
};
$('new-map').onclick = () => {
  scenario = newMap(60, 36);
  scenario.scenarioId = `custom_${Date.now().toString(36)}`;
  scenario.name = '我的新战役'; scenario.factions = { egypt: '进攻方', coalition: '防守方' };
  scenario.intro = '自制战役开始。';
  addUnit(scenario, 'pharaoh', 'egypt', 9, 18);
  addUnit(scenario, 'heavy', 'coalition', 50, 18);
  syncEditorFields(); $('editor-note').textContent = '已创建空白战场与双方基础部队。完成绘制后点击「保存战役地图」。'; refresh();
};
$('restore').onclick = async () => {
  if (!CAMPAIGN_IDS.has(scenario.scenarioId)) { $('editor-note').textContent = '自制战役没有原始地图；可继续编辑或新建战役。'; return; }
  try {
    const id = scenario.scenarioId;
    if (savedMapIds.has(id)) {
      const response = await fetch(`/api/ancient/maps/${encodeURIComponent(id)}`, { method: 'DELETE' });
      if (!response.ok) throw new Error(`恢复失败（${response.status}）`);
    }
    const available = await fetch(`/api/ancient/maps/${encodeURIComponent(id)}`, { cache: 'no-store' });
    if (available.status === 404) {
      savedMapIds.delete(id);
      [...$('scenario-select').options].find(option => option.value === id).textContent = campaignTitle(id);
    } else if (!available.ok) throw new Error(`恢复失败（${available.status}）`);
    scenario = available.ok ? importMap(await available.json()) : makeScenario(id);
    syncEditorFields(); $('editor-note').textContent = `已恢复${scenario.name}的安装包默认地图。`; refresh();
  } catch (e) { $('editor-note').textContent = e.message; }
};
window.addEventListener('keydown', ev => {
  if(ev.defaultPrevented||/input|select|textarea/i.test(document.activeElement?.tagName||'')||document.activeElement?.isContentEditable)return;
  if(editing&&(ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='z'){ev.preventDefault();(ev.shiftKey?terrainHistory.redo(scenario):terrainHistory.undo(scenario));lastPaint='';refresh();return;}
  if(game&&groupAvailable()&&!document.querySelector('dialog[open]')&&/^Digit[1-5]$/.test(ev.code)&&!ev.ctrlKey&&!ev.metaKey&&!ev.shiftKey){
    const name='自定 '+ev.code.at(-1);
    if(!armyGroups.has(playerTeam))armyGroups.set(playerTeam,new Map());
    const groups=armyGroups.get(playerTeam);
    if(ev.altKey){
      const ids=groupIds.size?[...groupIds]:selectable(selectedUnit(),playerTeam)?[selectedId]:[];
      if(ids.length){groups.set(name,new Set(ids));syncGroupControls();hint('已保存'+name);}
    }else if(groups.has(name))selectArmyGroup(name);
    else return;
    ev.preventDefault();return;
  }
  const inputAction=inputMapping.action(ev);
  if(inputAction==='endTurn'){if(!ev.repeat&&!navigationPaused&&!document.querySelector('dialog[open]')&&!$('end-turn').disabled){ev.preventDefault();$('end-turn').click();}return;}
  if(inputAction==='top'){ev.preventDefault();$('board-view').click();return;}
  if(inputAction==='settings'){ev.preventDefault();$('settings').click();return;}
  if(inputAction==='follow'){ev.preventDefault();$('soldier-view')?.click();return;}
  if(inputAction==='officer'){ev.preventDefault();orderOfficer?.open();return;}
  if(inputAction==='report'){ev.preventDefault();$('turn-report-open')?.click();return;}
  if (inputAction === 'pan' && !/input|select|textarea/i.test(document.activeElement?.tagName || '')) { spaceHeld = true; ev.preventDefault(); }
  if (inputAction === 'confirm' && ($('camera-dialog').open || $('follow-controls').contains(document.activeElement))) return;
  if (inputAction === 'cancel' && !$('camera-dialog').open && document.querySelector('dialog[open]')) { document.querySelector('dialog[open]').close(); return; }
  if(inputAction==='cancel'&&($('camera-dialog').open||(soldierCamera.active&&!document.querySelector('dialog[open]')))){soldierCameraUI.reset();ev.preventDefault();return;}
  if(inputAction==='cancel'){clearGroup();selectedId=null;$('selection-box').classList.add('hidden');if(gesture&&canvas.hasPointerCapture(gesture.pointerId))canvas.releasePointerCapture(gesture.pointerId);gesture=null;refresh();}
  if (inputAction === 'cancel' && $('help-dialog').open) $('help-dialog').close();
  if(inputAction==='confirm' && groupIds.size>1 && !/input|select|textarea/i.test(document.activeElement?.tagName||'')){ev.preventDefault();$('end-turn').click();return;}
  if (inputAction === 'confirm' && !editing && !game.over && document.activeElement?.tagName !== 'BUTTON') $('end-turn').click();
});
window.addEventListener('keyup', ev => { if(inputMapping.action(ev)==='pan') spaceHeld = false; }, true);
window.addEventListener('blur', () => { spaceHeld = false; });
const terrainHistory=createTerrainHistory();
for(const [label,method] of [['撤销 ⌘Z','undo'],['重做 ⇧⌘Z','redo']]){const b=document.createElement('button');b.textContent=label;b.id='terrain-'+method;b.onclick=()=>{if(terrainHistory[method](scenario)){lastPaint='';refresh();}};document.querySelector('.editor-head').append(b);}

const reconnaissanceMap=createTopographicMinimap(document.querySelector('#stage'),{
 state:()=>({game,map:currentMap(),editor:editing,observer:observerView(),team:playerTeam,selected:[...groupIds,...(selectedId?[selectedId]:[])]}),
 jump:p=>{soldierCameraUI.reset();target.set(p.x,0,p.z);clampCameraTarget();updateCamera();},
 footprint:()=>{const points=[],ray=new THREE.Raycaster();for(const [x,y] of [[-1,-1],[1,-1],[1,1],[-1,1]]){ray.setFromCamera(new THREE.Vector2(x,y),camera);let p=ray.ray.intersectPlane(plane,new THREE.Vector3());if(!p)continue;for(let i=0;i<3;i++){const cell=worldToOffset(p.x,p.z),h=(editing||observerView()||visibleTo(game,playerTeam,cell.col,cell.row))?(terrainObj?.sample(p.x,p.z)||0):0,next=ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0),-h),new THREE.Vector3());if(next)p=next;}points.push({x:p.x,z:p.z});}return points;}
});
setInterval(()=>reconnaissanceMap.update(),200);
window.ancientScenario = { get map() { return currentMap(); }, get game() { return editing?game:planningState(game,playerTeam); }, export: () => exportMap(currentMap()) };
if (scenario.scenarioId === 'salamis')
  hint('萨拉米斯：连续沿船首接近至少两格后，侧舷或船尾冲角默认×2；原地转向及射箭不获加成，正面撞击有反作用。旧存档保留旧规则。');
refresh();
async function bootSavedMaps() {
  const response = await fetch('/api/ancient/maps', { cache: 'no-store' });
  if (!response.ok) throw new Error(`无法读取自制战役（${response.status}）`);
  const maps = await response.json();
  for (const record of maps) if (typeof record.scenarioId === 'string' && typeof record.name === 'string')
    registerSavedMap(record.scenarioId, record.name);
  if (savedMapIds.has(chosenScenario)&&!ME_IDS.has(chosenScenario)) {
    scenario = await readScenario(chosenScenario);
    startForPlayer(); selectedId = null;
    const p = offsetToWorld(...scenarioFocus(scenario)); target.set(p.x, 0, p.z);
    cameraDistance = initialCameraDistance(scenario.scenarioId,scenario); updateCamera(); refresh();
  }
}
bootSavedMaps().catch(e => hint(e.message));




$('terrain-quality').value = terrainQuality;
try{$('mountain-relief').checked=localStorage.getItem('ancient-mountain-relief')!=='off';}catch{}
$('mountain-relief').onchange=()=>{const enabled=$('mountain-relief').checked;setMountainRelief(enabled);try{localStorage.setItem('ancient-mountain-relief',enabled?'on':'off');}catch{}terrainObj?.invalidate();refresh();};
try{$('vegetation').checked=localStorage.getItem('ancient-vegetation')!=='off';}catch{}
$('vegetation').onchange=()=>{setVegetation($('vegetation').checked);try{localStorage.setItem('ancient-vegetation',$('vegetation').checked?'on':'off');}catch{}terrainObj?.invalidate();refresh();};
$('casualties').checked=showCasualties;$('casualties').onchange=()=>{showCasualties=$('casualties').checked;try{localStorage.setItem('ancient-casualties',showCasualties?'on':'off');}catch{}refresh();};
$('hex-grid').checked = showHexGrid;
$('terrain-quality').onchange = () => {
  terrainQuality = $('terrain-quality').value;
  terrainObj?.setQuality(terrainQuality); terrainEnvironment.setQuality(terrainQuality);casualtyLayer.sync(currentMap(),u=>seen(u),{editing,show:showCasualties,detail:terrainQuality,budget:casualtyBudget,maxAgeTurns:casualtyAge,currentTurn:game?.turn||1});
  try { localStorage.setItem('ancient-terrain-quality', terrainQuality); } catch {}
};
$('hex-grid').onchange = () => {
  showHexGrid = $('hex-grid').checked;
  syncTerrainGrid();
  try { localStorage.setItem('ancient-hex-grid', showHexGrid ? 'on' : 'off'); } catch {}
};

$('box-select').onclick=()=>{boxSelect=!boxSelect;syncGroupControls();rebuildMarks();};
$('group-cancel').onclick=()=>{clearGroup();selectedId=null;refresh();};
$('army-group').onchange=ev=>{if(ev.target.value)selectArmyGroup(ev.target.value);};
$('army-area').onclick=()=>{armyArea=!armyArea;syncGroupControls();hint(armyArea?'点选要交战的区域':'已取消区域攻击');};
$('army-stop').onclick=()=>{
  orderOfficer?.delegates.cancelUnits(groupIds.size?[...groupIds]:selectedId?[selectedId]:[]);
  clearGroup();selectedId=null;refresh();hint('已取消待发批量命令与所选战团的托管命令。');
};

$('collapse-editor').onclick=()=>{const collapsed=$('editor-panel').classList.toggle('collapsed');$('collapse-editor').textContent=collapsed?'展开工具':'收起工具';$('collapse-editor').setAttribute('aria-expanded',String(!collapsed));};

// Shared tactical execution, with human intent kept independent of the trained AI.
orderOfficer=bindOrderOfficer({document,getState:()=>game,getTeam:()=>playerTeam,
 getSelection:()=>groupIds.size?[...groupIds]:selectedId?[selectedId]:[],
 canAct:team=>!editing&&game&&!game.over&&!game.deploying&&humanCanAct()&&game.side===team,
 onAction:a=>{if(a.type==='move')unitAnimator.move(a.id,a.from,a.result.path,performance.now());else if(a.result.visual)combatFx.play(a.result,game.map);},
 onSelection:ids=>{groupIds=new Set(ids);selectedId=ids[0]||null;},onRefresh:()=>refresh(),onNotice:hint});
$('symbol-legend').innerHTML=symbolLegend();$('animation-quality').value=animationQuality;
bindBattleSettings({document,officer:orderOfficer,onAnimationChange:value=>{animationQuality=value==='low'?'low':'standard';try{localStorage.setItem('ancient-animation-quality',animationQuality);}catch{}}});
orderOfficer.sync();

for(const [id,key,setter,value] of [['casualty-budget','ancient-casualty-budget',v=>casualtyBudget=v,casualtyBudget],['casualty-age','ancient-casualty-age',v=>casualtyAge=v,casualtyAge]]){const el=$(id);el.value=String(value);el.onchange=()=>{setter(Number(el.value));try{localStorage.setItem(key,el.value);}catch{}refresh();};}

const colorSection=document.createElement('section');colorSection.innerHTML='<h3>阵营颜色</h3><p>同步更换衣服、盾牌饰色及底座；保留皮肤、金属与坐骑原色。</p><label>第一方 <input id="faction-color-egypt" type="color"></label><label>第二方 <input id="faction-color-coalition" type="color"></label><button id="reset-faction-colors">恢复默认配色</button>';document.querySelector('#settings-dialog .settings-grid').append(colorSection);
const updateFactionColors=()=>{syncFactionMaterials();syncUniformColors();terrainObj?.invalidate?.();refresh();};
for(const team of ['egypt','coalition']){const input=$('faction-color-'+team);input.value=factionColor(team);input.oninput=()=>{setFactionColors({[team]:input.value});updateFactionColors();};}
$('reset-faction-colors').onclick=()=>{setFactionColors(DEFAULT_COLORS);for(const team of ['egypt','coalition'])$('faction-color-'+team).value=factionColor(team);updateFactionColors();};
const fogSection=document.createElement('section');fogSection.innerHTML=`<h3>当前战役情报规则</h3><label><input id="terrain-fog-toggle" type="checkbox">地形迷雾</label><input id="unit-fog-toggle" type="checkbox" checked hidden disabled><p>敌军情报由当前战役的战争迷雾规则自动管理；地形开关不改变敌军可见性。</p><label>开局地图知识 <select id="fog-knowledge"><option value="full">完整地图</option><option value="partial">部分已知地图</option><option value="unknown">未知地图</option></select></label><p>双方共用，切换立即生效；不会清除已侦察记录。关闭迷雾会按新规则公开对应信息。初始知识预设仅用于下局。</p><p id="active-fog-policy"></p>`;document.querySelector('#settings-dialog .settings-grid').append(fogSection);
$('terrain-fog-toggle').onchange=()=>{pendingFog={...pendingFog,terrainFog:$('terrain-fog-toggle').checked};$('fog-knowledge').disabled=!pendingFog.terrainFog;changeFogPolicy(game,{terrainFog:pendingFog.terrainFog});orderOfficer?.api.cancel();refresh();reconnaissanceMap.update(performance.now(),true);};
$('fog-knowledge').onchange=()=>{pendingFog={...pendingFog,initialKnowledge:$('fog-knowledge').value};};$('fog-knowledge').disabled=true;
$('settings').addEventListener('click',()=>{const p=game.fogPolicy||STANDARD_FOG_POLICY;$('terrain-fog-toggle').checked=p.terrainFog;$('unit-fog-toggle').checked=p.unitFog;$('fog-knowledge').value=p.initialKnowledge;$('fog-knowledge').disabled=!p.terrainFog;});
setInterval(()=>{$('active-fog-policy').textContent=`本局：地形迷雾 ${game.fogPolicy?.terrainFog?'开':'关'} · 战争迷雾 ${game.fogPolicy?.unitFog===false?'关':'开'} · 规则 v${game.rulesVersion}`;},1000);

bindBattleEndingUI({document,getState:()=>game,getTeam:()=>playerTeam,getMode:()=>battleMode,isActive:()=>!navigationPaused,label:victoryLabel,refresh,observe:team=>{playerTeam=team;},enemyTurn:()=>{playComputerTurn();refresh();}});

const boardButton=document.createElement('button');boardButton.id='board-view';boardButton.textContent='正上方棋盘';$('settings').before(boardButton);boardButton.onclick=()=>{if(soldierCamera.engaged)soldierCameraUI.reset();boardView=!boardView;boardButton.textContent=boardView?'返回3D沙盘':'正上方棋盘';updateCamera();};

battleInteraction=bindBattleInteraction({document,isSpectator:()=>battleMode==='ai-ai',getState:()=>game,getTeam:()=>playerTeam,getCamera:()=>camera,onReport:turn=>orderOfficer.report(turn),openReports:()=>orderOfficer.openReports(),onCoordinate:p=>{orderOfficer.open();const input=$('order-input');input.value+=` 零基坐标(${p.c}, ${p.r})`;input.focus();}});
document.querySelector('.actions').prepend($('restart'));document.querySelector('.actions').append($('end-turn'));
const apSection=document.createElement('section');apSection.innerHTML='<h3>行动力标记</h3><select id="ap-density"><option value="auto">近处及选中单位</option><option value="all">全部可见单位</option><option value="off">关闭</option></select>';document.querySelector('#settings-dialog .settings-grid').append(apSection);$('ap-density').value=localStorage.getItem('ancient-ap-density')||'auto';$('ap-density').onchange=()=>localStorage.setItem('ancient-ap-density',$('ap-density').value);

const phalanxStyle=document.createElement('link');phalanxStyle.rel='stylesheet';phalanxStyle.href='phalanx-ui.css';document.head.append(phalanxStyle);
batchPhalanx=bindBatchPhalanxUI({document,getState:()=>game,getMap:currentMap,getTeam:()=>playerTeam,getIds:()=>[...groupIds],canAct:()=>groupAvailable(),preview:previewPhalanx,refresh,notify:hint,onManual:ids=>{orderOfficer?.delegates.cancelUnits(ids);}});
battleInteraction.sync();

ruleManual=bindRulesManual({document,getState:()=>game,getUnit:()=>currentMap().units.find(u=>u.id===selectedId),getTeam:()=>playerTeam,getBindings:()=>inputMapping.bindings});
$('help').textContent='规则手册';$('help').onclick=()=>ruleManual.open('controls');
const terrainRules=document.createElement('button');terrainRules.id='terrain-rules-link';terrainRules.textContent='地形规则';terrainRules.onclick=()=>ruleManual.open('terrain');stage.append(terrainRules);
const failureRules=document.createElement('button');failureRules.id='failure-rules-link';failureRules.textContent='行动受限？查看规则';failureRules.onclick=()=>ruleManual.open(/攻击|射程|弹药/.test($('hint').textContent)?'combat':'terrain');stage.append(failureRules);
tutorialSystem=bindTutorialSystem({document,ready:refresh,
 context:()=>({game,selected:selectedId,group:[...groupIds],known:currentMap(),bindings:inputMapping.bindings,manual:ruleManual.chapter,officer:orderOfficer.history,camera:{x:target.x,z:target.z,yaw:cameraYaw,pitch:cameraPitch,distance:cameraDistance,board:boardView}}),
 project:p=>unitScreen(p),manual:id=>ruleManual.open(id),choose:()=>{ruleManual.close();navigation.finishTutorial('TutorialSelection');},exit:()=>{ruleManual.close();navigation.finishTutorial();},
 async setup(id){const spec=createTutorialMap(id);ruleManual.close();orderOfficer.close();battleMode='human-human';preferredHumanTeam='egypt';editing=false;scenario=spec.map;startForPlayer();game=startGame(scenario,{manualCores:true,reserveResponses:true,gateRules:1,fogPolicy:spec.fog});game.aiDifficulty=aiDifficulty;playerTeam='egypt';selectedId=null;autoRunning=false;cancelAutoTurn();clearGroup();$('editor-panel').classList.add('hidden');const p=offsetToWorld(spec.focus.c,spec.focus.r);target.set(p.x,0,p.z);boardView=false;cameraYaw=0;cameraPitch=.9;cameraDistance=id==='recon'?155:120;updateCamera();refresh();hint('按侧边提示练习；左键选择、移动或攻击。可随时跳过、重试或退出。');return spec.actors;}
});
const unitEncyclopedia=bindUnitEncyclopedia({getState:()=>game,getBindings:()=>inputMapping.bindings,async pause(){cancelAutoTurn();while(orderOfficer.api.pending||orderOfficer.delegates.running)await new Promise(resolve=>setTimeout(resolve,16));const wasPaused=navigationPaused;navigationPaused=true;cancelAutoTurn();return ()=>{navigationPaused=wasPaused;if(!wasPaused){refresh();scheduleAutoTurn();}};}});
const navigation=bindNavigation({
 encyclopedia:()=>unitEncyclopedia.open(),
 pause(on){navigationPaused=on;if(on){cancelAutoTurn();orderOfficer?.reset();if(gesture){if(canvas.hasPointerCapture(gesture.pointerId))canvas.releasePointerCapture(gesture.pointerId);gesture=null;$('selection-box').classList.add('hidden');}spaceHeld=false;}else {refresh();scheduleAutoTurn();}orderOfficer?.sync();},
 editing:()=>editing,loaded:()=>{const v=navigationLoaded;navigationLoaded=false;return v;},selected:()=>selectedId,unit:()=>game.map.units.find(u=>u.id===selectedId),damaged:()=>game.map.units.find(u=>u.kind==='archer')?.ammo<tutorialArrows||game.map.units.filter(u=>u.team==='coalition').reduce((n,u)=>n+Math.max(0,u.hp),0)<tutorialHP,
 describe:readScenario,manual:id=>ruleManual.open(id),stopTutorial:()=>tutorialSystem.stop(),tutorialId:()=>tutorialSystem.id,
 async start(id,config={},isCurrent=()=>true){
  const next=ME_IDS.has(id)?makeScenario(id):await readScenario(id);
  if(!isCurrent())return;
  battleMode=['human-ai','human-human','ai-ai'].includes(config.mode)?config.mode:'human-ai';
  preferredHumanTeam=config.team==='coalition'?'coalition':'egypt';aiDifficulty=['easy','normal','hard'].includes(config.difficulty)?config.difficulty:'normal';
  scenario=next;editing=false;selectedId=null;$('editor-panel').classList.add('hidden');
  startForPlayer();$('scenario-select').value=id;if(ME_IDS.has(id)){boardView=false;cameraYaw=-.17;cameraPitch=.98;const minimap=$('recon-toggle');if(minimap?.getAttribute('aria-expanded')==='true')minimap.click();}const p=offsetToWorld(...scenarioFocus(scenario));target.set(p.x,0,p.z);cameraDistance=initialCameraDistance(id,scenario);updateCamera();refresh();
  hint(`${scenario.name}：${battleMode==='ai-ai'?'双方由电脑指挥':battleMode==='human-human'?'双方玩家轮流指挥':`你指挥${scenario.factions[playerTeam]}`}。${game.deploying?'请先在合法部署区域布阵。':'左键选择、移动或攻击；右键拖动平移。'}`);
  const url=new URL(location.href);url.searchParams.set('scenario',id);url.searchParams.set('mode',battleMode);url.searchParams.set('side',preferredHumanTeam);history.replaceState(null,'',url);
 },
 restart(){startForPlayer();refresh();},
 async edit(){toggleEditor(true);},
 async tutorial(id){await tutorialSystem.start(id);}
});

bindBattleLayout(document);

tileDetails=bindTileDetails(document);

bindLogisticsUI({document,getState:()=>game,getTeam:()=>playerTeam,onRefresh:()=>refresh()});

function focusMiddleEarthPanorama(){
  const m=game.map, zone=isMorannon(m.scenarioId)?morannonWindows(m)[game.middleEarth.view]:[0,m.cols];
  const [left,right]=zone;
  const p=offsetToWorld((left+right-1)/2,Math.floor((m.rows-1)/2));
  const aspect=stage.clientWidth/Math.max(1,stage.clientHeight);
  const span=Math.max((right-left)*10.4/aspect,m.rows*9);
  target.set(p.x,8,p.z);
  const large=m.victory.layoutVersion>=3&&!hasCliffNavigation(m);
  cameraDistance=Math.min(maxCameraDistance(m),span*1.65);
  boardView=false;cameraYaw=large?-.10:-.24;cameraPitch=large?1.20:.81;
  $('board-view').textContent='正上方棋盘';
  updateCamera();
}

function updateMiddleEarthPanel(){
  let panel=$('middle-earth-panel');
  if(!panel){panel=document.createElement('section');panel.id='middle-earth-panel';stage.append(panel);}
  const d=game?.middleEarth;
  panel.hidden=!d||editing;
  if(panel.hidden)return;
  const objectiveOpen=panel.querySelector('details')?.open;
  panel.replaceChildren();
  const line=text=>{const p=document.createElement('div');p.textContent=text;panel.append(p);};
  const button=(label,fn)=>{const b=document.createElement('button');b.textContent=label;b.onclick=fn;panel.append(b);};
  const objective=document.createElement('details'),summary=document.createElement('summary');
  const m=game.map;
  const zone=isMorannon(m.scenarioId)?morannonWindows(m)[d.view]:[0,m.cols];
  summary.textContent=`第 ${game.turn} / ${m.victory.turnLimit} 回合 · 地图 V${m.victory.layoutVersion??1}${m.victory.layoutVersion>=3?` · ${zone[1]-zone[0]}×${m.rows} 格`:''}`;
  objective.open=!!objectiveOpen;
  objective.append(summary,game.map.intro);panel.append(objective);
  if(game.map.victory.layoutVersion>=2)button(beforePanorama?'返回指挥视角':'战场全景',()=>{
    soldierCameraUI.reset();
    if(beforePanorama){
      ({boardView,cameraYaw,cameraPitch,cameraDistance}=beforePanorama);
      target.copy(beforePanorama.target);beforePanorama=null;
      $('board-view').textContent=boardView?'返回3D沙盘':'正上方棋盘';
      updateCamera();
    }else{
      beforePanorama={boardView,cameraYaw,cameraPitch,cameraDistance,target:target.clone()};
      focusMiddleEarthPanorama();
    }
    updateMiddleEarthPanel();
  });
  if(d.withdrawn.length)line(`撤离 ${d.withdrawn.length} 队`);
  if(d.docks)line(`已控制泊位 ${d.docks.length} / 2`);
  if(game.map.scenarioId==='me_hornburg'&&playerTeam==='egypt'&&!d.events.seal&&(!hasCliffNavigation(m)||!d.events.breach))
    button('封堵涵洞',()=>{if(!sealCulvert(game))hint('需要一支仍有行动力的守军紧邻涵洞');refresh();});
  if(isMorannon(game.map.scenarioId)){
    const focus={front:morannonCell(10,8,game.map),pass:morannonCell(30,8,game.map),doom:morannonCell(51,8,game.map)};
    for(const zone of d.phase==='final'?['front','doom']:['pass']){
      button(({front:'黑门正面',doom:'末日山',pass:'西力斯昂哥'})[zone],()=>{
        soldierCameraUI.reset();d.view=zone;beforePanorama=null;selectedId=null;clearGroup();
        const p=offsetToWorld(focus[zone].c,focus[zone].r);target.set(p.x,0,p.z);
        cameraDistance=m.victory.layoutVersion===5?150:m.victory.layoutVersion===4?300:138;updateCamera();refresh();
      });
    }
    if(d.events.timeskip&&!d.cameraTransition){d.cameraTransition=true;beforePanorama=null;const p=offsetToWorld(focus.doom.c,focus.doom.r);target.set(p.x,0,p.z);updateCamera();}
    line(`戒指状态 ${({meFrodo:'弗罗多持戒',meSam:'山姆代持，靠近弗罗多归还',meGollum:'咕噜夺戒',ground:'掉落，靠近拾回',mordor:'魔多夺得，尚可截回'})[d.ring]}`);
    if(d.phase==='final'){
      line(`索伦对正面关注 ${d.attention>=.67?'高':d.attention>=.32?'中':'低'}`);
      if(d.alert)line(`本回合搜索预警 ${d.alert.c}, ${d.alert.r} 周围 ${d.alert.radius} 格，结束玩家行动后生效`);
      const other=game.map.units.some(u=>u.team==='egypt'&&u.hp>0&&u.actionsLeft>0&&meZone(u.c,game.map)!==d.view&&meUnitActive(game,u));
      if(other)line('另一战区仍有可行动部队');
    }
    if(d.view!=='front'&&!game.over)for(const [mode,label] of [['normal','正常行进'],['careful','谨慎潜行'],['hidden','寻找掩护']]){
      button(label,()=>{if(!setStealth(game,mode))hint('弗罗多需要剩余行动力，隐藏还需地形掩护');refresh();});
    }
    if(d.view!=='front')line(`当前 ${({normal:'正常行进',careful:'谨慎潜行',hidden:'隐蔽'})[d.stealth]}`);
  }
  const selected=selectedUnit();
  if(selected){
    if(meAir(selected))line('飞行 · 可俯冲攻击两格内目标 · 地面弓兵可以反击');
    const objective=siegeObjective(game,selected);
    if(objective&&selected.team===playerTeam&&humanCanAct()){
      if(selected.kind==='meBlast')line(siegeContact(m,selected,objective)?
        '爆破装置已抵达深谷墙，留在原位等待下一艾辛格阶段。':'将爆破装置移动到深谷墙爆破点旁。');
      if(selected.kind==='meGrond'){
        line('将格隆德推到王城大门正前方，再点击大门撞击。');
        if(siegeContact(m,selected,objective)&&attackPreview(game,selected,objective.c,objective.r))
          button('撞击王城大门',()=>clickCell(objective.c,objective.r,false,objective.id));
      }
    }
    if(selected.meFearTurn===game.turn)line('本回合受到恐惧影响');
    const stack=liveUnits().filter(u=>u.id!==selected.id&&u.c===selected.c&&u.r===selected.r);
    for(const u of stack){
      button(`查看同格 ${unitName(game.map,u)}`,()=>{selectedId=u.id;refresh();});
      if(u.team!==selected.team&&selected.team===playerTeam&&humanCanAct()){
        button(`攻击同格 ${unitName(game.map,u)}`,()=>{
          d.preferredTarget=u.id;
          try{const result=attack(game,selected.id,u.c,u.r);if(result.visual)combatFx.play(result,game.map);hint(result.ok?'攻击完成':result.reason);}
          finally{delete d.preferredTarget;}refresh();
        });
      }
    }
  }
  const last=Object.values(d.events).at(-1);
  if(last)line(last.text);
}
