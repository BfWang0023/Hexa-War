import {offsetToWorld} from '../js/core/hex.js';
// Facing uses E, NE, NW, W, SW, SE, with half steps for the clock.
export function frontVector(facing,dx,dz){const length=Math.hypot(dx,dz);return length>0&&(Math.cos(facing*Math.PI/3)*dx-Math.sin(facing*Math.PI/3)*dz)/length>=-1e-10;}
export function formationFront(unit,target){const a=offsetToWorld(unit.c,unit.r),b=offsetToWorld(target.c,target.r);return frontVector(unit.facing,b.x-a.x,b.z-a.z);}
