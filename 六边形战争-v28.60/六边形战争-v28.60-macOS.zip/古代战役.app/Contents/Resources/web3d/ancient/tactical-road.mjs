import {planningState,terrainKnown} from './fog-policy.mjs';
// A coarse road graph ranks goals; the engine still validates every actual path and expenditure.
import {TERRAIN,tile,visibleTo,neighbors,key,inBounds,distance,mobileAt} from './engine.mjs';
export function roadField(state,goal,team){state=planningState(state,team);
 const isRoad=p=>inBounds(state.map,p.c,p.r)&&terrainKnown(state,team,p.c,p.r)&&!!(tile(state.map,p.c,p.r).terrain&TERRAIN.ROAD),dist=new Map(),queue=[];
 if(isRoad(goal)){dist.set(key(goal.c,goal.r),0);queue.push(goal);}else for(const n of neighbors(goal.c,goal.r))if(isRoad(n)){dist.set(key(n.c,n.r),1);queue.push(n);}
 for(let i=0;i<queue.length;i++){const p=queue[i],d=dist.get(key(p.c,p.r));for(const n of neighbors(p.c,p.r))if(isRoad(n)&&!dist.has(key(n.c,n.r))){dist.set(key(n.c,n.r),d+1);queue.push(n);}}
 return {dist,isRoad,goal};
}
export function roadProgress(field,p){return p.c===field.goal.c&&p.r===field.goal.r?0:field.dist.get(key(p.c,p.r))??Infinity;}
export function legalRoadPath(state,path,goal){state=planningState(state,state.side);return path.every(p=>p.c===goal.c&&p.r===goal.r||!!(tile(state.map,p.c,p.r)?.terrain&TERRAIN.ROAD));}
