import test from 'node:test';
import assert from 'node:assert/strict';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {createTerrainRefresh} from './terrain-refresh.mjs';
import {bridgeDeckContains,bridgeDeckSpans} from './terrain-adjacency.mjs';
import {bridgeEnds,groundCell} from './cliff-navigation.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {TERRAIN,index} from './engine.mjs';

test('compact hex grid follows wet and dry edges without drawing shared edges twice',()=>{
  const map=makeMiddleEarthMap('me_isen_first');
  const terrain=createTerrainRefresh();
  terrain.refresh(map);
  const edges=new Set();
  let waterEdges=0;
  const vertex=(a,i)=>[a.getX(i).toFixed(3),a.getZ(i).toFixed(3)].join(',');
  for(const {terrain:chunk} of terrain.chunks.values()){
    const lines=chunk.grid.geometry.attributes.position;
    for(let i=0;i<lines.count;i+=2){
      const key=[vertex(lines,i),vertex(lines,i+1)].sort().join('/');
      assert.ok(!edges.has(key),key);
      edges.add(key);
      if(Math.abs(lines.getY(i)+.325)<.001&&Math.abs(lines.getY(i+1)+.325)<.001)waterEdges++;
    }
  }
  assert.ok(waterEdges>0);
  terrain.setGrid(true,true);
  assert.ok([...terrain.chunks.values()].every(({terrain:{grid}})=>grid.material.opacity===.62&&grid.material.color.getHex()===0xaebba2));
  terrain.setGrid(false,true);
  assert.ok([...terrain.chunks.values()].every(x=>!x.terrain.grid.visible));
  terrain.dispose();
});

test('submerged banks include rendered faces connecting dry rims to the water',()=>{
  const map=makeMiddleEarthMap('me_isen_first');
  const terrain=createTerrainRefresh();
  terrain.refresh(map);
  let vertical=0;
  for(const {terrain:chunk} of terrain.chunks.values()){
    const g=chunk.surface.geometry,a=g.attributes.position;
    for(let i=0;i<g.index.count;i+=3){
      const [x,y,z]=[g.index.getX(i),g.index.getX(i+1),g.index.getX(i+2)];
      const twiceArea=(a.getX(y)-a.getX(x))*(a.getZ(z)-a.getZ(x))-(a.getX(z)-a.getX(x))*(a.getZ(y)-a.getZ(x));
      if(Math.abs(twiceArea)<.00001&&a.getY(x)>.1&&Math.min(a.getY(y),a.getY(z))<-.50)vertical++;
    }
  }
  assert.ok(vertical>100);
  terrain.dispose();
});

test('bent bridge decks reach both logical approach edges and sample at deck height',()=>{
  const map=makeMiddleEarthMap('me_pelennor');
  const bridge=map.bridges.find(p=>{
    const a=offsetToWorld(p.c,p.r),ends=bridgeEnds(map,p);
    if(ends.length!==2)return false;
    const [b,c]=ends.map(q=>offsetToWorld(q.c,q.r));
    return Math.hypot(b.x+c.x-2*a.x,b.z+c.z-2*a.z)>1;
  });
  assert.ok(bridge);
  const {c,r}=bridge,cell=groundCell(map,c,r),spans=bridgeDeckSpans(map,c,r);
  assert.equal(spans.length,2);
  const terrain=createTerrainRefresh();
  terrain.refresh(map);
  for(const end of bridgeEnds(map,bridge)){
    const target=offsetToWorld(end.c,end.r);
    const x=(cell.center.x+target.x)*.5,z=(cell.center.z+target.z)*.5;
    assert.ok(bridgeDeckContains(spans,x,z));
    assert.equal(terrain.sample(x*.99+cell.center.x*.01,z*.99+cell.center.z*.01),.5);
  }
  assert.equal(map.terrain[index(map,c,r)]&(TERRAIN.ROAD|TERRAIN.RIVER),TERRAIN.ROAD|TERRAIN.RIVER);
  terrain.dispose();
});
