import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
for(const kind of ['light','scout','archer']) for(const h of [1,2,3,4])test(`${kind}: observer height3, intervening${h}, target0`,()=>{
 const m=E.newMap(24,18);E.addUnit(m,"pharaoh","egypt",1,1);E.addUnit(m,"hittiteKing","coalition",22,16);E.addUnit(m,kind,'egypt',8,8);const s=E.startGame(m),u=s.map.units[2],target={c:10,r:8};s.map.elevations=Array(24*18).fill(0);s.map.elevations[E.index(s.map,8,8)]=3;
 const points=[{c:9,r:8}];assert.ok(points.length);for(const p of points)s.map.elevations[E.index(s.map,p.c,p.r)]=h;
 const seen=E.unitSightCells(s,u);assert.equal(seen.has(E.key(10,8)),h<=3);assert.ok(seen.has(E.key(points[0].c,points[0].r)));
});
test('wall remains opaque even below observer; breach reveals only that ray',()=>{
 const m=E.newMap(24,18);E.addUnit(m,"pharaoh","egypt",1,1);E.addUnit(m,"hittiteKing","coalition",22,16);E.addUnit(m,'scout','egypt',8,8);const s=E.startGame(m),u=s.map.units[2],p={c:9,r:8};s.map.elevations=Array(432).fill(0);s.map.elevations[E.index(s.map,8,8)]=5;
 E.setFort(s.map,p.c,p.r,2,'coalition');assert.equal(E.unitSightCells(s,u).has('10,8'),false);E.fortAt(s.map,p.c,p.r).hp=0;assert.ok(E.unitSightCells(s,u).has('10,8'));
});
