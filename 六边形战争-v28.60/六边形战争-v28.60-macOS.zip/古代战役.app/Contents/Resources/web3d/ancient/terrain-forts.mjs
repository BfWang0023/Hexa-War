import {fortificationLayout,fortWallHeight,usesFortificationLayout} from './fortification-layout.mjs';
import {projectConstructionMaps,surfaceMaps} from './middle-earth-materials.mjs';
import {isMorannon} from './middle-earth-data.mjs';
import {blackGateTexture} from './black-gate-material.mjs';
import {factionColor} from './faction-colors.mjs';
// Batched defensive works. Levels affect appearance only; rule heights stay fixed.
import * as THREE from '../vendor/three/three.module.js';
import { offsetToWorld } from '../js/core/hex.js';
import { FORT_HP } from './engine.mjs';
import { noise } from './terrain-surface.mjs';


export const wallHeight=fortWallHeight;

export const gateDeckHeight=level=>wallHeight(level)+1.5+level*.25+.28;
export const fortStandingHeight=fort=>fort?.hp>0?(fort.gate?gateDeckHeight(fort.level):wallHeight(fort.level)):0;

export function createTerrainForts(m, forts, height) {
  const group = new THREE.Group();
  const blackGate=isMorannon(m.scenarioId),ironwork=[];
  const authored=m.victory?.layoutVersion>=2,remaster=!!m.victory?.army,whiteCity=m.scenarioId==='me_pelennor'&&remaster;
  const hornburg=m.scenarioId==='me_hornburg'&&remaster;
  const layout=fortificationLayout(m),anchor=layout.anchor,grounded=usesFortificationLayout(m);
  const sides = [], footings = [], tops = [], timber = [], damage = [], rubble = [], flags = [], earthworks = [];
  function add(list, u, x, y, z, sx, sy, sz, angle = 0, tilt = 0, cell = u) {
    list.push({ u, cell, p: [x, y, z], s: [sx, sy, sz], angle, tilt });
  }
  function footing(u,x,top,z,length,width,angle=0,tilt=0){
    const co=Math.cos(angle),si=Math.sin(angle),slope=Math.tan(tilt);
    let depth=.52;
    for(const a of [-length/2,0,length/2])for(const b of [-width/2,0,width/2]){
      const bottom=height(m,u.c,u.r,x+a*co+b*si,z-a*si+b*co);
      depth=Math.max(depth,top+a*slope-bottom+.32);
    }
    add(footings,u,x,top-depth/2+.045,z,length,depth+.09,width,angle,tilt);
  }
  for (const u of forts) {
    const plan=layout.at(u.c,u.r),p=plan.p,base=height(m,u.c,u.r);

    const h = wallHeight(u.level), ratio = Math.max(0, u.hp / FORT_HP[u.level]);
    if (ratio <= 0) {
      for (let i = 0; i < 6; i++)
        add(rubble, u, p.x + (noise(u.c, u.r, i) - .5) * 6, base + .15,
          p.z + (noise(u.r, u.c, i + 8) - .5) * 4,
          .5 + noise(i, u.c), .3, .65, noise(i, u.r) * 6);
      continue;
    }
    if(authored&&u.cityId==='外堤'){
      const arms=plan.arms.filter(arm=>arm.fort?.cityId===u.cityId);
      for(const [dy,w,depth] of [[-.15,5.7,1.25],[.60,4.45,1.15],[1.53,3.35,.98],[2.38,2.38,.82]]){
        add(earthworks,u,p.x,base+dy,p.z,w,depth,w);
        for(const {dx,dz,fort} of arms){
          const len=Math.hypot(dx,dz),dh=(height(m,fort.c,fort.r)-base)/2;
          add(earthworks,u,p.x+dx/2,base+dy+dh/2,p.z+dz/2,len,depth,w,-Math.atan2(dz,dx),Math.atan2(dh,len));
        }
      }
      continue;
    }
    if(u.gate){
      const connected=plan.connected,a=plan.axis;
      const gateH=h+1.5+u.level*.25;
      for(const side of [-1,1]){
        const x=p.x+Math.cos(a)*side*2,z=p.z-Math.sin(a)*side*2;
        add(sides,u,x,base+gateH/2,z,1.5,gateH,3.2,a);
        add(tops,u,x,base+gateH+.1,z,1.85,.28,3.5,a);
        if(grounded)footing(u,x,base,z,1.55,3.2,a);
      }
      add(sides,u,p.x,base+gateH-.45,p.z,5.3,.9,3.1,a);
      add(timber,u,p.x-2.65,base+gateH+1.25,p.z-2,.12,2.5,.12);
      add(flags,u,p.x-1.65,base+gateH+1.9,p.z-2,1.9,1.1,.07,a);
      add(tops,u,p.x,base+gateH+.14,p.z,5.8,.28,5.2,a);
      if(whiteCity){
        for(const side of [-1,1]){
          const x=p.x+Math.cos(a)*side*2.75,z=p.z-Math.sin(a)*side*2.75;
          add(sides,u,x,base+gateH*.54,z,1.25,gateH*1.08,3.55,a);
          add(tops,u,x,base+gateH*1.08+.14,z,1.58,.35,3.92,a);
        }
      }
      if(whiteCity||hornburg){
        for(const side of [-1,1]){
          const x=p.x+Math.cos(a)*side*2.4,z=p.z-Math.sin(a)*side*2.4;
          add(tops,u,x,base+gateH+.56,z,1.8,.22,3.50,a);
          for(const edge of [-1,1]){
            const tx=x+Math.sin(a)*edge*1.16,tz=z+Math.cos(a)*edge*1.16;
            add(tops,u,tx,base+gateH+.88,tz,.72,.68,.71,a);
          }
        }
      }
      if(blackGate){
        const point=(along,cross)=>[p.x+Math.cos(a)*along+Math.sin(a)*cross,p.z-Math.sin(a)*along+Math.cos(a)*cross];
        for(const side of [-1,1]){
          const [x,z]=point(side*2.3,0);
          add(ironwork,u,x,base+gateH/2,z,1.8,gateH,3.65,a);
          add(ironwork,u,x,base+.62,z,2.18,1.24,3.83,a);
          add(ironwork,u,x,base+gateH*.80,z,2.06,.34,3.84,a);
          for(const edge of [-1,1]){
            const [xx,zz]=point(side*2.47,edge*1.65);
            add(ironwork,u,xx,base+gateH*.43,zz,.48,gateH*.72,.42,a);
          }
          for(const corner of [-1,1]){
            const [xx,zz]=point(side*2.3+corner*.57,side*1.0);
            add(ironwork,u,xx,base+gateH+.86,zz,.42,1.65,.46,a);
          }
        }
        for(let i=-2;i<=2;i++){
          const [x,z]=point(i*.43,0);
          add(ironwork,u,x,base+gateH-1.85,z,.14,2.1,.30,a);
        }
        add(ironwork,u,p.x,base+gateH-.57,p.z,5.1,.56,3.27,a);
      }
      // The gate owns its half of each wall connection. Meet the neighboring
      // wall at the shared midpoint, with a slight overlap to prevent seams.
      for(const v of connected){const q=anchor(v),dx=q.x-p.x,dz=q.z-p.z,d=Math.hypot(dx,dz),start=Math.min(1.7,d/4),end=d/2+(authored?0:.12),angle=-Math.atan2(dz,dx),len=end-start;
        const top0=base+h,top1=(top0+height(m,v.c,v.r)+wallHeight(v.level))/2;
        const dh=top1-top0,tilt=Math.atan2(dh,len),x=p.x+dx/d*(start+end)/2,z=p.z+dz/d*(start+end)/2;
        const span=authored?len:Math.hypot(len,dh);
        add(sides,u,x,base+h/2+dh/2,z,span+(authored?0:.12),h,2.7,angle,tilt);
        if(grounded)footing(u,x,base+dh/2,z,span+(authored?0:.12),2.82,angle,tilt);
        add(tops,u,x,top0+.06+dh/2,z,span+(authored?0:.16),.14,2.85,angle,tilt);
      }
      continue;
    }
    const simple = u.level === 1;
    const {width,nodeWidth,tower}=plan;
    const foundation = simple&&!authored ? h*.58 : h;
    add(sides, u, p.x, base + foundation / 2, p.z, nodeWidth, foundation, nodeWidth);
    if(grounded)footing(u,p.x,base,p.z,nodeWidth+.16,nodeWidth+.16);
    // The central walkway remains at the existing unit anchor for all three levels.
    add(simple ? timber : tops, u, p.x, base + h + .04, p.z, nodeWidth + .15, .12, nodeWidth + .15);
    const arms=plan.arms.map(({dx,dz,fort})=>({dx,dz,dh:fort?
      (height(m,fort.c,fort.r)+wallHeight(fort.level)-base-h)/2:0}));

    for (const { dx, dz, dh } of arms) {
      const len = Math.hypot(dx, dz), angle = -Math.atan2(dz, dx), tilt = Math.atan2(dh, len);
      const span=grounded&&!authored?Math.hypot(len,dh):len;
      add(sides, u, p.x + dx / 2, base + foundation / 2 + dh / 2, p.z + dz / 2,
        span + (authored?0:.12), foundation, width, angle, tilt);
      if(grounded)footing(u,p.x+dx/2,base+dh/2,p.z+dz/2,span+(authored?0:.18),width+.16,angle,tilt);
      add(simple ? timber : tops, u, p.x + dx / 2, base + h + .06 + dh / 2, p.z + dz / 2,
        span + (authored?0:.16), .14, width + .15, angle, tilt);
      if (simple) {
        // Low stone footings, timber rail panels and upright stakes distinguish level one.
        for (const side of [-1, 1]) {
          const sx = Math.sin(angle) * side * 1.18, sz = Math.cos(angle) * side * 1.18;
          add(timber, u, p.x + dx / 2 + sx, base + h*.52 + dh / 2, p.z + dz / 2 + sz,
            len, .28, .2, angle, tilt);
          for (let j = 1; j <= 4; j++) {
            if (ratio < .75 && noise(u.c, u.r, j + side * 9) > ratio) continue;
            const f = j / 4.4;
            add(timber, u, p.x + dx * f + sx, base + h*.6 + dh * f, p.z + dz * f + sz,
              .26, h*.75, .26, angle);
          }
        }
      } else {
        for (let j = 1; j <= 3; j++) {
          if (ratio < .75 && noise(u.c, u.r, j + Math.round(angle * 10)) > ratio) continue;
          const f = j / 3.5;
          for (const side of [-1, 1])
            add(tops, u, p.x + dx * f + Math.sin(angle) * side * (width / 2 - .12),
              base + h + .35 + dh * f, p.z + dz * f + Math.cos(angle) * side * (width / 2 - .12),
              .65, .6, .43, angle);
        }
      }
    }
    if (authored&&u.cityId==='深谷墙'&&m.victory.points.culvert?.r===u.r-1){
      const culvert=m.victory.points.culvert;
      const q=offsetToWorld(culvert.c,culvert.r),floor=height(m,culvert.c,culvert.r);
      const top=Math.max(floor+4.6,base+h);
      for(const side of [-1,1]){
        add(sides,u,q.x,(top+floor)/2,q.z+side*2.75,width,top-floor,1.7,0,0,culvert);
        add(sides,u,q.x,(top+floor+2.1)/2,q.z+side*1.65,width,top-floor-2.1,.65,0,0,culvert);
      }
      add(sides,u,q.x,(top+floor+2.8)/2,q.z,width,top-floor-2.8,3.1,0,0,culvert);
      add(tops,u,q.x,top+.21,q.z,width+.15,.36,7.2,0,0,culvert);
      for(const z of [-2.6,-.9,.9,2.6])for(const x of [-1.95,1.95])
        add(tops,u,q.x+x,top+.59,q.z+z,.65,.71,.82,0,0,culvert);
    }
    if(tower){
      const {x,z,angle,size}=tower;
      if(grounded)footing(u,x,base,z,size+.16,size+.16,angle);
      const towerH = h + (ratio < .5 ? .75 : authored ? 5.6 : 1.5);
      add(sides, u, x, base + towerH / 2, z, authored?4.4:2.4, towerH, authored?4.4:2.4, angle);
      add(tops, u, x, base + towerH + .06, z, authored?4.7:2.7, .18, authored?4.7:2.7, angle);
      for (const sx of (authored?[-1.86,1.86]:[-.96,.96])) for (const sz of (authored?[-1.86,1.86]:[-.96,.96])) {
        if (ratio < .5 && sx === sz) continue;
        add(tops, u, x + Math.cos(angle) * sx + Math.sin(angle) * sz, base + towerH + .4,
          z - Math.sin(angle) * sx + Math.cos(angle) * sz, .52, .62, .52, angle);
      }
      add(damage, u, x, base + towerH * .72, z - 1.21, .17, .7, .025);
      add(damage, u, x + 1.21, base + towerH * .72, z, .025, .7, .17);
    }
    if (ratio < .85) {
      add(damage, u, p.x + .8, base + foundation * .5, p.z - nodeWidth / 2 - .01,
        .13, foundation * .72, .025, 0, .2);
      for (let i = 0; i < 3; i++)
        add(rubble, u, p.x - 2.0 + i * .6, base + .12, p.z + 2.1, .5, .24, .4, i * .6);
    }
  }
  function batch(name, items, color) {
    if (!items.length) return;
    const masonry=['wall-masonry','wall-coping','wall-footings','wall-rubble'].includes(name);
    const finish=masonry?'stone':name==='wall-timber'?'wood':name==='earthen-rampart'?'mud':null;
    const gateFinish=blackGate&&['wall-masonry','wall-coping','wall-footings','black-gate-iron'].includes(name);
    const material=new THREE.MeshStandardMaterial({color,roughness:1,
      ...(gateFinish?{map:blackGateTexture(name==='black-gate-iron')}:finish?surfaceMaps(finish):{}),
    });
    if(finish)projectConstructionMaps(material,finish==='wood'?4.5:finish==='mud'?11:6.4);
    const mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),material,items.length);
    const o = new THREE.Object3D();
    items.forEach(({ u, p, s, angle, tilt }, i) => {
      o.position.set(...p); o.scale.set(...s); o.rotation.set(0, angle, 0);
      if(!authored)o.rotateZ(tilt);
      o.updateMatrix();
      // Keep the plan inside its hex as elevation changes along a wall arm.
      if(authored)o.matrix.elements[1]=s[0]*Math.tan(tilt);
      mesh.setMatrixAt(i, o.matrix);
      const ratio = Math.max(0, u.hp / FORT_HP[u.level]);
      const tint = new THREE.Color(name==='gate-flags'?(factionColor(u.team)):blackGate||whiteCity?0xffffff:(u.team === 'egypt' ? 0xd3c3a5 : 0xc3b49a));
      tint.multiplyScalar(.72 + .28 * ratio); mesh.setColorAt(i, tint);
    });
    mesh.name = name; mesh.userData.unitIds = items.map(x => x.u.id);
    mesh.userData.cells = items.map(({cell})=>({c:cell.c,r:cell.r}));
    mesh.instanceMatrix.needsUpdate = true; mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh);
  }
  batch('gate-flags',flags,0xffffff);
  batch('wall-masonry', sides, blackGate||whiteCity?0xf2f1eb:hornburg?0x9a998e:0x9a8c75);
  batch('wall-footings',footings,blackGate?0x89837a:whiteCity?0xbcb5a6:0x8b7d65);
  batch('black-gate-iron',ironwork,0xffffff);
  batch('wall-coping', tops, blackGate||whiteCity?0xe5e3dc:hornburg?0xb7b2a2:0xdbceac);
  batch('wall-timber', timber, 0x89633c);
  batch('earthen-rampart',earthworks,0x8e7b54);
  batch('wall-cracks', damage, 0x413f35);
  batch('wall-rubble', rubble, 0x95886f);
  return group;
}
