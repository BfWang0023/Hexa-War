import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {createUnitModel} from './unit-presentation.mjs';
import {animateFullModel} from './full-models.mjs';
import {materials} from './models-v02.mjs';
import {STATS,newMap,addUnit,startGame,mobileAt,attack,attackPreview,endSide,unitStats,recruitLogistics} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
import {CAMPAIGN_CATALOG} from './campaign-catalog.mjs';
import {mapFor} from '../../tools/ai-training/maps.mjs';
const pairs=['heavy','guard','romanHastati','romanPrincipes','romanTriarii','romanLegion','phalangite','greekHoplite','africanInfantry','moraleGuard'];
const unit=(kind,team='egypt',formed=false)=>({id:'u1',kind,team,hp:100,c:3,r:3,morale:1,formed,facing:0});
const soldiers=root=>{const out=[];root.traverse(o=>{if(o.name==='soldier')out.push(o)});return out;};

test('all ten squad infantry types have four equally sized soldiers through marching, attacks and formation',()=>{
 for(const kind of pairs)for(const team of ['egypt','coalition'])for(const formed of [false,true]){
  const u=unit(kind,team,formed),before=JSON.stringify(u),m=createUnitModel(u,'mantinea'),people=soldiers(m.getObjectByName('near'));assert.equal(people.length,4,kind);
  for(const pose of [{},{moving:true},{moving:true,action:'thrust',progress:.4},{hit:1}]){animateFullModel(m,340,pose);assert.deepEqual(people[0].scale.toArray(),[.69,.69,.69]);assert.deepEqual(people[1].scale.toArray(),[.69,.69,.69]);const size=people.map(p=>new T.Box3().setFromObject(p).getSize(new T.Vector3()));assert.ok(Math.abs(size[0].y-size[1].y)<1e-6,kind);}
  assert.equal(JSON.stringify(u),before);
 }
});
test('phase-one and legacy paired infantry also use equal figure scales',()=>{
 for(const team of ['egypt','coalition']){
  const m=createUnitModel(unit('heavy',team),'china_chengpu',{phase1:true});for(const level of ['near','far']){const people=soldiers(m.getObjectByName(level));assert.equal(people.length,2);assert.deepEqual(people[0].scale.toArray(),people[1].scale.toArray());}
  for(const [kind,scenario]of [['heavy','megiddo'],['guard','megiddo'],['moraleGuard','china_changping'],['heavy','cannae'],['guard','qarqar'],['phalangite','gaugamela']]){const old=createUnitModel(unit(kind,team),scenario,{legacy:true}),body=old.getObjectByName('unit-body'),figures=body.children.filter(c=>c.isGroup);if(figures.length===2)assert.deepEqual(figures[0].scale.toArray(),figures[1].scale.toArray(),kind);}
 }
});
test('flattened far LOD includes four equal-height heads at the new shared human scale',()=>{
 for(const kind of pairs){const m=createUnitModel(unit(kind),'mantinea'),far=m.getObjectByName('far'),max=Array(4).fill(-Infinity),count=Array(4).fill(0);far.traverse(o=>{if(!o.isMesh||o.material!==materials.skin)return;const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++)for(const [j,x,z] of [[0,-.65,-.65],[1,.65,-.65],[2,-.65,.65],[3,.65,.65]])if(p.getY(i)>2.65*.69&&Math.hypot(p.getX(i)-x,p.getZ(i)-z)<.4*.69){max[j]=Math.max(max[j],p.getY(i));count[j]++;}});assert.ok(count.every(n=>n>10),kind+' all four heads visible');assert.ok(max.every(y=>Math.abs(y-max[0])<1e-6),kind);}
});
test('hero javelins and Chinese chariot arrows default to ten, with other missile stocks unchanged',()=>{
 assert.equal(STATS.hero.ammo,10);assert.equal(STATS.chinaHeavyChariot.ammo,10);assert.equal(STATS.hittiteChariot.ammo,1);assert.equal(STATS.archer.ammo,999);assert.equal(STATS.chinaCrossbow.ammo,999);
 const s=startGame(mapFor('china_changping'));s.map.logistics.routes.egypt=[s.map.logistics.depots.egypt[0]];s.money.egypt=150;const r=recruitLogistics(s,'chinaHeavyChariot');assert.ok(r.ok,r.reason);assert.equal(r.unit.ammo,10);
});
for(const kind of ['hero','chinaHeavyChariot'])test(`${kind}: ten ranged attacks consume ten missiles and an eleventh is rejected`,()=>{
 const m=newMap(12,8);m.scenarioId='custom_ten_missiles';addUnit(m,'pharaoh','egypt',0,0);addUnit(m,kind,'egypt',3,3);addUnit(m,'heavy','coalition',5,3);const s=startGame(m),u=mobileAt(s.map,3,3);
 for(let i=0;i<10;i++){assert.equal(u.ammo,10-i);assert.ok(attackPreview(s,u,5,3));const hit=attack(s,u.id,5,3,.999);assert.ok(hit.ok,hit.reason);assert.equal(u.ammo,9-i);endSide(s,()=>.5);endSide(s,()=>.5);}
 const actions=u.actionsLeft;assert.equal(attackPreview(s,u,5,3),null);assert.equal(attack(s,u.id,5,3,0).ok,false);assert.equal(u.ammo,0);assert.equal(u.actionsLeft,actions);
});
test('all 71 campaign starts use the ten-missile defaults, including Yique historical override',()=>{
 let heroes=0,chariots=0;for(const c of CAMPAIGN_CATALOG){const s=startGame(mapFor(c.id));for(const u of s.map.units)if(['hero','chinaHeavyChariot'].includes(u.kind)){assert.equal(unitStats(s.map,u).ammo,10,c.id+' capacity');assert.equal(u.ammo,10,c.id+' initial');u.kind==='hero'?heroes++:chariots++;}}assert.ok(heroes>0&&chariots>0);
});
test('save restore preserves spent ammunition and clamps legacy excess without replenishing',()=>{
 for(const id of ['troy','china_yique']){
  const s=startGame(mapFor(id)),u=s.map.units.find(u=>u.kind===(id==='troy'?'hero':'chinaHeavyChariot'));assert.ok(u);
  for(const ammo of [0,3,10,999]){u.ammo=ammo;const slot=JSON.parse(JSON.stringify(createSave(s.map,s,'egypt'))),restored=restoreSave(slot).game,v=restored.map.units.find(v=>v.id===u.id);assert.equal(v.ammo,Math.min(ammo,10));assert.equal(unitStats(restored.map,v).ammo,10);}
 }
});

test('all catalog models with exactly two soldiers or crew use equal figure scales',async()=>{
 const fs=await import('node:fs'),catalog=JSON.parse(fs.readFileSync(new URL('./unit_animation_catalog.json',import.meta.url)));let checked=0;
 for(const entry of catalog.units.filter(x=>x.id!=='fort')){const context=entry.contexts[0],m=createUnitModel(unit(entry.id,context.team),context.scenarioId),people=[];m.getObjectByName('near').traverse(o=>{if(['soldier','rider'].includes(o.name))people.push(o);});if(people.length===2){assert.deepEqual(people[0].scale.toArray(),people[1].scale.toArray(),entry.id);checked++;}}
 assert.ok(checked>=10);
});
