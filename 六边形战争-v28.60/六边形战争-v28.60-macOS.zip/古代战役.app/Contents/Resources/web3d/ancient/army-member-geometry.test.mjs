import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {createArmyMemberGeometry} from './army-member-geometry.mjs';
import {createArmyFormationRenderer,isArmyFormation} from './army-formation-render.mjs';
import {ME_STATS} from './middle-earth-data.mjs';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {createUnitModel,UNIT_SCENE_SCALE} from './unit-presentation.mjs';
import {loadCampaign} from './campaign-loader.mjs';

const map=makeMiddleEarthMap('me_pelennor');
const meshMoves=(base,pose)=>pose.array.some((value,i)=>Math.abs(value-base.array[i])>.10);

test('every army family retains its own colored mesh and active march and combat poses',()=>{
  const silhouettes=new Map();
  for(const kind of Object.keys(ME_STATS)){
    const unit={kind,team:'egypt'};
    if(!isArmyFormation(unit))continue;
    const geometry=createArmyMemberGeometry(unit,map);
    const {position,color}=geometry.attributes;
    assert.ok(position.count>300,kind);
    assert.ok(color.array.every(Number.isFinite),kind);
    const poses=geometry.morphAttributes.position;
    assert.equal(poses.length,4,kind);
    assert.ok(poses.every(p=>p.count===position.count&&p.array.every(Number.isFinite)),kind);
    assert.ok(meshMoves(position,poses[0])&&meshMoves(position,poses[1])&&meshMoves(poses[0],poses[1]),kind);
    assert.ok(meshMoves(position,poses[2]),kind);
    if(ME_STATS[kind].ranged)assert.ok(meshMoves(position,poses[3]),kind);
    silhouettes.set(kind,Array.from(position.array));
    geometry.dispose();
  }
  for(const [a,b] of [['meGondor','meRohanFoot'],['meOrc','meUruk'],['meElf','meDwarf'],['meRohan','meWarg']])
    assert.notDeepEqual(silhouettes.get(a),silhouettes.get(b));
});

test('four animated members share one batch and preserve selection IDs',()=>{
  const units=[{id:'u1',kind:'meGondorBow',team:'egypt'},{id:'u2',kind:'meGondorBow',team:'egypt'}];
  const models=new Map(units.map((u,i)=>{
    const model=new T.Group();
    const point=offsetToWorld(18+i,20);
    model.position.set(point.x,0,point.z);
    Object.assign(model.userData,{armyFormation:true,armyAction:'bow',armyProgress:.5});
    return [u.id,model];
  }));
  const focus=models.get('u1').position;
  const camera=new T.PerspectiveCamera(45,1.4,.1,500);
  camera.position.copy(focus).add(new T.Vector3(0,45,50));
  camera.lookAt(focus);
  camera.updateMatrixWorld();
  const formation=createArmyFormationRenderer();
  formation.bind(map,units,models,()=>0);
  formation.update(camera,100);
  const [mesh]=formation.group.children;
  assert.equal(formation.group.children.length,1);
  assert.equal(mesh.count,8);
  assert.equal(formation.visibleMen,8);
  const {armyHeight,armyMuzzle}=models.get('u1').userData;
  assert.ok(armyHeight>4.7);
  assert.ok(armyMuzzle[1]>armyHeight*.60&&armyMuzzle[1]<armyHeight*.85);
  assert.deepEqual(mesh.userData.formationIds,[...Array(4).fill('u1'),...Array(4).fill('u2')]);
  const pose={morphTargetInfluences:[0,0,0,0]};
  mesh.getMorphAt(4,pose);
  assert.equal(pose.morphTargetInfluences[3],1);
  formation.clear();
  assert.equal(formation.group.children.length,0);
});


test('Middle-earth infantry and mounted troops match the size of historical battlefield models',()=>{
  const historical=loadCampaign('megiddo');
  const height=(kind,battle=map)=>{
    const unit={kind,team:'egypt'};
    const model=createUnitModel(unit,battle.scenarioId,{map:battle,withoutBase:true});
    model.scale.setScalar(UNIT_SCENE_SCALE);
    return new T.Box3().setFromObject(model).getSize(new T.Vector3()).y;
  };
  const formationHeight=kind=>{
    const unit={id:'u1',kind,team:'egypt'};
    const model=new T.Group();
    model.userData.armyFormation=true;
    const formation=createArmyFormationRenderer();
    formation.bind(map,[unit],new Map([[unit.id,model]]),()=>0);
    formation.clear();
    return model.userData.armyHeight;
  };
  const infantry=formationHeight('meGondor'), mounted=formationHeight('meRohan');
  const infantryReference=height('heavy',historical),mountedReference=height('cavalry',loadCampaign('china_longxi'));
  assert.ok(Math.abs(infantry/infantryReference-1)<.06);
  assert.ok(Math.abs(mounted/mountedReference-1)<.06);
  assert.ok(height('meAragorn')>infantry*.8&&height('meAragorn')<infantry*1.16);
  assert.ok(formationHeight('meDwarf')<infantry*.83);
  assert.ok(height('meMumak')>infantry*1.4);
  assert.ok(height('meTroll')>infantry*1.65);
});
