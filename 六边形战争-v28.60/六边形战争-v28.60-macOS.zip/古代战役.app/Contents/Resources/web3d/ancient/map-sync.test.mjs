import {currentSnapshot,bundledContract} from '../../tools/visibility-v28.37/map-contract.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {importMap,startGame} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
import {CAMPAIGN_CATALOG} from './campaign-catalog.mjs';
import {mapFor} from '../../tools/ai-training/maps.mjs';
const manifest=JSON.parse(readFileSync(new URL('../../docs/map-sync/manifest.json',import.meta.url)));
for(const record of manifest.records.filter(r=>r.changed))test(`user-saved map retained without rewriting: ${record.id}`,()=>{
 const bundled=readFileSync(new URL(`./bundled-maps/${record.name}`,import.meta.url)),snapshot=currentSnapshot(record.name);assert.ok(bundled.equals(snapshot));bundledContract(record.name,bundled);
 const raw=JSON.parse(snapshot),map=importMap(raw),game=startGame(map);assert.equal(map.scenarioId,record.id);assert.equal(map.units.length,raw.units.length);assert.deepEqual(JSON.parse(bundled).units,raw.units);assert.deepEqual(JSON.parse(bundled).victory,raw.victory);assert.deepEqual(JSON.parse(bundled).terrain,raw.terrain);
 const restored=restoreSave(JSON.parse(JSON.stringify(createSave(map,game,'egypt'))));assert.equal(restored.game.map.scenarioId,record.id);assert.equal(restored.game.map.units.length,game.map.units.length);assert.deepEqual(restored.game.map.bridges,game.map.bridges);
});
test('all 85 campaigns still start and restore with the synchronized default maps',()=>{
 assert.equal(CAMPAIGN_CATALOG.length,96);const seen=new Set();for(const c of CAMPAIGN_CATALOG){const map=mapFor(c.id),game=startGame(map),slot=restoreSave(JSON.parse(JSON.stringify(createSave(map,game,'egypt'))));assert.equal(map.scenarioId,c.id);assert.equal(slot.game.map.scenarioId,c.id);assert.ok(map.units.length>0);assert.ok(!seen.has(c.id));seen.add(c.id);}assert.equal(seen.size,96);
});
