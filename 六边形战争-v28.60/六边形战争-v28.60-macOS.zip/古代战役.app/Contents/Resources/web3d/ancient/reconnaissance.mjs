import {knownMap,unitKnown} from './fog-policy.mjs';
// Read permissions before reading map content. Stored observations never update in fog.
import {groundElevation} from './elevation-rules.mjs';
const key=(c,r)=>`${c},${r}`;
export function validateRecon(game){const all=game.reconnaissance;if(all===undefined)return;
 if(!all||typeof all!=='object'||Array.isArray(all)||Object.keys(all).some(t=>!['egypt','coalition'].includes(t)))throw Error('侦察记录无效');
 for(const records of Object.values(all)){if(!records||typeof records!=='object'||Array.isArray(records)||Object.keys(records).length>game.map.cols*game.map.rows)throw Error('侦察记录无效');
 for(const [k,v] of Object.entries(records)){const [c,r]=k.split(',').map(Number);if(k!==key(c,r)||!Number.isInteger(c)||!Number.isInteger(r)||c<0||r<0||c>=game.map.cols||r>=game.map.rows||!v||!Number.isInteger(v.terrain)||v.terrain<0||v.terrain>255||!Number.isFinite(v.height)||Math.abs(v.height)>100||typeof v.bridge!=='boolean'||typeof v.facility!=='string'||v.facility.length>64)throw Error('侦察记录无效');}}
}
// Coordinates are cached outside save state; ordinary movement does not allocate a
// new observation object for every visible cell on every fog recomputation.
const locations=new WeakMap();
function location(map,k){let cache=locations.get(map);if(!cache||cache.cols!==map.cols){cache={cols:map.cols,values:new Map()};locations.set(map,cache);}let p=cache.values.get(k);if(!p){const comma=k.indexOf(','),c=Number(k.slice(0,comma)),r=Number(k.slice(comma+1));p={c,r,i:r*map.cols+c};cache.values.set(k,p);}return p;}

export function captureRecon(game,team,{editor=false,map=game.map}={}){
 const visible=editor?null:game.fog[team].visible;
 if(!editor){game.reconnaissance??={};game.reconnaissance[team]??={};}
 const records=editor?{}:game.reconnaissance[team],allowed=(c,r)=>editor||visible.has(key(c,r));
 const facilities=new Map(),bridges=new Set();
 for(const u of map.units)if(allowed(u.c,u.r)&&u.kind==='fort'&&u.hp>0)facilities.set(key(u.c,u.r),'城墙');
 for(const p of map.supplyPoints||[])if(allowed(p.c,p.r))facilities.set(key(p.c,p.r),'补给');
 for(const p of map.landmarks||[])if(allowed(p.c,p.r))facilities.set(key(p.c,p.r),'据点：'+p.label.slice(0,40));
 for(const p of map.bridges||[])if(allowed(p.c,p.r))bridges.add(key(p.c,p.r));
 let changed=false;const keys=editor?Array.from({length:map.cols*map.rows},(_,i)=>key(i%map.cols,Math.floor(i/map.cols))):visible;
 for(const k of keys){const {c,r,i}=location(map,k),terrain=map.terrain[i],height=groundElevation(map,c,r),bridge=bridges.has(k),facility=facilities.get(k)||'',old=records[k];if(!old||old.terrain!==terrain||old.height!==height||old.bridge!==bridge||old.facility!==facility){records[k]={terrain,height,bridge,facility};changed=true;}}
 return {records,changed};
}
export function reconView(game,team,{editor=false,map=game.map,selected=[]}={}){
 if(game.fogPolicy&&!editor){const m=knownMap(game,team),visible=game.fog[team].visible;return {cols:m.cols,rows:m.rows,cells:Array.from({length:m.cols*m.rows},(_,i)=>({c:i%m.cols,r:Math.floor(i/m.cols),terrain:m.terrain[i],height:m.elevations[i],bridge:m.bridges.some(p=>p.c===i%m.cols&&p.r===Math.floor(i/m.cols)),facility:m.units.some(u=>['fort','defenseTower'].includes(u.kind)&&u.c===i%m.cols&&u.r===Math.floor(i/m.cols))?'城墙':'',visible:visible.has(`${i%m.cols},${Math.floor(i/m.cols)}`)})).filter((v,i)=>!m.unknown[i]),units:m.units.filter(u=>u.hp>0&&!['fort','defenseTower'].includes(u.kind)&&!u.aboard&&unitKnown(game,team,u)).map(u=>({id:u.id,c:u.c,r:u.r,team:u.team,selected:selected.includes(u.id)})),history:[],team,editor:false};}
 const {records,changed}=captureRecon(game,team,{editor,map}),visible=game.fog[team].visible,cells=[];
 for(const [k,o] of Object.entries(records)){const [c,r]=k.split(',').map(Number);if(!editor&&!game.fog[team].explored.has(k))continue;cells.push({c,r,...o,visible:editor||visible.has(k)});}
 const chosen=new Set(selected);
 const units=map.units.filter(u=>u.hp>0&&!u.aboard&&u.kind!=='fort'&&(editor||u.team===team||visible.has(key(u.c,u.r)))).map(u=>({id:u.id,c:u.c,r:u.r,team:u.team,selected:chosen.has(u.id)}));
 return {cols:map.cols,rows:map.rows,cells,units,changed,editor,team};
}
export function heightColor(h,terrain){if(terrain&12)return '#487e9b';const stops=[[0,[119,151,92]],[1,[161,170,98]],[2,[184,160,103]],[4,[139,113,89]],[7,[108,103,99]]];let i=1;while(i<stops.length-1&&h>stops[i][0])i++;const [a,x]=stops[i-1],[b,y]=stops[i],f=Math.max(0,Math.min(1,(h-a)/(b-a)));return `rgb(${x.map((v,j)=>Math.round(v+(y[j]-v)*f)).join(',')})`;}
