import test from 'node:test';
import assert from 'node:assert/strict';
import {TERRAIN,newMap,addUnit,setTerrain,setFort,startGame as startGameCurrent,mobileAt,attackPreview,attack,distance,neighbors,recomputeFog,visibleTo} from './engine.mjs';
// Legacy v10 regression contract; v11 is covered in elevation-rules.test.mjs.
const startGame = map => startGameCurrent(map,{rulesVersion:10});
function setup(kind='archer',fromMountain=false,toMountain=false,wall=false){
 const m=newMap(16,10);m.scenarioId='custom_elevation_test';addUnit(m,'pharaoh','egypt',0,0);
 setTerrain(m,4,4,fromMountain?TERRAIN.MOUNTAIN:TERRAIN.PLAIN);setTerrain(m,7,4,toMountain?TERRAIN.MOUNTAIN:TERRAIN.PLAIN);
 if(wall)setFort(m,4,4,2,'egypt');
 addUnit(m,kind,'egypt',4,4);addUnit(m,'heavy','coalition',7,4);
 const s=startGame(m);return {s,u:mobileAt(s.map,4,4),target:mobileAt(s.map,7,4)};
}
for(const kind of ['archer','chinaCrossbow','romanArcher']){
 test(`${kind}: mountain shoulder must not hide an in-range plain target`,()=>{
  for(const wall of [false,true]){const {s,u}=setup(kind,true,false,wall);setTerrain(s.map,5,4,TERRAIN.MOUNTAIN|TERRAIN.ROAD);recomputeFog(s);assert.ok(visibleTo(s,'egypt',7,4));assert.ok(attackPreview(s,u,7,4));}
 });
 test(`${kind}: downhill adds exactly 0.5, uphill subtracts 1, same elevation unchanged`,()=>{
  const damage=(a,b)=>{const {s,u}=setup(kind,a,b);return attackPreview(s,u,7,4).damage;};
  const flat=damage(false,false);assert.equal(damage(true,false),flat+5);assert.equal(damage(false,true),flat-10);assert.equal(damage(true,true),flat);
 });
 test(`${kind}: range limits are hex distance in all directions and both row parities`,()=>{
  for(const row of [8,9])for(let direction=0;direction<6;direction++){
   const m=newMap(24,20);m.scenarioId='custom_elevation_test';addUnit(m,'pharaoh','egypt',0,0);setTerrain(m,12,row,TERRAIN.MOUNTAIN);
   addUnit(m,kind,'egypt',12,row);const max=kind==='romanArcher'?4:3;let p={c:12,r:row};for(let i=0;i<max;i++)p=neighbors(p.c,p.r)[direction];
   addUnit(m,'heavy','coalition',p.c,p.r);const s=startGame(m),u=mobileAt(s.map,12,row),target=mobileAt(s.map,p.c,p.r);
   assert.equal(distance(u,target),max);assert.ok(attackPreview(s,u,target.c,target.r));
   const beyond=neighbors(p.c,p.r)[direction];target.c=beyond.c;target.r=beyond.r;recomputeFog(s);assert.equal(distance(u,target),max+1);assert.equal(attackPreview(s,u,target.c,target.r),null);
  }
 });
 test(`${kind}: preview matches resolved elevation damage`,()=>{
  for(const [high,low]of[[true,false],[false,true]]){const {s,u,target}=setup(kind,high,low),p=attackPreview(s,u,target.c,target.r),before=target.hp;
   const result=attack(s,u.id,target.c,target.r,0);assert.equal(result.unitDamage,p.damage);assert.equal(target.hp,before-p.damage);}
 });
}
test('flat-ground mountain obstruction and intervening enemies/walls remain effective',()=>{
 const {s,u}=setup();setTerrain(s.map,5,4,TERRAIN.MOUNTAIN);recomputeFog(s);assert.equal(attackPreview(s,u,7,4),null);
 setTerrain(s.map,4,4,TERRAIN.MOUNTAIN);setTerrain(s.map,5,4,TERRAIN.PLAIN);setFort(s.map,5,4,2,'coalition');recomputeFog(s);assert.equal(attackPreview(s,u,7,4),null);
});
test('mountain wall bonus remains additive, and archers get no ranged elevation bonus in melee',()=>{
 const a=setup('archer',true,false,true),b=setup('archer',false,false,true);
 assert.equal(attackPreview(a.s,a.u,7,4).damage,attackPreview(b.s,b.u,7,4).damage+5);
 const x=setup('archer',true),y=setup('archer');for(const q of[x,y]){q.target.c=5;q.target.r=4;recomputeFog(q.s);}
 assert.equal(attackPreview(x.s,x.u,5,4).damage,attackPreview(y.s,y.u,5,4).damage);
});
