import * as T from '../vendor/three/three.module.js';
import {materials as M,part,oval,box,rod,joint} from './models-v02.mjs';
import {loft,sweep,panel,cloth} from './historical-geometry.mjs';
// Original support-unit meshes; reuse the existing walking, wheel and ballista rigs.
const stone=new T.MeshStandardMaterial({color:0xb5a48a,roughness:.98});stone.userData.atlasCell=6;
const stoneLight=new T.MeshStandardMaterial({color:0xcbbba0,roughness:.98});stoneLight.userData.atlasCell=6;
const mortar=new T.MeshStandardMaterial({color:0x716957,roughness:1});mortar.userData.atlasCell=6;
export function buildDraughtOx(parent,low,{position=[1.24,0,0],harness=true}={}){
 const g=joint(parent,'draught-ox',position);g.userData.anatomy='short-necked-draught-ox';
 loft(g,M.bay,[[-1.02,1.34,0,.12,.18],[-.77,1.42,0,.43,.38],[-.15,1.40,0,.49,.45],[.52,1.43,0,.49,.42],[.86,1.39,0,.33,.30]],{sides:low?8:16});
 oval(g,M.bay,[.59,1.47,0],[.40,.52,.43]);
 for(const x of [-.69,.61])for(const side of [-1,1]){
  const leg=joint(g,`beastleg:${x<0?-.8:.8}:${side}`,[x,1.35,side*.31]);
  sweep(leg,M.bay,[[0,0,0],[x<0?-.12:.05,-.56,0],[.05,-1.13,0]],[.155,.085,.07],{sides:low?5:8,steps:low?5:10});
  oval(leg,M.bay,[x<0?-.12:.05,-.56,0],[.11,.13,.105]);
  for(const dz of [-.052,.052])loft(leg,M.hoof,[[.10,-1.31,dz,.13,.048],[.10,-1.23,dz,.13,.048],[.06,-1.14,dz,.08,.039]],{axis:'y',sides:low?5:8});
 }
 // Low, broad head and lateral horns clearly distinguish the ox from a horse.
 const head=joint(g,'ox-head',[.88,1.38,0]);
 loft(head,M.bay,[[0,.10,0,.33,.31],[.30,.02,0,.30,.27],[.61,-.23,0,.20,.25],[.73,-.27,0,.16,.23]],{sides:low?8:14});
 oval(head,M.pale,[.68,-.26,0],[.15,.17,.245]);
 for(const side of [-1,1]){
  oval(head,M.mane,[.72,-.24,side*.21],[.045,.035,.023]);
  oval(head,M.mane,[.28,.18,side*.245],[.043,.041,.023]);
  const ear=oval(head,M.bay,[.03,.12,side*.39],[.17,.065,.22]);ear.rotation.x=side*.25;
  sweep(head,M.ivory,[[.02,.32,side*.20],[-.04,.40,side*.43],[.04,.49,side*.62],[.14,.68,side*.63]],[.085,.065,.035,.008],{steps:low?7:14,sides:low?5:8});
  rod(head,M.leather,[.60,-.13,side*.25],[.60,-.41,side*.22],.021);
  rod(head,M.leather,[.12,.23,side*.27],[.60,-.13,side*.25],.023);
 }
 rod(head,M.leather,[.60,-.13,-.25],[.60,-.13,.25],.021);
 const tail=joint(g,'tail',[-.91,1.48,0]);sweep(tail,M.bay,[[0,0,0],[-.16,-.35,.02],[-.13,-.81,.04]],[.045,.03,.023],{steps:8,sides:5});oval(tail,M.mane,[-.13,-.87,.04],[.07,.15,.07]);
 // Wooden yoke over the shoulders, leather collar underneath.
 if(harness){const yoke=joint(g,'ox-yoke',[.55,1.79,0]);box(yoke,M.wood,[0,0,0],[.20,.15,1.05]);
 for(const side of [-1,1])sweep(yoke,M.leather,[[0,0,side*.32],[.02,-.38,side*.40],[.02,-.61,side*.24],[0,-.65,0]],[.035,.035],{steps:9,sides:5});
 }
 return g;
}
function sack(parent,x,y,z,low,turned=false){
 const s=joint(parent,'grain-sack',[x,y,z]);if(turned)s.rotation.z=.12;
 loft(s,M.linen,[[0,0,0,.24,.30],[0,.13,0,.31,.35],[0,.44,0,.30,.33],[0,.61,0,.22,.25],[0,.69,0,.075,.075],[0,.79,0,.11,.10]],{axis:'y',sides:low?6:12});
 part(s,new T.TorusGeometry(.08,.019,4,low?7:12),M.leather,[0,.69,0]).rotation.x=Math.PI/2;
 if(!low){sweep(s,M.leather,[[.015,.68,.07],[.07,.62,.13],[.10,.49,.18]],[.011,.011],{steps:6,sides:4});rod(s,M.pale,[-.17,.13,.29],[-.18,.49,.27],.012);}
}
export function buildSupplyWagon(parent,team,p,low,person){
 const g=joint(parent,'supply-assembly',[0,.25,0]);
 buildDraughtOx(g,low);
 const cart=joint(g,'grain-cart',[-1.52,0,0]);
 for(const z of [-.62,.62])box(cart,M.darkWood,[0,.89,z],[2.30,.19,.15]);
 rod(cart,M.wood,[0,.70,-1.12],[0,.70,1.12],.095);
 for(const z of [-1.0,1.0]){
  const w=joint(cart,'wheel',[0,.70,z]);
  part(w,new T.TorusGeometry(.60,.075,5,low?12:22),M.wood,[0,0,0]);
  part(w,new T.TorusGeometry(.655,.025,4,low?12:22),M.iron,[0,0,0]);
  for(let i=0;i<10;i++){const a=i*Math.PI/5;rod(w,M.wood,[0,0,0],[.57*Math.cos(a),.57*Math.sin(a),0],.035);}
  rod(w,M.darkWood,[0,0,-.14],[0,0,.14],.12);oval(w,M.iron,[0,0,Math.sign(z)*.16],[.09,.09,.04]);
 }
 for(let i=0;i<8;i++)box(cart,M.wood,[-1.04+i*.30,1.04,0],[.28,.13,1.70]);
 for(const side of [-1,1]){
  for(const y of [1.22,1.46])box(cart,M.wood,[0,y,side*.85],[2.42,.17,.075]);
  for(const x of [-1.13,0,1.13]){box(cart,M.darkWood,[x,1.40,side*.88],[.09,.80,.10]);if(!low)for(const y of [1.23,1.47])oval(cart,M.iron,[x,y,side*.94],[.026,.026,.012]);}
 }
 for(const y of [1.22,1.46])box(cart,M.wood,[-1.16,y,0],[.08,.17,1.68]);
 for(const x of [-.77,0,.77])for(const z of [-.39,.39])sack(cart,x,1.11,z,low);
 for(const x of [-.38,.42])sack(cart,x,1.77,0,low,true);
 // Lash the cargo over the stack and onto the cart rails.
 for(const x of [-.45,.45])sweep(cart,M.leather,[[x,1.37,-.91],[x,2.13,-.39],[x,2.42,0],[x,2.13,.39],[x,1.37,.91]],[.022,.022],{steps:low?8:16,sides:4});
 for(const side of [-1,1])rod(g,M.wood,[-.42,1.01,side*.66],[1.83,1.78,side*.49],.055);
 const civilian={...p,armor:0,commander:false,heroicRegalia:false,weapon:'none',rangedWeapon:null};
 const driver=person(g,team,civilian,[.32,-.12,1.25],.67,{crew:true,crewRole:'driver'});
 driver.name='soldier'; // Reuse the existing march rig, with no combat equipment.
 // Rein is static/lightweight; the walking body and ox legs retain existing motion.
 sweep(g,M.leather,[[1.88,1.32,.25],[1.20,1.37,.77],[.57,1.26,.94]],[.014,.014],{steps:10,sides:4});
 box(cart,team==='egypt'?M.blue:M.red,[-1.22,1.46,0],[.035,.36,.49]);
}
function towerBallista(g){
 const aim=joint(g,'siege-aim',[.20,3.56,0]);
 part(aim,new T.CylinderGeometry(.36,.45,.38,10),M.darkWood,[0,.19,0]);
 box(aim,M.wood,[.02,.65,0],[1.95,.18,.29]);
 for(const z of [-.64,.64]){
  box(aim,M.wood,[.49,.61,z],[.16,.91,.18]);
  rod(aim,M.linen,[.49,.26,z],[.49,1.0,z],.075);
  for(const y of [.29,.96])box(aim,M.bronze,[.49,y,z],[.30,.07,.28]);
 }
 for(const y of [.24,1.04])box(aim,M.wood,[.49,y,0],[.22,.14,1.65]);
 const bow=joint(aim,'ballista-bow',[.49,.73,0]);
 for(const side of [-1,1]){
  rod(bow,M.darkWood,[0,0,side*.64],[.47,0,side*1.08],.065,.045);
  rod(bow,M.linen,[.47,0,side*1.08],[-.72,0,0],.018);
 }
 const bolt=joint(aim,'loaded-arrow',[0,.77,0]);rod(bolt,M.wood,[-.80,0,0],[1.30,0,0],.027);
 part(bolt,new T.ConeGeometry(.065,.23,4),M.iron,[1.39,0,0]).rotation.z=-Math.PI/2;
 for(const z of [-.04,.04])box(bolt,M.linen,[-.67,.02,z],[.22,.12,.015]);
 joint(aim,'muzzle',[1.51,.77,0]);
 // Cranking handles and a rear winding drum make the loading mechanism legible.
 rod(aim,M.wood,[-.77,.59,-.35],[-.77,.59,.35],.08);
 for(const z of [-.36,.36])rod(aim,M.iron,[-.77,.59,z],[-.77,.83,z],.025);
}
export function buildDefenseTower(g,team,p,low,person){
 const masonry=joint(g,'masonry-tower',[0,0,0]);
 box(masonry,stone,[0,.18,0],[3.05,.36,3.05]);box(masonry,stoneLight,[0,.43,0],[2.78,.16,2.78]);
 box(masonry,mortar,[0,1.87,0],[2.18,2.80,2.18]);
 // Staggered ashlar courses: the seams and alternating corners break the old cube.
 for(let row=0;row<7;row++){
  const y=.69+row*.40,width=2.48-row*.035;
  const cuts=row%2?[-.5,-.375,-.125,.125,.375,.5]:[-.5,-.25,0,.25,.5];
  for(const side of [-1,1])for(let i=0;i<cuts.length-1;i++){
   const t=(cuts[i]+cuts[i+1])*width/2,w=(cuts[i+1]-cuts[i])*width-.025,shade=(i+row)%3===0?stoneLight:stone;
   box(masonry,shade,[t,y,side*(width/2-.04)],[w,.37,.17]);
   box(masonry,shade,[side*(width/2-.04),y,t],[.17,.37,w]);
  }
 }
 box(masonry,stoneLight,[0,3.36,0],[2.86,.22,2.86]);
 // Recessed archway at the front, fitted with a plank door and iron straps.
 const door=joint(masonry,'tower-door',[1.27,.50,0]);door.rotation.y=Math.PI/2;
 panel(door,M.darkWood,[[-.34,0],[.34,0],[.34,1.02],[.27,1.21],[0,1.34],[-.27,1.21],[-.34,1.02]],.035);
 for(const x of [-.24,-.08,.08,.24])box(door,M.wood,[x,.51,.045],[.14,.99,.04]);
 for(const y of [.27,.81])box(door,M.iron,[0,y,.075],[.64,.065,.035]);
 for(const side of [-1,1])for(const y of [.26,.65,1.04])box(door,stoneLight,[side*.45,y,.01],[.18,.36,.14]);
 for(let i=0;i<7;i++){const a=i*Math.PI/6,b=box(door,stoneLight,[.43*Math.cos(a),1.05+.43*Math.sin(a),.01],[.20,.23,.14]);b.rotation.z=a-Math.PI/2;}
 // Narrow arrow slits and projecting timber supports beneath the fighting deck.
 for(const side of [-1,1]){
  box(masonry,M.mane,[0,2.47,side*1.225],[.095,.52,.02]);
  for(const x of [-.90,0,.90]){box(g,M.darkWood,[x,3.29,side*1.36],[.13,.18,.60]);rod(g,M.wood,[x,2.90,side*1.16],[x,3.28,side*1.58],.05);}
 }
 const deck=joint(g,'fighting-platform',[0,3.52,0]);
 for(let i=0;i<10;i++)box(deck,M.wood,[-1.40+i*.31,0,0],[.29,.13,3.02]);
 for(const side of [-1,1]){
  box(deck,stone,[0,.31,side*1.46],[3.08,.52,.18]);
  for(const x of [-1.37,-.69,0,.69,1.37])box(deck,stoneLight,[x,.77,side*1.46],[.38,.43,.26]);
  box(deck,stone,[side*1.46,.28,0],[.18,.46,2.72]);
  for(const z of [-.96,.96])box(deck,stoneLight,[side*1.46,.73,z],[.27,.49,.42]);
 }
 // Back ladder reaches the deck; no wheels on a fixed military tower.
 for(const z of [-.35,.35])rod(g,M.wood,[-1.72,.42,z],[-1.54,3.62,z],.045);
 for(let i=0;i<10;i++)rod(g,M.wood,[-1.70+i*.017,.57+i*.31,-.35],[-1.70+i*.017,.57+i*.31,.35],.032);
 towerBallista(g);
 const crew={...p,armor:0,commander:false,weapon:'none',rangedWeapon:null};
 for(const z of [-.82,.82])person(g,team,crew,[-.62,3.42,z],.48,{crew:true,crewRole:'loader'});
 const flag=joint(g,'tower-banner',[-.20,3.25,1.49]);
 cloth(flag,team==='egypt'?M.blue:M.red,[[[-.32,0,0],[.32,0,0]],[[-.32,-.60,.03],[.32,-.60,.03]],[[-.23,-.91,.05],[.23,-.91,.05]]]);
 rod(flag,M.bronze,[-.38,.04,0],[.38,.04,0],.026);
}
