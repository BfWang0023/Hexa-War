import {meKind} from './middle-earth-data.mjs';
// Base attributes stay immutable. All runtime growth is derived from these tables.
export const GROWTH = Object.freeze([
  {hp:1, attack:1, defense:1, recovery:1},
  {hp:1.2, attack:1.1, defense:1.1, recovery:1.5},
  {hp:1.5, attack:1.3, defense:1.3, recovery:2},
  {hp:1.8, attack:1.5, defense:1.5, recovery:2.2},
  {hp:2, attack:1.6, defense:1.6, recovery:2.5}
]);
export const PROMOTION_COSTS = Object.freeze([1,1,2,2]);
export const ELITE_KINDS = new Set(['guard','romanTriarii','romanLegion','romanPrincipes',
  'caesarReserve','pompeyLegion','zamaVeteran','africanInfantry','phalangite',
  'greekHoplite','companionCavalry','parthianCataphract']);
export const COMMAND_KINDS = new Set(['pharaoh','hittiteKing','hannibal','paullus','varro','scipio','masinissa','chinaGeneral']);
export const growthLevel = u => u?.veteranLevel ?? 0;
export const growth = u => GROWTH[growthLevel(u)] || GROWTH[0];
export const eliteIdentity = u => !!u?.elite || ELITE_KINDS.has(u?.kind);
export const commanderIdentity = u => !!u?.commander || !!u?.hero || u?.kind==='hero' || COMMAND_KINDS.has(u?.kind);
export const combatUnit = u => !!u && !meKind(u.kind)?.story && !['fort','defenseTower','captive','transport','supplyWagon','arrowCamel','engineer','trojanHorse'].includes(u.kind);
export const friendly = (a,b) => !!a && !!b && a.team===b.team && !a.mutinous && !b.mutinous;
export const hostile = (a,b) => !!a && !!b && a.id!==b.id && (a.team!==b.team || !!a.mutinous || !!b.mutinous);
export const controlledBy = (u,team) => !!u && u.team===team && !u.mutinous;
export function validateGrowth(u) {
  for(const [key,max] of [['veteranLevel',4],['kills',10000000],['promotionProgress',10000000],['unpaidTurns',100000],['combatStreak',100000],['lastCombatTurn',100000],['mutinyTurn',100000],['mutinyCheckedTurn',100000],['lastMutinyActionTurn',100000]]) {
    if(u[key]!==undefined && (!Number.isSafeInteger(u[key]) || u[key]<0 || u[key]>max))throw Error('等级或哗变状态无效：'+key);
  }
  if(u.starvationRatio!==undefined&&(!Number.isFinite(u.starvationRatio)||u.starvationRatio<0||u.starvationRatio>1))throw Error('饥饿比例状态无效');
  if(u.mutinyCause!==undefined&&(typeof u.mutinyCause!=='string'||u.mutinyCause.length>100))throw Error('哗变原因无效');
  if(u.mutinous!==undefined && typeof u.mutinous!=='boolean')throw Error('哗变状态无效');
  if(u.elite!==undefined && typeof u.elite!=='boolean')throw Error('精锐身份无效');
  if(u.wageArrears!==undefined && (!Number.isFinite(u.wageArrears)||u.wageArrears<0))throw Error('欠饷状态无效');
}
export function creditKill(s,attacker,defender,maxHp) {
  if(!s.growthRules || !combatUnit(defender) || defender.hp>0 || defender.deathCredit || !hostile(attacker,defender))return false;
  defender.deathCredit={id:attacker.id,turn:s.turn,team:attacker.mutinous?null:attacker.team};
  attacker.kills=(attacker.kills||0)+1;
  if(!combatUnit(attacker))return true;
  const before=growthLevel(attacker),oldMax=maxHp(s.map,attacker),ratio=oldMax?attacker.hp/oldMax:0;
  const reward=commanderIdentity(defender)?4:eliteIdentity(defender)?2:0;
  if(reward)attacker.veteranLevel=Math.min(4,before+reward);
  else if(before<4){
    attacker.promotionProgress=(attacker.promotionProgress||0)+1;
    while(growthLevel(attacker)<4 && attacker.promotionProgress>=PROMOTION_COSTS[growthLevel(attacker)]){
      attacker.promotionProgress-=PROMOTION_COSTS[growthLevel(attacker)];
      attacker.veteranLevel=growthLevel(attacker)+1;
    }
  }
  if(growthLevel(attacker)>before){
    attacker.hp=Math.min(maxHp(s.map,attacker),Math.max(attacker.hp>0?1:0,Math.round(ratio*maxHp(s.map,attacker))));
    s.log.push(`${attacker.id} 晋升 ${before}→${growthLevel(attacker)}级`);
  }
  return true;
}
