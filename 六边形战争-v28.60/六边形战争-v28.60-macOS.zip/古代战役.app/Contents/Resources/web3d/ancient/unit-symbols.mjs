import {ME_STATS} from './middle-earth-data.mjs';
// Original monochrome map symbols, drawn as reusable vector paths; no third-party artwork.
import {STATS} from './engine.mjs';
const shapes={
 scout:['斥候','M1 8 Q8 0 15 8 Q8 16 1 8 Z M8 5 A3 3 0 1 0 8 11 A3 3 0 1 0 8 5'],
 sword:['剑盾步兵','M3 4 L3 10 Q6 14 9 10 L9 4 Z M9 11 L14 2 M12 2 L14 2 L14 4 M9 8 L12 11'],
 spear:['长矛兵','M5 14 L5 3 M3 5 L5 1 L7 5 M10 14 L10 3 M8 5 L10 1 L12 5'],
 bow:['弓箭手','M4 2 Q15 8 4 14 L4 2 M2 8 L14 8 M11 5 L14 8 L11 11'],
 crossbow:['弩兵','M3 5 Q8 1 13 5 M3 5 L13 5 M8 2 L8 14 M6 12 L10 12 M8 2 L8 10'],
 horse:['骑兵','M3 13 L5 9 L4 5 L8 2 L12 4 L12 8 L9 7 L8 10 L12 14 M4 14 L12 14 M7 3 L6 1'],
 horsebow:['骑射兵','M2 13 L4 9 L4 5 L8 2 L10 4 L10 8 L7 7 L6 10 M11 2 Q16 8 11 14 L11 2'],
 armorhorse:['具装骑兵','M3 13 L5 9 L4 5 L8 2 L12 4 L12 8 L9 7 L8 10 L12 14 M4 14 L12 14 M2 5 L2 10 M1 7 L4 7'],
 chariot:['战车','M2 5 L12 5 L12 10 L3 10 Z M12 7 L15 4 M4 10 L4 14 M10 10 L10 14 M2 12 L6 12 M8 12 L12 12'],
 elephant:['战象','M2 11 L2 5 Q7 1 12 5 L14 6 L14 13 L12 13 L12 8 M3 10 L3 14 M8 10 L8 14 M5 5 Q9 6 8 10'],
 ship:['战船','M1 10 L15 10 L12 14 L4 14 Z M8 10 L8 1 L13 7 L8 7 M2 8 L5 5'],
 transport:['运输船','M1 10 L15 10 L12 14 L4 14 Z M5 9 L5 4 L11 4 L11 9 M8 4 L8 9'],
 ram:['攻城槌','M2 13 L5 3 L11 3 L14 13 M3 9 L14 9 M5 4 L5 9 M11 4 L11 9 M2 14 L4 14 M12 14 L14 14'],
 tower:['塔式器械','M4 14 L4 3 L2 3 L2 1 L6 1 L6 3 L10 3 L10 1 L14 1 L14 3 L12 3 L12 14 M3 14 L13 14 M7 9 L9 9 L9 14'],
 catapult:['抛石器械','M2 13 L14 13 M4 13 L7 5 L10 13 M6 8 L12 2 L15 2 M3 14 L5 14 M11 14 L13 14'],
 wagon:['后勤运输','M2 5 L13 5 L13 11 L2 11 Z M5 5 L5 2 L10 2 L10 5 M3 11 L3 14 M11 11 L11 14 M1 13 L5 13 M9 13 L13 13'],
 general:['统帅英雄','M8 1 L10 6 L15 6 L11 9 L13 15 L8 12 L3 15 L5 9 L1 6 L6 6 Z'],
 guard:['卫队督战','M3 2 L13 2 L13 9 Q8 16 3 9 Z M5 7 L7 9 L11 5'],
 engineer:['工程兵','M3 14 L12 3 M8 2 L12 1 L15 4 L13 6 Z M2 3 L5 6 M2 6 L5 3'],
 ox:['火牛','M3 13 L3 7 L1 4 M3 7 L6 5 L10 5 L13 7 L15 4 M13 7 L13 13 M5 6 L5 3 Q8 6 8 1 Q13 5 10 7'],
 camel:['骆驼后勤','M2 13 L3 7 Q5 2 7 7 Q9 2 11 7 L13 5 L14 2 M4 9 L4 14 M10 9 L10 14'],
 civilian:['非战斗人员','M8 1 L8 4 M4 6 L12 6 M8 4 L8 11 M8 11 L4 15 M8 11 L12 15'],
 wall:['城墙','M1 14 L1 3 L4 3 L4 6 L7 6 L7 3 L10 3 L10 6 L13 6 L13 3 L15 3 L15 14 Z'],
};
export const SYMBOL_SHAPES=Object.freeze(Object.fromEntries(Object.entries(shapes).map(([id,[label,path]])=>[id,Object.freeze({id,label,path})])));
const mapping={scout:'scout'};const add=(ids,symbol)=>ids.split(' ').forEach(id=>mapping[id]=symbol);
add('light heavy phalangite greekHoplite romanTriarii africanInfantry','spear');
add('guard romanHastati romanPrincipes romanLegion caesarReserve pompeyLegion gaulInfantry iberianInfantry zamaVeteran','sword');
add('archer romanArcher','bow');add('chinaCrossbow','crossbow');
add('cavalry companionCavalry romanHorse romanAlliedHorse pompeyHorse punicHeavyHorse zamaPunicHorse numidianHorse masinissaHorse','horse');
add('parthianHorseArcher','horsebow');add('parthianCataphract','armorhorse');
add('chariot hittiteChariot chinaHeavyChariot scythedChariot','chariot');
add('pharaoh hittiteKing hero chinaGeneral hannibal paullus varro scipio masinissa','general');
add('warship siegeGalley athenianTrireme alliedTrireme phoenicianTrireme imperialTrireme octavianLiburnian antonyHeavyGalley cleopatraGalley','ship');
add('transport','transport');add('moraleGuard moraleFlagship','guard');add('warElephant','elephant');
add('siegeRam trojanHorse','ram');add('siegeTower defenseTower','tower');add('romanOnager','catapult');
add('supplyWagon','wagon');add('arrowCamel','camel');add('engineer','engineer');add('chinaFireOx','ox');add('captive','civilian');
add('romanVelites punicSkirmisher','spear');add('fort','wall');
for(const [kind,s] of Object.entries(ME_STATS)){
  mapping[kind]=s.air?'horse':s.role==='ship'?'ship':s.role==='mumak'?'elephant':
    s.role==='grond'?'ram':s.role==='blast'?'engineer':s.role==='wolf'?'horse':
    s.mountedRole?(s.ranged?'horsebow':'horse'):s.ranged?'bow':s.story?'general':'sword';
}
export const UNIT_SYMBOLS=Object.freeze(mapping);
export const unitSymbol=u=>SYMBOL_SHAPES[UNIT_SYMBOLS[u.kind]];
