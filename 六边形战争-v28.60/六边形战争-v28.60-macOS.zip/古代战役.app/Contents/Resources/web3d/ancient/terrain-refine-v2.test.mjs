import test from 'node:test';import assert from 'node:assert/strict';import * as E from './engine.mjs';import {roadPaths} from './road-visual.mjs';import {offsetToWorld} from '../js/core/hex.js';import {vegetationPoints} from './terrain-vegetation.mjs';import {terrainArtProfile} from './terrain-art-profile.mjs';import {mountainSurfaceColor} from './mountain-visual.mjs';import * as T from '../vendor/three/three.module.js';
test('two-way roads form smooth curves wholly within the painted cell and retain shared edge endpoints',()=>{const m=E.newMap(16,12),p={c:7,r:6},neighbors=E.neighbors(p.c,p.r);for(let direction=1;direction<6;direction++){m.terrain.fill(0);for(const cell of [p,neighbors[0],neighbors[direction]])m.terrain[E.index(m,cell.c,cell.r)]=1;const path=roadPaths(m,p.c,p.r)[0],center=offsetToWorld(p.c,p.r);assert.equal(path.steps,6);for(let t=0;t<=1;t+=.05){const q=path.point(t);assert.ok(Math.hypot(q.x-center.x,q.z-center.z)<=6);assert.ok(Math.hypot(q.dx,q.dz)>1);}for(const n of [neighbors[0],neighbors[direction]]){const adjacent=roadPaths(m,n.c,n.r),candidates=adjacent.flatMap(p=>[p.point(0),p.point(1)]),endpoints=[path.point(0),path.point(1)];assert.ok(endpoints.some(a=>candidates.some(b=>Math.hypot(a.x-b.x,a.z-b.z)<1e-8&&Math.abs((a.dx*b.dx+a.dz*b.dz)/(Math.hypot(a.dx,a.dz)*Math.hypot(b.dx,b.dz)))>.999)));}}});
test('junctions retain all road branches without changing map data',()=>{const m=E.newMap(12,10);for(const p of [{c:5,r:5},...E.neighbors(5,5)])m.terrain[E.index(m,p.c,p.r)]=1;const before=JSON.stringify(m);assert.equal(roadPaths(m,5,5).length,6);assert.equal(JSON.stringify(m),before);});
test('ridge vegetation is reduced, deterministic, and absent from unknown terrain',()=>{const m=E.newMap(40,30);m.terrain.fill(2);m.elevations=Array(1200).fill(1);const low=vegetationPoints(m);m.elevations.fill(5);const high=vegetationPoints(m);assert.ok(high.trees.length<low.trees.length);assert.ok(high.grass.length<low.grass.length);assert.deepEqual(vegetationPoints(m),high);m.unknown=new Uint8Array(1200).fill(1);assert.equal(vegetationPoints(m).trees.length,0);assert.equal(vegetationPoints(m).grass.length,0);});
test('terrain profile uses observed neighbours only and distinguishes valley curvature',()=>{const m=E.newMap(12,10);m.elevations=Array(120).fill(2);m.elevations[E.index(m,5,5)]=1;assert.equal(terrainArtProfile(m,5,5).valley,true);m.unknown=new Uint8Array(120).fill(1);m.unknown[E.index(m,5,5)]=0;const before=terrainArtProfile(m,5,5);for(const p of E.neighbors(5,5))m.elevations[E.index(m,p.c,p.r)]=90;assert.deepEqual(terrainArtProfile(m,5,5),before);});
test('foothill materials are not dark green baked shadow bands',()=>{const plain=mountainSurfaceColor(new T.Color(),0,0,1,0),foot=mountainSurfaceColor(new T.Color(),1,0,1,0,1),slope=mountainSurfaceColor(new T.Color(),3,.2,.96,.1,1);assert.ok(foot.r>plain.r*.8);assert.ok(foot.g>plain.g*.75);assert.ok(slope.r>slope.g);assert.ok(Math.max(foot.r,foot.g,foot.b)<.6);});
test('road geometry remains grounded at bends and chunk borders',async()=>{const {createRoads}=await import('./terrain-surface.mjs');const m=E.newMap(24,18);for(const p of [{c:15,r:8},{c:16,r:8},{c:16,r:7},{c:16,r:6},{c:17,r:5}])m.terrain[E.index(m,p.c,p.r)]=3;const h=(c,r,x,z)=>Math.sin(x*.015)*2+z*.02,a=createRoads(m,h,{c0:0,r0:0,c1:16,r1:18}),b=createRoads(m,h,{c0:16,r0:0,c1:24,r1:18});for(const mesh of [a,b]){const p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++)assert.ok(Math.abs(p.getY(i)-h(0,0,p.getX(i),p.getZ(i))-.06)<1e-5);mesh.geometry.dispose();}});

// Constant logical height isolates the connected visual ridge/saddle relief.
test('visual ridge and saddle variation has volume across many cells, without logical writes',async()=>{const {mountainSurfaceHeight}=await import('./mountain-visual.mjs');const values=[];for(let x=50;x<300;x+=1)values.push(mountainSurfaceHeight(3,1,x,150));assert.ok(Math.max(...values)-Math.min(...values)>4);assert.ok(Math.max(...values)-Math.min(...values)<10);for(let i=1;i<values.length;i++)assert.ok(Math.abs(values[i]-values[i-1])<.3);});

test('distance haze preserves distant terrain without adding lights or changing knowledge masks',async()=>{const {createTerrainEnvironment}=await import('./terrain-environment.mjs');const scene=new T.Scene();scene.fog=new T.Fog(0x05070a,260,700);const renderer={shadowMap:{}},environment=createTerrainEnvironment(scene,renderer);assert.equal(scene.fog.near,320);assert.equal(scene.fog.far,1400);assert.equal(scene.children.filter(o=>o.isLight).length,2);environment.setQuality('low');assert.equal(renderer.shadowMap.enabled,false);});

test('historical background joins the board, continues edge water and ignores hidden terrain',async()=>{
  const {createTerrainRefresh}=await import('./terrain-refresh.mjs');
  const m=E.newMap(22,16),view=createTerrainRefresh();
  m.terrain[E.index(m,0,6)]=E.TERRAIN.SEA;
  m.houses[E.index(m,8,8)]=1;
  view.refresh(m);
  const horizon=()=>view.group.getObjectByName('historical-horizon');
  const initial=horizon(),sea=initial.getObjectByName('historical-horizon-water');
  assert.ok(initial.geometry.attributes.position.array.every(Number.isFinite));
  assert.ok(initial.geometry.attributes.normal.array.every(Number.isFinite));
  assert.ok(sea.geometry.attributes.position.array.every(Number.isFinite));
  assert.ok(view.group.getObjectByName('historical-house-roof'));
  const ray=new T.Raycaster(new T.Vector3(-20,100,55),new T.Vector3(0,-1,0));
  assert.deepEqual(ray.intersectObject(initial,true),[]);
  assert.ok(!view.pickables.includes(initial));
  m.terrain[E.index(m,10,8)]=E.TERRAIN.MOUNTAIN;
  view.refresh(m);
  assert.equal(horizon(),initial);
  m.unknown=new Uint8Array(m.cols*m.rows);
  m.unknown[E.index(m,0,6)]=1;
  view.refresh(m);
  assert.notEqual(horizon(),initial);
  assert.equal(horizon().getObjectByName('historical-horizon-water'),undefined);
  view.dispose();
});
