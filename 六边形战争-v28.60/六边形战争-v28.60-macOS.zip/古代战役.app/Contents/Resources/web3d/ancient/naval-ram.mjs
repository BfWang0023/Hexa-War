// Sailing evidence belongs to simulation state, never to animation or model pose.
import {distance,neighbors,isTrireme,isRouted} from './engine.mjs';
import {facingDelta,validFacing} from './directions12.mjs';
import {movementRun,runMatches} from './charge-rules.mjs';
export const DEFAULT_RAM_RULES=Object.freeze({multiplier:3,stationaryMultiplier:2,frontalMultiplier:1,recoil:0.25});
export function ramConfig(value={}){const v={...DEFAULT_RAM_RULES,...value};if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(v).some(k=>!Object.hasOwn(DEFAULT_RAM_RULES,k))||!Number.isFinite(v.multiplier)||v.multiplier<1||v.multiplier>3||!Number.isFinite(v.stationaryMultiplier)||v.stationaryMultiplier<1||v.stationaryMultiplier>3||!Number.isFinite(v.frontalMultiplier)||v.frontalMultiplier<1||v.frontalMultiplier>v.multiplier||!Number.isFinite(v.recoil)||v.recoil<0||v.recoil>1)throw Error('冲角参数无效');return v;}
export const canRam=u=>isTrireme(u)&&u.kind!=='siegeGalley'&&u.hp>0&&!isRouted(u);
export const sailingDirection=(a,b)=>neighbors(a.c,a.r).findIndex(p=>p.c===b.c&&p.r===b.r);
export function sailingRun(s,u,from,path,previous){return {...movementRun(s,u,from,path,previous),initialFacing:previous?.initialFacing??from.facing};}
export function recordSailing(s,u,before,path){if(s.rulesVersion<20)return;const old=s.ramRuns?.[u.id],prior=runMatches(s,before,old)?old:null;s.ramRuns={};if(canRam(u))s.ramRuns[u.id]=sailingRun(s,u,before,path,prior);}
export function ramEffect(s,u,target,melee){
 const result={triggered:false,momentum:false,multiplier:1,recoil:0,reason:melee?'普通接舷：需沿船首连续接近至少两格':'远程射击不享受冲角加成'};
 if(s.rulesVersion<20||!melee||!canRam(u)||!isTrireme(target)||target.team===u.team||distance(u,target)!==1)return result;
 const cfg=ramConfig(s.ramRules),towardTarget=sailingDirection(u,target),frontTarget=facingDelta(target.facing,sailingDirection(target,u))<=.5;
 const ordinary=validFacing(u.facing)&&facingDelta(u.facing,towardTarget)<=.5&&!frontTarget?{triggered:true,momentum:false,multiplier:cfg.stationaryMultiplier,recoil:0,reason:'无冲锋侧舷／船尾冲角'}:result;
 const run=s.ramRuns?.[u.id];if(!runMatches(s,u,run)||run.blocked||run.points.length<3)return ordinary;
 const ps=run.points,tail=ps.slice(-3),dirs=tail.slice(1).map((p,i)=>sailingDirection(tail[i],p));
 const heading=ps.length===3?run.initialFacing:sailingDirection(ps.at(-4),tail[0]);
 const toward=sailingDirection(u,target),ds=tail.map(p=>distance(p,target));
 if(dirs.some(d=>d<0)||dirs[0]!==dirs[1]||!validFacing(heading)||facingDelta(heading,dirs[0])>.5||facingDelta(u.facing,dirs[1])>.5||facingDelta(u.facing,toward)>.5||!(ds[0]>ds[1]&&ds[1]>ds[2]))return ordinary;
 const front=facingDelta(target.facing,sailingDirection(target,u))<=.5;
 return {triggered:!front,momentum:true,multiplier:front?cfg.frontalMultiplier:cfg.multiplier,recoil:front?cfg.recoil:0,reason:front?'正面撞击':'侧舷／船尾冲角'};
}
export const ramText=e=>(e?.momentum||e?.triggered)?`${e.reason}：伤害 ×${e.multiplier.toFixed(2)}${e.recoil?`，反作用为普通伤害的 ${Math.round(e.recoil*100)}%`:''}`:e?.reason||'';
export function validateRamState(s){if(!s||!(s.rulesVersion>=20))return;if(!s.ramRules||!s.ramRuns||typeof s.ramRuns!=='object'||Array.isArray(s.ramRuns))throw Error('新版存档缺少冲角记录');ramConfig(s.ramRules);for(const [id,r]of Object.entries(s.ramRuns)){const u=s.map.units.find(v=>v.id===id);if(!u||!canRam(u)||!r||!Array.isArray(r.points)||r.points.length<2||r.points.length>32||!validFacing(r.initialFacing)||typeof r.blocked!=='boolean'||!runMatches(s,u,r)||r.points.some(p=>!Number.isInteger(p.c)||!Number.isInteger(p.r)||p.c<0||p.r<0||p.c>=s.map.cols||p.r>=s.map.rows)||r.points.slice(1).some((p,i)=>distance(r.points[i],p)!==1))throw Error('存档航行记录无效');}}
