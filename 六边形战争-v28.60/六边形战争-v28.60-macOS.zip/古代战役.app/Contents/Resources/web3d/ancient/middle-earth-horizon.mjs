import {morannonWindows} from './middle-earth-data.mjs';
import * as T from '../vendor/three/three.module.js';
import {hexCorners,offsetToWorld,worldToOffset} from '../js/core/hex.js';
import {TERRAIN} from './engine.mjs';
import {WATER_Y,historicalHorizonMaterials} from './terrain-surface.mjs';

const distances=[0,19,48,96,155,234,340,475,720,1010];
const ridge=(x,z,cx,cz,w,d)=>Math.exp(-(((x-cx)/w)**2+((z-cz)/d)**2));

export function createMiddleEarthHorizon(map,window,sample,edgeColor=null){
  const [first,last]=window??[0,map.cols];
  const historical=!!edgeColor;
  const center=offsetToWorld((first+last-1)/2,0);
  center.z=(map.rows-1)*4.5;
  const siege=map.scenarioId==='me_hornburg',erebor=map.scenarioId==='me_erebor';
  const mordor=map.scenarioId?.startsWith('me_morannon'),port=map.scenarioId==='me_pelargir';
  const city=map.scenarioId==='me_pelennor',ford=map.scenarioId?.startsWith('me_isen');
  const doom=mordor&&first===morannonWindows(map).doom[0];
  const ground=new T.Color(mordor?0x55494a:erebor?0x6c7652:0x728151);
  const summit=new T.Color(mordor?0x6f676a:0x9f9c89);
  const water=new T.Color(port?0x436c81:0x527786),soil=new T.Color();
  const position=[],color=[],triangles=[],perimeter=new Map(),edges=[],links=new Map();
  const waterPosition=[],waterColors=[];
  const ocean=new T.Color(0x315e70),river=new T.Color(0x426f76),waterTint=new T.Color();
  const inRegion=p=>p.col>=first&&p.col<last&&p.row>=0&&p.row<map.rows;
  const add=(c,r,x,z)=>{
    const key=`${Math.round(x*1e4)},${Math.round(z*1e4)}`;
    const i=r*map.cols+c,unknown=!!map.unknown?.[i];
    const t=unknown?TERRAIN.PLAIN:map.terrain[i];
    if(!perimeter.has(key)){
      const h=historical&&unknown?0:sample(c,r,x,z);
      perimeter.set(key,{x,z,h,t,angle:Math.atan2(z-center.z,x-center.x),edgeColor:historical?edgeColor(t,c,r):null,
        wet:0,sea:0,mountain:0,uses:0});
    }
    const point=perimeter.get(key);
    if(historical){
      point.uses++;
      point.wet+=Number(!!(t&(TERRAIN.SEA|TERRAIN.RIVER)));
      point.sea+=Number(!!(t&TERRAIN.SEA));
      point.mountain+=Number(!!(t&TERRAIN.MOUNTAIN));
    }
    return point;
  };
  for(let r=0;r<map.rows;r++)for(let c=first;c<last;c++){
    if(c!==first&&c!==last-1&&r!==0&&r!==map.rows-1)continue;
    const p=offsetToWorld(c,r),corners=hexCorners(p.x,p.z);
    for(let side=0;side<6;side++){
      const a=corners[side],b=corners[(side+1)%6];
      if(inRegion(worldToOffset(p.x+((a[0]+b[0])/2-p.x)*1.05,p.z+((a[1]+b[1])/2-p.z)*1.05)))continue;
      const edge=[0,1/3,2/3,1].map(u=>add(c,r,a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u));
      const terrain=map.unknown?.[r*map.cols+c]?TERRAIN.PLAIN:map.terrain[r*map.cols+c];
      edges.push({edge,terrain});
      for(let i=0;i<edge.length-1;i++){
        for(const [from,to] of [[edge[i],edge[i+1]],[edge[i+1],edge[i]]]){
          if(!links.has(from))links.set(from,new Set());
          links.get(from).add(to);
        }
      }
    }
  }
  // Follow the actual outer hex edges. Using each point's raw polar angle
  // would fold the apron where the concave corners of the hexes point inward.
  const start=perimeter.values().next().value;
  const rim=[start];
  while(rim.length<perimeter.size){
    const next=[...links.get(rim.at(-1))].find(p=>p!==start&&p!==rim.at(-2));
    if(!next)break;
    rim.push(next);
  }
  const orientation=Math.sign(rim.reduce((sum,p,i)=>{
    const q=rim[(i+1)%rim.length];
    return sum+((p.x-center.x)*(q.z-center.z)-(q.x-center.x)*(p.z-center.z));
  },0));
  const unwrap=(angle,base)=>base+Math.atan2(Math.sin(angle-base),Math.cos(angle-base));
  const radii=rim.map(p=>Math.hypot(p.x-center.x,p.z-center.z));
  const angles=[];
  for(const edge of rim)angles.push(angles.length?unwrap(edge.angle,angles.at(-1)):edge.angle);
  const around=i=>(i+rim.length)%rim.length;
  const waterMask=t=>!!(t&(TERRAIN.SEA|TERRAIN.RIVER));
  rim.forEach((edge,i)=>{
    const {x,z,h:h0,t}=edge;
    const wet=waterMask(t);
    let heightSum=0,heightWeight=0,angleSum=0,radiusSum=0,weightSum=0,ridgeSum=0;
    for(let j=-15;j<=15;j++){
      const k=around(i+j),p=rim[k],weight=16-Math.abs(j);
      const turn=i+j<0?-1:i+j>=rim.length?1:0;
      angleSum+=(angles[k]+turn*orientation*Math.PI*2)*weight;
      radiusSum+=radii[k]*weight;weightSum+=weight;
      if(historical)ridgeSum+=p.mountain/p.uses*weight;
      if(waterMask(p.t)===wet){heightSum+=p.h*weight;heightWeight+=weight;}
    }
    const smoothHeight=heightSum/heightWeight;
    const smoothAngle=angleSum/weightSum,smoothRadius=radiusSum/weightSum;
    edge.start=position.length/3;
    for(const d of distances){
      const blend=1-Math.exp(-d/9);
      const direction=T.MathUtils.lerp(angles[i],smoothAngle,blend);
      const radius=T.MathUtils.lerp(radii[i],smoothRadius,blend)+d;
      const xx=d===0?x:center.x+Math.cos(direction)*radius;
      const zz=d===0?z:center.z+Math.sin(direction)*radius;
      const u=xx-center.x,v=zz-center.z;
      const fade=1-Math.exp(-d/110);
      const far=2.3+3*Math.sin(u*.014+v*.011)+2.2*Math.sin(v*.022-u*.008);
      const north=erebor?145*ridge(u,v,-16,-340,174,116):
        mordor?95*ridge(u,v,47,-300,120,112):siege?129*ridge(u,v,-105,-280,148,108):
        ford?62*ridge(u,v,-190,-302,141,129):42*ridge(u,v,15,-310,203,145);
      const flank=siege?110*ridge(u,v,-355,-13,127,180):
        erebor?75*ridge(u,v,-310,-140,137,140):
        city?125*ridge(u,v,-320,96,114,137):
        doom?73*ridge(u,v,290,-111,100,148):
        mordor?94*ridge(u,v,-266,-115,106,117):28*ridge(u,v,-280,-30,97,198);
      const peaks=(north+flank)*(.80+.14*Math.cos(u*.038+v*.011)+.12*Math.sin(v*.043));
      const local=T.MathUtils.lerp(h0,smoothHeight,blend);
      if(historical){
        const terrainRise=Math.max(0,smoothHeight-1.8)*1.65+ridgeSum/weightSum*25;
        const highland=far+terrainRise*(.76+.28*Math.sin(u*.019-v*.012))+
          (terrainRise+5)*ridge(u,v,-155,-285,240,185);
        const oceanFloor=edge.sea/edge.uses;
        const riverBed=(edge.wet-edge.sea)/edge.uses*(1-T.MathUtils.smoothstep(d,20,115));
        const wetness=Math.min(1,oceanFloor+riverBed);
        const depth=wetness*T.MathUtils.smoothstep(d,0,14);
        const height=T.MathUtils.lerp(local*(1-fade)+fade*highland,-1.15,depth);
        soil.copy(edge.edgeColor).lerp(ground,(1-Math.exp(-d/90))*.91);
        soil.multiplyScalar(1+.05*Math.sin(u*.027+v*.033)*fade);
        soil.lerp(summit,T.MathUtils.smoothstep(height,6,48)*.7);
        position.push(xx,height-.025,zz);color.push(soil.r,soil.g,soil.b);
        continue;
      }
      const land=local*(1-fade)+fade*(far+peaks)-.045;
      const openWater=wet&&(!!(t&TERRAIN.SEA)||ford&&d<54);
      const h=openWater?local*(1-fade)-.44*fade:land;
      soil.copy(openWater?water:ground);
      if(!openWater)soil.lerp(summit,T.MathUtils.smoothstep(h,7,49)*.91);
      soil.multiplyScalar(.95+.05*Math.sin(xx*.025+zz*.025));
      position.push(xx,h,zz);color.push(soil.r,soil.g,soil.b);
    }
  });
  for(const {edge,terrain} of edges)for(let j=0;j<3;j++)for(let i=0;i<distances.length-1;i++){
    const a=edge[j].start+i,b=edge[j+1].start+i;
    const face=[a,b,a+1,b,b+1,a+1];
    triangles.push(...face);
    const openSea=terrain&TERRAIN.SEA;
    if(historical&&(openSea||terrain&TERRAIN.RIVER&&distances[i]<96)){
      const tint=openSea?ocean:river;
      for(const vertex of face){
        const x=position[vertex*3],z=position[vertex*3+2];
        waterPosition.push(x,WATER_Y,z);
        waterTint.copy(tint).multiplyScalar(1+.035*Math.sin(x*.034+z*.023));
        waterColors.push(waterTint.r,waterTint.g,waterTint.b);
      }
    }
  }
  const geometry=new T.BufferGeometry();
  geometry.setAttribute('position',new T.Float32BufferAttribute(position,3));
  geometry.setAttribute('color',new T.Float32BufferAttribute(color,3));
  geometry.setIndex(triangles);
  // Smooth normals across several edge samples so a row of tiny hex corners
  // does not cast apparent grooves across the much coarser distant slopes.
  const normals=new Float32Array(position.length);
  const tangent=new T.Vector3(),outward=new T.Vector3(),normal=new T.Vector3(),tmp=new T.Vector3();
  const vertex=(point,i,v)=>v.fromArray(position,(point.start+i)*3);
  for(let j=0;j<rim.length;j++)for(let i=0;i<distances.length;i++){
    const edge=rim[j];
    vertex(rim[around(j+7)],i,tangent).sub(vertex(rim[around(j-7)],i,tmp));
    vertex(edge,Math.min(i+1,distances.length-1),outward).sub(vertex(edge,Math.max(i-1,0),tmp));
    normal.crossVectors(tangent,outward).normalize();
    if(normal.y<0)normal.negate();
    normal.toArray(normals,(edge.start+i)*3);
  }
  geometry.setAttribute('normal',new T.BufferAttribute(normals,3));
  const materials=historical?historicalHorizonMaterials():null;
  const mesh=new T.Mesh(geometry,materials?.ground??new T.MeshLambertMaterial({vertexColors:true,side:T.DoubleSide}));
  mesh.name=historical?'historical-horizon':'middle-earth-horizon';
  mesh.raycast=()=>{};
  if(waterPosition.length){
    const waterGeometry=new T.BufferGeometry();
    waterGeometry.setAttribute('position',new T.Float32BufferAttribute(waterPosition,3));
    waterGeometry.setAttribute('color',new T.Float32BufferAttribute(waterColors,3));
    waterGeometry.computeVertexNormals();
    const waterMesh=new T.Mesh(waterGeometry,materials.water);
    waterMesh.name='historical-horizon-water';
    waterMesh.renderOrder=1;
    waterMesh.raycast=()=>{};
    mesh.add(waterMesh);
  }
  return mesh;
}
