import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {middleEarthAi,siegeObjective} from './middle-earth-rules.mjs';
import {createSave,restoreSave} from './save.mjs';

function field(){
  const map=makeMiddleEarthMap('me_pelennor',{legacy:true});
  map.units=[];
  map.terrain.fill(E.TERRAIN.PLAIN);
  map.elevations=Array(map.cols*map.rows).fill(0);
  map.victory.points.core={c:3,r:3};
  E.addUnit(map,'meGondor','egypt',3,3);
  E.addUnit(map,'meOrc','coalition',22,18);
  return map;
}
const unit=(s,kind)=>s.map.units.find(u=>u.kind===kind);
const shot=(s,u,v)=>E.attack(s,u.id,v.c,v.r,0,.5,.9,.9);

test('mountain and wall archers fire downhill over a lower obstruction with normal fog',()=>{
  for(const stand of ['mountain','wall']){
    const m=field();
    if(stand==='mountain'){
      E.setTerrain(m,8,7,E.TERRAIN.MOUNTAIN);
      m.elevations[E.index(m,8,7)]=3.8;
    }else E.setFort(m,8,7,3,'egypt','塔墙');
    E.setTerrain(m,9,7,E.TERRAIN.MOUNTAIN);
    m.elevations[E.index(m,9,7)]=1.5;
    E.addUnit(m,'meGondorBow','egypt',8,7);
    E.addUnit(m,'meEast','coalition',10,7);
    const s=E.startGame(m,{fogPolicy:{unitFog:true}}),bow=unit(s,'meGondorBow'),foe=unit(s,'meEast');
    assert.ok(E.visibleTo(s,bow.team,foe.c,foe.r));
    const p=E.attackPreview(s,bow,foe.c,foe.r);
    assert.ok(p&&!p.melee&&p.elevation.multiplier>1);
    assert.ok(shot(s,bow,foe).unitDamage>0);
    s.map.elevations[E.index(m,9,7)]=6;
    E.recomputeFog(s);
    assert.equal(E.attackPreview(s,bow,foe.c,foe.r),null);
  }
});

test('movement and range use historical analogues, with five movement and two attack hexes for flyers',()=>{
  const s=E.startGame(field()),map=s.map;
  for(const [a,b] of [['meGuard','heavy'],['meUruk','heavy'],['meOrc','light'],['meGondorBow','archer'],['meRohan','cavalry'],['meRohanLight','parthianHorseArcher'],['meGrond','siegeRam']]){
    const middle=E.unitStats(map,{kind:a}),historical=E.STATS[b];
    assert.deepEqual([middle.move,middle.range],[historical.move,historical.range],a);
  }
  assert.ok(E.addUnit(map,'meEagle','egypt',8,7));
  assert.ok(E.addUnit(map,'meOrcBow','coalition',10,7));
  assert.ok(E.addUnit(map,'meUrukBow','coalition',8,8));
  assert.ok(E.addUnit(map,'meWitchKing','coalition',12,7));
  const eagle=unit(s,'meEagle'),witch=unit(s,'meWitchKing'),bow=unit(s,'meOrcBow');
  E.recomputeFog(s);
  assert.equal(E.movementAllowance(s,eagle).maxSteps,5);
  assert.ok(E.attackPreview(s,eagle,10,7));
  assert.equal(E.attackPreview(s,eagle,12,7),null);
  assert.ok(shot(s,eagle,bow).ok);
  assert.ok(eagle.meLow);
  E.endSide(s);
  assert.equal(E.attackPreview(s,unit(s,'meUrukBow'),eagle.c,eagle.r)?.target.id,eagle.id);
  assert.equal(E.attackPreview(s,witch,eagle.c,eagle.r),null);
});

test('both armies can form heavy infantry and save its stance and facing',()=>{
  const m=field();
  E.addUnit(m,'meGuard','egypt',8,7);
  E.addUnit(m,'meUruk','coalition',11,7);
  E.addUnit(m,'meGondorBow','egypt',8,8);
  const s=E.startGame(m);
  assert.equal(E.setPhalanxMode(s,unit(s,'meGuard').id,true,1.5).ok,true);
  assert.equal(E.setPhalanxMode(s,unit(s,'meGondorBow').id,true,0).ok,false);
  E.endSide(s);
  assert.equal(E.setPhalanxMode(s,unit(s,'meUruk').id,true,3.5).ok,true);
  const loaded=restoreSave(JSON.parse(JSON.stringify(createSave(m,s,'coalition')))).game;
  assert.deepEqual([unit(loaded,'meGuard').formed,unit(loaded,'meGuard').facing],[true,1.5]);
  assert.deepEqual([unit(loaded,'meUruk').formed,unit(loaded,'meUruk').facing],[true,3.5]);
});

test('attackers reach and destroy the original campaign walls with their siege units',()=>{
  for(const [id,kind] of [['me_hornburg','meBlast'],['me_pelennor','meGrond']]){
    const s=E.startGame(makeMiddleEarthMap(id),{middleEarthSeed:137}),engine=unit(s,kind),target=siegeObjective(s,engine);
    let moved=false,hit=false,armed=false;
    for(let turn=0;turn<10&&!s.over&&target.hp>0;turn++){
      E.endSide(s);
      armed||=!!s.middleEarth.blastReady;
      const actions=middleEarthAi(s).filter(a=>a.id===engine.id);
      moved||=actions.some(a=>a.type==='move');
      hit||=actions.some(a=>a.type==='attack'&&a.fortDamage>0);
      armed||=!!s.middleEarth.blastReady;
    }
    assert.ok(moved,id);
    assert.equal(target.hp,0,id);
    if(kind==='meBlast')assert.ok(armed&&s.middleEarth.events.breach);
    else assert.ok(hit);
  }
});
