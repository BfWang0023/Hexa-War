import {chargeClass} from './charge-rules.mjs';
import {selectable} from './group-command.mjs';
import {ROLE_KINDS} from './tactical-units.mjs';
// Names come from the very same engine function used by unit panels, including edited maps.
import {STATS,unitName,isShip,isFormableInfantry,isRouted} from './engine.mjs';
const aliases={parthianHorseArcher:['骑射手'],parthianCataphract:['具装骑兵'],phalangite:['马其顿长枪方阵'],siegeRam:['攻城槌'],chinaHeavyChariot:['中国重战车']};
export function buildUnitRegistry(map,team,rulesVersion=21){
 return Object.entries(STATS).filter(([id])=>id!=='fort').map(([id,stats])=>{
  const units=map?.units.filter(u=>u.kind===id&&u.team===team)||[],names=new Set([stats.name,...(aliases[id]||[])]);
  if(map){names.add(unitName(map,{kind:id,team}));for(const u of units)names.add(unitName(map,u));}
  return {unitTypeId:id,mapDefined:!!map,names:[...names],displayName:map?unitName(map,{kind:id,team}):stats.name,team,scenarioId:map?.scenarioId||null,categories:Object.entries(ROLE_KINDS).filter(([,xs])=>xs.includes(id)).map(([name])=>name),capabilities:{charge:chargeClass(map,{kind:id,team,hp:1},rulesVersion),mountedRole:stats.mountedRole||null,ship:isShip({kind:id}),formation:isFormableInfantry({kind:id}),ranged:stats.range>0},instances:units.map(u=>({id:u.id,alive:u.hp>0,available:!!selectable(u,team),groupId:u.formation||null}))};
 });
}
export function matchUnitEntities(text,registry){
 const matches=[],all=[];for(const entry of registry)for(const name of entry.names)if(name&&(entry.mapDefined||!['骑兵','弓箭手'].includes(name)))all.push({name,id:entry.unitTypeId,entry});
 // A culture-prefix abbreviation is accepted only as a unique suffix of a real registered name.
 // It never creates a new type or an inferred category.
 for(const fragment of text.split(/[\s，,、；;]|(?:所有|全部|选中|当前|向|在|列成|排成|组成|集结|停止|前进|推进|列$)/).filter(s=>s.length>=3)){
  if(['骑兵','弓箭手','步兵','弓兵','骑士','卫队'].includes(fragment)||all.some(x=>x.name===fragment))continue;
  const xs=all.filter(x=>x.name.endsWith(fragment)),ids=new Set(xs.map(x=>x.id));if(ids.size===1&&xs.length)all.push({...xs[0],name:fragment,abbreviated:true});
 }
 all.sort((a,b)=>b.name.length-a.name.length||a.id.localeCompare(b.id));let used=Array(text.length).fill(false);
 for(const candidate of all){let start=text.indexOf(candidate.name);while(start>=0){const end=start+candidate.name.length;if(!used.slice(start,end).some(Boolean)){const same=all.filter(x=>x.name===candidate.name),active=same.filter(x=>x.entry.instances.some(u=>u.available)),ids=[...new Set((active.length?active:same).map(x=>x.id))];matches.push({fragment:text.slice(start,end),start,end,kinds:ids,registeredName:candidate.entry.displayName,abbreviated:!!candidate.abbreviated});used.fill(true,start,end);}start=text.indexOf(candidate.name,start+1);}}
 return matches.sort((a,b)=>a.start-b.start);
}
export const stripEntities=(text,entities)=>{let s=text;for(const e of [...entities].reverse())s=s.slice(0,e.start)+' '.repeat(e.end-e.start)+s.slice(e.end);return s;};
export function registryVocabulary(map,team,rulesVersion=21){return buildUnitRegistry(map,team,rulesVersion).filter(r=>r.instances.length).map(r=>({unitTypeId:r.unitTypeId,names:r.names,capabilities:r.capabilities,categories:r.categories,count:r.instances.filter(u=>u.available).length}));}
