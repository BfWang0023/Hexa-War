// A continuous world-space field, sampled only while rebuilding static terrain.
// The 1–3 unit cosmetic rise never changes the engine or walking elevations.
let enabled=true;
export const mountainReliefEnabled=()=>enabled;
export function setMountainRelief(value){enabled=!!value;}
export function ridgeRise(x,z){
 const warp=.45*Math.sin(x*.012-z*.018);
 const broad=.5+.5*Math.sin(x*.025+z*.017+warp);
 const rolling=.5+.5*Math.sin(x*.043-z*.029+.6*Math.sin(z*.015));
 return 1+2*(.72*broad+.28*rolling);
}
