import {growthLevel,eliteIdentity,combatUnit,controlledBy} from './unit-growth.mjs';
export const MUTINY_RULES=Object.freeze({unpaidThreshold:3,combatThreshold:6,unpaidBase:.00004,combatBase:.00003,
  pressureGrowth:.00002,propagation:.0003,sourceCap:3,ceiling:.002,
  levelResistance:[1,.85,.7,.55,.4],eliteResistance:.55,restReduction:2});
const actors=new WeakMap();
export const mutinyObserver=s=>actors.get(s);
export function executeMutinous(s,u,visible,fn){const previous=actors.get(s);actors.set(s,{id:u.id,c:u.c,r:u.r,visible});try{return fn();}finally{previous?actors.set(s,previous):actors.delete(s);}}
export function rejectMutinyCommand(s,id){const u=s.map.units.find(v=>v.id===id);return !!u?.mutinous && actors.get(s)?.id!==id;}
export function mutinyProbability(u,sources=0,rules=MUTINY_RULES){
  let risk=0;
  if((u.unpaidTurns||0)>=rules.unpaidThreshold)risk+=rules.unpaidBase+Math.min(10,u.unpaidTurns-rules.unpaidThreshold)*rules.pressureGrowth;
  if((u.combatStreak||0)>=rules.combatThreshold)risk+=rules.combatBase+Math.min(10,u.combatStreak-rules.combatThreshold)*rules.pressureGrowth;
  risk+=Math.min(sources,rules.sourceCap)*rules.propagation;
  return Math.min(rules.ceiling,risk)*rules.levelResistance[growthLevel(u)]*(eliteIdentity(u)?rules.eliteResistance:1);
}
function random(s){let x=s.mutinyState.random>>>0;x^=x<<13;x^=x>>>17;x^=x<<5;s.mutinyState.random=x>>>0;return (x>>>0)/4294967296;}
export function cancelMutinyOrders(s,u){
  for(const task of s.delegatedOrders||[])if(task.ids.includes(u.id)&&['active','blocked','paused'].includes(task.status)){
    task.ids=task.ids.filter(id=>id!==u.id);task.progress[u.id]='cancelled';task.reason='部队哗变，失去指挥权';
    if(!task.ids.length)task.status='failed';
  }
  const plan=s.logisticsPlan;
  if(plan)for(const cart of plan.carts)if(cart.id===u.id){cart.phase='lost';cart.reason='哗变，运输调度解除';}
  delete s.chargeRuns?.[u.id];delete s.ramRuns?.[u.id];
}
export function becomeMutinous(s,u,cause='多因素压力'){
  if(u.mutinous||u.hp<=0)return false;
  u.mutinous=true;u.originalTeam=u.team;u.controlTeam=null;u.mutinyTurn=s.turn;u.mutinyCause=cause;
  // Keep facing and combat values. Shared formation support is computed dynamically.
  cancelMutinyOrders(s,u);
  s.log.push(`${u.id} 哗变（${cause}），对双方敌对`);
  (s.mutinyState.pending||=[]).push({id:u.id,turn:s.turn});
  return true;
}
export function initializeMutiny(s,seed){s.growthRules=1;s.mutinyState={version:1,random:(seed>>>0)||0x6d2b79f5,lastTurn:0,pending:[]};}
export function settleMutiny(s,distance,roll){
  const state=s.mutinyState;if(!state||state.lastTurn>=s.turn)return [];
  state.lastTurn=s.turn;
  const sources=state.pending.filter(e=>e.turn<s.turn).map(e=>s.map.units.find(u=>u.id===e.id&&u.hp>0)).filter(Boolean);
  state.pending=state.pending.filter(e=>e.turn>=s.turn);
  const events=[];
  for(const u of s.map.units){
    if(u.hp<=0||u.mutinous||u.routed||u.uncontrolled||u.starvedRouted||u.aboard||u.escaped||!combatUnit(u)||['siegeRam','siegeTower','romanOnager','defenseTower'].includes(u.kind)||u.mutinyCheckedTurn===s.turn)continue;
    u.mutinyCheckedTurn=s.turn;
    const nearby=sources.filter(v=>distance(u,v)<=1).length;
    const pressure=s.map.logistics?u:{...u,unpaidTurns:0};
    const probability=mutinyProbability(pressure,nearby);
    if(!probability)continue;
    const cause=[pressure.unpaidTurns>=MUTINY_RULES.unpaidThreshold?'欠饷':'',u.combatStreak>=MUTINY_RULES.combatThreshold?'久战':'',nearby?'邻近传播':''].filter(Boolean).join('、');
    if((roll?roll(u,probability):random(s))<probability && becomeMutinous(s,u,cause))events.push({id:u.id,probability,cause});
  }
  return events;
}
export function settleWages(s,team,units,cost,income,record){
  const due=units.reduce((n,u)=>n+cost(u),0);s.money[team]+=income;
  let funds=Math.max(0,s.money[team]);let paid=0;
  for(const u of units){
    const owed=cost(u),payment=Math.min(funds,owed);funds-=payment;paid+=payment;
    u.wagesDue=owed;u.wagesPaid=payment;u.wageArrears=(u.wageArrears||0)+owed-payment;
    u.unpaidTurns=u.wageArrears>0?(u.unpaidTurns||0)+1:0;
  }
  for(const u of units){const extra=Math.min(funds,u.wageArrears||0);u.wageArrears-=extra;funds-=extra;paid+=extra;if(!u.wageArrears)u.unpaidTurns=0;else if(extra>0)u.unpaidTurns=Math.max(0,u.unpaidTurns-1);}
  s.money[team]-=paid;record('income',income);record('expense',paid);return {due,paid};
}

export function validateMutiny(s){
 if(s.growthRules===undefined&&s.mutinyState===undefined)return;
 const state=s.mutinyState;
 if(s.growthRules!==1||!state||state.version!==1||!Number.isInteger(state.random)||state.random<0||state.random>4294967295||!Number.isInteger(state.lastTurn)||state.lastTurn<0||state.lastTurn>s.turn||!Array.isArray(state.pending)||state.pending.length>10000)throw Error('哗变结算状态无效');
 for(const event of state.pending)if(typeof event.id!=='string'||!Number.isInteger(event.turn)||event.turn<0||event.turn>s.turn)throw Error('哗变传播队列无效');
 for(const u of s.map.units){
  if(u.mutinous&&(u.originalTeam!==u.team||u.controlTeam!==null||!Number.isInteger(u.mutinyTurn)||u.mutinyTurn>s.turn))throw Error('失控单位状态无效');
  if((u.mutinyCheckedTurn||0)>s.turn||(u.lastMutinyActionTurn||0)>s.turn)throw Error('哗变结算回合无效');
 }
}
