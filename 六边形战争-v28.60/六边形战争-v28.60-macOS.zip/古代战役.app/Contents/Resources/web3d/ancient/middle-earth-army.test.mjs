import {visualProfile} from './visual-profiles.mjs';
import {chargeClass} from './charge-rules.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {executeArmyOrder} from './group-command.mjs';
import {makeMiddleEarthMap as make} from './middle-earth-maps.mjs';
import {MIDDLE_EARTH} from './middle-earth-data.mjs';
import {deployArmyWave,frontUnit} from './middle-earth-armies.mjs';
import {createSave,restoreSave} from './save.mjs';
import {formationOffsets} from './army-formation-render.mjs';
import {groundConnection} from './cliff-navigation.mjs';
import {createAncientTerrain} from './terrain.mjs';

const expected=[[20,32],[24,48],[18,32],[32,56],[30,48],[16,28],[24,48],[24,48]];
test('all default openings deploy the full revised roster on the original compact board',()=>{
  for(const [i,{id}] of MIDDLE_EARTH.entries()){
    const old=make(id,{largeArmies:false}),next=make(id),game=E.startGame(next);
    assert.deepEqual([next.cols,next.rows,next.victory.turnLimit],[old.cols,old.rows,old.victory.turnLimit],id);
    assert.deepEqual(next.terrain,old.terrain,id);
    assert.deepEqual(['egypt','coalition'].map(team=>game.map.units.filter(u=>u.team===team&&frontUnit(next,u)).length),expected[i],id);
    assert.equal(new Set(game.map.units.map(u=>u.id)).size,game.map.units.length);
    if(id.startsWith('me_morannon'))assert.deepEqual(next.units.filter(u=>!frontUnit(next,u)),old.units.filter(u=>!frontUnit(old,u)));
  }
});
test('a full entry queues reserves, and the same arrived IDs survive a save roundtrip',()=>{
  const map=make('me_pelennor'),game=E.startGame(map);
  const w=game.map.victory.waves.find(w=>w.key==='siege-follow');
  const event=(s,key)=>{s.middleEarth.events[key]={turn:s.turn,text:key};};
  game.turn=w.turn;
  const before=game.map.victory.army.peak;
  game.map.victory.army.peak=[before[0],56];
  deployArmyWave(game,w,event);
  assert.ok(game.middleEarth.army.reserve[w.key].every(v=>v.entered===null));
  game.map.victory.army.peak=before;
  deployArmyWave(game,w,event);
  const slots=game.middleEarth.army.reserve[w.key];
  assert.ok(slots.some(v=>v.entered!==null));
  const restored=restoreSave(JSON.parse(JSON.stringify(createSave(map,game,'egypt')))).game;
  const counts=restored.map.units.length;
  deployArmyWave(restored,w,event);
  assert.ok(restored.map.units.length>=counts);
  assert.equal(restored.map.units.length,new Set(restored.map.units.map(v=>v.id)).size);
  for(const v of slots.filter(v=>v.entered!==null))assert.equal(restored.map.units.filter(u=>u.id===v.id).length,1);
});
test('old compact saves retain old deployment without a reserve injection',()=>{
  const map=make('me_pelennor',{largeArmies:false}), game=E.startGame(map);
  const restored=restoreSave(JSON.parse(JSON.stringify(createSave(map,game,'egypt'))));
  assert.equal(restored.game.map.units.length,game.map.units.length);
  assert.equal(restored.game.middleEarth.army,undefined);
});
function mixed(){
  const s=E.startGame(make('me_pelennor'),{middleEarthSeed:17,mutinySeed:17});
  s.map.units=s.map.units.filter(u=>u.kind==='fort');
  for(const [kind,team,c,r] of [['meGondor','egypt',19,19],['meGondorHorse','egypt',19,18],['meGondorBow','egypt',18,20],['meOrc','coalition',23,20],['meOrc','coalition',24,22]]){
    assert.ok(E.addUnit(s.map,kind,team,c,r),kind);
  }
  E.recomputeFog(s);
  return s;
}
test('mixed army move assigns unique reachable cells and spends the existing budget',()=>{
  const s=mixed(),units=s.map.units.filter(u=>u.kind!=='fort'&&u.team==='egypt');
  const moves=[];
  const r=executeArmyOrder(s,units.map(u=>u.id),{c:22,r:21},{mover:(state,id,c,r)=>{
    const u=state.map.units.find(u=>u.id===id),old={c:u.c,r:u.r},budget=u.actionsLeft;
    const ret=E.move(state,id,c,r);
    if(ret.ok){assert.ok(u.actionsLeft<budget);moves.push(ret.path);let p=old;for(const q of ret.path){assert.equal(groundConnection(state.map,u,p,q),'');p=q;}}
    return ret;
  }});
  assert.ok(r.moved>=2);
  assert.ok(moves.length>=2);
  assert.equal(new Set(units.map(u=>E.key(u.c,u.r))).size,units.length);
  assert.ok(units.every(u=>u.actionsLeft>=0&&u.actionsLeft<=2));
});
test('focus fire only credits one kill and stops spending AP once the specified target dies',()=>{
  const s=mixed(),units=s.map.units.filter(u=>u.kind!=='fort'&&u.team==='egypt');
  const target=s.map.units.find(u=>u.kind==='meOrc'),other=s.map.units.filter(u=>u.kind==='meOrc')[1];
  target.hp=1;target.c=20;target.r=19;
  E.recomputeFog(s);
  const old=other.hp;
  const hit=(state,id,c,r)=>E.attack(state,id,c,r,0,.5,.9,.9);
  const result=executeArmyOrder(s,units.map(u=>u.id),target,{mode:'target',targetId:target.id,strike:hit});
  assert.equal(target.hp,0);
  assert.equal(other.hp,old);
  assert.equal(result.results.reduce((n,v)=>n+v.attacks,0),1);
  assert.equal(s.turnJournal.filter(e=>e.type==='death'&&e.id===target.id).length,1);
  assert.equal(units.reduce((n,v)=>n+(v.kills||0),0),1);
  assert.equal(units.reduce((n,v)=>n+v.actionsLeft,0),5);
});
test('changing the formation display budget does not alter the saved combat random sequence',()=>{
  function attack(offsets){
    const s=mixed(),u=s.map.units.find(v=>v.kind==='meGondor'),v=s.map.units.find(v=>v.kind==='meOrc');
    v.c=20;v.r=19;E.recomputeFog(s);
    for(const narrow of offsets)assert.equal(formationOffsets('infantry',narrow).length,4);
    const r=E.attack(s,u.id,v.c,v.r);
    return [r.hit,r.unitDamage,s.middleEarth.random,u.hp,v.hp];
  }
  assert.deepEqual(attack([false,true,true]),attack([false]));
});
test('the revised Pelennor river is one water level, and visual build leaves rule geometry intact',()=>{
  const map=make('me_pelennor'),original=structuredClone(map.terrain);
  const terrain=createAncientTerrain(map);
  const water=terrain.group.getObjectByName('continuous-water');
  assert.ok(water.geometry.attributes.position.count>300);
  for(let i=0;i<water.geometry.attributes.position.count;i++)assert.ok(Math.abs(water.geometry.attributes.position.getY(i)+.42)<1e-6);
  assert.equal(water.material.transparent,false);
  assert.deepEqual(map.terrain,original);
});
test('area attacks ignore visible opponents outside the chosen radius',()=>{
  const s=mixed(),u=s.map.units.find(v=>v.kind==='meGondor'),targets=s.map.units.filter(v=>v.kind==='meOrc');
  Object.assign(targets[0],{c:20,r:19,hp:1});
  Object.assign(targets[1],{c:24,r:21,hp:1});
  E.recomputeFog(s);
  executeArmyOrder(s,[u.id],{c:20,r:19},{mode:'area',strike:(...args)=>E.attack(...args,0,.5,.9,.9)});
  assert.equal(targets[0].hp,0);
  assert.equal(targets[1].hp,1);
});
test('ships require living troops and the oath-bearer at the port objective',()=>{
  const s=E.startGame(make('me_pelargir')),p=s.map.victory.points;
  const units=s.map.units.filter(u=>u.team==='egypt');
  const leader=units.find(u=>u.kind==='meAragorn');
  const ghost=units.find(u=>u.kind==='meDead');
  const crew=units.filter(u=>u.kind==='meGondor');
  const ships=s.map.units.filter(u=>u.kind==='meBlackShip');
  s.map.units=[leader,ghost,...crew,...ships];
  const nextTo=ship=>E.neighbors(ship.c,ship.r).find(v=>E.inBounds(s.map,v.c,v.r)&&!(E.tile(s.map,v.c,v.r).terrain&E.TERRAIN.SEA)&&E.distance(v,p.core)>1);
  Object.assign(ghost,nextTo(ships[0]));
  E.checkVictory(s);
  assert.equal(s.middleEarth.docks.length,0);
  Object.assign(crew[0],nextTo(ships[0]));Object.assign(crew[1],nextTo(ships[2]));
  E.checkVictory(s);
  assert.equal(s.middleEarth.docks.length,2);
  assert.ok(!s.over);
  Object.assign(leader,p.core);
  E.checkVictory(s);
  assert.equal(s.winner,'egypt');
  assert.ok(ghost.escaped);
});

test('new campaigns boost selected elites, and cavalry uses one figure per unit',()=>{
  const old=make('me_pelennor',{largeArmies:false}), next=make('me_pelennor');
  for(const kind of ['meGuard','meRohan']){
    const base=E.unitStats(old,{kind}), elite=E.unitStats(next,{kind});
    assert.ok(elite.hp>base.hp&&elite.melee>base.melee);
    assert.equal(elite.move,base.move);
  }
  for(const kind of ['infantry','mounted','ranged','wolf','warg','ghost'])
    for(const narrow of [false,true])assert.equal(formationOffsets(kind,narrow).length,['mounted','wolf','warg'].includes(kind)?1:4);
});

test('mounted commanders use the same horse profile for rules, visuals and restored state',()=>{
  for(const [id,kind,role] of [
    ['me_pelennor','meEowyn','shock'],['me_hornburg','meGandalf','maneuver'],
    ['me_morannon','meAragorn','shock'],['me_morannon_final','meGandalf','maneuver'],
    ['me_pelargir','meAragorn',undefined],['me_hornburg','meAragorn',undefined],
  ]){
    const m=make(id),game=E.startGame(m),unit={kind,hp:100,team:'egypt'};
    assert.equal(E.unitStats(game.map,unit).mountedRole,role);
    assert.equal(visualProfile(unit,id,game.map).family,role?'cavalry':'infantry');
    assert.equal(chargeClass(game.map,unit,game.rulesVersion),role==='shock'?'cavalry':null);
    const restored=restoreSave(JSON.parse(JSON.stringify(createSave(m,game,'egypt')))).game;
    assert.equal(E.unitStats(restored.map,unit).mountedRole,role);
  }
});
test('Grond has increased durability and a stronger attack on the great gate',()=>{
  const impact=largeArmies=>{
    const m=make('me_pelennor',{largeArmies});
    const s=E.startGame(m,{fogPolicy:{terrainFog:false,unitFog:false}});
    const ram=s.map.units.find(u=>u.kind==='meGrond'),gate=s.map.victory.points.gate;
    E.endSide(s);
    Object.assign(ram,{c:gate.c+1,r:gate.r});
    E.recomputeFog(s);
    const hit=E.attack(s,ram.id,gate.c,gate.r,0,.5,.9,.9);
    assert.ok(hit.ok&&hit.hit);
    return [E.unitMaxHp(s.map,ram),hit.fortDamage];
  };
  const old=impact(false),next=impact(true);
  assert.ok(next[0]>old[0]*1.7);
  assert.ok(next[1]>old[1]*1.4);
});
test('the Witch-king remains an aerial target after diving and can fall to arrows',()=>{
  const s=mixed(),map=s.map;
  for(const [kind,team,c,r] of [['meMerry','egypt',20,18],['meGondorBow','egypt',21,19],['meWitchKing','coalition',20,19],['meOrc','coalition',38,18]])
    assert.ok(E.addUnit(map,kind,team,c,r));
  const get=kind=>map.units.find(u=>u.kind===kind);
  const witch=get('meWitchKing'),merry=get('meMerry'),archer=map.units.find(u=>u.kind==='meGondorBow'&&u.c===21&&u.r===19);
  assert.equal(witch.hp,310);
  witch.meLow=true;witch.hp=1;E.recomputeFog(s);
  assert.equal(E.attackPreview(s,merry,witch.c,witch.r),null);
  const preview=E.attackPreview(s,archer,witch.c,witch.r);
  assert.equal(preview?.target.id,witch.id);
  assert.equal(preview.melee,false);
  const shot=E.attack(s,archer.id,witch.c,witch.r,0,.5,.95,.95);
  assert.ok(shot.hit&&s.middleEarth.events['witch-king']);
  assert.equal(witch.hp,0);
  assert.equal(s.turnJournal.filter(e=>e.type==='death'&&e.id===witch.id).length,1);
});
