import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {createFullModel,animateFullModel} from './full-models.mjs';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {MIDDLE_EARTH,ME_STATS,morannonCell,morannonWindows,largeMiddleEarthCell,projectMiddleEarthCell,MIDDLE_EARTH_SCALE} from './middle-earth-data.mjs';
import {chooseEyeArea,meZone,setStealth,sealCulvert} from './middle-earth-rules.mjs';
import {createSave,restoreSave} from './save.mjs';

const kind=(s,k)=>s.map.units.find(u=>u.kind===k);
const newGame=(id,seed=17)=>E.startGame(makeMiddleEarthMap(id,{layoutVersion:2}),{middleEarthSeed:seed});
const round=s=>{E.endSide(s);if(!s.over)E.endSide(s);};
for(const entry of MIDDLE_EARTH)test(entry.name+'初始化、AI、存读档和重开',()=>{
  const map=makeMiddleEarthMap(entry.id,{layoutVersion:2});
  const game=newGame(entry.id);
  for(let i=0;i<4&&!game.over;i++)E.aiTurn(game);
  assert.ok(game.turn>1||game.over);
  const restored=restoreSave(JSON.parse(JSON.stringify(createSave(map,game,'egypt')))).game;
  assert.deepEqual(restored.middleEarth,game.middleEarth);
  assert.deepEqual(restored.map.units.map(u=>[u.id,u.hp,u.actionsLeft]),game.map.units.map(u=>[u.id,u.hp,u.actionsLeft]));
  const fresh=newGame(entry.id);
  assert.deepEqual(fresh.middleEarth.events,{});
  assert.equal(fresh.turn,1);
});
test('中土兵种不上历史棋盘，每种模型有近景与远景',()=>{
  for(const k of Object.keys(ME_STATS)){
    assert.equal(E.canPlaceKind(k,'egypt','troy'),false);
    const model=createFullModel({kind:k,team:'egypt'},'me_erebor',{});
    assert.ok(model.getObjectByName('near')&&model.getObjectByName('far'));
    for(const opts of [{moving:true,action:'thrust',progress:.4},{distance:150}]){
      animateFullModel(model,500,opts);model.updateMatrixWorld(true);
      model.traverse(o=>assert.ok(o.matrixWorld.elements.every(Number.isFinite)));
    }
  }
});
test('艾辛河迟滞前不撤离，保住渡口后按实际到达撤离',()=>{
  const s=newGame('me_isen_second'), p=s.map.victory.points;
  const allies=s.map.units.filter(u=>u.team==='egypt');
  for(let i=0;i<4;i++)Object.assign(allies[i],{c:p.exit.c,r:p.exit.r});
  E.checkVictory(s);
  assert.equal(s.middleEarth.withdrawn.length,0);
  Object.assign(allies.at(-1),p.ford);
  while(s.turn<4&&!s.over)round(s);
  assert.equal(s.winner,'egypt');
  assert.equal(s.middleEarth.withdrawn.length,4);
});
test('深谷涵洞通行受兵种与封堵约束，爆破需要到位并等一个阶段',()=>{
  const s=newGame('me_hornburg'), p=s.map.victory.points;
  const foot=kind(s,'meRohanFoot'),carriage=kind(s,'meBlast');
  Object.assign(foot,{c:p.culvert.c-1,r:p.culvert.r});
  assert.ok(Number.isFinite(E.moveCost(s,foot,p.culvert.c,p.culvert.r)));
  assert.equal(E.moveCost(s,carriage,p.culvert.c,p.culvert.r),Infinity);
  assert.equal(sealCulvert(s),true);
  assert.equal(E.moveCost(s,foot,p.culvert.c,p.culvert.r),Infinity);
  Object.assign(carriage,{c:p.blast.c+1,r:p.blast.r});
  E.endSide(s);
  assert.ok(E.fortAt(s.map,p.blast.c,p.blast.r));
  assert.ok(s.middleEarth.events['blast-ready']);
  E.endSide(s);E.endSide(s);
  assert.equal(E.fortAt(s.map,p.blast.c,p.blast.r),null);
  assert.ok(s.middleEarth.events.breach);
  assert.equal(s.over,false);
});
test('空地共格，空中单位跨墙，飞行单位俯冲后仍不能被步兵近战攻击',()=>{
  const s=newGame('me_pelennor');
  s.side='coalition';
  const flyer=kind(s,'meWitchKing'),ground=kind(s,'meOrc');
  Object.assign(flyer,{c:15,r:12});
  Object.assign(ground,{c:14,r:12});
  E.recomputeFog(s);
  assert.ok(E.reachable(s,flyer).has('12,12'));
  assert.ok(E.reachable(s,flyer).has('14,12'));
  assert.ok(E.move(s,flyer.id,14,12).ok);
  assert.equal(flyer.c,ground.c);
  s.side='egypt';
  const soldier=kind(s,'meGuard');Object.assign(soldier,{c:15,r:12});
  E.recomputeFog(s);s.middleEarth.preferredTarget=flyer.id;
  assert.equal(E.attackPreview(s,soldier,14,12),null);
  flyer.meLow=true;
  assert.equal(E.attackPreview(s,soldier,14,12),null);
});
test('佩拉基尔以活人接管泊位，亡者履约退场',()=>{
  const s=newGame('me_pelargir');
  const allies=s.map.units.filter(u=>u.team==='egypt'&&u.kind==='meGondor');
  const dead=s.map.units.filter(u=>u.kind==='meDead');
  const docks=[s.map.victory.points.dock0,s.map.victory.points.dock1];
  const land=docks.map(({c,r})=>({c:c-1,r}));
  Object.assign(dead[0],land[0]);Object.assign(dead[1],land[1]);
  E.checkVictory(s);assert.equal(s.middleEarth.docks.length,0);
  Object.assign(allies[0],land[0]);Object.assign(allies[1],land[1]);
  Object.assign(kind(s,'meAragorn'),s.map.victory.points.core);
  assert.equal(E.checkVictory(s),'egypt');
  assert.ok(dead.every(u=>u.escaped));
});
test('隐藏位置不改变搜索区与已知地图，镜头与存档不消费随机数',()=>{
  const id='me_morannon_final',a=newGame(id),b=newGame(id);
  Object.assign(kind(b,'meFrodo'),morannonCell(50,14,b.map));
  E.recomputeFog(b);
  const copy=x=>structuredClone(x.middleEarth);
  assert.deepEqual(chooseEyeArea(copy(a),a.map),chooseEyeArea(copy(b),b.map));
  assert.deepEqual(E.observedMap(a,'coalition').units.filter(u=>u.kind==='meFrodo'),[]);
  assert.deepEqual(E.observedMap(b,'coalition').units.filter(u=>u.kind==='meFrodo'),[]);
  assert.equal(a.middleEarth.alert.turn,a.turn);
  const rand=a.middleEarth.random;a.middleEarth.view='doom';
  const reloaded=restoreSave(JSON.parse(JSON.stringify(createSave(makeMiddleEarthMap(id,{layoutVersion:2}),a,'egypt')))).game;
  assert.equal(reloaded.middleEarth.random,rand);
  assert.deepEqual(reloaded.middleEarth.alert,a.middleEarth.alert);
  assert.equal(reloaded.middleEarth.view,'doom');
});
test('序幕转场保留永久伤亡，末日裂隙唯一终点，锁定后不会覆写',()=>{
  const s=newGame('me_morannon'),p=s.map.victory.points,f=kind(s,'meFrodo');
  kind(s,'meGollum').hp=0;kind(s,'meSam').hp=0;
  Object.assign(f,p.pass);
  E.checkVictory(s);assert.equal(s.middleEarth.phase,'final');
  assert.equal(meZone(f.c,s.map),'doom');assert.equal(kind(s,'meSam').hp,0);assert.equal(kind(s,'meGollum').hp,0);
  f.c=p.crack.c-1;f.r=p.crack.r;
  E.checkVictory(s);assert.equal(s.over,false);
  f.actionsLeft=2;E.recomputeFog(s);
  assert.ok(E.move(s,f.id,p.crack.c,p.crack.r).ok);
  assert.equal(s.winner,'egypt');assert.match(s.victoryReason,/改写/);
  f.hp=0;assert.equal(E.checkVictory(s),'egypt');
});
test('黑门正面彻底崩溃或弗罗多阵亡才触发专属失败',()=>{
  const s=newGame('me_morannon_final'),f=kind(s,'meFrodo');
  const front=s.map.units.filter(u=>u.team==='egypt'&&meZone(u.c,s.map)==='front');
  for(const u of front.slice(1))u.hp=0;
  E.checkVictory(s);assert.equal(s.over,false);
  front[0].hp=0;assert.equal(E.checkVictory(s),'coalition');assert.ok(f.hp>0);
  const pre=newGame('me_morannon');kind(pre,'meFrodo').hp=0;
  assert.equal(E.checkVictory(pre),'coalition');
});
test('谨慎潜行确实缩短可移动距离，战区隔离不允许跨越',()=>{
  const s=newGame('me_morannon_final'),f=kind(s,'meFrodo');
  s.middleEarth.view='doom';
  assert.ok(setStealth(s,'careful'));
  const moves=[...E.reachable(s,f).values()];
  assert.ok(moves.length&&moves.every(p=>p.steps===1&&meZone(p.c,s.map)==='doom'));
});
test('搜索预警固定，实际搜中产生最后位置，失去接触后情报衰减',()=>{
  const s=newGame('me_morannon_final'), f=kind(s,'meFrodo'),d=s.middleEarth;
  Object.assign(f,morannonCell(45,8,s.map));
  d.alert={...morannonCell(45,8,s.map),turn:s.turn,radius:2};
  const announced=structuredClone(d.alert);
  d.attention=1;
  assert.deepEqual(d.alert,announced);
  E.endSide(s);
  assert.equal(d.trace.c,announced.c);
  Object.assign(f,morannonCell(57,14,s.map));
  E.endSide(s);
  assert.ok(d.trace.confidence<1);
  assert.equal(d.trace.c,announced.c);
});
test('正面牵制增加下一次搜查间隔，已发现时追捕优先',()=>{
  const states=[.05,.95].map(attention=>{
    const s=newGame('me_morannon_final');s.middleEarth.attention=attention;
    s.middleEarth.alert={...morannonCell(59,5,s.map),radius:2,turn:s.turn};
    E.endSide(s);return s.middleEarth;
  });
  assert.ok(states[1].nextSearch>states[0].nextSearch);
});
test('戒灵从正面调离后在途中不可行动，抵达保持同一个单位 ID',()=>{
  const s=newGame('me_morannon_final'),n=kind(s,'meNazgul');
  s.middleEarth.trace={...morannonCell(47,4,s.map),confidence:1,turn:s.turn};
  round(s);
  assert.ok(n.meInTransit> s.turn);
  s.side='coalition';assert.equal(E.reachable(s,n).size,0);E.endSide(s);
  round(s);
  assert.equal(meZone(n.c,s.map),'doom');assert.equal(s.map.units.filter(u=>u.kind==='meNazgul').length,1);
  assert.equal(kind(s,'meNazgul').id,n.id);
});
test('尸罗初次命中弗罗多留下山姆救援窗口',()=>{
  const s=newGame('me_morannon'),f=kind(s,'meFrodo'),spider=kind(s,'meShelob');
  f.hp=3;Object.assign(f,morannonCell(31,7,s.map));
  s.side='coalition';s.middleEarth.npcActing=spider.id;
  const result=E.attack(s,spider.id,f.c,f.r,0,.5,.9,1);
  delete s.middleEarth.npcActing;
  assert.ok(result.hit);assert.equal(f.hp,1);assert.equal(s.over,false);
});
test('只移动未暴露的持戒者不会改变魔多行动计划',()=>{
  const a=newGame('me_morannon_final'),b=newGame('me_morannon_final');
  const moved=kind(b,'meFrodo');Object.assign(moved,morannonCell(59,14,b.map));
  a.side=b.side='coalition';E.recomputeFog(a);E.recomputeFog(b);
  const summary=s=>E.aiTurn(s).map(({id,type,path,defenderId})=>({id,type,path,defenderId}));
  assert.deepEqual(summary(a),summary(b));
});


test('原版八个起点保存后仍加载原坐标、战况与剧情',()=>{
  for(const {id} of MIDDLE_EARTH){
    const map=makeMiddleEarthMap(id,{legacy:true});
    const state=E.startGame(map,{middleEarthSeed:47});
    E.aiTurn(state);
    const restored=restoreSave(JSON.parse(JSON.stringify(createSave(map,state,'egypt')))).game;
    assert.equal(restored.map.cols,map.cols);
    assert.equal(restored.map.rows,map.rows);
    assert.deepEqual(restored.map.units,state.map.units);
    assert.deepEqual(restored.middleEarth,state.middleEarth);
    assert.equal(restored.map.victory.layoutVersion,undefined);
  }
});

test('新版六章地图记录版本和手绘高程，导出导入一致',()=>{
  for(const {id} of MIDDLE_EARTH){
    const map=makeMiddleEarthMap(id,{layoutVersion:2}),original=makeMiddleEarthMap(id,{legacy:true});
    assert.equal(map.victory.layoutVersion,2);
    assert.ok(map.cols*map.rows>original.cols*original.rows);
    assert.deepEqual(E.importMap(E.exportMap(map)).elevations,map.elevations);
    assert.deepEqual(E.startGame(map).map.elevations,map.elevations);
    assert.equal(map.units.filter(u=>u.kind!=='fort').length,original.units.filter(u=>u.kind!=='fort').length);
  }
});

test('海尔姆侧门可实际出击，峡壁阻挡步兵，涵洞仍可渗透',()=>{
  const s=newGame('me_hornburg'),p=s.map.victory.points;
  const defender=kind(s,'meRohanFoot'),invader=kind(s,'meOrc');
  Object.assign(defender,{c:p.sally.c-1,r:p.sally.r});
  assert.ok(E.reachable(s,defender).has(E.key(p.sally.c,p.sally.r)));
  assert.equal(E.move(s,defender.id,p.sally.c,p.sally.r).ok,true);
  assert.equal(E.moveCost(s,defender,27,8),Infinity);
  s.side='coalition';
  Object.assign(invader,{c:p.culvert.c+1,r:p.culvert.r,actionsLeft:2});
  E.recomputeFog(s);
  assert.equal(E.move(s,invader.id,p.culvert.c,p.culvert.r).ok,true);
  assert.ok(s.middleEarth.events.infiltration);
});

test('孤山谷地可观察并射击，山脊和无道路山坡对步兵及座狼有不同限制',()=>{
  const s=newGame('me_erebor');
  const bow=s.map.units.find(u=>u.kind==='meElf'&&u.c===22&&u.r===23);
  const orc=s.map.units.find(u=>u.kind==='meOrc'&&u.c===24&&u.r===24);
  assert.equal(E.attackPreview(s,bow,orc.c,orc.r)?.melee,false);
  assert.equal(E.moveCost(s,bow,24,0),Infinity);
  const wolf=kind(s,'meWarg');
  const openSlope=s.map.terrain.findIndex((t,i)=>t===E.TERRAIN.MOUNTAIN&&s.map.elevations[i]<5.8);
  const c=openSlope%s.map.cols,r=Math.floor(openSlope/s.map.cols);
  assert.ok(Number.isFinite(E.moveCost(s,bow,c,r)));
  assert.equal(E.moveCost(s,wolf,c,r),Infinity);
});


test('V3 八个起点都有至少 200×200 格战场，实走外围及重新加载',()=>{
  for(const {id} of MIDDLE_EARTH){
    const map=makeMiddleEarthMap(id,{layoutVersion:3}),old=makeMiddleEarthMap(id,{layoutVersion:2});
    assert.equal(map.victory.layoutVersion,3);
    assert.ok(map.rows>=200);
    const regions=id.startsWith('me_morannon')?Object.values(morannonWindows(map)):[[0,map.cols]];
    for(const [a,b] of regions){
      assert.ok(b-a>=200);
      let traversable=0;
      for(let r=0;r<map.rows;r++)for(let c=a;c<b;c++){
        const i=r*map.cols+c,t=map.terrain[i];
        if(!(t&E.TERRAIN.SEA)&&(!(t&E.TERRAIN.RIVER)||t&E.TERRAIN.ROAD)&&
          (!(t&E.TERRAIN.MOUNTAIN)||t&E.TERRAIN.ROAD||map.elevations[i]<5.8))traversable++;
      }
      assert.ok(traversable>=30000,`${id} ${traversable}`);
    }
    for(const [key,p] of Object.entries(old.victory.points))
      assert.deepEqual(map.victory.points[key],largeMiddleEarthCell(id,p.c,p.r));
    const s=E.startGame(map);
    const u=s.map.units.find(u=>u.team==='egypt'&&u.customName?.endsWith('外围斥候'));
    if(id!=='me_morannon'){
      assert.ok(u,`${id} 无外围联军`);
      const d=[...E.reachable(s,u).values()].find(p=>p.steps===1);
      assert.ok(d,`${id} 无外围路线`);
      assert.ok(E.move(s,u.id,d.c,d.r).ok);
    }
    const saved=restoreSave(JSON.parse(JSON.stringify(createSave(map,s,'egypt')))).game;
    assert.deepEqual(saved.map.units,s.map.units);
    assert.deepEqual(saved.map.elevations,s.map.elevations);
    assert.equal(saved.map.victory.layoutVersion,3);
  }
});

test('V3 黑门完整地形情报可在现有存档容量内保存',()=>{
  const map=makeMiddleEarthMap('me_morannon_final',{layoutVersion:3});
  const s=E.startGame(map,{fogPolicy:{terrainFog:true,initialKnowledge:'full'}});
  const json=JSON.stringify(createSave(map,s,'egypt'));
  assert.ok(Buffer.byteLength(json)<16*1024*1024);
  const restored=restoreSave(JSON.parse(json)).game;
  assert.deepEqual(restored.mapKnowledge,s.mapKnowledge);
  assert.deepEqual(restored.middleEarth,s.middleEarth);
});


test('V4 等比例放大六章，任务坐标、自然地形与实走路径随棋盘迁移',()=>{
  for(const {id} of MIDDLE_EARTH){
    const source=makeMiddleEarthMap(id,{layoutVersion:2}),map=makeMiddleEarthMap(id,{layoutVersion:4});
    assert.equal(map.victory.layoutVersion,4);
    assert.deepEqual([map.cols,map.rows],[source.cols*MIDDLE_EARTH_SCALE,source.rows*MIDDLE_EARTH_SCALE]);
    assert.ok(map.cols>=200&&map.rows>=200);
    assert.deepEqual(map.units.filter(u=>u.kind!=='fort').map(u=>u.kind),source.units.filter(u=>u.kind!=='fort').map(u=>u.kind));
    const dual=id.startsWith('me_morannon');
    if(dual){
      for(const [a,b] of Object.values(morannonWindows(map)))assert.ok(b-a>=200);
    }
    for(const [k,p] of Object.entries(source.victory.points)){
      const scaled=projectMiddleEarthCell(map,p.c,p.r);
      assert.deepEqual(map.victory.points[k],scaled);
      const t=E.tile(source,p.c,p.r).terrain,actual=E.tile(map,scaled.c,scaled.r).terrain;
      assert.equal(actual&(E.TERRAIN.SEA|E.TERRAIN.RIVER|E.TERRAIN.MOUNTAIN),t&(E.TERRAIN.SEA|E.TERRAIN.RIVER|E.TERRAIN.MOUNTAIN));
    }
    const state=E.startGame(map);
    const unit=state.map.units.find(u=>u.team==='egypt'&&u.kind!=='fort'&&E.reachable(state,u).size>0);
    assert.ok(unit,id);
    const paths=[...E.reachable(state,unit).values()].sort((a,b)=>b.steps-a.steps);
    assert.ok(E.move(state,unit.id,paths[0].c,paths[0].r).ok);
    const restored=restoreSave(JSON.parse(JSON.stringify(createSave(map,state,'egypt')))).game;
    assert.deepEqual(restored.map.units,state.map.units);
    assert.deepEqual(restored.map.elevations,state.map.elevations);
    assert.equal(restored.map.victory.layoutVersion,4);
  }
});

test('V4 最高容量黑门存档完整保留迷雾信息',()=>{
  const map=makeMiddleEarthMap('me_morannon_final',{layoutVersion:4});
  const state=E.startGame(map,{fogPolicy:{terrainFog:true,initialKnowledge:'full'}});
  const json=JSON.stringify(createSave(map,state,'egypt'));
  assert.ok(Buffer.byteLength(json)<16*1024*1024);
  const saved=restoreSave(JSON.parse(json)).game;
  assert.equal(Object.keys(saved.mapKnowledge.egypt).length,map.cols*map.rows);
  assert.deepEqual(saved.middleEarth,state.middleEarth);
});


test('V5 将 V4 的长宽各减半，八个开局可实走和恢复存档',()=>{
  for(const {id} of MIDDLE_EARTH){
    const large=makeMiddleEarthMap(id,{layoutVersion:4}),map=makeMiddleEarthMap(id,{layoutVersion:5});
    assert.equal(map.victory.layoutVersion,5);
    assert.deepEqual([map.cols,map.rows],[Math.round(large.cols/2),Math.round(large.rows/2)]);
    if(id.startsWith('me_morannon'))for(const [zone,[a,b]] of Object.entries(morannonWindows(map))){
      const [left,right]=morannonWindows(large)[zone];
      assert.ok(Math.abs((b-a)-(right-left)/2)<=.5);
    }
    for(const [key,point] of Object.entries(map.victory.points)){
      const old=large.victory.points[key];
      assert.ok(Math.abs(point.c-old.c/2)<=2&&Math.abs(point.r-old.r/2)<=2);
    }
    const state=E.startGame(map);
    const u=state.map.units.find(u=>u.team==='egypt'&&u.kind!=='fort'&&E.reachable(state,u).size>0);
    assert.ok(u,id);
    const dest=E.reachable(state,u).values().next().value;
    assert.ok(E.move(state,u.id,dest.c,dest.r).ok);
    const loaded=restoreSave(JSON.parse(JSON.stringify(createSave(map,state,'egypt')))).game;
    assert.equal(loaded.map.victory.layoutVersion,5);
    assert.deepEqual(loaded.map.units,state.map.units);
  }
});
