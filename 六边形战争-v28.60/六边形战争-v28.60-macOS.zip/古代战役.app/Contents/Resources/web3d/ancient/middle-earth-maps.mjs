import * as E from './engine.mjs';
import {applyArmyDeployment} from './middle-earth-armies.mjs';
import {MIDDLE_EARTH,isMorannon,morannonCell} from './middle-earth-data.mjs';

import {expandedMiddleEarthMap} from './middle-earth-landscapes.mjs';

import {scaleMiddleEarthMap} from './middle-earth-scale-map.mjs';
import {makeLargeMiddleEarthMap} from './middle-earth-large-map.mjs';

export function makeMiddleEarthMap(id,{legacy=false,layoutVersion=6,largeArmies=layoutVersion===6}={}){
  const info=MIDDLE_EARTH.find(entry=>entry.id===id);
  if(!info)throw Error('未知中土剧本');
  const dual=isMorannon(id);
  const m=E.newMap(dual?61:32,dual?17:20);
  m.scenarioId=id;m.name=info.title;m.intro=info.intro;
  m.factions={egypt:info.west,coalition:info.east};
  m.victory={mode:'middle-earth',turnLimit:dual?28:22,points:{},waves:[]};
  m.gateRules=1;
  const T=E.TERRAIN, v=m.victory;
  const paint=(c,r,t)=>E.setTerrain(m,c,r,t);
  const rect=(c1,r1,c2,r2,t)=>{for(let r=r1;r<=r2;r++)for(let c=c1;c<=c2;c++)paint(c,r,t);};
  const road=(c1,r1,c2,r2)=>rect(c1,r1,c2,r2,T.ROAD);
  const landmark=(c,r,label)=>m.landmarks.push({c,r,label});
  const point=(key,c,r,label)=>{v.points[key]={c,r};landmark(c,r,label);};
  const put=(team,rows)=>{for(const [kind,c,r,name] of rows){
    if(E.mobileAt(m,c,r)||!E.addUnit(m,kind,team,c,r))throw Error(`部署失败 ${id}: ${kind} ${c},${r}`);
    if(name)m.units.at(-1).customName=name;
  }};
  const west=(...rows)=>put('egypt',rows),east=(...rows)=>put('coalition',rows);
  const wave=(key,turn,team,rows,label)=>v.waves.push({key,turn,team,rows,label});
  const wall=(c,r,team,name,gate=false,level=2)=>{
    E.setFort(m,c,r,level,team,name);
    if(gate){const f=E.fortAt(m,c,r);f.gate=true;f.hp=Math.round(E.FORT_HP[level]*.7);}
  };
  const line=(c,r,kinds)=>kinds.map((kind,i)=>[kind,c+Math.floor(i/4),r+i%4]);

  if(id.startsWith('me_isen')){
    const first=id.endsWith('first');
    rect(13,0,17,19,T.RIVER);rect(15,8,15,11,T.MOUNTAIN);
    road(1,10,30,10);rect(13,10,14,10,T.RIVER|T.ROAD);rect(16,10,17,10,T.RIVER|T.ROAD);
    road(20,10,20,18);road(7,4,7,10);
    landmark(15,9,'河中洲与低丘');point('ford',15,10,'艾辛河渡口');point('exit',25,17,'东南撤离路');
    west(['meRiderLord',first?15:19,first?9:10,first?'希奥杰德':'埃尔夫海姆'],
      ['meCaptain',first?19:12,10,'格林博尔德'],['meRohanFoot',15,10],
      ['meRohanBow',19,11],['meRohanFoot',20,11],['meRohan',21,12],['meRohanLight',20,13]);
    east(...line(9,7,['meOrc','meUruk','meUrukBow','meDunland','meWarg','meOrc']),
      ...line(20,3,['meWarg','meUruk','meOrc','meDunland','meUrukBow','meOrc']));
    if(first)wave('rescue',3,'egypt',[['meRohan',25,16,'埃尔夫海姆的救援队'],['meRohanFoot',26,16],['meRohanLight',27,16]],'埃尔夫海姆从东岸道路抵达');
    else wave('flank',4,'coalition',line(22,5,['meWarg','meDunland','meOrc']), '艾辛格第二波沿东岸推进');
  }else if(id==='me_hornburg'){
    rect(0,0,31,2,T.MOUNTAIN);rect(0,17,31,19,T.MOUNTAIN);
    rect(0,12,31,12,T.RIVER|T.ROAD);road(3,8,31,8);
    for(let r=3;r<=16;r++)if(r!==12)wall(12,r,'egypt','深谷墙',r===8);
    for(let r=4;r<=10;r++)wall(7,r,'egypt','号角堡',r===8,3);
    for(let r=5;r<=10;r++)if(r!==8)wall(19,r,'egypt','外堤',false,1);
    point('core',5,8,'号角堡内院');point('cave',5,14,'后方洞窟');point('counter',20,8,'外堤反击点');
    point('culvert',12,12,'溪流涵洞');point('blast',12,13,'爆破墙段');
    west(...line(9,6,['meRohanFoot','meRohanBow','meRiderLord','meRohanFoot','meRohanBow','meRohanFoot']),
      ['meAragorn',8,8],['meRohanFoot',6,8],['meRohanFoot',7,14]);
    m.units.find(u=>u.kind==='meRiderLord').customName='伊欧墨';
    east(...line(22,6,['meUruk','meUrukBow','meUruk','meDunland','meUruk','meUrukBow','meDunland','meOrc','meOrc','meUruk','meOrc']),
      ['meBlast',17,13],['meOrc',14,12]);
    wave('dawn',6,'egypt',[['meGandalf',29,4],['meCaptain',28,4,'鄂肯布兰德'],...line(29,5,['meRohanFoot','meRohanFoot','meRohanBow','meRohanFoot'])],'黎明，甘道夫与鄂肯布兰德率西谷步兵抵达');
  }else if(id==='me_pelennor'){
    rect(0,0,4,19,T.MOUNTAIN);rect(27,0,31,19,T.RIVER);
    road(6,9,26,9);road(13,0,13,18);road(23,9,23,18);
    for(let r=4;r<=14;r++)wall(9,r,'egypt','米那斯提力斯主城',r===9,3);
    for(let r=3;r<=15;r++)if(r!==9&&r!==4)wall(25,r,'egypt','兰马斯残墙',false,1);
    for(const [c,r]of [[11,4],[12,5],[18,6],[20,13],[17,15],[24,17]])E.setHouse(m,c,r);
    point('core',7,9,'米那斯提力斯城心');point('gate',9,9,'大门');point('counter',16,9,'佩兰诺大道');
    landmark(25,17,'哈隆德港');landmark(13,2,'洛汗北来');
    west(...line(7,7,['meGuard','meGondorBow','meGondor','meGondorBow','meGondor','meGondor','meGuard','meGondorBow']),
      ['meGondor',11,9],['meGondorBow',11,10],['meGondorHorse',11,7]);
    east(...line(17,7,['meOrc','meOrcBow','meTroll','meOrc','meEast','meOrc','meOrcBow','meHarad','meOrc','meEast','meOrc','meOrcBow']),
      ['meGrond',14,9],['meMumak',21,11],['meWitchKing',15,6]);
    wave('rohan',3,'egypt',[['meRiderLord',13,1,'希优顿'],['meEowyn',12,2],['meMerry',13,2],...line(14,1,['meRohan','meRohan','meRohanLight','meRohan'])],'洛汗骑兵从北方入场');
    wave('harad',5,'coalition',line(24,12,['meHarad','meEast','meMumak','meOrc']),'魔多后军沿东南道路压上');
    wave('ships',7,'egypt',[['meAragorn',24,17],...line(25,16,['meGondor','meGuard','meGondorBow','meGondor'])],'阿拉贡与南方援军乘黑船在哈隆德登陆');
  }else if(id==='me_erebor'){
    rect(0,0,31,3,T.MOUNTAIN);rect(4,4,10,10,T.MOUNTAIN);rect(20,4,26,10,T.MOUNTAIN);
    road(8,5,8,14);road(23,5,23,14);road(15,4,15,18);
    rect(16,9,16,19,T.RIVER);paint(16,13,T.RIVER|T.ROAD);
    for(const [c,r]of [[13,13],[14,14],[13,15],[18,13],[19,15]])E.setHouse(m,c,r);
    point('core',15,5,'孤山正门');point('counter',15,11,'山门通路');
    landmark(8,7,'乌鸦岭');landmark(23,7,'东侧山脊');landmark(14,14,'河谷邦废墟');
    west(['meThorin',15,5],...line(13,6,['meDwarf','meDwarf','meDwarf','meLake','meLake','meLake','meDwarf','meLake']),
      ...line(8,8,['meElf','meElf','meElf','meElf']),['meElf',23,8],['meElf',23,9]);
    east(['meBolg',17,16],...line(18,14,['meOrc','meOrcBow','meWarg','meWolf','meOrc','meOrc','meOrcBow','meOrc','meWarg','meOrc','meWolf','meOrc']),
      ['meWarg',8,15],['meOrc',9,15],['meWolf',23,15],['meOrc',24,15]);
    wave('eagles',5,'egypt',[['meEagle',10,8],['meEagle',21,8]],'巨鹰抵达两道山脊');
    wave('beorn',7,'egypt',[['meBeorn',12,16]],'比翁以巨熊形态加入战斗');
  }else if(id==='me_pelargir'){
    rect(22,0,31,19,T.SEA);
    for(const r of [5,10,15]){road(11,r,21,r);paint(22,r,T.ROAD);}
    for(const [c,r]of [[15,6],[17,7],[15,12],[18,13],[16,16],[20,12]])E.setHouse(m,c,r);
    for(const [i,r]of [5,10,15].entries())point('dock'+i,22,r,'黑船泊位 '+(i+1));
    point('core',20,10,'履约码头');
    west(['meAragorn',8,10],...line(9,8,['meGondor','meGuard','meGondorBow','meGondor']),
      ...line(12,8,['meDead','meDead','meDead','meDead']));
    east(...line(17,4,['meCorsair','meCorsair','meHarad','meCorsair']),
      ...line(18,9,['meCorsair','meCorsair','meCorsair','meHarad']),
      ...line(18,14,['meCorsair','meHarad','meCorsair','meCorsair']),
      ...[5,10,15].map(r=>['meBlackShip',22,r]));
  }else{
    rect(19,0,21,16,T.SEA);rect(40,0,42,16,T.SEA);
    rect(0,0,18,2,T.MOUNTAIN);rect(0,14,18,16,T.MOUNTAIN);
    rect(14,3,18,13,T.MOUNTAIN);road(3,8,17,8);
    rect(5,5,7,6,T.MOUNTAIN);rect(5,10,7,11,T.MOUNTAIN);
    rect(10,6,11,7,T.RIVER);rect(10,10,11,11,T.RIVER);
    for(let r=5;r<=11;r++)wall(16,r,'coalition','黑门',r===8,3);
    landmark(6,5,'北荒渣丘');landmark(6,11,'南荒渣丘');point('front',8,8,'黑门正面');
    rect(22,0,39,4,T.MOUNTAIN);rect(22,12,39,16,T.MOUNTAIN);road(23,8,38,8);
    for(const [c,r]of [[28,7],[29,9],[30,7],[32,9],[35,7]])paint(c,r,T.MOUNTAIN);
    point('start',23,8,'西力斯昂哥入口');point('pass',38,8,'潜行序幕出口');
    landmark(31,8,'尸罗巢穴');
    rect(51,1,59,15,T.MOUNTAIN);road(44,9,53,9);road(53,5,53,9);road(53,5,59,5);
    point('ash',44,9,'灰烬地');point('crack',59,5,'火焰密室·末日裂隙');point('flee',58,12,'夺戒者逃离口');
    landmark(53,8,'末日山攀登路');landmark(47,3,'魔多巡逻营地');
    west(['meAragorn',5,8],['meRiderLord',5,9,'伊欧墨'],['meGandalf',5,7],
      ...line(6,6,['meGuard','meGondor','meGondorBow','meGondor','meRohan','meGuard','meGondorBow','meRohan']),
      ['meFrodo',id.endsWith('final')?44:23,id.endsWith('final')?9:8],
      ['meSam',id.endsWith('final')?44:23,id.endsWith('final')?10:9]);
    east(...line(12,4,['meOrc','meOrcBow','meEast','meOrc','meTroll','meOrc','meOrcBow','meOrc','meEast','meOrc','meOrc','meOrcBow','meOrc','meTroll','meOrc','meOrc']),
      ['meNazgul',15,9],['meTracker',47,3],['meTracker',49,13],['meOrc',46,4],
      ['meShelob',32,7],['meGollum',25,10]);
    if(id.endsWith('final')){
      Object.assign(m.units.find(u=>u.kind==='meGollum'),{c:46,r:12});
      m.units=m.units.filter(u=>u.kind!=='meShelob');
    }
    wave('mordor-1',3,'coalition',line(17,4,['meOrc','meOrcBow','meEast','meOrc','meOrc','meOrc']),'魔多第一批预备队从门楼方向压上');
    wave('mordor-2',6,'coalition',line(17,9,['meOrc','meOrc','meTroll','meOrc','meOrcBow','meEast']),'魔多最后一批预备队入场');
  }
  const original=expandBoard(m,dual);
  const expanded=legacy?null:expandedMiddleEarthMap(original,{compact:layoutVersion===6});
  if(!expanded)return original;
  const map=layoutVersion===2||layoutVersion===6?expanded:layoutVersion===3?makeLargeMiddleEarthMap(expanded):scaleMiddleEarthMap(expanded,layoutVersion);
  if(layoutVersion===6&&largeArmies)applyArmyDeployment(map);
  E.validateMap(map);
  return map;
}

function expandBoard(base,dual){
  const map=E.newMap(dual?81:40,dual?23:26);
  const project=dual?morannonCell:(c,r)=>({c:c+4,r:r+3});
  const clamp=(x,max)=>Math.max(0,Math.min(max,x));
  for(let r=0;r<map.rows;r++)for(let c=0;c<map.cols;c++){
    if(dual&&(c>=27&&c<30||c>=54&&c<57)){E.setTerrain(map,c,r,E.TERRAIN.SEA);continue;}
    const source=dual?(c<27?clamp(c<14?c-2:Math.max(11,c-7),18):c<54?Math.max(22,Math.min(39,c-10)):Math.max(43,Math.min(60,c-17))):clamp(c-4,31);
    E.setTerrain(map,c,r,base.terrain[clamp(r-3,base.rows-1)*base.cols+source]);
  }
  // Preserve every authored cell exactly after expanding the approach corridors.
  for(let r=0;r<base.rows;r++)for(let c=0;c<base.cols;c++){
    if(dual&&(c>=19&&c<=21||c>=40&&c<=42))continue;
    const p=project(c,r),i=E.index(base,c,r);
    E.setTerrain(map,p.c,p.r,base.terrain[i]);
    if(base.houses[i])E.setHouse(map,p.c,p.r);
  }
  for(const key of ['name','intro','scenarioId','factions','gateRules'])map[key]=base[key];
  const shift=p=>({...p,...project(p.c,p.r)});
  map.units=base.units.map(shift);map.landmarks=base.landmarks.map(shift);
  const points=Object.fromEntries(Object.entries(base.victory.points).map(([k,p])=>[k,shift(p)]));
  const waves=base.victory.waves.map(w=>({...w,rows:w.rows.map(([kind,c,r,name])=>{
    const p=project(c,r);return [kind,p.c,p.r,name??null];
  })}));
  map.victory={...base.victory,points,waves};
  E.validateMap(map);
  return map;
}
