import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {creditKill,GROWTH,growthLevel,PROMOTION_COSTS} from './unit-growth.mjs';
import {becomeMutinous,settleMutiny,mutinyProbability,initializeMutiny,MUTINY_RULES} from './mutiny.mjs';
import {createSave,restoreSave} from './save.mjs';
import {knownMap} from './fog-policy.mjs';
function fixture(){
 const m=E.newMap(24,16);m.scenarioId='custom_growth';
 E.addUnit(m,'pharaoh','egypt',1,1);E.addUnit(m,'light','egypt',5,5);E.addUnit(m,'light','coalition',6,5);
 const s=E.startGame(m,{mutinySeed:123,reserveResponses:true});
 return {s,u:s.map.units[1],v:s.map.units[2]};
}
function kill(s,u,kind='light',flags={}){const target={id:'victim'+(u.kills||0),kind,team:'coalition',hp:0,...flags};E.recordUnitKill(s,u,target,1);return target;}
for(let rank=0;rank<=4;rank++)test('rank '+rank+' exact derived stats, proportional health and unchanged AP',()=>{
 const {s,u}=fixture(),baseHp=E.unitMaxHp(s.map,u),attack=E.meleePower(u,s.map),defense=E.unitArmor(s.map,u);u.hp=baseHp*.6;
 E.setVeteranLevel(s.map,u,rank);assert.equal(E.unitMaxHp(s.map,u),Math.round(baseHp*GROWTH[rank].hp));assert.equal(u.hp,Math.round(baseHp*.6*GROWTH[rank].hp));assert.equal(E.meleePower(u,s.map),attack*GROWTH[rank].attack);assert.equal(E.unitArmor(s.map,u),defense*GROWTH[rank].defense);assert.equal(u.actionsLeft,2);
});
test('ordinary promotions at cumulative 1,2,4,6 kills; repeat death, friend, building and nonfatal reward rejected',()=>{
 const {s,u}=fixture();let target;
 for(const expected of [1,2,2,3,3,4]){target=kill(s,u);assert.equal(growthLevel(u),expected);}
 assert.equal(u.kills,6);E.recordUnitKill(s,u,target,0);assert.equal(u.kills,6);
 for(const flags of [{team:'egypt'},{kind:'fort'},{hp:1}]){kill(s,u,'light',flags);assert.equal(u.kills,6);}
 kill(s,u);assert.equal(u.kills,7);assert.equal(growthLevel(u),4);
});
test('elite +2 and hero +4 select highest reward, retaining prior ordinary progress',()=>{
 const {s,u}=fixture();E.setVeteranLevel(s.map,u,2);u.promotionProgress=1;kill(s,u,'guard');assert.equal(u.veteranLevel,4);assert.equal(u.promotionProgress,1);assert.equal(u.kills,1);
 const another=fixture();another.u.promotionProgress=0;kill(another.s,another.u,'hero',{elite:true,commander:'hero'});assert.equal(another.u.veteranLevel,4);assert.equal(another.u.kills,1);assert.equal(another.u.promotionProgress,0);
});
test('actual melee lethal hit promotes before victory and counterattack lethal hit credits defender',()=>{
 const {s,u,v}=fixture();v.hp=1;const hit=E.attack(s,u.id,v.c,v.r,.01,.5,1,1);assert.ok(hit.ok&&hit.hit);assert.equal(u.kills,1);assert.equal(u.veteranLevel,1);
 const next=fixture();next.u.hp=1;next.v.actionsLeft=2;const random=Math.random;Math.random=()=>.01;
 try{const result=E.attack(next.s,next.u.id,next.v.c,next.v.r,.01,.1,1,1);assert.ok(result.response?.hit);assert.equal(next.u.hp,0);assert.equal(next.v.kills,1);assert.equal(next.v.veteranLevel,1);}finally{Math.random=random;}
});
test('map and save roundtrips preserve injured veterans without stacking or resetting progress',()=>{
 const {s,u}=fixture();E.setVeteranLevel(s.map,u,3);u.hp=63;u.promotionProgress=1;u.kills=4;
 const map=E.importMap(E.exportMap(s.map));const restored=map.units.find(v=>v.c===u.c&&v.r===u.r);assert.equal(restored.hp,63);assert.equal(restored.veteranLevel,3);
 const save=createSave(s.map,s,'egypt'),loaded=restoreSave(JSON.parse(JSON.stringify(save))).game;
 assert.equal(loaded.map.units[1].hp,63);assert.equal(E.unitMaxHp(loaded.map,loaded.map.units[1]),E.unitMaxHp(s.map,u));assert.equal(loaded.mutinyState.random,s.mutinyState.random);
});
test('mutiny keeps health/rank/AP, cancels old tasks, refuses manual control and attacks old allies',()=>{
 const {s,u,v}=fixture();E.setVeteranLevel(s.map,u,2);u.hp=60;u.actionsLeft=1;s.delegatedOrders=[{ids:[u.id],progress:{},status:'active',irrevocable:true}];
 assert.ok(becomeMutinous(s,u,'欠饷'));assert.equal(u.hp,60);assert.equal(u.actionsLeft,1);assert.equal(u.veteranLevel,2);assert.equal(s.delegatedOrders[0].status,'failed');assert.equal(E.move(s,u.id,5,6).ok,false);assert.equal(E.attack(s,u.id,v.c,v.r).ok,false);
 const own=s.map.units[0];own.c=5;own.r=6;own.hp=1;v.c=22;v.r=14;E.recomputeFog(s);
 const events=E.runMutinousUnits(s,()=>.01);assert.ok(events.some(e=>e.type==='attack'));assert.equal(own.hp,0);assert.equal(u.kills,1);assert.deepEqual(E.runMutinousUnits(s,()=>.01),[]);
});
test('both sides may attack mutineers, hidden units do not gain the former army vision',()=>{
 const {s,u,v}=fixture();becomeMutinous(s,u);u.hp=80;E.recomputeFog(s);assert.ok(E.attackPreview(s,s.map.units[0],u.c,u.r)===null); // commander is too far away
 const own=s.map.units[0];own.c=5;own.r=6;E.recomputeFog(s);assert.ok(E.attackPreview(s,own,u.c,u.r));s.side='coalition';assert.ok(E.attackPreview(s,v,u.c,u.r));
 const far={id:'far',kind:'light',team:'coalition',hp:70,c:23,r:15};s.map.units.push(far);E.recomputeFog(s);assert.ok(!E.unitSightCells(s,u).has('23,15'));
});
test('merged check once per logical round; cross-team infection waits until next round',()=>{
 const {s,u,v}=fixture();becomeMutinous(s,u);v.c=6;v.r=5;settleMutiny(s,E.distance,()=>0);assert.ok(!v.mutinous);s.turn++;settleMutiny(s,E.distance,()=>0);assert.ok(v.mutinous);const state=JSON.stringify(s.mutinyState);settleMutiny(s,E.distance,()=>0);assert.equal(JSON.stringify(s.mutinyState),state);
});
test('risk requires real pressure; rank and elite reduce both independent and propagation risk monotonically',()=>{
 assert.equal(mutinyProbability({kind:'light'}),0);let previous=Infinity;
 for(let level=0;level<=4;level++){const u={kind:'light',veteranLevel:level,unpaidTurns:4,combatStreak:7};const p=mutinyProbability(u,2);assert.ok(p<previous);assert.ok(mutinyProbability({...u,elite:true},2)<p);previous=p;}
 assert.ok(mutinyProbability({kind:'light'},1)>0);assert.ok(mutinyProbability({kind:'light',unpaidTurns:3})>0);assert.ok(mutinyProbability({kind:'light',combatStreak:6})>0);
});
for(const id of ['china_changping','china_qin_chu','china_seven_states','china_longxi'])test(id+' actual logistics: all ranks share hunger lifetime, consumption and fractional loss',async()=>{
 const {mapFor}=await import('../../tools/ai-training/maps.mjs');const histories=[];
 for(let level=0;level<=4;level++){
   const s=E.startGame(mapFor(id),{mutinySeed:123}),u=s.map.units.find(u=>u.team==='egypt'&&E.logisticsSoldier(u)&&E.usesMorale(u));assert.ok(s.map.logistics&&u);
   s.map.units=s.map.units.filter(v=>v.id===u.id||v.kind==='pharaoh'||v.kind==='hittiteKing');
   E.setVeteranLevel(s.map,u,level,{initial:true});u.hunger=3;u.fedTurns=0;u.hungerClock=0;s.money.egypt=100000;s.over=false;
   const trace=[];for(let turn=0;turn<20&&u.hp>0;turn++){E.advanceLogistics(s,'egypt');trace.push({ratio:u.hp/E.unitMaxHp(s.map,u),hunger:u.hunger,food:u.fedTurns,routed:E.isRouted(u)});s.over=false;}
   histories.push(trace);
 }
 const base=histories[0];for(const trace of histories){assert.equal(trace.length,base.length);for(let i=0;i<trace.length;i++){assert.ok(Math.abs(trace[i].ratio-base[i].ratio)<.011);assert.equal(trace[i].hunger,base[i].hunger);assert.equal(trace[i].food,base[i].food);assert.equal(trace[i].routed,base[i].routed);}}
});
test('actual paid wages differ from due, arrears accrue and later funds repay them',()=>{
 const {s,u}=fixture();s.map.logistics={income:{egypt:0,coalition:0},depots:{egypt:[],coalition:[]},musters:{egypt:[],coalition:[]}};s.money={egypt:0,coalition:0};E.advanceLogistics(s,'egypt');assert.ok(u.wagesDue>0);assert.equal(u.wagesPaid,0);assert.equal(u.unpaidTurns,1);assert.ok(u.wageArrears>0);s.money.egypt=100;E.advanceLogistics(s,'egypt');assert.equal(u.wageArrears,0);assert.equal(u.unpaidTurns,0);
});
test('rest recovery uses a flat base times rank multiplier and is suppressed without food',()=>{
 for(let rank=0;rank<=4;rank++){
   const {s,u,v}=fixture();v.c=22;v.r=14;E.setVeteranLevel(s.map,u,rank);u.hp=10;E.endSide(s,()=>.5);assert.equal(u.hp,10+Math.round(10*GROWTH[rank].recovery));
   const hungry=fixture();hungry.v.c=22;hungry.v.r=14;E.setVeteranLevel(hungry.s.map,hungry.u,rank);hungry.u.hp=10;hungry.u.hunger=1;hungry.u.fedTurns=0;hungry.s.map.logistics={income:{egypt:100,coalition:100},depots:{egypt:[],coalition:[]},musters:{egypt:[],coalition:[]}};hungry.s.money={egypt:100,coalition:100};E.endSide(hungry.s,()=>.5);assert.equal(hungry.u.hp,10);
 }
});
test('actual ranged kill and commander kill receive rewards before terminal victory',()=>{
 const {s,u,v}=fixture();u.kind='archer';u.ammo=5;v.c=8;v.hp=1;E.recomputeFog(s);const hit=E.attack(s,u.id,v.c,v.r,.01,.5,1,1);assert.ok(hit.hit);assert.equal(u.veteranLevel,1);
 const next=fixture();next.v.kind='hittiteKing';next.v.hp=1;assert.ok(E.attack(next.s,next.u.id,next.v.c,next.v.r,.01,.5,1,1).hit);assert.equal(next.u.veteranLevel,4);assert.equal(next.u.kills,1);assert.equal(next.s.over,true);
});
test('all remaining troops mutiny is a loss of command, never a stuck battle',()=>{
 const {s}=fixture();for(const u of s.map.units.filter(u=>u.team==='egypt'))becomeMutinous(s,u);E.checkVictory(s);assert.equal(s.over,true);assert.equal(s.winner,'coalition');assert.ok(s.map.units.some(u=>u.mutinous&&u.hp>0));
});
test('unrelated mutineer cannot share vision of a hidden target with another mutineer',()=>{
 const {s,u,v}=fixture();v.c=22;v.r=14;E.addUnit(s.map,'light','egypt',21,14);const other=s.map.units.at(-1);becomeMutinous(s,u);becomeMutinous(s,other);E.recomputeFog(s);const before={c:u.c,r:u.r,ap:u.actionsLeft};E.runMutinousUnits(s,()=>.01);assert.deepEqual({c:u.c,r:u.r,ap:u.actionsLeft},before);
});
test('mid-pressure save/load preserves the next combined random check and never redraws on fog refresh',()=>{
 const {s,u}=fixture();u.combatStreak=6;settleMutiny(s,E.distance);const saved=createSave(s.map,s,'egypt'),copy=restoreSave(JSON.parse(JSON.stringify(saved))).game;
 const seed=copy.mutinyState.random;for(let i=0;i<4;i++)E.recomputeFog(copy);assert.equal(copy.mutinyState.random,seed);s.turn++;copy.turn++;assert.deepEqual(settleMutiny(copy,E.distance),settleMutiny(s,E.distance));assert.equal(copy.mutinyState.random,s.mutinyState.random);
});
test('reapplying base editor stats to an injured veteran never compounds HP or attack',()=>{const {s,u}=fixture();E.setVeteranLevel(s.map,u,4);u.hp=70;E.setUnitStats(s.map,u.kind,{});E.setUnitStats(s.map,u.kind,{});assert.equal(u.hp,70);assert.equal(E.unitMaxHp(s.map,u),140);assert.equal(E.meleePower(u,s.map),E.STATS.light.melee*1.6);});
test('normal AI attacks a visible mutineer even from its original team',()=>{const {s,u,v}=fixture();becomeMutinous(s,v);v.team='egypt';v.originalTeam='egypt';E.recomputeFog(s);const actions=E.aiTurn(s,()=>.01);assert.ok(actions.some(a=>a.id===u.id&&a.type==='attack'));assert.ok(!actions.some(a=>a.id===v.id));});

test('example 60/100 becomes 72/120 and salary-free battles cannot synthesize arrears risk',()=>{const {s,u}=fixture();E.setUnitStats(s.map,'light',{hp:100});u.hp=60;kill(s,u);assert.equal(u.hp,72);assert.equal(E.unitMaxHp(s.map,u),120);u.unpaidTurns=10;u.combatStreak=0;s.turn++;settleMutiny(s,E.distance,()=>0);assert.equal(u.mutinous,undefined);});
test('multiple attributed deaths in one trample action promote consecutively without duplicate rewards',()=>{const {s,u,v}=fixture();u.kind='warElephant';u.uncontrolled=true;v.hp=1;const spot=E.neighbors(u.c,u.r).find(p=>!E.mobileAt(s.map,p.c,p.r));E.addUnit(s.map,'light','coalition',spot.c,spot.r);s.map.units.at(-1).hp=1;E.moveUncontrolledElephants(s,()=>.5);assert.equal(u.kills,2);assert.equal(u.veteranLevel,2);});
