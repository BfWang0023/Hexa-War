/**
 * HUD：顶栏 / 招募栏 / 单位列表 / 棋子控制面板 / 消息 / 日志 / 帮助 / 结算。
 *
 * 面板功能与原 GUI 右侧面板**一一对应**（招募、追加部署、初始搭载、存档读档、
 * 同时攻击、炮兵模式、装载/卸下、补给、大本营补给、屋顶、结束行动…），
 * 但布局按要求改为：顶栏 + 左上招募 + 右上缩略图 + 左下我军列表 +
 * 右下敌军列表 + 下方中部棋子控制面板。
 */

import { hexDistance, axialFromOffset, offsetToWorld, T } from '../core/hex.js';

const $ = (id) => document.getElementById(id);

export class Hud {
  constructor(ctx) {
    this.store = ctx.store;
    this.net = ctx.net;
    this.world = ctx.world;
    this.camera = ctx.camera;
    this.units = ctx.units;
    this.anim = ctx.anim;
    this.onFocusUnit = ctx.onFocusUnit;
    this.confirm = { restart: 0, endTurn: 0 };
    this.pendingCargoKind = 'rifleman';
    this.lastError = '';
    this.toasts = [];
    this.el = {
      turn: $('tb-turn'), phase: $('tb-phase'), status: $('tb-status'),
      recruit: $('recruit'), rcPoints: $('rc-points'), rcIncome: $('rc-income'),
      rcBody: $('rc-body'), rcList: $('rc-list'), rcHint: $('rc-hint'),
      rcCargo: $('rc-cargo'), rcSustain: $('rc-sustain'),
      rcFinish: $('rc-finish'), rcDone: $('rc-done'), rcRandom: $('rc-random'), rcEnter: $('rc-enter'),
      ownItems: $('own-items'), enemyItems: $('enemy-items'),
      ownCount: $('own-count'), enemyCount: $('enemy-count'), enemyTitle: $('enemy-title'),
      control: $('control'), ctrlHead: $('ctrl-head'), ctrlBody: $('control')?.querySelector('.ctrl-body'),
      ctrlStats: $('ctrl-stats'),
      ctrlStatus: $('ctrl-status'), ctrlActions: $('ctrl-actions'), ctrlHint: $('ctrl-hint'),
      toasts: $('toasts'), logbox: $('logbox'), logLines: $('log-lines'),
      tooltip: $('tooltip'), hover: $('hover-hex'), hoverPanel: $('hover-panel'),
      help: $('help'), helpBody: $('help-body'),
      gameover: $('gameover'), goMsg: $('go-msg'),
      minimapCoord: $('mm-coord'),
    };
    this.rcUserCollapsed = false;
    this.bind();
    // 捕获阶段拦截：鼠标在招募栏/日志面板上时，滚轮只滚动面板
    window.addEventListener('wheel', (e) => this.handlePanelWheel(e), { capture: true, passive: false });
    this.buildHelp();
  }

  /* ================================================================== */
  /* 事件绑定                                                            */
  /* ================================================================== */
  bind() {
    const net = this.net;
    // 顶栏
    $('btn-endturn').onclick = () => this.endTurn();
    $('btn-restart').onclick = () => this.restart();
    $('btn-export').onclick = () => net.cmd('exportLog');
    $('btn-test').onclick = () => net.cmd('enterTestMode');
    $('btn-fastforward').onclick = () => this.fastForward();
    $('btn-help').onclick = () => this.toggleHelp(true);
    $('help-close').onclick = () => this.toggleHelp(false);
    $('btn-ai').onclick = (e) => { e.stopPropagation(); this.toggleAiMenu(); };
    $('btn-settings').onclick = (e) => { e.stopPropagation(); this.toggleSettingsMenu(); };
    $('btn-map').onclick = (e) => { e.stopPropagation(); this.toggleMapMenu(); };
    $('go-restart').onclick = () => { this.el.gameover.classList.add('hidden'); net.cmd('restart', { force: true }); };
    $('go-close').onclick = () => this.el.gameover.classList.add('hidden');
    $('log-toggle').onclick = () => this.toggleLog();
    $('log-close').onclick = () => this.toggleLog(false);
    $('mm-fit').onclick = () => this.fitView();
    // 招募栏：点击展开 = 进入招募/追加部署，点击收起 = 退出
    $('rc-toggle').onclick = () => this.setRecruitOpen(this.el.recruit.classList.contains('collapsed'), true);
    this.el.rcRandom.onclick = () => net.cmd('randomDeploy');
    this.el.rcFinish.onclick = () => net.cmd('finishDeploy');
    this.el.rcDone.onclick = () => this.setRecruitOpen(false, true);   // 完成招募 = 收起面板（退出）
  }

  /** 展开/收起招募栏；用户手动操作时同步进入/退出招募（追加部署）模式。
   *  **收起 = 确认**：招募/追加部署阶段收起即完成招募，开局部署阶段收起即开始战斗。 */
  setRecruitOpen(open, byUser = false) {
    const rc = this.el.recruit;
    const st = this.store.state;
    rc.classList.toggle('collapsed', !open);
    if (byUser) this.rcUserCollapsed = !open;
    if (!st) return;
    if (open) {
      // 可持续部署模式下，展开即进入招募/追加部署（部署阶段本身就是招募阶段）
      if (st.sustain?.on && !st.sustainDeploying && !st.deploying && !st.over) {
        this.net.cmd('toggleSustainDeploy');
      }
      return;
    }
    if (st.testPlacing) return;              // 试验放置由 F3 退出
    if (st.sustainDeploying) {
      // 收起 = 点「完成招募」：退出招募/追加部署并清掉待放置兵种
      this.net.cmd('toggleSustainDeploy');
      this.net.cmd('clearRecruit');
      return;
    }
    if (byUser && st.deploying) {
      // 收起 = 点「开始战斗」；与按钮一致：至少部署一个棋子
      if (this.store.ownUnits.length === 0) {
        this.toast('至少部署一个棋子后才能开始战斗', 'err');
        this.setRecruitOpen(true, true);
        return;
      }
      this.net.cmd('clearRecruit');
      this.net.cmd('finishDeploy');
      this.toast('招募栏已收起：开始战斗');
      return;
    }
    this.net.cmd('clearRecruit');
  }

  /** 滚轮落在招募栏/日志面板上时滚动它们，而不是缩放地图。 */
  handlePanelWheel(e) {
    const sm = document.getElementById('settings-menu');
    const mm = document.getElementById('map-menu');
    const targets = [
      [this.el.recruit, this.el.rcBody],
      [this.el.logbox, this.el.logLines],
      // 棋子（单位）详情面板：面板本身不拦鼠标（方便点它后面的地块），
      // 但滚轮必须落在面板上时滚动它的正文，而不是缩放地图
      [this.el.control, this.el.ctrlBody],
      // 单位列表（左下我军 / 右下敌军）：列表本体滚动
      [this.el.ownItems?.closest('.list-panel'), this.el.ownItems],
      [this.el.enemyItems?.closest('.list-panel'), this.el.enemyItems],
      // 顶栏下拉：本身就是滚动容器
      [sm, sm],
      [mm, mm],
    ];
    // 面板矩形按 200ms 缓存：滚轮事件很密集，逐个读布局会触发同步重排
    const now = performance.now();
    if (!this._rects || now - (this._rectsAt || 0) > 200) {
      this._rectsAt = now;
      this._rects = targets.map(([box]) => (box ? box.getBoundingClientRect() : null));
    }
    for (let i = 0; i < targets.length; i++) {
      const [box, scroller] = targets[i];
      if (!box || !scroller || box.classList.contains('hidden')) continue;
      const r = this._rects[i];
      if (!r || e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) continue;
      scroller.scrollTop += e.deltaY;
      e.preventDefault();
      e.stopPropagation();
      return true;
    }
    return false;
  }

  endTurn() {
    const st = this.store.state;
    const remaining = this.store.ownUnits.filter(u => u.actions > 0).length;
    const now = performance.now();
    if (remaining > 0 && now - this.confirm.endTurn > 2500) {
      this.confirm.endTurn = now;
      this.toast(`还有 ${remaining} 个单位未行动，再点一次「结束回合」确认`, 'err');
      this.render(this.store.state);
      return;
    }
    this.confirm.endTurn = 0;
    this.net.cmd('endTurn', { force: true });
  }

  restart() {
    const now = performance.now();
    if (now - this.confirm.restart > 2500) {
      this.confirm.restart = now;
      this.toast('再点一次「重新开始」确认', 'err');
      this.render(this.store.state);
      return;
    }
    this.confirm.restart = 0;
    this.net.cmd('restart', { force: true });
  }

  fitView() {
    const w = Math.sqrt(3) * 6 * this.store.cols;
    const d = 1.5 * 6 * this.store.rows;
    const cam = this.world.camera;
    const vfov = (cam.fov * Math.PI) / 180;
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * cam.aspect);
    // 俯视投影下地图在屏幕竖直方向占 d*sin(pitch)，水平方向占 w
    const pitch = this.camera.pitch;
    const distV = (d * Math.sin(pitch) * 0.5) / Math.tan(vfov / 2);
    const distH = (w * 0.5) / Math.tan(hfov / 2);
    const dist = Math.max(distV, distH) * 1.16 + 12;
    this.camera.focus(w / 2 - Math.sqrt(3) * 3, d / 2 - 9, dist);
  }

  toggleHelp(show) {
    this.el.help.classList.toggle('hidden', !show);
  }

  toggleLog(show) {
    const el = this.el.logbox;
    const next = show === undefined ? el.classList.contains('hidden') : show;
    el.classList.toggle('hidden', !next);
    this.net.send({ t: 'ui', logOpen: next });
    this.scrollLog();
  }

  /* ================================================================== */
  /* 主渲染                                                              */
  /* ================================================================== */
  render(state) {
    if (!state) return;
    this.renderTop(state);
    this.renderRecruit(state);
    this.renderLists(state);
    this.renderControl(state);
    this.renderGameOver(state);
    // 让镜头取景避开面板：左上招募栏（展开时）与下方棋子控制面板。
    // 读面板尺寸会强制一次同步重排（前面刚写过 DOM），因此最多每 300ms 量一次，
    // 面板开合状态变化时立即重量。
    if (this.camera) this.updateUiPad();
    this.el.rcPoints.textContent = String(state.points?.blue ?? 0);
    const inc = state.sustain?.on ? (state.sustain.blue || 0) : 0;
    this.el.rcIncome.textContent = state.sustain?.on ? `+${inc}/回合` : '—';
    this.el.rcIncome.style.color = state.sustain?.on ? '' : 'var(--text-dim)';
  }

  /** 量取面板占位并写入相机边距（节流，避免每条状态更新都强制重排）。 */
  updateUiPad() {
    const rc = this.el.recruit;
    const ctrl = this.el.control;
    const rcOpen = !!(rc && !rc.classList.contains('collapsed'));
    const ctrlOpen = !!(ctrl && !ctrl.classList.contains('hidden'));
    const now = performance.now();
    const sig = (rcOpen ? 1 : 0) + '|' + (ctrlOpen ? 1 : 0);
    if (sig === this._padSig && now - (this._padAt || 0) < 300) return;
    this._padSig = sig;
    this._padAt = now;
    this.camera.uiPad.left = rcOpen ? Math.min(300, (rc.getBoundingClientRect().width || 246) + 16) : 0;
    this.camera.uiPad.bottom = ctrlOpen ? Math.min(320, (ctrl.getBoundingClientRect().height || 160) + 16) : 0;
  }

  renderTop(state) {
    const turn = state.turn ?? 0;
    this.el.turn.textContent = state.deploying ? '第 0 回合 · 部署' : `第 ${turn} 回合`;
    const phase = state.phase === 'blue' ? '我方行动' : '敌方行动';
    this.el.phase.textContent = state.over ? '对局结束'
      : state.deploying ? '部署阶段'
        : state.testMode ? '试验模式' : phase;
    this.el.phase.classList.toggle('enemy', state.phase === 'red' && !state.over && !state.deploying);
    // 状态提示串
    const bits = [];
    if (state.testMode) bits.push('🧪 试验模式');
    if (state.testPlacing) bits.push('📌 放置棋子');
    if (state.sustainDeploying) bits.push('🛠 追加部署');
    if (state.modes?.howitzerFire) bits.push('炮击模式');
    if (state.modes?.smoke) bits.push('烟雾弹待发射');
    if (state.modes?.load) bits.push('装载模式');
    if (state.modes?.supply) bits.push('补给模式');
    if (state.modes?.simul) bits.push(`⚔ 同时攻击（${(state.simulOrders || []).length} 条）`);
    if (state.pending?.disembark) bits.push(`等待放下地点`);
    if (state.confirm?.kind === 'endTurn' && state.confirm.fresh) bits.push('确认结束回合？');
    if (state.aiThinking) bits.push('🤖 AI 思考中…');
    else if (state.busy) bits.push('🤖 AI 行动播放中');
    else if (this.anim.busy) bits.push('▶ 动画播放中');
    if (state.error) bits.push('⚠ ' + state.error);
    this.el.status.textContent = bits.join('　');
    $('btn-ai').textContent = `🤖 AI：${this.store.aiVersion === 'v2' ? '新版' : '旧版'}`;
    $('btn-restart').classList.toggle('confirming', performance.now() - this.confirm.restart < 2500);
    $('btn-endturn').disabled = !!state.over || !!state.busy;
    $('btn-test').disabled = !state.deploying;
    // 只有真的在播放时才出现「⏩ 加速」（跳过敌方动画，立刻回到可操作状态）
    const playing = !!(state.busy || this.anim.busy);
    const ff = $('btn-fastforward');
    if (ff) {
      // 常驻显示、只在播放时可点：避免顶栏按钮位置来回抖动
      ff.disabled = !playing;
      ff.title = `跳过动画，立刻跳到最终局面（F）${this.store.settings.animSpeed > 1 ? ` · 当前动画速度 ${this.store.settings.animSpeed}×` : ''}`;
    }
  }

  /** 跳过当前动画：本地清空播放队列并让棋子落到最终位置，同时让后端提前解除输入屏蔽。 */
  fastForward() {
    if (!this.anim.busy && !this.store.state?.busy) return;
    this.anim.skipAll?.();
    this.net.cmd('fastForward');
    this.toast('已跳过动画，直接进入最终局面');
  }

  /* ---------------- 招募栏 ---------------- */
  renderRecruit(state) {
    const rc = this.el.recruit;
    const isDeploy = state.deploying;
    const isRecruit = state.sustainDeploying;
    const isTestPlace = state.testPlacing;
    const canRecruit = isRecruit || (state.sustain?.on && !state.over && !state.busy);
    const needRecruit = !!state.sustain?.on && !isRecruit && !isDeploy && !isTestPlace
      && !state.over && this.store.ownUnits.length === 0;
    // 刚进入招募/部署阶段：重新自动展开（否则上一局手动收起过就再也弹不出来）
    if ((isRecruit && !this.wasRecruit) || (isDeploy && !this.wasDeploy)) this.rcUserCollapsed = false;
    this.wasRecruit = isRecruit;
    this.wasDeploy = isDeploy;
    const autoOpen = (isDeploy || isTestPlace || isRecruit || needRecruit) && !this.rcUserCollapsed;
    if (autoOpen) rc.classList.remove('collapsed');
    // 提示文字
    let hint = '';
    if (isTestPlace) {
      hint = `试验放置：当前阵营 ${state.testPlaceTeam === 'blue' ? '我方（蓝）' : '敌方（红）'}，选择兵种后点击地图空位免费放置（F3 退出）。`;
    } else if (isDeploy) {
      hint = '点击兵种招募（可重复），再点击地图上青色高亮的出发区域放置；点击已放置的棋子可撤销返还点数。收起招募栏即开始战斗。';
    } else if (isRecruit) {
      const first = (state.recruitZoneTurn > 0 && state.turn <= state.recruitZoneTurn);
      hint = first
        ? `第 ${state.turn} 回合：可点击兵种后在本方出发区域招募，本回合即可行动。收起招募栏即完成招募。`
        : '点击兵种后在本方大本营周围 2 格内追加部署（本回合不可行动）。收起招募栏即完成招募。';
    } else if (state.sustain?.on) {
      const firstRound = state.recruitZoneTurn > 0 && state.turn <= state.recruitZoneTurn;
      hint = `♾ 持续部署：每回合 +${state.sustain.blue} 点，当前 ${state.points?.blue ?? 0} 点。`
        + `点击下方按钮（或按 D）进入${firstRound ? '招募' : '追加部署'}，再选兵种、点地图放置。`;
    } else {
      hint = '本局未启用持续部署（可在部署阶段开启）。';
    }
    this.el.rcHint.textContent = hint;
    // 兵种列表
    const pts = state.points?.blue ?? 0;
    const kinds = [...this.store.kinds.values()].filter(k => k.recruitable);
    const selected = state.pending?.recruit;
    const current = this.el.rcList.dataset.sig || '';
    const sig = [isDeploy, isRecruit, isTestPlace, pts, selected, state.testPlaceTeam, kinds.length].join('|');
    if (current !== sig) {
      this.el.rcList.dataset.sig = sig;
      const html = kinds.map(k => {
        const afford = isTestPlace || k.recruit <= pts;
        const sel = selected === k.token ? ' selected' : '';
        const dis = afford ? '' : ' disabled';
        return `<div class="rc-item${sel}${dis}" data-kind="${k.token}" title="${k.name}：射程${k.range} 攻击${k.attack} 护甲${k.armor} 命中${k.hit}% 行动${k.actions} 移动${k.move} 视野${k.vision} 弹药${k.ammo}${k.capacity ? ' 载重' + k.capacity : ''}">
          <span class="ri-icon">${kindIcon(k)}</span>
          <span class="ri-name">${k.name}</span>
          <span class="ri-cost">${isTestPlace ? '免费' : k.recruit + '点'}</span>
        </div>`;
      }).join('');
      this.el.rcList.innerHTML = html;
      this.el.rcList.querySelectorAll('.rc-item').forEach(el => {
        el.onclick = () => {
          if (el.classList.contains('disabled')) return;
          this.net.send({ t: 'recruitKind', kind: el.dataset.kind });
        };
      });
    }
    // 初始搭载
    const kind = selected ? this.store.kind(selected) : null;
    if (kind && kind.capacity > 0) {
      this.el.rcCargo.classList.remove('hidden');
      const cargo = state.pending?.cargo || [];
      const used = cargo.reduce((s, c) => s + (this.store.kind(c)?.weight || 0), 0);
      const choices = (kind.carries || []).map(t => this.store.kind(t)).filter(Boolean);
      const names = cargo.map(c => this.store.kindName(c)).join('、');
      const cost = cargo.reduce((s, c) => s + (this.store.kind(c)?.recruit || 0), 0) + kind.recruit;
      this.el.rcCargo.innerHTML = `
        <div><b>初始搭载</b>（${kind.name} 载重 ${used}/${kind.capacity}）</div>
        <div class="rcc-row">
          <select id="rc-cargo-kind">${choices.map(c => `<option value="${c.token}"${c.token === this.pendingCargoKind ? ' selected' : ''}>${c.name}（${c.weight}）</option>`).join('')}</select>
          <button class="btn small" id="rc-cargo-add">添加</button>
          <button class="btn small" id="rc-cargo-clear">清空</button>
        </div>
        ${names ? `<div>已装：${names}</div>` : ''}
        <div>总费用 <b>${cost}</b> 点${cost > pts ? ' · 点数不足' : ''}</div>`;
      $('rc-cargo-kind').onchange = (e) => { this.pendingCargoKind = e.target.value; };
      $('rc-cargo-add').onclick = () => this.net.send({ t: 'cargo', op: 'add', kind: this.pendingCargoKind });
      $('rc-cargo-clear').onclick = () => this.net.send({ t: 'cargo', op: 'clear' });
      $('rc-cargo-add').disabled = used + (this.store.kind(this.pendingCargoKind)?.weight || 0) > kind.capacity;
    } else {
      this.el.rcCargo.classList.add('hidden');
    }
    // 试验放置：阵营选择
    if (isTestPlace) {
      if (!this.el.rcCargo.classList.contains('hidden') === false) { /* keep */ }
      const div = document.createElement('div');
      div.className = 'rc-cargo';
      div.innerHTML = `<div><b>放置阵营</b></div><div class="rcc-row">
        <button class="btn small${state.testPlaceTeam === 'blue' ? ' active' : ''}" data-team="blue">我方（蓝）</button>
        <button class="btn small${state.testPlaceTeam === 'red' ? ' active' : ''}" data-team="red">敌方（红）</button>
      </div>`;
      div.querySelectorAll('button').forEach(b => {
        b.onclick = () => this.net.send({ t: 'testTeam', team: b.dataset.team });
      });
      this.el.rcSustain.innerHTML = '';
      this.el.rcSustain.appendChild(div);
      this.el.rcSustain.innerHTML += `<div style="margin-top:6px">F3 退出放置模式；试验模式下敌方不行动，视野外敌人以暗色显示。</div>`;
    } else if (isDeploy) {
      // 部署阶段：可持续部署设置（对应原右侧面板的「♾ 可持续部署」区）
      const on = !!state.sustain?.on;
      // 未开启时用与原 GUI 相同的默认值（我方 10 / 敌方 20 每回合）
      const pp = this.sustainPp ?? (on ? state.sustain.blue : 10);
      const ap = this.sustainAp ?? (on ? state.sustain.red : 20);
      this.el.rcSustain.innerHTML = `<div style="margin-top:4px"><b>♾ 可持续部署</b></div>
        <label><input type="checkbox" id="rc-sus-on" ${on ? 'checked' : ''}> 开启：每回合获得部署点数，可在大本营追加部署</label>
        <div class="rcc-row"><span style="color:var(--text-dim)">我方/回合</span>
          <input type="number" id="rc-sus-pp" min="0" max="200" value="${pp}">
          <span style="color:var(--text-dim)">敌方</span>
          <input type="number" id="rc-sus-ap" min="0" max="200" value="${ap}">
          <button class="btn small" id="rc-sus-apply">应用</button></div>`;
      $('rc-sus-apply').onclick = () => {
        this.sustainPp = parseInt($('rc-sus-pp').value || '10', 10);
        this.sustainAp = parseInt($('rc-sus-ap').value || '20', 10);
        this.net.send({ t: 'sustain', on: $('rc-sus-on').checked, pp: this.sustainPp, ap: this.sustainAp, apply: true });
      };
    } else {
      this.el.rcSustain.innerHTML = state.sustain?.on
        ? `♾ 持续部署已开启：每回合 +${state.sustain.blue}（我方）/ +${state.sustain.red}（敌方）点。`
        : '';
    }
    // 按钮可见性
    this.el.rcFinish.classList.toggle('hidden', !isDeploy);
    this.el.rcRandom.classList.toggle('hidden', !isDeploy);
    this.el.rcDone.classList.toggle('hidden', !isRecruit);
    this.el.rcFinish.disabled = this.store.ownUnits.length === 0;
    // 展开招募栏即进入招募模式，因此不再需要单独的「进入招募」按钮
    if (!canRecruit && !isDeploy && !isTestPlace) rc.classList.add('collapsed');
    const toggle = $('rc-toggle').querySelector('.rc-title');
    toggle.textContent = isTestPlace ? '放置棋子' : (isRecruit ? (state.recruitZoneTurn > 0 && state.turn <= state.recruitZoneTurn ? '招募' : '追加部署') : '招募');
  }

  /* ---------------- 单位列表 ---------------- */
  renderLists(state) {
    const mk = (u, own) => {
      const k = this.store.kind(u.kind);
      const hpPips = [];
      for (let i = 0; i < Math.min(6, u.maxHp); i++) {
        hpPips.push(`<i class="${i < u.hp ? 'on' : ''}"></i>`);
      }
      const selected = state.selected && state.selected.h[0] === u.h[0] && state.selected.h[1] === u.h[1]
        && !!state.selected.air === !!u.air;
      const cls = [own ? 'blue' : 'red', selected ? 'selected' : '', own && u.actions === 0 ? 'spent' : '',
        u.visible === false ? 'dim' : ''].filter(Boolean).join(' ');
      const extra = [];
      if (u.passengers?.length) extra.push('载' + u.passengers.map(p => p.label).join(','));
      if (u.deployed) extra.push('已架设');
      if (u.suppression > 0) extra.push('压制' + u.suppression);
      if (u.modeName && (u.missileMode || u.aaMode)) extra.push(u.modeName);
      const deployHint = this.store.isDeploying && own ? '　（点击撤销部署并返还点数）' : '';
      return `<div class="lp-item ${cls}" data-team="${u.team}" data-label="${u.label}" title="${k ? k.name : u.kind} 生命${u.hp}/${u.maxHp}　射程${k?.range ?? '-'} 攻击${k?.attack ?? '-'} 护甲${k?.armor ?? '-'} 命中${k?.hit ?? '-'}%　行动${u.actions}/${u.maxActions}${deployHint}">
        <span class="lp-label">${u.label}</span>
        <span class="lp-name">${k ? k.name : u.kind}${u.visible === false ? '（暗）' : ''}</span>
        ${extra.length ? `<span class="lp-act">${extra.join(' ')}</span>` : ''}
        <span class="lp-hp">${hpPips.join('')}</span>
        <span class="lp-act">${u.actions}/${u.maxActions}</span>
      </div>`;
    };
    const own = this.store.ownUnits;
    // 无迷雾视觉时列出全部敌军（未侦察到的标注「暗」）；开启迷雾时只列视野内敌军
    const testMode = !!this.store.state?.testMode;
    const hide = !!this.store.settings.hideUndetected && !testMode;
    const enemy = hide
      ? this.store.enemyUnits.filter(u => u.visible !== false)
      : this.store.enemyUnits;
    this.el.enemyTitle.textContent = testMode
      ? '敌方单位（试验模式全显）'
      : (hide ? '视野内敌军' : '敌军单位（暗=未被侦察）');
    // 内容签名未变就不重建 DOM（状态更新很频繁，两个列表加起来几十个节点）
    const ownHtml = own.length
      ? own.map(u => mk(u, true)).join('')
      : '<div class="lp-empty">暂无单位（部署阶段请在左上角招募）</div>';
    const enemyHtml = enemy.length
      ? enemy.map(u => mk(u, false)).join('')
      : `<div class="lp-empty">${hide ? '视野内暂无敌人（视野外敌军不可见）' : '暂无敌方单位'}</div>`;
    const sig = ownHtml + '\u0001' + enemyHtml + '\u0001' + (this.store.isDeploying ? 1 : 0);
    if (this.listsSig !== sig) {
      this.listsSig = sig;
      this.el.ownItems.innerHTML = ownHtml;
      this.el.enemyItems.innerHTML = enemyHtml;
      for (const el of [...this.el.ownItems.querySelectorAll('.lp-item'), ...this.el.enemyItems.querySelectorAll('.lp-item')]) {
        el.onclick = () => {
          const team = el.dataset.team, label = el.dataset.label;
          const u = this.store.unitByLabel(team, label);
          // 部署阶段点击我方单位 = 撤销部署并返还点数（与原右侧面板的已部署列表一致）
          if (this.store.isDeploying && team === 'blue' && u) {
            this.net.cmd('undeploy', { h: [u.h[0], u.h[1]] });
            return;
          }
          this.net.send({ t: 'focusUnit', team, label });
          if (u) this.onFocusUnit?.(u);
        };
      }
    }
    this.el.ownCount.textContent = String(own.length);
    this.el.enemyCount.textContent = String(enemy.length);
  }

  /* ---------------- 棋子控制面板 ---------------- */
  renderControl(state) {
    const box = this.el.control;
    const sel = state.selected;
    const u = this.store.selectedUnit;
    if (!sel || !u) {
      if (!box.classList.contains('hidden')) this._rectsAt = 0;
      box.classList.add('hidden');
      this.ctrlSig = null;
      return;
    }
    if (box.classList.contains('hidden')) this._rectsAt = 0;   // 面板刚出现，命中矩形要重量
    box.classList.remove('hidden');
    // 服务端在 unitDetails 里算好了「可移动格数 / 射程内目标 / 可装载与原因 / 补给范围」等，
    // 棋子原始状态里没有这些字段——必须从 unitDetails 里取（否则这些区块永远不显示）。
    const d = state.unitDetails || {};
    const k = this.store.kind(u.kind);
    const own = u.team === 'blue';
    const r = u.h[0], c = u.h[1];
    const terr = [];
    const mask = this.store.mask(r, c);
    if (mask & T.FOREST) terr.push('森林（被命中×0.8、移动×2）');
    if (mask & T.BUILDING) terr.push('楼房（步兵可入，被命中×0.6）');
    if (mask & T.WATER) terr.push('水域（仅空中单位）');
    if (mask & T.ROAD) terr.push('道路（车辆 0.5/格）');
    if (mask & T.ROCK) terr.push('岩石（阻挡视线）');
    const smoke = (state.smoke || []).find(s => s.h[0] === r && s.h[1] === c);
    if (smoke) terr.push(`烟雾（剩 ${smoke.turns} 回合）`);

    // 面板内容签名：状态更新很频繁，但选中棋子的数据大多没变，
    // 签名一致就整块跳过（否则每条 update 都要重建几十个节点）。
    const sig = JSON.stringify([
      u.label, u.kind, u.hp, u.maxHp, u.actions, u.maxActions, u.modeName, u.effRange, u.effAttack,
      u.effHit, u.ammo, u.missileMode, u.aaMode, u.missileAmmo, u.aaAmmo, u.deployed, u.rooftop,
      u.suppression, u.visible, u.adUses, u.passengers?.length, own, r, c, terr.join('|'),
      d.reachCount, d.inHqSupply, d.canDeployRooftop, d.weight, d.threats?.length,
      d.canRetreat ? (d.retreatRefund ?? 0) : 0,
      (d.targets || []).map(t => t.label + t.status + t.dist + (t.los ? 1 : 0)).join('|'),
      (d.unloadable || []).map(p => p.label).join('|'),
      (d.boardable || []).map(p => p.label + (p.fits === false ? 0 : 1) + (p.reason || '')).join('|'),
      (state.simulOrders || []).length, JSON.stringify(state.modes || null), this.ctrlCollapsed ? 1 : 0,
    ]);
    if (this.ctrlSig === sig) return;
    this.ctrlSig = sig;
    this._rectsAt = 0;     // 内容变了 → 面板高度可能变了，滚轮命中矩形立即重量

    this.el.ctrlHead.innerHTML = `
      <span class="ch-title ${own ? 'blue' : 'red'}">${u.label} · ${k?.name || u.kind}${own ? '（我方）' : '（敌方）'}</span>
      <span class="ch-sub">位置 ${r + 1},${c + 1}${terr.length ? ' · ' + terr.join('、') : ''}</span>
      <span class="ch-sub" style="margin-left:auto">生命 ${u.hp}/${u.maxHp}</span>
      <span class="ch-fold">${this.ctrlCollapsed ? '▲ 展开' : '▼ 收起'}</span>`;
    this.el.ctrlHead.onclick = () => {
      this.ctrlCollapsed = !this.ctrlCollapsed;
      box.classList.toggle('collapsed', this.ctrlCollapsed);
      this._rectsAt = 0;
      this.ctrlCollapsed ? null : null;
    };
    box.classList.toggle('collapsed', !!this.ctrlCollapsed);

    if (!own) {
      // 敌军：只显示基本属性与当前血量（不可查看弹药等内部信息）
      const rows = [
        ['类型', k?.name || u.kind],
        ['当前血量', `${u.hp} / ${u.maxHp}`, u.hp <= 1 ? 'danger' : ''],
        ['射程', `${k?.range ?? '-'} 格`],
        ['攻击力', `${k?.attack ?? '-'}`],
        ['护甲', `${k?.armor ?? '-'}`],
        ['基础命中', `${k?.hit ?? '-'}%`],
        ['行动力', `${k?.move ?? '-'}`],
        ['每回合行动', `${k?.actions ?? '-'}`],
        ['视野', `${k?.vision ?? '-'}`],
        ['压制', u.suppression ? `是（-${u.suppression}）` : '否'],
        ['屋顶', u.rooftop ? '在屋顶' : '—'],
      ];
      this.el.ctrlStats.innerHTML = '<div class="ctrl-sec">基本属性</div>' + rows.map(([a, b, cls]) =>
        `<div class="stat-row"><span class="k">${a}</span><span class="v ${cls || ''}">${b}</span></div>`).join('');
      this.el.ctrlStatus.innerHTML = '<div class="ctrl-sec">状态</div>' +
        `<div class="stat-row"><span class="k">可见性</span><span class="v ${u.visible === false ? 'warn' : 'ok'}">${u.visible === false ? '视野外（暗）' : '在视野内'}</span></div>` +
        (u.passengers?.length ? `<div class="stat-row"><span class="k">搭载</span><span class="v">${u.passengers.map(p => (this.store.kindName(p.kind)) + p.label).join('、')}</span></div>` : '');
      const threats = d.threats || [];
      this.el.ctrlActions.innerHTML = '<div class="ctrl-sec">威胁评估' +
        (threats.length ? '（能打到它的我方单位）' : '') + '</div>'
        + (threats.length
          ? threats.map(t => `<div class="target-line"><span class="chip ok">${t.label} ${this.store.kindName(t.kind)}</span><span style="color:var(--text-dim)">距离 ${t.dist}</span></div>`).join('')
          : `<div class="ctrl-hint">暂无（射程内没有打得穿它的我方单位）。敌方单位只读：不能查看弹药与武器模式。</div>`);
      this.el.ctrlHint.textContent = '点击我方棋子可查看完整数据并操作。';
      return;
    }

    /* ---- 我方：完整数据 ---- */
    const ammoInfo = this.ammoText(u, k);
    const stats = [
      ['位置', `${r + 1},${c + 1}`],
      ['生命', `${u.hp} / ${u.maxHp}`, u.hp <= 1 ? 'danger' : (u.hp < u.maxHp ? 'warn' : 'ok')],
      ['行动次数', `${u.actions} / ${u.maxActions}`, u.actions === 0 ? 'danger' : 'ok'],
      ['当前武器', u.modeName || '主武器'],
      ['射程', `${u.effRange ?? k?.range} 格`],
      ['攻击力', `${u.effAttack ?? k?.attack}`],
      ['命中率', `${u.effHit ?? k?.hit}%`],
      ['护甲', `${k?.armor}`],
      ['行动力', `${k?.move}`],
      ['视野', `${k?.vision}`],
      [ammoInfo[0], ammoInfo[1], ammoInfo[2]],
      ['可移动格数', `${d.reachCount ?? '-'}`],
    ];
    this.el.ctrlStats.innerHTML = '<div class="ctrl-sec">基本数据</div>' + stats.map(([a, b, cls]) =>
      `<div class="stat-row"><span class="k">${a}</span><span class="v ${cls || ''}">${b}</span></div>`).join('');

    const st = [];
    if (u.deployed) st.push(['架设', '已架设（可开火）', 'ok']);
    if (k?.needsDeploy && !u.deployed) st.push(['架设', '未架设（需先架设）', 'warn']);
    if (u.flares > 0) st.push(['诱饵弹', `${u.flares} 发（被命中×0.6）`, '']);
    if (u.adUses > 0) st.push(['主动防御', `剩余 ${u.adUses} 次`, 'blue']);
    if (u.suppression > 0) st.push(['压制', `-${u.suppression} 行动`, 'danger']);
    if (d.weight !== undefined && k?.capacity) st.push(['载重', `${d.weight} / ${k.capacity}`, '']);
    if (u.passengers?.length) st.push(['搭载', u.passengers.map(p => this.store.kindName(p.kind) + p.label).join('、'), '']);
    if (u.rooftop) st.push(['位置', '屋顶（视野/攻击无视遮挡）', 'warn']);
    if ((mask & T.BUILDING) && k?.foot) st.push(['位置', u.rooftop ? '屋顶' : '屋中（享受楼房隐蔽）', '']);
    if (smoke) st.push(['烟雾', '处于烟幕中（被命中×0.6）', '']);
    this.el.ctrlStatus.innerHTML = '<div class="ctrl-sec">当前状态</div>' + (st.length
      ? st.map(([a, b, cls]) => `<div class="stat-row"><span class="k">${a}</span><span class="v ${cls}">${b}</span></div>`).join('')
      : '<div class="ctrl-hint">无特殊状态</div>');

    /* ---- 操作区 ---- */
    const acts = [];
    const btn = (label, cmd, opts = {}) =>
      `<button class="btn small${opts.active ? ' active' : ''}${opts.primary ? ' primary' : ''}" data-cmd="${cmd}" ${opts.disabled ? 'disabled' : ''} title="${opts.title || ''}">${label}</button>`;
    // 武器模式
    if (k?.dualWeapon) acts.push(btn(`副武器 (M)`, 'toggleAmmo:missile', { active: u.missileMode, disabled: !u.missileAmmo && !u.missileMode, title: '切换主/副武器（坦克重机枪、M3E1、TOW、M864…）' }));
    if (k?.thirdWeapon) acts.push(btn(`Stinger (A)`, 'toggleAmmo:aa', { active: u.aaMode, title: '特战小队第三武器：Stinger 防空导弹' }));
    if (k?.needsDeploy) acts.push(btn('🛠 架设', 'entrench', { disabled: u.deployed || u.actions < 1, title: '消耗 1 次行动架设，之后才能开火（移动后需重新架设）' }));
    if (u.kind === 'howitzer' || u.kind === 'mortar') {
      acts.push(btn(state.modes?.howitzerFire ? '切到行动模式 (T)' : '切到射击模式 (T)', 'toggleHowitzer', { active: state.modes?.howitzerFire, title: '射击模式下点击射程内黄色格子炮击' }));
      const canSmoke = u.kind === 'mortar' ? (u.actions > 0 && u.ammo > 0) : u.deployed;
      acts.push(btn(state.modes?.smoke ? '💨 取消烟雾弹' : '💨 烟雾弹', 'toggleSmoke', { active: state.modes?.smoke, disabled: !canSmoke, title: '发射烟雾弹（遮挡视线 2 回合）' }));
    }
    // 载具
    if (k?.capacity > 0) {
      if (!k.air) {
        acts.push(btn(state.modes?.load ? '退出装载 (X)' : '装载模式 (X)', 'toggleLoad', { active: state.modes?.load, disabled: u.actions < 1 && !state.modes?.load, title: '进入后点击紧邻的己方单位上车（不能移动）' }));
      } else {
        acts.push(btn('装载正下方 (X)', 'heliBoard', { disabled: u.actions < 1 || (d.weight ?? 0) >= k.capacity, title: '把同一格的己方单位载入机舱' }));
      }
    }
    if (u.kind === 'supply') acts.push(btn(state.modes?.supply ? '退出补给 (S)' : '补给模式 (S)', 'toggleSupply', { active: state.modes?.supply, disabled: u.actions < 1, title: '点击半径 2 格内友军补给（双方各消耗 1 行动）' }));
    if (d.inHqSupply) acts.push(btn('🏛 大本营补给 (H)', 'hqResupply', { disabled: u.actions < 1, title: '消耗 1 行动恢复全部弹药' }));
    if (d.canDeployRooftop) acts.push(btn(u.rooftop ? '🏠 进入屋中' : '🪜 登上屋顶', 'toggleRooftop', { disabled: u.actions < 1, title: '屋顶：视野/攻击无视遮挡，但失去楼房隐蔽（消耗 1 行动）' }));
    acts.push(btn('⚔ 同时攻击 (U)', 'toggleSimul', { active: state.modes?.simul, title: '进入后依次点选我方单位与目标，按 C 统一结算' }));
    if (state.modes?.simul) acts.push(btn(`✅ 确认齐射 (C)`, 'confirmSimul', { primary: true, disabled: !(state.simulOrders || []).length }));
    // 撤退：单位位于本方出发区域（可部署区）内时可主动撤离，按血量比例返还招募点
    if (d.canRetreat) acts.push(btn(`🏳 撤退（返还 ${d.retreatRefund ?? 0} 点）`, 'retreat', { title: '单位立即撤离战场（含车上搭载单位），按「招募费用 × 当前HP/总HP」返还招募点数；撤退不算被歼灭' }));
    if (u.kind === 'supply' || u.actions > 0) acts.push(btn('结束该单位行动 (S)', 'passUnit', { disabled: u.actions === 0, title: '作废该单位剩余行动' }));
    acts.push(btn('取消选择 (Esc)', 'cancelSelection'));
    this.el.ctrlActions.innerHTML = '<div class="ctrl-sec">操作</div><div class="ctrl-actions">' + acts.join('') + '</div>';

    /* ---- 目标 / 货物列表 ---- */
    const extra = [];
    const targets = d.targets || [];
    if (targets.length) {
      extra.push('<div class="ctrl-sec">射程内目标（点击可选中/攻击）</div>');
      for (const t of targets) {
        extra.push(`<div class="target-line clickable" data-hex="${t.h[0]},${t.h[1]}">
          <span class="chip ${t.status === '可攻击' ? 'danger' : ''}">${t.status}</span>
          <span>${t.label} ${this.store.kindName(t.kind)}</span>
          <span style="color:var(--text-dim)">距离 ${t.dist}${t.los ? '' : ' · 视线受阻'}</span></div>`);
      }
    }
    if (d.unloadable?.length) {
      extra.push(`<div class="ctrl-sec">搭载货物（${d.unloadable.length} 件）</div>`);
      for (const p of d.unloadable) {
        extra.push(`<div class="target-line">${p.label} ${this.store.kindName(p.kind)}
          ${k.air ? `<button class="btn small" data-cmd="heliUnload:${p.label}" ${u.actions < 1 ? 'disabled' : ''}>放下到正下方</button>`
    : `<button class="btn small" data-cmd="disembarkPending:${p.label}" ${u.actions < 1 ? 'disabled' : ''}>放下</button>`}</div>`);
      }
    }
    if (d.boardable?.length) {
      const free = d.boardable[0].free ?? 0;
      extra.push(`<div class="ctrl-sec">可装载（剩余运力 ${free} 点，点击上车）</div>`);
      for (const p of d.boardable) {
        const ok = p.fits !== false;
        extra.push(`<div class="target-line">${p.label} ${this.store.kindName(p.kind)}
          <span class="chip ${ok ? '' : 'warn'}">${p.weight} 点</span>
          ${ok
    ? `<button class="btn small" data-cmd="board:${p.h[0]},${p.h[1]}">搭载</button>`
    : `<span class="hp-det" style="color:var(--warn)">${p.reason || '无法装载'}</span>`}</div>`);
      }
    }
    this.el.ctrlHint.innerHTML = extra.join('') || '提示：绿色=可移动，红色=可攻击，黄色=炮击范围，青色=可装载/放下。';
    // 按钮事件
    this.el.control.querySelectorAll('[data-cmd]').forEach(el => {
      el.onclick = () => this.runCommand(el.dataset.cmd);
    });
    this.el.control.querySelectorAll('[data-hex]').forEach(el => {
      el.onclick = () => {
        const [r2, c2] = el.dataset.hex.split(',').map(Number);
        this.net.click({ col: c2, row: r2 }, false);
      };
    });
  }

  runCommand(spec) {
    const [name, arg] = spec.split(':');
    switch (name) {
      case 'toggleAmmo': this.net.cmd('toggleAmmo', { which: arg }); break;
      case 'entrench': this.net.cmd('entrench'); break;
      case 'toggleHowitzer': this.net.cmd('toggleHowitzer'); break;
      case 'toggleSmoke': this.net.cmd('toggleSmoke'); break;
      case 'toggleLoad': this.net.cmd('toggleLoad'); break;
      case 'toggleSupply': this.net.cmd('toggleSupply'); break;
      case 'toggleSimul': this.net.cmd('toggleSimul'); break;
      case 'confirmSimul': this.net.cmd('confirmSimul'); break;
      case 'passUnit': this.net.cmd('passUnit'); break;
      case 'cancelSelection': this.net.cmd('cancelSelection'); break;
      case 'hqResupply': this.net.cmd('hqResupply'); break;
      case 'retreat': this.net.cmd('retreat'); break;
      case 'toggleRooftop': this.net.cmd('toggleRooftop'); break;
      case 'heliBoard': this.net.cmd('heliBoard'); break;
      case 'heliUnload': this.net.cmd('heliUnload', { label: arg }); break;
      case 'disembarkPending': this.net.cmd('disembarkPending', { label: arg }); break;
      case 'board': {
        const [r, c] = arg.split(',').map(Number);
        this.net.cmd('board', { h: [c, r] });
        break;
      }
      default: break;
    }
  }

  ammoText(u, k) {
    if (!k || k.ammo === 0 && !u.missileAmmo && !u.aaAmmo) return ['弹药', '无（该单位无武器）', ''];
    if (u.aaMode) return ['Stinger 弹', `${u.aaAmmo} / ${u.maxAaAmmo}`, u.aaAmmo === 0 ? 'danger' : 'ok'];
    if (u.missileMode) return ['副武器弹', `${u.missileAmmo} / ${u.maxMissileAmmo}`, u.missileAmmo <= 2 ? 'warn' : 'ok'];
    return ['主武器弹', `${u.ammo} / ${u.maxAmmo}`, u.ammo === 0 ? 'danger' : (u.ammo <= 2 ? 'warn' : 'ok')];
  }

  /* ---------------- 结算 / 菜单 ---------------- */
  renderGameOver(state) {
    if (state.over && !this._overShown) {
      this._overShown = true;
      const msg = state.result || '对局结束';
      this.el.goMsg.textContent = msg;
      this.el.goMsg.className = 'go-msg ' + (msg.includes('★') ? 'win' : (msg.includes('✗') ? 'lose' : ''));
      this.el.gameover.classList.remove('hidden');
    } else if (!state.over) {
      this._overShown = false;
      this.el.gameover.classList.add('hidden');
    }
  }

  /** AI 版本 / 难度菜单（对应原右侧面板与顶栏的 AI 设置）。 */
  toggleAiMenu() {
    const existing = $('ai-menu');
    if (existing) { existing.remove(); return; }
    const div = document.createElement('div');
    div.id = 'ai-menu';
    const v = this.store.aiVersion;
    const d = this.store.aiDifficulty;
    const diffs = [['recruit', '新兵'], ['regular', '常规'], ['veteran', '老兵'], ['elite', '精英']];
    div.innerHTML = `<h4>AI 设置</h4>
      <div class="qm-row"><label>智能版本</label>
        <select id="ai-ver">
          <option value="legacy"${v === 'legacy' ? ' selected' : ''}>旧版（经典三策略）</option>
          <option value="v2"${v === 'v2' ? ' selected' : ''}>新版（期望伤害+威胁图）</option>
        </select></div>
      <div class="qm-row"><label>难度</label>
        <select id="ai-diff">
          ${diffs.map(([k, n]) => `<option value="${k}"${d === k ? ' selected' : ''}>${n}</option>`).join('')}
        </select></div>
      <div class="mm-desc">难度仅影响新版 AI。对局中可随时切换。</div>`;
    document.getElementById('app').appendChild(div);
    $('ai-ver').onchange = (e) => {
      this.store.aiVersion = e.target.value;
      this.net.send({ t: 'ai', version: e.target.value });
      this.render(this.store.state);
    };
    $('ai-diff').onchange = (e) => {
      this.store.aiDifficulty = e.target.value;
      this.net.send({ t: 'ai', difficulty: e.target.value });
    };
    setTimeout(() => {
      document.addEventListener('pointerdown', function close(ev) {
        if (!div.contains(ev.target) && ev.target.id !== 'btn-ai') {
          div.remove();
          document.removeEventListener('pointerdown', close);
        }
      });
    }, 0);
  }

  /** 顶栏「设置」下拉菜单：悬停能见度、画质与各类显示选项。 */
  toggleSettingsMenu() {
    const existing = $('settings-menu');
    if (existing) { existing.remove(); return; }
    const st = this.store.settings;
    const div = document.createElement('div');
    div.id = 'settings-menu';
    div.innerHTML = `<h4>设置</h4>
      <div class="st-sec">镜头 · 鼠标拖动</div>
      <div class="st-row"><label>拖动方向</label>
        <select id="st-panmode">
          <option value="grab"${st.panMode === 'grab' ? ' selected' : ''}>内容跟随鼠标（抓取式）</option>
          <option value="camera"${st.panMode === 'camera' ? ' selected' : ''}>镜头跟随鼠标（反向）</option>
        </select></div>
      <div class="st-row"><label>拖动灵敏度</label>
        <input type="range" id="st-pansens" min="0.3" max="3" step="0.1" value="${st.panSens}">
        <span class="st-val" id="st-pansens-val">${Number(st.panSens).toFixed(1)}×</span></div>
      <div class="st-row"><label>水平反向</label>
        <input type="checkbox" id="st-invx" ${st.panInvertX ? 'checked' : ''}></div>
      <div class="st-row"><label>垂直反向</label>
        <input type="checkbox" id="st-invy" ${st.panInvertY ? 'checked' : ''}></div>
      <div class="st-note">拖动时「光标下的地面」会 1:1 跟手；若方向不合习惯可切换为反向或分轴反向。
        方向键平移不受此设置影响。</div>
      <div class="st-sec">悬停提示</div>
      <div class="st-row"><label>悬停显示能见度（探测结果）</label>
        <input type="checkbox" id="st-probe" ${st.hoverProbe ? 'checked' : ''}></div>
      <div class="st-row"><label>悬停触发延迟</label>
        <input type="range" id="st-delay" min="100" max="500" step="25" value="${st.hoverDelayMs}">
        <span class="st-val" id="st-delay-val">${(st.hoverDelayMs / 1000).toFixed(2)}s</span></div>
      <div class="st-sec">战争迷雾</div>
      <div class="st-row"><label>隐藏视野外敌军（机制，默认开启）</label>
        <input type="checkbox" id="st-hide" ${st.hideUndetected ? 'checked' : ''}></div>
      <div class="st-note">双方都看不到视野外的敌人：地图本身正常显示，敌人藏在上面，
        进入视野才显现。把鼠标停在格子上可查看该格敌人能否被发现。</div>
      <div class="st-row"><label>旧版迷雾覆盖与「?」标记（默认关闭）</label>
        <input type="checkbox" id="st-fog" ${st.fogVisual ? 'checked' : ''}></div>
      <div class="st-note">额外画出未侦察/半侦察的雾块，以及敌人最后已知位置的「?」标记。</div>
      <div class="st-sec">画质与性能</div>
      <div class="st-row"><label>画质档位</label>
        <select id="st-quality">
          <option value="low"${this.world.qualityKey === 'low' ? ' selected' : ''}>低（核显/老机器）</option>
          <option value="medium"${this.world.qualityKey === 'medium' ? ' selected' : ''}>中（推荐）</option>
          <option value="high"${this.world.qualityKey === 'high' ? ' selected' : ''}>高（独显）</option>
        </select></div>
      <div class="st-row"><label>渲染分辨率</label>
        <select id="st-res">
          <option value="auto"${this.world.resMode === 'auto' ? ' selected' : ''}>自动（保帧率，75%~100%）</option>
          <option value="100"${this.world.resMode === '100' ? ' selected' : ''}>100%（最清晰）</option>
          <option value="85"${this.world.resMode === '85' ? ' selected' : ''}>85%</option>
          <option value="75"${this.world.resMode === '75' ? ' selected' : ''}>75%（最流畅）</option>
        </select></div>
      <div class="st-note">分辨率是核显笔记本上最有效的一档性能开关。150%／200% 缩放的屏幕上，
        85% 与 100% 肉眼几乎无法区分，却少约 28% 像素。</div>
      <div class="st-row"><label>动画速度</label>
        <select id="st-animspeed">
          <option value="1"${Number(st.animSpeed) === 1 ? ' selected' : ''}>1×（原始节奏）</option>
          <option value="1.5"${Number(st.animSpeed) === 1.5 ? ' selected' : ''}>1.5×</option>
          <option value="2"${Number(st.animSpeed) === 2 ? ' selected' : ''}>2×</option>
          <option value="3"${Number(st.animSpeed) === 3 ? ' selected' : ''}>3×（AI 回合快很多）</option>
        </select></div>
      <div class="st-row"><label>阴影</label>
        <input type="checkbox" id="st-shadow" ${this.world.quality.shadows ? 'checked' : ''}></div>
      <div class="st-row"><label>自动降档保帧率</label>
        <input type="checkbox" id="st-auto" ${this.world.autoQuality ? 'checked' : ''}></div>
      <div class="st-row"><label>显示 FPS / 渲染信息</label>
        <input type="checkbox" id="st-fps" ${st.showFps ? 'checked' : ''}></div>
      <div class="st-row"><label>面板毛玻璃（更耗性能）</label>
        <input type="checkbox" id="st-frosted" ${st.frosted ? 'checked' : ''}></div>
      <div class="st-note">毛玻璃会让合成器在镜头移动时每帧重新模糊面板区域；关闭后画面
        观感几乎一致，核显笔记本更流畅。</div>
      <div class="st-note">阴影贴图与静态场景无关时不会重复计算；动画播放中可用顶栏「⏩ 加速」
        或 <kbd>F</kbd> 立刻跳到最终局面。</div>
      <div class="st-sec">显示</div>
      <div class="st-row"><label>六角网格线 (G)</label>
        <input type="checkbox" id="st-grid" ${st.grid ? 'checked' : ''}></div>
      <div class="st-row"><label>单位编号 / 血条</label>
        <input type="checkbox" id="st-marks" ${st.unitMarks ? 'checked' : ''}></div>
      <div class="st-fps" id="st-fps-val">FPS: --</div>`;
    document.getElementById('app').appendChild(div);

    $('st-panmode').onchange = (e) => {
      st.panMode = e.target.value;
      this.store.saveSettings();
      this.onSettingsChanged?.();
    };
    $('st-pansens').oninput = (e) => {
      st.panSens = parseFloat(e.target.value);
      $('st-pansens-val').textContent = Number(st.panSens).toFixed(1) + '×';
      this.store.saveSettings();
      this.onSettingsChanged?.();
    };
    $('st-invx').onchange = (e) => {
      st.panInvertX = e.target.checked;
      this.store.saveSettings();
      this.onSettingsChanged?.();
    };
    $('st-invy').onchange = (e) => {
      st.panInvertY = e.target.checked;
      this.store.saveSettings();
      this.onSettingsChanged?.();
    };
    $('st-probe').onchange = (e) => { st.hoverProbe = e.target.checked; this.store.saveSettings(); if (!e.target.checked) this.hideProbe(); };
    $('st-delay').oninput = (e) => {
      st.hoverDelayMs = parseInt(e.target.value, 10);
      $('st-delay-val').textContent = (st.hoverDelayMs / 1000).toFixed(2) + 's';
      this.store.saveSettings();
    };
    $('st-hide').onchange = (e) => {
      st.hideUndetected = e.target.checked;
      this.store.saveSettings();
      this.onSettingsChanged?.();
      this.toast(e.target.checked ? '已开启战争迷雾机制：视野外敌军不可见' : '已关闭战争迷雾机制：全部敌军可见（调试用）');
    };
    $('st-fog').onchange = (e) => {
      st.fogVisual = e.target.checked;
      this.store.saveSettings();
      this.onSettingsChanged?.();
      this.toast(e.target.checked ? '已显示旧版迷雾覆盖与「?」标记' : '已隐藏迷雾覆盖与「?」标记');
    };
    $('st-quality').onchange = (e) => {
      this.world.setQuality(e.target.value);
      $('st-shadow').checked = this.world.quality.shadows;
    };
    $('st-res').onchange = (e) => {
      const mode = e.target.value;
      this.world.setResMode(mode);
      this.store.settings.resMode = mode;
      this.store.saveSettings();
      this.toast(mode === 'auto'
        ? `渲染分辨率：自动（当前 ${Math.round(this.world.renderScale * 100)}%）`
        : `渲染分辨率：${mode}%`);
    };
    $('st-animspeed').onchange = (e) => {
      const v = parseFloat(e.target.value) || 1;
      this.store.settings.animSpeed = v;
      this.store.saveSettings();
      this.net.cmd('animSpeed', { mult: v });
      this.toast(`动画速度：${v}×`);
    };
    $('st-shadow').onchange = (e) => {
      this.world.quality.shadows = e.target.checked;
      this.world.renderer.shadowMap.enabled = e.target.checked;
      this.world.sun.castShadow = e.target.checked;
      this.world.markShadowsDirty();
      this.world.scene.traverse(o => { if (o.isMesh && o.material) o.material.needsUpdate = true; });
    };
    $('st-auto').onchange = (e) => {
      this.world.autoQuality = e.target.checked;
      localStorage.setItem('hw3d.autoQuality', e.target.checked ? '1' : '0');
    };
    $('st-fps').onchange = (e) => { st.showFps = e.target.checked; this.store.saveSettings(); };
    $('st-frosted').onchange = (e) => {
      st.frosted = e.target.checked;
      this.store.saveSettings();
      this.onSettingsChanged?.();
    };
    $('st-grid').onchange = (e) => {
      st.grid = e.target.checked;
      this.store.saveSettings();
      this.onToggleGrid?.(e.target.checked);
    };
    $('st-marks').onchange = (e) => {
      st.unitMarks = e.target.checked;
      this.store.saveSettings();
      this.onSettingsChanged?.();
    };
    setTimeout(() => {
      document.addEventListener('pointerdown', function close(ev) {
        if (!div.contains(ev.target) && ev.target.id !== 'btn-settings') {
          div.remove();
          document.removeEventListener('pointerdown', close);
        }
      });
    }, 0);
  }

  /** 悬停能见度面板：显示该格中隐蔽 0.5/1/2/4 的敌人能否被我方发现。 */
  renderProbe(probe, x, y) {
    const el = this.el.hoverPanel;
    if (!probe) { el.classList.add('hidden'); return; }
    const terr = (probe.terrain && probe.terrain.length) ? probe.terrain.join('、') : '平原';
    const rows = (probe.classes || []).map(c => `<div class="hp-row">
        <span class="hp-c">隐蔽 ${c.conceal}</span>
        <span class="${c.detected ? 'hp-yes' : 'hp-no'}">${c.detected ? '✅ 可发现' : '❌ 不可发现'}</span>
      </div>`).join('');
    el.innerHTML = `<div class="hp-head"><span class="hp-coord">格 ${probe.label}</span>
        <span class="hp-terr">${terr}${probe.smoke ? ` · 烟雾（剩 ${probe.smoke} 回合）` : ''}</span></div>
      <div class="hp-sec">该格敌人能否被发现</div>
      ${rows || '<div class="hp-det">暂无可用于侦察的己方单位</div>'}
      ${probe.smokeDoubles ? '<div class="hp-note">烟雾：地面单位隐蔽 ×2</div>' : ''}`;
    el.classList.remove('hidden');
    const w = el.offsetWidth || 292, h = el.offsetHeight || 150;
    el.style.left = Math.max(6, Math.min(window.innerWidth - w - 8, x + 16)) + 'px';
    el.style.top = Math.max(6, Math.min(window.innerHeight - h - 8, y + 14)) + 'px';
  }

  hideProbe() { this.el.hoverPanel.classList.add('hidden'); }

  toggleMapMenu() {
    const existing = $('map-menu');
    if (existing) { existing.remove(); return; }
    const div = document.createElement('div');
    div.id = 'map-menu';
    const lv = this.store.state?.level?.key || 'open';
    div.innerHTML = `<h4>加载地图 / 新对局</h4>
      ${this.store.levels.map(l => `<button class="mm-item${lv === l.key ? ' active' : ''}" data-level="${l.key}">
        <b>${l.name}</b><div class="mm-desc">${l.desc}</div></button>`).join('')}
      <div class="mm-sec">自定义地图（maps/ 目录）</div>
      ${this.store.maps.length ? this.store.maps.map(m =>
      `<button class="mm-item${lv === 'custom' && this.store.state?.level?.mapName === m.name ? ' active' : ''}" data-file="${m.file}">${m.name}</button>`).join('')
      : '<div class="mm-desc">未发现自定义地图</div>'}
      <div class="mm-sec">存档</div>
      <div class="qm-row"><button class="btn small" id="mm-save">💾 保存当前对局</button></div>
      ${this.store.saves.length ? this.store.saves.map(s =>
        `<button class="mm-item" data-save="${s.file}">📂 ${s.name}</button>`).join('')
      : '<div class="mm-desc">暂无存档</div>'}`;
    document.getElementById('app').appendChild(div);
    div.querySelectorAll('[data-level]').forEach(b => {
      b.onclick = () => { this.net.cmd('newGame', { level: b.dataset.level }); div.remove(); };
    });
    div.querySelectorAll('[data-file]').forEach(b => {
      b.onclick = () => { this.net.cmd('newGame', { level: 'custom', file: b.dataset.file }); div.remove(); };
    });
    div.querySelectorAll('[data-save]').forEach(b => {
      b.onclick = () => { this.net.cmd('loadSave', { file: b.dataset.save }); div.remove(); };
    });
    $('mm-save').onclick = () => { this.net.cmd('save'); div.remove(); };
    setTimeout(() => {
      document.addEventListener('pointerdown', function close(ev) {
        if (!div.contains(ev.target) && ev.target.id !== 'btn-map') {
          div.remove();
          document.removeEventListener('pointerdown', close);
        }
      });
    }, 0);
  }

  /* ---------------- 消息 / 日志 ---------------- */
  toast(text, kind = '') {
    const el = document.createElement('div');
    el.className = 'toast ' + kind;
    el.textContent = text;
    this.el.toasts.appendChild(el);
    setTimeout(() => el.classList.add('fade'), 3200);
    setTimeout(() => el.remove(), 3800);
    while (this.el.toasts.children.length > 6) this.el.toasts.firstChild.remove();
  }

  pushLog(lines) {
    const box = this.el.logLines;
    const atBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 20;
    for (const l of lines) {
      const div = document.createElement('div');
      div.textContent = l.text;
      div.style.color = logColor(l.text);
      box.appendChild(div);
      if (/^⚠/.test(l.text)) this.toast(l.text, 'err');
      else if (/击毁|摧毁|阵亡|占领|胜利|失败/.test(l.text)) this.toast(l.text, 'kill');
    }
    while (box.children.length > 400) box.firstChild.remove();
    if (atBottom) this.scrollLog();
  }

  updateFps(fps, perf = null) {
    const extra = perf
      ? `　${perf.frameMs.toFixed(1)}ms　${Math.round(perf.scale * 100)}%　${perf.calls} draw`
      : '';
    const el = $('st-fps-val');
    if (el) el.textContent = `FPS: ${fps.toFixed(0)}${extra}`;
    const s = this.store.settings;
    const ind = document.getElementById('fps-indicator');
    if (s.showFps) {
      if (!ind) {
        const d = document.createElement('div');
        d.id = 'fps-indicator';
        d.style.cssText = 'position:absolute;top:calc(var(--topbar-h) + 6px);left:50%;transform:translateX(-50%);z-index:18;'
          + 'font:11px monospace;color:#cfe0c8;background:rgba(12,16,12,0.7);padding:1px 6px;border-radius:3px;pointer-events:none';
        document.getElementById('app').appendChild(d);
      }
      document.getElementById('fps-indicator').textContent = `${fps.toFixed(0)} FPS${extra}`;
    } else if (ind) {
      ind.remove();
    }
  }

  scrollLog() {
    const box = this.el.logLines;
    box.scrollTop = box.scrollHeight;
  }

  /* ---------------- 帮助 ---------------- */
  buildHelp() {
    const rows = [...this.store.kinds.values()].filter(k => k.recruitable).map(k =>
      `<tr><td>${k.name}</td><td>${k.recruit}</td><td>${k.range}</td><td>${k.armor}</td><td>${k.attack}</td><td>${k.hit}%</td><td>${k.hp}</td><td>${k.actions}</td><td>${k.move}</td><td>${k.vision}</td><td>${k.ammo}</td></tr>`).join('');
    this.el.helpBody.innerHTML = `
      <h3>目标</h3>
      <p>《文明》式 3D 视角的六边形回合制战术对战：指挥蓝方部队，通过占领全部关键据点（⚑）或歼灭敌人取胜。
      双方棋子一律用**数字编号**：蓝方 1、2、3…，红方 1、2、3…（由阵营底色区分）。</p>
      <h3>镜头</h3>
      <p><b>左键拖动</b>（或右键拖动 / 方向键）平移　<kbd>中键拖动</kbd>／<kbd>Q</kbd><kbd>E</kbd>／<kbd>Shift</kbd>+左键拖动 旋转　
      <kbd>滚轮</kbd> 缩放（以光标为中心）　<kbd>[</kbd><kbd>]</kbd> 俯仰　<kbd>空格</kbd> 对焦选中棋子　双击地图 以该点为中心</p>
      <p>镜头只用鼠标操作，不再占用 WASD（<kbd>S</kbd>=补给/<kbd>A</kbd>=Stinger/<kbd>D</kbd>=追加部署 等快捷键不受影响）。
      拖动方向（内容跟随 / 镜头跟随）、灵敏度与分轴反向可在 <b>⚙ 设置 → 镜头</b> 中调整。</p>
      <h3>操作</h3>
      <p>左键点击己方棋子选中（直接点战场上的棋子模型、左下／右下列表都行）；点绿色格子移动；点红色高亮敌人攻击；右键/Esc 取消选择。</p>
      <p>左上「招募」栏：展开即进入招募；<b>收起即等于确认</b>——招募/追加部署阶段收起＝完成招募，开局部署阶段收起＝开始战斗。</p>
      <p><kbd>T</kbd> 炮兵行动/射击模式　<kbd>M</kbd> 副武器　<kbd>A</kbd> Stinger　<kbd>X</kbd> 装载/登机　<kbd>S</kbd> 补给/结束该单位行动　
      <kbd>H</kbd> 大本营补给　<kbd>U</kbd> 同时攻击　<kbd>C</kbd> 结算齐射　<kbd>D</kbd> 追加部署　<kbd>F3</kbd> 试验放置　
      <kbd>R</kbd> 测距器　<kbd>Tab</kbd> 循环选择　<kbd>Enter</kbd> 结束回合　<kbd>G</kbd> 网格线　<kbd>F</kbd> 跳过动画　<kbd>F1</kbd> 本帮助</p>
      <p>「⏩ 加速」按钮（或 <kbd>F</kbd>）可跳过正在播放的动画直接进入最终局面；AI 回合的播放速度
      可在 <b>⚙ 设置 → 画质与性能 → 动画速度</b> 里整体调快。渲染分辨率与画质档位也在同一处。</p>
      <h3>地形</h3>
      <p>▲ 岩石：阻挡移动/视线，仅空中单位可越过。♣ 森林：移动 2 点、被命中×0.8、削弱视野。▣ 楼房：仅步兵可进入、被命中×0.6、阻挡视线。
      ≈ 水域：陆军不可进入。▬ 道路：车辆每格 0.5 行动力。</p>
      <h3>单位属性表</h3>
      <table><tr><th>单位</th><th>费用</th><th>射程</th><th>护甲</th><th>攻击</th><th>命中</th><th>血</th><th>行动</th><th>移动</th><th>视野</th><th>弹药</th></tr>${rows}</table>
      <h3>提示</h3>
      <p>榴弹炮/重机枪手需先「架设」才能开火，移动后需重新架设；运输单位可搭载步兵，运载直升机在自身格上下机；
      补给单位每回合可为半径 2 格内友军补满弹药；持续部署模式下每回合获得点数，可在大本营周围追加部署。</p>`;
  }
}

function kindIcon(k) {
  if (k.air) return '🚁';
  if (k.foot) return '🪖';
  if (k.token.includes('howitzer') || k.token.includes('mortar')) return '💥';
  if (k.token.includes('supply')) return '📦';
  if (k.token.includes('truck')) return '🚚';
  if (k.token.includes('aa')) return '🎯';
  if (k.armor >= 3) return '🛡';
  return '🚙';
}

function logColor(text) {
  if (text.includes('——')) return '#d8c494';
  if (/^⚠/.test(text)) return '#ffbe5a';
  if (/击毁|消灭|胜利|失败|摧毁/.test(text)) return '#ff7864';
  if (/命中|炮击|攻击/.test(text)) return '#f0a06e';
  if (/移动|搭载|下车|载入|放下/.test(text)) return '#a0d2aa';
  if (/模式/.test(text)) return '#f0dc8c';
  return '#c6cec6';
}

export { logColor };
