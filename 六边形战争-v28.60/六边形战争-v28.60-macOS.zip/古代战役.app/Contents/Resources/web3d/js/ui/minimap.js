/**
 * 右上角缩略地图：整张地图的地形俯视 + 迷雾 + 据点 + 双方单位，
 * 并用**线条框**标出当前 3D 视角覆盖的战场范围（相机视锥在地面的投影）。
 * 点击 / 拖动缩略地图可直接把镜头移动到该处。
 */

import { offsetToWorld, T } from '../core/hex.js';

export class Minimap {
  constructor(canvas, store, world, camera, onJump) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.store = store;
    this.world = world;
    this.camera = camera;
    this.onJump = onJump;
    this.terrainCache = null;
    this.lastKey = '';
    this.bind();
  }

  bind() {
    const jump = (ev) => {
      const rect = this.canvas.getBoundingClientRect();
      const nx = (ev.clientX - rect.left) / rect.width;
      const ny = (ev.clientY - rect.top) / rect.height;
      const c = nx * this.store.cols;
      const r = ny * this.store.rows;
      const w = offsetToWorld(Math.floor(c), Math.floor(r));
      this.camera.focus(w.x, w.z, null);
    };
    let dragging = false;
    this.canvas.addEventListener('pointerdown', (e) => { dragging = true; jump(e); this.canvas.setPointerCapture(e.pointerId); });
    this.canvas.addEventListener('pointermove', (e) => { if (dragging) jump(e); });
    this.canvas.addEventListener('pointerup', (e) => { dragging = false; this.canvas.releasePointerCapture(e.pointerId); });
  }

  /** 地形底图只画一次（按尺寸缓存到离屏 canvas）。 */
  buildTerrain() {
    const { cols, rows } = this.store;
    const W = this.canvas.width, H = this.canvas.height;
    const off = document.createElement('canvas');
    off.width = W; off.height = H;
    const ctx = off.getContext('2d');
    const cw = W / cols, ch = H / rows;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const m = this.store.mask(c, r);
        let col = '#3b4a2c';
        if (m & T.WATER) col = '#1d4a6e';
        else if (m & T.ROCK) col = '#6e6a60';
        else if (m & T.BUILDING) col = '#7a6a52';
        else if (m & T.FOREST) col = '#2f4a2c';
        else if (m & T.ROAD) col = '#5a5650';
        ctx.fillStyle = col;
        const x = c * cw + (r % 2 ? cw * 0.5 : 0);
        ctx.fillRect(x, r * ch, cw + 0.6, ch + 0.6);
      }
    }
    this.terrainCache = off;
  }

  draw(state, time, fogVisual = false, hideUndetected = true) {
    const { cols, rows } = this.store;
    if (!cols) return;
    const key = cols + 'x' + rows + ':' + this.store.seed;
    if (this.lastKey !== key || !this.terrainCache) {
      this.buildTerrain();
      this.lastKey = key;
    }
    const ctx = this.ctx;
    const W = this.canvas.width, H = this.canvas.height;
    ctx.clearRect(0, 0, W, H);
    ctx.drawImage(this.terrainCache, 0, 0);
    const cw = W / cols, ch = H / rows;
    const px = (col, row) => [col * cw + (row % 2 ? cw * 0.5 : 0) + cw / 2, row * ch + ch / 2];

    // 迷雾
    const fogOn = !!fogVisual && state && !state.deploying && !state.testMode;
    const revealed = new Set((fogOn ? state.fog?.revealed || [] : []).map(h => h[0] + ',' + h[1]));
    const dims = new Set((fogOn ? state.fog?.dims || [] : []).map(d => d.h[0] + ',' + d.h[1]));
    if (fogOn) {
      ctx.fillStyle = 'rgba(10,14,12,0.86)';
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if (!revealed.has(c + ',' + r)) {
            const [x, y] = px(c, r);
            ctx.fillRect(x - cw / 2, y - ch / 2, cw + 0.5, ch + 0.5);
          }
        }
      }
      ctx.fillStyle = 'rgba(120,128,124,0.32)';
      for (const d of state?.fog?.dims || []) {
        const [x, y] = px(d.h[0], d.h[1]);
        ctx.fillRect(x - cw / 2, y - ch / 2, cw + 0.5, ch + 0.5);
      }
    }

    // 据点
    for (const kp of state?.keypoints || []) {
      const [x, y] = px(kp.h[0], kp.h[1]);
      ctx.fillStyle = kp.controller === 'blue' ? '#4a86f0' : '#ec5a4a';
      ctx.beginPath();
      ctx.arc(x, y, kp.center ? 3.4 : 2.6, 0, Math.PI * 2);
      ctx.fill();
      if (kp.center) {
        ctx.strokeStyle = '#f0f0e0';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    // 单位：视野外的敌人不画（战争迷雾机制；试验模式全显）
    const hide = hideUndetected && !state?.testMode;
    for (const u of state?.units || []) {
      if (hide && u.team === 'red' && u.visible === false) continue;
      const [x, y] = px(u.h[0], u.h[1]);
      if (u.ghost) {
        ctx.fillStyle = 'rgba(180,180,180,0.55)';
        ctx.beginPath();
        ctx.arc(x, y, 1.7, 0, Math.PI * 2);
        ctx.fill();
        continue;
      }
      const own = u.team === 'blue';
      ctx.fillStyle = own ? (u.air ? '#9fd8ff' : '#5aa8e0') : (u.air ? '#ffb0a0' : '#e05a48');
      const s = u.air ? 2.6 : 2.2;
      ctx.beginPath();
      if (u.air) {
        ctx.moveTo(x, y - s); ctx.lineTo(x + s, y + s); ctx.lineTo(x - s, y + s);
        ctx.closePath();
      } else {
        ctx.rect(x - s, y - s, s * 2, s * 2);
      }
      ctx.fill();
      if (u.label && u.label !== '?') {
        ctx.fillStyle = '#0d100d';
        ctx.font = 'bold 7px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(u.label), x, y + 0.5);
      }
    }

    // 单位：默认全部显示（无迷雾视觉）；开启迷雾时只显示视野内敌人
    // 视野框：**相机视锥在地面的投影**（世界坐标到缩略图是线性映射，直接换算）
    const pts = this.camera.footprint(0);
    if (pts.length === 4) {
      ctx.save();
      ctx.strokeStyle = 'rgba(245,238,190,0.98)';
      ctx.lineWidth = 1.8;
      ctx.shadowColor = 'rgba(0,0,0,0.85)';
      ctx.shadowBlur = 3;
      ctx.beginPath();
      pts.forEach((p, i) => {
        const x = (p.x / (Math.sqrt(3) * 6)) * cw + cw * 0.5;
        const y = (p.z / (1.5 * 6)) * ch + ch * 0.5;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.stroke();
      // 中心十字
      ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(245,238,190,0.9)';
      const cx = this.camera.target.x / (Math.sqrt(3) * 6) * cw + cw * 0.5;
      const cy = this.camera.target.z / (1.5 * 6) * ch + ch * 0.5;
      ctx.fillRect(cx - 1.5, cy - 1.5, 3, 3);
      ctx.restore();
    }
  }
}
