/**
 * 3D 前端主程序：装配世界 / 状态 / 网络 / UI，并驱动渲染与输入。
 */

import * as THREE from '../vendor/three/three.module.js';
import { World, loadQualityKey } from './world/scene.js';
import { Terrain } from './world/terrain.js';
import { UnitLayer } from './world/units.js';
import { Animator } from './world/anim.js';
import { Picker } from './world/picker.js';
import { RtsCamera } from './world/camera.js';
import { Store } from './core/store.js';
import { Net } from './core/net.js';
import { Hud } from './ui/hud.js';
import { Minimap } from './ui/minimap.js';
import { offsetToWorld } from './core/hex.js';

const canvas = document.getElementById('scene');
const world = new World(canvas, loadQualityKey());
const store = new Store();
const net = new Net();
const camera = new RtsCamera(world, canvas);

let terrain = null, units = null, anim = null, picker = null, hud = null, minimap = null;
let ready = false;
let hoverHex = null;
let lastHoverPick = 0;
let hoverSince = 0;          // 当前格开始悬停的时刻（ms）
let hoverProbeSent = null;   // 已请求过探测的格（"col,row"）
let hoverProbeAt = { x: 0, y: 0 };
let lastClickDebug = null;
let lastMinimap = 0;
let selectedView = null;

function setLoading(msg, done = false) {
  const el = document.getElementById('loading');
  const m = document.getElementById('load-msg');
  if (m) m.textContent = msg;
  if (done) el.classList.add('done');
}

/* ------------------------------------------------------------------ */
/* 初始化                                                              */
/* ------------------------------------------------------------------ */
/** 依据 store 里的地图数据重建 3D 世界（首次加载与换图都走这里）。 */
function setupWorld() {
  if (anim) anim.reset();
  if (terrain) terrain.dispose();
  if (units) {
    // 旧单位层：移除 3D 组，并清掉它的 HTML 标记（否则换图后会残留上一张地图的编号/血条）
    units.group.traverse(o => { if (o.geometry) o.geometry.dispose?.(); });
    if (units.material) units.material.dispose?.();
    world.scene.remove(units.group);
  }
  document.getElementById('unit-overlay').innerHTML = '';
  document.getElementById('float-layer').innerHTML = '';
  if (minimap) {
    minimap.terrainCache = null;
    minimap.lastKey = '';
  }
  terrain = new Terrain(world, store);
  units = new UnitLayer(world, terrain, store, document.getElementById('unit-overlay'));
  anim = new Animator(world, terrain, units, store, document.getElementById('float-layer'));
  picker = new Picker(world, terrain, units, store);
  world.setMapBounds(store.cols, store.rows);
  camera.setBounds(store.cols, store.rows);
  if (hud) {
    hud.units = units;
    hud.anim = anim;
    hud.onToggleGrid = (v) => terrain.setGridVisible(v);
  }
  if (minimap) minimap.store = store;
}

/** 相机取景到整张地图。 */
function fitWholeMap(instant = true) {
  const w = Math.sqrt(3) * 6 * store.cols;
  const d = 1.5 * 6 * store.rows;
  camera.desiredPitch = camera.pitch = 0.78;
  camera.focus(w / 2 - Math.sqrt(3) * 3, d / 2 - 9, Math.max(w, d) * 0.72, instant);
}

net.on('init', (msg) => {
  setLoading('正在生成地形与单位模型…');
  store.applyInit(msg);
  setupWorld();
  fitWholeMap(true);
  if (!hud) {
    hud = new Hud({
      store, net, world, camera, units, anim,
      onFocusUnit: (u) => focusUnit(u),
    });
    hud.onToggleGrid = (v) => terrain.setGridVisible(v);
    minimap = new Minimap(document.getElementById('minimap'), store, world, camera, null);
    bindInput();
  }
  const settings = store.loadSettings();
  camera.panMode = settings.panMode === 'camera' ? 'camera' : 'grab';
  camera.panSens = Number(settings.panSens) || 1;
  camera.invertX = !!settings.panInvertX;
  camera.invertY = !!settings.panInvertY;
  world.setResMode(settings.resMode || 'auto');
  document.body.classList.toggle('frosted', !!settings.frosted);
  terrain.setGridVisible(!!settings.grid);
  terrain.updateHighlights(store.state, settings.fogVisual);
  // 持久化的动画速度同步给后端（影响 AI 播放窗口与输入屏蔽时长）
  net.cmd('animSpeed', { mult: Number(settings.animSpeed) || 1 });
  terrain.updateKeypoints(store.state?.keypoints);
  terrain.updateSmoke(store.state?.smoke, performance.now() / 1000);
  units.sync(store.state, null, settings.unitMarks, settings.hideUndetected);
  if (settings.fogVisual) units.syncGhosts(store.state?.ghosts); else units.syncGhosts([]);
  hud.onSettingsChanged = () => applySettings();
  hud.render(store.state);
  hud.pushLog(msg.log || []);
  ready = true;
  setLoading('', true);
  window.__HW3D_READY__ = true;
});

/**
 * 状态更新不直接在 WebSocket 回调里处理，而是**攒到渲染循环帧内统一处理**：
 *  - 回调可能在帧中间任意时刻触发，会让某一帧的 JS 时间突然变长（"操作卡一下"）；
 *  - AI 回合里消息以 25Hz 到达，同一帧可能来好几条，合并后只做一次重建。
 * 事件（动画磁带）按到达顺序拼接，状态/日志取最新的即可。
 */
let pendingUpdate = null;
const pendingEvents = [];

net.on('update', (msg) => {
  if (!ready) return;
  const prev = pendingUpdate;
  const merged = { ...(prev || {}), ...msg, events: null };
  if (prev) {
    // 合并多条消息：地图数据、增量日志、战报必须保留（不能只留最后一条）
    if (!(msg.map && typeof msg.map === 'object') && prev.map) merged.map = prev.map;
    if (prev.log?.length) merged.log = msg.log?.length ? [...prev.log, ...msg.log] : prev.log;
    if (prev.battleEvents?.length) {
      merged.battleEvents = msg.battleEvents?.length ? [...prev.battleEvents, ...msg.battleEvents] : prev.battleEvents;
    }
  }
  pendingUpdate = merged;
  if (msg.events && msg.events.length) pendingEvents.push(...msg.events);
});

/** 帧内处理攒下来的状态更新（返回是否有更新）。 */
function flushUpdate() {
  if (!pendingUpdate) return false;
  const msg = pendingUpdate;
  const events = pendingEvents.length ? pendingEvents.slice() : (msg.events || []);
  pendingUpdate = null;
  pendingEvents.length = 0;
  applyUpdateMsg(msg, events);
  return true;
}

function applyUpdateMsg(msg, events) {
  // 换图：后端在 update 里带上了新的地图数据 → 重建地形/单位层/缩略图
  const mapChanged = !!msg.map && typeof msg.map === 'object';
  if (mapChanged) {
    store.applyMap(msg.map);
    setupWorld();
    fitWholeMap(true);
    hud.toast(`已加载地图：${msg.map.level?.mapName || msg.map.level?.name || ''}`, 'good');
  }
  const state = msg.state;
  // 正在进行移动动画的单位：本帧不要被状态快照拽到终点
  const hold = new Set(events.filter(e => e.k === 'move').map(e => e.team + ':' + e.label));
  store.applyUpdate(msg);
  units.sync(state, hold, store.settings.unitMarks, store.settings.hideUndetected);
  units.syncGhosts(store.settings.fogVisual ? state.ghosts : []);
  terrain.updateHighlights(state, store.settings.fogVisual);
  terrain.updateKeypoints(state.keypoints);
  terrain.updateSmoke(state.smoke, performance.now() / 1000);
  anim.refreshSmokers(state);
  anim.enqueue(events, msg.eventScale || 1);
  hud.render(state);
  if (state.over) hud.el.gameover.classList.remove('hidden');
}

let pendingProbe = null;
let pendingProbeSet = false;
net.on('probe', (data) => { pendingProbe = data; pendingProbeSet = true; });

function flushProbe() {
  if (!pendingProbeSet) return;
  const data = pendingProbe;
  pendingProbeSet = false;
  if (!ready) return;
  store.probe = data;
  if (!data) { hud.hideProbe(); return; }
  // 只在鼠标仍停在同一格、且延迟设置仍开启时显示
  if (!store.settings.hoverProbe) return;
  if (!hoverHex) return;
  if (data.h[0] !== hoverHex.col || data.h[1] !== hoverHex.row) return;
  const r = canvas.getBoundingClientRect();
  hud.renderProbe(data, hoverProbeAt.x - r.left, hoverProbeAt.y - r.top);
}

net.on('open', () => {
  setLoading('已连接，等待初始化…');
});
net.on('close', () => {
  if (ready) hud?.toast('与后端的连接已断开，正在重连…', 'err');
});

/* ------------------------------------------------------------------ */
/* 输入                                                                */
/* ------------------------------------------------------------------ */
function bindInput() {
  let down = null;
  canvas.addEventListener('pointerdown', (e) => {
    if (e.button === 0) down = { x: e.clientX, y: e.clientY, t: performance.now() };
  });
  canvas.addEventListener('pointerup', (e) => {
    if (e.button !== 0 || !down) return;
    const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y);
    const elapsed = performance.now() - down.t;
    down = null;
    // 左键拖动 = 平移镜头（不算点击）；长按也不算点击
    lastClickDebug = { moved: +moved.toFixed(1), elapsed: +elapsed.toFixed(0), dragged: !!camera.dragged };
    if (camera.dragged || moved > 6 || elapsed > 700) return;
    if (!ready) return;
    const hit = picker.pick(e);
    lastClickDebug.hit = hit ? [hit.hex.col, hit.hex.row] : null;
    if (!hit) return;
    net.click(hit.hex, hit.upper);
  });
  canvas.addEventListener('dblclick', (e) => {
    if (!ready) return;
    const hit = picker.pick(e);
    if (!hit) return;
    const w = offsetToWorld(hit.hex.col, hit.hex.row);
    camera.focus(w.x, w.z, null);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!ready) return;
    // 正在拖动/旋转镜头：跳过悬停拾取与提示更新（拖动时它既没用又要花时间）
    if (camera.dragged || camera._drag) {
      if (hoverHex) { hoverHex = null; hoverProbeSent = null; hud?.hideProbe(); document.getElementById('hover-hex')?.classList.add('hidden'); document.getElementById('tooltip')?.classList.add('hidden'); }
      return;
    }
    const now = performance.now();
    if (now - lastHoverPick < 60) return;
    lastHoverPick = now;
    const hit = picker.pick(e);
    const prevKey = hoverHex ? hoverHex.col + ',' + hoverHex.row : null;
    hoverHex = hit ? hit.hex : null;
    const key = hoverHex ? hoverHex.col + ',' + hoverHex.row : null;
    if (key !== prevKey) {
      hoverSince = now;
      hoverProbeSent = null;
      hud?.hideProbe();
    }
    hoverProbeAt = { x: e.clientX, y: e.clientY };

    const hx = document.getElementById('hover-hex');
    if (hoverHex) {
      hx.classList.remove('hidden');
      hx.textContent = `${hoverHex.col + 1},${hoverHex.row + 1}`;
      hx.style.left = (e.clientX + 14) + 'px';
      hx.style.top = (e.clientY + 16) + 'px';
      const u0 = store.unitAt(hoverHex.col, hoverHex.row);
      // 战争迷雾机制：未侦察到的敌方棋子不显示任何信息（悬停也不例外）
      const u = (u0 && u0.team === 'red' && u0.visible === false && store.settings.hideUndetected)
        ? null : u0;
      const tooltip = document.getElementById('tooltip');
      if (u) {
        const k = store.kind(u.kind);
        tooltip.classList.remove('hidden');
        tooltip.innerHTML = `<b>${u.team === 'blue' ? '我方' : '敌方'} ${u.label} · ${k?.name || u.kind}</b><br>
          生命 ${u.hp}/${u.maxHp}　行动 ${u.actions ?? '-'}/${u.maxActions ?? '-'}<br>
          ${u.team === 'blue' ? `射程 ${u.effRange ?? k?.range}　攻击 ${u.effAttack ?? k?.attack}　命中 ${u.effHit ?? k?.hit}%<br>
          弹药 ${u.aaMode ? u.aaAmmo : (u.missileMode ? u.missileAmmo : u.ammo)}　${u.modeName || ''}` : '（敌方单位：仅基本属性）'}
          ${u.passengers?.length ? `<br>搭载：${u.passengers.map(p => store.kindName(p.kind) + p.label).join('、')}` : ''}`;
        tooltip.style.left = Math.min(window.innerWidth - 320, e.clientX + 18) + 'px';
        tooltip.style.top = (e.clientY + 30) + 'px';
      } else {
        tooltip.classList.add('hidden');
      }
    } else {
      hx.classList.add('hidden');
      document.getElementById('tooltip').classList.add('hidden');
    }
  });
  canvas.addEventListener('pointerleave', () => {
    document.getElementById('hover-hex').classList.add('hidden');
    document.getElementById('tooltip').classList.add('hidden');
    hud?.hideProbe();
    hoverHex = null;
    hoverProbeSent = null;
  });

  // 键盘
  window.addEventListener('keydown', (e) => {
    if (!ready) return;
    if (e.target && /input|select|textarea/i.test(e.target.tagName)) return;
    const k = e.code;
    const st = store.state;
    const modalOpen = !document.getElementById('help').classList.contains('hidden');
    if (k === 'F1') { hud.toggleHelp(modalOpen ? false : true); e.preventDefault(); return; }
    if (modalOpen) {
      if (k === 'Escape') hud.toggleHelp(false);
      return;
    }
    switch (k) {
      case 'Escape': net.cmd('cancelLayer'); break;
      case 'Enter': if (!st?.modes?.simul) hud.endTurn(); break;
      case 'KeyT': net.cmd('toggleHowitzer'); break;
      case 'KeyM': net.cmd('toggleAmmo', { which: 'missile' }); break;
      case 'KeyA': net.cmd('toggleAmmo', { which: 'aa' }); break;
      case 'KeyU': net.cmd('toggleSimul'); break;
      case 'KeyC': if (st?.modes?.simul) net.cmd('confirmSimul'); break;
      case 'KeyD': net.cmd('toggleSustainDeploy'); break;
      case 'KeyS': {
        const u = store.selectedUnit;
        const kk = u ? store.kind(u.kind) : null;
        if (u && kk && u.kind === 'supply') net.cmd('toggleSupply');
        else if (u && u.team === 'blue') net.cmd('passUnit');
        break;
      }
      case 'KeyH': net.cmd('hqResupply'); break;
      case 'KeyX': {
        const u = store.selectedUnit;
        const kk = u ? store.kind(u.kind) : null;
        if (u && kk && kk.air && kk.capacity > 0) net.cmd('heliBoard');
        else net.cmd('toggleLoad');
        break;
      }
      case 'KeyR': net.cmd('ranger'); break;
      case 'KeyG': {
        const g = !terrain.gridLines.visible;
        store.settings.grid = g;
        store.saveSettings();
        terrain.setGridVisible(g);
        break;
      }
      case 'KeyL': hud.toggleLog(); break;
      case 'Tab': net.cmd('cycleUnit', { reverse: e.shiftKey }); e.preventDefault(); break;
      case 'F3': net.cmd('toggleTestPlacing'); break;
      case 'KeyF': hud.fastForward(); break;
      case 'Space': {
        const u = store.selectedUnit;
        if (u) focusUnit(u);
        e.preventDefault();
        break;
      }
      default: break;
    }
  });
}

/** 设置变化后立刻生效（迷雾 / 单位标记 / 网格）。 */
function applySettings() {
  const st = store.settings;
  // 镜头拖动行为（方向 / 灵敏度 / 分轴反向）
  camera.panMode = st.panMode === 'camera' ? 'camera' : 'grab';
  camera.panSens = Number(st.panSens) || 1;
  camera.invertX = !!st.panInvertX;
  camera.invertY = !!st.panInvertY;
  world.setResMode(st.resMode || 'auto');
  document.body.classList.toggle('frosted', !!st.frosted);   // 面板毛玻璃（默认关）
  if (!terrain) return;
  terrain.setGridVisible(!!st.grid);
  terrain.updateHighlights(store.state, st.fogVisual);
  units.sync(store.state, null, st.unitMarks, st.hideUndetected);
  units.syncGhosts(st.fogVisual ? store.state?.ghosts : []);
  hud.render(store.state);   // 列表标题/内容随设置（是否隐藏视野外敌军）刷新
  if (!st.fogVisual) hud.hideProbe();
  minimap.draw(store.state, performance.now() / 1000, st.fogVisual, st.hideUndetected);
  if (st.fogVisual && st.hoverProbe && hoverHex && hoverProbeSent) net.probe(hoverHex);
}

function focusUnit(u) {
  const w = offsetToWorld(u.h[0], u.h[1]);
  camera.focus(w.x, w.z, u.air ? 46 : 40);
}

/* ------------------------------------------------------------------ */
/* 渲染循环                                                            */
/* ------------------------------------------------------------------ */
let last = performance.now();
let fpsAcc = 0, fpsCount = 0, fpsTimer = 0, fps = 60, lowStreak = 0;

function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  const time = now / 1000;
  camera.update(dt);
  world.update(dt);
  // 悬停达到设定延迟（0.1~0.5s，默认 0.2s）后请求该格的能见度探测
  if (ready && hoverHex && store.settings.hoverProbe && !camera.dragged && !camera._drag) {
    const key = hoverHex.col + ',' + hoverHex.row;
    if (key !== hoverProbeSent && now - hoverSince >= store.settings.hoverDelayMs) {
      hoverProbeSent = key;
      net.probe(hoverHex);
    }
  }
  if (!ready) { world.render(); return; }
  // 所有网络消息驱动的重建都在帧内完成（合并同一帧内的多条），避免帧中途插入工作
  flushUpdate();
  flushProbe();
  terrain.update(dt, time);
  anim.update(dt, time);
  units.update(dt, time, world.camera);
  world.render();
  // 缩略地图（10 Hz 足够）
  if (now - lastMinimap > 100) {
    lastMinimap = now;
    minimap.draw(store.state, time, store.settings.fogVisual, store.settings.hideUndetected);
    const sel = store.selectedUnit;
    document.getElementById('mm-coord').textContent = sel
      ? `${sel.label} · ${sel.h[0] + 1},${sel.h[1] + 1}`
      : (hoverHex ? `${hoverHex.col + 1},${hoverHex.row + 1}` : '');
  }
  // FPS / 动态分辨率 / 自动降档
  fpsAcc += dt; fpsCount++;
  if (fpsAcc >= 0.5) {
    fps = fpsCount / fpsAcc;
    fpsAcc = 0; fpsCount = 0;
    // 先让动态分辨率去顶帧率：核显笔记本上这比降画质有效得多，也几乎看不出差别
    world.reportFps(fps);
    hud.updateFps(fps, world.perf);
    // 只有分辨率已在下限、帧率仍然偏低时才降画质档位
    if (world.autoQuality) {
      if (fps < 38 && world.atResFloor) {
        lowStreak++;
        if (lowStreak >= 4) {
          lowStreak = 0;
          const order = ['high', 'medium', 'low'];
          const i = order.indexOf(world.qualityKey);
          if (i >= 0 && i < order.length - 1) {
            world.setQuality(order[i + 1]);
            hud.toast(`帧率偏低（${fps.toFixed(0)} FPS），已自动切换到「${world.quality.name}」画质`, 'err');
          }
        }
      } else {
        lowStreak = 0;
      }
    }
  }
}

setLoading('正在连接游戏后端…');
net.connect();
requestAnimationFrame(frame);

/** 调试/自动化用：把格坐标投影成屏幕坐标（CSS 像素）。 */
function screenOf(col, row, lift = 2) {
  const w = offsetToWorld(col, row);
  const y = (terrain ? terrain.heightAt(col, row) : 0) + lift;
  const p = new THREE.Vector3(w.x, y, w.z).project(world.camera);
  const rect = canvas.getBoundingClientRect();
  return {
    x: rect.left + (p.x * 0.5 + 0.5) * rect.width,
    y: rect.top + (-p.y * 0.5 + 0.5) * rect.height,
  };
}

// 调试入口：便于自动化截图核对
window.__HW3D__ = {
  screenOf,
  lastClick: () => lastClickDebug,
  hoverState: () => ({
    hex: hoverHex, since: hoverSince, sent: hoverProbeSent,
    probe: store.probe ? store.probe.label : null,
    settings: store.settings,
  }),
  get world() { return world; },
  get store() { return store; },
  get camera() { return camera; },
  get units() { return units; },
  get terrain() { return terrain; },
  get anim() { return anim; },
  get net() { return net; },
  get hud() { return hud; },
};
