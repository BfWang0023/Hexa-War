/**
 * 与 Rust 后端的 WebSocket 通信：收状态快照 / 动画事件，发操作命令。
 * 协议见 src/web3d/host.rs（`hello` / `update` / `cmd` ...）。
 */

const RECONNECT_MS = 1200;

export class Net {
  constructor() {
    this.ws = null;
    this.connected = false;
    this.handlers = { init: [], update: [], open: [], close: [], probe: [] };
    this.queue = [];
    this.url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
    this.seq = 0;
    this.latency = 0;
  }

  on(evt, fn) { this.handlers[evt].push(fn); return this; }

  emit(evt, arg) { for (const fn of this.handlers[evt]) fn(arg); }

  connect() {
    try {
      this.ws = new WebSocket(this.url);
    } catch (e) {
      setTimeout(() => this.connect(), RECONNECT_MS);
      return;
    }
    this.ws.onopen = () => {
      this.connected = true;
      this.emit('open');
      this.send({ t: 'hello' });
      for (const msg of this.queue.splice(0)) this.raw(msg);
    };
    this.ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.t === 'init') {
        this.seq = msg.state?.seq ?? 0;
        this.emit('init', msg);
      } else if (msg.t === 'update') {
        this.seq = msg.seq ?? this.seq;
        this.emit('update', msg);
      } else if (msg.t === 'probe') {
        this.emit('probe', msg.data);
      }
    };
    this.ws.onclose = () => {
      this.connected = false;
      this.emit('close');
      setTimeout(() => this.connect(), RECONNECT_MS);
    };
    this.ws.onerror = () => { /* onclose 会处理重连 */ };
  }

  raw(obj) { this.ws.send(JSON.stringify(obj)); }

  send(obj) {
    if (this.connected && this.ws && this.ws.readyState === WebSocket.OPEN) this.raw(obj);
    else { this.queue.push(obj); if (this.queue.length > 60) this.queue.shift(); }
  }

  /** 点击地图格子。`upper` = 该格空中层（直升机）。 */
  click(h, upper, button = 'left') { this.send({ t: 'click', h: [h.col, h.row], upper: !!upper, button }); }

  /** 悬停探测：该格中隐蔽值 0.5/1/2/4 的敌方单位能否被我方发现。 */
  probe(h) { this.send({ t: 'probe', h: h ? [h.col, h.row] : null }); }

  /** 命名命令。 */
  cmd(name, extra = {}) { this.send({ t: 'cmd', name, ...extra }); }
}
