/**
 * 客户端状态仓库：保存后端下发的静态地图信息、兵种表与最新状态快照，
 * 并提供派生索引（按格查单位、按标签查单位…）。UI 与 3D 层都从这里读数据。
 */

import { decodeTerrain, neighbors, axialFromOffset } from './hex.js';

export class Store {
  constructor() {
    this.cols = 0;
    this.rows = 0;
    this.terrain = null;      // Uint8Array(cols*rows)
    this.kinds = new Map();   // token -> 静态属性
    this.levels = [];
    this.maps = [];
    this.saves = [];
    this.seed = 0;
    this.aiVersion = 'legacy';
    this.aiDifficulty = 'regular';

    this.state = null;        // 最近一次状态快照
    this.log = [];            // {seq,team,text}
    this.maxLog = 500;
    this.listeners = { state: [], log: [], static: [], map: [] };

    /** 点击/悬停到的高亮，由 main.js 维护 */
    this.hoverHex = null;
    this.simulTargets = [];
    /** 最近一次悬停探测结果（{t:'probe'} 直回消息） */
    this.probe = null;
    this.probeHex = null;
    /** 界面设置（可在顶栏「设置」中修改，存 localStorage） */
    this.settings = {
      // 战争迷雾「机制」：视野外敌军不显示（默认开启，双方都受此限制）
      hideUndetected: true,
      // 旧版迷雾「视觉」：地形上的黑/灰雾覆盖 + 「?」最后已知位置标记（默认关闭）
      fogVisual: false,
      hoverProbe: true,        // 悬停显示能见度
      hoverDelayMs: 200,       // 悬停触发延迟（0.1~0.5 秒）
      unitMarks: true,         // 单位编号/血条标记
      grid: false,             // 六角网格线
      showFps: false,
      // 镜头拖动行为（⚙ 设置 → 镜头）
      panMode: 'grab',         // 'grab' 内容跟随鼠标 ｜ 'camera' 镜头跟随鼠标
      panSens: 1.0,            // 拖动灵敏度 0.3~3.0
      panInvertX: false,       // 水平反向
      panInvertY: false,       // 垂直反向
      // 性能（⚙ 设置 → 画质与性能）
      resMode: 'auto',         // 渲染分辨率：auto | 100 | 85 | 75
      animSpeed: 1,            // 动画速度倍率 1 / 1.5 / 2 / 3
      frosted: false,          // 面板毛玻璃（backdrop-filter，核显上很贵，默认关）
    };
  }

  loadSettings() {
    try {
      const raw = localStorage.getItem('hw3d.settings');
      if (raw) Object.assign(this.settings, JSON.parse(raw));
    } catch (e) { /* 忽略损坏的设置 */ }
    return this.settings;
  }

  saveSettings() {
    try { localStorage.setItem('hw3d.settings', JSON.stringify(this.settings)); } catch (e) { /* ignore */ }
    this.emit('settings', this.settings);
  }

  on(evt, fn) { (this.listeners[evt] = this.listeners[evt] || []).push(fn); return this; }
  emit(evt, arg) { for (const fn of (this.listeners[evt] || [])) fn(arg); }

  applyInit(msg) {
    this.cols = msg.cols;
    this.rows = msg.rows;
    this.terrain = decodeTerrain(msg.terrain, msg.cols, msg.rows);
    this.kinds = new Map(msg.kinds.map(k => [k.token, k]));
    this.levels = msg.levels || [];
    this.maps = msg.maps || [];
    this.saves = msg.saves || [];
    this.seed = msg.seed;
    this.aiVersion = msg.aiVersion;
    this.aiDifficulty = msg.aiDifficulty;
    this.log = (msg.log || []).slice(-this.maxLog);
    this.state = msg.state;
    this.emit('static', msg);
    this.emit('log', this.log);
    this.emit('state', this.state);
  }

  /** 换图（update 里带 map 字段时调用）：只更新地图相关静态数据。 */
  applyMap(map) {
    this.cols = map.cols;
    this.rows = map.rows;
    this.terrain = decodeTerrain(map.terrain, map.cols, map.rows);
    this.seed = map.seed;
    if (map.kinds) this.kinds = new Map(map.kinds.map(k => [k.token, k]));
    if (map.level) this.levelInfo = map.level;
    this.emit('map', map);
    this.emit('static', map);
  }

  applyUpdate(msg) {
    if (msg.state) {
      this.state = msg.state;
      this.emit('state', this.state);
    }
    if (msg.log && msg.log.length) {
      this.log.push(...msg.log);
      if (this.log.length > this.maxLog) this.log.splice(0, this.log.length - this.maxLog);
      this.emit('log', this.log);
    }
    return msg;
  }

  kind(token) { return this.kinds.get(token) || null; }
  kindName(token) { return this.kinds.get(token)?.name || token; }

  /** 地形掩码。 */
  mask(col, row) {
    if (!this.terrain || col < 0 || row < 0 || col >= this.cols || row >= this.rows) return 0;
    return this.terrain[row * this.cols + col];
  }

  inBounds(col, row) {
    return col >= 0 && row >= 0 && col < this.cols && row < this.rows;
  }

  /** 我方单位（不含幽灵）。 */
  get ownUnits() {
    return (this.state?.units || []).filter(u => u.team === 'blue' && !u.ghost);
  }

  /** 视野内敌军（含试验模式的暗色单位）。 */
  get enemyUnits() {
    return (this.state?.units || []).filter(u => u.team === 'red' && !u.ghost);
  }

  get ghostUnits() {
    return (this.state?.units || []).filter(u => u.ghost);
  }

  unitAt(col, row, air = null) {
    const list = this.state?.units || [];
    let ground = null, airU = null;
    for (const u of list) {
      if (u.ghost || u.h[0] !== col || u.h[1] !== row) continue;
      if (u.air) airU = u; else ground = u;
    }
    if (air === null) return airU || ground;
    return air ? airU : ground;
  }

  unitByLabel(team, label) {
    return (this.state?.units || []).find(u => u.team === team && u.label === String(label) && !u.ghost) || null;
  }

  /** 当前选中的单位对象（若选中格上有单位）。 */
  get selectedUnit() {
    const sel = this.state?.selected;
    if (!sel) return null;
    return this.unitAt(sel.h[0], sel.h[1], !!sel.air);
  }

  get isDeploying() { return !!this.state?.deploying; }
  get isRecruiting() { return !!this.state?.sustainDeploying; }
  get isTestPlacing() { return !!this.state?.testPlacing; }
  get myPoints() { return this.state?.points?.blue ?? 0; }
  get busy() { return !!this.state?.busy; }
  get over() { return !!this.state?.over; }

  /** 高亮集合（后端算好的）。 */
  get highlights() {
    return this.state?.highlights || { reachable: [], attackable: [], blocked: [], howitzer: [], disembark: [], board: [], supply: [] };
  }

  /** 部署 / 招募可放置格集合（Set of "col,row"）。 */
  get deployCellSet() {
    const s = new Set();
    for (const h of this.state?.deployCells || []) s.add(h[0] + ',' + h[1]);
    return s;
  }

  /** 已揭示格（用于迷雾）。 */
  get revealedSet() {
    const s = new Set();
    for (const h of this.state?.fog?.revealed || []) s.add(h[0] + ',' + h[1]);
    return s;
  }

  get dimSet() {
    const s = new Set();
    for (const d of this.state?.fog?.dims || []) s.add(d.h[0] + ',' + d.h[1]);
    return s;
  }

  get keypoints() { return this.state?.keypoints || []; }
  get smoke() { return this.state?.smoke || []; }
  get alarms() { return this.state?.alarms || []; }

  /** 单位所在格的轴向坐标。 */
  axialOf(unit) { return axialFromOffset(unit.h[0], unit.h[1]); }

  /** 相邻格（偏移坐标）。 */
  neighborsOf(col, row) {
    return neighbors(axialFromOffset(col, row)).map(a => {
      const off = { col: a.q + ((a.r - (a.r & 1)) >> 1), row: a.r };
      return off;
    });
  }
}
