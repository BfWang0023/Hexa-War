/**
 * 六边形坐标与地形数据：与 Rust 后端 `hex.rs` / `map.rs` 完全一致的约定。
 *
 * - 后端内部用轴向坐标 (q, r)，网络传输用 **0 基奇数列偏移坐标 [col,row]**。
 * - 布局：**尖顶（pointy-top）**，奇数列向右偏移半格（odd-r）。
 * - 世界坐标（米）：1 格外接圆半径 HEX_R = 6 m（由原 GUI 的像素比例推算），
 *   x = √3·R·(q + r/2)，z = 1.5·R·r。
 *   ⇒ row 越大 z 越大（屏幕下方），col 越大 x 越大（屏幕右方）。
 */

export const HEX_R = 6;
export const SQRT3 = Math.sqrt(3);

/** 地形位掩码（与后端 snapshot.rs 一致）。 */
export const T = {
  ROCK: 1,
  FOREST: 2,
  BUILDING: 4,
  WATER: 8,
  ROAD: 16,
  BRIDGE: 32,
};

export function axialFromOffset(col, row) {
  return { q: col - ((row - (row & 1)) >> 1), r: row };
}

export function offsetFromAxial(q, r) {
  return { col: q + ((r - (r & 1)) >> 1), row: r };
}

/** 轴向坐标 → 世界坐标（米）。 */
export function axialToWorld(q, r) {
  return { x: SQRT3 * HEX_R * (q + r / 2), z: 1.5 * HEX_R * r };
}

export function offsetToWorld(col, row) {
  const a = axialFromOffset(col, row);
  return axialToWorld(a.q, a.r);
}

/** 世界坐标 → 偏移格坐标（立方体取整，含边界）。 */
export function worldToOffset(x, z) {
  const rf = z / (1.5 * HEX_R);
  const qf = x / (SQRT3 * HEX_R) - rf / 2;
  let xf = qf, zf = rf, yf = -qf - rf;
  let rx = Math.round(xf), ry = Math.round(yf), rz = Math.round(zf);
  const dx = Math.abs(rx - xf), dy = Math.abs(ry - yf), dz = Math.abs(rz - zf);
  if (dx > dy && dx > dz) rx = -ry - rz;
  else if (dy > dz) ry = -rx - rz;
  else rz = -rx - ry;
  return offsetFromAxial(rx, rz);
}

export function hexDistance(a, b) {
  const dq = Math.abs(a.q - b.q);
  const dr = Math.abs(a.r - b.r);
  const ds = Math.abs(a.q + a.r - b.q - b.r);
  return (dq + dr + ds) / 2;
}

export const DIRS = [
  [1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1],
];

export function neighbors(h) {
  return DIRS.map(([dq, dr]) => ({ q: h.q + dq, r: h.r + dr }));
}

/** 六边形 6 个顶点（世界坐标，尖顶：角度 30°,90°,…）。 */
export function hexCorners(cx, cz, radius = HEX_R) {
  const out = [];
  for (let i = 0; i < 6; i++) {
    const ang = Math.PI / 6 + i * Math.PI / 3;
    out.push([cx + radius * Math.cos(ang), cz + radius * Math.sin(ang)]);
  }
  return out;
}

/** 解析后端下发的地形行（**每格 2 个十六进制字符** = 位掩码 0..63）。 */
export function decodeTerrain(rows, cols, nRows) {
  // 兼容两种调用：(rows, cols, nRows) 或 (地图行数组, 列数, 行数)
  const lines = Array.isArray(rows) ? rows : [];
  const count = Number(nRows ?? lines.length) || 0;
  const grid = new Uint8Array(Math.max(0, cols * count));
  for (let r = 0; r < count; r++) {
    const line = lines[r] || '';
    // 兼容旧版 1 字符/格 的编码（位掩码 ≥16 会被截断，仅用于容错）
    const wide = line.length >= cols * 2;
    for (let c = 0; c < cols; c++) {
      const ch = wide ? line.substr(c * 2, 2) : (line[c] || '0');
      grid[r * cols + c] = parseInt(ch, 16) || 0;
    }
  }
  return grid;
}

/** 地形备注（与后端 terrain_note 一致的展示顺序）。 */
export function terrainNames(mask) {
  const out = [];
  if (mask & T.FOREST) out.push('森林');
  if (mask & T.BUILDING) out.push('楼房');
  if (mask & T.WATER) out.push('水域');
  if (mask & T.ROAD) out.push('道路');
  if (mask & T.ROCK) out.push('岩石');
  return out;
}

/* -------------------------------------------------------------------------
   地形高度：让相邻地块自然衔接的关键。
   岩石最高（山体），森林/楼房略高，平地基准，水域下沉；
   再用确定性哈希给每格一点起伏，避免「平板棋盘」感。
   ------------------------------------------------------------------------- */
export const H_PLAIN = 0.0;
export const H_FOREST = 0.34;
export const H_BUILDING = 0.12;
export const H_ROCK = 2.35;
// 计算共享棱高时每格高度的上限：只有岩石会超过它。
// 山体因此只在自身格内隆起（格心高、格边落到 ~H_SLOPE_CAP），
// 不会把相邻地块的棱抬高成斜坡（否则岩石周边 6 格的观感会被"污染"）。
export const H_SLOPE_CAP = 0.5;
export const H_WATER = -0.62;        // 水面高度（整片水面网格）
export const H_WATER_BED = -1.55;    // 水底高度（地形网格里水域格的高度）
export const H_ROAD = 0.02;

function hash2(col, row) {
  let h = (col * 73856093) ^ (row * 19349663);
  h = (h ^ (h >>> 13)) >>> 0;
  return (h % 1000) / 1000;
}

/** 每格的地表高度（米）。`grid` 为 decodeTerrain 的结果。 */
export function tileHeight(grid, cols, rows, col, row) {
  if (col < 0 || row < 0 || col >= cols || row >= rows) return H_WATER - 0.3;
  const m = grid[row * cols + col];
  const jitter = (hash2(col, row) - 0.5) * 0.22;
  if (m & T.WATER) return H_WATER_BED;
  if (m & T.ROCK) return H_ROCK + (hash2(col * 7 + 1, row * 3 + 5) - 0.5) * 0.9;
  if (m & T.FOREST) return H_FOREST + jitter * 0.6;
  if (m & T.BUILDING) return H_BUILDING + jitter * 0.3;
  if (m & T.ROAD) return H_ROAD + jitter * 0.25;
  return H_PLAIN + jitter;
}

/** 每格的确定性随机（装饰物摆放用）。 */
export function tileRandom(col, row, salt = 0) {
  return hash2(col * 31 + salt * 977, row * 17 + salt * 131);
}
