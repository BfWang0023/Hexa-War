/**
 * 场景 / 渲染器 / 光照 / 天空 / 画质档位 / 渲染分辨率。
 *
 * 性能取向（目标：无独显的核显笔记本也能流畅）：
 * - 地形合并成极少数 Mesh，装饰物用 InstancedMesh，单位合并为 1~3 个 Mesh；
 * - 不用任何后处理（Bloom/SSAO 等）；
 * - 画质档位控制阴影贴图、像素比、装饰密度与粒子数量；
 * - **阴影贴图按需重算**：太阳与阴影相机都静止，因此只有"会投影的东西真的动了"
 *   （棋子移动/新增、地形重建、画质变化）才需要重画 shadow map；镜头平移或画面静止时
 *   整趟深度 pass 直接跳过——输出像素完全一致；
 * - **动态分辨率**：帧时间超标时按 5% 步长轻降渲染分辨率（下限 75%，上限 = 档位像素比），
 *   帧时间富裕时再升回。核显笔记本上这是最有效也最不容易察觉的一档性能；
 * - **纯色天空**：可见天空区域本来就是近黑（实测 (0,0,1)），去掉全景天空盒后省掉一整趟
 *   全屏绘制，画面几乎逐像素相同；
 * - 运行期自适应：只有分辨率已在 75% 下限、帧率仍长期偏低时才下调画质档位。
 */

import * as THREE from '../../vendor/three/three.module.js';

/** 天空/雾/背景板的统一底色（与旧版全景天空盒的可见部分一致）。 */
export const SKY_COLOR = 0x05070a;

export const QUALITY_PRESETS = {
  low: {
    name: '低',
    shadows: false, shadowMap: 0,
    maxPixelRatio: 1.0, antialias: false,
    decor: 0.45, particles: 0.45, waterAnim: true, unitDetail: 0.75, treeShadows: false,
  },
  medium: {
    name: '中',
    shadows: true, shadowMap: 1024,
    maxPixelRatio: 1.5, antialias: true,
    decor: 0.8, particles: 0.75, waterAnim: true, unitDetail: 1.0, treeShadows: false,
  },
  high: {
    name: '高',
    shadows: true, shadowMap: 2048,
    maxPixelRatio: 2.0, antialias: true,
    decor: 1.0, particles: 1.0, waterAnim: true, unitDetail: 1.0, treeShadows: true,
  },
};

/** 渲染分辨率档位（相对"档位像素比"的缩放；auto = 按帧时间动态调节）。 */
export const RES_SCALES = { auto: null, '100': 1.0, '85': 0.85, '75': 0.75 };
/** 动态分辨率的可调范围与目标帧时间（60FPS 留一点余量）。 */
export const RES_MIN = 0.75;
const RES_TARGET_MS = 17.2;
const RES_FLOOR_MS = 13.2;

export function loadQualityKey() {
  const saved = localStorage.getItem('hw3d.quality');
  return QUALITY_PRESETS[saved] ? saved : 'medium';
}

export class World {
  constructor(canvas, qualityKey) {
    this.canvas = canvas;
    this.qualityKey = qualityKey;
    this.quality = { ...QUALITY_PRESETS[qualityKey] };
    this.autoQuality = localStorage.getItem('hw3d.autoQuality') !== '0';

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: this.quality.antialias,
      powerPreference: 'high-performance',
      stencil: false,
    });
    this.renderer.setClearColor(SKY_COLOR, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.18;
    this.renderer.shadowMap.enabled = this.quality.shadows;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    // 阴影贴图只在"有东西动了"时重画（见 markShadowsDirty）
    this.shadowDirty = true;
    this.renderer.shadowMap.autoUpdate = false;

    // 渲染分辨率（动态）
    this.resMode = 'auto';       // auto | 100 | 85 | 75
    this.renderScale = 1;
    this.resPaused = false;      // 自适应被"降了也没用"判据暂停
    this._probeFps = 0; this._probeScale = 1;
    // 性能统计（供 HUD 显示；applyPixelRatio 会写 perf.scale，必须先建好）
    this.perf = { fps: 0, frameMs: 0, scale: 1, calls: 0, tris: 0, shadowFrames: 0, frames: 0 };
    this.applyPixelRatio();

    this.scene = new THREE.Scene();
    // 纯色背景：旧版是 1×256 的全景渐变天空盒，可见区域只有 (5,7,10)→(4,6,10)，
    // 经 ACES 色调映射后实际显示为近黑，故改为直接的 clear 颜色（少一趟全屏绘制）
    this.scene.background = new THREE.Color(SKY_COLOR);
    this.scene.fog = new THREE.Fog(SKY_COLOR, 300, 900);

    this.camera = new THREE.PerspectiveCamera(45, 1, 0.8, 2400);
    this.camera.position.set(0, 120, 160);

    // 光照：半球光提供环境色，平行光当太阳（唯一投影光源）
    this.hemi = new THREE.HemisphereLight(0xdfeaf5, 0x39402f, 1.15);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff4e0, 1.85);
    this.sun.castShadow = this.quality.shadows;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    // 爆炸闪光等瞬时点光（池化复用）
    this.flashLight = new THREE.PointLight(0xffb060, 0, 40, 2);
    this.flashLight.visible = false;
    this.scene.add(this.flashLight);

    this.center = new THREE.Vector3();
    this.mapRadius = 100;
    this.shake = 0;
    this._shakeOffset = new THREE.Vector3();

    window.addEventListener('resize', () => this.resize());
    this.resize();
  }

  /** 标记阴影贴图需要重画（棋子移动/增删、地形重建、画质或地图变化时调用）。 */
  markShadowsDirty() { this.shadowDirty = true; }

  applyPixelRatio() {
    const cap = Math.min(window.devicePixelRatio || 1, this.quality.maxPixelRatio);
    const fixed = RES_SCALES[this.resMode];
    this.renderScale = fixed === null || fixed === undefined ? this.renderScale : fixed;
    this.renderer.setPixelRatio(Math.max(0.5, cap * this.renderScale));
    this.perf.scale = this.renderScale;
  }

  /** 切换渲染分辨率档位（auto = 动态，其余为固定缩放）。 */
  setResMode(mode) {
    if (!(mode in RES_SCALES)) return;
    this.resMode = mode;
    this.resPaused = false; this._probeFps = 0; this._probeScale = 1;
    if (RES_SCALES[mode] !== null) this.renderScale = RES_SCALES[mode];
    this.applyPixelRatio();
    this.resize();
  }

  /** 动态分辨率：由主循环每 0.5 秒用实测帧率调用一次。 */
  reportFps(fps) {
    this.perf.fps = fps;
    this.perf.frameMs = 1000 / Math.max(1, fps);
    if (this.resMode !== 'auto' || this.resPaused) return;
    const ms = this.perf.frameMs;
    // 防误伤：从"开始降档"到"已降 15% 以上"时评估这一次降档到底有没有换来帧率。
    // 没有明显收益（例如瓶颈是垂直同步 / CPU / 30Hz 外接屏）就恢复全分辨率并暂停自适应，
    // 避免白白牺牲画质。
    if (this.renderScale < 1) {
      if (!this._probeFps) {
        this._probeFps = fps;
        this._probeScale = this.renderScale;
      } else if (this.renderScale <= this._probeScale - 0.14) {
        if (fps / Math.max(1, this._probeFps) < 1.06) {
          this.resPaused = true;
          this._probeFps = 0;
          this.renderScale = 1;
          this.applyPixelRatio();
          this.resize();
          return;
        }
        this._probeFps = fps;
        this._probeScale = this.renderScale;
      }
    } else {
      this._probeFps = 0;
      this._probeScale = 1;
    }
    let next = this.renderScale;
    if (ms > RES_TARGET_MS && this.renderScale > RES_MIN) {
      // 严重超标（>1.5 倍预算）时一次多降一点，让重负载的开局/大会战更快稳定下来
      const step = ms > RES_TARGET_MS * 1.5 ? 0.10 : 0.05;
      next = Math.max(RES_MIN, this.renderScale - step);
    } else if (ms < RES_FLOOR_MS && this.renderScale < 1) {
      next = Math.min(1, this.renderScale + 0.05);
    }
    if (next !== this.renderScale) {
      this.renderScale = next;
      this.applyPixelRatio();
      this.resize();
    }
  }

  /** 是否已降到分辨率下限（此时才值得下调画质档位）。 */
  get atResFloor() { return this.resMode === 'auto' && this.renderScale <= RES_MIN + 1e-6; }

  setQuality(key) {
    if (!QUALITY_PRESETS[key]) return;
    this.qualityKey = key;
    this.quality = { ...QUALITY_PRESETS[key] };
    localStorage.setItem('hw3d.quality', key);
    this.renderer.shadowMap.enabled = this.quality.shadows;
    this.sun.castShadow = this.quality.shadows;
    this.resPaused = false; this._probeFps = 0; this._probeScale = 1;
    this.applyPixelRatio();
    this.resizeShadowCamera();
    this.markShadowsDirty();
    this.emitQuality();
  }

  emitQuality() {
    if (this.onQualityChange) this.onQualityChange(this.qualityKey, this.quality);
  }

  /** 地图尺寸变化后更新太阳阴影范围与雾。 */
  setMapBounds(cols, rows) {
    const w = Math.sqrt(3) * 6 * (cols + 1);
    const d = 1.5 * 6 * (rows + 1);
    this.center.set(w / 2 - Math.sqrt(3) * 6 * 0.5 - 1.2, 0, d / 2 - 9);
    this.mapRadius = Math.max(w, d) * 0.62;
    this.sun.position.set(this.center.x - this.mapRadius * 0.65, this.mapRadius * 1.5, this.center.z - this.mapRadius * 0.5);
    this.sun.target.position.copy(this.center);
    this.sun.target.updateMatrixWorld();
    this.resizeShadowCamera();
    this.scene.fog.near = this.mapRadius * 2.2;
    this.scene.fog.far = this.mapRadius * 6.5;
    this.resPaused = false; this._probeFps = 0; this._probeScale = 1;
    this.markShadowsDirty();
  }

  resizeShadowCamera() {
    const r = this.mapRadius * 1.35;
    const cam = this.sun.shadow.camera;
    cam.left = -r; cam.right = r; cam.top = r; cam.bottom = -r;
    cam.near = 1; cam.far = this.mapRadius * 5;
    cam.updateProjectionMatrix();
    if (this.quality.shadows) {
      this.sun.shadow.mapSize.set(this.quality.shadowMap, this.quality.shadowMap);
      if (this.sun.shadow.map) {
        this.sun.shadow.map.dispose();
        this.sun.shadow.map = null;
      }
    }
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  /** 屏幕震动（爆炸时调用，幅度随画质缩放）。 */
  addShake(amount) {
    this.shake = Math.min(1.4, this.shake + amount);
  }

  update(dt) {
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt * 1.9);
      const s = this.shake * this.shake * 0.9;
      this._shakeOffset.set((Math.random() - 0.5) * s, (Math.random() - 0.5) * s * 0.6, (Math.random() - 0.5) * s);
      this.camera.position.add(this._shakeOffset);
    }
  }

  render() {
    // 静止画面：跳过整趟 shadow map 深度 pass（输出与逐帧重画完全相同）
    if (this.shadowDirty && this.quality.shadows) {
      this.renderer.shadowMap.needsUpdate = true;
      this.shadowDirty = false;
      this.perf.shadowFrames++;
    }
    this.renderer.render(this.scene, this.camera);
    const r = this.renderer.info.render;
    this.perf.calls = r.calls;
    this.perf.tris = r.triangles;
    this.perf.frames++;
  }
}
