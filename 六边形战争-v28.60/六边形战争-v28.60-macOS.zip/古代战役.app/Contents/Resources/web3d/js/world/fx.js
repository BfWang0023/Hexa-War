/**
 * 武器时序与弹种（与 Rust 端 `src/fx.rs::weapon_profile` 完全一致）：
 * 决定瞄准时长、弹丸飞行时长与弹道样式，保证前端动画节奏与后端结算一致。
 */

export function weaponProfile(kind, aaMode, missileMode, area) {
  const p = (aim, flight) => ({ aim, flight });
  if (area) {
    return kind === 'mortar' ? p(0.25, 0.62) : p(0.3, 0.78);
  }
  if (aaMode) return p(0.4, 0.42);
  if (missileMode) {
    switch (kind) {
      case 'elite_infantry':
      case 'special_forces': return p(0.5, 0.4);
      case 'rifleman': return p(0.5, 0.4);
      case 'ifv':
      case 'cavalry_ifv': return p(0.35, 0.55);
      case 'aa_mgv': return p(0.4, 0.42);
      case 'tank':
      case 'heavy_tank': return p(0.06, 0.16);
      case 'howitzer': return p(0.3, 0.78);
      default: return p(0.3, 0.45);
    }
  }
  switch (kind) {
    case 'tank':
    case 'heavy_tank': return p(0.1, 0.2);
    case 'scout': return p(0.12, 0.22);
    case 'ifv':
    case 'cavalry_ifv':
    case 'aa_mgv': return p(0.08, 0.15);
    case 'atgm': return p(0.35, 0.55);
    case 'javelin': return p(0.45, 0.72);
    case 'aa_infantry':
    case 'aa_launcher': return p(0.4, 0.42);
    case 'hmg_gunner': return p(0.08, 0.14);
    case 'attack_heli':
    case 'drone': return p(0.22, 0.48);
    default: return p(0.05, 0.12);
  }
}

/** 弹种（决定弹道外观）。 */
export function projKind(kind, aaMode, missileMode, area) {
  if (area) return 'shell';
  if (aaMode) return 'stinger';
  if (missileMode) {
    switch (kind) {
      case 'elite_infantry':
      case 'special_forces':
      case 'rifleman': return 'rocket';
      case 'ifv':
      case 'cavalry_ifv': return 'tow';
      case 'aa_mgv': return 'stinger';
      case 'tank':
      case 'heavy_tank': return 'tracer';
      case 'howitzer': return 'shell';
      default: return 'rocket';
    }
  }
  switch (kind) {
    case 'tank':
    case 'heavy_tank':
    case 'scout': return 'shell';
    case 'ifv':
    case 'cavalry_ifv':
    case 'aa_mgv': return 'autocannon';
    case 'atgm': return 'tow';
    case 'javelin': return 'javelin';
    case 'aa_infantry':
    case 'aa_launcher': return 'stinger';
    case 'hmg_gunner': return 'tracer';
    case 'attack_heli':
    case 'drone': return 'hellfire';
    default: return 'tracer';
  }
}
