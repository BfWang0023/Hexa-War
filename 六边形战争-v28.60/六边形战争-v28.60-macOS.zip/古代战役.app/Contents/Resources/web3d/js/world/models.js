/**
 * 单位 3D 模型：全部用基本体程序化生成并**合并为极少的 Mesh**（车身 / 炮塔 / 旋翼），
 * 顶点色烘焙阵营涂装，几何按 (兵种, 阵营, 状态变体) 缓存，多个同型单位共享同一份几何。
 *
 * 尺寸单位 = 米（六边形外接圆半径 6 m）。为了 RTS 视角下的可读性，车辆/人员比真实
 * 尺寸略放大 10~20%（与原 2D 棋子「夸张一点更好认」的思路一致）。
 *
 * 模型朝向：**+X 为车头/炮口方向**，由 units.js 按航向绕 Y 轴旋转 -heading。
 */

import * as THREE from '../../vendor/three/three.module.js';
import { paintGeometry, mergeGeometries, srgb } from './terrain.js';

/* ------------------------------------------------------------------ */
/* 调色板                                                              */
/* ------------------------------------------------------------------ */
const PAL = {
  blue: srgb(58, 122, 186),
  blueDark: srgb(38, 84, 132),
  red: srgb(198, 78, 64),
  redDark: srgb(140, 50, 40),
  metal: srgb(56, 60, 62),
  metalLight: srgb(96, 100, 102),
  track: srgb(38, 40, 42),
  tire: srgb(30, 30, 32),
  glass: srgb(58, 78, 96),
  olive: srgb(108, 116, 66),
  oliveDark: srgb(74, 82, 46),
  white: srgb(238, 240, 236),
  canvasTop: srgb(96, 92, 74),
  sand: srgb(150, 138, 106),
  camo: srgb(88, 100, 70),
  camoDark: srgb(64, 74, 52),
};

function teamColors(team) {
  return team === 'blue'
    ? { main: PAL.blue, dark: PAL.blueDark }
    : { main: PAL.red, dark: PAL.redDark };
}

/* ------------------------------------------------------------------ */
/* 基本体工具                                                          */
/* ------------------------------------------------------------------ */

function g(geo, color, x = 0, y = 0, z = 0, rot = null) {
  if (rot) {
    if (rot.x) geo.rotateX(rot.x);
    if (rot.y) geo.rotateY(rot.y);
    if (rot.z) geo.rotateZ(rot.z);
  }
  geo.translate(x, y, z);
  paintGeometry(geo, color);
  return geo;
}

const box = (w, h, d, color, x = 0, y = 0, z = 0, rot = null) =>
  g(new THREE.BoxGeometry(w, h, d), color, x, y, z, rot);

const cyl = (rt, rb, h, color, x = 0, y = 0, z = 0, seg = 8, rot = null) =>
  g(new THREE.CylinderGeometry(rt, rb, h, seg), color, x, y, z, rot);

const sph = (r, color, x = 0, y = 0, z = 0, seg = 10) =>
  g(new THREE.SphereGeometry(r, seg, Math.max(6, seg / 2)), color, x, y, z);

/** 前后倾斜的楔形（车首装甲）：沿 +X 收窄的六面体。 */
function wedge(len, hFront, hBack, width, color, x = 0, y = 0, z = 0) {
  const hw = width / 2;
  const x0 = -len / 2, x1 = len / 2;
  const y0 = -hBack / 2, y1 = hBack / 2;
  const fy0 = -hFront / 2, fy1 = hFront / 2;
  const v = [
    x0, y0, -hw, x1, fy0, -hw, x1, fy1, -hw, x0, y1, -hw,
    x0, y0, hw, x1, fy0, hw, x1, fy1, hw, x0, y1, hw,
  ];
  const idx = [
    0, 1, 2, 0, 2, 3, // 左面
    5, 4, 7, 5, 7, 6, // 右面
    1, 5, 6, 1, 6, 2, // 前
    4, 0, 3, 4, 3, 7, // 后
    3, 2, 6, 3, 6, 7, // 上
    4, 5, 1, 4, 1, 0, // 下
  ];
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  geo.translate(x, y, z);
  paintGeometry(geo, color);
  return geo;
}

/** 平放在顶面的五角星涂装。 */
function starDecal(radius, color, x, y, z, rotY = 0) {
  const shape = new THREE.Shape();
  for (let i = 0; i < 10; i++) {
    const ang = -Math.PI / 2 + i * Math.PI / 5;
    const r = i % 2 === 0 ? radius : radius * 0.44;
    const px = Math.cos(ang) * r, py = Math.sin(ang) * r;
    if (i === 0) shape.moveTo(px, py); else shape.lineTo(px, py);
  }
  shape.closePath();
  const geo = new THREE.ShapeGeometry(shape);
  geo.rotateX(-Math.PI / 2);
  geo.rotateY(rotY);
  geo.translate(x, y, z);
  paintGeometry(geo, color);
  return geo;
}

/** 履带（含负重轮与履带板纹理感）。 */
function track(len, width, height, x, z) {
  const parts = [];
  parts.push(box(len, height, width, PAL.track, x, height / 2, z));
  const wheels = Math.max(3, Math.round(len / 1.15));
  for (let i = 0; i < wheels; i++) {
    const wx = x - len / 2 + (i + 0.5) * (len / wheels);
    parts.push(cyl(height * 0.36, height * 0.36, width * 0.72, PAL.metalLight, wx, height * 0.52, z, 8, { x: Math.PI / 2 }));
  }
  return parts;
}

function wheels(count, radius, width, positions) {
  const out = [];
  for (const [x, z] of positions) {
    out.push(cyl(radius, radius, width, PAL.tire, x, radius, z, 10, { x: Math.PI / 2 }));
    out.push(cyl(radius * 0.45, radius * 0.45, width * 1.06, PAL.metalLight, x, radius, z, 8, { x: Math.PI / 2 }));
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* 步兵                                                                */
/* ------------------------------------------------------------------ */

/** 单个士兵（约 2.35 m 高，含头盔/步枪），朝向 +X。 */
function soldier(color, pose = 'stand') {
  const parts = [];
  const bodyH = 1.15;
  parts.push(box(0.5, 0.16, 0.62, PAL.track, 0.02, 0.05, 0));        // 靴子
  parts.push(box(0.52, 0.62, 0.5, color.dark, 0, 0.44, 0));           // 腿
  parts.push(box(0.72, 0.62, 0.62, color.main, 0, 1.02, 0));          // 躯干
  parts.push(box(0.3, 0.4, 0.5, PAL.camoDark, -0.34, 1.05, 0));       // 背包
  parts.push(sph(0.24, PAL.sand, 0.02, 1.45, 0, 8));                  // 头盔
  parts.push(box(0.12, 0.12, 0.42, PAL.sand, 0.12, 1.44, 0));         // 盔沿
  // 步枪（斜挎）
  const rifleRot = pose === 'aim' ? { z: 0 } : { z: -0.35 };
  parts.push(box(0.9, 0.09, 0.1, PAL.metal, 0.5, pose === 'aim' ? 1.12 : 1.0, -0.2, rifleRot));
  if (pose === 'prone') {
    // 卧倒（阵亡用）
    parts.length = 0;
    parts.push(box(1.5, 0.3, 0.5, color.main, 0, 0.16, 0));
    parts.push(sph(0.24, PAL.sand, 0.85, 0.2, 0, 8));
    parts.push(box(0.9, 0.09, 0.1, PAL.metal, 1.2, 0.2, 0.2));
  }
  return parts;
}

/** 步兵班组：按 3 个菱形小队摆放（与原 2D 棋子编队一致）。 */
function squadFigures(n, team, opts = {}) {
  const colors = teamColors(team);
  const parts = [];
  const slots = squadSlots(n);
  const camoColor = opts.camo ? { main: PAL.camo, dark: PAL.camoDark } : colors;
  for (let i = 0; i < n; i++) {
    const [sx, sz, rot] = slots[i];
    for (const p of soldier(camoColor, opts.pose || 'stand')) {
      const c = p.clone();
      c.rotateY(rot);
      c.translate(sx, 0, sz);
      parts.push(c);
    }
  }
  return parts;
}

/** 班组内每名士兵的局部位置（米）。 */
export function squadSlots(n) {
  const spots = [];
  const spacing = 1.15;
  if (n <= 2) {
    for (let i = 0; i < n; i++) spots.push([0.2, (i - (n - 1) / 2) * spacing * 1.25, 0]);
  } else {
    const perTeam = Math.ceil(n / 3);
    const centers = [[0, 0], [0, 2.9], [2.5, 1.45]];
    let k = 0;
    for (let t = 0; t < 3 && k < n; t++) {
      const [cx, cz] = centers[t];
      for (let i = 0; i < perTeam && k < n; i++, k++) {
        const dx = (i % 2 === 0 ? -0.95 : 0.95) * (i < 2 ? 1 : 0.55);
        const dz = (i < 2 ? (i === 0 ? -0.95 : 0.95) : 0);
        spots.push([cx + dx, cz + dz, 0]);
      }
    }
  }
  return spots;
}

/* ------------------------------------------------------------------ */
/* 车辆族                                                              */
/* ------------------------------------------------------------------ */

function buildTank(team, kind) {
  const c = teamColors(team);
  const heavy = kind === 'heavy_tank';
  const L = heavy ? 8.6 : 7.6;
  const W = heavy ? 3.9 : 3.5;
  const hullH = heavy ? 1.35 : 1.25;
  const parts = [];
  // 车体
  parts.push(box(L, hullH, W, c.main, 0, 0.95 + hullH / 2 - 0.5, 0));
  parts.push(wedge(heavy ? 1.5 : 1.9, hullH * 0.55, hullH, W * 0.98, c.main, L / 2 + (heavy ? 0.5 : 0.6), 0.95 + hullH * 0.5, 0));
  parts.push(box(L * 0.92, 0.24, W * 0.9, c.dark, 0, 0.92 + hullH, 0));      // 车顶
  parts.push(...track(L + 0.5, 0.78, 1.15, 0.55, W / 2 - 0.1));
  parts.push(...track(L + 0.5, 0.78, 1.15, 0.55, -(W / 2 - 0.1)));
  parts.push(box(L * 0.5, 0.42, W * 1.18, c.dark, -L * 0.2, 0.9, 0));        // 侧裙
  parts.push(box(1.5, 0.3, W * 0.72, PAL.metal, -L / 2 + 0.5, 1.95, 0));    // 发动机格栅
  parts.push(starDecal(0.62, PAL.white, -L * 0.28, 0.94 + hullH + 0.13, 0, Math.PI / 2));
  return parts;
}

function buildTankTurret(team, kind) {
  const c = teamColors(team);
  const heavy = kind === 'heavy_tank';
  const parts = [];
  if (heavy) {
    // M1A2：楔形角状炮塔
    parts.push(box(4.0, 1.05, 3.0, c.main, -0.2, 0.52, 0));
    parts.push(wedge(1.5, 0.85, 1.05, 2.9, c.main, 2.0, 0.52, 0));
    parts.push(box(1.2, 0.5, 3.4, c.dark, -2.0, 0.55, 0));                  // 尾舱
    parts.push(box(1.0, 0.34, 0.9, PAL.metalLight, -0.1, 1.12, 1.0));       // 车长周视镜
    parts.push(cyl(0.34, 0.34, 0.22, c.dark, 0.5, 1.12, -1.0, 10));         // 舱盖
    parts.push(box(0.7, 0.3, 0.5, PAL.metal, 1.0, 1.2, 0.9));               // CROWS
    parts.push(box(1.4, 0.18, 0.3, PAL.metal, 0.2, 0.98, 1.7));             // 烟幕发射器
    parts.push(box(1.4, 0.18, 0.3, PAL.metal, 0.2, 0.98, -1.7));
    // 120mm 炮
    parts.push(cyl(0.19, 0.19, 2.6, PAL.metal, 2.6, 0.52, 0, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.13, 0.13, 2.9, PAL.metalLight, 5.2, 0.52, 0, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.17, 0.17, 0.5, PAL.metal, 6.7, 0.52, 0, 10, { z: Math.PI / 2 }));
  } else {
    // M60：蛋形炮塔
    const t = new THREE.SphereGeometry(1.0, 12, 8);
    t.scale(2.1, 0.78, 1.5);
    t.translate(0.1, 0.62, 0);
    paintGeometry(t, c.main);
    parts.push(t);
    parts.push(cyl(0.44, 0.44, 0.26, c.dark, -0.5, 1.02, -0.5, 10));         // 指挥塔
    parts.push(box(0.5, 0.26, 0.34, PAL.metal, 0.35, 1.0, -0.5));
    parts.push(cyl(0.36, 0.36, 0.2, c.dark, -0.6, 1.0, 0.62, 10));
    parts.push(box(0.6, 0.3, 0.4, PAL.metalLight, -0.3, 1.05, 1.1));         // 探照灯
    // 105mm 炮 + 炮口制退器
    parts.push(cyl(0.17, 0.17, 3.0, PAL.metal, 2.7, 0.55, 0, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.115, 0.115, 2.4, PAL.metalLight, 4.4, 0.55, 0, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.19, 0.19, 0.55, PAL.metal, 5.7, 0.55, 0, 10, { z: Math.PI / 2 }));
  }
  return parts;
}

function buildIfv(team, kind) {
  const c = teamColors(team);
  const cav = kind === 'cavalry_ifv';
  const L = cav ? 7.4 : 7.0;
  const W = 3.6;
  const parts = [];
  parts.push(box(L, 1.5, W, c.main, 0, 1.25, 0));
  parts.push(wedge(1.3, 1.0, 1.5, W * 0.96, c.main, L / 2 + 0.5, 1.25, 0));
  parts.push(box(L * 0.9, 0.22, W * 0.88, c.dark, 0, 2.06, 0));
  parts.push(...track(L + 0.4, 0.72, 1.1, 0.48, W / 2 - 0.05));
  parts.push(...track(L + 0.4, 0.72, 1.1, 0.48, -(W / 2 - 0.05)));
  parts.push(box(0.9, 0.9, W * 0.6, c.dark, -L / 2 - 0.05, 1.5, 0));  // 后门
  parts.push(starDecal(0.5, PAL.white, -L * 0.3, 2.22, 0, Math.PI / 2));
  return parts;
}

function buildIfvTurret(team, kind) {
  const c = teamColors(team);
  const cav = kind === 'cavalry_ifv';
  const parts = [];
  if (cav) {
    parts.push(cyl(1.25, 1.15, 0.95, c.main, -0.1, 0.5, 0, 6, { y: Math.PI / 6 }));
    // 圆柱形双联 TOW
    parts.push(cyl(0.34, 0.34, 2.0, PAL.olive, -0.4, 0.62, 1.15, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.34, 0.34, 2.0, PAL.olive, -0.4, 0.62, 0.62, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.36, 0.36, 0.12, PAL.oliveDark, 0.68, 0.62, 1.15, 10, { z: Math.PI / 2 }));
    parts.push(cyl(0.36, 0.36, 0.12, PAL.oliveDark, 0.68, 0.62, 0.62, 10, { z: Math.PI / 2 }));
  } else {
    parts.push(cyl(1.05, 1.0, 0.85, c.main, -0.2, 0.46, 0, 8));
    parts.push(box(1.6, 0.35, 1.0, PAL.olive, -0.3, 0.72, 1.25));  // 双联 TOW 箱
    parts.push(cyl(0.16, 0.16, 0.3, PAL.oliveDark, 0.5, 0.72, 1.45, 8, { z: Math.PI / 2 }));
    parts.push(cyl(0.16, 0.16, 0.3, PAL.oliveDark, 0.5, 0.72, 1.05, 8, { z: Math.PI / 2 }));
  }
  parts.push(cyl(0.12, 0.12, 2.5, PAL.metal, 2.0, 0.5, 0.15, 8, { z: Math.PI / 2 }));  // 25mm 机炮
  parts.push(cyl(0.09, 0.09, 1.2, PAL.metalLight, 0.9, 0.55, -0.7, 8, { z: Math.PI / 2 }));
  parts.push(box(0.6, 0.3, 0.5, PAL.metalLight, 0.4, 0.9, -0.4));  // 瞄准镜
  return parts;
}

function buildScout(team) {
  const c = teamColors(team);
  const L = 5.6, W = 3.0;
  const parts = [];
  parts.push(box(L, 1.2, W, c.main, 0, 1.05, 0));
  parts.push(wedge(1.2, 0.8, 1.2, W * 0.95, c.main, L / 2 + 0.4, 1.05, 0));
  parts.push(...track(L + 0.4, 0.66, 1.0, 0.4, W / 2 - 0.05));
  parts.push(...track(L + 0.4, 0.66, 1.0, 0.4, -(W / 2 - 0.05)));
  parts.push(starDecal(0.42, PAL.white, -L * 0.28, 1.72, 0, Math.PI / 2));
  return parts;
}

function buildScoutTurret(team) {
  const c = teamColors(team);
  const parts = [];
  const dome = new THREE.SphereGeometry(1.05, 12, 7, 0, Math.PI * 2, 0, Math.PI / 2);
  dome.translate(0.1, 0.5, 0);
  paintGeometry(dome, c.main);
  parts.push(dome);
  parts.push(cyl(0.24, 0.24, 1.9, PAL.metal, 1.5, 0.62, 0, 10, { z: Math.PI / 2 }));
  parts.push(cyl(0.3, 0.3, 0.22, PAL.metalLight, 2.3, 0.62, 0, 10, { z: Math.PI / 2 }));
  parts.push(sph(0.2, PAL.metalLight, 0.2, 1.3, 0, 8));
  return parts;
}

/** 悍马族（4x4）：HMG / TOW / Javelin / Stinger。 */
function buildHumvee(team, kind) {
  const c = teamColors(team);
  const L = 5.6, W = 2.6;
  const parts = [];
  parts.push(box(L, 0.85, W, c.main, 0, 0.95, 0));                       // 底盘
  parts.push(box(2.0, 0.95, W * 0.95, c.main, 0.9, 1.55, 0));            // 驾驶室
  parts.push(box(1.5, 0.6, W * 0.86, PAL.glass, 1.75, 1.62, 0));         // 风挡
  parts.push(box(1.9, 0.5, W * 0.94, c.dark, -1.3, 1.5, 0));             // 货斗
  parts.push(box(0.35, 0.35, W * 1.05, PAL.metal, L / 2 + 0.1, 0.86, 0));// 前保险杠
  parts.push(...wheels(4, 0.52, 0.4, [[1.75, W / 2 - 0.1], [1.75, -(W / 2 - 0.1)], [-1.7, W / 2 - 0.1], [-1.7, -(W / 2 - 0.1)]]));
  parts.push(starDecal(0.4, PAL.white, 1.0, 1.38, 0, Math.PI / 2));
  return parts;
}

function buildHumveeTurret(team, kind) {
  const parts = [];
  parts.push(cyl(0.5, 0.55, 0.35, PAL.metal, 0, 0.16, 0, 10));            // 转塔座圈
  if (kind === 'humvee_hmg') {
    parts.push(box(0.7, 0.5, 0.6, PAL.metal, 0.1, 0.5, 0));
    parts.push(cyl(0.09, 0.09, 1.5, PAL.metal, 1.1, 0.62, 0, 8, { z: Math.PI / 2 }));
    parts.push(box(0.4, 0.3, 0.3, PAL.oliveDark, -0.3, 0.5, 0.35));       // 弹箱
  } else if (kind === 'humvee_tow') {
    parts.push(box(1.5, 0.62, 1.0, PAL.olive, 0.25, 0.62, 0));
    parts.push(cyl(0.17, 0.17, 0.3, PAL.oliveDark, 1.05, 0.75, 0.25, 8, { z: Math.PI / 2 }));
    parts.push(cyl(0.17, 0.17, 0.3, PAL.oliveDark, 1.05, 0.75, -0.25, 8, { z: Math.PI / 2 }));
    parts.push(box(0.5, 0.4, 0.35, PAL.metalLight, -0.35, 0.62, 0));
  } else if (kind === 'humvee_javelin') {
    parts.push(box(1.4, 0.42, 0.42, PAL.olive, 0.3, 0.62, 0));
    parts.push(box(0.55, 0.55, 0.4, PAL.metalLight, -0.35, 0.7, 0));      // CLU
    parts.push(cyl(0.2, 0.26, 0.35, PAL.oliveDark, 1.15, 0.62, 0, 8, { z: Math.PI / 2 }));
  } else {
    parts.push(box(1.3, 0.75, 1.15, PAL.olive, 0, 0.75, 0));              // 四联 Stinger
    for (const dz of [-0.28, 0.28]) {
      for (const dy of [-0.16, 0.16]) {
        parts.push(cyl(0.11, 0.11, 0.3, PAL.oliveDark, 0.7, 0.75 + dy, dz, 8, { z: Math.PI / 2 }));
      }
    }
  }
  return parts;
}

function buildTruck(team) {
  const c = teamColors(team);
  const L = 8.2, W = 2.9;
  const parts = [];
  parts.push(box(L, 0.7, W, c.dark, 0, 1.0, 0));
  parts.push(box(2.3, 1.5, W * 0.98, c.main, 2.5, 1.95, 0));            // 平头驾驶室
  parts.push(box(1.5, 0.66, W * 0.9, PAL.glass, 3.4, 2.2, 0));
  parts.push(box(5.0, 1.75, W * 0.98, PAL.canvasTop, -1.2, 2.2, 0));    // 帆布货箱
  for (let i = 0; i < 4; i++) {
    parts.push(cyl(1.46, 1.46, 0.12, PAL.metal, -3.4 + i * 1.45, 2.2, 0, 8, { x: Math.PI / 2, y: 0 }));
  }
  parts.push(...wheels(6, 0.62, 0.42, [[2.6, W / 2 - 0.05], [2.6, -(W / 2 - 0.05)], [-1.0, W / 2 - 0.05], [-1.0, -(W / 2 - 0.05)], [-2.6, W / 2 - 0.05], [-2.6, -(W / 2 - 0.05)]]));
  return parts;
}

function buildHowitzer(team, deployed) {
  const c = teamColors(team);
  const parts = [];
  // 大架（展开/收起）
  const spread = deployed ? 1.0 : 0.25;
  for (const sgn of [1, -1]) {
    const trail = box(4.2, 0.22, 0.4, c.dark, -2.0, 0.5, sgn * 0.5);
    trail.rotateY(0);
    parts.push(trail);
    parts.push(box(0.9, 0.18, 0.5, c.dark, -4.1, 0.42, sgn * (0.5 + spread * 0.7)));
  }
  parts.push(cyl(0.9, 0.9, 0.4, PAL.tire, 0.2, 0.9, 1.35, 12, { x: Math.PI / 2 }));
  parts.push(cyl(0.9, 0.9, 0.4, PAL.tire, 0.2, 0.9, -1.35, 12, { x: Math.PI / 2 }));
  parts.push(box(1.6, 0.5, 2.4, c.main, -0.2, 1.1, 0));                 // 炮座
  const shield = box(0.24, 1.7, 2.6, c.dark, 1.35, 1.75, 0);
  shield.rotateZ(-0.22);
  parts.push(shield);
  parts.push(cyl(0.28, 0.34, 2.6, PAL.metal, 1.6, 1.95, 0.0, 10, { z: Math.PI / 2 }));
  parts.push(cyl(0.16, 0.16, 4.2, PAL.metalLight, 5.0, 1.95 - (deployed ? 0.35 : 0), 0, 10, { z: Math.PI / 2 }));
  parts.push(cyl(0.26, 0.26, 0.6, PAL.metal, 7.3, 1.95 - (deployed ? 0.35 : 0), 0, 10, { z: Math.PI / 2 }));
  if (!deployed) {
    parts.push(box(2.2, 0.5, 1.2, PAL.metal, -3.4, 1.05, 0));           // 牵引杆
  }
  return parts;
}

function buildMortar(team) {
  const c = teamColors(team);
  const L = 7.6, W = 3.1;
  const parts = [];
  parts.push(box(L, 1.5, W, c.main, 0, 1.3, 0));
  parts.push(wedge(1.2, 1.0, 1.5, W * 0.96, c.main, L / 2 + 0.4, 1.3, 0));
  parts.push(box(L * 0.8, 0.24, W * 0.9, c.dark, -0.2, 2.1, 0));
  parts.push(...wheels(8, 0.62, 0.42, [
    [2.4, W / 2 - 0.02], [2.4, -(W / 2 - 0.02)], [0.9, W / 2 - 0.02], [0.9, -(W / 2 - 0.02)],
    [-1.6, W / 2 - 0.02], [-1.6, -(W / 2 - 0.02)], [-3.0, W / 2 - 0.02], [-3.0, -(W / 2 - 0.02)],
  ]));
  return parts;
}

function buildMortarTurret(team) {
  const parts = [];
  parts.push(cyl(0.95, 0.95, 0.2, PAL.metal, 0, 0.1, 0, 14));
  const tube = cyl(0.24, 0.26, 2.6, PAL.metalLight, 0.55, 0.95, 0, 10, { z: -1.05 });
  parts.push(tube);
  parts.push(box(1.1, 0.2, 1.2, PAL.metal, -0.4, 0.2, 0));              // 座钣
  return parts;
}

function buildAaMgv(team) {
  const c = teamColors(team);
  const L = 7.6, W = 3.1;
  const parts = [];
  parts.push(box(L, 1.5, W, c.main, 0, 1.3, 0));
  parts.push(wedge(1.2, 1.0, 1.5, W * 0.96, c.main, L / 2 + 0.4, 1.3, 0));
  parts.push(...wheels(8, 0.62, 0.42, [
    [2.4, W / 2 - 0.02], [2.4, -(W / 2 - 0.02)], [0.9, W / 2 - 0.02], [0.9, -(W / 2 - 0.02)],
    [-1.6, W / 2 - 0.02], [-1.6, -(W / 2 - 0.02)], [-3.0, W / 2 - 0.02], [-3.0, -(W / 2 - 0.02)],
  ]));
  return parts;
}

function buildAaMgvTurret(team) {
  const c = teamColors(team);
  const parts = [];
  parts.push(cyl(1.0, 1.05, 0.8, c.main, 0, 0.45, 0, 6, { y: Math.PI / 6 }));
  parts.push(cyl(0.11, 0.11, 2.4, PAL.metal, 1.9, 0.55, 0.2, 8, { z: Math.PI / 2 }));
  parts.push(box(1.0, 0.9, 1.1, PAL.olive, -0.9, 0.7, 0));              // Stinger 四联
  for (const dz of [-0.26, 0.26]) {
    for (const dy of [-0.2, 0.2]) {
      parts.push(cyl(0.1, 0.1, 0.3, PAL.oliveDark, -0.4, 0.7 + dy, dz, 8, { z: Math.PI / 2 }));
    }
  }
  parts.push(box(0.6, 0.3, 0.4, PAL.metalLight, 0.6, 0.95, -0.4));
  return parts;
}

/* ------------------------------------------------------------------ */
/* 空中单位                                                            */
/* ------------------------------------------------------------------ */

function buildAttackHeli(team) {
  const c = teamColors(team);
  const parts = [];
  parts.push(box(4.6, 1.15, 1.5, c.main, 0.4, 0, 0));                    // 机身
  parts.push(wedge(1.6, 0.7, 1.15, 1.4, c.main, 3.4, 0, 0));             // 机头
  parts.push(box(1.5, 0.7, 1.2, PAL.glass, 1.9, 0.32, 0));               // 座舱
  parts.push(box(4.2, 0.45, 0.6, c.dark, -4.5, 0.1, 0));                 // 尾梁
  const fin = box(1.1, 1.5, 0.25, c.main, -6.6, 0.6, 0);
  fin.rotateZ(0.25);
  parts.push(fin);
  for (const sgn of [1, -1]) {
    parts.push(box(2.4, 0.22, 1.1, c.main, 0.2, -0.1, sgn * 1.45));      // 短翼
    for (let i = 0; i < 4; i++) {
      parts.push(cyl(0.16, 0.16, 1.3, PAL.olive, 0.2, -0.42, sgn * (1.0 + i * 0.28), 8, { z: Math.PI / 2 }));
    }
  }
  parts.push(cyl(0.3, 0.3, 0.5, PAL.metal, 3.0, -0.55, 0, 8));           // 机炮塔
  parts.push(cyl(0.09, 0.09, 0.9, PAL.metal, 3.5, -0.6, 0, 6, { z: Math.PI / 2 }));
  parts.push(cyl(0.36, 0.36, 0.5, c.dark, -6.9, 1.1, 0, 8, { z: Math.PI / 2 })); // 尾桨毂
  for (const sgn of [1, -1]) {
    parts.push(box(1.4, 0.6, 0.35, c.dark, 0.6, 0.5, sgn * 0.8));        // 短翼挂架
  }
  return parts;
}

function buildTransportHeli(team) {
  const c = teamColors(team);
  const parts = [];
  parts.push(box(5.2, 1.5, 1.9, c.main, 0.2, 0, 0));
  parts.push(wedge(1.8, 0.9, 1.5, 1.8, c.main, 3.5, 0, 0));
  parts.push(box(1.8, 0.8, 1.6, PAL.glass, 2.6, 0.4, 0));
  parts.push(box(4.4, 0.5, 0.7, c.dark, -4.8, 0.15, 0));
  const fin = box(1.2, 1.4, 0.25, c.main, -7.0, 0.55, 0);
  fin.rotateZ(0.2);
  parts.push(fin);
  parts.push(cyl(0.3, 0.3, 0.45, c.dark, -7.2, 1.0, 0, 8, { z: Math.PI / 2 }));
  parts.push(...wheels(4, 0.45, 0.32, [[1.9, 1.0], [1.9, -1.0], [-2.4, 1.0], [-2.4, -1.0]].map(([x, z]) => [x, z])));
  parts.push(box(0.9, 0.3, 0.3, PAL.metal, 1.6, -0.65, 0.95));           // 舱门机枪
  return parts;
}

function buildHeavyTransportHeli(team) {
  const c = teamColors(team);
  const parts = [];
  parts.push(box(9.5, 1.7, 2.4, c.main, 0, 0, 0));
  parts.push(wedge(1.6, 1.1, 1.7, 2.3, c.main, 5.4, 0, 0));
  parts.push(box(1.6, 0.9, 2.0, PAL.glass, 5.0, 0.5, 0));
  parts.push(box(1.4, 1.6, 0.3, c.main, -5.4, 0.9, 0));
  parts.push(cyl(0.36, 0.36, 0.5, c.dark, -5.5, 1.7, 0, 8));
  for (const sgn of [1, -1]) {
    parts.push(box(1.1, 0.5, 0.5, c.dark, -1.4, 1.1, sgn * 1.3));        // 转子塔
  }
  parts.push(...wheels(4, 0.5, 0.35, [[2.6, 1.1], [2.6, -1.1], [-2.2, 1.1], [-2.2, -1.1]]));
  return parts;
}

function buildDrone(team) {
  const c = teamColors(team);
  const parts = [];
  parts.push(box(3.4, 0.45, 0.55, c.main, 0, 0, 0));
  parts.push(wedge(0.9, 0.3, 0.45, 0.5, c.main, 2.0, 0, 0));
  parts.push(box(5.6, 0.14, 0.9, c.main, -0.1, 0.05, 0));                // 直翼
  for (const sgn of [1, -1]) {
    const t = box(1.3, 0.12, 0.4, c.dark, -1.9, 0.35, sgn * 0.35);
    t.rotateZ(0.5);
    parts.push(t);
  }
  parts.push(sph(0.3, PAL.glass, 1.5, -0.3, 0, 8));                      // 光电球
  parts.push(cyl(0.09, 0.09, 0.6, PAL.metal, -1.85, 0.1, 0, 6, { z: Math.PI / 2 }));
  return parts;
}

/* ------------------------------------------------------------------ */
/* 其它                                                                */
/* ------------------------------------------------------------------ */

function buildHeadquarters(team) {
  const c = teamColors(team);
  const parts = [];
  parts.push(box(6.0, 2.2, 5.0, c.main, 0, 1.1, 0));
  const roof = new THREE.CylinderGeometry(3.4, 3.4, 6.2, 3, 1);
  roof.rotateZ(Math.PI / 2);
  roof.rotateY(Math.PI / 2);
  roof.scale(1, 1, 0.55);
  roof.translate(0, 2.9, 0);
  paintGeometry(roof, c.dark);
  parts.push(roof);
  parts.push(box(1.2, 1.8, 0.2, PAL.metal, 0, 0.9, 2.55));               // 门
  parts.push(starDecal(0.9, PAL.white, -1.2, 2.24, 0, Math.PI / 2));
  parts.push(cyl(0.06, 0.06, 5.0, PAL.metal, -2.0, 4.4, -1.8, 5));       // 鞭状天线
  return parts;
}

function buildSupply(team) {
  const c = teamColors(team);
  const wood = srgb(126, 96, 58);
  const woodTop = srgb(156, 122, 76);
  const parts = [];
  parts.push(box(2.6, 1.0, 1.8, wood, 0, 0.5, 0));
  parts.push(box(2.62, 0.12, 1.82, woodTop, 0, 1.0, 0));
  parts.push(box(2.2, 0.9, 1.6, wood, -0.1, 1.5, 0.1));
  parts.push(box(2.22, 0.12, 1.62, woodTop, -0.1, 1.95, 0.1));
  parts.push(box(1.2, 0.8, 1.2, wood, 0.9, 0.4, -1.0));
  parts.push(box(2.7, 0.16, 1.9, c.main, 0, 0.06, 0));                   // 阵营色带
  return parts;
}

/* ------------------------------------------------------------------ */
/* 组装：按兵种生成 { body, turret, rotors, height }                    */
/* ------------------------------------------------------------------ */

const CACHE = new Map();

/** 全局模型放大系数（1.0 = 真实尺寸；略放大以便在 RTS 视角下辨认）。 */
export const UNIT_SCALE = 1.3;

/** 步兵班组人数（与后端 soldiers_alive 口径一致：hp*4，上限 12/8）。 */
export function soldierCount(kind, hp) {
  if (kind === 'rifleman' || kind === 'elite_infantry') return Math.max(0, Math.min(12, hp * 4));
  if (kind === 'special_forces') return Math.max(0, Math.min(8, hp * 4));
  if (kind === 'headquarters') return 1;
  if (kind === 'atgm' || kind === 'javelin' || kind === 'aa_infantry' || kind === 'hmg_gunner') return 2;
  return 2;
}

const FOOT_KINDS = new Set(['rifleman', 'atgm', 'javelin', 'special_forces', 'elite_infantry', 'aa_infantry', 'hmg_gunner']);

function buildFoot(kind, team, hp) {
  const n = soldierCount(kind, hp);
  const colors = teamColors(team);
  const parts = [];
  if (kind === 'atgm') {
    parts.push(...squadFigures(2, team, {}));
    parts.push(box(1.1, 0.6, 0.9, PAL.olive, 1.5, 0.75, 0));             // 双联 TOW
    parts.push(cyl(0.14, 0.14, 0.4, PAL.oliveDark, 2.1, 0.75, 0.22, 8, { z: Math.PI / 2 }));
    parts.push(cyl(0.14, 0.14, 0.4, PAL.oliveDark, 2.1, 0.75, -0.22, 8, { z: Math.PI / 2 }));
    for (const [x, z] of [[1.2, 0.5], [1.2, -0.5], [1.9, 0]]) {
      parts.push(cyl(0.05, 0.05, 0.8, PAL.metal, x, 0.4, z, 5));
    }
  } else if (kind === 'javelin' || kind === 'aa_infantry') {
    parts.push(...squadFigures(2, team, {}));
    const tubeCol = kind === 'javelin' ? PAL.olive : PAL.oliveDark;
    parts.push(cyl(0.16, 0.16, 1.7, tubeCol, 1.0, 1.35, 1.1, 8, { z: Math.PI / 2, y: -0.25 }));
    parts.push(cyl(0.16, 0.16, 1.7, tubeCol, 1.0, 1.35, -1.1, 8, { z: Math.PI / 2, y: 0.25 }));
  } else if (kind === 'hmg_gunner') {
    parts.push(...squadFigures(2, team, {}));
    parts.push(cyl(0.1, 0.1, 1.9, PAL.metal, 1.3, 0.78, 0, 8, { z: Math.PI / 2 }));
    parts.push(box(0.55, 0.4, 0.5, PAL.oliveDark, 0.1, 0.75, 0));
    for (const [x, z] of [[0.7, 0.42], [0.7, -0.42], [0.1, 0]]) {
      parts.push(cyl(0.05, 0.05, 0.85, PAL.metal, x, 0.42, z, 5, { x: z === 0 ? 0.35 : 0, z: z === 0 ? 0 : (z > 0 ? 0.35 : -0.35) }));
    }
  } else {
    const camo = kind === 'special_forces' || kind === 'elite_infantry';
    parts.push(...squadFigures(n, team, { camo }));
    // 背负的火箭筒（发射管数量随弹药减少由 units.js 简化处理，这里画 1~2 根）
    if (kind === 'rifleman' || kind === 'elite_infantry' || kind === 'special_forces') {
      const tube = kind === 'rifleman' ? PAL.olive : PAL.oliveDark;
      parts.push(cyl(0.13, 0.13, 1.2, tube, -0.3, 1.25, 0.75, 8, { z: Math.PI / 2 }));
      parts.push(cyl(0.13, 0.13, 1.2, tube, -0.3, 1.25, -0.75, 8, { z: Math.PI / 2 }));
    }
  }
  if (parts.length === 0) parts.push(...squadFigures(2, team, {}));
  return parts;
}

/**
 * 构建单位模型（带缓存）。
 * @returns {{bodyGeo, turretGeo, rotorGeo, rotorY, turretPivot, height, foot}}
 */
export function getModel(kind, team, opts = {}) {
  const hp = opts.hp ?? 2;
  const deployed = !!opts.deployed;
  const variant = FOOT_KINDS.has(kind) ? `h${soldierCount(kind, hp)}`
    : (kind === 'howitzer' ? (deployed ? 'dep' : 'tow') : '');
  const key = `${kind}|${team}|${variant}`;
  let cached = CACHE.get(key);
  if (cached) return cached;

  let body = [], turret = null, rotors = null, height = 3, turretPivot = [0, 0, 0], foot = false;

  switch (kind) {
    case 'tank': case 'heavy_tank':
      body = buildTank(team, kind); turret = buildTankTurret(team, kind);
      height = 5; turretPivot = [0, kind === 'heavy_tank' ? 2.55 : 2.35, 0];
      break;
    case 'ifv': case 'cavalry_ifv':
      body = buildIfv(team, kind); turret = buildIfvTurret(team, kind);
      height = 5; turretPivot = [0, 2.15, 0];
      break;
    case 'scout':
      body = buildScout(team); turret = buildScoutTurret(team);
      height = 4.2; turretPivot = [0, 1.65, 0];
      break;
    case 'humvee_hmg': case 'humvee_tow': case 'humvee_javelin': case 'aa_launcher':
      body = buildHumvee(team, kind); turret = buildHumveeTurret(team, kind);
      height = 3.6; turretPivot = [-1.1, 1.62, 0];
      break;
    case 'truck':
      body = buildTruck(team); height = 4.2;
      break;
    case 'howitzer':
      body = buildHowitzer(team, deployed); height = 4.4;
      break;
    case 'mortar':
      body = buildMortar(team); turret = buildMortarTurret(team);
      height = 4.2; turretPivot = [0.4, 2.2, 0];
      break;
    case 'aa_mgv':
      body = buildAaMgv(team); turret = buildAaMgvTurret(team);
      height = 4.4; turretPivot = [0.3, 2.1, 0];
      break;
    case 'attack_heli': {
      body = buildAttackHeli(team); height = 3.4;
      rotors = [
        { x: -0.2, y: 1.35, z: 0, blades: rotorBlades(5.9, 4), disc: rotorDisc(5.9), speed: 11 },
        { x: -6.9, y: 1.1, z: 0.42, blades: rotorBlades(1.3, 2), disc: null, speed: 22, axis: 'z' },
      ];
      break;
    }
    case 'transport_heli': {
      body = buildTransportHeli(team); height = 3.8;
      rotors = [
        { x: -0.3, y: 1.7, z: 0, blades: rotorBlades(5.5, 4), disc: rotorDisc(5.5), speed: 10 },
        { x: -7.2, y: 1.0, z: 0.4, blades: rotorBlades(1.2, 2), disc: null, speed: 20, axis: 'z' },
      ];
      break;
    }
    case 'heavy_transport_heli': {
      body = buildHeavyTransportHeli(team); height = 4.2;
      rotors = [
        { x: 2.6, y: 1.95, z: 0, blades: rotorBlades(4.2, 3), disc: rotorDisc(4.2), speed: 9 },
        { x: -2.2, y: 1.95, z: 0, blades: rotorBlades(4.2, 3), disc: rotorDisc(4.2), speed: 9, phase: 0.6 },
      ];
      break;
    }
    case 'drone':
      body = buildDrone(team); height = 1.6;
      rotors = [{ x: -2.05, y: 0.1, z: 0, blades: rotorBlades(0.9, 2), disc: null, speed: 34, axis: 'z' }];
      break;
    case 'headquarters':
      body = buildHeadquarters(team); height = 6;
      break;
    case 'supply':
      body = buildSupply(team); height = 2.6;
      break;
    default:
      body = buildFoot(kind, team, hp); height = 2.6; foot = true;
      break;
  }

  const bodyGeo = mergeGeometries(body);
  // 统一放大：RTS 视角下更容易辨认（与原 2D 棋子「夸张一点更好认」一致）
  bodyGeo.scale(UNIT_SCALE, UNIT_SCALE, UNIT_SCALE);
  const turretGeo = turret ? mergeGeometries(turret) : null;
  if (turretGeo) turretGeo.scale(UNIT_SCALE, UNIT_SCALE, UNIT_SCALE);
  const rotorDefs = rotors ? rotors.map(r => {
    const bladesGeo = mergeGeometries(r.blades);
    bladesGeo.scale(UNIT_SCALE, UNIT_SCALE, UNIT_SCALE);
    const discGeo = r.disc ? mergeGeometries(r.disc) : null;
    if (discGeo) discGeo.scale(UNIT_SCALE, UNIT_SCALE, UNIT_SCALE);
    return { ...r, x: r.x * UNIT_SCALE, y: r.y * UNIT_SCALE, z: r.z * UNIT_SCALE, bladesGeo, discGeo };
  }) : null;
  const pivot = turretPivot.map(v => v * UNIT_SCALE);
  cached = { bodyGeo, turretGeo, rotors: rotorDefs, turretPivot: pivot, height: height * UNIT_SCALE, foot, kind, team };
  CACHE.set(key, cached);
  return cached;
}

/** 旋翼桨叶（不透明部分：桨毂 + 桨叶）。 */
function rotorBlades(radius, count) {
  const parts = [];
  parts.push(cyl(radius * 0.055 + 0.08, radius * 0.055 + 0.08, 0.22, PAL.metal, 0, 0, 0, 8));
  for (let i = 0; i < count; i++) {
    const ang = (i / count) * Math.PI * 2;
    const blade = box(radius, 0.09, Math.max(0.42, radius * 0.1), PAL.metalLight, radius / 2, 0, 0);
    blade.rotateY(-ang);
    parts.push(blade);
  }
  return parts;
}

/** 旋翼盘（半透明，表现高速旋转的视觉残留）。 */
function rotorDisc(radius) {
  const disc = new THREE.CylinderGeometry(radius * 0.99, radius * 0.99, 0.02, 26);
  disc.translate(0, -0.05, 0);
  paintGeometry(disc, PAL.metalLight);
  return [disc];
}

/** 阵亡步兵尸体（卧倒的灰色小人），按人数生成并缓存。 */
const CORPSE_CACHE = new Map();
export function getCorpseGeo(kind, n) {
  const key = kind + ':' + n;
  if (CORPSE_CACHE.has(key)) return CORPSE_CACHE.get(key);
  const gray = { main: srgb(122, 122, 116), dark: srgb(92, 92, 88) };
  const parts = [];
  const slots = squadSlots(n);
  for (let i = 0; i < n; i++) {
    const [sx, sz, rot] = slots[i];
    for (const p of soldier(gray, 'prone')) {
      const c = p.clone();
      c.rotateY(rot + (i % 3) * 0.4 - 0.4);
      c.translate(sx, 0, sz);
      parts.push(c);
    }
  }
  const geo = mergeGeometries(parts.length ? parts : [box(1, 0.3, 0.6, gray.main, 0, 0.15, 0)]);
  CORPSE_CACHE.set(key, geo);
  return geo;
}

export function clearModelCache() { CACHE.clear(); CORPSE_CACHE.clear(); }

export { PAL, teamColors };
