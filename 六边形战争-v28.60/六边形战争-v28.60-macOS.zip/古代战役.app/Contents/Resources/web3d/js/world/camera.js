/**
 * RTS 摄像机：可平移 / 旋转 / 缩放，带平滑与「对焦到棋子」补间。
 *
 * 操作（以鼠标为主，不再占用 WASD，避免与 S=补给 等快捷键冲突）：
 *   **左键拖动** / 右键拖动 / 中键拖动 / 方向键  —— 平移
 *   中键拖动 / Q E / 按住 Shift + 左键拖动        —— 旋转
 *   滚轮                                          —— 以光标为中心缩放
 *   [ / ]                                         —— 俯仰
 *   双击地图                                       —— 以该点为中心
 *
 * 左键按下后位移超过 CLICK_SLOP 像素才进入拖动（否则仍算点击选兵/移动），
 * 并把这段位移一并补偿，拖动是 1:1 跟手的。
 */

import * as THREE from '../../vendor/three/three.module.js';

const CLICK_SLOP = 6;   // 左键位移超过该像素数才算拖动（否则按点击处理）
const MIN_DIST = 16;
const MAX_DIST = 420;
const MIN_PITCH = 0.22;
const MAX_PITCH = 1.42;

export class RtsCamera {
  constructor(world, dom) {
    this.world = world;
    this.dom = dom;
    this.camera = world.camera;
    this.target = new THREE.Vector3(0, 0, 0);
    this.desiredTarget = new THREE.Vector3(0, 0, 0);
    this.dist = 150;
    this.desiredDist = 150;
    this.yaw = 0;
    this.desiredYaw = 0;
    this.pitch = 0.86;
    this.desiredPitch = 0.86;
    this.bounds = { minX: -60, maxX: 60, minZ: -60, maxZ: 60 };
    this.keys = new Set();
    this.edgeScroll = false;
    this.enabled = true;
    /** 被 UI 面板遮挡的边距（像素）：让取景中心落在未被遮挡的区域，
     *  这样左上角招募栏/下方棋子面板不会盖住战场中心。 */
    this.uiPad = { left: 0, right: 0, top: 0, bottom: 0 };
    /** 拖动行为（可在 ⚙ 设置 → 镜头 中调整）：
     *  - panMode: 'grab'   内容跟随鼠标（抓取式，默认，地图类应用的手感）
     *             'camera' 镜头跟随鼠标（内容反向移动）
     *  - panSens:  灵敏度倍率（0.3~3.0）
     *  - invertX / invertY: 分轴反向 */
    this.panMode = 'grab';
    this.panSens = 1.0;
    this.invertX = false;
    this.invertY = false;
    /** 本次左键手势是否已经变成拖动（供点击逻辑判断，避免「拖一下顺带选了兵」） */
    this.dragged = false;
    this.tween = null;
    this._raycaster = new THREE.Raycaster();
    this._plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    this._drag = null;
    // 画布矩形与尺寸缓存：每帧/每次 pointermove 都读 clientWidth/getBoundingClientRect
    // 会在 DOM 脏的时候触发同步重排（拖动时正好每帧都脏），这里只在窗口尺寸变化时失效
    this._rect = null;
    this._vw = 0;
    this._vh = 0;
    window.addEventListener('resize', () => { this._rect = null; this._vw = 0; this._vh = 0; });
    this._bind();
  }

  /** 画布 CSS 矩形（缓存；只在窗口尺寸变化后重建）。 */
  rect() {
    if (!this._rect) this._rect = this.dom.getBoundingClientRect();
    return this._rect;
  }

  /** 画布 CSS 尺寸（缓存）。 */
  viewSize() {
    if (!this._vw) {
      const w = this.dom.clientWidth || window.innerWidth;
      const h = this.dom.clientHeight || window.innerHeight;
      this._vw = w; this._vh = h;
    }
    return { w: this._vw, h: this._vh };
  }

  setBounds(cols, rows) {
    const w = Math.sqrt(3) * 6 * cols;
    const d = 1.5 * 6 * rows + 6;
    this.bounds = { minX: -24, maxX: w + 24 - Math.sqrt(3) * 6, minZ: -24, maxZ: d + 24 };
    this.target.set(w / 2 - Math.sqrt(3) * 3, 0, d / 2 - 9);
    this.desiredTarget.copy(this.target);
  }

  _bind() {
    const dom = this.dom;
    dom.addEventListener('contextmenu', e => e.preventDefault());
    dom.addEventListener('pointerdown', (e) => {
      if (!this.enabled) return;
      this.dragged = false;
      if (e.button === 0) {
        // 左键：先记为「待定」，位移超过阈值才转为平移（否则交给点击逻辑选兵/移动）
        this._drag = {
          button: 0,
          x: e.clientX,
          y: e.clientY,
          ox: e.clientX,
          oy: e.clientY,
          mode: e.shiftKey ? 'rotate' : 'pending',
        };
        dom.setPointerCapture?.(e.pointerId);
      } else if (e.button === 1 || e.button === 2) {
        this._drag = {
          button: e.button,
          x: e.clientX,
          y: e.clientY,
          ox: e.clientX,
          oy: e.clientY,
          mode: e.button === 1 ? 'rotate' : 'pan',
        };
        this.dragged = true;
        dom.setPointerCapture?.(e.pointerId);
        e.preventDefault();
      }
    });
    dom.addEventListener('pointermove', (e) => {
      const d = this._drag;
      if (!d) return;
      if (d.mode === 'pending') {
        // 还没到拖动阈值：仍可能是点击
        if (Math.hypot(e.clientX - d.ox, e.clientY - d.oy) < CLICK_SLOP) return;
        d.mode = 'pan';
        this.dragged = true;
      }
      const dx = e.clientX - d.x;
      const dy = e.clientY - d.y;
      d.x = e.clientX;
      d.y = e.clientY;
      if (d.mode === 'pan') {
        this.panScreen(dx, dy, { x: e.clientX - dx, y: e.clientY - dy }, { x: e.clientX, y: e.clientY });
      } else if (d.mode === 'rotate') {
        // 直接跟手（同样不做平滑）
        this.desiredYaw -= dx * 0.006;
        this.yaw = this.desiredYaw;
        this.desiredPitch = clamp(this.desiredPitch + dy * 0.004, MIN_PITCH, MAX_PITCH);
        this.pitch = this.desiredPitch;
      }
    });
    const endDrag = (e) => {
      if (this._drag) {
        this._drag = null;
        this.dom.releasePointerCapture?.(e.pointerId);
      }
    };
    dom.addEventListener('pointerup', endDrag);
    dom.addEventListener('pointercancel', endDrag);
    dom.addEventListener('wheel', (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      const factor = Math.exp(e.deltaY * 0.0012);
      this.zoomAt(e.clientX, e.clientY, factor);
    }, { passive: false });
    window.addEventListener('keydown', (e) => {
      if (e.target && /input|select|textarea/i.test(e.target.tagName)) return;
      this.keys.add(e.code);
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());
  }

  /** 屏幕坐标（CSS 像素）→ 地面交点。 */
  groundPointClient(clientX, clientY, height = 0, out = null) {
    const rect = this.rect();
    if (rect.width < 1 || rect.height < 1) return null;
    const ndc = this._ndc2 || (this._ndc2 = new THREE.Vector2());
    ndc.set(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1,
    );
    return this.groundPoint(ndc, height, out);
  }

  /**
   * 拖动平移：让「按下时光标下的地面点」始终跟着光标走（抓取式，1:1 跟手）。
   * 用射线求交而不是按比例估算，因此不同俯仰/缩放/宽高比下手感一致
   * —— 旧实现纵横比例不一致，竖直方向会明显偏快（这正是「方向反直觉」的来源）。
   */
  panScreen(dx, dy, fromClient = null, toClient = null) {
    const f = this.forward().set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const r = this.right().set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const mv = this._mv || (this._mv = new THREE.Vector3());
    mv.set(0, 0, 0);
    let ok = false;
    if (fromClient && toClient) {
      const g0 = this.groundPointClient(fromClient.x, fromClient.y, 0, this._g0 || (this._g0 = new THREE.Vector3()));
      const g1 = this.groundPointClient(toClient.x, toClient.y, 0, this._g1 || (this._g1 = new THREE.Vector3()));
      if (g0 && g1) {
        // 光标下的地面点移动了 d，则镜头要反向移动 -d 才能让它跟手
        mv.set(g1.x - g0.x, 0, g1.z - g0.z);
        if (this.panMode !== 'camera') mv.multiplyScalar(-1);
        const cap = this.dist * 2.5;   // 俯仰极低时射线交点会飞很远，做个限幅
        const len = Math.hypot(mv.x, mv.z);
        if (len > cap) mv.multiplyScalar(cap / len);
        ok = true;
      }
    }
    if (!ok) {
      // 退化情况（射线与地面近乎平行等）：按像素比例近似
      const k = this.dist * 0.0017;
      mv.set(0, 0, 0).addScaledVector(r, -dx * k).addScaledVector(f, -dy * k);
      if (this.panMode === 'camera') mv.multiplyScalar(-1);
    }
    // 分轴反向：把位移按屏幕横/纵轴镜像
    if (this.invertX) mv.addScaledVector(r, -2 * mv.dot(r));
    if (this.invertY) mv.addScaledVector(f, -2 * mv.dot(f));
    const sens = this.panSens || 1;
    this.desiredTarget.x += mv.x * sens;
    this.desiredTarget.z += mv.z * sens;
    // **直接跟手**：指针拖动不做平滑（否则镜头会以 ~0.15s 的时间常数"追"光标，
    // 表现为拖动发飘/延迟）。平滑只保留给键盘平移与对焦补间。
    this.target.x = this.desiredTarget.x;
    this.target.z = this.desiredTarget.z;
    this.clampNow();
    this.tween = null;
  }

  forward() { return this._fwd || (this._fwd = new THREE.Vector3()); }
  right() { return this._rgt || (this._rgt = new THREE.Vector3()); }

  /** 以屏幕某点为中心缩放（保持光标下的地面点不动）。 */
  zoomAt(clientX, clientY, factor) {
    const rect = this.rect();
    const ndc = this._ndc3 || (this._ndc3 = new THREE.Vector2());
    ndc.set(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1,
    );
    const before = this.groundPoint(ndc, 0, this._before || (this._before = new THREE.Vector3()));
    this.desiredDist = clamp(this.desiredDist * factor, MIN_DIST, MAX_DIST);
    // **立刻缩放**（滚轮不做平滑，否则缩放同样会滞后约 0.15s），
    // 并用新距离把「光标下的地面点」补偿回原位。
    this.dist = this.desiredDist;
    this.applyCamera();
    const after = this.groundPoint(ndc, 0, this._after || (this._after = new THREE.Vector3()));
    if (before && after) {
      this.desiredTarget.x += before.x - after.x;
      this.desiredTarget.z += before.z - after.z;
      this.target.x = this.desiredTarget.x;
      this.target.z = this.desiredTarget.z;
      this.clampNow();
      this.tween = null;
    }
  }

  /** NDC → 地面（y=0）交点。 */
  groundPoint(ndc, height = 0, out = null) {
    this._plane.constant = -height;
    this._raycaster.setFromCamera(ndc, this.camera);
    const hit = out || this._hit || (this._hit = new THREE.Vector3());
    return this._raycaster.ray.intersectPlane(this._plane, hit) ? hit : null;
  }

  /** 视锥在地面上的投影四角（缩略地图的视野框）。 */
  footprint(height = 0) {
    const pts = this._foot || (this._foot = []);
    pts.length = 0;
    if (!this._footPool) {
      this._footPool = [];
      for (let i = 0; i < 4; i++) this._footPool.push(new THREE.Vector3());
    }
    let i = 0;
    for (const [nx, ny] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      const ndc = this._ndc || (this._ndc = new THREE.Vector2());
      ndc.set(nx, ny);
      const p = this.groundPoint(ndc, height, this._footPool[i++]);
      if (p) pts.push(p);
    }
    return pts;
  }

  /** 平滑对焦到世界坐标点。 */
  focus(x, z, dist = null, instant = false) {
    this.tween = {
      fromX: this.target.x, fromZ: this.target.z,
      toX: x, toZ: z,
      fromDist: this.dist, toDist: dist ?? Math.min(this.dist, 70),
      t: 0, dur: instant ? 0.001 : 0.45,
    };
    this.desiredTarget.set(x, 0, z);
    if (dist != null) this.desiredDist = clamp(dist, MIN_DIST, MAX_DIST);
  }

  clampTarget() {
    const b = this.bounds;
    this.desiredTarget.x = clamp(this.desiredTarget.x, b.minX, b.maxX);
    this.desiredTarget.z = clamp(this.desiredTarget.z, b.minZ, b.maxZ);
  }

  /** 立即把目标点夹到地图范围内（直接跟手的拖动必须当帧夹住，
   *  否则拖到边界外会"冲出去"再慢慢飘回来）。 */
  clampNow() {
    this.clampTarget();
    this.target.x = this.desiredTarget.x;
    this.target.z = this.desiredTarget.z;
  }

  update(dt) {
    if (!this.enabled) { this.applyCamera(); return; }
    // 键盘平移
    const speed = this.dist * 1.15;
    const f = this.forward().set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const r = this.right().set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    // 只保留方向键（WASD 已移除：S/A/D 等是游戏快捷键，避免冲突）
    let mx = 0, mz = 0;
    if (this.keys.has('ArrowUp')) mz += 1;
    if (this.keys.has('ArrowDown')) mz -= 1;
    if (this.keys.has('ArrowLeft')) mx -= 1;
    if (this.keys.has('ArrowRight')) mx += 1;
    if (mx || mz) {
      this.desiredTarget.addScaledVector(f, mz * speed * dt);
      this.desiredTarget.addScaledVector(r, mx * speed * dt);
      this.tween = null;
    }
    if (this.keys.has('KeyQ')) this.desiredYaw += dt * 1.1;
    if (this.keys.has('KeyE')) this.desiredYaw -= dt * 1.1;
    if (this.keys.has('BracketRight')) this.desiredPitch = clamp(this.desiredPitch + dt * 0.5, MIN_PITCH, MAX_PITCH);
    if (this.keys.has('BracketLeft')) this.desiredPitch = clamp(this.desiredPitch - dt * 0.5, MIN_PITCH, MAX_PITCH);

    // 对焦补间
    if (this.tween) {
      const tw = this.tween;
      tw.t += dt;
      const k = Math.min(1, tw.t / tw.dur);
      const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      this.target.x = tw.fromX + (tw.toX - tw.fromX) * e;
      this.target.z = tw.fromZ + (tw.toZ - tw.fromZ) * e;
      this.dist = tw.fromDist + (tw.toDist - tw.fromDist) * e;
      if (k >= 1) this.tween = null;
    } else {
      const s = 1 - Math.pow(0.0009, dt);
      this.target.x += (this.desiredTarget.x - this.target.x) * s;
      this.target.z += (this.desiredTarget.z - this.target.z) * s;
      this.dist += (this.desiredDist - this.dist) * s;
    }
    const rs = 1 - Math.pow(0.0005, dt);
    this.yaw += (this.desiredYaw - this.yaw) * rs;
    this.pitch += (this.desiredPitch - this.pitch) * rs;
    this.clampTarget();
    this.applyCamera();
  }

  applyCamera() {
    this.clampTarget();
    // UI 边距补偿：把目标点放在「未被面板遮挡区域」的中心，而不是窗口中心
    const { w: vw, h: vh } = this.viewSize();
    const halfFov = Math.tan((this.camera.fov * Math.PI) / 360);
    const worldPerPxY = (2 * this.dist * halfFov) / vh;
    const worldPerPxX = (2 * this.dist * halfFov * this.camera.aspect) / vw;
    // 目标点希望出现在「自由区域」中心：横向把视点向左挪、纵向把视点向近处挪
    const offX = -((this.uiPad.left - this.uiPad.right) / 2) * worldPerPxX;
    const offZ = ((this.uiPad.top - this.uiPad.bottom) / 2) * worldPerPxY;
    const r = this.right().set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const f = this.forward().set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const cx = this.target.x + r.x * offX + f.x * offZ;
    const cz = this.target.z + r.z * offX + f.z * offZ;
    const cd = Math.cos(this.pitch) * this.dist;
    this.camera.position.set(
      cx + Math.sin(this.yaw) * cd,
      this.target.y + Math.sin(this.pitch) * this.dist,
      cz + Math.cos(this.yaw) * cd,
    );
    this.camera.lookAt(cx, this.target.y + 2, cz);
  }
}

function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
