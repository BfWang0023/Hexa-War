/**
 * 地形渲染：整张地图合并为极少数 Mesh，地块之间通过**共享棱高**自然衔接。
 *
 * 做法（《文明》系列的观感）：
 *  1. 每个格心有各自高度（岩石为山、森林/楼房略高、水域下沉、平地基准 + 确定性起伏）；
 *  2. 每个六边形顶点的高度取**共享该顶点的 3 个格**的平均值 —— 相邻地块因此完全
 *     贴合、没有缝隙，也不会出现高差断崖；但计算时对每格高度取了上限 H_SLOPE_CAP，
 *     于是岩石只在自身格内隆起，不会把周围 6 格拉成斜坡；
 *  3. 顶面 6 个三角形 + 边缘裙边（skirt），地图外圈顺势落到水面高度；
 *  4. 顶面写入逐顶点颜色（含轻微明暗抖动、按高度提亮），配合平滑法线得到自然过渡；
 *  5. 装饰物（树 / 岩石 / 楼房）、道路、桥梁、水域都是**独立合并网格或 InstancedMesh**，
 *     总绘制调用数保持在个位数；岩石装饰被限制在本格内切圆里，不覆盖邻格。
 */

import * as THREE from '../../vendor/three/three.module.js';
import {
  HEX_R, SQRT3, T, hexCorners, offsetToWorld, axialFromOffset, axialToWorld,
  tileHeight, tileRandom, H_WATER, H_WATER_BED, H_SLOPE_CAP,
} from '../core/hex.js';

/** 与顶点相邻的 6 个方向（按世界角度 0°,60°,…,300° 排列，用于顶点共享）。 */
const ANG_DIRS = [[1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1]];

/** 六边形内切圆半径：装饰物限制在这个半径内就不会越界到相邻格。 */
const HEX_INR = (HEX_R * SQRT3) / 2;
/** 单个岩石模型的最大水平半径（makeBoulder 的半径 × 最大实例缩放之外的部分）。 */
const BOULDER_R = 1.22;

function srgb(r, g, b) {
  const c = new THREE.Color();
  c.setRGB(r / 255, g / 255, b / 255, THREE.SRGBColorSpace);
  return c;
}

/* 地表配色（取自原 GUI 主题，略微提亮以适应 3D 光照） */
const COL = {
  plainA: srgb(96, 112, 68),
  plainB: srgb(74, 92, 58),
  plainDry: srgb(122, 122, 78),
  forest: srgb(70, 98, 58),
  forestDark: srgb(48, 74, 46),
  rock: srgb(126, 122, 112),
  rockDark: srgb(84, 82, 78),
  rockLit: srgb(158, 154, 144),
  bed: srgb(48, 74, 78),
  bedDeep: srgb(28, 48, 62),
  buildingLot: srgb(150, 140, 116),
  road: srgb(92, 90, 86),
  roadTile: srgb(104, 101, 96),   // 道路格的地表色（柏油）
  roadMark: srgb(214, 196, 120),
};

export class Terrain {
  constructor(world, store) {
    this.world = world;
    this.store = store;
    this.group = new THREE.Group();
    this.group.name = 'terrain';
    world.scene.add(this.group);
    this.tileTopY = new Float32Array(0);   // 每格中心高度（供单位落位）
    this.build();
  }

  dispose() {
    this.group.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
        else o.material.dispose();
      }
    });
    this.world.scene.remove(this.group);
  }

  /* ------------------------------------------------------------------ */
  /* 构建                                                               */
  /* ------------------------------------------------------------------ */

  build() {
    const store = this.store;
    const cols = store.cols, rows = store.rows;
    const grid = store.terrain;
    const q = this.world.quality;

    // 1) 每格高度
    const hOf = new Float32Array(cols * rows);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) hOf[r * cols + c] = tileHeight(grid, cols, rows, c, r);
    }
    this.hOf = hOf;
    this.tileTopY = new Float32Array(cols * rows);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        this.tileTopY[r * cols + c] = hOf[r * cols + c];
      }
    }

    // 2) 顶点共享高度表
    const vkey = (x, z) => `${Math.round(x * 100)},${Math.round(z * 100)}`;
    const vh = new Map();
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        const corners = hexCorners(w.x, w.z);
        for (let i = 0; i < 6; i++) {
          const key = vkey(corners[i][0], corners[i][1]);
          if (vh.has(key)) continue;
          const heights = [];
          for (const [dq, dr] of [ANG_DIRS[i], ANG_DIRS[(i + 1) % 6], [0, 0]]) {
            const q2 = a.q + dq, r2 = a.r + dr;
            const off = { col: q2 + ((r2 - (r2 & 1)) >> 1), row: r2 };
            if (off.col < 0 || off.row < 0 || off.col >= cols || off.row >= rows) {
              heights.push(H_WATER - 0.45);
            } else {
              // 上限让岩石只在自身格内隆起，不抬高邻格的棱
              heights.push(Math.min(hOf[off.row * cols + off.col], H_SLOPE_CAP));
            }
          }
          vh.set(key, (heights[0] + heights[1] + heights[2]) / 3);
        }
      }
    }
    this.vertexHeight = vh;
    this.vkey = vkey;

    this.buildSurface(cols, rows, hOf, vh, vkey, q);
    this.buildWater(cols, rows, grid);
    this.buildRoads(cols, rows, grid, hOf, q);
    this.buildDecor(cols, rows, grid, hOf, q);
    this.buildGrid(cols, rows);
    this.buildSurroundings(cols, rows);
    this.buildOverlays(cols, rows, hOf);
    this.buildKeypointMarkers();
    // 地形（投影体）换了，阴影贴图必须重画一次
    this.world.markShadowsDirty();
  }

  centerOf(col, row) { return offsetToWorld(col, row); }

  /** 地表高度（格中心）。 */
  heightAt(col, row) {
    if (col < 0 || row < 0 || col >= this.store.cols || row >= this.store.rows) return H_WATER - 0.45;
    return this.hOf[row * this.store.cols + col];
  }

  /* ---------------- 地表顶面 + 裙边 ---------------- */
  buildSurface(cols, rows, hOf, vh, vkey, q) {
    const pos = [];
    const colArr = [];
    const idx = [];
    let vi = 0;
    const push = (x, y, z, color) => {
      pos.push(x, y, z);
      colArr.push(color.r, color.g, color.b);
      return vi++;
    };
    const shade = (base, k) => base.clone().multiplyScalar(k);

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        const mask = this.store.mask(c, r);
        const corners = hexCorners(w.x, w.z);
        const hc = hOf[r * cols + c];
        const jitter = (tileRandom(c, r, 3) - 0.5) * 0.16;
        // 该格代表色
        let base;
        if (mask & T.WATER) base = COL.bedDeep;   // 水底统一深色，避免透出水底拼接纹路
        else if (mask & T.ROCK) base = COL.rock;
        else if (mask & T.BUILDING) base = COL.buildingLot;
        else if (mask & T.FOREST) base = COL.forest;
        else if (mask & T.ROAD) base = COL.roadTile;   // (3) 道路格整格做成柏油色平地
        else {
          const t = tileRandom(c, r, 7);
          base = COL.plainA.clone().lerp(t > 0.72 ? COL.plainDry : COL.plainB, 0.35 + t * 0.5);
        }
        if (mask & T.WATER) base = base.clone().lerp(COL.bed, 0.15 + tileRandom(c, r, 5) * 0.2);
        if (mask & T.ROCK) base = base.clone().lerp(COL.rockDark, 0.25 + tileRandom(c, r, 11) * 0.4);
        if (mask & T.FOREST) base = base.clone().lerp(COL.forestDark, 0.3 + tileRandom(c, r, 13) * 0.5);

        const cCenter = shade(base, 1 + jitter * 0.8);
        const ci = push(w.x, hc, w.z, cCenter);
        const ringStart = vi;
        const cornerY = [];
        for (let i = 0; i < 6; i++) {
          const key = vkey(corners[i][0], corners[i][1]);
          let y = vh.get(key);
          if (y === undefined) y = hc;
          // 网格顶点略微内收，形成细缝由裙边连接（避免 T 型接缝闪烁）
          cornerY.push(y);
          const rr = HEX_R * 1.001;
          const ang = Math.PI / 6 + i * Math.PI / 3;
          const px = w.x + rr * Math.cos(ang);
          const pz = w.z + rr * Math.sin(ang);
          const slope = Math.min(1, Math.abs(y - hc) / 3);
          const cc = shade(base, (1 + jitter * 0.5) * (1 - slope * 0.18));
          push(px, y, pz, cc);
        }
        for (let i = 0; i < 6; i++) {
          // 逆时针（自上而下看）→ 法线朝上；否则会被背面剔除
          idx.push(ci, ringStart + ((i + 1) % 6), ringStart + i);
        }
        // 裙边：与相邻格的高差用一圈竖直面补上，视觉上像自然的坡脚
        for (let i = 0; i < 6; i++) {
          const [dq, dr] = ANG_DIRS[i];
          const nq = a.q + dq, nr = a.r + dr;
          const noff = { col: nq + ((nr - (nr & 1)) >> 1), row: nr };
          const inside = noff.col >= 0 && noff.row >= 0 && noff.col < cols && noff.row < rows;
          const nh = inside ? hOf[noff.row * cols + noff.col] : H_WATER - 0.45;
          const myCorner = (i + 5) % 6; // 该方向对应的两个顶点
          const otherCorner = i;
          const y1 = cornerY[myCorner], y2 = cornerY[otherCorner];
          const drop = Math.min(y1, y2) - Math.min(nh, Math.min(y1, y2));
          const needSkirt = y1 > nh + 0.02 || y2 > nh + 0.02;
          if (!needSkirt) continue;
          const p1 = corners[myCorner], p2 = corners[otherCorner];
          const bottom = Math.min(y1, y2) - drop;
          const k = 0.72;
          const cTopA = shade(base, (1 + jitter * 0.4) * k);
          const cTopB = shade(base, (1 + jitter * 0.4) * k * 0.95);
          const cBotA = shade(base, k * 0.62);
          const s = vi;
          push(p1[0], y1, p1[1], cTopA);
          push(p2[0], y2, p2[1], cTopB);
          push(p2[0], bottom, p2[1], cBotA);
          push(p1[0], bottom, p1[1], cBotA);
          idx.push(s, s + 1, s + 2, s, s + 2, s + 3);
        }
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colArr, 3));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'terrain-surface';
    mesh.receiveShadow = q.shadows;
    mesh.castShadow = false;
    mesh.matrixAutoUpdate = false;
    this.group.add(mesh);
    this.surface = mesh;

    // 拾取用网格（仅顶面，三角形更少、更精确）
    const pickPos = [];
    const pickIdx = [];
    let pv = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        const corners = hexCorners(w.x, w.z);
        const hc = hOf[r * cols + c];
        const ci = pv;
        pickPos.push(w.x, hc, w.z);
        pv++;
        for (let i = 0; i < 6; i++) {
          const key = vkey(corners[i][0], corners[i][1]);
          const y = vh.get(key) ?? hc;
          pickPos.push(corners[i][0], y, corners[i][1]);
          pv++;
        }
        for (let i = 0; i < 6; i++) pickIdx.push(ci, ci + 1 + ((i + 1) % 6), ci + 1 + i);
      }
    }
    const pickGeo = new THREE.BufferGeometry();
    pickGeo.setAttribute('position', new THREE.Float32BufferAttribute(pickPos, 3));
    pickGeo.setIndex(pickIdx);
    pickGeo.computeVertexNormals();
    const pickMesh = new THREE.Mesh(pickGeo, new THREE.MeshBasicMaterial({ visible: false }));
    pickMesh.name = 'terrain-pick';
    pickMesh.matrixAutoUpdate = false;
    this.group.add(pickMesh);
    this.pickMesh = pickMesh;
  }

  /* ---------------- 水域（仅覆盖地图内的水域格） ---------------- */
  buildWater(cols, rows, grid) {
    const pos = [], uvs = [], idx = [];
    let vi = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (!(grid[r * cols + c] & T.WATER)) continue;
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        const ci = vi;
        pos.push(w.x, 0, w.z); uvs.push(w.x, w.z); vi++;
        for (let i = 0; i < 6; i++) {
          const ang = Math.PI / 6 + i * Math.PI / 3;
          const x = w.x + HEX_R * 1.004 * Math.cos(ang);
          const z = w.z + HEX_R * 1.004 * Math.sin(ang);
          pos.push(x, 0, z); uvs.push(x, z); vi++;
        }
        for (let i = 0; i < 6; i++) idx.push(ci, ci + 1 + ((i + 1) % 6), ci + 1 + i);
      }
    }
    if (!idx.length) return;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    this.waterUniforms = {
      uTime: { value: 0 },
      uDeep: { value: new THREE.Color(0x123449) },
      uShallow: { value: new THREE.Color(0x3f7fa8) },
      uSun: { value: new THREE.Vector3(0.4, 0.8, 0.3).normalize() },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.waterUniforms,
      transparent: true,
      depthWrite: false,
      vertexShader: /* glsl */`
        uniform float uTime;
        varying vec3 vWorld;
        varying float vWave;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          // 波形按世界坐标计算：相邻格的共享顶点位移一致，因此不会出现接缝
          float w = sin(wp.x * 0.09 + uTime * 1.05) * 0.5
                  + sin(wp.z * 0.13 - uTime * 0.8) * 0.5
                  + sin((wp.x + wp.z) * 0.05 + uTime * 0.5) * 0.5;
          vWave = w;
          wp.y += ${H_WATER.toFixed(2)} + w * 0.09;
          vWorld = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }`,
      fragmentShader: /* glsl */`
        uniform vec3 uDeep;
        uniform vec3 uShallow;
        uniform vec3 uSun;
        uniform float uTime;
        varying vec3 vWorld;
        varying float vWave;
        void main() {
          float nx = cos(vWorld.x * 0.09 + uTime * 1.05) * 0.05 + cos((vWorld.x + vWorld.z) * 0.05 + uTime * 0.5) * 0.04;
          float nz = cos(vWorld.z * 0.13 - uTime * 0.8) * 0.05 + cos((vWorld.x + vWorld.z) * 0.05 + uTime * 0.5) * 0.04;
          vec3 n = normalize(vec3(-nx, 1.0, -nz));
          vec3 v = normalize(cameraPosition - vWorld);
          float fres = pow(1.0 - max(dot(n, v), 0.0), 3.0);
          float spec = pow(max(dot(reflect(-uSun, n), v), 0.0), 60.0);
          vec3 col = mix(uDeep, uShallow, clamp(vWave * 0.3 + 0.5, 0.0, 1.0));
          col = mix(col, vec3(0.70, 0.83, 0.93), fres * 0.40);
          col += vec3(1.0, 0.96, 0.86) * spec * 0.8;
          gl_FragColor = vec4(col, 0.96);
          #include <colorspace_fragment>
        }`,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'water';
    mesh.renderOrder = 1;
    this.group.add(mesh);
    this.water = mesh;
  }

  /** 空中单位悬浮高度（水面之上按水面高度计算）。 */
  flyY(col, row, hover) {
    const mask = this.store.mask(col, row);
    const base = (mask & T.WATER) ? H_WATER : this.heightAt(col, row);
    return base + hover;
  }

  /* ---------------- 道路 + 桥梁 ---------------- */
  buildRoads(cols, rows, grid, hOf, q) {
    const pos = [], colArr = [], idx = [];
    let vi = 0;
    const roadCol = COL.road.clone();
    const markCol = COL.roadMark.clone();
    const pushV = (x, y, z, color) => { pos.push(x, y, z); colArr.push(color.r, color.g, color.b); return vi++; };
    const quad = (ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, color) => {
      const s = vi;
      pushV(ax, ay, az, color); pushV(bx, by, bz, color);
      pushV(cx, cy, cz, color); pushV(dx, dy, dz, color);
      idx.push(s, s + 1, s + 2, s, s + 2, s + 3);
    };

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const mask = grid[r * cols + c];
        if (!(mask & T.ROAD)) continue;
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        // 桥梁与一般道路使用完全相同的抬升量，绘制效果保持一致
        const lift = 0.07;
        // 水面上的道路以水面为基准（水域格的地形高度是水底，直接加 lift 会沉到水下）
        const surfaceY = (mask & T.WATER) ? H_WATER : hOf[r * cols + c];
        const baseY = surfaceY + lift;
        const half = 2.4;
        // 中心路块
        const corners = hexCorners(w.x, w.z, HEX_R * 0.99);
        const cIdx = vi;
        pushV(w.x, baseY, w.z, roadCol);
        for (let i = 0; i < 6; i++) {
          pushV(corners[i][0] * 0.999 + w.x * 0.001, baseY, corners[i][1] * 0.999 + w.z * 0.001, roadCol);
        }
        for (let i = 0; i < 6; i++) idx.push(cIdx, cIdx + 1 + ((i + 1) % 6), cIdx + 1 + i);
        // 与相邻道路格的连接带
        for (let i = 0; i < 6; i++) {
          const [dq, dr] = ANG_DIRS[i];
          const nq = a.q + dq, nr = a.r + dr;
          const noff = { col: nq + ((nr - (nr & 1)) >> 1), row: nr };
          if (noff.col < 0 || noff.row < 0 || noff.col >= cols || noff.row >= rows) continue;
          const nmask = grid[noff.row * cols + noff.col];
          const nw = axialToWorld(nq, nr);
          const edge = [
            (w.x + nw.x) / 2, 0, (w.z + nw.z) / 2,
          ];
          const ang = Math.PI / 6 + i * Math.PI / 3;
          const ex = w.x + HEX_R * 0.5 * Math.cos(ang);
          const ez = w.z + HEX_R * 0.5 * Math.sin(ang);
          if (!(nmask & T.ROAD)) continue;
          const ny = ((nmask & T.WATER) ? H_WATER : hOf[noff.row * cols + noff.col]) + lift;
          const perpX = Math.cos(ang + Math.PI / 2), perpZ = Math.sin(ang + Math.PI / 2);
          quad(
            w.x + perpX * half, baseY, w.z + perpZ * half,
            ex + perpX * half, (baseY + ny) / 2 + 0.02, ez + perpZ * half,
            ex - perpX * half, (baseY + ny) / 2 + 0.02, ez - perpZ * half,
            w.x - perpX * half, baseY, w.z - perpZ * half,
            roadCol,
          );
          // 中线虚线（桥梁与一般道路一致）
          const dx = (ex - w.x), dz = (ez - w.z);
          const len = Math.hypot(dx, dz);
          const ux = dx / len, uz = dz / len;
          const mx = w.x + ux * len * 0.55, mz = w.z + uz * len * 0.55;
          const seg = 1.7, wid = 0.32;
          const py = (baseY + ny) / 2 + 0.06;
          quad(
            mx + perpX * wid, py, mz + perpZ * wid,
            mx + ux * seg + perpX * wid, py, mz + uz * seg + perpZ * wid,
            mx + ux * seg - perpX * wid, py, mz + uz * seg - perpZ * wid,
            mx - perpX * wid, py, mz - perpZ * wid,
            markCol,
          );
        }
      }
    }
    if (!idx.length) return;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colArr, 3));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true }));
    mesh.name = 'roads';
    mesh.receiveShadow = q.shadows;
    mesh.matrixAutoUpdate = false;
    this.group.add(mesh);
  }

  /* ---------------- 装饰：树 / 岩石 / 楼房 ---------------- */
  buildDecor(cols, rows, grid, hOf, q) {
    const treeGeos = [makeConifer(1.0), makeConifer(0.82)];
    const treeSlots = [[], []];
    const rockSlots = [];
    const houseSlots = [[], []];

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const mask = grid[r * cols + c];
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        const y = hOf[r * cols + c];
        if (mask & T.FOREST) {
          const n = 3 + Math.floor(tileRandom(c, r, 21) * 3 * q.decor);
          for (let i = 0; i < n; i++) {
            const t = tileRandom(c, r, 40 + i * 7);
            const t2 = tileRandom(c, r, 90 + i * 13);
            const ang = t * Math.PI * 2;
            const rad = Math.sqrt(t2) * HEX_R * (mask & T.ROCK ? 0.3 : 0.74);
            treeSlots[i % 2].push({
              x: w.x + Math.cos(ang) * rad, y, z: w.z + Math.sin(ang) * rad,
              s: 0.72 + tileRandom(c, r, 120 + i) * 0.62,
              rot: tileRandom(c, r, 160 + i) * Math.PI * 2,
              tint: 0.85 + tileRandom(c, r, 200 + i) * 0.35,
            });
          }
        } else if (mask & T.ROCK) {
          const n = 3 + Math.floor(tileRandom(c, r, 33) * 3 * q.decor);
          // 该格 6 个角的高度：岩石沿山体锥面摆放，不会悬空
          const rc = hexCorners(w.x, w.z);
          let cornerAvg = 0;
          for (let i = 0; i < 6; i++) {
            const cy = this.vertexHeight.get(this.vkey(rc[i][0], rc[i][1]));
            cornerAvg += cy === undefined ? y : cy;
          }
          cornerAvg /= 6;
          for (let i = 0; i < n; i++) {
            const t = tileRandom(c, r, 60 + i * 11);
            const t2 = tileRandom(c, r, 130 + i * 17);
            const ang = t * Math.PI * 2;
            const s = 0.9 + tileRandom(c, r, 170 + i) * 1.0;
            // 关键：石块整体（半径 BOULDER_R·s）必须留在本格内切圆内，
            // 否则会探进相邻 6 格，盖住地面高亮（尤其是"可部署"格）。
            const maxRad = Math.max(0.5, HEX_INR - BOULDER_R * s - 0.15);
            const rad = Math.sqrt(t2) * maxRad;
            const f = Math.min(1, rad / HEX_R);
            rockSlots.push({
              x: w.x + Math.cos(ang) * rad,
              y: y + (cornerAvg - y) * f - 0.22,
              z: w.z + Math.sin(ang) * rad,
              s,
              rot: tileRandom(c, r, 210 + i) * Math.PI * 2,
              tilt: (tileRandom(c, r, 240 + i) - 0.5) * 0.34,
              tint: 0.8 + tileRandom(c, r, 270 + i) * 0.4,
            });
          }
        } else if (mask & T.BUILDING) {
          const v = tileRandom(c, r, 55) > 0.5 ? 1 : 0;
          houseSlots[v].push({
            x: w.x, y, z: w.z,
            rot: (Math.floor(tileRandom(c, r, 77) * 6) * Math.PI) / 3,
            s: 0.92 + tileRandom(c, r, 99) * 0.2,
          });
        }
      }
    }

    const mkInstanced = (geo, slots, opts = {}) => {
      if (!slots.length) return null;
      const mat = new THREE.MeshLambertMaterial({ vertexColors: true, ...opts.mat });
      const mesh = new THREE.InstancedMesh(geo, mat, slots.length);
      mesh.name = opts.name || 'decor';
      mesh.castShadow = !!opts.castShadow;
      mesh.receiveShadow = !!opts.receiveShadow;
      const m = new THREE.Matrix4();
      const qt = new THREE.Quaternion();
      const e = new THREE.Euler();
      const sc = new THREE.Vector3();
      const pv = new THREE.Vector3();
      const color = new THREE.Color();
      slots.forEach((s, i) => {
        e.set(opts.tilt ? s.tilt || 0 : 0, s.rot || 0, 0);
        qt.setFromEuler(e);
        sc.set(s.s, s.s * (opts.yScale || 1), s.s);
        pv.set(s.x, s.y + (opts.yOffset || 0), s.z);
        m.compose(pv, qt, sc);
        mesh.setMatrixAt(i, m);
        if (s.tint !== undefined) {
          color.setScalar(s.tint);
          mesh.setColorAt(i, color);
        }
      });
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.frustumCulled = false;
      this.group.add(mesh);
      return mesh;
    };

    mkInstanced(treeGeos[0], treeSlots[0], { name: 'trees-a', castShadow: q.treeShadows, receiveShadow: false });
    mkInstanced(treeGeos[1], treeSlots[1], { name: 'trees-b', castShadow: q.treeShadows, receiveShadow: false });
    mkInstanced(makeBoulder(), rockSlots, { name: 'rocks', castShadow: q.shadows, receiveShadow: true, tilt: true, yScale: 0.85 });
    mkInstanced(makeHouse(0), houseSlots[0], { name: 'houses-a', castShadow: q.shadows, receiveShadow: true });
    mkInstanced(makeHouse(1), houseSlots[1], { name: 'houses-b', castShadow: q.shadows, receiveShadow: true });
  }

  /* ---------------- 六角网格线（可切换） ---------------- */
  buildGrid(cols, rows) {
    const pos = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const a = axialFromOffset(c, r);
        const w = axialToWorld(a.q, a.r);
        // 水域格把网格画在水面上（水底在下沉的水底高度，否则水面上的格子看不到线）
        const mask = this.store.mask(c, r);
        const water = !!(mask & T.WATER);
        const hc = this.hOf[r * cols + c];
        const corners = hexCorners(w.x, w.z, HEX_R * 0.995);
        // 陆地格把网格线贴着坡面画（否则在岩石边坡上会被地表盖住）；
        // 水域格仍画在水面上（水底在下沉的水底高度，否则水面上的格子看不到线）
        const ys = corners.map((p) => {
          if (water) return H_WATER + 0.06;
          const y = this.vertexHeight.get(this.vkey(p[0], p[1]));
          return (y === undefined ? hc : y) + 0.09;
        });
        for (let i = 0; i < 6; i++) {
          const p1 = corners[i], p2 = corners[(i + 1) % 6];
          pos.push(p1[0], ys[i], p1[1], p2[0], ys[(i + 1) % 6], p2[1]);
        }
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    const mat = new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.34 });
    this.gridLines = new THREE.LineSegments(geo, mat);
    this.gridLines.visible = false;
    this.gridLines.matrixAutoUpdate = false;
    this.group.add(this.gridLines);
  }

  /* ---------------- 地图外围：纯黑背景板（地图之外一律黑色） ---------------- */
  buildSurroundings(cols, rows) {
    const w = SQRT3 * HEX_R * (cols + 1);
    const d = 1.5 * HEX_R * (rows + 1);
    const geo = new THREE.PlaneGeometry(w * 12, d * 12, 1, 1);
    const mat = new THREE.MeshBasicMaterial({ color: srgb(6, 7, 8) });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(w / 2 - SQRT3 * HEX_R * 0.5, H_WATER - 1.2, d / 2 - 9);
    mesh.receiveShadow = false;
    mesh.matrixAutoUpdate = false;
    mesh.updateMatrix();
    this.group.add(mesh);
  }

  /* ---------------- 叠加层：高亮 / 部署区 / 迷雾 ---------------- */
  buildOverlays(cols, rows, hOf) {
    const capacity = cols * rows;
    const mk = (color, opacity, order, blend = THREE.NormalBlending) => {
      const mat = new THREE.MeshBasicMaterial({
        color, transparent: true, opacity, depthWrite: false,
        side: THREE.DoubleSide, blending: blend,
      });
      // 顶点按地形坡面抬降：否则高亮是平台，会被上坡的地表"吞掉"半张脸
      mat.onBeforeCompile = (shader) => {
        shader.vertexShader = shader.vertexShader
          .replace('#include <common>', `#include <common>
attribute float aCorner;
attribute vec4 aH0;
attribute vec4 aH1;`)
          .replace('#include <begin_vertex>', `#include <begin_vertex>
{
  float dY = 0.0;
  if (aCorner > 5.5) dY = aH1.y;
  else if (aCorner > 4.5) dY = aH1.x;
  else if (aCorner > 3.5) dY = aH0.w;
  else if (aCorner > 2.5) dY = aH0.z;
  else if (aCorner > 1.5) dY = aH0.y;
  else if (aCorner > 0.5) dY = aH0.x;
  transformed.y += dY;
}`);
      };
      const mesh = new THREE.InstancedMesh(makeOverlayHex(capacity), mat, capacity);
      mesh.count = 0;
      mesh.frustumCulled = false;
      mesh.renderOrder = order;
      this.group.add(mesh);
      return mesh;
    };
    this.ovReach = mk(0x5ad278, 0.34, 4);
    this.ovAttack = mk(0xeb5046, 0.42, 4);
    this.ovBlocked = mk(0xaaaaaa, 0.16, 4);
    this.ovArty = mk(0xf0c850, 0.26, 4);
    this.ovBoard = mk(0x78e6aa, 0.34, 4);
    this.ovDisembark = mk(0x50c8e6, 0.38, 4);
    this.ovSupply = mk(0x7ee08a, 0.3, 4);
    this.ovDeploy = mk(0x50c8e6, 0.16, 3);
    this.ovDeployEdge = mk(0x6edcf5, 0.34, 5);
    this.ovFogDark = mk(0x2b3230, 0.82, 6);
    this.ovFogDim = mk(0x6a7270, 0.34, 6);
    this.ovSimul = mk(0xffc85a, 0.4, 5);
    this.overlays = {
      reach: this.ovReach, attack: this.ovAttack, blocked: this.ovBlocked, arty: this.ovArty,
      board: this.ovBoard, disembark: this.ovDisembark, supply: this.ovSupply,
    };
    this._m4 = new THREE.Matrix4();
    this._q = new THREE.Quaternion();
    this._v = new THREE.Vector3();
    this._s = new THREE.Vector3(1, 1, 1);
    this._cornerRel = new Float32Array(6);
  }

  /** 写入某一高亮层的实例数据。**格集合没变就整层跳过**：
   *  状态更新很频繁，但多数层（可达/可攻击/部署区…）在两次更新之间完全一样，
   *  没必要把几百个实例矩阵与角高重新算一遍再上传一遍显存。 */
  setInstances(mesh, cells, lift = 0.14) {
    if (!mesh) return;
    const n = cells.length;
    let cache = mesh.userData.__cells;
    if (cache && cache.length === n * 2) {
      let same = true;
      for (let k = 0; k < n; k++) {
        const cell = cells[k];
        if (cache[k * 2] !== cell[0] || cache[k * 2 + 1] !== cell[1]) { same = false; break; }
      }
      if (same) return;
    } else {
      cache = new Int32Array(n * 2);   // 空数组是合法的：0 个格也要能"记住"
      mesh.userData.__cells = cache;
    }
    for (let k = 0; k < n; k++) { cache[k * 2] = cells[k][0]; cache[k * 2 + 1] = cells[k][1]; }
    const cols = this.store.cols, rows = this.store.rows;
    const aH0 = mesh.geometry.getAttribute('aH0');
    const aH1 = mesh.geometry.getAttribute('aH1');
    const rel = this._cornerRel;
    let i = 0;
    for (const cell of cells) {
      const [c, r] = cell;
      if (c < 0 || r < 0 || c >= cols || r >= rows) continue;
      const w = offsetToWorld(c, r);
      const cy = this.hOf[r * cols + c];
      this._v.set(w.x, cy + lift, w.z);
      this._m4.compose(this._v, this._q, this._s);
      mesh.setMatrixAt(i, this._m4);
      // 6 个角相对格心的高度差（与地表用同一套共享棱高，因此完全贴合）
      const corners = hexCorners(w.x, w.z);
      for (let k = 0; k < 6; k++) {
        const y = this.vertexHeight.get(this.vkey(corners[k][0], corners[k][1]));
        rel[k] = (y === undefined ? cy : y) - cy;
      }
      aH0.setXYZW(i, rel[0], rel[1], rel[2], rel[3]);
      aH1.setXYZW(i, rel[4], rel[5], 0, 0);
      i++;
    }
    mesh.count = i;
    mesh.instanceMatrix.needsUpdate = true;
    aH0.needsUpdate = true;
    aH1.needsUpdate = true;
  }

  /** 更新所有高亮层（每次状态变化时调用）。`fogVisual=false` 时不画任何迷雾。 */
  updateHighlights(state, fogVisual = false) {
    const hl = state?.highlights || {};
    this.setInstances(this.ovReach, hl.reachable || [], 0.13);
    this.setInstances(this.ovAttack, hl.attackable || [], 0.16);
    this.setInstances(this.ovBlocked, hl.blocked || [], 0.15);
    this.setInstances(this.ovArty, hl.howitzer || [], 0.13);
    this.setInstances(this.ovBoard, hl.board || [], 0.2);
    this.setInstances(this.ovDisembark, hl.disembark || [], 0.2);
    this.setInstances(this.ovSupply, hl.supply || [], 0.2);
    this.setInstances(this.ovSimul, (state?.simulOrders || []).map(o => o.target), 0.22);
    const deploy = state?.deployCells || [];
    this.setInstances(this.ovDeploy, deploy, 0.1);
    this.setInstances(this.ovDeployEdge, deploy, 0.12);
    // 迷雾：默认整体关闭（有无视野显示相同）；仅在设置里显式开启时才绘制
    const fogOn = !!fogVisual && state && !state.deploying && !state.testMode;
    const fog = fogOn ? (state.fog || { revealed: [], dims: [] }) : { revealed: [], dims: [] };
    const revealed = new Set((fog.revealed || []).map(h => h[0] + ',' + h[1]));
    const dims = new Set((fog.dims || []).map(d => d.h[0] + ',' + d.h[1]));
    const dark = [], dim = [];
    for (let r = 0; r < this.store.rows; r++) {
      for (let c = 0; c < this.store.cols; c++) {
        const key = c + ',' + r;
        if (!revealed.has(key)) dark.push([c, r]);
        else if (dims.has(key)) dim.push([c, r]);
      }
    }
    if (!fogOn) { dark.length = 0; dim.length = 0; }
    this.setInstances(this.ovFogDark, dark, 0.3);
    this.setInstances(this.ovFogDim, dim, 0.28);
  }

  /* ---------------- 关键据点标记 ---------------- */
  /* 大本营：以格中心为圆心的 3 个同心圆（最大半径 = 1.5 × 格外接圆半径，即 9m）
     关键据点：用阵营色的加粗六边形边线框住该格（半径略大于格外接圆，覆盖细网格线） */
  buildKeypointMarkers() {
    this.kpGroup = new THREE.Group();
    this.kpGroup.name = 'keypoints';
    this.group.add(this.kpGroup);
    this.kpMeshes = [];
    // 同心圆（32 段）与六边形粗边（6 段，起始角 30° 与地块朝向一致）
    const ringGeos = [
      flatRing(1.5 * HEX_R, 1.5 * HEX_R - 0.55, 40),
      flatRing(1.15 * HEX_R, 1.15 * HEX_R - 0.5, 40),
      flatRing(0.8 * HEX_R, 0.8 * HEX_R - 0.45, 40),
    ];
    const hexBandGeo = flatRing(HEX_R * 1.02, HEX_R * 0.86, 6, Math.PI / 6);
    for (let i = 0; i < 24; i++) {
      const g = new THREE.Group();
      const mats = [];
      const rings = ringGeos.map((geo) => {
        const m = new THREE.MeshBasicMaterial({
          color: 0x3c78f0, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false,
        });
        mats.push(m);
        const mesh = new THREE.Mesh(geo, m);
        mesh.renderOrder = 7;
        g.add(mesh);
        return mesh;
      });
      const bandMat = new THREE.MeshBasicMaterial({
        color: 0x3c78f0, transparent: true, opacity: 0.95, side: THREE.DoubleSide, depthWrite: false,
      });
      mats.push(bandMat);
      const band = new THREE.Mesh(hexBandGeo, bandMat);
      band.renderOrder = 9;   // 高于细网格线，避免被压住
      g.add(band);
      g.visible = false;
      this.kpGroup.add(g);
      this.kpMeshes.push({ group: g, rings, band, mats });
    }
  }

  updateKeypoints(keypoints) {
    const list = keypoints || [];
    this.kpMeshes.forEach((m, i) => {
      const kp = list[i];
      if (!kp) { m.group.visible = false; return; }
      const [c, r] = kp.h;
      const w = offsetToWorld(c, r);
      const y = this.heightAt(c, r);
      const isWater = !!(this.store.mask(c, r) & T.WATER);
      const baseY = (isWater ? H_WATER : y) + 0.16;
      m.group.position.set(w.x, baseY, w.z);
      m.group.visible = true;
      const blue = kp.controller === 'blue';
      const col = blue ? 0x4a9bf0 : 0xef5a4a;
      for (const mm of m.mats) { mm.color.setHex(col); mm.opacity = 0.9; }
      const isHq = !!kp.center;
      m.rings.forEach(ring => { ring.visible = isHq; });
      m.band.visible = !isHq;
    });
  }

  /** 烟雾弹：格子上方的白色烟团（随剩余回合缓慢翻滚）。 */
  updateSmoke(list, time) {
    if (!this.smokeGroup) {
      this.smokeGroup = new THREE.Group();
      this.smokeGroup.name = 'smoke';
      this.group.add(this.smokeGroup);
      this.smokeMeshes = [];
      const geo = new THREE.IcosahedronGeometry(1, 1);
      for (let i = 0; i < 40; i++) {
        const mat = new THREE.MeshLambertMaterial({
          color: 0xe8e8e2, transparent: true, opacity: 0.55, depthWrite: false,
        });
        const m = new THREE.Mesh(geo, mat);
        m.visible = false;
        m.renderOrder = 3;
        this.smokeGroup.add(m);
        this.smokeMeshes.push({ mesh: m, mat, phase: i * 1.7 });
      }
    }
    const cells = [];
    for (const s of list || []) {
      const [c, r] = s.h;
      cells.push({ c, r, turns: s.turns });
      if (cells.length >= 13) break;
    }
    let idx = 0;
    for (const cell of cells) {
      const base = offsetToWorld(cell.c, cell.r);
      const y = this.heightAt(cell.c, cell.r);
      for (let k = 0; k < 3 && idx < this.smokeMeshes.length; k++, idx++) {
        const o = this.smokeMeshes[idx];
        const ang = o.phase + time * 0.25;
        const rad = 2.2 + k * 1.3;
        o.mesh.visible = true;
        o.mesh.position.set(
          base.x + Math.cos(ang + k * 2.1) * rad,
          y + 1.6 + k * 1.15 + Math.sin(time * 0.7 + o.phase) * 0.35,
          base.z + Math.sin(ang + k * 2.1) * rad,
        );
        const sc = 3.2 + Math.sin(time * 0.9 + o.phase) * 0.3;
        o.mesh.scale.setScalar(sc);
        o.mat.opacity = (cell.turns <= 1 ? 0.34 : 0.52) - k * 0.06;
      }
    }
    for (; idx < this.smokeMeshes.length; idx++) this.smokeMeshes[idx].mesh.visible = false;
  }

  update(dt, time) {
    if (this.waterUniforms && this.world.quality.waterAnim) {
      this.waterUniforms.uTime.value = time;
    }
  }

  setGridVisible(v) { if (this.gridLines) this.gridLines.visible = v; }
}

/* ====================================================================== */
/* 几何构件                                                                */
/* ====================================================================== */

/** 平放在地面（XZ 平面）上的一段圆环；segments=6 且 thetaStart=30° 时即为六边形边带。 */
function flatRing(outer, inner, segments = 32, thetaStart = 0) {
  const geo = new THREE.RingGeometry(Math.max(0.05, inner), outer, segments, 1, thetaStart, Math.PI * 2);
  geo.rotateX(-Math.PI / 2);
  return geo;
}

/** 一个六边形（朝上），用于各类叠加层。 */
function makeFlatHex() {
  const pos = [0, 0, 0];
  const idx = [];
  for (let i = 0; i < 6; i++) {
    const ang = Math.PI / 6 + i * Math.PI / 3;
    pos.push(Math.cos(ang) * HEX_R * 0.965, 0, Math.sin(ang) * HEX_R * 0.965);
  }
  for (let i = 0; i < 6; i++) idx.push(0, 1 + ((i + 1) % 6), 1 + i);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/**
 * 叠加层专用六边形：额外带 `aCorner`（顶点编号：0=格心、1..6=六个角）
 * 与逐实例的角高差 `aH0`/`aH1`（每实例各 4 个分量），顶点着色器据此让高亮贴着坡面绘制。
 * 每个图层各持一份（逐实例属性不能跨图层共享），`capacity` 必须 ≥ 该层可能出现的实例数。
 */
function makeOverlayHex(capacity) {
  const g = makeFlatHex();
  const n = 7;
  const idx = new Float32Array(n);
  for (let i = 0; i < n; i++) idx[i] = i;
  g.setAttribute('aCorner', new THREE.BufferAttribute(idx, 1));
  g.setAttribute('aH0', new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4));
  g.setAttribute('aH1', new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4));
  return g;
}

/** 针叶树：树干 + 两层锥形树冠（顶点色）。 */
function makeConifer(scale = 1) {
  const parts = [];
  const trunk = new THREE.CylinderGeometry(0.22, 0.3, 1.5, 5);
  trunk.translate(0, 0.75, 0);
  paintGeometry(trunk, srgb(84, 62, 40));
  parts.push(trunk);
  const c1 = new THREE.ConeGeometry(1.7, 3.1, 8);
  c1.translate(0, 2.3, 0);
  paintGeometry(c1, srgb(42, 80, 46));
  parts.push(c1);
  const c2 = new THREE.ConeGeometry(1.2, 2.5, 8);
  c2.translate(0, 3.8, 0);
  paintGeometry(c2, srgb(58, 108, 60));
  parts.push(c2);
  const geo = mergeGeometries(parts);
  geo.scale(scale, scale, scale);
  return geo;
}

/** 不规则岩石。 */
function makeBoulder() {
  const g = new THREE.IcosahedronGeometry(1, 1);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const k = 0.82 + ((i * 37) % 13) / 30;
    const y = p.getY(i);
    p.setXYZ(i, p.getX(i) * k, Math.max(0.02, y * 0.9 + 0.12) * k * 0.85, p.getZ(i) * k);
  }
  g.computeVertexNormals();
  paintGeometry(g, srgb(124, 120, 110));
  return g;
}

/** 上色立方体（本文件内的小工具，与 models.js 的 box 同义）。 */
function box(w, h, d, color, x = 0, y = 0, z = 0) {
  const geo = new THREE.BoxGeometry(w, h, d);
  geo.translate(x, y, z);
  paintGeometry(geo, color);
  return geo;
}

/** 双坡屋顶（脊线沿 X 轴），带出檐。 */
function gableRoof(w, d, h, color, x = 0, y = 0, z = 0) {
  const hw = w / 2, hd = d / 2;
  const v = [
    -hw, 0, -hd, hw, 0, -hd, hw, 0, hd, -hw, 0, hd,       // 檐口 0..3
    -hw, h, 0, hw, h, 0,                                    // 屋脊 4,5
  ];
  const idx = [
    0, 1, 5, 0, 5, 4,      // 北坡
    3, 4, 5, 3, 5, 2,      // 南坡
    0, 4, 3,               // 西山墙
    1, 2, 5,               // 东山墙
  ];
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  geo.translate(x, y, z);
  paintGeometry(geo, color);
  return geo;
}

/** 简易民居：墙体 + 双坡屋顶 + 门窗 + 烟囱（顶点色）。 */
function makeHouse(variant = 0) {
  const parts = [];
  const w = 5.6, d = 4.4, h = 3.0;
  const body = new THREE.BoxGeometry(w, h, d);
  body.translate(0, h / 2, 0);
  paintGeometry(body, srgb(variant ? 168 : 190, variant ? 158 : 170, variant ? 138 : 142));
  parts.push(body);
  // 勒脚
  parts.push(box(w + 0.2, 0.32, d + 0.2, srgb(120, 112, 96), 0, 0.16, 0));
  // 屋顶
  const roofCol = variant ? srgb(128, 66, 52) : srgb(146, 78, 58);
  parts.push(gableRoof(w + 0.8, d + 0.8, 1.5, roofCol, 0, h, 0));
  // 烟囱
  parts.push(box(0.7, 1.9, 0.7, srgb(122, 96, 84), w * 0.28, h + 1.0, -d * 0.22));
  // 门
  parts.push(box(1.1, 1.9, 0.2, srgb(84, 66, 48), 0, 0.95, d / 2 + 0.02));
  // 窗（正面两扇 + 侧面各一扇）
  for (const sx of [-1.7, 1.7]) {
    parts.push(box(1.0, 0.9, 0.2, srgb(226, 206, 156), sx, 1.9, d / 2 + 0.02));
  }
  parts.push(box(0.2, 0.9, 1.0, srgb(220, 200, 152), w / 2 + 0.02, 1.9, 0));
  return mergeGeometries(parts);
}

/** 据点旗（杆 + 三角旗）。 */
function makeFlag() {
  const parts = [];
  const pole = new THREE.CylinderGeometry(0.12, 0.12, 7.5, 5);
  pole.translate(0, 3.75, 0);
  paintGeometry(pole, srgb(230, 226, 214));
  parts.push(pole);
  const flag = new THREE.BufferGeometry();
  flag.setAttribute('position', new THREE.Float32BufferAttribute([
    0.1, 7.2, 0, 3.4, 6.4, 0, 0.1, 5.7, 0,
  ], 3));
  flag.setIndex([0, 1, 2]);
  flag.computeVertexNormals();
  parts.push(flag);
  return mergeGeometries(parts);
}

function makeStar() {
  const shape = new THREE.Shape();
  const R = 2.4, r = 1.05;
  for (let i = 0; i < 10; i++) {
    const ang = -Math.PI / 2 + i * Math.PI / 5;
    const rad = i % 2 === 0 ? R : r;
    const x = Math.cos(ang) * rad, y = Math.sin(ang) * rad;
    if (i === 0) shape.moveTo(x, y); else shape.lineTo(x, y);
  }
  shape.closePath();
  const g = new THREE.ExtrudeGeometry(shape, { depth: 0.3, bevelEnabled: false });
  g.rotateX(-Math.PI / 2);
  g.translate(0, 4.6, 0);
  paintGeometry(g, srgb(240, 240, 230));
  return g;
}

/** 给几何体写入统一顶点色。 */
export function paintGeometry(geo, color) {
  const count = geo.attributes.position.count;
  const arr = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    arr[i * 3] = color.r; arr[i * 3 + 1] = color.g; arr[i * 3 + 2] = color.b;
  }
  geo.setAttribute('color', new THREE.Float32BufferAttribute(arr, 3));
  return geo;
}

/** 合并多个带顶点色的 BufferGeometry（不引入 addons，自己实现）。 */
export function mergeGeometries(geos) {
  let vcount = 0, icount = 0;
  for (const g of geos) {
    vcount += g.attributes.position.count;
    icount += g.index ? g.index.count : g.attributes.position.count;
  }
  const pos = new Float32Array(vcount * 3);
  const nor = new Float32Array(vcount * 3);
  const col = new Float32Array(vcount * 3);
  const idx = new Uint32Array(icount);
  let vo = 0, io = 0;
  for (const g of geos) {
    if (!g.attributes.normal) g.computeVertexNormals();
    const p = g.attributes.position, n = g.attributes.normal, c = g.attributes.color;
    pos.set(p.array.subarray(0, p.count * 3), vo * 3);
    nor.set(n.array.subarray(0, n.count * 3), vo * 3);
    if (c) col.set(c.array.subarray(0, c.count * 3), vo * 3);
    else col.fill(1, vo * 3, vo * 3 + p.count * 3);
    if (g.index) {
      for (let i = 0; i < g.index.count; i++) idx[io + i] = g.index.array[i] + vo;
      io += g.index.count;
    } else {
      for (let i = 0; i < p.count; i++) idx[io + i] = i + vo;
      io += p.count;
    }
    vo += p.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('color', new THREE.BufferAttribute(col, 3));
  out.setIndex(new THREE.BufferAttribute(idx, 1));
  return out;
}

export { srgb };
