/**
 * 单位层：把状态里的单位映射为 3D 视图 + HTML 悬浮标记（编号 / 血条 / 状态图标）。
 *
 * 「不同单位在不同地块上的视觉效果自适应」：
 *  - 高度：贴合地块高度（岩石上的直升机飞得更高、楼房里的步兵在屋中/屋顶）；
 *  - 森林：步兵缩小并压暗，融进树影；车辆照常；
 *  - 楼房：步兵未登屋顶时贴在楼脚（半掩），登屋顶则站在屋顶；
 *  - 道路：车辆自动对齐道路走向；
 *  - 水域：只有空中单位可停留，悬浮高度略降并带波纹环；
 *  - 朝向：默认面向敌方（蓝→东、红→西），移动/开火后按实际方向平滑转向。
 */

import * as THREE from '../../vendor/three/three.module.js';
import { offsetToWorld, T, axialFromOffset, axialToWorld } from '../core/hex.js';
import { getModel, soldierCount } from './models.js';

const AIR_HOVER = 7.2;

export class UnitLayer {
  constructor(world, terrain, store, overlayEl) {
    this.world = world;
    this.terrain = terrain;
    this.store = store;
    this.overlay = overlayEl;
    this.group = new THREE.Group();
    this.group.name = 'units';
    world.scene.add(this.group);
    this.views = new Map();     // key -> view
    this.rings = new THREE.Group();  // 选中/悬停环
    this.group.add(this.rings);
    this.selectedKey = null;
    this.hoverKey = null;
    // 叠加层尺寸缓存：每帧读 clientWidth/clientHeight 会在 DOM 脏时触发同步重排，
    // 而标记每帧都在写 style —— 正好把布局弄脏。这里只在窗口尺寸变化时失效。
    this._ovW = 0;
    this._ovH = 0;
    window.addEventListener('resize', () => { this._ovW = 0; this._ovH = 0; });
  }

  overlaySize() {
    if (!this._ovW) {
      this._ovW = this.overlay.clientWidth || window.innerWidth;
      this._ovH = this.overlay.clientHeight || window.innerHeight;
    }
    return { w: this._ovW, h: this._ovH };
  }

  key(team, label) { return team + ':' + label; }

  viewOf(team, label) { return this.views.get(this.key(team, label)) || null; }

  /** 根据最新状态增删改单位视图。`hold` 中的单位正处于移动动画中，本帧不更新目标位置。 */
  sync(state, hold = null, markVisible = true, hideUndetected = true) {
    this.marksVisible = markVisible;
    const seen = new Set();
    // 战争迷雾「机制」：视野外的敌军不渲染（藏在普通地图上，进入视野才显现）。
    // 试验模式是自由沙盘（与原 GUI 一致：敌人全显、视野外压暗），因此不隐藏。
    const hide = hideUndetected && !state?.testMode;
    const units = (state?.units || []).filter(u =>
      !u.ghost && (!hide || u.team === 'blue' || u.visible !== false));
    let casterChanged = false;
    for (const u of units) {
      const k = this.key(u.team, u.label);
      seen.add(k);
      let v = this.views.get(k);
      if (!v) {
        v = this.createView(u);
        this.views.set(k, v);
        casterChanged = true;
      }
      this.updateViewFromUnit(v, u, hold && hold.has(k));
    }
    for (const [k, v] of [...this.views]) {
      if (!seen.has(k)) {
        this.disposeView(v);
        this.views.delete(k);
        casterChanged = true;
      }
    }
    if (casterChanged) this.world.markShadowsDirty();
    this.syncRings(state);
  }

  /** 幽灵（最后已知敌方位置）单独一层：半透明问号牌。 */
  syncGhosts(ghosts) {
    if (!this.ghostGroup) {
      this.ghostGroup = new THREE.Group();
      this.group.add(this.ghostGroup);
      this.ghostMeshes = [];
    }
    const list = ghosts || [];
    while (this.ghostMeshes.length < list.length) {
      const m = new THREE.Mesh(
        new THREE.CylinderGeometry(1.9, 1.9, 0.3, 12),
        new THREE.MeshLambertMaterial({ color: 0x5a6260, transparent: true, opacity: 0.75 }),
      );
      this.ghostGroup.add(m);
      this.ghostMeshes.push(m);
    }
    this.ghostMeshes.forEach((m, i) => {
      const g = list[i];
      if (!g) { m.visible = false; return; }
      const [c, r] = g.h;
      const w = offsetToWorld(c, r);
      m.position.set(w.x, this.terrain.heightAt(c, r) + 0.4, w.z);
      m.visible = true;
    });
  }

  createView(u) {
    const model = getModel(u.kind, u.team, { hp: u.hp, deployed: u.deployed });
    const material = new THREE.MeshLambertMaterial({ vertexColors: true });
    const body = new THREE.Mesh(model.bodyGeo, material);
    body.castShadow = this.world.quality.shadows;
    body.receiveShadow = false;
    const g = new THREE.Group();
    g.add(body);
    let turret = null, turretPivot = null;
    if (model.turretGeo) {
      turretPivot = new THREE.Group();
      turretPivot.position.set(...model.turretPivot);
      turret = new THREE.Mesh(model.turretGeo, material);
      turret.castShadow = this.world.quality.shadows;
      turretPivot.add(turret);
      g.add(turretPivot);
    }
    const rotors = [];
    if (model.rotors) {
      for (const rd of model.rotors) {
        const pivot = new THREE.Group();
        pivot.position.set(rd.x, rd.y, rd.z);
        if (rd.axis === 'z') pivot.rotation.z = Math.PI / 2;
        const blades = new THREE.Mesh(rd.bladesGeo, material);
        pivot.add(blades);
        let disc = null;
        if (rd.discGeo) {
          disc = new THREE.Mesh(rd.discGeo, new THREE.MeshBasicMaterial({
            color: 0xb9c0c2, transparent: true, opacity: 0.1, depthWrite: false, side: THREE.DoubleSide,
          }));
          pivot.add(disc);
        }
        g.add(pivot);
        rotors.push({ pivot, speed: rd.speed, phase: rd.phase || 0 });
      }
    }
    this.group.add(g);
    g.userData.__view = null;
    // HTML 标记
    const el = document.createElement('div');
    el.className = 'u-mark';
    el.innerHTML = '<span class="u-label"></span><span class="u-bar"><i></i></span><span class="u-icons"></span>';
    el.dataset.key = this.key(u.team, u.label);
    this.overlay.appendChild(el);
    const view = {
      key: this.key(u.team, u.label),
      team: u.team, label: u.label, kind: u.kind,
      unit: u, group: g, body, material, turret, turretPivot, rotors, el,
      heading: u.team === 'blue' ? 0 : Math.PI,
      desiredHeading: u.team === 'blue' ? 0 : Math.PI,
      pos: new THREE.Vector3(), target: new THREE.Vector3(),
      turretHeading: u.team === 'blue' ? 0 : Math.PI,
      desiredTurret: u.team === 'blue' ? 0 : Math.PI,
      hp: u.hp, maxHp: u.maxHp,
      flash: 0, dead: false, dying: null,
      bobPhase: Math.random() * Math.PI * 2,
      lastHp: u.hp,
      model,
    };
    const [c, r] = u.h;
    const w = offsetToWorld(c, r);
    view.pos.set(w.x, this.groundY(u, c, r), w.z);
    view.target.copy(view.pos);
    g.userData.__view = view;
    return view;
  }

  /** 单位所在位置的地面高度（含地形自适应偏移）。 */
  groundY(u, col, row) {
    const base = this.terrain.heightAt(col, row);
    const mask = this.store.mask(col, row);
    if (u.air) {
      // 水面上按水面高度悬浮（水底比水面低，否则直升机会掉进水里）
      return this.terrain.flyY(col, row, mask & T.WATER ? AIR_HOVER - 1.0 : AIR_HOVER);
    }
    if (mask & T.BUILDING) {
      if (u.rooftop) return base + 3.55;
      return base + 0.35;
    }
    if (mask & T.ROCK) return base;
    return base + 0.05;
  }

  /** 道路方向（车辆对齐路面走向）。 */
  roadHeading(col, row) {
    const a = axialFromOffset(col, row);
    let sumX = 0, sumZ = 0, n = 0;
    for (const [dq, dr] of [[1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1]]) {
      const nq = a.q + dq, nr = a.r + dr;
      const off = { col: nq + ((nr - (nr & 1)) >> 1), row: nr };
      if (!this.store.inBounds(off.col, off.row)) continue;
      if (!(this.store.mask(off.col, off.row) & T.ROAD)) continue;
      const w = axialToWorld(nq, nr);
      const c = axialToWorld(a.q, a.r);
      sumX += w.x - c.x;
      sumZ += w.z - c.z;
      n++;
    }
    if (!n) return null;
    return Math.atan2(sumZ, sumX);
  }

  updateViewFromUnit(v, u, holdPosition = false) {
    v.unit = u;
    const [c, r] = u.h;
    const w = offsetToWorld(c, r);
    const y = this.groundY(u, c, r);
    if (!holdPosition) v.target.set(w.x, y, w.z);
    // 模型变体（步兵人数随血量、榴弹炮架设状态）
    const needModel = (u.hp !== v.hp && !u.air && (u.kind === 'rifleman' || u.kind === 'elite_infantry'
      || u.kind === 'special_forces' || u.kind === 'atgm' || u.kind === 'javelin'
      || u.kind === 'aa_infantry' || u.kind === 'hmg_gunner'))
      || (u.kind === 'howitzer' && (v.model ? v.model.kind === 'howitzer' : false)
        && ((v.model.turretGeo === null) !== !u.deployed) === false);
    const deployedChanged = u.kind === 'howitzer' && v.deployedState !== u.deployed;
    if (needModel || deployedChanged || !v.model) {
      const model = getModel(u.kind, u.team, { hp: u.hp, deployed: u.deployed });
      if (model.bodyGeo !== v.model.bodyGeo) {
        v.body.geometry = model.bodyGeo;
        if (v.turret && model.turretGeo) v.turret.geometry = model.turretGeo;
      }
      v.model = model;
      v.deployedState = u.deployed;
    }
    v.hp = u.hp;
    v.maxHp = u.maxHp;
    // 朝向：优先保持移动/开火朝向，否则面向敌方
    if (!v.moving) {
      const road = (this.store.mask(c, r) & T.ROAD) && !u.air && !v.model.foot ? this.roadHeading(c, r) : null;
      v.desiredHeading = road !== null ? road : (u.team === 'blue' ? 0 : Math.PI);
    }
    // 标记内容
    this.updateMark(v, u);
    // 地形自适应微调
    let scale = 1;
    let tint = 1;
    const mask = this.store.mask(c, r);
    if (v.model.foot) {
      if (mask & T.FOREST) { scale = 0.9; tint = 0.86; }
      if (mask & T.BUILDING && !u.rooftop) { scale = 0.88; tint = 0.92; }
      if (mask & T.BUILDING && u.rooftop) { scale = 0.95; tint = 1.05; }
    }
    v.group.scale.setScalar(scale);
    v.tint = tint;
  }

  updateMark(v, u) {
    const own = u.team === 'blue';
    const el = v.el;
    el.classList.toggle('own', own);
    el.classList.toggle('enemy', !own);
    el.classList.toggle('ghost', !!u.ghost);
    el.classList.toggle('selected', this.selectedKey === v.key);
    el.classList.toggle('dim', u.visible === false);
    el.classList.toggle('spent', own && u.actions === 0);
    const label = el.querySelector('.u-label');
    label.textContent = u.label;
    const bar = el.querySelector('.u-bar');
    const pct = u.maxHp > 0 ? Math.max(0, u.hp) / u.maxHp : 0;
    bar.firstChild.style.width = (pct * 100).toFixed(0) + '%';
    bar.style.opacity = u.hp >= u.maxHp && u.maxHp > 0 ? '0.55' : '1';
    const icons = el.querySelector('.u-icons');
    let ic = '';
    if (u.passengers && u.passengers.length) ic += '▪'.repeat(Math.min(4, u.passengers.length));
    if (u.deployed) ic += '◎';
    if (u.suppression > 0) ic += '⚡' + u.suppression;
    if (u.adUses > 0) ic += '🛡';
    if (u.actions === 0 && own) ic += '○';
    if (u.modeName && u.missileMode) ic += 'M';
    if (u.aaMode) ic += 'A';
    if (u.rooftop) ic += '🪜';
    icons.textContent = ic;
  }

  syncRings(state) {
    if (!this.ringMesh) {
      const geo = new THREE.RingGeometry(6.4, 7.0, 6, 1);
      geo.rotateX(-Math.PI / 2);
      geo.rotateY(Math.PI / 6);
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffffff, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false,
      });
      this.ringMesh = new THREE.Mesh(geo, mat);
      this.ringMesh.visible = false;
      this.ringMesh.renderOrder = 8;
      this.rings.add(this.ringMesh);
    }
    const sel = state?.selected;
    if (!sel) { this.ringMesh.visible = false; this.selectedKey = null; return; }
    const [c, r] = sel.h;
    const w = offsetToWorld(c, r);
    const u = this.store.unitAt(c, r, !!sel.air);
    const y = this.terrain.heightAt(c, r) + 0.22;
    this.ringMesh.position.set(w.x, y, w.z);
    this.ringMesh.visible = true;
    this.selectedKey = u ? this.key(u.team, u.label) : null;
  }

  disposeView(v) {
    this.group.remove(v.group);
    v.material.dispose();
    v.el.remove();
  }

  /** 每帧：位置/朝向平滑、旋翼、命中闪白、标记投影。
   *  性能要点：①叠加层尺寸只取一次（避免每个单位读一次布局属性触发强制重排）；
   *  ②标记位置未变的单位不写 DOM；③只有真的有棋子移动时才把阴影贴图标为脏。 */
  update(dt, time, camera) {
    const { w: ovW, h: ovH } = this.overlaySize();
    let casterMoved = false;
    for (const v of this.views.values()) {
      const u = v.unit;
      // 位置插值（动画层可直接改写 v.pos）
      if (!v.moving) {
        const k = 1 - Math.pow(0.0015, dt);
        v.pos.lerp(v.target, k);
      }
      // 朝向平滑（最短弧）
      let dh = v.desiredHeading - v.heading;
      while (dh > Math.PI) dh -= Math.PI * 2;
      while (dh < -Math.PI) dh += Math.PI * 2;
      v.heading += dh * Math.min(1, dt * 8);
      let dh2 = v.desiredTurret - v.turretHeading;
      while (dh2 > Math.PI) dh2 -= Math.PI * 2;
      while (dh2 < -Math.PI) dh2 += Math.PI * 2;
      v.turretHeading += dh2 * Math.min(1, dt * 6);
      let bob = 0;
      if (u.air) bob = Math.sin(time * 1.7 + v.bobPhase) * 0.28;
      v.group.position.set(v.pos.x, v.pos.y + bob, v.pos.z);
      v.group.rotation.y = -v.heading;
      if (v.turretPivot) v.turretPivot.rotation.y = -(v.turretHeading - v.heading);
      for (const r of v.rotors) {
        if (r.pivot.rotation.z !== 0 && r.pivot.rotation.z !== Math.PI) continue;
        r.pivot.rotation.y = time * r.speed + r.phase;
      }
      // 阴影是否值得重画：用**不含悬浮起伏**的位置比较（直升机上下浮动 ±0.28m
      // 远小于一个阴影贴图像素，重画没有意义），位移 > 6cm 或转向 > 0.02rad 才算。
      if (v.shadowPos === undefined) {
        v.shadowPos = new THREE.Vector3().copy(v.pos);
        v.shadowHeading = v.heading;
        casterMoved = true;
      } else if (v.shadowPos.distanceToSquared(v.pos) > 0.0036
        || Math.abs(v.heading - v.shadowHeading) > 0.02) {
        v.shadowPos.copy(v.pos);
        v.shadowHeading = v.heading;
        casterMoved = true;
      }
      // 命中闪白 / 材质亮度
      if (v.flash > 0) {
        v.flash = Math.max(0, v.flash - dt * 5);
        const f = v.flash;
        v.material.emissive.setRGB(f * 0.9, f * 0.55, f * 0.35);
      } else if (v.material.emissive.r !== 0) {
        v.material.emissive.setRGB(0, 0, 0);
      }
      const tint = (v.tint ?? 1) * (u.visible === false ? 0.5 : 1);
      if (v.material.color.r !== tint) v.material.color.setScalar(tint);
      // 标记投影
      this.projectMark(v, camera, ovW, ovH);
    }
    if (casterMoved) this.world.markShadowsDirty();
  }

  projectMark(v, camera, ovW, ovH) {
    const el = v.el;
    if (v.hidden || this.marksVisible === false) {
      if (v.markShown !== false) { el.style.display = 'none'; v.markShown = false; }
      return;
    }
    const p = this._markPos || (this._markPos = new THREE.Vector3());
    p.copy(v.group.position);
    p.y += (v.model.height || 3) + 0.8;
    p.project(camera);
    if (p.z > 1 || p.z < -1) {
      if (v.markShown !== false) { el.style.display = 'none'; v.markShown = false; }
      return;
    }
    const x = (p.x * 0.5 + 0.5) * ovW;
    const y = (-p.y * 0.5 + 0.5) * ovH;
    if (v.markShown !== true) { el.style.display = 'block'; v.markShown = true; }
    // 亚像素抖动不写 DOM（相机静止时几乎零写入）
    if (v.markX === undefined || Math.abs(v.markX - x) > 0.05 || Math.abs(v.markY - y) > 0.05) {
      v.markX = x; v.markY = y;
      el.style.transform = `translate(-50%,-100%) translate(${x.toFixed(1)}px,${y.toFixed(1)}px)`;
    }
    const d = Math.sqrt(camera.position.distanceToSquared(p));
    const fade = Math.max(0.18, Math.min(1, 1.25 - d / 420));
    const fadeStr = fade.toFixed(2);
    if (v.markFade !== fadeStr) { el.style.opacity = fadeStr; v.markFade = fadeStr; }
  }

  setVisible(visible) { this.group.visible = visible; }
}
