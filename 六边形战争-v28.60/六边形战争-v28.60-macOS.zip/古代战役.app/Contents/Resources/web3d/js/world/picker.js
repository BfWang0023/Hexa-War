/**
 * 拾取：把屏幕坐标转换成「格子 + 空中/地面层」。
 *
 * 两步：
 *  1. 先用地形合并网格求交（精确到坡面）拿到格坐标；
 *  2. 再对**候选棋子模型**（该格及其相邻 6 格的单位）做一次射线求交——
 *     棋子是有体积的模型，点击时命中的像素往往落在相邻格上（坦克车体、直升机旋翼
 *     都会探出本格），只看地形交点会把点击算到"棋子身后的格子"，
 *     于是点棋子选不中棋子。命中模型时以棋子自己的格坐标为准（可含"上/下"层）。
 *
 * 候选取「地形交点所在格 + 6 邻格」，所以每次点击只测极少数模型，开销可忽略。
 */

import * as THREE from '../../vendor/three/three.module.js';
import { worldToOffset, neighbors, axialFromOffset, offsetFromAxial } from '../core/hex.js';

export class Picker {
  constructor(world, terrain, unitLayer, store) {
    this.world = world;
    this.terrain = terrain;
    this.units = unitLayer;
    this.store = store;
    this.raycaster = new THREE.Raycaster();
    this.ndc = new THREE.Vector2();
  }

  setFromEvent(ev) {
    const rect = this.world.canvas.getBoundingClientRect();
    this.ndc.set(
      ((ev.clientX - rect.left) / rect.width) * 2 - 1,
      -((ev.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this.raycaster.setFromCamera(this.ndc, this.world.camera);
    return this.raycaster;
  }

  /** 命中信息：{hex:{col,row}, point, upper, unit?} 或 null。 */
  pick(ev) {
    const ray = this.setFromEvent(ev);
    const hits = ray.intersectObject(this.terrain.pickMesh, false);
    const point = hits.length ? hits[0].point : null;
    let off = null;
    if (point) {
      const o = worldToOffset(point.x, point.z);
      if (this.store.inBounds(o.col, o.row)) off = o;
    }

    // 1) 棋子优先：模型像素可能压在邻格上，命中模型就以它自己的格为准
    const views = this.candidateViews(off);
    if (views.length) {
      const uh = ray.intersectObjects(views.map(v => v.group), true);
      if (uh.length && (!hits.length || uh[0].distance <= hits[0].distance + 0.75)) {
        let obj = uh[0].object;
        while (obj && !obj.userData.__view) obj = obj.parent;
        const v = obj?.userData.__view;
        if (v) {
          const [c, r] = v.unit.h;
          if (this.store.inBounds(c, r)) {
            return { hex: { col: c, row: r }, point: uh[0].point, upper: !!v.unit.air, unit: v.unit };
          }
        }
      }
    }

    if (!off) return null;
    // 2) 纯地形命中：同格有双单位（地面 + 空中）时按交点高度判断层
    let upper = false;
    const ground = this.store.unitAt(off.col, off.row, false);
    const air = this.store.unitAt(off.col, off.row, true);
    if (ground && air) {
      const gv = this.units.viewOf(ground.team, ground.label);
      const av = this.units.viewOf(air.team, air.label);
      const meshes = [];
      if (gv) meshes.push(...gv.group.children);
      if (av) meshes.push(...av.group.children);
      const unitHits = ray.intersectObjects(meshes, true);
      if (unitHits.length) {
        let obj = unitHits[0].object;
        while (obj && !obj.userData.__view) obj = obj.parent;
        upper = obj?.userData.__view === av;
      } else {
        upper = Math.abs(point.y - (this.terrain.heightAt(off.col, off.row) + 7.2))
          < Math.abs(point.y - this.terrain.heightAt(off.col, off.row));
      }
    } else if (air) {
      upper = true;
    }
    return { hex: off, point, upper };
  }

  /** 可能有单位的格（地形交点格 + 6 邻格）上已渲染的棋子视图。 */
  candidateViews(off) {
    const out = [];
    const seen = new Set();
    const push = (c, r) => {
      if (!this.store.inBounds(c, r)) return;
      for (const air of [false, true]) {
        const u = this.store.unitAt(c, r, air);
        if (!u) continue;
        const key = u.team + '|' + u.label;
        if (seen.has(key)) continue;
        seen.add(key);
        const v = this.units.viewOf(u.team, u.label);
        if (v && v.group.visible) out.push(v);
      }
    };
    if (off) {
      push(off.col, off.row);
      // 6 邻格（轴向邻居 → 偏移坐标）
      for (const n of neighbors(axialFromOffset(off.col, off.row))) {
        const o = offsetFromAxial(n.q, n.r);
        push(o.col, o.row);
      }
    } else {
      // 地形没打到（比如点在模型上、而模型高过地形边界）：退化为全量候选
      for (const v of this.units.views.values()) {
        if (v.group.visible) out.push(v);
      }
    }
    return out;
  }
}
