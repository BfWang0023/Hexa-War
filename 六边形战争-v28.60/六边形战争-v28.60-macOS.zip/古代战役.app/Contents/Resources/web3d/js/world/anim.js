/**
 * 动画引擎：消费后端下发的 UiEvent（move / fire），在客户端重放：
 *  - 移动：沿真实路径匀速滑行 + 转向平滑（窗口 0.35 路径参数，与原 GUI 一致）；
 *  - 开火：瞄准（炮塔/车体转向）→ 炮口火光 → 弹道（曳光/炮弹/火箭/导弹/抛物线）→
 *          命中（爆炸 / 跳弹火花 / 未命中）→ 伤亡（残骸、尸体、坠机）；
 *  - 附加表现：命中闪白、受损车辆冒烟、烟雾弹、飘字伤害、镜头震动。
 *
 * 所有特效都用共享几何 + 池化 Mesh，特效数量有上限；核显也能稳住帧率。
 */

import * as THREE from '../../vendor/three/three.module.js';
import { offsetToWorld, axialFromOffset } from '../core/hex.js';
import { weaponProfile, projKind } from './fx.js';

const MAX_EFFECTS = 160;
const TURN_W = 0.35;

export class Animator {
  constructor(world, terrain, unitLayer, store, floatLayer) {
    this.world = world;
    this.terrain = terrain;
    this.units = unitLayer;
    this.store = store;
    this.floatLayer = floatLayer;
    this.queue = [];
    this.clock = 0;
    this.scale = 1;
    this.current = null;
    this.nextStart = 0;
    this.doomed = [];      // 待阵亡（击毁弹落地前保持显示）
    this.effects = [];
    this.corpses = [];
    this.smokers = [];
    this.pool = { puffs: [], flashes: [], explosions: [], sparks: [], projectiles: [] };
    this.onKill = null;    // 回调：击毁提示
    this.time = 0;
    this._flW = 0; this._flH = 0;
    window.addEventListener('resize', () => { this._flW = 0; this._flH = 0; });
  }

  /** 后端更新包里的动画事件入队。 */
  enqueue(events, scale) {
    if (!events || !events.length) return;
    this.scale = scale || 1;
    for (const ev of events) this.queue.push(ev);
    if (this.clock < this.time) this.clock = this.time;
  }

  get busy() { return this.current !== null || this.queue.length > 0; }

  /** 队列剩余预计时长（用于 UI 上的“播放中”提示）。 */
  estimateRemaining() {
    let t = 0;
    for (const ev of this.queue) t += this.slotOf(ev);
    return t;
  }

  slotOf(ev) {
    if (ev.k === 'move') {
      const n = (ev.path || []).length;
      return Math.max(0.16 * Math.max(1, n - 1), 0.18) * this.scale + 0.06;
    }
    if (ev.k === 'fire') {
      const prof = weaponProfile(ev.kind, ev.aa, ev.missile, ev.area);
      return Math.max(prof.aim * this.scale, 0.03) + prof.flight + (ev.killed ? 1.5 : 0.35) * this.scale;
    }
    return (ev.dur || 0.05);
  }

  update(dt, time) {
    this.time = time;
    // 启动下一个事件
    if (!this.current && this.queue.length && time >= this.nextStart) {
      const ev = this.queue.shift();
      this.startEvent(ev, time);
    }
    if (this.current?.update) this.current.update(time);
    this.updateDoomed(time);
    this.updateEffects(dt, time);
    this.updateSmokers(time);
    this.updateFloats(dt);
  }

  /* ------------------------------------------------------------------ */
  /* 事件启动                                                            */
  /* ------------------------------------------------------------------ */
  startEvent(ev, now) {
    if (ev.k === 'move') return this.startMove(ev, now);
    if (ev.k === 'fire') return this.startFire(ev, now);
    if (ev.k === 'skip') {
      this.nextStart = now + (ev.dur || 0.05);
      this.current = null;
      return;
    }
    this.nextStart = now;
    this.current = null;
  }

  worldPath(path) {
    return (path || []).map(([c, r]) => {
      const w = offsetToWorld(c, r);
      return new THREE.Vector3(w.x, 0, w.z);
    });
  }

  startMove(ev, now) {
    const v = this.units.viewOf(ev.team, ev.label);
    const pts = this.worldPath(ev.path);
    const dur = Math.max(0.16 * Math.max(1, pts.length - 1), 0.18) * this.scale;
    if (!v || pts.length < 2) {
      this.current = null;
      this.nextStart = now + 0.02;
      return;
    }
    v.moving = true;
    const startHeading = v.heading;
    const segDirs = [];
    for (let i = 0; i < pts.length - 1; i++) {
      segDirs.push(Math.atan2(pts[i + 1].z - pts[i].z, pts[i + 1].x - pts[i].x));
    }
    const prevTurret = v.turretHeading;
    const self = this;
    this.current = {
      kind: 'move',
      update(t) {
        const k = Math.min(1, (t - now) / dur);
        const raw = k * (pts.length - 1);
        const seg = Math.min(pts.length - 2, Math.floor(raw));
        const frac = raw - seg;
        const p = pts[seg].clone().lerp(pts[seg + 1], frac);
        // 高度按当前格地形
        const cell = ev.path[Math.min(ev.path.length - 1, Math.round(raw))];
        p.y = ev.air
          ? self.terrain.flyY(cell[0], cell[1], 7.2)
          : self.terrain.heightAt(cell[0], cell[1]) + 0.05;
        v.pos.copy(p);
        // 转向：进入下一个节点前 0.35 窗口内混合
        const u = raw;
        let heading = segDirs[seg];
        const smooth = (x) => x * x * (3 - 2 * x);
        if (seg + 1 < segDirs.length && u >= seg + 1 - TURN_W) {
          const tt = smooth(Math.min(1, Math.max(0, (u - (seg + 1 - TURN_W)) / (TURN_W * 2))));
          heading = blendAngle(segDirs[seg], segDirs[seg + 1], tt);
        }
        v.heading = heading;
        v.desiredHeading = heading;
        v.desiredTurret = v.fired ? v.desiredTurret : heading;
        if (k >= 1) {
          v.moving = false;
          v.heading = segDirs[segDirs.length - 1];
          v.desiredHeading = v.heading;
          if (!v.fired) { v.turretHeading = v.heading; v.desiredTurret = v.heading; }
          v.target.copy(p);
          self.current = null;
          self.nextStart = t + 0.06;
        }
      },
    };
    // 起步时同步一次，避免第一帧闪回旧位置
    this.current.update(now);
  }

  startFire(ev, now) {
    const v = this.units.viewOf(ev.team, ev.label);
    const prof = weaponProfile(ev.kind, ev.aa, ev.missile, ev.area);
    const aim = Math.max(prof.aim * this.scale, 0.03);
    const from = this.hexWorld(ev.from);
    const target = this.hexWorld(ev.target);
    const aimAng = Math.atan2(target.z - from.z, target.x - from.x);
    if (v) {
      v.fired = true;
      if (v.model.foot) {
        v.desiredHeading = aimAng;
        v.desiredTurret = aimAng;
      } else {
        v.desiredTurret = aimAng;
      }
    }
    // 被击毁单位：在命中前保持显示
    for (const k of ev.killedUnits || []) this.spawnDoomed(k, now + aim + prof.flight);
    let launched = false;
    let landed = false;
    const self = this;
    this.current = {
      kind: 'fire',
      update(t) {
        if (!launched && t >= now + aim) {
          launched = true;
          self.spawnProjectile(ev, from, target, prof);
        }
        if (!landed && t >= now + aim + prof.flight) {
          landed = true;
          self.spawnImpact(ev, target);
          if (v) v.fired = false;
        }
        if (t >= now + aim + prof.flight + (ev.killed ? 1.5 : 0.35) * self.scale) {
          self.current = null;
          self.nextStart = t;
        }
      },
    };
  }

  hexWorld(h) {
    const [c, r] = h;
    const w = offsetToWorld(c, r);
    return new THREE.Vector3(w.x, this.terrain.heightAt(c, r), w.z);
  }

  /* ------------------------------------------------------------------ */
  /* 弹道与命中                                                          */
  /* ------------------------------------------------------------------ */
  spawnProjectile(ev, from, target, prof) {
    const kind = projKind(ev.kind, ev.aa, ev.missile, ev.area);
    const start = from.clone();
    const v = this.units.viewOf(ev.team, ev.label);
    if (v) {
      const ang = v.model.foot ? v.heading : v.turretHeading;
      const off = ev.area ? 2.6 : (v.model.foot ? 1.2 : 3.2);
      start.x += Math.cos(ang) * off;
      start.z += Math.sin(ang) * off;
      start.y += v.model.foot ? 1.3 : 1.9;
    }
    this.spawnFlash(start, Math.atan2(target.z - start.z, target.x - start.x), kind === 'tracer' ? 0.7 : 1.35);
    const q = this.world.quality;
    if (ev.area) {
      this.spawnArc(start, target, prof.flight, kind === 'smoke', ev.blast);
    } else if (kind === 'tracer' || kind === 'autocannon') {
      this.spawnTracer(start, target, prof.flight, kind === 'autocannon');
    } else {
      this.spawnMissile(start, target, prof.flight, kind, ev.hit);
    }
  }

  spawnImpact(ev, target) {
    const c = this.hexWorld(ev.target);
    const q = this.world.quality;
    if (ev.area) {
      // 范围炮击：每个波及格一次爆炸
      for (const b of ev.blast || []) {
        const p = this.hexWorld(b);
        const big = b[0] === ev.target[0] && b[1] === ev.target[1];
        this.spawnExplosion(p, big, big ? 1 : 0.8);
      }
      this.world.addShake(0.5 * (q.particles > 0.5 ? 1 : 0.5));
    } else if (ev.hit && ev.blocked) {
      this.spawnSpark(c);
    } else if (!ev.hit) {
      // 未命中：落点附近零星火花
      this.spawnSpark(c, 0.7);
    } else if (ev.killed) {
      this.spawnExplosion(c, true, 1.15);
      this.world.addShake(0.42);
    } else {
      this.spawnExplosion(c, false, 0.85);
      this.spawnSpark(c);
      this.world.addShake(0.16);
    }
    // 飘字
    if (ev.hit && !ev.blocked && ev.dmg > 0) {
      this.addFloat(c, `-${ev.dmg}`, ev.killed ? '#ff8a7a' : '#ffd08a', ev.killed ? 1.5 : 1.0);
    } else if (ev.hit && ev.blocked) {
      this.addFloat(c, '跳弹', '#cfd6cc', 0.9);
    } else if (!ev.hit) {
      this.addFloat(c, '未命中', '#a8b0a6', 0.85);
    }
    if (ev.killed) {
      if (this.onKill) this.onKill(ev);
      for (const k of ev.killedUnits || []) this.killDoomed(k, this.time);
    }
  }

  /* ---------------- 特效池 ---------------- */
  obtain(kind, factory) {
    const list = this.pool[kind];
    for (const o of list) if (!o.active) return o;
    if (list.length + this.effects.length > MAX_EFFECTS) return null;
    const o = factory();
    list.push(o);
    return o;
  }

  spawnFlash(pos, ang, scale) {
    const o = this.obtain('flashes', () => {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(1, 8, 6),
        new THREE.MeshBasicMaterial({ color: 0xffe0a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (!o) return;
    o.active = true;
    o.t0 = this.time;
    o.dur = 0.11;
    o.mesh.visible = true;
    o.mesh.position.copy(pos);
    o.mesh.scale.setScalar(0.5 * scale);
    o.scale = scale;
    this.effects.push({ kind: 'flash', o, t0: this.time, dur: o.dur });
  }

  spawnTracer(from, to, flight, thick) {
    const o = this.obtain('projectiles', () => {
      const m = new THREE.Mesh(
        new THREE.CylinderGeometry(0.14, 0.14, 1, 6),
        new THREE.MeshBasicMaterial({ color: 0xffd65c, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      m.rotation.z = Math.PI / 2;
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (!o) return;
    o.active = true;
    o.mesh.visible = true;
    const dir = to.clone().sub(from);
    const len = dir.length();
    const ang = Math.atan2(dir.z, dir.x);
    o.mesh.position.copy(from);
    o.mesh.rotation.set(0, -ang, Math.PI / 2);
    o.mesh.scale.set(1, thick ? 4.5 : 3.0, thick ? 2.2 : 1.4);
    this.effects.push({
      kind: 'tracer', o, t0: this.time, dur: flight,
      update: (t) => {
        const k = Math.min(1, (t - this.time) / flight);
        o.mesh.position.lerpVectors(from, to, k);
        o.mesh.material.opacity = 1;
      },
    });
    // 连发（机炮/重机枪）额外两簇
    if (thick) {
      for (let i = 1; i <= 2; i++) {
        setTimeout(() => {
          if (this.effects.length < MAX_EFFECTS) this.spawnTracer(from, to, flight, false);
        }, i * 55);
      }
    }
  }

  spawnMissile(from, to, flight, kind, willHit) {
    const o = this.obtain('projectiles', () => {
      const m = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.28, 1.5, 3, 6),
        new THREE.MeshBasicMaterial({ color: 0xe8e8dc }),
      );
      m.rotation.z = Math.PI / 2;
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (!o) return;
    o.active = true;
    o.mesh.visible = true;
    o.mesh.material.color.set(kind === 'tow' ? 0xdedede : kind === 'stinger' ? 0xf0f0e0 : 0xd8d8c0);
    const arc = kind === 'javelin' ? 12 : 0;
    const mid = from.clone().lerp(to, 0.5);
    mid.y = Math.max(from.y, to.y) + arc;
    const start = this.time;
    this.effects.push({
      kind: 'missile', o, t0: start, dur: flight,
      update: (t) => {
        const k = Math.min(1, (t - start) / flight);
        const p = quadratic(from, mid, to, k);
        o.mesh.position.copy(p);
        const ahead = quadratic(from, mid, to, Math.min(1, k + 0.02));
        const ang = Math.atan2(ahead.z - p.z, ahead.x - p.x);
        o.mesh.rotation.set(0, -ang, Math.PI / 2);
        // 尾焰
        if (Math.random() < 0.7 * this.world.quality.particles) {
          this.spawnPuff(p.clone(), 0.55, true, kind === 'stinger' ? 0.9 : 0.6);
        }
      },
    });
  }

  spawnArc(from, to, flight, smoke, blast) {
    const o = this.obtain('projectiles', () => {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(0.45, 8, 6),
        new THREE.MeshBasicMaterial({ color: smoke ? 0xe8e8e0 : 0x50504c }),
      );
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (!o) return;
    o.active = true;
    o.mesh.visible = true;
    const peak = 26;
    const start = this.time;
    this.effects.push({
      kind: 'arc', o, t0: start, dur: flight,
      update: (t) => {
        const k = Math.min(1, (t - start) / flight);
        const p = from.clone().lerp(to, k);
        p.y += Math.sin(Math.PI * k) * peak;
        o.mesh.position.copy(p);
        if (Math.random() < 0.5 * this.world.quality.particles) this.spawnPuff(p.clone(), 0.5, false, 0.5);
      },
    });
  }

  spawnExplosion(pos, big, scale = 1) {
    const k = big ? 1.55 : 1.0;
    const size = k * scale;
    const o = this.obtain('explosions', () => {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(1, 10, 8),
        new THREE.MeshBasicMaterial({ color: 0xffb050, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (!o) return;
    o.active = true;
    o.mesh.visible = true;
    o.mesh.position.copy(pos);
    o.mesh.material.color.setRGB(1, 0.72, 0.3);
    const start = this.time;
    const dur = big ? 0.85 : 0.55;
    this.effects.push({
      kind: 'explosion', o, t0: start, dur,
      update: (t) => {
        const a = (t - start) / dur;
        if (a < 0.3) {
          // 火球：亮黄 → 橙红
          const fq = a / 0.3;
          o.mesh.scale.setScalar((0.7 + 5.4 * fq) * size);
          o.mesh.material.opacity = 1 - fq * 0.25;
          o.mesh.material.color.setRGB(1, 0.86 - 0.36 * fq, 0.42 - 0.3 * fq);
        } else {
          // 余烟：暗灰、低透明度
          const sq = (a - 0.3) / 0.7;
          o.mesh.scale.setScalar((6.1 + 5 * sq) * size);
          o.mesh.material.opacity = Math.max(0, 1 - sq) * 0.34;
          o.mesh.material.color.setRGB(0.3, 0.28, 0.26);
        }
      },
    });
    // 冲击波圆环
    const ring = this.obtain('flashes', () => {
      const m = new THREE.Mesh(
        new THREE.RingGeometry(0.7, 1.0, 20),
        new THREE.MeshBasicMaterial({ color: 0xffd9a0, transparent: true, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }),
      );
      m.rotation.x = -Math.PI / 2;
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (ring) {
      ring.active = true;
      ring.mesh.visible = true;
      ring.mesh.position.copy(pos).add(new THREE.Vector3(0, 0.4, 0));
      const r0 = this.time;
      this.effects.push({
        kind: 'shock', o: ring, t0: r0, dur: 0.45,
        update: (t) => {
          const a = Math.min(1, (t - r0) / 0.45);
          ring.mesh.scale.setScalar((1 + a * 7.5) * size);
          ring.mesh.material.opacity = Math.max(0, 0.6 * (1 - a));
        },
      });
    }
    // 火星
    const sparks = Math.round(4 * this.world.quality.particles);
    for (let i = 0; i < sparks; i++) {
      const p = pos.clone();
      p.x += (Math.random() - 0.5) * 2;
      p.z += (Math.random() - 0.5) * 2;
      p.y += 0.6;
      this.spawnPuff(p, 0.32, true, 0.45);
    }
    // 烟团
    const n = Math.round((big ? 5 : 3) * this.world.quality.particles);
    for (let i = 0; i < n; i++) {
      const p = pos.clone();
      p.x += (Math.random() - 0.5) * 3 * size;
      p.z += (Math.random() - 0.5) * 3 * size;
      p.y += Math.random() * 1.4 * size;
      this.spawnPuff(p, big ? 1.7 : 1.1, false, 0.9 * size);
    }
    // 短暂点光
    const fl = this.world.flashLight;
    fl.position.copy(pos).add(new THREE.Vector3(0, 3, 0));
    fl.intensity = big ? 900 : 380;
    fl.distance = big ? 46 : 26;
    fl.visible = true;
    clearTimeout(this._flashTimer);
    this._flashTimer = setTimeout(() => { fl.visible = false; fl.intensity = 0; }, 110);
  }

  spawnSpark(pos, scale = 1) {
    const o = this.obtain('sparks', () => {
      const grp = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({ color: 0xfff0c0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
      for (let i = 0; i < 5; i++) {
        const m = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.07, 0.07), mat);
        m.rotation.y = i * 1.2566 + 0.3;
        grp.add(m);
      }
      const dot = new THREE.Mesh(new THREE.SphereGeometry(0.5, 6, 5), mat.clone());
      grp.add(dot);
      this.world.scene.add(grp);
      return { mesh: grp, active: false, mats: [mat, dot.material] };
    });
    if (!o) return;
    o.active = true;
    o.mesh.visible = true;
    o.mesh.position.copy(pos).add(new THREE.Vector3(0, 0.6, 0));
    const start = this.time;
    this.effects.push({
      kind: 'spark', o, t0: start, dur: 0.32,
      update: (t) => {
        const a = (t - start) / 0.32;
        o.mesh.scale.setScalar((1 + a * 3.2) * scale);
        for (const m of o.mats) m.opacity = Math.max(0, 1 - a);
      },
    });
  }

  spawnPuff(pos, size, white, life = 1.2) {
    const o = this.obtain('puffs', () => {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(1, 7, 6),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false }),
      );
      this.world.scene.add(m);
      return { mesh: m, active: false };
    });
    if (!o) return;
    o.active = true;
    o.mesh.visible = true;
    o.mesh.position.copy(pos);
    o.mesh.material.color.set(white ? 0xe6e6e0 : 0x9a9894);
    const start = this.time;
    const drift = new THREE.Vector3((Math.random() - 0.5) * 1.6, 1.4 + Math.random(), (Math.random() - 0.5) * 1.6);
    this.effects.push({
      kind: 'puff', o, t0: start, dur: life,
      update: (t) => {
        const a = Math.min(1, (t - start) / life);
        o.mesh.position.copy(pos).addScaledVector(drift, a);
        o.mesh.scale.setScalar((0.7 + a * 3.4) * size);
        o.mesh.material.opacity = Math.max(0, (1 - a) * (white ? 0.72 : 0.55));
      },
    });
  }

  updateEffects(dt, time) {
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const e = this.effects[i];
      if (e.update) e.update(time);
      if (time - e.t0 >= e.dur) {
        e.o.active = false;
        e.o.mesh.visible = false;
        if (e.o.mats) for (const m of e.o.mats) m.opacity = 1;
        if (e.o.mesh.material && !e.o.mats) e.o.mesh.material.opacity = 1;
        this.effects.splice(i, 1);
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* 伤亡                                                                */
  /* ------------------------------------------------------------------ */
  spawnDoomed(k, landAt) {
    // 状态里该单位已被移除：用临时 Mesh 在命中前保持显示（对应原 GUI 的 pending_deaths）
    const md = getModelFor(k.kind, k.team, k.hpBefore);
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
    const mesh = new THREE.Mesh(md.bodyGeo, mat);
    mesh.castShadow = this.world.quality.shadows;
    const [c, r] = k.h;
    const w = offsetToWorld(c, r);
    const air = isAirKind(k.kind);
    const y = air ? this.terrain.flyY(c, r, 7.2) : this.terrain.heightAt(c, r) + 0.05;
    mesh.position.set(w.x, y, w.z);
    mesh.rotation.y = k.team === 'blue' ? 0 : -Math.PI;
    this.world.scene.add(mesh);
    this.world.markShadowsDirty();
    this.doomed.push({ mesh, mat, k, landAt, air, y, falling: 0 });
  }

  killDoomed(k, time) {
    for (const d of this.doomed) {
      if (d.k.team === k.team && d.k.label === k.label && !d.dying) {
        d.dying = time;
        this.spawnDeathFx(d);
      }
    }
  }

  spawnDeathFx(d) {
    const k = d.k;
    const foot = isFootKind(k.kind);
    if (foot) {
      // 尸体：一组卧倒的灰sefigures
      const n = corpseCount(k.kind, k.hpBefore);
      const geo = getCorpseGeo(k.kind, n);
      const mat = new THREE.MeshLambertMaterial({ color: 0x8a8a84, transparent: true, opacity: 1 });
      const m = new THREE.Mesh(geo, mat);
      m.position.copy(d.mesh.position);
      m.rotation.y = d.mesh.rotation.y;
      this.world.scene.add(m);
      this.corpses.push({ mesh: m, mat, t0: this.time, dur: 2.6 });
    } else if (d.air) {
      // 坠机：机身旋转下坠 + 冒烟
      d.falling = 1;
    } else {
      // 载具残骸：灰化、冒烟，慢慢淡出
      const mat = new THREE.MeshLambertMaterial({ color: 0x6e6e68 });
      const m = new THREE.Mesh(d.mesh.geometry, mat);
      m.position.copy(d.mesh.position);
      m.rotation.copy(d.mesh.rotation);
      this.world.scene.add(m);
      this.corpses.push({ mesh: m, mat, t0: this.time + 0.35, dur: 3.2, wreck: true });
      for (let i = 0; i < 3; i++) {
        const p = m.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 2, 1 + i * 0.6, (Math.random() - 0.5) * 2));
        this.spawnPuff(p, 1.5, false, 1.4 + i * 0.3);
      }
    }
  }

  updateDoomed(time) {
    for (let i = this.doomed.length - 1; i >= 0; i--) {
      const d = this.doomed[i];
      if (d.falling > 0) {
        d.falling += 0.016;
        d.mesh.position.y -= 0.14;
        d.mesh.rotation.z += 0.05;
        d.mesh.rotation.x += 0.03;
        if (Math.random() < 0.5) this.spawnPuff(d.mesh.position.clone(), 1.2, false, 1.2);
        if (d.mesh.position.y < d.y - 6) { this.disposeDoomed(i); continue; }
      }
      if (d.dying && time - d.dying > (d.air ? 1.6 : 0.45)) {
        this.disposeDoomed(i);
      }
    }
    for (let i = this.corpses.length - 1; i >= 0; i--) {
      const c = this.corpses[i];
      const age = time - c.t0;
      if (age < 0) continue;
      const k = age / c.dur;
      c.mat.opacity = k > 0.75 ? Math.max(0, (1 - k) / 0.25) : Math.min(1, age * 4);
      c.mat.transparent = true;
      if (age >= c.dur) {
        this.world.scene.remove(c.mesh);
        c.mat.dispose();
        if (c.wreck) c.mesh.geometry === undefined;
        this.corpses.splice(i, 1);
      }
    }
  }

  disposeDoomed(i) {
    const d = this.doomed[i];
    this.world.scene.remove(d.mesh);
    d.mat.dispose();
    this.doomed.splice(i, 1);
    this.world.markShadowsDirty();   // 投影体少了一个
  }

  updateSmokers(time) {
    for (const s of this.smokers) {
      if (time >= s.next && time < s.until) {
        const p = s.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 1.5, 1.5, (Math.random() - 0.5) * 1.5));
        this.spawnPuff(p, 0.9, false, 1.1);
        s.next = time + 0.4;
      }
    }
    this.smokers = this.smokers.filter(s => time < s.until + 1);
  }

  /** 受损载具持续冒烟（状态同步时调用）。 */
  refreshSmokers(state) {
    const list = [];
    for (const u of state?.units || []) {
      if (u.ghost || u.air) continue;
      if (u.hp > 0 && u.hp < u.maxHp && u.hp <= 1) {
        const [c, r] = u.h;
        const w = offsetToWorld(c, r);
        const p = new THREE.Vector3(w.x, this.terrain.heightAt(c, r) + 1.4, w.z);
        const old = this.smokers.find(s => s.key === u.team + u.label);
        list.push(old && old.hx === c + ',' + r
          ? old
          : { key: u.team + u.label, pos: p, hx: c + ',' + r, next: this.time, until: this.time + 3.5 });
      }
    }
    this.smokers = list;
  }

  /* ------------------------------------------------------------------ */
  /* 飘字                                                                */
  /* ------------------------------------------------------------------ */
  addFloat(pos, text, color, scale = 1) {
    if (!this.floatLayer) return;
    const el = document.createElement('div');
    el.className = 'float-text';
    el.textContent = text;
    el.style.color = color;
    el.style.fontSize = (13 + 6 * scale) + 'px';
    this.floatLayer.appendChild(el);
    this.floats = this.floats || [];
    this.floats.push({ el, pos: pos.clone().add(new THREE.Vector3(0, 4, 0)), t: 0, dur: 1.35 });
  }

  updateFloats(dt) {
    if (!this.floats) return;
    const cam = this.world.camera;
    for (let i = this.floats.length - 1; i >= 0; i--) {
      const f = this.floats[i];
      f.t += dt;
      f.pos.y += dt * 3.4;
      const sp = (this._flVec || (this._flVec = new THREE.Vector3())).copy(f.pos).project(cam);
      if (!this._flW) {
        this._flW = this.floatLayer.clientWidth || window.innerWidth;
        this._flH = this.floatLayer.clientHeight || window.innerHeight;
      }
      const x = (sp.x * 0.5 + 0.5) * this._flW;
      const y = (-sp.y * 0.5 + 0.5) * this._flH;
      f.el.style.transform = `translate(-50%,-50%) translate(${x.toFixed(1)}px,${y.toFixed(1)}px)`;
      f.el.style.opacity = String(Math.max(0, 1 - f.t / f.dur));
      if (f.t >= f.dur) {
        f.el.remove();
        this.floats.splice(i, 1);
      }
    }
  }

  /** 「跳过动画」：清空播放队列与临时特效，让棋子直接落到**状态里已有的最终位置**。
   *  后端在 AI 播放窗口结束后本来就是这个结果，因此跳过只是把"看动画"这一步省掉。 */
  skipAll() {
    this.queue.length = 0;
    this.current = null;
    this.nextStart = this.time;
    for (const e of this.effects) { e.o.active = false; e.o.mesh.visible = false; }
    this.effects.length = 0;
    for (let i = this.doomed.length - 1; i >= 0; i--) this.disposeDoomed(i);
    if (this.floats) { for (const f of this.floats) f.el.remove(); this.floats.length = 0; }
    // 移动中的棋子直接吸附到目标格（units.sync 已把最终位置写进 v.target）
    for (const v of this.units.views.values()) {
      v.moving = false;
      v.pos.copy(v.target);
      v.heading = v.desiredHeading;
      v.turretHeading = v.desiredTurret;
      v.shadowPos = undefined;      // 位置跳变，阴影贴图重画一次
    }
    this.world.markShadowsDirty();
  }

  /** 重开一局时清空所有动画状态。 */
  reset() {
    this.queue.length = 0;
    this.current = null;
    for (const e of this.effects) { e.o.active = false; e.o.mesh.visible = false; }
    this.effects.length = 0;
    for (let i = this.doomed.length - 1; i >= 0; i--) this.disposeDoomed(i);
    for (const c of this.corpses) { this.world.scene.remove(c.mesh); c.mat.dispose(); }
    this.corpses.length = 0;
    this.smokers.length = 0;
    if (this.floats) { for (const f of this.floats) f.el.remove(); this.floats.length = 0; }
    this.clock = 0;
    this.nextStart = 0;
  }
}

/* ---------------- 工具 ---------------- */
function blendAngle(a, b, t) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function quadratic(a, c, b, t) {
  const u = 1 - t;
  return new THREE.Vector3(
    u * u * a.x + 2 * u * t * c.x + t * t * b.x,
    u * u * a.y + 2 * u * t * c.y + t * t * b.y,
    u * u * a.z + 2 * u * t * c.z + t * t * b.z,
  );
}

const AIR = new Set(['attack_heli', 'transport_heli', 'heavy_transport_heli', 'drone']);
const FOOT = new Set(['rifleman', 'atgm', 'javelin', 'special_forces', 'elite_infantry', 'aa_infantry', 'hmg_gunner', 'headquarters']);
const isAirKind = (k) => AIR.has(k);
const isFootKind = (k) => FOOT.has(k);

function corpseCount(kind, hp) {
  if (kind === 'rifleman' || kind === 'elite_infantry') return Math.max(1, Math.min(12, hp * 4));
  if (kind === 'special_forces') return Math.max(1, Math.min(8, hp * 4));
  if (kind === 'headquarters') return 1;
  return 2;
}

// 延迟引入，避免循环依赖
import { getModel, getCorpseGeo } from './models.js';
function getModelFor(kind, team, hp) {
  try {
    return getModel(kind, team, { hp, deployed: false });
  } catch (e) {
    return { bodyGeo: new THREE.BoxGeometry(2, 2, 2) };
  }
}
