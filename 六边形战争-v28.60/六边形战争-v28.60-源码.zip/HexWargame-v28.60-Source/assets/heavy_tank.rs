//! 棋子美术 · 主战坦克（M1A2 艾布拉姆斯）。
//!
//! 按 docs/topview-refs/M1A2-Topview.png 的网格测量值重绘：外轮廓为方正的
//! 履带/裙板整体（占满全长），两侧裙板窄条几乎全程覆盖履带；车体甲板在前部
//! 收为内凹楔形（楔尖在炮框正下方），无中央尖顶；大尺寸平板棱角炮塔占车长
//! 近半、几乎盖满两侧甲板；炮管大幅悬出车首。车体与炮塔分层绘制：履带/车体
//! 随移动转向（hull），炮塔随最后一次开火转向（turret）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Palette, Px, STAR_WHITE, WRECK};
use super::parts::disc;

/// 履带/裙板窄条：矩形带 + 拼缝线（前后端平齐方切口）。
fn skirt_band(px: &Px, c: Pos2, ang: f32, x0: f32, x1: f32, yc: f32, hw: f32, pal: &Palette) {
    let ink = pal.ink;
    px.unit_poly(
        c,
        ang,
        &[(x0, yc - hw), (x1, yc - hw), (x1, yc + hw), (x0, yc + hw)],
        pal.dark,
        0.7,
        ink,
    );
    let n = (((x1 - x0) / 4.6).floor() as i32).max(1);
    for i in 1..n {
        let x = x0 + (x1 - x0) * i as f32 / n as f32;
        px.unit_line(c, ang, (x, yc - hw), (x, yc + hw), 0.6, ink);
    }
}

/// 绘制主战坦克棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal: Palette = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;

    // ---- 履带/裙板窄条（全长矩形，前后方切口；测量：每侧带宽≈车宽 14%）----
    skirt_band(px, c, hull, -18.4, 18.4, -7.55, 1.2, &pal);
    skirt_band(px, c, hull, -18.4, 18.4, 7.55, 1.2, &pal);

    // ---- 车体甲板（-18.3..15.4，前缘后收于裙板；楔形接缝线）----
    px.unit_poly(
        c,
        hull,
        &[(-18.3, -6.3), (15.4, -6.3), (15.4, 6.3), (-18.3, 6.3)],
        pal.fill,
        0.9,
        ink,
    );
    // 首上甲板楔形受光面（楔尖在炮框下方，两道斜缝）
    px.unit_poly(c, hull, &[(15.4, -6.3), (15.4, 6.3), (10.2, 0.0)], pal.light, 0.0, ink);
    // 驾驶员舱盖（前右）
    disc(px, c, hull, (12.6, 2.4), 1.3, ink, pal.dark, Some(pal.metal));

    // ---- 尾部动力舱（两块格栅 + 中央盖板；测量：占尾端 30% 车长）----
    for side in [-1.0f32, 1.0] {
        let (ya, yb) = if side < 0.0 { (-5.2, -2.3) } else { (2.3, 5.2) };
        px.unit_poly(c, hull, &[(-14.4, ya), (-8.2, ya), (-8.2, yb), (-14.4, yb)], pal.dark, 0.0, ink);
        for gx in [-13.5, -12.5, -11.5, -10.5, -9.5] {
            px.unit_line(c, hull, (gx, ya), (gx, yb), 0.5, ink);
        }
    }
    px.unit_line(c, hull, (-14.4, -1.6), (-8.2, -1.6), 0.5, ink);
    px.unit_line(c, hull, (-14.4, 1.6), (-8.2, 1.6), 0.5, ink);

    // ---- 大尺寸棱角炮塔（测量：车长 0.22..0.70，宽度≈0.69 车宽）----
    let tc = xform(c, hull, (1.3, 0.0), px.s);
    px.unit_poly(
        tc,
        turret,
        &[
            (8.9, 0.0),
            (7.2, -4.9),
            (3.6, -6.0),
            (-4.2, -6.0),
            (-6.1, -4.9),
            (-8.7, -3.5),
            (-8.7, 3.5),
            (-6.1, 4.9),
            (-4.2, 6.0),
            (3.6, 6.0),
            (7.2, 4.9),
        ],
        pal.light,
        0.9,
        ink,
    );
    // 两侧平板装甲嵌条
    for side in [-1.0f32, 1.0] {
        px.unit_poly(
            tc,
            turret,
            &[(5.8, side * 5.5), (-4.2, side * 5.5), (-4.2, side * 4.1), (5.0, side * 4.1)],
            pal.fill,
            0.0,
            ink,
        );
    }
    // 尾舱储物筐边框（测量：车长 0.55..0.71 段）
    px.unit_poly(
        tc,
        turret,
        &[(-3.4, -5.0), (-8.4, -5.0), (-8.4, 5.0), (-3.4, 5.0)],
        pal.light,
        0.7,
        ink,
    );
    // 筐内两个储物箱
    for side in [-1.0f32, 1.0] {
        let (ya, yb) = if side < 0.0 { (-4.5, -1.1) } else { (1.1, 4.5) };
        px.unit_poly(tc, turret, &[(-3.9, ya), (-7.9, ya), (-7.9, yb), (-3.9, yb)], pal.dark, 0.5, ink);
        px.unit_line(tc, turret, (-5.9, ya), (-5.9, yb), 0.5, ink);
    }
    // 车长/装填手大圆舱盖
    for (hx, hy) in [(-3.0, 3.1), (-1.7, -3.2)] {
        disc(px, tc, turret, (hx, hy), 2.3, ink, pal.fill, Some(pal.dark));
    }
    // CROWS 遥控武器站（车长位）
    disc(px, tc, turret, (-3.0, 3.1), 0.9, ink, pal.metal, None);
    px.unit_line(tc, turret, (-3.0, 3.1), (-0.4, 4.3), 0.5, pal.metal);
    // 炮长主瞄具（右前深色方箱）
    px.unit_poly(tc, turret, &[(4.9, 1.2), (6.7, 1.2), (6.7, 2.7), (4.9, 2.7)], pal.dark, 0.5, ink);
    // 炮塔颊部烟幕弹发射器（外斜小方块）
    for side in [-1.0f32, 1.0] {
        px.unit_poly(
            tc,
            turret,
            &[(6.6, side * 5.6), (8.3, side * 5.0), (8.7, side * 5.9), (7.0, side * 6.4)],
            pal.metal,
            0.4,
            ink,
        );
    }

    // ---- 炮框 + 120mm 滑膛炮（热护套 + 炮口套管；悬出车首 ≈17% 车长）----
    px.unit_poly(tc, turret, &[(8.6, -1.8), (11.0, -1.8), (11.0, 1.8), (8.6, 1.8)], pal.metal, 0.6, ink);
    px.unit_line(tc, turret, (10.4, 0.0), (15.4, 0.0), 2.4, pal.metal);
    px.unit_line(tc, turret, (15.4, 0.0), (22.2, 0.0), 1.5, pal.metal);
    px.unit_poly(tc, turret, &[(21.8, -1.05), (24.0, -1.05), (24.0, 1.05), (21.8, 1.05)], pal.metal, 0.5, ink);
    px.unit_line(tc, turret, (24.0, 0.0), (24.8, 0.0), 0.9, pal.metal);

    px.star(xform(c, hull, (-16.4, 0.0), px.s), 1.8, hull, STAR_WHITE);
}
