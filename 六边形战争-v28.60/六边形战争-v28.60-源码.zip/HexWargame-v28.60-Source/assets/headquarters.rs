//! 棋子美术 · 指挥部。
//!
//! 指挥帐篷 + 中线/门 + 星徽 + 天线（屏幕正立，不随朝向旋转）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px, STAR_WHITE};

/// 绘制指挥部棋子本体（不含血条/角标/选中框）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, dim: bool) {
    let pal = palette(u.team, dim);
    // 帐篷主体（俯视棱形）
    px.unit_poly(
        c,
        0.0,
        &[(-11.0, -8.0), (8.0, -8.0), (13.0, 0.0), (8.0, 8.0), (-11.0, 8.0)],
        pal.fill,
        1.4,
        pal.ink,
    );
    // 帐篷中线 + 门
    px.unit_line(c, 0.0, (8.0, 0.0), (-11.0, 0.0), 1.0, pal.ink);
    px.unit_poly(c, 0.0, &[(13.0, -2.2), (15.0, 0.0), (13.0, 2.2)], pal.dark, 0.0, pal.ink);
    // 天线
    px.unit_line(c, 0.0, (-6.0, -8.0), (-9.0, -14.0), 1.0, pal.ink);
    px.unit_circle(c, 0.0, (-9.0, -14.0), 1.1, pal.light);
    // 星徽
    px.star(xform(c, 0.0, (-3.0, 0.0), px.s), 4.2, 0.0, STAR_WHITE);
    let _ = u;
}
