//! 棋子美术 · 步兵共用件。
//!
//! 俯视士兵、班组队列与 2 人武器小组的共用绘制：
//! - `draw_soldier`：单兵（圆身 + 头盔 + 步枪，可背负火箭筒/防空导弹，筒身
//!   沿体侧与头盔相切）；
//! - `draw_squad`：步枪手/精锐步兵/特战小队的班组队列——人数 = HP×4，按
//!   4 人菱形小组排布（满编步枪手 3 组、特战 2 组）；每组默认 1 具火箭筒
//!   （特战一组 2 具 + 另一组 1 具 1 毒刺），发射 1 弹消失 1 具，HP 损失
//!   整组消失、未发射的筒具转移到幸存小组由其他队员背负；
//! - `draw_shoulder_team`：Javelin 射手 / 防空导弹手的肩扛发射筒小组；
//! - `type_badge`：反坦克（橙底坦克剪影）/ 防空（青底战机剪影）小图标。
//!
//! 各步兵棋子的入口文件（assets/rifleman.rs、assets/atgm.rs 等）调用这里；
//! 需要为某个兵种单独差异化外观时，改它的入口文件即可。

use eframe::egui::{self, Color32, Pos2, Stroke};
use crate::unit::{Unit, UnitKind};

use super::common::{palette, tint, xform, Palette, Px, OLIVE, OLIVE_DARK};

/// 棋子上的士兵人数（随当前 HP 变化）。
pub fn soldiers_alive(kind: UnitKind, hp: i32) -> usize {
    match kind {
        UnitKind::Rifleman | UnitKind::EliteInfantry => (hp * 4).clamp(0, 12) as usize,
        UnitKind::SpecialForces => (hp * 4).clamp(0, 8) as usize,
        UnitKind::Headquarters => 1,
        // TOW/Javelin/防空/重机枪 = 2 人班组
        _ => 2,
    }
}

/// 菱形小组内 4 个槽位（相对小组中心）：排头 / 队尾 / 左 / 右。
const DIAMOND: [(f32, f32); 4] = [(3.4, 0.0), (-3.4, 0.0), (0.0, -4.0), (0.0, 4.0)];

/// 小组中心阵型（均在六边形格子内）：
/// 1 组居中；2 组沿竖直中线并排（上/下 1/4 处）；
/// 3 组为尖朝前的等边三角形（外接圆半径 13.5，边长 ≈23 显著大于组内间距）。
fn team_centers(k: usize) -> Vec<(f32, f32)> {
    match k {
        1 => vec![(0.0, 0.0)],
        2 => vec![(0.0, -13.0), (0.0, 13.0)],
        _ => {
            let r = 13.5;
            vec![(r, 0.0), (-r * 0.5, -r * 0.866), (-r * 0.5, r * 0.866)]
        }
    }
}

/// 班组队列槽位（局部坐标，+x 前方，索引 0 = 排头）。
///
/// 步枪手/精锐/特战 = 若干 4 人菱形小组（人数 = HP×4，组数 = HP）；
/// 槽位按小组顺序整组排列，队尾一组即伤亡特效（main.rs）取走的位置。
pub fn soldier_slots(count: usize) -> Vec<(f32, f32)> {
    if count >= 4 && count % 4 == 0 {
        let mut v = Vec::with_capacity(count);
        for tc in team_centers(count / 4) {
            for d in DIAMOND {
                v.push((tc.0 + d.0, tc.1 + d.1));
            }
        }
        return v;
    }
    match count {
        0 => Vec::new(),
        1 => vec![(0.0, 0.0)],
        2 => vec![(1.0, -3.6), (1.0, 3.6)],
        n => {
            let mut v = Vec::with_capacity(n);
            for i in 0..n {
                let row = (i / 2) as f32;
                let x = 10.0 - row * 5.2;
                let y = if i % 2 == 0 { -4.0 } else { 4.0 };
                v.push((x, y));
            }
            v
        }
    }
}

/// 背负的特殊弹药。
#[derive(Clone, Copy, PartialEq)]
pub enum BackWeapon {
    Rocket,   // M3E1-XM1176（步枪手）
    RocketHe, // M3E1-HE（精锐/特战：弹体红色标识带）
    Aa,       // Stinger 防空导弹
}

/// HE 火箭弹的红色标识带（与步枪手 XM1176 区分）。
const HE_BAND: Color32 = Color32::from_rgb(196, 60, 44);

/// 头盔装饰：精锐 = 深色盔带圆环；特战 = 枣红色条纹（贝雷帽风格）。
#[derive(Clone, Copy, PartialEq)]
pub enum HelmetMark {
    None,
    EliteBand,
    SfStripe,
}

/// 特战条纹的枣红色。
const SF_MAROON: Color32 = Color32::from_rgb(122, 34, 40);

/// 单具背负筒身（挂 `side` 侧，近缘与身体轮廓相切、不穿过头盔）。
fn draw_back_tube(px: &Px, c: Pos2, facing: f32, w: BackWeapon, side: f32) {
    let t = side;
    match w {
        BackWeapon::Rocket | BackWeapon::RocketHe => {
            px.unit_poly(c, facing, &[(-4.6, t * 3.3), (1.8, t * 3.3), (1.8, t * 4.7), (-4.6, t * 4.7)], OLIVE, 0.7, OLIVE_DARK);
            px.unit_poly(c, facing, &[(-5.4, t * 4.5), (-4.6, t * 4.5), (-4.6, t * 3.5), (-5.4, t * 3.5)], OLIVE_DARK, 0.0, OLIVE_DARK);
            if w == BackWeapon::RocketHe {
                // HE 弹红色标识带（弹体前段）
                px.unit_poly(c, facing, &[(0.4, t * 3.3), (1.4, t * 3.3), (1.4, t * 4.7), (0.4, t * 4.7)], HE_BAND, 0.0, HE_BAND);
            }
        }
        BackWeapon::Aa => {
            px.unit_poly(c, facing, &[(-5.6, t * 3.3), (2.0, t * 3.3), (2.0, t * 4.9), (-5.6, t * 4.9)], OLIVE, 0.7, OLIVE_DARK);
            // 导弹头 + 探测头
            px.unit_poly(c, facing, &[(-6.8, t * 3.2), (-5.6, t * 3.2), (-5.6, t * 5.0), (-6.8, t * 5.0)], OLIVE_DARK, 0.0, OLIVE_DARK);
            px.unit_circle(c, facing, (-3.4, t * 4.1), 0.7, Color32::from_rgb(190, 200, 150));
        }
    }
}

/// 绘制一名俯视士兵：圆身 + 头 + 步枪线，可背负火箭筒/防空导弹。
/// 1 具挂 `tube_side` 侧（默认 -y，外侧队员可挂 +y）；2 具分挂两侧（一人双背）。
/// `mark` = 头盔装饰（精锐盔带 / 特战条纹）。
pub fn draw_soldier(
    px: &Px,
    c: Pos2,
    pal: &Palette,
    facing: f32,
    backs: &[BackWeapon],
    dead: bool,
    tube_side: f32,
    mark: HelmetMark,
) {
    let (fill, ink, dark) = if dead {
        (
            Color32::from_rgb(118, 118, 114),
            Color32::from_rgb(52, 52, 50),
            Color32::from_rgb(88, 88, 86),
        )
    } else {
        (pal.fill, pal.ink, pal.dark)
    };
    // 背包
    px.unit_poly(c, facing, &[(-3.6, -1.5), (-1.2, -1.5), (-1.2, 1.5), (-3.6, 1.5)], dark, 0.0, ink);
    // 背负的特殊弹药
    for (i, w) in backs.iter().take(2).enumerate() {
        draw_back_tube(px, c, facing, *w, if i == 0 { tube_side } else { -tube_side });
    }
    // 身体（肩圆）
    px.unit_circle(c, facing, (0.0, 0.0), 2.8, fill);
    // 头盔
    px.unit_circle(c, facing, (0.8, 0.0), 1.6, if dead { dark } else { pal.light });
    if !dead {
        match mark {
            HelmetMark::None => {}
            HelmetMark::EliteBand => {
                // 精锐：头盔深色盔带圆环
                px.p.add(egui::Shape::circle_stroke(
                    xform(c, facing, (0.8, 0.0), px.s),
                    1.05 * px.s,
                    Stroke::new(0.55 * px.s, tint(OLIVE_DARK, px.a)),
                ));
            }
            HelmetMark::SfStripe => {
                // 特战：头盔前后向枣红色条纹
                px.unit_line(c, facing, (-0.7, 0.0), (2.3, 0.0), 0.6, SF_MAROON);
            }
        }
    }
    px.p.add(egui::Shape::circle_stroke(
        xform(c, facing, (0.0, 0.0), px.s),
        2.8 * px.s,
        Stroke::new(1.0 * px.s, tint(ink, px.a)),
    ));
    // 步枪（阵亡者步枪甩开）
    if dead {
        px.unit_line(c, facing + 0.9, (0.0, 1.0), (6.0, 1.0), 1.0, ink);
    } else {
        px.unit_line(c, facing, (1.6, 1.0), (7.0, 0.4), 1.2, ink);
        px.unit_line(c, facing, (3.2, 0.9), (3.2, 1.7), 1.0, ink); // 弹匣
    }
}

/// 肩上武器（发射动画：把背后的筒子扛到肩上指向目标）。
pub fn draw_shoulder_weapon(px: &Px, c: Pos2, aim: f32, weapon: BackWeapon, progress: f32) {
    let a = (progress.clamp(0.0, 1.0) * 255.0) as u8;
    let px = Px { a, ..*px };
    match weapon {
        BackWeapon::Rocket | BackWeapon::RocketHe => {
            px.unit_poly(c, aim, &[(0.6, -0.9), (8.4, -0.9), (8.4, 0.9), (0.6, 0.9)], OLIVE, 0.7, OLIVE_DARK);
            px.unit_poly(c, aim, &[(8.4, -0.6), (9.4, -0.6), (9.4, 0.6), (8.4, 0.6)], OLIVE_DARK, 0.0, OLIVE_DARK);
            if weapon == BackWeapon::RocketHe {
                px.unit_poly(c, aim, &[(6.0, -0.9), (7.2, -0.9), (7.2, 0.9), (6.0, 0.9)], HE_BAND, 0.0, HE_BAND);
            }
        }
        BackWeapon::Aa => {
            px.unit_poly(c, aim, &[(-1.0, -1.0), (9.4, -1.0), (9.4, 1.0), (-1.0, 1.0)], OLIVE, 0.7, OLIVE_DARK);
            px.unit_poly(c, aim, &[(9.4, -0.7), (10.6, -0.7), (10.6, 0.7), (9.4, 0.7)], OLIVE_DARK, 0.0, OLIVE_DARK);
            px.unit_poly(c, aim, &[(-2.2, -1.3), (-1.0, -1.3), (-1.0, 1.3), (-2.2, 1.3)], OLIVE_DARK, 0.0, OLIVE_DARK);
        }
    }
}

/// 步兵班组队列（步枪手/精锐/特战）：4 人菱形小组。
/// `fire`：(瞄准角, 上肩进度, 武器)。武器 None = 步枪开火（只转向排头士兵）。
/// 发射动画期间弹离膛前，发射手仍 +1 显示背负。
pub fn draw_squad(
    px: &Px,
    c: Pos2,
    u: &Unit,
    facing: f32,
    dim: bool,
    fire: Option<(f32, f32, Option<BackWeapon>)>,
) {
    let pal = palette(u.team, dim);
    let alive = soldiers_alive(u.kind, u.hp) as usize;
    if alive == 0 {
        return;
    }
    let sf = u.kind == UnitKind::SpecialForces;
    // 精锐/特战 = 老兵外观（盔带/条纹）+ M3E1-HE 弹种；步枪手 = XM1176
    let veteran = u.kind != UnitKind::Rifleman;
    let mark = match u.kind {
        UnitKind::EliteInfantry => HelmetMark::EliteBand,
        UnitKind::SpecialForces => HelmetMark::SfStripe,
        _ => HelmetMark::None,
    };
    let rocket_kind = if veteran { BackWeapon::RocketHe } else { BackWeapon::Rocket };
    // 筒具数 = 剩余弹数（1 弹 1 具）：步枪手/精锐 4 具火箭筒、特战 4 筒 + 1 刺。
    // 发射 1 弹消失 1 具；损 HP 整组消失、筒具向幸存小组集中（挤不下时一人双背）
    let mut rockets = (u.missile_ammo as usize).min(alive * 2);
    let mut aa = if sf && u.aa_ammo > 0 { 1 } else { 0 };
    // 发射动画中：发射手在弹离膛前仍显示背负/上肩
    if let Some((_, progress, Some(w))) = fire {
        if progress < 1.0 {
            match w {
                BackWeapon::Rocket | BackWeapon::RocketHe => rockets += 1,
                BackWeapon::Aa => aa += 1,
            }
        }
    }
    let rockets = rockets.min(alive * 2);
    let aa = aa.min(1);
    let slots = soldier_slots(alive);
    let n_teams = (alive / 4).max(1);

    // 小组分配：均分、余具给靠前的小组；毒刺固定在最后一组。
    // 组内槽位顺序：队尾 → 左 → 排头 → 右；超出 4 具时由队尾队员双背。
    const ORDER: [usize; 4] = [1, 2, 0, 3];
    let mut backs: Vec<Vec<BackWeapon>> = vec![Vec::new(); alive];
    let (base, rem) = (rockets / n_teams, rockets % n_teams);
    for t in 0..n_teams {
        let mut ws = vec![rocket_kind; base + if t < rem { 1 } else { 0 }];
        if aa > 0 && t == n_teams - 1 {
            ws.push(BackWeapon::Aa);
        }
        for (i, w) in ws.iter().enumerate() {
            let s = if i < ORDER.len() { ORDER[i] } else { ORDER[0] };
            backs[t * 4 + s].push(*w);
        }
    }
    // 正在发射的士兵：步枪 = 排头；火箭筒 = 最前一位筒手；防空导弹 = 毒刺手
    let shooter: usize = match fire {
        Some((_, _, Some(BackWeapon::Aa))) => (0..alive)
            .find(|&i| backs[i].contains(&BackWeapon::Aa))
            .unwrap_or(0),
        Some((_, _, Some(w))) => {
            // 火箭筒（XM1176 / HE 同规则）
            let mut best: Option<usize> = None;
            for i in 0..alive {
                if backs[i].contains(&w) && best.map_or(true, |b| slots[i].0 > slots[b].0) {
                    best = Some(i);
                }
            }
            best.unwrap_or(0)
        }
        _ => 0,
    };
    // 从队尾往前画，排头压在最上层
    for i in (0..alive).rev() {
        let (lx, ly) = slots[i];
        let mut f = facing;
        let mut shoulder = None;
        if i == shooter {
            if let Some((aim, progress, w)) = fire {
                f = aim;
                if let Some(w) = w {
                    if progress > 0.02 {
                        shoulder = Some((aim, w, progress));
                    }
                }
            }
        }
        let sc = xform(c, facing, (lx, ly), px.s);
        let tube_side = if i % 4 == 3 { 1.0 } else { -1.0 }; // 右侧队员筒挂外侧
        let shown: Vec<BackWeapon> = if shoulder.is_some() { Vec::new() } else { backs[i].clone() };
        draw_soldier(px, sc, &pal, f, &shown, false, tube_side, mark);
        if let Some((aim, w, progress)) = shoulder {
            draw_shoulder_weapon(px, sc, aim, w, progress);
        }
    }
}

/// 反坦克/防空小图标：屏幕正立，不随朝向旋转。
/// AT = 橙底坦克剪影；AA = 青底战机剪影。
pub fn type_badge(px: &Px, at: Pos2, aa: bool) {
    let bg = if aa {
        Color32::from_rgb(74, 178, 222)
    } else {
        Color32::from_rgb(230, 136, 48)
    };
    let ink = Color32::from_rgb(20, 24, 22);
    let r = 3.6;
    px.poly(
        vec![
            Pos2::new(at.x - r, at.y - r),
            Pos2::new(at.x + r, at.y - r),
            Pos2::new(at.x + r, at.y + r),
            Pos2::new(at.x - r, at.y + r),
        ],
        bg,
        Stroke::new(0.7, ink),
    );
    if aa {
        // 战机剪影：机身 + 后掠主翼 + 尾翼
        px.line(Pos2::new(at.x, at.y - 2.7), Pos2::new(at.x, at.y + 2.4), 1.0, ink);
        px.poly(
            vec![
                Pos2::new(at.x - 2.7, at.y + 0.7),
                Pos2::new(at.x + 2.7, at.y + 0.7),
                Pos2::new(at.x, at.y - 1.1),
            ],
            ink,
            Stroke::NONE,
        );
        px.poly(
            vec![
                Pos2::new(at.x - 1.2, at.y + 2.5),
                Pos2::new(at.x + 1.2, at.y + 2.5),
                Pos2::new(at.x, at.y + 1.1),
            ],
            ink,
            Stroke::NONE,
        );
    } else {
        // 坦克剪影：车体 + 炮塔 + 炮管（朝右）
        px.poly(
            vec![
                Pos2::new(at.x - 2.7, at.y + 0.1),
                Pos2::new(at.x + 1.3, at.y + 0.1),
                Pos2::new(at.x + 1.3, at.y + 1.7),
                Pos2::new(at.x - 2.7, at.y + 1.7),
            ],
            ink,
            Stroke::NONE,
        );
        px.poly(
            vec![
                Pos2::new(at.x - 1.3, at.y - 1.1),
                Pos2::new(at.x + 0.6, at.y - 1.1),
                Pos2::new(at.x + 0.6, at.y + 0.1),
                Pos2::new(at.x - 1.3, at.y + 0.1),
            ],
            ink,
            Stroke::NONE,
        );
        px.line(Pos2::new(at.x + 0.6, at.y - 0.3), Pos2::new(at.x + 2.9, at.y - 0.3), 0.8, ink);
    }
}

/// 肩扛发射筒小组（Javelin / 防空导弹手）。
/// 2 名步兵各自操作 1 具发射筒（aa=false 为 Javelin，true 为 Stinger），
/// 士兵旁加小图标区分反坦克（橙·坦克）/ 防空（青·战机）。
pub fn draw_shoulder_team(px: &Px, c: Pos2, u: &Unit, facing: f32, dim: bool, aa: bool) {
    let pal = palette(u.team, dim);
    for side in [-1.0f32, 1.0] {
        let (lx, ly) = (1.5, side * 5.6);
        let sc = xform(c, facing, (lx, ly), px.s);
        draw_soldier(px, sc, &pal, facing, &[], false, -1.0, HelmetMark::None);
        // 各自的发射筒：扛在肩侧（与朝向平行）
        let (w, tip) = if aa { (1.3, 8.6) } else { (1.6, 8.0) };
        let y0 = side * 1.7;
        px.unit_poly(
            sc,
            facing,
            &[(-2.2, y0 - w * 0.5), (tip, y0 - w * 0.5), (tip, y0 + w * 0.5), (-2.2, y0 + w * 0.5)],
            OLIVE,
            0.7,
            OLIVE_DARK,
        );
        if aa {
            // Stinger：敌我识别盒 + 导弹头
            px.unit_poly(sc, facing, &[(1.0, y0 - w * 0.8), (2.6, y0 - w * 0.8), (2.6, y0 + w * 0.8), (1.0, y0 + w * 0.8)], OLIVE_DARK, 0.0, OLIVE_DARK);
            px.unit_poly(sc, facing, &[(tip - 1.2, y0 - w * 0.4), (tip, y0 - w * 0.4), (tip, y0 + w * 0.4), (tip - 1.2, y0 + w * 0.4)], OLIVE_DARK, 0.0, OLIVE_DARK);
        } else {
            // Javelin：瞄准具（CLU）+ 软发射锥头
            px.unit_poly(sc, facing, &[(-3.6, y0 - w * 0.7), (-2.2, y0 - w * 0.7), (-2.2, y0 + w * 0.7), (-3.6, y0 + w * 0.7)], OLIVE_DARK, 0.0, OLIVE_DARK);
            px.unit_poly(sc, facing, &[(tip - 1.6, y0 - w * 0.35), (tip, y0 - w * 0.35), (tip, y0 + w * 0.35), (tip - 1.6, y0 + w * 0.35)], OLIVE_DARK, 0.0, OLIVE_DARK);
        }
        type_badge(px, Pos2::new(sc.x + 6.6 * px.s, sc.y - 7.4 * px.s), aa);
    }
}
