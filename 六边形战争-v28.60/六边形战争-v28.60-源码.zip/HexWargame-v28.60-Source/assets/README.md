# assets/ —— 棋子美术目录

所有棋子的俯视绘制代码按**兵种**拆分在本目录，每种棋子一个文件。由
`src/pieces.rs` 用标准模块机制（`#[path] mod`，编译期静态加载）挂进编译单元，
游戏运行时通过 `pieces::draw_unit_body(...)` 按兵种分发到这里。

## 目录结构

| 文件 | 内容 |
| --- | --- |
| `common.rs` | 绘制基础件：画笔 `Px`（统一缩放/透明度）、坐标变换 `xform` / `angle_between`、阵营配色 `palette()`（玩家蓝 / AI 红 / `WRECK` 残骸灰）、通用色 `OLIVE` / `STAR_WHITE` |
| `infantry.rs` | 步兵共用件：单兵 `draw_soldier`（精锐/特战头盔带盔带装饰）、班组队列 `draw_squad`（4 人菱形小组：人数 = HP×4，发射 1 弹消失 1 具筒具、损 HP 整组消失且筒具转移；精锐/特战用 M3E1-HE 红色标识带弹种，区别于步枪手 XM1176）、肩扛发射筒小组 `draw_shoulder_team`、反坦克/防空小图标 `type_badge` |
| `parts.rs` | 载具/飞行器共用部件：履带 `track_assembly` / `tracks`、炮管 `barrel`、直升机旋翼 `rotor`、圆盘件 `disc`（车轮在车体下，不画出车体外） |
| `render_golden.rs` | 渲染回归基准测试（见下文） |
| 其余 `<兵种>.rs` | 各兵种美术，每个文件导出一个 `draw(...)` 入口 |

## 兵种文件一览

| 文件 | 兵种 | 实际形象 |
| --- | --- | --- |
| `rifleman.rs` | 步枪手 | 12 人 = 3 个 4 人菱形小组，每组 1 具火箭筒（共用 `infantry.rs::draw_squad`） |
| `elite_infantry.rs` | 精锐步兵班组 | 12 人 = 3 个 4 人菱形小组，每组 1 具火箭筒（共用 `draw_squad`） |
| `special_forces.rs` | 特战小队 | 8 人 = 2 个 4 人菱形小组（2 筒 + 1 筒 1 刺）（共用 `draw_squad`） |
| `atgm.rs` | TOW 射手 | 三脚架双联发射器 + 2 名射手 |
| `javelin.rs` | Javelin 射手 | 肩扛发射筒小组（共用 `draw_shoulder_team`） |
| `aa_infantry.rs` | 防空导弹手 | Stinger 肩扛发射筒小组（共用 `draw_shoulder_team`） |
| `hmg_gunner.rs` | 重机枪手 | 2 人共用 1 挺重机枪 |
| `headquarters.rs` | 指挥部 | 指挥帐篷 + 星徽 + 天线 |
| `tank.rs` | 坦克 | M60 巴顿（蛋形炮塔，参照 `docs/topview-refs/M60-Topview.png`） |
| `heavy_tank.rs` | 主战坦克 | M1A2 艾布拉姆斯（裙板履带 + 棱角炮塔，参照 `docs/topview-refs/M1A2-Topview.png`） |
| `ifv.rs` | 步兵战车 | M2 布莱德利（左肩双联 TOW + 25mm 链炮，参照 `docs/topview-refs/M2Bradley-Topview.png`） |
| `cavalry_ifv.rs` | 装甲骑兵战车 | M3 布莱德利骑兵型（圆筒 TOW 发射器 + 车尾双天线，参照 `docs/topview-refs/M3Bradley-Topview.png`） |
| `scout.rs` | 侦察战车 | M551 谢里登 |
| `truck.rs` | 卡车 | FMTV 战术卡车 |
| `howitzer.rs` | 榴弹炮 | M777A2 牵引榴弹炮（分式大架 + 双轮胎 + 长炮管） |
| `mortar.rs` | 自行迫击炮 | M1129（斯崔克底盘） |
| `aa_mgv.rs` | M-SHORAD | 斯崔克 + 30mm 链炮 + 四联 Stinger |
| `humvee.rs` | 悍马系列共用底盘 | M1151 风格 4×4 车体 + 车内遥控武器站（重机枪 / TOW / Javelin / 四联 Stinger 四个入口） |
| `aa_launcher.rs` | 悍马-Stinger | 悍马底盘 + 遥控四联 Stinger（委托 `humvee.rs`） |
| `attack_heli.rs` | 武装直升机 | AH-64 阿帕奇 |
| `transport_heli.rs` | 运输直升机 | UH-60 黑鹰 |
| `heavy_transport_heli.rs` | 重型运输直升机 | CH-47 支奴干（纵列双旋翼） |
| `drone.rs` | 侦察无人机 | 平直翼 + 推进式螺旋桨 |

## 绘制约定

- **局部坐标**：以 `+x` 为前方（屏幕向右），调用方传入朝向角统一旋转；
  长度单位为“基准像素”（s=1），绘制时统一乘 `Px.s`。
- **车辆** = 车身（随移动路径转向 `hull`）与炮塔（随最后一次开火转向 `turret`）
  分层绘制；`hp <= 0` 时整体使用 `WRECK` 残骸灰。
- **轮式车辆** = 纯车体俯视：车轮位于车体正下方不参与画面，车体外不得出现
  半圆轮子凸出（履带车辆的履带窄条除外）。
- **步兵** = 班组队列：人数随 HP 减少；背负火箭筒/防空导弹的人数随剩余弹药变化；
  开火动画把背后的筒子扛上肩（`fire` 参数）。
- **入口签名**（按类别）：
  - 步兵班组：`draw(px, c, u, facing, dim, fire)`
  - 武器小组：`draw(px, c, u, facing, dim, firing)`
  - 载具：`draw(px, c, u, hull, turret, dim)`
  - 空中单位：`draw(px, c, u, facing, time, dim)`
  - 指挥部：`draw(px, c, u, dim)`

## 如何针对性修改某个棋子

1. 直接改对应兵种文件（如重画坦克就改 `tank.rs`）；需要新部件时加进
   `parts.rs` / `infantry.rs` 供多兵种共用。
2. 改完运行 `cargo test --bin hex_wargame render_golden`：基准测试会精确列出
   画面发生变化的兵种与参数组。
3. 若变化符合预期，用
   `REGENERATE_GOLDEN=1 cargo test --bin hex_wargame render_golden -- --nocapture`
   的输出更新 `golden_render_hashes.txt` 并一并提交。
