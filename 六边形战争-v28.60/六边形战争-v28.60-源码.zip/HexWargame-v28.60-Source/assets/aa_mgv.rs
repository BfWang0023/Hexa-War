//! 棋子美术 · M-SHORAD 高射机枪战车（斯崔克 8×8 底盘）。
//!
//! RWS 遥控炮塔：30mm 链炮 + 四联 Stinger（2×2），空/地都能打。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px, OLIVE, OLIVE_DARK, STAR_WHITE, WRECK};

/// 绘制 M-SHORAD 棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;
    // M-SHORAD（斯崔克 8×8）：车体俯视（轮在车体下不参与画面）
    px.unit_poly(
        c,
        hull,
        &[(-14.5, -8.0), (13.0, -8.0), (15.5, -3.4), (15.5, 3.4), (13.0, 8.0), (-14.5, 8.0)],
        pal.fill,
        1.3,
        ink,
    );
    let tc = xform(c, hull, (2.0, 0.0), px.s);
    // RWS 炮塔
    px.unit_poly(tc, turret, &[(-3.0, -2.8), (3.4, -2.8), (4.6, -1.4), (4.6, 1.4), (3.4, 2.8), (-3.0, 2.8)], pal.light, 1.2, ink);
    // 30mm 链炮
    px.unit_line(tc, turret, (4.2, 1.0), (10.5, 1.0), 1.4, pal.metal);
    // 四联 Stinger 管（2×2）
    for (dx, dy) in [(-4.6, -3.0), (-4.6, 0.0), (-1.8, -3.0), (-1.8, 0.0)] {
        px.unit_poly(tc, turret, &[(dx, dy - 1.1), (dx + 2.2, dy - 1.1), (dx + 2.2, dy + 1.1), (dx, dy + 1.1)], OLIVE, 0.7, OLIVE_DARK);
    }
    px.star(xform(c, hull, (-11.0, 0.0), px.s), 2.4, hull, STAR_WHITE);
}
