//! 棋子美术 · 悍马-Stinger（原“防空导弹发射车”）。
//!
//! 悍马 4×4 底盘 + 车内遥控四联 Stinger 发射箱。车体与武器站共用 `humvee.rs`：
//! 车体随 `hull`、发射箱随 `turret` 转向；车轮位于车体正下方不参与画面。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::Px;

/// 绘制悍马-Stinger 棋子本体（委托悍马共用底盘 + 四联 Stinger 武器站）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    super::humvee::draw_stinger(px, c, u, hull, turret, dim);
}
