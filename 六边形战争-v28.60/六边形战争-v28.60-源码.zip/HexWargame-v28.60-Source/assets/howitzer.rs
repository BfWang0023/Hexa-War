//! 棋子美术 · 榴弹炮（M777A2 牵引榴弹炮）。
//!
//! 分开式大架（尾部分叉 + 驻锄板）+ 轮轴横梁 + 两侧充气轮胎 + 155mm 长炮管
//! （炮口制退器、驻退筒、平衡机、瞄准具）。大架/车轮固定于放列方向（hull），
//! 上架/炮盾/炮管随瞄准转动（turret）；范围攻击 + 压制，需先架设，不能自主移动。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Palette, Px, STAR_WHITE, WRECK};
use super::parts::{barrel, disc};

/// 充气轮胎：胶囊形（滚动方向拉长）+ 轮毂。
fn tire(px: &Px, c: Pos2, ang: f32, y: f32, pal: &Palette) {
    let (hl, hw) = (3.3, 2.0); // 半长 / 胎面半宽
    let mut pts = Vec::with_capacity(16);
    for i in 0..=6 {
        let a = -std::f32::consts::FRAC_PI_2 + std::f32::consts::PI * i as f32 / 6.0;
        pts.push((hl - hw + hw * a.cos(), y + hw * a.sin()));
    }
    for i in 0..=6 {
        let a = std::f32::consts::FRAC_PI_2 + std::f32::consts::PI * i as f32 / 6.0;
        pts.push((-(hl - hw) + hw * a.cos(), y + hw * a.sin()));
    }
    px.unit_poly(c, ang, &pts, pal.dark, 0.9, pal.ink);
    disc(px, c, ang, (0.0, y), 1.15, pal.ink, pal.metal, None);
}

/// 绘制榴弹炮棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;

    // ---- 分开式大架（固定于放列方向 hull）：V 形张开 + 端部驻锄板 ----
    for side in [-1.0f32, 1.0] {
        px.unit_poly(
            c,
            hull,
            &[
                (0.6, side * 2.0),
                (-12.4, side * 5.6),
                (-12.4, side * 7.4),
                (0.6, side * 3.8),
            ],
            pal.fill,
            1.0,
            ink,
        );
        px.unit_poly(
            c,
            hull,
            &[(-14.2, side * 4.9), (-12.4, side * 4.9), (-12.4, side * 7.7), (-14.2, side * 7.7)],
            pal.dark,
            0.9,
            ink,
        );
        // 大架铰接套筒（架腿中段）
        disc(px, c, hull, (-6.8, side * 4.95), 0.9, ink, pal.dark, None);
    }

    // ---- 轮轴横梁 + 两侧轮胎（露在基座与轮胎之间连成整体）----
    px.unit_poly(c, hull, &[(-0.9, -7.1), (0.9, -7.1), (0.9, 7.1), (-0.9, 7.1)], pal.dark, 0.9, ink);
    tire(px, c, hull, -7.1, &pal);
    tire(px, c, hull, 7.1, &pal);

    // ---- 上架（随瞄准转动 turret）：基座置于轮轴之上，前缘让出炮盾 ----
    let tc = xform(c, hull, (0.0, 0.0), px.s);
    px.unit_poly(tc, turret, &[(-3.2, -3.8), (3.0, -3.8), (3.0, 3.8), (-3.2, 3.8)], pal.fill, 1.0, ink);
    // 回转轴心
    disc(px, tc, turret, (-1.8, 0.0), 1.0, ink, pal.dark, Some(pal.metal));
    // 平衡机（炮身两侧细筒）
    for side in [-1.0f32, 1.0] {
        px.unit_poly(tc, turret, &[(-0.4, side * 2.3), (2.6, side * 2.3), (2.6, side * 3.2), (-0.4, side * 3.2)], pal.metal, 0.7, ink);
    }
    // 炮盾
    px.unit_poly(tc, turret, &[(3.0, -5.2), (6.2, -3.2), (6.2, 3.2), (3.0, 5.2)], pal.light, 1.2, ink);
    // 驻退筒（炮盾后加粗段）
    px.unit_line(tc, turret, (4.2, 0.0), (8.4, 0.0), 3.0, pal.metal);
    // 155mm 炮管 + 炮口制退器（大幅悬出架外）
    barrel(px, tc, turret, 8.0, 12.6, 2.0, &pal);
    px.star(xform(tc, turret, (4.6, 0.0), px.s), 1.7, turret, STAR_WHITE);
}
