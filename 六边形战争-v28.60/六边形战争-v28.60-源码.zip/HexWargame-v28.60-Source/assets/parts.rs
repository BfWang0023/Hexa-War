//! 棋子美术 · 载具/飞行器共用部件。
//!
//! - `track_assembly`：圆端胶囊履带（含履带板纹，宽度比例参考真实履带）；
//! - `tracks`：简化履带（履带板矩形 + 履带齿）；
//! - `barrel`：炮管（粗线 + 炮口制退器）；
//! - `rotor`：直升机主旋翼（旋转桨叶 + 半透明桨盘，随 `time` 旋转）；
//! - `disc`：圆盘舱盖/圆鼓部件。
//!
//! 俯视图约定：车轮位于车体正下方不参与画面（车体外不得出现半圆凸出）。

use eframe::egui::{self, Color32, Pos2};

use super::common::{tint, Palette, Px};

/// 履带总成：圆端胶囊外形 + 履带板纹（宽度比例参考真实履带）。
pub fn track_assembly(px: &Px, c: Pos2, ang: f32, half_len: f32, y: f32, width: f32, pal: &Palette) {
    let r = width * 0.5;
    let mut pts = Vec::with_capacity(20);
    for i in 0..=8 {
        let a = -std::f32::consts::FRAC_PI_2 + std::f32::consts::PI * i as f32 / 8.0;
        pts.push((half_len - r + r * a.cos(), y + r * a.sin()));
    }
    for i in 0..=8 {
        let a = std::f32::consts::FRAC_PI_2 + std::f32::consts::PI * i as f32 / 8.0;
        pts.push((-half_len + r + r * a.cos(), y + r * a.sin()));
    }
    px.unit_poly(c, ang, &pts, pal.dark, 0.7, pal.ink);
    // 履带板
    let n = (((half_len * 2.0 - width) / 3.2).floor() as i32).max(2);
    for i in 1..n {
        let x = -half_len + r + i as f32 * 3.2;
        px.unit_line(c, ang, (x, y - r * 0.75), (x, y + r * 0.75), 0.5, pal.ink);
    }
}

/// 履带（坦克/步战/自行火炮底盘）。
pub fn tracks(px: &Px, c: Pos2, ang: f32, half_len: f32, half_w: f32, pal: &Palette) {
    for y in [-1.0, 1.0] {
        let yc = y * half_w;
        px.unit_poly(
            c,
            ang,
            &[(-half_len, yc - 2.2), (half_len, yc - 2.2), (half_len, yc + 2.2), (-half_len, yc + 2.2)],
            pal.dark,
            0.9,
            pal.ink,
        );
        // 履带齿
        for i in -3..=3 {
            let x = i as f32 * half_len / 3.5;
            px.unit_line(c, ang, (x, yc - 2.2), (x, yc + 2.2), 0.7, pal.ink);
        }
    }
}

/// 炮管：粗线 + 炮口制退器。
pub fn barrel(px: &Px, c: Pos2, ang: f32, from_x: f32, len: f32, w: f32, pal: &Palette) {
    px.unit_line(c, ang, (from_x, 0.0), (from_x + len, 0.0), w, pal.metal);
    let mz = from_x + len - 1.6;
    px.unit_poly(
        c,
        ang,
        &[(mz, -w * 0.95), (mz + 2.6, -w * 0.95), (mz + 2.6, w * 0.95), (mz, w * 0.95)],
        pal.metal,
        0.6,
        pal.ink,
    );
}

/// 主旋翼：旋转桨叶 + 半透明桨盘。
pub fn rotor(px: &Px, c: Pos2, r: f32, time: f64, pal: &Palette) {
    px.p.add(egui::Shape::circle_filled(c, r * px.s, tint(Color32::from_rgba_unmultiplied(200, 205, 200, 26), px.a)));
    let spin = (time * 9.0) as f32;
    for i in 0..3 {
        let a = spin + i as f32 * std::f32::consts::TAU / 3.0;
        let tip = Pos2::new(c.x + r * a.cos() * px.s, c.y + r * a.sin() * px.s);
        px.line(c, tip, 1.1, pal.ink);
    }
    px.circle(c, 1.4, pal.ink);
}

/// 圆盘舱盖/圆鼓部件：16 边形逼近圆 + 描边圈 + 可选中心圆点。
///
/// 比 `Px::circle` 多分段：小半径圆经 egui 低分段 tessellate 后（尤其导出
/// 工具在单位尺度渲染再放大时）会呈方形/八角形，这里显式用 16 边形保证圆润。
pub fn disc(
    px: &Px,
    c: Pos2,
    ang: f32,
    at: (f32, f32),
    r: f32,
    outline: Color32,
    fill: Color32,
    dot: Option<Color32>,
) {
    const N: usize = 16;
    let ring = |rad: f32, col: Color32| {
        let pts: Vec<(f32, f32)> = (0..N)
            .map(|i| {
                let a = std::f32::consts::TAU * i as f32 / N as f32;
                (at.0 + rad * a.cos(), at.1 + rad * a.sin())
            })
            .collect();
        px.unit_poly(c, ang, &pts, col, 0.0, col);
    };
    ring(r + 0.18, outline);
    ring(r, fill);
    if let Some(col) = dot {
        ring(r * 0.32, col);
    }
}
