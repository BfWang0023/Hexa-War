//! 棋子美术 · 防空导弹手（2 人小组，Stinger）。
//!
//! 2 名步兵各自操作 1 具 Stinger 发射筒（敌我识别盒 + 导弹头），
//! 旁加防空小图标（青底战机剪影）。
//! 渲染与 Javelin 射手共用肩扛发射筒小组（`assets/infantry.rs::draw_shoulder_team`）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::Px;
use super::infantry::draw_shoulder_team;

/// 绘制防空导弹手棋子本体（firing 不参与画面，与拆分前一致）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, dim: bool, _firing: bool) {
    draw_shoulder_team(px, c, u, facing, dim, true)
}
