//! 棋子美术 · TOW 导弹射手（2 人小组）。
//!
//! 2 名射手共同操作 1 具三脚架双联发射器，
//! 旁加反坦克小图标（橙底坦克剪影）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px, OLIVE, OLIVE_DARK};
use super::infantry::{draw_soldier, type_badge, HelmetMark};

/// 绘制 TOW 射手棋子本体；firing=true 时在发射器上显示开火亮斑。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, dim: bool, firing: bool) {
    let pal = palette(u.team, dim);
    let ink = pal.ink;
    for &(lx, ly) in [(0.5f32, -3.4f32), (0.5, 3.4)].iter() {
        let sc = xform(c, facing, (lx, ly), px.s);
        draw_soldier(px, sc, &pal, facing, &[], false, -1.0, HelmetMark::None);
    }
    // 三脚架（两条前腿 + 一条后腿）
    px.unit_line(c, facing, (2.6, 0.0), (0.0, -3.0), 1.0, ink);
    px.unit_line(c, facing, (2.6, 0.0), (0.0, 3.0), 1.0, ink);
    px.unit_line(c, facing, (2.6, 0.0), (4.8, 0.0), 1.0, ink);
    // 发射箱（双联）
    px.unit_poly(c, facing, &[(-0.8, -1.8), (6.4, -1.8), (6.4, 1.8), (-0.8, 1.8)], OLIVE, 0.8, OLIVE_DARK);
    px.unit_line(c, facing, (-0.8, 0.0), (6.4, 0.0), 0.6, OLIVE_DARK);
    px.unit_circle(c, facing, (6.4, 0.0), 1.1, OLIVE_DARK);
    if firing {
        px.unit_circle(c, facing, (2.0, 0.0), 0.9, pal.light);
    }
    let lp = xform(c, facing, (2.8, 0.0), px.s);
    type_badge(px, Pos2::new(lp.x + 8.0 * px.s, lp.y - 9.0 * px.s), false);
}
