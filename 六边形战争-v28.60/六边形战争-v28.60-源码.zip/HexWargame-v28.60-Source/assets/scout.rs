//! 棋子美术 · 侦察战车（M551 谢里登）。
//!
//! 轻装甲 + 圆顶炮塔 + 短粗 152mm 炮（炮口抽烟装置）。

use eframe::egui::{self, Pos2, Stroke};
use crate::unit::Unit;

use super::common::{palette, tint, xform, Px, STAR_WHITE, WRECK};
use super::parts::{barrel, tracks};

/// 绘制侦察战车棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;
    // M551 谢里登：轻装甲 + 圆顶炮塔 + 短粗 152mm 炮
    tracks(px, c, hull, 11.5, 8.0, &pal);
    px.unit_poly(
        c,
        hull,
        &[(-11.0, -5.8), (6.0, -5.8), (11.0, -2.6), (11.0, 2.6), (6.0, 5.8), (-11.0, 5.8)],
        pal.fill,
        1.2,
        ink,
    );
    let tc = xform(c, hull, (1.0, 0.0), px.s);
    px.p.add(egui::Shape::circle_stroke(
        xform(tc, turret, (0.0, 0.0), px.s),
        4.4 * px.s,
        Stroke::new(1.2 * px.s, tint(ink, px.a)),
    ));
    px.unit_circle(tc, turret, (0.0, 0.0), 4.4, pal.light);
    barrel(px, tc, turret, 4.0, 7.5, 2.4, &pal);
    // 炮口抽烟装置
    px.unit_circle(tc, turret, (8.0, 0.0), 1.6, pal.metal);
    px.star(xform(tc, turret, (-1.5, 0.0), px.s), 2.2, turret, STAR_WHITE);
}
