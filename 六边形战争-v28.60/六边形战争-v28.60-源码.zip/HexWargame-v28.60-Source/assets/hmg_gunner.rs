//! 棋子美术 · 重机枪手（2 人小组）。
//!
//! 2 名步兵共用 1 挺重机枪（枪管 + 三脚架 + 弹箱）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px, OLIVE_DARK};
use super::infantry::{draw_soldier, soldier_slots, HelmetMark};

/// 绘制重机枪手棋子本体；firing=true 时在枪身上显示开火亮斑。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, dim: bool, firing: bool) {
    let pal = palette(u.team, dim);
    let ink = pal.ink;
    // 2 人共用 1 挺机枪
    for &(lx, ly) in soldier_slots(2).iter() {
        let sc = xform(c, facing, (lx, ly), px.s);
        draw_soldier(px, sc, &pal, facing, &[], false, -1.0, HelmetMark::None);
    }
    px.unit_line(c, facing, (-1.0, 0.0), (7.5, 0.0), 1.8, ink);
    px.unit_line(c, facing, (7.5, 0.0), (9.5, 0.0), 1.0, ink);
    px.unit_line(c, facing, (1.0, 0.0), (0.0, -2.4), 0.9, ink);
    px.unit_line(c, facing, (1.0, 0.0), (0.0, 2.4), 0.9, ink);
    px.unit_poly(c, facing, &[(-2.6, -1.4), (-0.4, -1.4), (-0.4, 1.4), (-2.6, 1.4)], OLIVE_DARK, 0.6, ink);
    if firing {
        px.unit_circle(c, facing, (2.0, 0.0), 0.9, pal.light);
    }
}
