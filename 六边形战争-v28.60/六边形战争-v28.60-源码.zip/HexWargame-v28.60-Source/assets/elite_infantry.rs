//! 棋子美术 · 精锐步兵班组。
//!
//! 12 人 = 3 个 4 人菱形小组，每组 1 具 M3E1-HE 火箭筒（发射 1 弹消失 1 具，
//! 损 HP 整组消失、筒具转移；共用 `assets/infantry.rs::draw_squad`）。
//! 当前与步枪手 / 特战小队共用班组渲染（`assets/infantry.rs::draw_squad`）；
//! 需要为精锐步兵单独差异化外观时，直接在本文件实现 `draw` 即可。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::Px;
use super::infantry::{draw_squad, BackWeapon};

/// 绘制精锐步兵棋子本体（不含血条/角标/选中框）。
pub fn draw(
    px: &Px,
    c: Pos2,
    u: &Unit,
    facing: f32,
    dim: bool,
    fire: Option<(f32, f32, Option<BackWeapon>)>,
) {
    draw_squad(px, c, u, facing, dim, fire)
}
