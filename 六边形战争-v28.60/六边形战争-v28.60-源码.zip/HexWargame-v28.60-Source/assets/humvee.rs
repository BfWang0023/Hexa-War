//! 棋子美术 · 悍马系列共用底盘（M1151/M1165 风格 4×4）。
//!
//! 俯视只见车体：切角车头 + 前保险杠 + 两片式风挡 + 侧门缝 + 后部货斗；
//! **车轮位于车体正下方，不参与画面**（车体外不出现半圆轮子）。
//!
//! 车体随移动路径转向 `hull`；武器为**车内遥控武器站**，随最后一次开火转向 `turret`。
//! 后座没有操作武器的士兵，因此只绘制武器本身的转向，不绘制射手。
//!
//! 各兵种入口：`draw_hmg`（重机枪）/ `draw_tow`（TOW）/ `draw_javelin`（Javelin）/
//! `draw_stinger`（四联 Stinger）。武器站共用同一底盘与底座环。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Palette, Px, OLIVE, OLIVE_DARK, STAR_WHITE, WRECK};
use super::parts::barrel;

/// 遥控武器站回转中心（车体局部坐标，位于后部货斗中央）。
const MOUNT: (f32, f32) = (-9.0, 0.0);

/// 悍马车体 + 武器站底座环（不含武器）。`hull` 为车体朝向。
pub fn chassis(px: &Px, c: Pos2, hull: f32, pal: &Palette) {
    let ink = pal.ink;
    // 主车体：切角车头 + 平直货斗，尾部略收
    px.unit_poly(
        c,
        hull,
        &[
            (-12.6, -7.0),
            (-11.8, -7.6),
            (6.0, -7.6),
            (11.6, -4.4),
            (12.6, -4.0),
            (12.6, 4.0),
            (11.6, 4.4),
            (6.0, 7.6),
            (-11.8, 7.6),
            (-12.6, 7.0),
        ],
        pal.fill,
        1.25,
        ink,
    );
    // 前保险杠
    px.unit_poly(
        c,
        hull,
        &[(12.6, -5.2), (14.2, -5.2), (14.2, 5.2), (12.6, 5.2)],
        pal.metal,
        0.8,
        ink,
    );
    // 机盖中线（避开军徽）
    px.unit_line(c, hull, (6.2, 0.0), (8.0, 0.0), 0.6, ink);
    // 两片式风挡（斜置玻璃）
    px.unit_poly(
        c,
        hull,
        &[(5.2, -6.7), (7.6, -4.5), (7.6, 4.5), (5.2, 6.7)],
        pal.dark,
        0.9,
        ink,
    );
    px.unit_line(c, hull, (6.4, -5.6), (6.4, 5.6), 0.6, ink);
    // 侧门缝
    px.unit_line(c, hull, (1.2, -7.6), (1.2, 7.6), 0.7, ink);
    px.unit_line(c, hull, (-4.6, -7.6), (-4.6, 7.6), 0.7, ink);
    // 货斗边梁
    px.unit_line(c, hull, (-11.8, -6.4), (-0.4, -6.4), 0.6, ink);
    px.unit_line(c, hull, (-11.8, 6.4), (-0.4, 6.4), 0.6, ink);
    px.unit_line(c, hull, (-11.8, -6.9), (-11.8, 6.9), 0.8, ink);
    // 遥控武器站底座环
    px.unit_circle(c, hull, MOUNT, 3.2, pal.dark);
    px.unit_circle(c, hull, MOUNT, 2.3, pal.metal);
    // 军徽（机盖）
    px.star(xform(c, hull, (10.0, 0.0), px.s), 2.0, hull, STAR_WHITE);
}

/// 取武器站的屏幕坐标。
fn mount(px: &Px, c: Pos2, hull: f32) -> Pos2 {
    xform(c, hull, MOUNT, px.s)
}

/// 悍马-重机枪：遥控重机枪（枪身随 `turret` 转向）。
pub fn draw_hmg(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    chassis(px, c, hull, &pal);
    let wc = mount(px, c, hull);
    // 转塔
    px.unit_circle(wc, turret, (0.0, 0.0), 2.3, pal.light);
    // 机枪座
    px.unit_poly(
        wc,
        turret,
        &[(-1.6, -1.5), (1.2, -1.5), (1.2, 1.5), (-1.6, 1.5)],
        pal.dark,
        0.7,
        pal.ink,
    );
    barrel(px, wc, turret, 1.0, 6.2, 1.1, &pal);
    // 弹箱
    px.unit_poly(
        wc,
        turret,
        &[(-2.6, 1.1), (-0.8, 1.1), (-0.8, 2.6), (-2.6, 2.6)],
        OLIVE_DARK,
        0.5,
        pal.ink,
    );
}

/// 悍马-TOW：遥控双联 TOW 发射箱（随 `turret` 转向）。
pub fn draw_tow(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    chassis(px, c, hull, &pal);
    let wc = mount(px, c, hull);
    // 双联发射箱
    px.unit_poly(
        wc,
        turret,
        &[(-2.4, -3.1), (6.6, -3.1), (6.6, 3.1), (-2.4, 3.1)],
        OLIVE,
        0.9,
        OLIVE_DARK,
    );
    // 两个管口
    for dy in [-1.5f32, 1.5] {
        px.unit_circle(wc, turret, (6.2, dy), 0.95, OLIVE_DARK);
    }
    // 方位机/三脚座
    px.unit_circle(wc, turret, (-2.8, 0.0), 1.5, pal.metal);
    // 光学瞄准具
    px.unit_poly(
        wc,
        turret,
        &[(-0.8, -3.1), (1.4, -3.1), (1.4, -2.5), (-0.8, -2.5)],
        pal.light,
        0.4,
        pal.ink,
    );
}

/// 悍马-Javelin：遥控 Javelin 发射筒 + CLU（随 `turret` 转向）。
pub fn draw_javelin(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    chassis(px, c, hull, &pal);
    let wc = mount(px, c, hull);
    // 发射筒
    px.unit_poly(
        wc,
        turret,
        &[(-1.8, -1.9), (5.8, -1.9), (5.8, 1.9), (-1.8, 1.9)],
        OLIVE,
        0.8,
        OLIVE_DARK,
    );
    px.unit_circle(wc, turret, (5.4, 0.0), 0.95, OLIVE_DARK);
    // CLU 观瞄/指挥发射单元
    px.unit_poly(
        wc,
        turret,
        &[(-1.4, 1.9), (1.6, 1.9), (1.6, 3.4), (-1.4, 3.4)],
        pal.dark,
        0.6,
        pal.ink,
    );
    px.unit_circle(wc, turret, (0.6, 2.6), 0.6, pal.light);
}

/// 悍马-Stinger：遥控四联 Stinger 发射箱（随 `turret` 转向）。
pub fn draw_stinger(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    chassis(px, c, hull, &pal);
    let wc = mount(px, c, hull);
    // 四联发射箱（2×2 管）
    px.unit_poly(
        wc,
        turret,
        &[(-2.4, -3.1), (5.2, -3.1), (5.2, 3.1), (-2.4, 3.1)],
        OLIVE,
        0.9,
        OLIVE_DARK,
    );
    for dy in [-1.6f32, 1.6] {
        for dx in [0.0f32, 2.6] {
            px.unit_circle(wc, turret, (3.0 + dx, dy), 0.9, OLIVE_DARK);
        }
    }
    // 光电观瞄转塔
    px.unit_circle(wc, turret, (-2.9, 0.0), 1.5, pal.light);
}
