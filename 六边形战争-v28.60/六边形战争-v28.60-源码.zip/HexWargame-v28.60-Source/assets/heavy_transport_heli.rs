//! 棋子美术 · 重型运输直升机（CH-47 支奴干）。
//!
//! 纵列双旋翼（前后各一，相位错开）；血量 2、可搭载 2 名步兵。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px};
use super::parts::rotor;

/// 绘制重型运输直升机棋子本体。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, time: f64, dim: bool) {
    let pal = palette(u.team, dim);
    let ink = pal.ink;
    // CH-47 支奴干：纵列双旋翼（前后各一）
    px.unit_poly(
        c,
        facing,
        &[(16.0, -4.0), (18.0, -1.5), (18.0, 1.5), (16.0, 4.0), (-14.0, 4.6), (-17.0, 1.8), (-17.0, -1.8), (-14.0, -4.6)],
        pal.fill,
        1.3,
        ink,
    );
    // 座舱窗
    px.unit_line(c, facing, (12.0, -3.2), (12.0, 3.2), 0.9, ink);
    // 前后旋翼
    let r1 = xform(c, facing, (11.0, 0.0), px.s);
    let r2 = xform(c, facing, (-12.5, 0.0), px.s);
    rotor(px, r1, 11.0, time + 0.2, &pal);
    rotor(px, r2, 11.0, time, &pal);
}
