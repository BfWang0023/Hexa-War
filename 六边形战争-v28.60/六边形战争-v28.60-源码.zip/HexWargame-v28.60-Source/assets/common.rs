//! 棋子美术 · 绘制基础件。
//!
//! - `Px`：绘制封装，统一缩放（`s`）与全局透明度（`a`），并提供局部坐标
//!   多边形 / 线段 / 圆等辅助；
//! - `xform` / `angle_between`：局部坐标到屏幕的旋转变换与方向角；
//! - `Palette` / `palette()`：阵营配色（玩家蓝 / AI 红，可整体变暗），`WRECK` 残骸灰；
//! - `OLIVE` / `OLIVE_DARK` / `STAR_WHITE`：弹药筒、军徽等通用色。
//!
//! 坐标约定（全部棋子一致）：局部坐标以 +x 为前方（屏幕向右），由调用方传入
//! 朝向角统一旋转；长度单位为“基准像素”（s=1），绘制时统一乘 `Px.s`。

use eframe::egui::{self, Color32, Pos2, Stroke};
use crate::unit::Team;

/// 两点连线方向角（屏幕坐标系，y 向下，0 = +x，顺时针为正）。
pub fn angle_between(a: Pos2, b: Pos2) -> f32 {
    (b.y - a.y).atan2(b.x - a.x)
}

/// 把局部坐标点（朝向 +x，基准像素）绕 c 旋转 ang 并缩放 s 后映射到屏幕。
pub fn xform(c: Pos2, ang: f32, p: (f32, f32), s: f32) -> Pos2 {
    let (sin, cos) = ang.sin_cos();
    let (lx, ly) = (p.0 * s, p.1 * s);
    Pos2::new(c.x + lx * cos - ly * sin, c.y + lx * sin + ly * cos)
}

/// 给颜色叠加全局透明度。
pub fn tint(col: Color32, a: u8) -> Color32 {
    if a == 255 {
        col
    } else {
        Color32::from_rgba_unmultiplied(col.r(), col.g(), col.b(), a)
    }
}

/// 绘制封装：统一缩放与透明度，局部坐标多边形辅助。
pub struct Px<'p> {
    pub p: &'p egui::Painter,
    pub s: f32,
    pub a: u8,
}

impl<'p> Px<'p> {
    pub fn new(p: &'p egui::Painter, s: f32) -> Self {
        Px { p, s, a: 255 }
    }

    pub fn poly(&self, pts: Vec<Pos2>, fill: Color32, stroke: Stroke) {
        let stroke = Stroke::new(stroke.width * self.s, tint(stroke.color, self.a));
        self.p.add(egui::Shape::convex_polygon(
            pts,
            tint(fill, self.a),
            stroke,
        ));
    }

    pub fn circle(&self, c: Pos2, r: f32, fill: Color32) {
        self.p.circle_filled(c, r * self.s, tint(fill, self.a));
    }

    pub fn ring(&self, c: Pos2, r: f32, w: f32, col: Color32) {
        self.p.circle_stroke(c, r * self.s, Stroke::new(w * self.s, tint(col, self.a)));
    }

    pub fn line(&self, a: Pos2, b: Pos2, w: f32, col: Color32) {
        self.p.add(egui::Shape::line_segment(
            [a, b],
            Stroke::new(w * self.s, tint(col, self.a)),
        ));
    }

    pub fn text(&self, c: Pos2, anchor: egui::Align2, txt: &str, size: f32, col: Color32) {
        self.p.text(
            c,
            anchor,
            txt,
            egui::FontId::proportional(size * self.s),
            tint(col, self.a),
        );
    }

    /// 局部坐标多边形（绕 c 旋转 ang）。
    pub fn unit_poly(
        &self,
        c: Pos2,
        ang: f32,
        pts: &[(f32, f32)],
        fill: Color32,
        stroke_w: f32,
        stroke_col: Color32,
    ) {
        let screen: Vec<Pos2> = pts.iter().map(|&p| xform(c, ang, p, self.s)).collect();
        self.poly(
            screen,
            fill,
            Stroke::new(stroke_w, stroke_col),
        );
    }

    /// 局部坐标线段。
    pub fn unit_line(
        &self,
        c: Pos2,
        ang: f32,
        a: (f32, f32),
        b: (f32, f32),
        w: f32,
        col: Color32,
    ) {
        self.line(xform(c, ang, a, self.s), xform(c, ang, b, self.s), w, col);
    }

    /// 局部坐标圆。
    pub fn unit_circle(&self, c: Pos2, ang: f32, at: (f32, f32), r: f32, fill: Color32) {
        self.circle(xform(c, ang, at, self.s), r, fill);
    }

    /// 五角星（美军军徽风格），`ang` 为朝向：一个尖顶指向 `ang` 方向
    /// （车型传入 hull/turret 朝向，尖顶即指向车头）。
    ///
    /// 星形是凹多边形，不能走 `convex_polygon`（凹角会被填实），也不能拆成
    /// 多块凸形分别填充——多块填充的抗锯齿羽化边互相叠加覆盖率不足，会透出
    /// 底色形成“内圈五边形”缝线。这里直接以中心为扇形顶点自己三角化成
    /// 单个 Mesh 图元：无拼缝、形状精确；边缘硬切由导出 4x 超采样平滑。
    pub fn star(&self, c: Pos2, r: f32, ang: f32, fill: Color32) {
        const FIVE: f32 = std::f32::consts::TAU / 5.0;
        const HALF: f32 = std::f32::consts::PI / 5.0;
        let ri = r * 0.42;
        let color = tint(fill, self.a);
        let mut vertices = Vec::with_capacity(11);
        vertices.push(egui::epaint::Vertex { pos: c, uv: egui::epaint::WHITE_UV, color });
        for i in 0..10 {
            let a = ang + (i as f32 / 2.0).floor() * FIVE + (i % 2) as f32 * HALF;
            let rad = if i % 2 == 0 { r } else { ri };
            vertices.push(egui::epaint::Vertex {
                pos: Pos2::new(c.x + rad * a.cos() * self.s, c.y + rad * a.sin() * self.s),
                uv: egui::epaint::WHITE_UV,
                color,
            });
        }
        let mut indices = Vec::with_capacity(30);
        for i in 1..=10u32 {
            indices.extend_from_slice(&[0, i, i % 10 + 1]);
        }
        self.p.add(egui::Shape::Mesh(egui::epaint::Mesh {
            indices,
            vertices,
            texture_id: Default::default(),
        }.into()));
    }
}

// ---------- 配色 ----------

#[derive(Clone, Copy)]
pub struct Palette {
    pub fill: Color32,  // 主体填色（阵营色）
    pub ink: Color32,   // 深色描边
    pub dark: Color32,  // 深部（负重轮/履带/背包）
    pub light: Color32, // 亮部（炮塔顶/高光）
    pub metal: Color32, // 武器金属色
}

pub fn palette(team: Team, dimmed: bool) -> Palette {
    let mut p = match team {
        Team::Player => Palette {
            fill: Color32::from_rgb(58, 122, 186),
            ink: Color32::from_rgb(12, 30, 52),
            dark: Color32::from_rgb(24, 42, 66),
            light: Color32::from_rgb(96, 164, 224),
            metal: Color32::from_rgb(30, 38, 48),
        },
        Team::Ai => Palette {
            fill: Color32::from_rgb(198, 78, 64),
            ink: Color32::from_rgb(54, 14, 10),
            dark: Color32::from_rgb(74, 26, 20),
            light: Color32::from_rgb(228, 116, 98),
            metal: Color32::from_rgb(48, 30, 26),
        },
    };
    if dimmed {
        // 用 u16 中间量避免 u8 乘法溢出
        let f = |v: u8| (v as u16 * 55 / 100) as u8;
        let dim = |c: Color32| Color32::from_rgb(f(c.r()), f(c.g()), f(c.b()));
        p = Palette {
            fill: dim(p.fill),
            ink: dim(p.ink),
            dark: dim(p.dark),
            light: dim(p.light),
            metal: dim(p.metal),
        };
    }
    p
}

/// 残骸灰。
pub const WRECK: Palette = Palette {
    fill: Color32::from_rgb(96, 96, 92),
    ink: Color32::from_rgb(38, 38, 36),
    dark: Color32::from_rgb(56, 56, 54),
    light: Color32::from_rgb(122, 122, 116),
    metal: Color32::from_rgb(60, 60, 58),
};

pub const OLIVE: Color32 = Color32::from_rgb(96, 104, 58); // 火箭筒/导弹管
pub const OLIVE_DARK: Color32 = Color32::from_rgb(64, 70, 38);
pub const STAR_WHITE: Color32 = Color32::from_rgb(238, 240, 236);
