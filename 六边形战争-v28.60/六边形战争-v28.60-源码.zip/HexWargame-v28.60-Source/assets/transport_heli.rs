//! 棋子美术 · 运输直升机（UH-60 黑鹰）。
//!
//! 宽机身 + 低尾梁 + 右侧舱门机枪 + 主轮；可搭载 1 名步兵。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px};
use super::parts::rotor;

/// 绘制运输直升机棋子本体。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, time: f64, dim: bool) {
    let pal = palette(u.team, dim);
    let ink = pal.ink;
    // UH-60 黑鹰：宽机身 + 低尾梁 + 右侧舱门机枪
    px.unit_poly(c, facing, &[(-5.0, -1.1), (-15.0, -0.8), (-15.0, 0.8), (-5.0, 1.1)], pal.fill, 1.0, ink);
    px.unit_poly(c, facing, &[(-16.5, -0.8), (-14.5, -3.6), (-14.5, 0.8)], pal.fill, 1.0, ink); // 垂尾
    let tr = xform(c, facing, (-16.0, -2.8), px.s);
    px.ring(tr, 2.8, 0.9, ink);
    px.unit_poly(
        c,
        facing,
        &[(11.0, -2.2), (13.0, 0.0), (11.0, 2.2), (4.0, 4.6), (-5.5, 4.0), (-5.5, -4.0), (4.0, -4.6)],
        pal.fill,
        1.3,
        ink,
    );
    px.unit_line(c, facing, (6.5, -2.6), (6.5, 2.6), 0.9, ink);
    // 主轮
    px.unit_circle(c, facing, (5.5, 4.4), 1.1, pal.dark);
    px.unit_circle(c, facing, (5.5, -4.4), 1.1, pal.dark);
    px.unit_circle(c, facing, (-4.5, 3.6), 1.0, pal.dark);
    px.unit_circle(c, facing, (-4.5, -3.6), 1.0, pal.dark);
    rotor(px, c, 14.0, time, &pal);
}
