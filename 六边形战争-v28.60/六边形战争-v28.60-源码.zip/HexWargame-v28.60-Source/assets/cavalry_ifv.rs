//! 棋子美术 · 装甲骑兵战车（M3 布莱德利骑兵型）。
//!
//! 按 docs/topview-refs/M3Bradley-Topview.png 的网格测量值重绘：与 M2 同族
//! 的方正履带外轮廓 + 钝头梯形斜甲，但炮塔为更大的六角形（盖满甲板宽度），
//! 炮塔左侧为圆筒形双联 TOW 发射器（骑兵型识别特征，测量：位于车长 30%..50%
//! 段），右后再装填舱口，车尾角双通讯天线，细长 25mm 链炮。车体与炮塔分层
//! 绘制：履带/车体随移动转向（hull），炮塔随最后一次开火转向（turret）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Palette, Px, OLIVE, OLIVE_DARK, STAR_WHITE, WRECK};
use super::parts::disc;

/// 履带窄条：矩形带 + 履带板纹（前后端平齐方切口）。
fn track_band(px: &Px, c: Pos2, ang: f32, x0: f32, x1: f32, yc: f32, hw: f32, pal: &Palette) {
    let ink = pal.ink;
    px.unit_poly(
        c,
        ang,
        &[(x0, yc - hw), (x1, yc - hw), (x1, yc + hw), (x0, yc + hw)],
        pal.dark,
        0.7,
        ink,
    );
    let n = (((x1 - x0) / 3.4).floor() as i32).max(1);
    for i in 1..n {
        let x = x0 + (x1 - x0) * i as f32 / n as f32;
        px.unit_line(c, ang, (x, yc - hw), (x, yc + hw), 0.5, ink);
    }
}

/// 绘制装甲骑兵战车棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal: Palette = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;

    // ---- 履带窄条（全长，前后方切口）----
    track_band(px, c, hull, -16.2, 16.2, -7.55, 1.3, &pal);
    track_band(px, c, hull, -16.2, 16.2, 7.55, 1.3, &pal);

    // ---- 车体（钝头梯形斜甲与履带前端平齐；方尾）----
    px.unit_poly(
        c,
        hull,
        &[
            (-15.9, -6.25),
            (12.0, -6.25),
            (16.0, -3.4),
            (16.0, 3.4),
            (12.0, 6.25),
            (-15.9, 6.25),
        ],
        pal.fill,
        0.9,
        ink,
    );
    // 首上斜甲受光面
    px.unit_poly(c, hull, &[(12.8, -5.4), (15.4, -3.0), (15.4, 3.0), (12.8, 5.4)], pal.light, 0.0, ink);
    // 动力舱格栅（前右）
    px.unit_poly(c, hull, &[(7.4, 2.4), (11.9, 2.4), (11.9, 5.4), (7.4, 5.4)], pal.dark, 0.0, ink);
    for gx in [8.2, 9.2, 10.2, 11.2] {
        px.unit_line(c, hull, (gx, 2.4), (gx, 5.4), 0.5, ink);
    }
    // 驾驶员舱盖（首部左侧）
disc(px, c, hull, (11.0, -3.4), 1.4, ink, pal.dark, Some(pal.metal));
    // 车首两侧前灯盒
    for side in [-1.0f32, 1.0] {
        px.unit_poly(c, hull, &[(13.6, side * 3.9), (15.4, side * 3.9), (15.4, side * 5.7), (13.6, side * 5.7)], pal.dark, 0.4, ink);
    }
    // 车尾跳板接缝 + 尾角双通讯天线（骑兵型标志）
    px.unit_line(c, hull, (-13.9, -6.0), (-13.9, 6.0), 0.6, ink);
    px.unit_line(c, hull, (-14.6, -5.4), (-18.0, -8.0), 0.5, ink);
    px.unit_line(c, hull, (-14.6, 5.4), (-18.0, 8.0), 0.5, ink);

    // ---- 六角炮塔（测量：盖满甲板宽度，中心略偏后）----
    let tc = xform(c, hull, (-0.6, 0.0), px.s);
    px.unit_poly(
        tc,
        turret,
        &[
            (6.8, 0.0),
            (4.2, -4.9),
            (-3.8, -6.3),
            (-7.0, -3.4),
            (-7.0, 3.4),
            (-3.8, 6.3),
            (4.2, 4.9),
        ],
        pal.light,
        0.9,
        ink,
    );
    // 车长/炮长双圆舱盖（带环圈）
    for hy in [-2.4, 2.4] {
        disc(px, tc, turret, (-1.6, hy), 1.9, ink, pal.fill, Some(pal.dark));
    }
    // 炮长瞄具（前部小方箱）
    px.unit_poly(tc, turret, &[(4.2, 0.8), (5.6, 0.8), (5.6, 2.2), (4.2, 2.2)], pal.dark, 0.0, ink);

    // 25mm 链炮（炮塔中轴线细长炮管）+ 同轴机枪
    px.unit_line(tc, turret, (5.0, 0.0), (12.8, 0.0), 0.9, pal.metal);
    px.unit_poly(tc, turret, &[(12.2, -0.45), (13.4, -0.45), (13.4, 0.45), (12.2, 0.45)], pal.metal, 0.4, ink);
    px.unit_line(tc, turret, (5.2, 2.4), (9.4, 2.4), 0.5, pal.metal);

    // 左侧圆筒形双联 TOW 发射器（测量：车长 30%..50% 段；圆筒 + 前端盖）
    px.unit_poly(tc, turret, &[(0.4, -7.3), (7.0, -7.3), (7.0, -4.9), (0.4, -4.9)], OLIVE, 0.6, OLIVE_DARK);
    px.unit_line(tc, turret, (0.8, -6.1), (6.6, -6.1), 0.5, OLIVE_DARK);
    disc(px, tc, turret, (6.1, -6.1), 1.1, ink, OLIVE_DARK, None);
    // 右后导弹再装填舱口（贴塔缘方盖）
    px.unit_poly(tc, turret, &[(-4.4, 4.4), (-1.6, 4.6), (-2.0, 6.4), (-4.8, 6.2)], pal.dark, 0.5, ink);

    // 尾部甲板军徽
    px.star(xform(c, hull, (-11.4, 0.0), px.s), 1.7, hull, STAR_WHITE);
}
