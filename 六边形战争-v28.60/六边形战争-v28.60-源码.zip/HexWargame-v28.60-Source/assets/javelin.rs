//! 棋子美术 · Javelin 导弹射手（2 人小组）。
//!
//! 2 名步兵各自操作 1 具 Javelin 发射筒（CLU 瞄准具 + 软发射锥头），
//! 旁加反坦克小图标（橙底坦克剪影）。
//! 渲染与防空导弹手共用肩扛发射筒小组（`assets/infantry.rs::draw_shoulder_team`）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::Px;
use super::infantry::draw_shoulder_team;

/// 绘制 Javelin 射手棋子本体（firing 不参与画面，与拆分前一致）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, dim: bool, _firing: bool) {
    draw_shoulder_team(px, c, u, facing, dim, false)
}
