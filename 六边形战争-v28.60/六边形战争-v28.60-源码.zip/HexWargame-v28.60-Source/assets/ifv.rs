//! 棋子美术 · 步兵战车（M2 布莱德利）。
//!
//! 按 docs/topview-refs/M2Bradley-Topview.png 的网格测量值重绘：外轮廓为
//! 方正的履带整体，车首是与履带前端平齐的钝头梯形斜甲（无中央尖顶）；小型
//! 八角炮塔（≈37% 车长、≈67% 车宽，中心略偏后），顶部双舱盖；右侧 25mm
//! 链炮、左肩双联 TOW 发射箱、右后扇形烟幕弹发射器；尾部跳板方角。
//! 车体与炮塔分层绘制：履带/车体随移动转向（hull），炮塔随最后一次开火
//! 转向（turret）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Palette, Px, OLIVE, OLIVE_DARK, STAR_WHITE, WRECK};
use super::parts::disc;

/// 履带窄条：矩形带 + 履带板纹（前后端平齐方切口）。
fn track_band(px: &Px, c: Pos2, ang: f32, x0: f32, x1: f32, yc: f32, hw: f32, pal: &Palette) {
    let ink = pal.ink;
    px.unit_poly(
        c,
        ang,
        &[(x0, yc - hw), (x1, yc - hw), (x1, yc + hw), (x0, yc + hw)],
        pal.dark,
        0.7,
        ink,
    );
    let n = (((x1 - x0) / 3.4).floor() as i32).max(1);
    for i in 1..n {
        let x = x0 + (x1 - x0) * i as f32 / n as f32;
        px.unit_line(c, ang, (x, yc - hw), (x, yc + hw), 0.5, ink);
    }
}

/// 绘制步兵战车棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal: Palette = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;

    // ---- 履带窄条（全长，前后方切口）----
    track_band(px, c, hull, -15.4, 15.4, -7.3, 1.25, &pal);
    track_band(px, c, hull, -15.4, 15.4, 7.3, 1.25, &pal);

    // ---- 车体（钝头梯形斜甲与履带前端平齐；方尾）----
    px.unit_poly(
        c,
        hull,
        &[
            (-14.9, -6.05),
            (11.0, -6.05),
            (15.2, -3.3),
            (15.2, 3.3),
            (11.0, 6.05),
            (-14.9, 6.05),
        ],
        pal.fill,
        0.9,
        ink,
    );
    // 首上斜甲受光面
    px.unit_poly(c, hull, &[(11.8, -5.2), (14.6, -2.9), (14.6, 2.9), (11.8, 5.2)], pal.light, 0.0, ink);
    // 动力舱格栅（前右）
    px.unit_poly(c, hull, &[(6.4, 2.1), (11.4, 2.1), (11.4, 5.3), (6.4, 5.3)], pal.dark, 0.0, ink);
    for gx in [7.4, 8.4, 9.4, 10.4] {
        px.unit_line(c, hull, (gx, 2.1), (gx, 5.3), 0.5, ink);
    }
    // 驾驶员舱盖（首部左侧）
disc(px, c, hull, (10.6, -3.3), 1.4, ink, pal.dark, Some(pal.metal));
    // 车首两侧前灯盒
    for side in [-1.0f32, 1.0] {
        px.unit_poly(c, hull, &[(13.2, side * 3.8), (15.0, side * 3.8), (15.0, side * 5.6), (13.2, side * 5.6)], pal.dark, 0.4, ink);
    }
    // 车尾跳板接缝（方尾）
    px.unit_line(c, hull, (-12.8, -5.8), (-12.8, 5.8), 0.6, ink);
    px.unit_line(c, hull, (-14.5, -4.6), (-14.5, 4.6), 0.5, ink);

    // ---- 小型八角炮塔（测量：≈37% 车长、≈67% 车宽，中心略偏后）----
    let tc = xform(c, hull, (-1.2, 0.0), px.s);
    px.unit_poly(
        tc,
        turret,
        &[
            (5.7, 0.0),
            (4.0, -4.6),
            (-2.6, -5.9),
            (-5.2, -4.4),
            (-5.7, 0.0),
            (-5.2, 4.4),
            (-2.6, 5.9),
            (4.0, 4.6),
        ],
        pal.light,
        0.9,
        ink,
    );
    // 车长/炮长双圆舱盖（带环圈）
    for hy in [-2.3, 2.3] {
        disc(px, tc, turret, (-2.0, hy), 1.9, ink, pal.fill, Some(pal.dark));
    }
    // 炮长瞄具（前部小方箱）
    px.unit_poly(tc, turret, &[(3.0, 0.8), (4.4, 0.8), (4.4, 2.2), (3.0, 2.2)], pal.dark, 0.0, ink);
    // 右后扇形烟幕弹发射器（外斜条带 + 分隔刻线）
    px.unit_poly(tc, turret, &[(-3.8, 4.2), (-4.8, 5.2), (-7.4, 2.6), (-6.4, 1.6)], pal.metal, 0.4, ink);
    for (ax, ay, bx, by) in [(-5.0, 3.6, -5.8, 4.4), (-5.9, 2.7, -6.7, 3.5)] {
        px.unit_line(tc, turret, (ax, ay), (bx, by), 0.5, ink);
    }

    // 25mm 链炮（炮塔中轴线）+ 同轴机枪
    px.unit_line(tc, turret, (4.2, 0.0), (11.8, 0.0), 1.0, pal.metal);
    px.unit_poly(tc, turret, &[(11.2, -0.5), (12.4, -0.5), (12.4, 0.5), (11.2, 0.5)], pal.metal, 0.4, ink);
    px.unit_line(tc, turret, (4.6, 2.2), (8.8, 2.2), 0.5, pal.metal);

    // 左肩双联 TOW 发射箱（伸出车体侧）
    px.unit_poly(tc, turret, &[(0.2, -7.1), (6.6, -7.1), (6.6, -4.7), (0.2, -4.7)], OLIVE, 0.6, OLIVE_DARK);
    px.unit_line(tc, turret, (0.2, -5.9), (6.6, -5.9), 0.5, OLIVE_DARK);

    // 尾部甲板：载员舱盖 + 军徽
    px.unit_poly(c, hull, &[(-8.9, 2.4), (-7.1, 2.4), (-7.1, 4.2), (-8.9, 4.2)], pal.dark, 0.4, ink);
    px.unit_poly(c, hull, &[(-8.9, -4.2), (-7.1, -4.2), (-7.1, -2.4), (-8.9, -2.4)], pal.dark, 0.4, ink);
    px.star(xform(c, hull, (-11.0, 0.0), px.s), 1.7, hull, STAR_WHITE);
}
