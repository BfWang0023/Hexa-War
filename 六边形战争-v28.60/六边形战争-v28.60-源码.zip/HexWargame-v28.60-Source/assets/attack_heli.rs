//! 棋子美术 · 武装直升机（AH-64 阿帕奇）。
//!
//! 串列座舱细机身 + 短翼挂 4×2 Hellfire + 尾梁/尾桨；
//! 主旋翼随时间旋转（`assets/parts.rs::rotor`）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px, OLIVE, OLIVE_DARK};
use super::parts::rotor;

/// 绘制武装直升机棋子本体。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, time: f64, dim: bool) {
    let pal = palette(u.team, dim);
    let ink = pal.ink;
    // AH-64 阿帕奇：串列座舱细机身 + 短翼挂弹 + 尾桨
    // 尾梁
    px.unit_poly(c, facing, &[(-6.5, -1.2), (-16.5, -0.9), (-16.5, 0.9), (-6.5, 1.2)], pal.fill, 1.0, ink);
    // 垂尾 + 尾桨
    px.unit_poly(c, facing, &[(-17.5, -3.4), (-15.5, -0.8), (-15.5, 0.8), (-17.5, 0.8)], pal.fill, 1.0, ink);
    let tr = xform(c, facing, (-17.0, -2.6), px.s);
    px.ring(tr, 3.0, 0.9, ink);
    // 机身
    px.unit_poly(
        c,
        facing,
        &[(11.5, -1.6), (13.5, 0.0), (11.5, 1.6), (5.0, 3.4), (-6.5, 2.8), (-6.5, -2.8), (5.0, -3.4)],
        pal.fill,
        1.3,
        ink,
    );
    // 串列座舱分隔线
    px.unit_line(c, facing, (7.0, -2.0), (7.0, 2.0), 0.9, ink);
    // 机鼻转塔
    px.unit_circle(c, facing, (11.0, 0.0), 1.4, pal.metal);
    // 短翼 + 挂架（每侧 4 联 Hellfire）
    for y in [-1.0, 1.0] {
        let wy = y * 4.2;
        px.unit_poly(c, facing, &[(-1.0, wy - 1.4), (2.4, wy - 1.4), (2.4, wy + y * 5.4), (-1.0, wy + y * 5.4)], pal.dark, 1.0, ink);
        for k in 0..4 {
            let ty = wy + y * (1.2 + k as f32 * 1.35);
            px.unit_poly(c, facing, &[(-0.6, ty - 0.55), (1.8, ty - 0.55), (1.8, ty + 0.55), (-0.6, ty + 0.55)], OLIVE, 0.0, OLIVE_DARK);
        }
    }
    rotor(px, c, 15.0, time, &pal);
}
