//! 棋子美术 · 卡车（FMTV 战术卡车，平头驾驶舱）。
//!
//! 俯视只见车体：平头驾驶舱（两片式大风挡）+ 篷布货槽（篷布弓）；
//! 轮在车体正下方不参与画面。不能攻击、可搭载 3 名步兵。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px, STAR_WHITE, WRECK};
use super::parts::disc;

/// 绘制卡车棋子本体（hp<=0 用残骸灰配色；无炮塔，turret 不参与画面）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, _turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;

    // ---- 篷布货槽（尾部切角 + 篷布弓）----
    px.unit_poly(
        c,
        hull,
        &[(-14.3, -6.0), (-13.6, -7.2), (0.8, -7.2), (0.8, 7.2), (-13.6, 7.2), (-14.3, 6.0)],
        pal.dark,
        1.2,
        ink,
    );
    // 尾板
    px.unit_line(c, hull, (-13.4, -6.3), (-13.4, 6.3), 0.8, ink);
    // 篷布弓
    for x in [-10.6, -7.4, -4.2, -1.0] {
        px.unit_line(c, hull, (x, -6.4), (x, 6.4), 0.8, ink);
    }

    // ---- 车架外露段（货槽与驾驶舱之间）+ 排气包 ----
    px.unit_poly(c, hull, &[(0.8, -6.4), (2.8, -6.4), (2.8, 6.4), (0.8, 6.4)], pal.metal, 0.8, ink);
    disc(px, c, hull, (1.8, -5.0), 1.0, ink, pal.dark, None);

    // ---- 平头驾驶舱 ----
    px.unit_poly(
        c,
        hull,
        &[(2.8, -7.0), (11.0, -7.0), (13.6, -4.4), (13.6, 4.4), (11.0, 7.0), (2.8, 7.0)],
        pal.fill,
        1.2,
        ink,
    );
    // 保险杠
    px.unit_poly(c, hull, &[(13.6, -5.6), (15.2, -5.6), (15.2, 5.6), (13.6, 5.6)], pal.metal, 0.8, ink);
    // 两片式前风挡（斜置玻璃）
    px.unit_poly(c, hull, &[(11.0, -6.3), (13.0, -4.9), (13.0, 4.9), (11.0, 6.3)], pal.dark, 0.8, ink);
    px.unit_line(c, hull, (12.0, -5.6), (12.0, 5.6), 0.7, ink);
    // 顶盖舱口
    disc(px, c, hull, (5.2, 3.6), 1.2, ink, pal.dark, Some(pal.metal));
    px.star(xform(c, hull, (6.6, 0.0), px.s), 2.2, hull, STAR_WHITE);
}
