//! 渲染回归基准（golden test）。
//!
//! 以固定参数把全部兵种各绘制 7 组（双方阵营 / 变暗 / 残血 / 残骸 / 开火动画等），
//! 把生成的 egui Shape 列表做 FNV-1a 哈希，与 `golden_render_hashes.txt` 逐项比对：
//! - 重构 / 迁移渲染代码时，证明“渲染结果与之前完全一致”；
//! - 后续修改某兵种美术时，`cargo test` 会精确指出哪些兵种的画面变了；
//!   确认改动符合预期后，用
//!   `REGENERATE_GOLDEN=1 cargo test --bin hex_wargame render_golden -- --nocapture`
//!   重新生成，并更新 `golden_render_hashes.txt`。

use eframe::egui::{self, LayerId, Order, Pos2};
use crate::hex::Hex;
use crate::unit::{Team, Unit, UnitKind};

use super::{draw_unit_body, BackWeapon, Px};

const GOLDEN: &str = include_str!("golden_render_hashes.txt");

/// 全部兵种（与 `UnitKind` 一一对应）。
const KINDS: &[UnitKind] = &[
    UnitKind::Rifleman,
    UnitKind::SpecialForces,
    UnitKind::EliteInfantry,
    UnitKind::Atgm,
    UnitKind::Javelin,
    UnitKind::AaInfantry,
    UnitKind::HmgGunner,
    UnitKind::Headquarters,
    UnitKind::Tank,
    UnitKind::HeavyTank,
    UnitKind::Ifv,
    UnitKind::CavalryIfv,
    UnitKind::HumveeHmg,
    UnitKind::HumveeTow,
    UnitKind::HumveeJavelin,
    UnitKind::Scout,
    UnitKind::Truck,
    UnitKind::Howitzer,
    UnitKind::Mortar,
    UnitKind::AaMgv,
    UnitKind::AaLauncher,
    UnitKind::AttackHeli,
    UnitKind::TransportHeli,
    UnitKind::HeavyTransportHeli,
    UnitKind::Drone,
];

fn fnv1a(bytes: &[u8]) -> u64 {
    let mut h: u64 = 0xcbf2_9ce4_8422_2325;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100_0000_01b3);
    }
    h
}

/// 一组参数下渲染 `kind` 并返回图形哈希。
#[allow(clippy::too_many_arguments)]
fn render_hash(
    kind: UnitKind,
    team: Team,
    hp: i32,
    dim: bool,
    hull: f32,
    turret: f32,
    time: f64,
    fire: Option<(f32, f32, Option<BackWeapon>)>,
) -> u64 {
    let ctx = egui::Context::default();
    let painter = ctx.layer_painter(LayerId::new(Order::Middle, egui::Id::new("render_golden")));
    let mut u = Unit::new(kind, team, Hex::new(3, -2));
    // hp<=0 保留原值（车辆残骸判定用 hp<=0；步兵人数随 HP 截断为 0）
    u.hp = if hp > 0 { hp.min(u.hp) } else { hp };
    let px = Px::new(&painter, 1.0);
    draw_unit_body(&px, Pos2::new(100.0, 80.0), &u, hull, turret, fire, time, dim);
    let mut buf = String::new();
    painter.for_each_shape(|cs| buf.push_str(&format!("{:?}", cs)));
    fnv1a(buf.as_bytes())
}

/// 解析基准文件为 “兵种名 序号” -> 哈希。
fn parse_golden() -> Vec<(String, u64)> {
    GOLDEN
        .lines()
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(|l| {
            let mut it = l.split_whitespace();
            let key = format!("{} {}", it.next().unwrap(), it.next().unwrap());
            (key, u64::from_str_radix(it.next().unwrap(), 16).unwrap())
        })
        .collect()
}

#[test]
fn golden_render_matches_baseline() {
    let mut cases: Vec<(String, u64)> = Vec::new();
    for kind in KINDS {
        // 7 组参数：满血 / 敌方 / 变暗+另一组朝向 / 残血 / 残骸(hp0) / 火箭筒开火 / 防空弹开火
        let team = |i: usize| if i == 1 { Team::Ai } else { Team::Player };
        #[allow(clippy::type_complexity)]
        let params: [(i32, bool, f32, f32, f64, Option<(f32, f32, Option<BackWeapon>)>); 7] = [
            (i32::MAX, false, 0.8, -0.4, 1.25, None),
            (i32::MAX, false, 0.8, -0.4, 1.25, None),
            (i32::MAX, true, -1.2, 2.5, 2.5, None),
            (1, false, 0.0, 0.0, 0.0, None),
            (0, false, 0.3, 0.7, 1.0, None),
            (i32::MAX, false, 0.8, -0.4, 1.25, Some((1.0, 0.7, Some(BackWeapon::Rocket)))),
            (i32::MAX, false, 0.8, -0.4, 1.25, Some((2.2, 1.0, Some(BackWeapon::Aa)))),
        ];
        for (i, &(hp, dim, hull, turret, time, fire)) in params.iter().enumerate() {
            let h = render_hash(*kind, team(i), hp, dim, hull, turret, time, fire);
            cases.push((format!("{:?} {}", kind, i), h));
        }
    }

    if std::env::var("REGENERATE_GOLDEN").is_ok() {
        println!("\n# ---- 以下为新的基准（覆盖 assets/golden_render_hashes.txt）----");
        for (key, h) in &cases {
            println!("{} {:016x}", key, h);
        }
        return;
    }

    let golden = parse_golden();
    let mut problems = Vec::new();
    for (key, h) in &cases {
        match golden.iter().find(|(k, _)| k == key) {
            Some((_, g)) if g == h => {}
            Some((_, g)) => problems.push(format!("{} 变了：基准 {:016x} → 实际 {:016x}", key, g, h)),
            None => problems.push(format!("{} 缺少基准", key)),
        }
    }
    for (key, g) in &golden {
        if !cases.iter().any(|(k, _)| k == key) {
            problems.push(format!("基准里多余的条目：{} {:016x}", key, g));
        }
    }
    assert!(
        problems.is_empty(),
        "渲染结果与基准不一致（共 {} 处）：\n{}",
        problems.len(),
        problems.join("\n")
    );
}
