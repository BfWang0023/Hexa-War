//! 棋子美术 · 坦克（M60 巴顿）。
//!
//! 按 docs/topview-refs/M60-Topview.png 的网格测量值重绘：船形车体长锥首与
//! 履带前端平齐（无中央尖顶），标志性的大蛋形炮塔宽度≈83% 车宽（覆盖履带
//! 内半幅）、长度≈54% 车长；105mm 炮管抽烟装置贴近炮框，炮管大幅悬出车首；
//! 前后翼子板箱覆盖整条履带宽。车体与炮塔分层绘制：履带/车体随移动转向
//! （hull），炮塔随最后一次开火转向（turret）。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Palette, Px, STAR_WHITE, WRECK};
use super::parts::disc;

/// 履带窄条：矩形带 + 履带板纹（前后端平齐方切口）。
fn track_band(px: &Px, c: Pos2, ang: f32, x0: f32, x1: f32, yc: f32, hw: f32, pal: &Palette) {
    let ink = pal.ink;
    px.unit_poly(
        c,
        ang,
        &[(x0, yc - hw), (x1, yc - hw), (x1, yc + hw), (x0, yc + hw)],
        pal.dark,
        0.7,
        ink,
    );
    let n = (((x1 - x0) / 3.6).floor() as i32).max(1);
    for i in 1..n {
        let x = x0 + (x1 - x0) * i as f32 / n as f32;
        px.unit_line(c, ang, (x, yc - hw), (x, yc + hw), 0.5, ink);
    }
}

/// 蛋形炮塔轮廓（局部坐标，中心 cx/cy，长半轴 rx、短半轴 ry，前部收窄）。
fn egg_pts(cx: f32, cy: f32, rx: f32, ry: f32) -> Vec<(f32, f32)> {
    let n = 18;
    (0..n)
        .map(|i| {
            let a = -std::f32::consts::FRAC_PI_2 + std::f32::consts::TAU * i as f32 / n as f32;
            let k = 1.0 - 0.10 * a.cos().max(0.0);
            (cx + rx * a.cos() * k, cy + ry * a.sin())
        })
        .collect()
}

/// 绘制坦克棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal: Palette = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;

    // ---- 履带窄条（全长，前后方切口）----
    track_band(px, c, hull, -15.2, 15.2, -6.95, 1.2, &pal);
    track_band(px, c, hull, -15.2, 15.2, 6.95, 1.2, &pal);

    // ---- 船形车体（长锥首与履带前端平齐，测量：锥段长≈33% 车长）----
    px.unit_poly(
        c,
        hull,
        &[
            (-14.9, -5.8),
            (5.0, -5.8),
            (9.5, -4.9),
            (12.5, -3.3),
            (14.3, -1.4),
            (15.0, 0.0),
            (14.3, 1.4),
            (12.5, 3.3),
            (9.5, 4.9),
            (5.0, 5.8),
            (-14.9, 5.8),
        ],
        pal.fill,
        0.9,
        ink,
    );
    // 首部甲板受光面 + 变速箱鼓包
    px.unit_poly(c, hull, &[(6.5, -5.1), (13.2, -2.3), (13.2, 2.3), (6.5, 5.1)], pal.light, 0.0, ink);
    disc(px, c, hull, (11.8, 0.0), 1.4, ink, pal.dark, None);
    // 驾驶员舱盖（首部左前）
disc(px, c, hull, (11.2, -2.9), 1.3, ink, pal.dark, Some(pal.metal));

    // ---- 前后翼子板储物箱（覆盖整条履带宽，测量：箱带贴车体两缘）----
    for side in [-1.0f32, 1.0] {
        for (x0, x1) in [(6.8, 14.6), (-14.6, -6.8)] {
            let (ya, yb) = (side * 6.1, side * 8.2);
            px.unit_poly(c, hull, &[(x0, ya), (x1, ya), (x1, yb), (x0, yb)], pal.dark, 0.6, ink);
            px.unit_line(c, hull, ((x0 + x1) * 0.5, ya), ((x0 + x1) * 0.5, yb), 0.5, ink);
        }
        // 尾角排气百叶
        px.unit_poly(c, hull, &[(-15.1, side * 3.0), (-14.2, side * 3.0), (-14.2, side * 5.3), (-15.1, side * 5.3)], pal.metal, 0.4, ink);
    }

    // ---- 尾部动力舱格栅（测量：尾端两块长条）----
    for side in [-1.0f32, 1.0] {
        let (ya, yb) = if side < 0.0 { (-5.0, -2.1) } else { (2.1, 5.0) };
        px.unit_poly(c, hull, &[(-9.3, ya), (-14.3, ya), (-14.3, yb), (-9.3, yb)], pal.dark, 0.0, ink);
        for gx in [-13.6, -12.6, -11.6, -10.6] {
            px.unit_line(c, hull, (gx, ya), (gx, yb), 0.5, ink);
        }
    }

    // ---- 大蛋形炮塔（测量：长≈54% 车长、宽≈83% 车宽，中心略偏前）----
    let tc = xform(c, hull, (0.6, 0.0), px.s);
    px.unit_poly(tc, turret, &egg_pts(0.0, 0.0, 8.2, 6.8), pal.light, 0.9, ink);

    // 车长指挥塔（右后，带环圈 + 机枪）
    disc(px, tc, turret, (-2.8, 3.2), 2.0, ink, pal.fill, Some(pal.metal));
    px.unit_line(tc, turret, (-2.8, 3.2), (-1.2, 4.5), 0.5, pal.metal);
    // 装填手舱盖（左后平圆盘）
    disc(px, tc, turret, (-2.6, -3.2), 1.7, ink, pal.dark, None);
    // 炮框两侧潜望镜凸块
    px.unit_poly(tc, turret, &[(4.6, -2.3), (6.2, -2.0), (6.2, -1.3), (4.6, -1.6)], pal.dark, 0.0, ink);
    px.unit_poly(tc, turret, &[(4.6, 2.3), (6.2, 2.0), (6.2, 1.3), (4.6, 1.6)], pal.dark, 0.0, ink);

    // ---- 炮框 + 105mm 炮管（抽烟装置贴近炮框；悬出车首 ≈27% 车长）----
    px.unit_poly(tc, turret, &[(8.4, -1.7), (10.6, -1.7), (10.6, 1.7), (8.4, 1.7)], pal.metal, 0.6, ink);
    px.unit_line(tc, turret, (10.2, 0.0), (14.4, 0.0), 2.6, pal.metal);
    px.unit_line(tc, turret, (14.4, 0.0), (22.6, 0.0), 1.6, pal.metal);
    px.unit_poly(tc, turret, &[(22.2, -1.0), (23.8, -1.0), (23.8, 1.0), (22.2, 1.0)], pal.metal, 0.5, ink);
    // 氙气探照灯（炮框左侧圆柱）
    px.unit_poly(tc, turret, &[(7.4, -4.4), (10.2, -4.4), (10.2, -3.1), (7.4, -3.1)], pal.dark, 0.5, ink);

    px.star(xform(tc, turret, (-4.6, 0.0), px.s), 2.1, turret, STAR_WHITE);
}
