//! 棋子美术 · 自行迫击炮（M1129，斯崔克 8×8 底盘）。
//!
//! 开启的舱口 + 斜置 120mm 迫击炮管 + 座钣；范围攻击 + 压制，无需架设。

use eframe::egui::{self, Pos2, Stroke};
use crate::unit::Unit;

use super::common::{palette, tint, xform, Px, STAR_WHITE, WRECK};

/// 绘制自行迫击炮棋子本体（hp<=0 用残骸灰配色）。
pub fn draw(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    let pal = if u.hp <= 0 { WRECK } else { palette(u.team, dim) };
    let ink = pal.ink;
    // M1129 自行迫击炮（斯崔克）：车体俯视（轮在车体下不参与画面）
    px.unit_poly(
        c,
        hull,
        &[(-14.5, -8.0), (13.0, -8.0), (15.5, -3.4), (15.5, 3.4), (13.0, 8.0), (-14.5, 8.0)],
        pal.fill,
        1.3,
        ink,
    );
    // 开启的舱口
    let tc = xform(c, hull, (3.0, 0.0), px.s);
    px.p.add(egui::Shape::circle_stroke(
        xform(tc, turret, (0.0, 0.0), px.s),
        4.6 * px.s,
        Stroke::new(1.2 * px.s, tint(ink, px.a)),
    ));
    px.unit_circle(tc, turret, (0.0, 0.0), 4.6, pal.dark);
    // 迫击炮管（斜置）
    px.unit_line(tc, turret, (0.0, 0.0), (8.0, 0.0), 3.0, pal.metal);
    px.unit_circle(tc, turret, (0.0, 0.0), 2.0, pal.metal);
    // 座钣
    px.unit_poly(tc, turret, &[(-4.2, -2.2), (-2.2, -2.2), (-2.2, 2.2), (-4.2, 2.2)], pal.light, 0.0, ink);
    px.star(xform(c, hull, (-8.0, 0.0), px.s), 2.4, hull, STAR_WHITE);
}
