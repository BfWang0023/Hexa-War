//! 棋子美术 · 侦察无人机。
//!
//! 细长平直翼 + 推进式螺旋桨（旋转线）+ V 尾 + 光电球；
//! 视野极远，携带 1 枚反坦克导弹。

use eframe::egui::Pos2;
use crate::unit::Unit;

use super::common::{palette, xform, Px};

/// 绘制侦察无人机棋子本体。
pub fn draw(px: &Px, c: Pos2, u: &Unit, facing: f32, time: f64, dim: bool) {
    let pal = palette(u.team, dim);
    let ink = pal.ink;
    // 侦察无人机：细长平直翼 + 推进式螺旋桨 + V 尾
    px.unit_poly(
        c,
        facing,
        &[(10.0, -0.9), (12.5, 0.0), (10.0, 0.9), (-6.0, 1.5), (-9.0, 0.8), (-9.0, -0.8), (-6.0, -1.5)],
        pal.fill,
        1.1,
        ink,
    );
    // 平直主翼
    px.unit_line(c, facing, (-0.5, 0.0), (-0.5, 13.0), 2.2, pal.dark);
    // V 尾
    px.unit_line(c, facing, (-8.0, 0.5), (-12.5, 3.6), 1.4, pal.dark);
    px.unit_line(c, facing, (-8.0, -0.5), (-12.5, -3.6), 1.4, pal.dark);
    // 推进螺旋桨（旋转线）
    let pp = xform(c, facing, (-9.6, 0.0), px.s);
    let spin = (time * 14.0) as f32;
    let a = spin;
    px.line(
        Pos2::new(pp.x + (1.8 * a.cos()) * px.s, pp.y + (1.8 * a.sin()) * px.s),
        Pos2::new(pp.x - (1.8 * a.cos()) * px.s, pp.y - (1.8 * a.sin()) * px.s),
        0.9,
        ink,
    );
    // 光电球
    px.unit_circle(c, facing, (9.0, 0.0), 1.1, pal.metal);
}
