import {readFileSync,writeFileSync,mkdirSync,renameSync,unlinkSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {importMap} from '../../web3d/ancient/engine.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url));
const manifest=JSON.parse(readFileSync(join(root,'docs/terrain-v02/personal-map-revisions.json'),'utf8'));
const backup=join(root,'docs/terrain-v02/personal-backups',new Date().toISOString().replaceAll(':','-'));
mkdirSync(backup,{recursive:true});const applied=[];
for(const patch of manifest){
 if(!patch.personalFile)continue;
 const path=patch.personalFile,bytes=readFileSync(path),raw=JSON.parse(bytes.toString('utf8'));
 const cells=new Map(raw.terrain.map(x=>[`${x[0]},${x[1]}`,x]));
 for(const p of patch.river){const key=`${p.c},${p.r}`,old=cells.get(key)?.[2]||0;assert.ok(old===p.before||old===p.after,`${patch.id} terrain changed during review`);cells.set(key,[p.c,p.r,p.after]);}
 raw.terrain=[...cells.values()].sort((a,b)=>a[1]-b[1]||a[0]-b[0]);
 for(const p of patch.forts){const u=raw.units.find(u=>u.kind==='fort'&&u.c===p.c&&u.r===p.r);assert.ok(u,`${patch.id} wall removed during review`);assert.ok((u.team===p.fromTeam&&u.cityId===p.fromCity)||(u.team===p.toTeam&&u.cityId===p.toCity),`${patch.id} owner changed during review`);u.team=p.toTeam;u.cityId=p.toCity;}
 importMap(raw);const tmp=path+'.terrain-v02.tmp';writeFileSync(join(backup,`${patch.id}.json`),bytes);writeFileSync(tmp,JSON.stringify(raw));
 if(!readFileSync(path).equals(bytes)){unlinkSync(tmp);throw Error(`${path} changed during write; original retained`);}
 renameSync(tmp,path);applied.push({id:patch.id,riverCells:patch.river.length,fortFields:patch.forts.length,path});
}
writeFileSync(join(root,'docs/terrain-v02/personal-applied.json'),JSON.stringify({backup,applied},null,2));console.log(JSON.stringify({backup,applied},null,2));
