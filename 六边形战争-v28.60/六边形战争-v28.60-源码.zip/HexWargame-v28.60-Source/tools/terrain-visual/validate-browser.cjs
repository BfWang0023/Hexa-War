const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1}),errors=[],checks=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.route('**/ancient/app.mjs',async route=>{const response=await route.fetch();await route.fulfill({response,body:(await response.text()).replace('bootSavedMaps().catch(e => hint(e.message));','window.__qaBootReady=false;bootSavedMaps().catch(e=>hint(e.message)).finally(()=>window.__qaBootReady=true);')+`\nwindow.__terrainQA={renderer,scene,camera,get terrain(){return terrainObj},get map(){return currentMap()},get units(){return unitGroup},get forts(){return fortGroup},get marks(){return markGroup},get selected(){return selectedId},rebuildScene,refresh,eventHex,clickCell,unitY,updateCamera,target,setDistance(v){cameraDistance=v;updateCamera()}};`})});
 const root=process.env.BASE_URL||'http://127.0.0.1:8809';
 async function load(id){await page.goto(`${root}/ancient/?scenario=${id}`);await page.waitForFunction(id=>window.__terrainQA?.map.scenarioId===id&&window.__qaBootReady,id);await page.waitForTimeout(180);}
 await load('china_changping');
 const ids=await page.locator('#scenario-select option').evaluateAll(xs=>xs.map(x=>x.value));
 for(const id of ids){await load(id);checks.push({id,units:await page.evaluate(()=>__terrainQA.map.units.length)});}
 assert.equal(ids.length,71);
 await load('china_changping');
 const uuid=await page.evaluate(()=>__terrainQA.terrain.group.uuid);await page.evaluate(()=>__terrainQA.refresh());await page.waitForTimeout(150);
 assert.equal(await page.evaluate(()=>__terrainQA.terrain.group.uuid),uuid);
 await page.locator('#hex-grid').uncheck();assert.equal(await page.evaluate(()=>__terrainQA.terrain.grid.visible),false);
 await page.locator('#terrain-quality').selectOption('low');assert.equal(await page.evaluate(()=>__terrainQA.renderer.shadowMap.enabled),false);
 await page.locator('#terrain-quality').selectOption('standard');await page.locator('#hex-grid').check();
 const unit=await page.evaluate(()=>{const q=__terrainQA,rect=document.querySelector('#scene').getBoundingClientRect();for(const model of q.units.children){const p=model.position.clone().project(q.camera),x=(p.x+1)*rect.width/2,y=(1-p.y)*rect.height/2+rect.top;if(x>50&&x<1000&&y>150&&y<900)return {id:model.userData.unitId,x,y};}});
 assert.ok(unit);await page.mouse.click(unit.x,unit.y);await page.waitForTimeout(200);
 assert.equal(await page.evaluate(()=>__terrainQA.selected),unit.id);
 assert.ok(await page.evaluate(()=>__terrainQA.marks.children.length)>0);
 await page.screenshot({path:'docs/terrain-v02/after/selection-ranges.png'});
 await page.locator('#editor').click();await page.waitForTimeout(200);
 const cell=await page.evaluate(async()=>{const {offsetToWorld}=await import('/js/core/hex.js');const {terrainHeight}=await import('/ancient/terrain.mjs');const q=__terrainQA,rect=document.querySelector('#scene').getBoundingClientRect();for(let r=0;r<q.map.rows;r++)for(let c=0;c<q.map.cols;c++){
  if(q.map.units.some(u=>u.c===c&&u.r===r))continue;const w=offsetToWorld(c,r),v=q.camera.position.clone().set(w.x,terrainHeight(q.map,c,r),w.z).project(q.camera),x=(v.x+1)*rect.width/2,y=(1-v.y)*rect.height/2+rect.top;
  if(x>100&&x<900&&y>760&&y<920){const picked=q.eventHex({clientX:x,clientY:y});if(picked?.c===c&&picked.r===r)return {c,r,x,y};}
 }});assert.ok(cell);
 await page.locator('[data-brush=mountain]').click();await page.mouse.click(cell.x,cell.y);await page.waitForTimeout(250);
 assert.equal(await page.evaluate(cell=>__terrainQA.map.terrain[cell.r*__terrainQA.map.cols+cell.c],cell),2);
 assert.notEqual(await page.evaluate(()=>__terrainQA.terrain.group.uuid),uuid);
 await page.screenshot({path:'docs/terrain-v02/after/editor.png'});
 // Isolated visual fixture, never saved. Exercises all overlays and keeps actual battle data intact.
 await load('mantinea');
 await page.evaluate(async()=>{
   const e=await import('/ancient/engine.mjs'), {offsetToWorld}=await import('/js/core/hex.js'),q=__terrainQA,m=q.map;
   for(let r=19;r<=25;r++)for(let c=30;c<=40;c++)e.setTerrain(m,c,r,e.TERRAIN.PLAIN);
   for(let c=30;c<=40;c++){e.setTerrain(m,c,22,e.TERRAIN.ROAD);e.setTerrain(m,c,24,e.TERRAIN.MOUNTAIN);}
   for(let r=19;r<=25;r++)e.setTerrain(m,35,r,e.TERRAIN.RIVER|(r===22?e.TERRAIN.ROAD:0));e.setBridge(m,35,22);
   for(let c=30;c<34;c++){e.setFort(m,c,23,2,'egypt');const f=e.fortAt(m,c,23);if(f&&c===32)f.hp=100;if(f&&c===33)f.hp=0;}
   q.target.set(offsetToWorld(35,22).x,0,offsetToWorld(35,22).z);q.setDistance(100);q.rebuildScene();
 });await page.waitForTimeout(600);await page.screenshot({path:'docs/terrain-v02/after/terrain-combinations-bridge.png'});
 const crossing=await page.evaluate(()=>({ford:!!__terrainQA.terrain.group.getObjectByName('underlying-fords'),deck:!!__terrainQA.terrain.group.getObjectByName('bridge-decks')}));assert.ok(crossing.ford&&crossing.deck);
 await page.evaluate(async()=>{const e=await import('/ancient/engine.mjs');e.setBridge(__terrainQA.map,35,22,false);__terrainQA.rebuildScene()});await page.waitForTimeout(400);
 assert.ok(await page.evaluate(()=>!__terrainQA.terrain.group.getObjectByName('bridge-decks')&&!!__terrainQA.terrain.group.getObjectByName('underlying-fords')));
 await page.screenshot({path:'docs/terrain-v02/after/terrain-combinations-ford.png'});

 await page.evaluate(async()=>{
   const e=await import('/ancient/engine.mjs'),q=__terrainQA,g=ancientScenario.game,m=q.map;
   const own=m.units.find(u=>u.team==='egypt'&&u.kind==='greekHoplite'),foe=m.units.find(u=>u.team==='coalition'&&u.kind==='greekHoplite');
   if(!own||!foe)throw Error('missing attack fixture infantry');
   Object.assign(own,{c:32,r:21,actionsLeft:3});Object.assign(foe,{c:33,r:21});
   e.setTerrain(m,32,21,e.TERRAIN.PLAIN);e.setTerrain(m,33,21,e.TERRAIN.PLAIN);e.recomputeFog(g);
   q.rebuildScene();q.clickCell(32,21);
 });await page.waitForTimeout(200);
 assert.ok(await page.evaluate(()=>__terrainQA.marks.children.some(o=>o.material.color.getHex()===0xe77968)));
 await page.screenshot({path:'docs/terrain-v02/after/attack-range.png'});
 await page.evaluate(async()=>{
   const e=await import('/ancient/engine.mjs'),{offsetToWorld}=await import('/js/core/hex.js'),q=__terrainQA,m=q.map;
   m.units=m.units.filter(u=>u.kind!=='fort');
   for(let r=19;r<=25;r++)for(let c=29;c<=42;c++)e.setTerrain(m,c,r,e.TERRAIN.PLAIN);
   for(const [level,cols] of [[1,[30,31]],[2,[34,35]],[3,[38,39]]])for(const c of cols)e.setFort(m,c,22,level,'egypt');
   const p=offsetToWorld(35,22);q.target.set(p.x,0,p.z);q.setDistance(130);q.rebuildScene();
   document.querySelector('aside').style.display='none';document.querySelector('#hint').textContent='城墙等级展示：左侧一级木石工事 · 中间二级石墙 · 右侧三级塔楼城墙（独立测试场景，未保存）';
 });await page.waitForTimeout(400);await page.screenshot({path:'docs/terrain-v02/after/wall-levels.png'});
 await browser.close();fs.writeFileSync('docs/terrain-v02/browser-validation.json',JSON.stringify({checks,cache:true,grid:true,quality:true,unitSelection:true,ranges:true,attackRange:true,wallLevels:true,editorPaint:true,bridgeFord:true,errors},null,2));assert.equal(errors.length,0,errors.join('\n'));console.log('71 browser loads; cache, grid, quality, unit selection, ranges, editor painting and bridge/ford states passed.');
})();
