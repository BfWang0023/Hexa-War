const { chromium } = require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('node:fs');
const path = require('node:path');
(async () => {
 const base = process.env.BASE_URL || 'http://127.0.0.1:8808';
 const out = process.argv[2] || 'docs/terrain-v02/before'; fs.mkdirSync(out,{recursive:true});
 const browser = await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless:true});
 const page = await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
 if(process.env.QUALITY==='low')await page.addInitScript(()=>localStorage.setItem('ancient-terrain-quality','low'));
 const errors=[]; page.on('pageerror',e=>errors.push(e.message)); page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 await page.route('**/ancient/app.mjs',async route=>{
   const response=await route.fetch();
   await route.fulfill({response,body:(await response.text()).replace('bootSavedMaps().catch(e => hint(e.message));','window.__qaBootReady=false;bootSavedMaps().catch(e=>hint(e.message)).finally(()=>window.__qaBootReady=true);')+`\nwindow.__terrainQA={renderer,scene,camera,get terrain(){return terrainObj},get map(){return currentMap()},get units(){return unitGroup},get forts(){return fortGroup},get marks(){return markGroup},rebuildScene,refresh,eventHex,clickCell,unitY,updateCamera,target,setDistance(v){cameraDistance=v;updateCamera()}};`});
 });
 if(process.env.FIXED_MAPS_BASE)await page.route('**/api/ancient/maps**',async route=>{const url=new URL(route.request().url());const response=await route.fetch({url:process.env.FIXED_MAPS_BASE+url.pathname+url.search});await route.fulfill({response});});
 const data=[];
 for(const id of ['china_muye','china_changping','mantinea']) {
   const loadStart=performance.now(); await page.goto(`${base}/ancient/?scenario=${id}`); await page.waitForFunction(()=>window.__terrainQA && window.__qaBootReady && document.querySelector('#phase').textContent!=='载入中');
   await page.waitForFunction(()=>document.querySelector('#scenario-select').value===window.__terrainQA.map.scenarioId); await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))); const loadMs=performance.now()-loadStart; await page.waitForTimeout(1500);const cdp=await page.context().newCDPSession(page);await cdp.send('HeapProfiler.collectGarbage');await cdp.detach();
   const metrics=await page.evaluate(async()=>{
     const q=window.__terrainQA, gl=q.renderer.getContext(), ext=gl.getExtension('WEBGL_debug_renderer_info');
     const times=[]; let last=performance.now(); const start=last;
     await new Promise(resolve=>{function f(now){times.push(now-last);last=now;if(now-start<10000)requestAnimationFrame(f);else resolve()} requestAnimationFrame(f)});
     times.shift(); times.sort((a,b)=>a-b);
     let meshes=0,triangles=0; q.terrain.group.traverse(o=>{if(o.isMesh){meshes++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3*(o.count||1)}});
     const info=JSON.parse(JSON.stringify(q.renderer.info));
     const hidden=[]; for(const o of q.scene.children)if(o.isGroup&&o!==q.terrain.group&&o.visible){hidden.push(o);o.visible=false}
     q.renderer.render(q.scene,q.camera);const terrainCalls=q.renderer.info.render.calls; hidden.forEach(o=>o.visible=true);
     return {id:q.map.scenarioId,cells:q.map.cols*q.map.rows,units:q.map.units.length,fps:1000/(times.reduce((a,b)=>a+b,0)/times.length),medianMs:times[Math.floor(times.length*.5)],p95Ms:times[Math.floor(times.length*.95)],low1Fps:1000/(times.slice(-Math.max(1,Math.ceil(times.length*.01))).reduce((a,b)=>a+b,0)/Math.max(1,Math.ceil(times.length*.01))),calls:info.render.calls,triangles:info.render.triangles,terrainCalls,terrainMeshes:meshes,terrainTriangles:triangles,geometries:info.memory.geometries,textures:info.memory.textures,heapBytes:performance.memory?.usedJSHeapSize||null,gpu:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):null};
   });
   metrics.loadMs=loadMs; await page.screenshot({path:path.join(out,`${id}.png`)}); data.push(metrics); console.log(metrics);
 }
 fs.writeFileSync(path.join(out,'metrics.json'),JSON.stringify({date:new Date().toISOString(),viewport:[1440,1000],deviceScaleFactor:1,headless:true,quality:process.env.QUALITY||'standard',gcBeforeSample:true,sampleSeconds:10,fixedMapsBase:process.env.FIXED_MAPS_BASE||null,data,errors},null,2));
 await browser.close(); if(errors.length)throw Error(errors.join('\n'));
})();
