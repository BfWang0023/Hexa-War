// Reproducible, bounded map edits. Always read the retained original source package.
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {CAMPAIGN_CATALOG} from '../../web3d/ancient/campaign-catalog.mjs';
import {TERRAIN,index,neighbors,inBounds,exportMap,importMap} from '../../web3d/ancient/engine.mjs';
const root=process.argv[2];if(!root)throw Error('Pass the original source directory as the first argument.');
const {mapFor}=await import(pathToFileURL(join(resolve(root),'tools/ai-training/maps.mjs')));
const personalDir=process.argv[3]||null;
const outputDir=personalDir?'docs/terrain-v02/personal-map-patches':'web3d/ancient/bundled-maps';
mkdirSync(outputDir,{recursive:true});
const manifest=[];mkdirSync('docs/terrain-v02/original-maps',{recursive:true});
const correctedCity={china_jin_partition:['智氏围城主营','晋阳城'],china_tian_dan:['燕军围城营','即墨城'],china_handan:['秦军围城主营','邯郸城'],china_qin_chu:['楚军主阵','秦军坚壁营']};
for(const {id} of CAMPAIGN_CATALOG){
 const personal=personalDir&&join(personalDir,`${id}.json`);
 const input=personal&&existsSync(personal)?personal:join(resolve(root),'web3d/ancient/bundled-maps',`${id}.json`);
 const raw=existsSync(input)?JSON.parse(readFileSync(input,'utf8')):exportMap(mapFor(id));
 const m=personalDir?importMap(raw):mapFor(id);
 const original=structuredClone(raw),changes={id,river:[],forts:[],blocked:[]},seen=new Set(),components=[];
 const blocked=new Set([...m.units.filter(u=>u.hp>0),...m.supplyPoints,...m.landmarks,...(m.reinforcements||[]).flatMap(w=>w.units||[])].filter(p=>Number.isInteger(p.c)&&Number.isInteger(p.r)).map(p=>index(m,p.c,p.r)));
 if(m.victory.objective)blocked.add(index(m,m.victory.objective.c,m.victory.objective.r));
 for(let r=0;r<m.rows;r++)for(let c=0;c<m.cols;c++){
  if(!(m.terrain[index(m,c,r)]&TERRAIN.RIVER)||seen.has(index(m,c,r)))continue;
  const cells=[{c,r}];seen.add(index(m,c,r));
  for(let i=0;i<cells.length;i++)for(const n of neighbors(cells[i].c,cells[i].r))if(inBounds(m,n.c,n.r)&&m.terrain[index(m,n.c,n.r)]&TERRAIN.RIVER&&!seen.has(index(m,n.c,n.r))){seen.add(index(m,n.c,n.r));cells.push(n);}
  components.push(cells);
 }
 const edgeDistance={left:p=>p.c,right:p=>m.cols-1-p.c,top:p=>p.r,bottom:p=>m.rows-1-p.r};
 for(const cells of components){
  const distances=Object.fromEntries(Object.entries(edgeDistance).map(([e,f])=>[e,Math.min(...cells.map(f))]));
  if(Object.values(distances).filter(d=>d<=3).length<2)continue;
  for(const [edge,d] of Object.entries(distances)){
   if(d===0||d>3)continue;
   const starts=cells.filter(p=>edgeDistance[edge](p)===d);
   for(const start of starts){
    const queue=[{p:start,path:[]}],visited=new Set([index(m,start.c,start.r)]);let found=null;
    for(let i=0;i<queue.length;i++){
     const {p,path}=queue[i];if(edgeDistance[edge](p)===0){found=path;break;}if(path.length>=3)continue;
     const ns=neighbors(p.c,p.r).filter(n=>inBounds(m,n.c,n.r)&&edgeDistance[edge](n)<edgeDistance[edge](p));
     ns.sort((a,b)=>Math.abs(a.c-start.c)+Math.abs(a.r-start.r)-Math.abs(b.c-start.c)-Math.abs(b.r-start.r));
     for(const n of ns){const k=index(m,n.c,n.r);if(visited.has(k)||blocked.has(k)||m.houses[k]||m.terrain[k]===TERRAIN.SEA)continue;visited.add(k);queue.push({p:n,path:[...path,n]});}
    }
    if(!found){changes.blocked.push({edge,start});continue;}
    for(const p of found){const k=index(m,p.c,p.r),before=m.terrain[k],after=TERRAIN.RIVER|(before&TERRAIN.ROAD);if(before===after)continue;
     m.terrain[k]=after;changes.river.push({c:p.c,r:p.r,before,after,edge});
    }
   }
  }
 }
 for(const u of raw.units){
  if(u.kind!=='fort')continue;
  // The unlabelled segments continue Qin's Hangu defensive line; there are no allied garrisons.
  // Yan's unlabelled east-bank defensive segments likewise sit between the river and Yan's capital.
  if(['china_alliance_qin','china_qi_yan'].includes(id)&&u.team==='egypt'&&!u.cityId){
   changes.forts.push({c:u.c,r:u.r,fromTeam:u.team,toTeam:'coalition',fromCity:u.cityId,toCity:id==='china_alliance_qin'?'函谷关':'燕军河东防线',reason:id==='china_alliance_qin'?'connected-to-Qin-Hangu-wall':'east-bank-before-Yan-capital'});
   u.team='coalition';u.cityId=id==='china_alliance_qin'?'函谷关':'燕军河东防线';
  }
  const fix=correctedCity[id];if(fix&&u.team==='egypt'&&u.cityId===fix[0]){
   changes.forts.push({c:u.c,r:u.r,fromTeam:u.team,toTeam:u.team,fromCity:u.cityId,toCity:fix[1],reason:'landmark-and-garrison-match-owner'});u.cityId=fix[1];
  }
 }
 if(!changes.river.length&&!changes.forts.length)continue;
 const terrain=new Map(raw.terrain.map(t=>[`${t[0]},${t[1]}`,t]));
 for(const p of changes.river)terrain.set(`${p.c},${p.r}`,[p.c,p.r,p.after]);
 raw.terrain=[...terrain.values()].sort((a,b)=>a[1]-b[1]||a[0]-b[0]);
 // No rules, armies, objectives, wall HP, road bits or intact bridges may be edited here.
 const strip=x=>{const y=structuredClone(x);delete y.terrain;for(const u of y.units)if(u.kind==='fort'){delete u.team;delete u.cityId;}return y;};
 assert.deepEqual(strip(raw),strip(original));importMap(raw);
 if(!personalDir)writeFileSync(`docs/terrain-v02/original-maps/${id}.json`,JSON.stringify(original));
 writeFileSync(`${outputDir}/${id}.json`,JSON.stringify(raw));manifest.push({...changes,wasBundled:existsSync(input),personalFile:personal&&existsSync(personal)?personal:null});
}
writeFileSync(personalDir?'docs/terrain-v02/personal-map-revisions.json':'docs/terrain-v02/map-revisions.json',JSON.stringify(manifest,null,2));
console.log(manifest.map(x=>({id:x.id,riverCells:x.river.length,teamChanges:x.forts.filter(f=>f.fromTeam!==f.toTeam).length,cityLabels:x.forts.filter(f=>f.fromTeam===f.toTeam).length,blocked:x.blocked.length})));
