import {CAMPAIGN_CATALOG} from '../../web3d/ancient/campaign-catalog.mjs';
import {mapFor} from '../ai-training/maps.mjs';
import {TERRAIN,index,neighbors,inBounds,distance} from '../../web3d/ancient/engine.mjs';
import {writeFileSync} from 'node:fs';
const results=[];
for(const {id,title} of CAMPAIGN_CATALOG){
 const m=mapFor(id),visited=new Set(),rivers=[];
 for(let r=0;r<m.rows;r++)for(let c=0;c<m.cols;c++){
  const k=index(m,c,r);if(!(m.terrain[k]&TERRAIN.RIVER)||visited.has(k))continue;
  const cells=[{c,r}];visited.add(k);for(let i=0;i<cells.length;i++)for(const n of neighbors(cells[i].c,cells[i].r)){
   if(inBounds(m,n.c,n.r)&&m.terrain[index(m,n.c,n.r)]&TERRAIN.RIVER&&!visited.has(index(m,n.c,n.r))){visited.add(index(m,n.c,n.r));cells.push(n);}
  }
  const edges={left:m.cols,right:m.cols,top:m.rows,bottom:m.rows};
  const nearest={};for(const p of cells)for(const [edge,d] of Object.entries({left:p.c,right:m.cols-1-p.c,top:p.r,bottom:m.rows-1-p.r}))if(d<edges[edge]){edges[edge]=d;nearest[edge]=p;}
  rivers.push({size:cells.length,edges,nearest,cells});
 }
 const forts=m.units.filter(u=>u.kind==='fort'&&u.hp>0),cities={};
 for(const f of forts){const name=f.cityId||'(无城名)';const x=cities[name]||{egypt:0,coalition:0,samples:[]};x[f.team]++;if(x.samples.length<5)x.samples.push([f.c,f.r,f.team,f.level]);cities[name]=x;}
 const occupiedConflicts=forts.flatMap(f=>m.units.filter(u=>u.kind!=='fort'&&u.hp>0&&u.c===f.c&&u.r===f.r&&u.team!==f.team).map(u=>({fort:f,unit:u})));
 const isolatedSide=forts.filter(f=>{const ns=forts.filter(v=>distance(f,v)===1);return ns.length>=2&&ns.every(v=>v.team!==f.team)}).map(f=>({c:f.c,r:f.r,team:f.team,cityId:f.cityId,level:f.level}));
 const nearSoldiers=Object.entries(cities).map(([city,data])=>{const cityForts=forts.filter(f=>(f.cityId||'(无城名)')===city);const close=m.units.filter(u=>u.kind!=='fort'&&u.hp>0&&cityForts.some(f=>distance(f,u)<=2));return {city,...data,nearby:{egypt:close.filter(u=>u.team==='egypt').length,coalition:close.filter(u=>u.team==='coalition').length}}});
 results.push({id,title,cols:m.cols,rows:m.rows,rivers,cities:nearSoldiers,occupiedConflicts,isolatedSide,factions:m.factions});
}
writeFileSync('docs/terrain-v02/map-audit.json',JSON.stringify(results,null,2));
for(const x of results){
 const near=x.rivers.filter(r=>Object.values(r.edges).filter(d=>d<=3).length>=2&&Object.values(r.edges).some(d=>d>0&&d<=3));
 if(near.length)console.log('RIVER',x.id,JSON.stringify(near.map(r=>({size:r.size,edges:r.edges}))));
 if(x.cities.length)console.log('FORT',x.id,JSON.stringify(x.cities));
 if(x.occupiedConflicts.length||x.isolatedSide.length)console.log('CONFLICT',x.id,JSON.stringify({occupied:x.occupiedConflicts,isolated:x.isolatedSide}));
}
