const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const assert=require('node:assert/strict');const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8811/ancient/?scenario=china_handan');await page.waitForFunction(()=>window.ancientScenario?.game?.map.scenarioId==='china_handan');await page.waitForTimeout(500);
 const phase=await page.locator('#phase').innerText();assert.ok(phase.includes('击溃秦军'));assert.equal(await page.locator('.landmark-label').filter({hasText:'★ 秦军围城主营'}).count(),0);
 await page.locator('#help').click();const help=await page.locator('#help-body').innerText();assert.ok(help.includes('占领秦军主营地不构成胜利条件'));await page.screenshot({path:'docs/terrain-v02/after/handan-victory.png'});
 const state=await page.evaluate(async()=>{const e=await import('/ancient/engine.mjs'),g=ancientScenario.game,p=g.map.victory.objective;const u=g.map.units.find(u=>u.team==='egypt'&&u.kind==='heavy'),present=e.mobileAt(g.map,p.c,p.r);if(present){present.c=1;present.r=1;}u.c=p.c;u.r=p.r;e.checkVictory(g);return {over:g.over,winner:g.winner,captureObjective:e.hasChinaCaptureObjective(g.map)};});assert.equal(state.over,false);assert.equal(state.captureObjective,false);assert.equal(errors.length,0);
 fs.writeFileSync('docs/terrain-v02/handan-validation.json',JSON.stringify({phase,help,state,errors},null,2));await browser.close();console.log('Handan UI and camp occupation regression passed.');
})();
