#!/usr/bin/env python3
"""Plot the road geometry dumped by tools/road_preview.py (before vs after fix)."""
import pickle
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np


def load(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def topdown(ax, quads, title):
    for kind, pts, col, isb in quads:
        xs = [p[0] for p in pts] + [pts[0][0]]
        zs = [p[2] for p in pts] + [pts[0][2]]
        if kind == "rail":
            c = (0.9, 0.2, 0.2)
        elif isb:
            c = (0.1, 0.45, 0.95)
        else:
            c = (0.35, 0.35, 0.35)
        ax.fill(xs, zs, facecolor=c, edgecolor=c, linewidth=0.2)
    ax.set_title(title)
    ax.set_aspect("equal")
    ax.invert_yaxis()


def perspective(ax, quads, title):
    polys = []
    cols = []
    for kind, pts, col, isb in quads:
        polys.append([(p[0], p[2], p[1]) for p in pts])  # x, z(forward), y(up)
        if kind == "rail":
            cols.append((0.9, 0.2, 0.2, 1))
        elif kind == "mark":
            cols.append((0.85, 0.78, 0.47, 1))
        elif isb:
            cols.append((0.2, 0.5, 0.95, 1))
        else:
            cols.append((0.4, 0.4, 0.4, 1))
    pc = Poly3DCollection(polys, facecolors=cols, edgecolors="none")
    ax.add_collection3d(pc)
    ax.set_xlabel("x"); ax.set_ylabel("z"); ax.set_zlabel("y")
    ax.set_title(title)


def main():
    before = load("tools/_preview/roads_before.pkl")
    after = load("tools/_preview/roads_fixed.pkl")
    # zoom to bridge 1 area (col 16..24, row 1..6)
    def clip(quads, x0, x1, z0, z1):
        out = []
        for q in quads:
            cx = sum(p[0] for p in q[1]) / len(q[1])
            cz = sum(p[2] for p in q[1]) / len(q[1])
            if x0 <= cx <= x1 and z0 <= cz <= z1:
                out.append(q)
        return out

    fig = plt.figure(figsize=(16, 9))

    ax = fig.add_subplot(2, 2, 1)
    topdown(ax, before, "BEFORE top-down (blue=bridge, red=rail, dark=road)")
    ax = fig.add_subplot(2, 2, 2)
    topdown(ax, after, "AFTER top-down")

    # bridge 1 world bbox approx: col18..21 -> x; rows 2..5 -> z
    b1 = clip(before, 180, 235, 14, 40)
    b1a = clip(after, 180, 235, 14, 40)
    ax = fig.add_subplot(2, 2, 3, projection="3d")
    perspective(ax, b1, "BEFORE bridge-1 close-up")
    ax.view_init(elev=18, azim=-60)
    ax = fig.add_subplot(2, 2, 4, projection="3d")
    perspective(ax, b1a, "AFTER bridge-1 close-up")
    ax.view_init(elev=18, azim=-60)
    for a in (fig.axes[2], fig.axes[3]):
        a.set_xlim(180, 235); a.set_ylim(14, 40); a.set_zlim(-1.2, 1.6)

    fig.tight_layout()
    out = sys.argv[1] if len(sys.argv) > 1 else "tools/_preview/roads_compare.png"
    fig.savefig(out, dpi=95)
    print("wrote", out)


if __name__ == "__main__":
    main()
