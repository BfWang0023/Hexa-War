#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
staging=$(mktemp -d "${TMPDIR:-/tmp}/tactical-mac.XXXXXX")
trap 'rm -rf "$staging"' EXIT HUP INT TERM
previous='/Users/boriswang/Documents/ChatGPT/六边形战争/古代战役-v02-整合升级/dist/formation-arrows/古代战役-v02-macOS.zip'
out=dist/motion-v28.42
ditto -xk "$previous" "$staging"
app="$staging/古代战役.app"
codesign --verify --deep --strict "$app"
# The native launcher and Rust server have no changes in this release.
rm -rf "$app/Contents/Resources/web3d"
cp -RX web3d "$app/Contents/Resources/web3d"
find "$app" -name '.DS_Store' -delete
xattr -cr "$app"
codesign --force --deep --sign - "$app"
codesign --verify --deep --strict "$app"
mkdir -p "$out"
ditto -c -k --norsrc --noextattr --keepParent "$app" "$out/古代战役-v02-macOS.zip"
