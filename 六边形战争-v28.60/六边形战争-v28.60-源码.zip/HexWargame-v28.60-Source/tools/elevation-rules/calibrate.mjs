import fs from 'node:fs';
import * as E from '../../web3d/ancient/engine.mjs';
const rows=[];
for(const kind of ['light','heavy','guard','cavalry','archer','chinaCrossbow'])for(const target of ['light','heavy'])for(const rate of [.10,.15,.20]){
 const m=E.newMap(16,10);m.scenarioId="custom_calibration";E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,kind,'egypt',5,4);const ranged=['archer','chinaCrossbow'].includes(kind);E.addUnit(m,target,'coalition',ranged?8:6,4);const s=E.startGame(m,{elevationRules:{gain:rate,loss:rate}}),a=E.mobileAt(s.map,5,4),d=E.mobileAt(s.map,ranged?8:6,4),out={kind,target,rate,hp:d.hp/10};
 for(const delta of [-3,-1,0,1,3]){s.map.elevations[E.index(s.map,a.c,a.r)]=Math.max(0,delta);s.map.elevations[E.index(s.map,d.c,d.r)]=Math.max(0,-delta);const p=E.attackPreview(s,a,d.c,d.r);if(!p)throw Error('illegal calibration fixture');out[delta]={damage:p.damage/10,multiplier:p.elevation.multiplier,hitsToDefeat:Math.ceil(d.hp/p.damage)};}
 rows.push(out);
}
fs.writeFileSync('docs/elevation-rules-20261028/parameter-matrix.json',JSON.stringify({method:'Engine attackPreview; unchanged type stats, armor and morale; deterministic hits, not win-rate balance testing',rows},null,2));
console.log(JSON.stringify(rows.filter(r=>r.rate===.15&&r.target==='light'),null,2));
