const DEFAULT_PRESET = 'wargame'
const DEFAULT_HOST = '127.0.0.1'
const DEFAULT_PORT = 45123
const TEAM_CN = { blue: '蓝方', red: '红方' }

function other(side) { return side === 'blue' ? 'red' : 'blue' }
function teamCn(side) { return TEAM_CN[side] === undefined ? String(side) : TEAM_CN[side] }
function shq(value) { return "'" + String(value).replace(/'/g, "'\\''") + "'" }
function stamp() { return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) }

const state = {
  phase: 'idle',
  gameDir: null,
  preset: DEFAULT_PRESET,
  host: DEFAULT_HOST,
  port: DEFAULT_PORT,
  stateFile: null,
  spectateFile: null,
  hostLog: null,
  hostPid: null,
  hostHandle: null,
  hostOwned: false,
  opening: false,
  blue: null,
  red: null,
  activeSide: null,
  turn: 0,
  triggers: 0,
  maxTurns: 200,
  looping: false,
  turnMs: 900000,
  fixAttempts: 3,
  lastSeenSeq: 0,
  timeline: [],
  events: [],
  over: false,
  result: '',
  error: null,
  cancelled: false,
  busy: false,
  auto: true,
  // 可持续部署（默认开启，与游戏默认一致；false = 经典全歼模式）
  view: 'acting',
  sustain: true,
  sustainPp: 10,
  sustainAp: 10,
  sustainPoints: null,
  lastSnap: null,
  wake: null,
  wakePromise: null,
}

function note(text) {
  state.events.push('[' + new Date().toISOString().slice(11, 19) + '] ' + String(text))
  if (state.events.length > 400) state.events.splice(0, state.events.length - 400)
}

function notify() {
  const resolve = state.wake
  state.wake = null
  state.wakePromise = new Promise((r) => { state.wake = r })
  if (resolve !== undefined) resolve()
}

function textOfMessage(message) {
  if (message === null || message === undefined) return ''
  const content = message.content
  if (!Array.isArray(content)) return ''
  const parts = []
  for (const block of content) {
    if (block !== null && typeof block === 'object' && block.type === 'text' && typeof block.text === 'string') {
      parts.push(block.text)
    }
  }
  return parts.join('\n')
}

function lastAssistantEvent(surface) {
  const events = surface === null || surface === undefined ? [] : surface.events
  if (!Array.isArray(events)) return null
  let last = null
  for (const ev of events) if (ev.type === 'assistant/message') last = ev
  return last
}

function lastAssistantText(surface) {
  const last = lastAssistantEvent(surface)
  if (last === null) return ''
  return textOfMessage(last.data && last.data.message)
}

/// 该会话最近一条 assistant 消息是否被中途打断（aborted / interrupted / max-tokens 都会标记）。
function surfaceInterrupted(surface) {
  const last = lastAssistantEvent(surface)
  if (last === null || last.data === null || last.data === undefined) return false
  return last.data.interrupted === true
}

function pad(value, width) {
  let text = String(value)
  while (text.length < width) text = ' ' + text
  return text
}

function entryOf(side) { return side === 'blue' ? state.blue : state.red }

return {
  inject: ['tools', 'timer'],
  apply(ctx) {
    state.wakePromise = new Promise((r) => { state.wake = r })
    ctx.effect(() => {
      state.cancelled = false
      return () => { state.cancelled = true; notify() }
    })

    const agents = ctx.get('agents')
    const presets = ctx.get('agentPresets')
    const sessionQuery = ctx.get('sessionQuery')
    const defaults = ctx.get('agentDefaultModel')
    const shell = ctx.get('shell')
    const subprocess = ctx.get('subprocess')

    // ---------------------------------------------------------------- shell

    async function runShell(command, timeoutMs) {
      if (shell === undefined) throw new Error('shell service unavailable')
      const spec = shell.resolve({ command, timeoutMs: timeoutMs === undefined ? 20000 : timeoutMs })
      const result = await shell.run(spec)
      return result
    }

    async function outOf(command, timeoutMs) {
      const r = await runShell(command, timeoutMs)
      const stdout = r.stdout === undefined ? '' : String(r.stdout.text)
      const stderr = r.stderr === undefined ? '' : String(r.stderr.text)
      return { code: r.exitCode, text: stdout, err: stderr }
    }

    async function writeFile(path, text) {
      const dir = String(path).replace(/\/[^/]*$/, '')
      const b64 = btoa(text)
      const r = await outOf(
        'mkdir -p ' + shq(dir) + ' && printf %s ' + shq(b64) + ' | base64 -d > ' + shq(path),
        20000,
      )
      if (r.code !== 0) throw new Error('write ' + path + ' failed: ' + r.err)
    }

    async function readFile(path) {
      const r = await outOf('cat ' + shq(path) + ' 2>/dev/null || true', 15000)
      return r.text
    }

    async function portOpen() {
      const r = await outOf(
        '(exec 3<>/dev/tcp/' + state.host + '/' + state.port + ') 2>/dev/null && echo OPEN || echo CLOSED',
        6000,
      )
      return r.text.indexOf('OPEN') >= 0
    }

    // ---------------------------------------------------------- game state

    async function readSnapshot() {
      const text = await readFile(state.stateFile)
      if (text.trim() === '') return null
      try {
        return JSON.parse(text)
      } catch (error) {
        note('观战快照解析失败: ' + String(error && error.message ? error.message : error))
        return null
      }
    }

    async function waitForChange(before, timeoutMs) {
      const deadline = Date.now() + timeoutMs
      let snap = await readSnapshot()
      while (Date.now() < deadline) {
        if (snap !== null && (snap.over || snap.turn !== before.turn || snap.active_team !== before.active_team)) return snap
        await ctx.timeout(250)
        snap = await readSnapshot()
      }
      return snap === null ? before : snap
    }

    function deltaLines(snap, sinceSeq) {
      const lines = []
      const events = Array.isArray(snap.events) ? snap.events : []
      for (const ev of events) {
        if (Number(ev.seq) > sinceSeq) lines.push(String(ev.text))
      }
      return lines
    }

    function situationLines(snap) {
      const mine = snap.teams[state.activeSide] || {}
      const foe = snap.teams[other(state.activeSide)] || {}
      const lines = [
        '你方: 存活 ' + String(mine.alive) + ' · 已损失 ' + String(mine.lost) + '（' + String(mine.lost_points) + ' 分）· 已击毁敌方 ' + String(mine.kills) + ' 个',
        '敌方: 存活 ' + String(foe.alive) + ' · 已损失 ' + String(foe.lost) + ' · 已击毁你方 ' + String(foe.kills) + ' 个',
      ]
      if (snap.sustain === true) {
        lines.push('部署点数: 你方 ' + String(mine.points) + '（每回合 +' + String(mine.points_per_turn) + '）· 敌方 ' + String(foe.points) + '（每回合 +' + String(foe.points_per_turn) + '）')
        const hq = mine.hq === null || mine.hq === undefined ? '未设立' : String(mine.hq)
        const zoneOpen = snap.recruit_zone_turn !== undefined && snap.recruit_zone_turn > 0
          && Number(snap.turn) <= Number(snap.recruit_zone_turn)
        if (zoneOpen) {
          lines.push('招募区域: 第 ' + String(snap.turn) + ' 回合可在本方出发区域任意空格招募（招募的单位本回合即可行动）；第 ' + String(Number(snap.recruit_zone_turn) + 1) + ' 回合起改为大本营周围 2 格内')
        } else {
          lines.push('招募区域: 你方大本营中心 ' + hq + ' 周围 2 格内（当回合部署的单位不可行动）')
        }
      }
      return lines
    }

    /// 可持续部署模式的规则摘要（写进开局与回合提示词）。快照缺字段时用 ? 兜底。
    function sustainBrief(side, snap) {
      const mine = snap === null || snap.teams === undefined ? {} : (snap.teams[side] || {})
      const per = mine.points_per_turn === undefined ? '?' : String(mine.points_per_turn)
      const pts = mine.points === undefined ? '?' : String(mine.points)
      const hq = mine.hq === undefined || mine.hq === null ? '未设立' : String(mine.hq)
      return [
        '本局为【持续部署模式】：双方开局没有任何棋子，所有单位都要自己招募。',
        '- 第 1 回合：可在本方出发区域任意空格招募（招募的单位本回合即可行动）——这是组建主力部队的唯一机会。',
        '- 第 2 回合起：只能在大本营中心（' + hq + '）周围 2 格内追加部署（当回合不可行动；距敌军 ≤5 格的格子不可部署）。',
        '- 每回合开始双方各获得部署点数（你方 +' + per + '/回合，当前 ' + pts + ' 点）；`dp` 查看点数与当前招募区域，`dp list` 查看兵种与费用，`dp <兵种|编号> <格>` 招募。',
        '- 胜负：陆军单位踏入并同时控制双方全部 6 个关键据点即获胜；一方全灭不算结束（可以增援再战）。',
      ]
    }

    // ------------------------------------------------------- turn-end reason

    /// 最近若干次 agent 回合的结束原因（completed / aborted / interrupted / max-tokens）。
    /// 用来区分"正常收尾但忘了 `e`"与"被中途打断"：前者提醒立即收尾，后者要求继续做完本回合。
    async function recentTurnEnds(sessionId, count) {
      const out = []
      if (sessionQuery === undefined) return out
      try {
        // 注意：filterEvents 只返回"有语义文本"的事件，completed 的 turn/end 语义文本为空、
        // 因此会被过滤掉；必须用 listEvents 取完整事件序列再按 seq 读回原因。
        const records = await sessionQuery.listEvents(sessionId)
        if (!Array.isArray(records)) return out
        const ends = []
        for (const rec of records) {
          if (rec !== null && rec !== undefined && rec.type === 'turn/end') ends.push(rec)
        }
        const take = Math.max(1, Math.min(count === undefined ? 1 : count, 12))
        for (const rec of ends.slice(-take)) {
          let reason = null
          let turn = null
          try {
            const win = await sessionQuery.readEvent({ sessionId, seq: rec.seq })
            const ev = win === null || win === undefined ? null : win.target
            if (ev !== null && ev !== undefined && ev.data !== undefined && ev.data !== null) {
              const r = ev.data.reason
              if (r !== null && r !== undefined && r.kind !== undefined) reason = String(r.kind)
              if (ev.data.turn !== undefined && ev.data.turn !== null) turn = Number(ev.data.turn)
            }
          } catch { /* keep null */ }
          out.push({ seq: Number(rec.seq), turn, reason, time: Number(rec.time) || 0 })
        }
      } catch (error) {
        note('读取回合结束原因失败: ' + String(error && error.message ? error.message : error))
      }
      return out
    }

    async function lastTurnEndReason(sessionId) {
      const list = await recentTurnEnds(sessionId, 1)
      return list.length === 0 ? null : list[list.length - 1].reason
    }

    function isInterrupted(reason) {
      return reason === 'aborted' || reason === 'interrupted' || reason === 'max-tokens'
    }

    // ------------------------------------------------------------- prompts

    function openingPrompt(side, snap) {
      const lines = [
        '你执掌六边形战争多人对局中的【' + teamCn(side) + '】。对手是另一名 AI 指挥官，执掌' + teamCn(other(side)) + '。没有人会给你战术建议，一切由你判断。',
        '',
      ]
      if (snap !== null && snap !== undefined && snap.sustain === true) {
        for (const line of sustainBrief(side, snap)) lines.push(line)
        lines.push('')
      }
      lines.push(
        '第一步（必须按顺序完成）：',
        '1. 完整阅读 ' + state.gameDir + '/README.md，掌握全部规则。',
        '2. 调用 wargame_connect，参数 team: "' + side + '"（连接失败时按工具提示处理）。',
        '3. 用 wargame_observe 与 wargame_screenshot 观察初始战场。',
        '',
        '然后完成【第 1 回合 · ' + teamCn(side) + '行动】：',
        '- 用 wargame_command 逐条下达命令，直到本回合指挥完成；',
        '- 结束时发送 `e` 结束回合；若你把所有单位的行动都用完了，游戏会自动结束回合（那时不需要再发 `e`）；',
        '- 不要替对手行动。',
        '',
        '回合结束后用不超过 120 字汇报，随即结束本次输出。控制管线会在对手回合结束后再唤醒你，你不需要等待、不需要轮询。',
        '若收到「对局结束：…」或命令返回「对局已经结束。」，立即停止指挥，并在回复第一行写 BATTLE_OVER: <结果>。',
      )
      return lines.join('\n')
    }

    function newTurnPrompt(side, snap, delta) {
      const lines = []
      lines.push('【控制管线 · 第 ' + String(snap.turn) + ' 回合 · ' + teamCn(side) + '行动】只完成这一个回合。')
      lines.push('当前局势（上帝视角统计）：')
      for (const line of situationLines(snap)) lines.push('- ' + line)
      if (delta.length > 0) {
        lines.push('上一手之后发生的战况：')
        for (const line of delta.slice(-12)) lines.push('- ' + line)
      } else {
        lines.push('上一手之后没有新的战报事件。')
      }
      lines.push('要求：')
      lines.push('1. 先用 wargame_observe 确认回合与阶段（必要时 wargame_screenshot 观察画面，可局部放大）。')
      if (snap.sustain === true) {
        const mine = snap.teams[side] || {}
        const zoneOpen = snap.recruit_zone_turn !== undefined && snap.recruit_zone_turn > 0
          && Number(snap.turn) <= Number(snap.recruit_zone_turn)
        lines.push('2. 用 wargame_command 发 `dp <兵种|编号> <格>` 招募（当前点数 ' + String(mine.points)
          + '，每回合 +' + String(mine.points_per_turn) + '；`dp list` 查兵种与费用）：'
          + (zoneOpen
            ? '本回合可在本方出发区域任意空格招募，招募的单位本回合即可行动。'
            : '只能在大本营周围 2 格内，当回合不可行动。'))
        lines.push('3. 用 wargame_command 完成本回合其余指挥。')
        lines.push('4. 结束回合前确认本回合想做的动作都已完成——不要因为时间紧就提前 `e`。')
        lines.push('5. 结束时发送 `e` 结束回合；若全部单位行动已用完，游戏会自动结束回合。不结束回合，对手不会被唤醒，整场对局会卡住。')
        lines.push('6. 用不超过 120 字汇报本回合指挥要点与战果，然后立即结束本次输出。')
      } else {
        lines.push('2. 用 wargame_command 完成本回合指挥。')
        lines.push('3. 结束回合前确认本回合想做的动作都已完成——不要因为时间紧就提前 `e`。')
        lines.push('4. 结束时发送 `e` 结束回合；若全部单位行动已用完，游戏会自动结束回合。不结束回合，对手不会被唤醒，整场对局会卡住。')
        lines.push('5. 用不超过 120 字汇报本回合指挥要点与战果，然后立即结束本次输出。')
      }
      lines.push('不要等待对手、不要轮询、不要使用 wait_for_turn_ms：轮到你的前提由控制管线保证。')
      lines.push('若对局已结束，第一行写 BATTLE_OVER: <结果>。')
      return lines.join('\n')
    }

    /// 回合被中途打断（aborted / interrupted / max-tokens）时用：把本回合做完，而不是草草收尾。
    function continueTurnPrompt() {
      const lines = [
        '【控制管线】你上一个回合被中途打断了，对局仍停在' + teamCn(state.activeSide) + '行动——本回合还没完成。',
        '请继续完成这个回合：',
        '1. 先用 wargame_observe 看清当前局势（必要时 wargame_screenshot）。',
        '2. 把本回合还没做完的动作做完（该移动的移动、该攻击的攻击）；不要重复已经做过的动作。',
      ]
      if (state.lastSnap !== null && state.lastSnap.sustain === true) {
        lines.push('3. 如果本回合还想增援，用 `dp <兵种|编号> <格>` 追加部署（`dp list` 查兵种与费用）。')
        lines.push('4. 所有动作完成后，用 wargame_command 发送 `e` 结束回合。')
      } else {
        lines.push('3. 所有动作完成后，用 wargame_command 发送 `e` 结束回合。')
      }
      lines.push('不要为了收尾而提前结束回合。最后用不超过 60 字说明你补做了哪些动作。')
      return lines.join('\n')
    }

    /// 回合正常结束但忘了 `e` 时用：已完成就立即收尾，没完成就先把动作做完再收尾。
    function endTurnFixPrompt() {
      const lines = [
        '【控制管线】对局仍停在' + teamCn(state.activeSide) + '行动，说明你还没有结束回合。',
        '如果你本回合想做的动作都已经完成，请立即用 wargame_command 发送 `e` 结束回合；',
        '如果还有动作没做完，请先把它们做完，最后再发送 `e`。',
      ]
      if (state.lastSnap !== null && state.lastSnap.sustain === true) {
        lines.push('（可持续部署：还想增援就先用 `dp <兵种|编号> <格>` 追加部署，再发送 `e`。）')
      }
      lines.push('两种情况都必须以 `e` 收尾，然后不超过 40 字确认。')
      return lines.join('\n')
    }

    // ---------------------------------------------------------------- agents

    function modelOptions() {
      if (defaults === undefined) return undefined
      const selection = defaults.currentSelection()
      return {
        provider: selection.provider,
        model: selection.model,
        ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
      }
    }

    async function ensurePreset(agent, preset) {
      if (presets === undefined) return 'no agentPresets'
      if (presets.composedPreset(agent.ctx) === preset) return 'already composed'
      await presets.mount(agent.ctx, preset)
      return 'mounted'
    }

    async function attachSide(side, sessionId, opts) {
      const live = agents === undefined ? undefined : agents.get(sessionId)
      if (live !== undefined) {
        const composed = presets === undefined ? 'n/a' : String(presets.composedPreset(live.ctx))
        note('adopt ' + side + ' ' + String(sessionId) + ' composedPreset=' + composed)
        return { agent: live, dispose: async () => {}, adopted: true }
      }
      const options = modelOptions()
      const handle = await agents.create({
        sessionId,
        meta: { cwd: state.gameDir, agentPreset: state.preset },
        ...(options === undefined ? {} : { agentOptions: options }),
      })
      const mounted = await ensurePreset(handle.agent, state.preset)
      note('create ' + side + ' ' + String(sessionId) + ' preset=' + mounted)
      return { agent: handle.agent, dispose: () => handle.dispose(), adopted: false }
    }

    async function resumeSide(side, sessionId) {
      const options = modelOptions()
      const handle = await agents.resume({
        resumeSessionId: sessionId,
        ...(options === undefined ? {} : { agentOptions: options }),
      })
      const mounted = await ensurePreset(handle.agent, state.preset)
      note('resume ' + side + ' ' + String(sessionId) + ' preset=' + mounted)
      return { agent: handle.agent, dispose: () => handle.dispose(), adopted: false }
    }

    async function ensureIdle(agent) {
      if (agent.status !== 'running') return
      note('agent 仍在运行，取消其当前回合: ' + String(agent.id))
      try { agent.cancel({ kind: 'user' }) } catch { /* ignore */ }
      try { await Promise.race([agent.whenIdle(), ctx.timeout(60000)]) } catch { /* ignore */ }
    }

    async function trigger(side, text) {
      const entry = entryOf(side)
      if (entry === null) throw new Error('side not attached: ' + side)
      const agent = entry.agent
      state.triggers += 1
      const id = 'msg-pipeline-' + String(state.triggers)
      agent.followup({ id, role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } })
      let timedOut = false
      await Promise.race([
        agent.whenIdle(),
        ctx.timeout(state.turnMs).then(() => { timedOut = true; try { agent.cancel({ kind: 'user' }) } catch { /* ignore */ } }),
      ])
      let out = ''
      let interrupted = false
      if (sessionQuery !== undefined) {
        try {
          const surface = await sessionQuery.readSurface(agent.id)
          out = lastAssistantText(surface)
          interrupted = surfaceInterrupted(surface)
        } catch (error) {
          note('readSurface failed: ' + String(error && error.message ? error.message : error))
        }
      }
      return { out, timedOut, interrupted }
    }

    // ------------------------------------------------------------ one turn

    async function playOneTurn() {
      if (state.busy) return 'busy: a turn is already in flight'
      if (state.blue === null || state.red === null) return 'no agents attached'
      if (state.over) return 'battle already over: ' + state.result
      state.busy = true
      state.phase = 'running'
      notify()
      try {
        const before = await readSnapshot()
        if (before === null) {
          state.phase = 'failed'
          state.error = '观战快照不可读: ' + String(state.stateFile)
          return state.error
        }
        if (before.over) {
          await finish(before)
          return 'battle over: ' + state.result
        }
        const side = before.active_team
        state.activeSide = side
        state.turn = before.turn
        const delta = deltaLines(before, state.lastSeenSeq)
        state.lastSeenSeq = Number(before.battle_seq) || 0
        state.lastSnap = before
        const prompt = state.opening && state.triggers === 0 ? openingPrompt(side, before) : newTurnPrompt(side, before, delta)
        note('触发 ' + side + ' · 第 ' + String(before.turn) + ' 回合'
          + (state.opening && state.triggers === 1 ? '（开局）' : ''))
        const started = Date.now()
        let result = await trigger(side, prompt)
        let after = await waitForChange(before, 6000)
        let fixes = 0
        let fixMode = null
        while (
          !result.timedOut
          && after !== null
          && !after.over
          && after.turn === before.turn
          && after.active_team === before.active_team
          && fixes < state.fixAttempts
        ) {
          fixes += 1
          fixMode = result.interrupted === true ? 'continue' : 'endturn'
          note(side + ' 未结束回合（第 ' + String(fixes) + ' 次'
            + (fixMode === 'continue' ? '续做提醒' : '收尾提醒')
            + '，上一回合' + (result.interrupted === true ? '被中途打断' : '正常结束') + '）')
          result = await trigger(side, fixMode === 'continue' ? continueTurnPrompt() : endTurnFixPrompt())
          after = await waitForChange(before, 6000)
        }
        const ms = Date.now() - started
        const next = after === null ? null : after
        const handoff = next !== null && (next.over || next.turn !== before.turn || next.active_team !== before.active_team)
        const record = {
          n: state.triggers,
          side,
          turn: before.turn,
          ms,
          outLen: result.out.length,
          timedOut: result.timedOut,
          fixes,
          fixMode,
          handoff,
          next: next === null ? null : next.active_team,
          kills: next === null ? null : (next.teams[side] || {}).kills,
          lost: next === null ? null : (next.teams[side] || {}).lost,
          points: before.teams === undefined || before.teams[side] === undefined ? null : before.teams[side].points,
        }
        state.timeline.push(record)
        if (state.timeline.length > 200) state.timeline.splice(0, state.timeline.length - 200)
        note(
          side + ' 第 ' + String(before.turn) + ' 回合完成 ' + (ms / 1000).toFixed(1) + 's 输出' + String(result.out.length) + '字'
          + (result.timedOut ? ' [超时]' : '')
          + (fixes > 0 ? ' [补救' + String(fixes) + '次:' + String(fixMode) + ']' : '')
          + (handoff ? ' → ' + String(next.active_team) : ' [未交接]'),
        )
        if (next !== null && next.over) await finish(next)
        else if (!handoff) {
          state.phase = 'stalled'
          state.error = side + ' 连续 ' + String(fixes) + ' 次未结束回合，管线已暂停（对手不会被唤醒）'
          note(state.error)
        }
        await writeSpectate()
        notify()
        return 'turn done: ' + side + ' ' + String(before.turn) + ' ' + String(ms) + 'ms handoff=' + String(handoff)
      } catch (error) {
        state.phase = 'failed'
        state.error = String(error && error.message ? error.message : error)
        note('failed: ' + state.error)
        return state.error
      } finally {
        state.busy = false
        notify()
      }
    }

    async function loop() {
      if (state.looping) return
      state.looping = true
      try {
        while (!state.cancelled && !state.over && state.triggers < state.maxTurns) {
          const outcome = await playOneTurn()
          if (state.phase === 'failed' || state.phase === 'stalled' || state.phase === 'over') break
          if (String(outcome).indexOf('busy') === 0) break
        }
        if (!state.over && !state.cancelled && state.phase !== 'failed' && state.phase !== 'stalled') {
          state.phase = 'paused'
          note('已达回合上限 ' + String(state.maxTurns) + '，管线暂停（用 battle_pipeline_resume 继续）')
        }
      } finally {
        state.looping = false
        notify()
      }
    }

    async function finish(snap) {
      state.over = true
      state.phase = 'over'
      state.result = String(snap.result === '' ? '对局结束' : snap.result)
      note('对局结束: ' + state.result)
      notify()
    }

    // ----------------------------------------------------------- spectate

    async function spectateText(snap, eventLimit) {
      const lines = []
      lines.push('# 六边形战争 · 控制管线观战（上帝视角）')
      lines.push('')
      lines.push('- 状态: ' + state.phase + (state.error === null ? '' : ' · ' + state.error))
      lines.push('- 第 ' + String(snap.turn) + ' 回合 · ' + teamCn(snap.active_team) + '行动')
      lines.push('- 蓝方: 存活 ' + String(snap.teams.blue.alive) + ' · 已损失 ' + String(snap.teams.blue.lost) + ' · 击毁 ' + String(snap.teams.blue.kills))
      lines.push('- 红方: 存活 ' + String(snap.teams.red.alive) + ' · 已损失 ' + String(snap.teams.red.lost) + ' · 击毁 ' + String(snap.teams.red.kills))
      if (snap.sustain === true) {
        const per = snap.sustain_per_turn === undefined ? {} : snap.sustain_per_turn
        const zoneOpen = snap.recruit_zone_turn !== undefined && snap.recruit_zone_turn > 0
          && Number(snap.turn) <= Number(snap.recruit_zone_turn)
        lines.push('- 模式: 持续部署 · 空地图开局（每回合 蓝 +' + String(per.blue) + ' / 红 +' + String(per.red) + ' 点）')
        lines.push('- 招募区域: ' + (zoneOpen
          ? '第 ' + String(snap.turn) + ' 回合 · 双方出发区域（本回合招募即可行动）'
          : '大本营周围 2 格内（当回合不可行动）'))
        lines.push('- 部署点数: 蓝 ' + String(snap.teams.blue.points) + ' · 红 ' + String(snap.teams.red.points)
          + ' · 大本营: 蓝 ' + String(snap.teams.blue.hq) + ' / 红 ' + String(snap.teams.red.hq))
      }
      if (snap.result !== '') lines.push('- 结果: ' + snap.result)
      if (state.timeline.length > 0) {
        lines.push('')
        lines.push('## 回合交接记录')
        for (const t of state.timeline.slice(-16)) {
          lines.push('- #' + String(t.n) + ' ' + teamCn(t.side) + ' 第' + String(t.turn) + '回合 '
            + (t.ms / 1000).toFixed(1) + 's 输出' + String(t.outLen) + '字'
            + (t.kills === null ? '' : ' 击毁' + String(t.kills) + ' 损失' + String(t.lost))
            + (t.points === null || t.points === undefined ? '' : ' 点数' + String(t.points))
            + (t.handoff ? ' → ' + teamCn(t.next) : ' [未交接]'))
        }
      }
      lines.push('')
      lines.push('## 战场（全视野）')
      lines.push('```')
      lines.push(String(snap.map))
      lines.push('```')
      const events = Array.isArray(snap.events) ? snap.events.slice(-(eventLimit === undefined ? 12 : eventLimit)) : []
      if (events.length > 0) {
        lines.push('')
        lines.push('## 最近战报')
        for (const ev of events) lines.push('- 第' + String(ev.turn) + '回合 ' + String(ev.text))
      }
      return lines.join('\n')
    }

    async function writeSpectate() {
      if (state.spectateFile === null) return
      const snap = await readSnapshot()
      if (snap === null) return
      try {
        await writeFile(state.spectateFile, await spectateText(snap, 12))
      } catch (error) {
        note('写观战文件失败: ' + String(error && error.message ? error.message : error))
      }
    }

    // --------------------------------------------------------------- setup

    function hostDiag() {
      const handle = state.hostHandle
      if (handle === null) return '（未启动进程句柄）'
      try {
        const out = handle.collected.stdout === undefined ? '' : String(handle.collected.stdout.readFrom(0).text)
        const err = handle.collected.stderr === undefined ? '' : String(handle.collected.stderr.readFrom(0).text)
        return 'stdout=' + out.slice(-400) + ' | stderr=' + err.slice(-400)
      } catch (error) {
        return '（读取主机输出失败: ' + String(error && error.message ? error.message : error) + '）'
      }
    }

    async function ensureHost(opts) {
      if (await portOpen()) {
        note('游戏主机已在 ' + state.host + ':' + String(state.port) + ' 监听')
        return 'already-listening'
      }
      const bin = state.gameDir + '/target/release/hex_wargame_multiplayer'
      const exists = await outOf('test -x ' + shq(bin) + ' && echo YES || echo NO', 8000)
      if (exists.text.indexOf('YES') < 0) {
        note('编译多人主机…')
        const build = await outOf('cd ' + shq(state.gameDir) + ' && cargo build --release --bin hex_wargame_multiplayer', 600000)
        if (build.code !== 0) throw new Error('cargo build failed: ' + build.err.slice(-400))
      }
      if (subprocess === undefined) throw new Error('subprocess service unavailable')
      const argv = ['env', '-u', 'WAYLAND_DISPLAY', 'DISPLAY=:0', bin,
        '--listen', state.host + ':' + String(state.port),
        '--state-file', state.stateFile,
        // 单方视角：窗口只渲染当前行动方的迷雾视野，窗口标题声明「X方视角」。
        // agent 截图据此核对后才敢抓窗口，否则退回本方视角渲染图。
        '--view', state.view]
      if (opts.seed !== undefined) argv.push('--seed', String(opts.seed))
      if (opts.sustain) {
        // 持续部署（主机默认）：空地图开局 + 每回合点数 + 大本营；这里显式传参。
        argv.push('--sustain', '--sustain-pp', String(opts.sustainPp), '--sustain-ap', String(opts.sustainAp))
        if (opts.sustainPoints !== null) argv.push('--sustain-points', String(opts.sustainPoints))
      } else {
        // 经典快速开局（预置部队）必须显式关闭，否则主机默认是持续部署。
        argv.push('--no-sustain')
      }
      const handle = subprocess.spawn({
        argv,
        cwd: state.gameDir,
        stdio: {
          stdin: 'ignore',
          stdout: { maxBytes: 262144 },
          stderr: { maxBytes: 262144 },
        },
        graceMs: 5000,
      })
      state.hostHandle = handle
      state.hostPid = handle.pid
      state.hostOwned = true
      note('启动游戏主机 pid=' + String(handle.pid))
      for (let i = 0; i < 60; i += 1) {
        if (await portOpen()) return 'started'
        await ctx.timeout(500)
      }
      throw new Error('游戏主机未能在 30 秒内监听 ' + state.host + ':' + String(state.port) + '；' + hostDiag())
    }

    /// 等到观战快照可读（主机刚启动时可能还没写出第一份）。
    async function waitSnapshot(timeoutMs) {
      const deadline = Date.now() + timeoutMs
      let snap = await readSnapshot()
      while (snap === null && Date.now() < deadline) {
        await ctx.timeout(250)
        snap = await readSnapshot()
      }
      return snap
    }

    /// 确保运行中的主机处于请求的模式。快照里的 `sustain` 是权威标志：
    /// 主机可能已被别人（或上一次 start）以另一种模式启动，此时只有本管线
    /// 自己拉起的主机才能安全重启；否则报错并给出处理办法。
    async function ensureHostMode(opts) {
      let how = await ensureHost(opts)
      let snap = await waitSnapshot(15000)
      if (snap === null) {
        throw new Error('观战快照不可读（主机是否用 --state-file 启动？）: ' + String(state.stateFile))
      }
      const actual = snap.sustain === true
      if (actual === opts.sustain) return how
      const want = opts.sustain ? '可持续部署' : '经典（全歼）'
      const has = actual ? '可持续部署' : '经典（全歼）'
      if (state.hostHandle === null) {
        throw new Error('已在 ' + state.host + ':' + String(state.port) + ' 运行的主机是' + has
          + '模式，与请求的' + want + '模式不一致；请先停掉该主机再启动管线'
          + '（battle_pipeline_stop {stop_host:true} 只能停本管线启动的主机）。')
      }
      note('主机模式不匹配（当前' + has + '），重启主机以切换到' + want + '模式')
      try { state.hostHandle.terminate() } catch { /* ignore */ }
      state.hostHandle = null
      state.hostPid = null
      state.hostOwned = false
      for (let i = 0; i < 40; i += 1) {
        if (!(await portOpen())) break
        await ctx.timeout(250)
      }
      // 删掉旧快照：新主机会立刻重写，waitSnapshot 才不会立刻读到旧模式的文件。
      await outOf('rm -f ' + shq(state.stateFile), 8000)
      how = await ensureHost(opts)
      snap = await waitSnapshot(15000)
      if (snap === null || (snap.sustain === true) !== opts.sustain) {
        throw new Error('重启后主机仍未进入' + want + '模式')
      }
      return how
    }

    function readArgs(args) {
      const gameDir = String(args.game_dir === undefined ? '/home/qirui-gao/wargame_pi' : args.game_dir)
      const now = stamp()
      return {
        gameDir,
        preset: args.preset === undefined ? DEFAULT_PRESET : String(args.preset),
        host: args.host === undefined ? DEFAULT_HOST : String(args.host),
        port: Number.isInteger(args.port) ? args.port : DEFAULT_PORT,
        stateFile: args.state_file === undefined ? gameDir + '/logs/pipeline_state.json' : String(args.state_file),
        spectateFile: args.spectate_file === undefined ? gameDir + '/logs/pipeline_spectate.md' : String(args.spectate_file),
        hostLog: args.host_log === undefined ? gameDir + '/logs/pipeline_host.log' : String(args.host_log),
        blueSession: args.blue_session === undefined ? 'session-pipe-blue-' + now : String(args.blue_session),
        redSession: args.red_session === undefined ? 'session-pipe-red-' + now : String(args.red_session),
        resume: args.resume === true,
        maxTurns: Number.isInteger(args.max_turns) ? args.max_turns : 200,
        turnMs: Number.isInteger(args.turn_timeout_ms) ? args.turn_timeout_ms : 900000,
        auto: args.mode === 'manual' ? false : true,
        seed: Number.isInteger(args.seed) ? args.seed : undefined,
        autoHost: args.auto_host !== false,
        view: args.view === 'spectator' ? 'spectator' : 'acting',
        sustain: args.sustain !== false,
        sustainPp: Number.isInteger(args.sustain_pp) ? args.sustain_pp : 10,
        sustainAp: Number.isInteger(args.sustain_ap) ? args.sustain_ap : 10,
        sustainPoints: Number.isInteger(args.sustain_points) ? args.sustain_points : null,
      }
    }

    async function setup(args) {
      const opts = readArgs(args)
      state.gameDir = opts.gameDir
      state.preset = opts.preset
      state.host = opts.host
      state.port = opts.port
      state.stateFile = opts.stateFile
      state.spectateFile = opts.spectateFile
      state.hostLog = opts.hostLog
      state.maxTurns = opts.maxTurns
      state.turnMs = opts.turnMs
      state.auto = opts.auto
      state.sustain = opts.sustain
      state.sustainPp = opts.sustainPp
      state.sustainAp = opts.sustainAp
      state.sustainPoints = opts.sustainPoints
      state.view = opts.view
      state.lastSnap = null
      state.phase = 'starting'
      state.over = false
      state.result = ''
      state.error = null
      state.cancelled = false
      state.triggers = 0
      state.timeline = []
      state.lastSeenSeq = 0
      state.activeSide = null
      state.turn = 0
      notify()
      await outOf('mkdir -p ' + shq(state.gameDir + '/logs'), 10000)
      if (opts.autoHost) await ensureHostMode(opts)
      if (agents === undefined) throw new Error('agents service unavailable')
      if (opts.resume) {
        state.blue = await resumeSide('blue', opts.blueSession)
        state.red = await resumeSide('red', opts.redSession)
      } else {
        state.blue = await attachSide('blue', opts.blueSession, opts)
        state.red = await attachSide('red', opts.redSession, opts)
      }
      await ensureIdle(state.blue.agent)
      await ensureIdle(state.red.agent)
      const snap = await readSnapshot()
      if (snap === null) throw new Error('观战快照不可读（主机是否用 --state-file 启动？）: ' + state.stateFile)
      // auto_host=false 时没有经过 ensureHostMode：这里补一次模式核对，避免
      // 用经典主机跑可持续部署的提示词（反之亦然）。
      if ((snap.sustain === true) !== opts.sustain) {
        throw new Error('运行中的主机是' + (snap.sustain === true ? '可持续部署' : '经典（全歼）')
          + '模式，与请求的' + (opts.sustain ? '可持续部署' : '经典（全歼）') + '模式不一致；'
          + '请先停掉该主机再启动管线。')
      }
      state.lastSeenSeq = Number(snap.battle_seq) || 0
      state.lastSnap = snap
      state.turn = snap.turn
      state.activeSide = snap.active_team
      state.opening = !opts.resume && state.blue.adopted !== true && state.red.adopted !== true && Number(snap.turn) <= 1
      state.phase = 'running'
      note('就绪: blue=' + String(state.blue.agent.id) + ' red=' + String(state.red.agent.id)
        + ' 当前 第' + String(snap.turn) + '回合 ' + snap.active_team + '行动 mode=' + (state.auto ? 'auto' : 'manual'))
      await writeSpectate()
      notify()
      if (state.auto) loop()
      return {
        blue: String(state.blue.agent.id),
        red: String(state.red.agent.id),
        turn: snap.turn,
        active: snap.active_team,
        stateFile: state.stateFile,
        spectateFile: state.spectateFile,
        hostPid: state.hostPid,
        mode: state.auto ? 'auto' : 'manual',
        sustain: opts.sustain,
        sustainPerTurn: opts.sustain ? { blue: opts.sustainPp, red: opts.sustainAp } : null,
      }
    }

    // --------------------------------------------------------------- tools

    const setupParams = {
      game_dir: { type: 'string', description: '游戏仓库目录，默认 /home/qirui-gao/wargame_pi。' },
      preset: { type: 'string', description: '两名指挥官的 agent preset，默认 wargame。' },
      blue_session: { type: 'string', description: '蓝方会话 id；缺省自动生成。' },
      red_session: { type: 'string', description: '红方会话 id；缺省自动生成。' },
      resume: { type: 'boolean', description: 'true 表示从磁盘恢复两个已存在的会话。' },
      mode: { type: 'string', enum: ['auto', 'manual'], description: 'auto 连续跑完整场；manual 每次 step 只跑一回合。' },
      max_turns: { type: 'integer', description: '最多触发多少次 agent 回合（默认 200；每次「续做/收尾提醒」也算一次，一轮约 2 次）。' },
      turn_timeout_ms: { type: 'integer', description: '单个 agent 回合超时毫秒（默认 900000）。' },
      host: { type: 'string', description: '游戏主机地址，默认 127.0.0.1。' },
      port: { type: 'integer', description: '游戏主机端口，默认 45123。' },
      state_file: { type: 'string', description: '观战快照路径（游戏主机写出），默认 <game_dir>/logs/pipeline_state.json。' },
      spectate_file: { type: 'string', description: '观战 markdown 路径，默认 <game_dir>/logs/pipeline_spectate.md。' },
      seed: { type: 'integer', description: '仅当管线自己启动游戏主机时使用的随机种子。' },
      auto_host: { type: 'boolean', description: '主机未监听时自动启动图形界面主机，默认 true。' },
      view: { type: 'string', enum: ['acting', 'spectator'], description: '图形界面主机的视野模式：acting（默认）= 窗口只渲染当前行动方的迷雾视野，agent 截图可安全抓窗口；spectator = 历史的全视野观战窗口（agent 截图会自动退回本方视角渲染图）。' },
      sustain: { type: 'boolean', description: '持续部署模式（默认 true，与游戏默认一致）：空地图开局（双方全部单位自行招募，第 1 回合在出发区域、第 2 回合起在大本营周围 2 格）、每回合获得部署点数、6 据点决胜；false = 预置部队经典全歼模式。' },
      sustain_pp: { type: 'integer', description: '蓝方每回合部署点数，默认 10（仅 sustain 模式）。' },
      sustain_ap: { type: 'integer', description: '红方每回合部署点数，默认 10（仅 sustain 模式；与蓝方对称，单人模式的 10/20 可显式传 sustain_ap: 20）。' },
      sustain_points: { type: 'integer', description: '双方初始部署点数，默认沿用关卡初始点数（开阔地 100/100）。' },
    }

    const textOutput = {
      schema: { type: 'string' },
      render(_a, v) { return [{ type: 'text', text: String(v) }] },
    }

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_start',
      description: '启动「回合交接管线」：确保游戏主机在跑（默认持续部署模式：空地图开局、双方单位全部自行招募；sustain:false 为预置部队经典全歼模式），创建/恢复蓝红两个 wargame 指挥官会话，然后严格轮流唤醒——一方回合结束才唤醒另一方，双方永远不会同时等待对方。',
      parameters: setupParams,
      output: textOutput,
      timeoutMs: 1800000,
      async execute(args) {
        if (state.phase === 'starting' || state.busy) return 'pipeline busy: ' + state.phase
        try {
          const info = await setup(args)
          return 'pipeline started\n' + JSON.stringify(info, null, 1)
            + '\n模式: ' + (info.sustain
              ? '持续部署（每回合 蓝 +' + String(info.sustainPerTurn.blue) + ' / 红 +' + String(info.sustainPerTurn.red) + ' 点，可在大本营追加部署）'
              : '经典（全歼）')
            + '\n观战: ' + info.spectateFile
            + (info.mode === 'auto' ? '\n（自动模式：后台连续进行，随时用 battle_pipeline_status / battle_pipeline_spectate 查看）' : '\n（手动模式：用 battle_pipeline_step 推进一个回合）')
        } catch (error) {
          state.phase = 'failed'
          state.error = String(error && error.message ? error.message : error)
          note('start failed: ' + state.error)
          return 'start failed: ' + state.error
        }
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_step',
      description: '手动推进一个 agent 回合（当前行动方），等它结束输出并核对回合是否真正交接后才返回。',
      parameters: { turn_timeout_ms: { type: 'integer', description: '本回合超时毫秒，覆盖启动时的默认值。' } },
      output: textOutput,
      timeoutMs: 1800000,
      async execute(args) {
        if (state.blue === null || state.red === null) return 'pipeline not started'
        if (Number.isInteger(args.turn_timeout_ms)) state.turnMs = args.turn_timeout_ms
        if (state.over) return 'battle already over: ' + state.result
        const out = await playOneTurn()
        const snap = await readSnapshot()
        if (snap === null) return out
        return out + '\n现在: 第' + String(snap.turn) + '回合 ' + teamCn(snap.active_team) + '行动'
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_status',
      description: '控制管线状态：阶段、当前回合与行动方、每个 agent 的忙碌状态、回合交接记录与耗时。',
      parameters: { timeline: { type: 'integer', description: '返回最近多少条交接记录，默认 12。' } },
      output: textOutput,
      async execute(args) {
        const n = Number.isInteger(args.timeline) ? args.timeline : 12
        const lines = []
        lines.push('phase=' + state.phase + ' auto=' + String(state.auto) + ' triggers=' + String(state.triggers)
          + '/' + String(state.maxTurns) + ' busy=' + String(state.busy) + ' over=' + String(state.over)
          + ' sustain=' + String(state.sustain))
        if (state.error !== null) lines.push('error=' + state.error)
        if (state.result !== '') lines.push('result=' + state.result)
        lines.push('blue=' + (state.blue === null ? '-' : String(state.blue.agent.id) + ' (' + state.blue.agent.status + ')')
          + ' red=' + (state.red === null ? '-' : String(state.red.agent.id) + ' (' + state.red.agent.status + ')'))
        lines.push('state_file=' + String(state.stateFile) + ' spectate=' + String(state.spectateFile)
          + (state.hostPid === null ? '' : ' host_pid=' + String(state.hostPid)))
        const snap = await readSnapshot()
        if (snap !== null) {
          lines.push('game: 第' + String(snap.turn) + '回合 ' + teamCn(snap.active_team) + '行动 · 蓝 存活'
            + String(snap.teams.blue.alive) + '/损失' + String(snap.teams.blue.lost) + '/击毁' + String(snap.teams.blue.kills)
            + ' · 红 存活' + String(snap.teams.red.alive) + '/损失' + String(snap.teams.red.lost) + '/击毁' + String(snap.teams.red.kills)
            + (snap.result === '' ? '' : ' · ' + String(snap.result)))
          if (snap.sustain === true) {
            const zoneOpen = snap.recruit_zone_turn !== undefined && snap.recruit_zone_turn > 0
              && Number(snap.turn) <= Number(snap.recruit_zone_turn)
            lines.push('sustain: 空地图招募 · 每回合 蓝 +' + String(snap.teams.blue.points_per_turn) + ' / 红 +' + String(snap.teams.red.points_per_turn)
              + ' · 部署点数 蓝 ' + String(snap.teams.blue.points) + ' / 红 ' + String(snap.teams.red.points)
              + ' · 大本营 蓝 ' + String(snap.teams.blue.hq) + ' / 红 ' + String(snap.teams.red.hq)
              + ' · 招募区域 ' + (zoneOpen ? '出发区域（第 ' + String(snap.turn) + ' 回合）' : '大本营周围 2 格'))
          }
        } else {
          lines.push('game: 快照不可读')
        }
        lines.push('--- 回合交接 ---')
        for (const t of state.timeline.slice(-n)) {
          lines.push('#' + String(t.n) + ' ' + teamCn(t.side) + ' 第' + String(t.turn) + '回合 '
            + (t.ms / 1000).toFixed(1) + 's 输出' + String(t.outLen) + '字'
            + (t.timedOut ? ' [超时]' : '')
            + (t.kills === null ? '' : ' 击毁' + String(t.kills) + ' 损失' + String(t.lost))
            + (t.points === null || t.points === undefined ? '' : ' 点数' + String(t.points))
            + (t.handoff ? ' → ' + teamCn(t.next) : ' [未交接]'))
        }
        lines.push('--- 事件 ---')
        for (const line of state.events.slice(-14)) lines.push(line)
        return lines.join('\n')
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_resume',
      description: '暂停/达到回合上限后继续推进：提高回合上限并重新启动自动循环。不重置对局、不重建会话（继续使用当前已接管的两个 agent，对局从中断处接着打）。',
      parameters: {
        max_turns: { type: 'integer', description: '再增加多少次触发额度（默认 200）；也可理解为新的上限 = 当前已触发次数 + 该值。' },
        mode: { type: 'string', enum: ['auto', 'manual'], description: 'auto（默认）立刻重新启动自动循环；manual 只提高上限、恢复状态，不自动推进。' },
      },
      output: textOutput,
      async execute(args) {
        if (state.blue === null || state.red === null) return 'pipeline not started：请先用 battle_pipeline_start 建立会话'
        if (state.over) return 'battle already over: ' + state.result
        if (state.busy) return 'busy: a turn is in flight; 稍后再试'
        if (state.looping) return 'already running: 自动循环仍在推进'
        const add = Number.isInteger(args.max_turns) ? Math.max(1, args.max_turns) : 200
        state.maxTurns = state.triggers + add
        state.cancelled = false
        state.error = null
        state.phase = 'running'
        note('继续推进：回合上限提高到 ' + String(state.maxTurns) + '（已触发 ' + String(state.triggers) + ' 次）')
        notify()
        if (args.mode !== 'manual') loop()
        const snap = await readSnapshot()
        return 'resumed: triggers=' + String(state.triggers) + '/' + String(state.maxTurns)
          + ' game=' + (snap === null ? '?' : '第' + String(snap.turn) + '回合 ' + teamCn(snap.active_team) + '行动')
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_spectate',
      description: '观战视图：从游戏主机的观战快照渲染全视野战场（双方单位都可见）、局势、回合交接记录与最近战报。',
      parameters: { events: { type: 'integer', description: '附带多少条最近战报，默认 10。' } },
      output: textOutput,
      async execute(args) {
        const snap = await readSnapshot()
        if (snap === null) return '快照不可读: ' + String(state.stateFile) + '（管线是否已启动？）'
        return await spectateText(snap, Number.isInteger(args.events) ? args.events : 10)
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_wait',
      description: '等待管线取得进展（回合交接、结束、失败）或超时，然后返回一行状态。',
      parameters: { timeout_ms: { type: 'integer', description: '最长等待毫秒，默认 120000。' } },
      output: textOutput,
      timeoutMs: 1800000,
      async execute(args) {
        const ms = Number.isInteger(args.timeout_ms) ? Math.max(1000, Math.min(args.timeout_ms, 1500000)) : 120000
        await Promise.race([state.wakePromise, ctx.timeout(ms)])
        const snap = await readSnapshot()
        return 'phase=' + state.phase + ' triggers=' + String(state.triggers) + ' over=' + String(state.over)
          + ' game=' + (snap === null ? '?' : '第' + String(snap.turn) + '回合' + teamCn(snap.active_team))
          + (state.error === null ? '' : ' error=' + state.error)
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_say',
      description: '监督者直接给某一方指挥官留言（会立即唤醒它，因此会额外消耗一个回合；仅在需要人工干预时使用）。',
      parameters: {
        side: { type: 'string', enum: ['blue', 'red'], required: true },
        message: { type: 'string', required: true },
      },
      output: textOutput,
      timeoutMs: 1800000,
      async execute(args) {
        const entry = entryOf(String(args.side))
        if (entry === null) return 'side not attached: ' + String(args.side)
        if (state.busy) return 'busy: a turn is in flight; 稍后再试'
        state.busy = true
        try {
          const result = await trigger(String(args.side), String(args.message))
          return 'sent to ' + String(args.side) + (result.timedOut ? ' (timeout)' : '') + '\n' + result.out.slice(0, 800)
        } finally {
          state.busy = false
          notify()
        }
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_turnend',
      description: '诊断：读取某一方（或指定会话）最近几次 agent 回合的结束原因（completed=正常结束 / aborted=被中途打断 / interrupted / max-tokens），用于判断该要求继续做完本回合还是提醒收尾。',
      parameters: {
        side: { type: 'string', enum: ['blue', 'red'], description: '按阵营取会话；与 session_id 二选一。' },
        session_id: { type: 'string', description: '直接给会话 id；与 side 二选一。' },
        count: { type: 'integer', description: '返回最近多少条，默认 5。' },
      },
      output: textOutput,
      async execute(args) {
        let sessionId = args.session_id === undefined ? null : String(args.session_id)
        let label = sessionId
        if (sessionId === null && (args.side === 'blue' || args.side === 'red')) {
          const entry = entryOf(String(args.side))
          if (entry === null) return 'side not attached: ' + String(args.side)
          sessionId = String(entry.agent.id)
          label = String(args.side) + ' ' + sessionId
        }
        if (sessionId === null) return '需要 side 或 session_id'
        const list = await recentTurnEnds(sessionId, Number.isInteger(args.count) ? args.count : 5)
        if (list.length === 0) return label + '：没有读到 turn/end 事件'
        const lines = [label + ' 最近 ' + String(list.length) + ' 次回合结束：']
        for (const item of list) {
          lines.push('- 第' + String(item.turn) + '回合 seq=' + String(item.seq) + ' 原因=' + String(item.reason)
            + (isInterrupted(item.reason) ? '（被中途打断 → 应要求继续做完本回合）' : '（正常结束 → 若对局未推进则提醒收尾）'))
        }
        return lines.join('\n')
      },
    }))

    harness.registerTool(ctx, harness.defineTool({
      name: 'battle_pipeline_stop',
      description: '停止控制管线；dispose=true 时同时销毁本管线创建的 agent 会话，stop_host=true 时停止本管线启动的游戏主机。',
      parameters: {
        dispose: { type: 'boolean' },
        stop_host: { type: 'boolean' },
      },
      output: textOutput,
      timeoutMs: 300000,
      async execute(args) {
        state.cancelled = true
        state.phase = 'stopped'
        notify()
        for (const side of ['blue', 'red']) {
          const entry = entryOf(side)
          if (entry !== null) { try { entry.agent.cancel({ kind: 'user' }) } catch { /* ignore */ } }
        }
        if (args.dispose === true) {
          for (const side of ['blue', 'red']) {
            const entry = entryOf(side)
            if (entry !== null && entry.adopted !== true) {
              try { await entry.dispose() } catch { /* ignore */ }
            }
            if (side === 'blue') state.blue = entry !== null && entry.adopted === true ? entry : null
            else state.red = entry !== null && entry.adopted === true ? entry : null
          }
        }
        if (args.stop_host === true && state.hostHandle !== null) {
          try { state.hostHandle.terminate() } catch { /* ignore */ }
          note('已停止游戏主机 pid=' + String(state.hostPid))
          state.hostPid = null
          state.hostHandle = null
        }
        return 'stopped' + (args.dispose === true ? ' (agents disposed)' : '') + (args.stop_host === true ? ' (host stopped)' : '')
      },
    }))
  },
}
