#!/usr/bin/env python3
"""Build the self-contained visual upgrade report from recorded evidence."""
import argparse
import base64
import html
import io
import json
import re
from pathlib import Path

from PIL import Image

parser=argparse.ArgumentParser()
parser.add_argument("evidence",type=Path)
parser.add_argument("destination",type=Path)
parser.add_argument("requirements",type=Path)
args=parser.parse_args()

def data(name):
    return json.loads((args.evidence/name).read_text())

def picture(name,alt):
    with Image.open(args.evidence/f'{name}.png') as source:
        image=source.convert('RGB')
        image.thumbnail((1440,960))
        encoded=io.BytesIO()
        image.save(encoded,format='JPEG',quality=89,optimize=True)
    blob=base64.b64encode(encoded.getvalue()).decode()
    return f'<figure><img loading="lazy" width="{image.width}" height="{image.height}" src="data:image/jpeg;base64,{blob}" alt="{html.escape(alt)}"><figcaption>{html.escape(alt)}</figcaption></figure>'

def table(headers,rows):
    head=''.join(f'<th scope="col">{html.escape(str(cell))}</th>' for cell in headers)
    body=''.join('<tr>'+''.join(f'<td>{html.escape(str(cell))}</td>' for cell in row)+'</tr>' for row in rows)
    return f'<div class="scroll"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'

audit=data('map-audit.json')
titles={x['id']:x['name'] for x in audit}
areas=[]
routes=[]
for row in audit:
    before,after=row['before'],row['after']
    for zone,now in after['areas'].items():
        then=before['areas'][zone]
        zone_name={'front':' · 正面','pass':' · 西力斯昂哥','doom':' · 末日山'}.get(zone,'')
        areas.append((row['name']+zone_name,f"{then['width']}×{then['height']} → {now['width']}×{now['height']}",
                      f"{then['passable']:,} → {now['passable']:,}",f"{now['passable']/then['passable']-1:+.0%}",
                      f"{before['units']} → {after['units']}",f"{before['visualFigures']} → {after['visualFigures']}"))
    for left,right in zip(before['routes'],after['routes'],strict=True):
        key={'ford':'渡口','exit':'撤离区','culvert':'涵洞','counter':'反击或通路目标','cave':'洞窟','blast':'爆破点',
             'gate':'城门','core':'章节核心','dock0':'北泊位','dock2':'南泊位','pass':'序幕出口','crack':'末日裂隙','front':'正面牵制点'}[right['key']]
        kinds={'meRohanFoot':'西谷步兵','meRiderLord':'洛汗将领','meAragorn':'阿拉贡','meBlast':'爆破装置','meThorin':'索林',
               'meElf':'林地精灵','meBolg':'波尔格','meGrond':'格龙德','meGondorHorse':'刚铎骑兵','meGondor':'刚铎盾矛兵','meFrodo':'弗罗多'}
        fmt=lambda x: f"{x['cells']} 格 / {x['turns']} 回合" if 'turns' in x else '封闭'
        routes.append((row['name'],kinds[right['kind']]+' → '+key,fmt(left),fmt(right)))

before_bench=data('browser-before.json')
after_bench=data('browser.json')
metrics=[]
for label,report in [('v28.47',before_bench),('v28.48',after_bench)]:
    for r in report['rows']:
        render=r['after']['render']
        metrics.append((label,titles[r['id']],f"{r['frame']['p50']:.1f} / {r['frame']['p95']:.1f}",r['turnMs'],r['zoomMs'],
                        f"{r['after']['heapMB']:.0f}",render['calls'],f"{render['triangles']:,}",r['before']['live']))
assert len(after_bench['rows'])==8 and not after_bench['errors']
assert len(before_bench['rows'])==2 and not before_bench['errors']
full=(args.evidence/'full.log').read_text()
tests=re.search(r'# pass (\d+)\n# fail (\d+)',full)
assert tests and tests[2]=='0'
target=re.search(r'# pass (\d+)\n# fail (\d+)',(args.evidence/'targeted.log').read_text())
assert target and target[2]=='0'
checks=(args.evidence/'package-check.log').read_text().strip()
replays=[]
for line in (args.evidence/'morannon-playthrough.log').read_text().splitlines():
    r=json.loads(line)
    replays.append((r['seed'],{'careful':'谨慎','rush':'急进','abandon-front':'正面全军失效模拟'}[r['strategy']],
                    len(r['journey']),r.get('reason','达到脚本上限')))
chapters={
    'me_hornburg':('海尔姆深谷','西侧后谷和洞窟提供退守通道。北岩台的号角堡与南壁之间接上深谷墙。外堤与主墙间隔 11 列，保留东侧集结区和北侧黎明援军路线。主门、侧门和涵洞分别占据不同通路。'),
    'me_erebor':('孤山五军之战','索尔图以东在上，战术图旋转到北在上。南向双山脊包住奔流河谷，西南乌鸦岭高地设有坡道。东侧翼、两条山后攀行路线与河谷邦街巷用于换防、伏击和出击。'),
    'me_isen_first':('艾辛河渡口','双支河与洲上低丘构成渡口，东西两岸分别有道路和威胁。新增东南撤离纵深和北侧来敌空间。两个开局共用地形，部署、救援和迟滞目标独立。'),
    'me_pelennor':('佩兰诺平原','西南王城主门、阶梯城景与明多路因山麓相接。中段保留骑兵和攻城阵列用地，果园、田块、溪流与外围兰马斯残墙形成局部遮蔽，东南靠安都因布置登陆道路。'),
    'me_pelargir':('佩拉基尔','三个黑船泊位沿安都因布置，靠仓储街、码头和横向道路接通。街巷与泊位形状为关卡推演。恐惧驱散、活人接管和阿拉贡履约沿用既有规则。'),
    'me_morannon_final':('黑门双线','正面把西方联军分置于两丘附近，门前泥沼和南北迂回路径分流。末日山另有火山坡、灰烬沟壑和多条掩护路径。西力斯昂哥保留独立序幕，决战两个视图共享回合。'),
}
references=args.requirements.read_text()
link_groups=[]
for prefix,pattern in [('地理与原著定位',r'^(T\d+)\s+([^\n]+)\n(https?://[^\s]+)'),
                       ('Wētā 电影造型',r'^\[(F\d+)\]\s+([^\n]+)\n(https?://[^\s]+)'),
                       ('Three.js 186 技术参考',r'^(C\d+)\s+([^\n]+)\n(https?://[^\s]+)')]:
    links=''.join(f'<li><a href="{html.escape(url)}">{html.escape(num+" "+name)}</a></li>'
                 for num,name,url in re.findall(pattern,references,re.M))
    link_groups.append(f'<details><summary>{prefix}</summary><ul>{links}</ul></details>')

overview=''.join(f'<article><h3>{title}</h3><p>{text}</p>{picture(key+"-panorama",title+" · 游戏内战场全景")}</article>'
                 for key,(title,text) in chapters.items())
details=''.join('<article><h3>'+chapters[key][0]+'</h3><div class="pair">'+picture(key+'-before','v28.47 · 地点标签隐藏')+
                picture(key+'-after','v28.48 · 地点标签隐藏')+'</div>'+picture(key+'-overview','纯俯视 · 保留实际界面')+'</article>'
                for key in ('me_hornburg','me_erebor'))
source_video=args.destination.parent/'孤山实战演示.mp4'
video=base64.b64encode(source_video.read_bytes()).decode()
package_links=''.join(f'<li><a href="{n}">{label}</a></li>' for n,label in [
    ('六边形战争-v28.48-macOS.zip','macOS Apple 芯片'),('HexWargame-v28.48-Windows-x64.zip','Windows x64'),
    ('HexWargame-v28.48-Linux-x64.tar.gz','Linux x64'),('HexWargame-v28.48-Linux-ARM64.tar.gz','Linux ARM64'),
    ('SHA256SUMS.txt','SHA-256 校验清单'),('孤山实战演示.mp4','独立 MP4 录屏')])
report=f'''<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>六边形战争 v28.48 · 中土地图与兵模</title>
<style>
:root{{color-scheme:dark;--ink:#ebeadf;--dim:#bac1b4;--accent:#e0bd7d;--panel:#222a24;--rule:#495649}}*{{box-sizing:border-box}}
body{{margin:0;background:#141c17;color:var(--ink);font:16px/1.7 system-ui,sans-serif}}main{{max-width:1200px;margin:auto;padding:38px 28px 74px}}
header{{padding:38px 0 30px;border-bottom:1px solid var(--rule)}}h1,h2,h3{{font-family:Georgia,"Songti SC",serif;line-height:1.2}}
h1{{font-size:clamp(36px,6vw,67px);margin:.2em 0}}h2{{font-size:32px;margin-top:62px;border-bottom:1px solid var(--rule);padding-bottom:12px}}
h3{{font-size:23px}}p{{max-width:85ch}}nav{{display:flex;flex-wrap:wrap;gap:14px}}a{{color:var(--accent)}}small,figcaption,.muted{{color:var(--dim)}}
article{{margin:22px 0 30px}}figure{{margin:10px 0}}img,video{{width:100%;height:auto;border:1px solid var(--rule);border-radius:7px}}
figcaption{{font-size:14px;margin-top:5px}}.pair,.gallery{{display:grid;grid-template-columns:1fr 1fr;gap:15px}}
.gallery article{{margin:0;background:var(--panel);padding:15px;border-radius:8px}}.gallery h3{{margin:0 0 10px}}
.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;white-space:nowrap}}td,th{{text-align:left;padding:8px 11px;border-bottom:1px solid var(--rule)}}
th{{background:var(--panel)}}details{{padding:9px 0;border-bottom:1px solid var(--rule)}}summary{{cursor:pointer}}code{{color:#dfc89a;overflow-wrap:anywhere}}
@media(max-width:730px){{main{{padding:22px 16px}}.pair,.gallery{{grid-template-columns:1fr}}}}
</style>
<main>
<header><small>六边形战争 v28.48 · 2026 年 11 月 12 日</small><h1>中土地图与兵模重制</h1>
<p>六章八个起点采用地图 V2。海尔姆和孤山从 40×26 格扩为 58×36 和 52×40 格。所有章节可用战场全景，近处保留指挥距离、单位选择和正上方棋盘。</p>
<nav><a href="#maps">六章全景</a><a href="#compare">样板对照</a><a href="#troops">兵模与实战</a><a href="#sizes">地图与路线</a><a href="#tests">实测</a><a href="#downloads">安装包</a></nav></header>
<section id="maps"><h2>六章全景</h2><p>高程由地图数据驱动。陡崖对步兵构成阻挡，座狼与骑兵走山路。渲染加深山脊和河谷的垂直层次，边界外连续铺接山脚、远山和河面。远景网格没有站位、选中或交战能力。黑门只加载当前战区的地表和远景。</p>
<div class="gallery">{overview}</div>
<div class="pair">{picture('me_isen_second-panorama','艾辛河第二次战斗 · 同地形、不同部署')}{picture('me_morannon-doom-panorama','末日山 · 独立战区的火山坡与通路')}</div></section>
<section id="compare"><h2>海尔姆与孤山前后对照</h2>
<p>同一章节使用相同俯仰、偏航和镜头距离，焦点对准相应地理位置。对照图隐藏地点标签，保留战斗界面和真实迷雾。旧海尔姆整排溪流同时使用河流与道路标记，产生连续浅色。旧孤山两翼以规则矩形山地为主。新版把地标、道路、过水点和高差写入地格数据。</p>{details}</section>
<section id="troops"><h2>兵模与实战</h2>
<p>用可编辑的程序化网格制作甲胄与坐骑，复用原有骨架关节、武器切换和攻击时序。刚铎高盔与板甲、洛汗绿披风与圆盾、普通半兽人佝偻体态、强兽人黑铁与白手盾、林地精灵修长轮廓、矮人厚甲、座狼粗肩和颚部在近景保留各自的结构。远景合并静态几何，飞兽和坐骑沿现有动作控制器工作。图鉴和战役共用资产，菜单地图预览从 V2 地图重新生成。</p>
<div class="pair">{picture('models-before','v28.47 · 兵种家族，统一光照')}{picture('models-after','v28.48 · 兵种家族，统一光照')}</div>
<p>下方录屏在孤山正常战斗中执行弓箭射击、单位移动、俯视切换、缩放和首轮结算。保留真实界面与战争迷雾。</p>
<video controls playsinline preload="metadata" src="data:video/mp4;base64,{video}"></video>
</section>
<section id="sizes"><h2>地图、兵力与实际行军</h2>
<p>通行面积按普通地面步兵的移动成本统计，排除驻军墙格。黑门各区按其可用阶段分别测量，兵团数为全关合计。展示人数按兵团编组估算，随战争迷雾和视角改变。</p>
{table(['开局与战区','范围','通行格','通行增幅','机动兵团','模型展示数量'],areas)}
<p>路线通过游戏可达格函数搜索，按每回合两次行动和渡口耗尽行动力结算。测量保留地形、桥和工事，移开沿路其他兵团。攻守争夺、拦截或溃逃会改变实战耗时。海尔姆城墙与外堤之间的纵深为 11 列，孤山山门至河谷邦街区约 20 排。正面主力维持原战力和移动力。</p>
{table(['开局','兵种与终点','v28.47','v28.48'],routes)}
</section>
<section id="tests"><h2>实测与回归</h2>
<p>Apple M4、16 GB，Chromium 无头，1440×960，默认画质。首轮结算计时从点击结束到回合界面更新。帧间隔取结算后连续 60 帧，缩放计时包含输入派发及随后两帧。JS 堆记录首轮后垃圾回收后的留存值，包含浏览器进程仍持有的对象，三角面与绘制提交数为当帧整个场景。以样板基线设置开局交战预算，P95 不超过 33.3 ms、结算不超过 450 ms、缩放反馈不超过 150 ms、留存 JS 堆低于 512 MiB。持续长局与 M1 16 GB 需要对应设备复测。</p>
{table(['版本','开局','P50/P95 帧间隔 ms','首轮结算 ms','缩放 ms','JS 堆 MiB','绘制提交','场景三角面','可见机动兵团'],metrics)}
<p>全量回归 {tests[1]} 项通过，失败 {tests[2]} 项。中土专项 {target[1]} 项通过。浏览器八个入口完成首轮、全景往返与纯俯视，页面错误 0。专项覆盖旧版八个起点存档、地图版本及高程读回、海尔姆侧门和涵洞实走、爆破、山坡通行、空地共格、渡口撤离、亡者履约、黑门搜索与戒灵调动。</p>
{table(['黑门种子','路线','记录回合','结果'],replays)}
<p>兵模验收覆盖实时轮廓、现有武器动作和近远层级。电影背面未获完整三视图，部分结构按公开图库推演。逐个角色的电影级面部、背面细节、逐帧动作复刻及所有随机分支仍待进一步验收。</p>
</section>
<section id="sources"><h2>参考依据与制作取舍</h2>
<p>海尔姆采用作者鸟瞰稿核对谷口、号角岩、溪流和外堤方向，再按《双塔殊途》卷三第七章的结构建立关卡。孤山的 Bodleian 图件页面超时，采用托尔金遗产委员会公布的 <a href="https://www.tolkienestate.com/painting/maps/">1936 年索尔原图与海尔姆手稿</a>，根据《霍比特人》第十七章布置两翼和正门。魔多早期鸟瞰用于地貌参考。码头与仓储道路采用战术关卡推演。</p>
<p>F1–F4 提取高盔、披风、鳞甲、圆盾和鞍位，F5–F7 校对兽人身形和座狼肩背，F8–F9 校对翼膜、骑手及幽绿轮廓，F10–F11 采用精灵与矮人各自的身材和装备，F12–F13 校对大型单位负重与比例。运行时使用 Three.js r186 的现有渲染与动作管线，建筑按批实例化。可编辑源文件为 <code>web3d/ancient/middle-earth-landscapes.mjs</code>、<code>middle-earth-models.mjs</code>、<code>middle-earth-scenery.mjs</code> 和 <code>middle-earth-horizon.mjs</code>。</p>
{''.join(link_groups)}</section>
<section id="downloads"><h2>安装与验证</h2>
<ul>{package_links}</ul>
<p>Mac 解压后打开应用。Windows 运行 <code>start.cmd</code>，Linux 运行 <code>./start.sh</code>，然后在浏览器打开 <code>http://127.0.0.1:8800/ancient/</code>。从「战役选择 → 中土战役」进入，战斗状态条显示地图 V2。旧战局读取存档中的原地图和原坐标。用户数据目录仍独立于应用包。</p>
<p>{html.escape(checks)}</p>
</section></main></html>'''
args.destination.write_text(report)
