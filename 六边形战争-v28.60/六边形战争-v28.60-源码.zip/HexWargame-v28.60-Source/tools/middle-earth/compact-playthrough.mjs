import * as E from '../../web3d/ancient/engine.mjs';
import {MIDDLE_EARTH} from '../../web3d/ancient/middle-earth-data.mjs';
import {makeMiddleEarthMap} from '../../web3d/ancient/middle-earth-maps.mjs';
import {meRoll} from '../../web3d/ancient/middle-earth-rules.mjs';

const active=u=>u.hp>0&&!E.isRouted(u)&&!u.escaped;
const names={me_isen_second:5,me_morannon_final:35};
const preset=process.argv[2];
const layoutVersion=Number(process.argv[3]||6);
const override=Number(process.argv[4]||0);
const waitDefense=process.env.HEX_WAIT_DEFENSE==='1';

function portTurn(s){
  const actions=[],p=s.map.victory.points;
  const a=s.map.units.find(u=>u.kind==='meAragorn');
  const troops=s.map.units.filter(u=>u.team==='egypt'&&active(u));
  const order={meDead:0,meGuard:1,meGondorBow:2,meGondor:3,meAragorn:4};
  const dock=u=>u.r<16?p.dock0:u.r>19?p.dock2:p.dock1;
  for(const u of troops.sort((a,b)=>order[a.kind]-order[b.kind])){
    for(let i=0;i<2&&!s.over&&active(u)&&u.actionsLeft>0;i++){
      const foes=s.map.units.filter(v=>v.team==='coalition'&&active(v)&&v.kind!=='meBlackShip'&&E.knownTo(s,u.team,v));
      const attacks=foes.map(v=>E.attackPreview(s,u,v.c,v.r)).filter(Boolean)
        .sort((a,b)=>a.target.hp-a.damage-b.target.hp+b.damage||b.hit-a.hit);
      if(attacks.length){
        const t=attacks[0].target,result=E.attack(s,u.id,t.c,t.r,meRoll(s),meRoll(s),meRoll(s),meRoll(s));
        if(result.ok){actions.push({type:'attack',id:u.id,at:[t.c,t.r],hit:result.hit});continue;}
      }
      let goal=u.kind==='meAragorn'?p.core:dock(u);
      if(s.turn<=2&&u.kind!=='meDead'){
        if(u===a&&(!foes.length||foes.every(v=>E.distance(u,v)>3)))break;
        goal={c:u===a?20:27,r:u.r};
      }
      let risk=()=>0;
      if(u===a&&foes.length){
        // Keep the oath-bearer outside the first wave's melee contact.
        risk=q=>foes.reduce((n,v)=>n+Math.max(0,6-E.distance(v,q))*2.7,0);
      }
      if(u.kind==='meDead'&&foes.length){
        goal=foes.sort((v,w)=>E.distance(v,u)-E.distance(w,u))[0];
      }
      const score=q=>Math.max(0,E.distance(q,goal)-1)+risk(q);
      const best=[...E.reachable(s,u).values()].filter(q=>score(q)<score(u))
        .sort((a,b)=>score(a)-score(b)||a.cost-b.cost)[0];
      if(!best)break;
      const from=[u.c,u.r],result=E.move(s,u.id,best.c,best.r);
      if(!result.ok)break;
      actions.push({type:'move',id:u.id,from,path:result.path});
    }
  }
  if(!s.over)E.endSide(s);
  return actions;
}

for(const {id,name} of MIDDLE_EARTH.filter(e=>!preset||preset===e.id)){
  const seed=override||names[id]||17;
  const s=E.startGame(makeMiddleEarthMap(id,{layoutVersion}),{middleEarthSeed:seed,mutinySeed:seed});
  const started=performance.now(),rounds=[],first={};
  for(let side=0;side<2*(s.map.victory.turnLimit+2)&&!s.over;side++){
    const turn=s.turn,team=s.side;
    const actions=waitDefense&&team==='egypt'?(E.endSide(s),[]):id==='me_pelargir'&&team==='egypt'&&layoutVersion===6?portTurn(s):E.aiTurn(s);
    for(const a of actions){
      const key=team+'_'+a.type;
      first[key]??=turn;
      if(a.type==='attack'&&a.hit)first[team+'_hit']??=turn;
    }
    rounds.push({turn,team,actions,events:Object.keys(s.middleEarth.events),withdrawn:s.middleEarth.withdrawn.length,
      docks:[...(s.middleEarth.docks??[])],west:s.map.units.filter(u=>u.kind!=='fort'&&u.team==='egypt'&&active(u)).length});
  }
  console.log(JSON.stringify({id,name,layoutVersion,seed,turn:s.turn,winner:s.winner,reason:s.victoryReason,
    events:s.middleEarth.events,first,elapsedMs:Math.round(performance.now()-started),rounds}));
}
