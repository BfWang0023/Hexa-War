#!/usr/bin/env python3
import base64
import html
import json
import re
import sys
from pathlib import Path

evidence = Path(sys.argv[1])
output = Path(sys.argv[2])
names = {
    'me_isen_first':'艾辛渡口第一次', 'me_isen_second':'艾辛渡口第二次',
    'me_hornburg':'海尔姆深谷', 'me_pelennor':'佩兰诺平原', 'me_erebor':'孤山五军之战',
    'me_pelargir':'佩拉基尔夺船', 'me_morannon':'黑门（含潜行序幕）', 'me_morannon_final':'黑门（直接决战）',
}
def read_lines(name):
    return [json.loads(line) for line in (evidence/name).read_text().splitlines() if line]
def uri(path, kind):
    return 'data:'+kind+';base64,'+base64.b64encode(path.read_bytes()).decode()
def image(name, label):
    return f'<figure><img src="{uri(evidence/(name+".jpg"), "image/jpeg")}" alt="{label}" loading="lazy"><figcaption>{label}</figcaption></figure>'
def pair(values):
    return ' / '.join(map(str,values))
def summary(result):
    return f'{result["turn"]} 回合 · {"友军" if result["winner"]=="egypt" else "敌军"}胜'
def metrics(result):
    final = result['final']
    return [pair(result['initial']),f'{pair(result.get("peakAlive",result["peak"]))}（合计 {result.get("peakAliveTogether",result["peakTogether"])}）',
        pair(result['committed']),pair(result.get('reserve') or [p-c for p,c in zip(result['planned'],result['committed'])]),
        pair([v['dead'] for v in final]),pair([v['routed'] for v in final]),
        pair([v['withdrawn'] for v in final]),pair([v['alive'] for v in final]),summary(result)]
old = {x['id']:x for x in read_lines('old.jsonl')}
new = {x['id']:x for x in read_lines('army.jsonl')}
assert set(old) == set(new) == set(names)
browser = json.loads((evidence/'browser.json').read_text())['new']
assert not browser['errors'] and browser['terminal']['over']
assert all(browser[k]['active']==88 for k in ('default','restart','reload','return'))
assert browser['hornburg']['active']==50
assert all(browser[k]['people'] % 4 == 0 for k in ('default','combat','restart','reload','return'))
tests=(evidence/'regression.log').read_text()
match=re.search(r'# pass (\d+)\s+# fail 0',tests)
assert match
pel=new['me_pelennor']
peak=browser['combat']
frames=browser['combatFrames']
assert peak['active']>=88
video=uri(output.parent/'佩兰诺大军团会战实录.mp4','video/mp4')
rows=''
for id,name in names.items():
    for ver,data in [('旧',old[id]),('新',new[id])]:
        cells=''.join(f'<td>{html.escape(x)}</td>' for x in metrics(data))
        rows+=f'<tr class="{"latest" if ver=="新" else "previous"}"><th>{name}</th><td>{ver}</td>{cells}</tr>'
gallery=''
for key,label in [('city','白城全景'),('gate','城门与墙体'),('field','城外地表'),('river','连续河段')]:
    gallery+=f'<h3>{label}</h3><div class="compare">{image("old-"+key,"v28.52 · 同机位")}{image("new-"+key,"v28.53 · 同机位")}</div>'
terminal=browser['terminal']
assets=[
    ('Grass 001','https://ambientcg.com/a/Grass001','颜色、OpenGL 法线、粗糙度','ambientCG'),
    ('Brown Mud','https://polyhaven.com/a/brown_mud','颜色','Poly Haven'),
    ('Rock Face','https://polyhaven.com/a/rock_face','颜色，降饱和','Poly Haven'),
    ('Stone Tile Wall','https://polyhaven.com/a/stone_tile_wall','颜色、OpenGL 法线、粗糙度','Poly Haven'),
    ('Wooden Planks','https://polyhaven.com/a/wooden_planks','颜色、OpenGL 法线、粗糙度','Poly Haven'),
    ('Grey Roof Tiles','https://polyhaven.com/a/grey_roof_tiles','颜色','Poly Haven'),
    ('Ceramic Roof 01','https://polyhaven.com/a/ceramic_roof_01','颜色','Poly Haven'),
]
asset_rows=''.join(f'<tr><th><a href="{url}">{name}</a></th><td>{owner}</td><td>1024 × 1024</td><td>{channels}</td><td>CC0 1.0</td></tr>' for name,url,channels,owner in assets)
lifecycle=' · '.join(f'{label} {browser[k]["textures"]} 纹理 / {browser[k]["geometries"]} 几何' for k,label in [('restart','重开'),('reload','存读档'),('hornburg','切海尔姆'),('return','切回佩兰诺')])
docs=f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>中土大军团与材质重制验收</title>
<style>
:root{{color-scheme:dark;--paper:#111815;--muted:#a9b9aa;--ink:#eee8d9;--rule:#314537;--gold:#d7c18d}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}}
main{{max-width:1410px;padding:40px clamp(18px,4vw,60px) 64px;margin:auto}}
h1{{font-size:clamp(30px,5vw,64px);line-height:1.15;margin:8px 0 18px;font-weight:650}}
h2{{font-size:28px;line-height:1.2;margin:0 0 20px}} h3{{font-size:19px;margin:24px 0 8px}}
header p{{max-width:900px}} .version,figcaption,small{{color:var(--muted)}} .numbers{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1px;background:var(--rule);border:1px solid var(--rule);margin:22px 0}}
.numbers div{{background:#17231c;padding:16px}} .numbers b{{display:block;font-size:clamp(22px,4vw,42px);color:var(--gold)}}
section{{margin-top:40px;border-top:1px solid var(--rule);padding-top:29px}} .compare{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}}
figure{{margin:0}} img,video{{width:100%;height:auto;display:block;border:1px solid var(--rule);background:#0b100c}}
figcaption{{font-size:13px;margin:6px 0 12px}} .scroll{{overflow:auto}} table{{width:100%;border-collapse:collapse;font-size:14px;text-align:left}}
th,td{{padding:8px 10px;border-bottom:1px solid var(--rule);white-space:nowrap}} thead{{background:#1c2a21}}
.latest{{background:#19241d}} .previous{{color:var(--muted)}} a{{color:#e1cf9e}}
ul{{padding-left:23px}} li{{margin-bottom:7px}} strong{{color:var(--gold)}} video{{max-width:1080px}}
@media(max-width:720px){{.compare,.numbers{{grid-template-columns:1fr}} th,td{{padding:7px}}}}
</style></head><body><main>
<header><div class="version">六边形战争 v28.53</div><h1>中土大军团与材质重制验收</h1>
<p>六章八开局默认加载扩军。普通步兵、弓手、骑兵和亡者每团显示 4 个成员，具名人物、巨兽与器械保留独立造型。佩兰诺维持 V6 的 54×35 格和 25 回合上限。</p>
<div class="numbers"><div><b>88</b>佩兰诺开局逻辑兵团</div><div><b>{pel['peakAliveTogether']}</b>固定种子实测同时在场</div><div><b>{sum(pel['committed'])}</b>该局累计入场</div></div></header>
<section><h2>佩兰诺会战实录</h2><video controls preload="none" src="{video}">请使用支持 H.264 的浏览器打开。</video>
<p>前段展示编组、批量移动和取消，随后切换观战并调用同一套游戏规则运行到终局。Chrome 这次实录到第 {terminal['turn']} 回合，实录峰值画面含 {peak['active']} 团在场与 {peak['people']} 个入镜的编队成员。</p>
<div class="compare">{image('new-combat','佩兰诺交战峰值采样机位')}{image('new-rohan','洛汗骑兵从北侧展开')}</div>
</section>
<section><h2>白城、地表与河道</h2>{gallery}
<p>白城外围沿用 V6 的正式城防判定，六道山侧退台加上外墙构成七层视觉轮廓。山顶新增白塔、城塞大厅、喷泉庭院与白树，中心山脊用连续石面造型。电影设计参考见 <a href="https://www.thewetamuseum.com/lotr/environments/lotrenviro_minast.html">Wētā 电影微缩模型资料</a>。</p>
<p>地表使用世界坐标混合草、裸土和岩面，路面边缘向草地过渡。水面采用同高的不透明连续表面，浅色过渡集中在真实岸边。外墙保留原有城门碰撞与崖坡规则。</p></section>
<section><h2>八个开局的实际投入</h2>
<p>均按友／敌列示。开局和峰值来自实跑的逻辑单位记录，累计按唯一 ID 去重。在场包含尚未撤离的溃逃单位，终局“存活”也包含溃逃单位，撤离另列。双方各自峰值可能出现在不同阶段。黑门只统计正面区，潜行仍按独立剧情结算。</p>
<div class="scroll"><table><thead><tr><th>开局</th><th>版本</th><th>初始</th><th>在场峰值</th><th>累计入场</th><th>余下后备</th><th>阵亡</th><th>溃逃</th><th>撤离</th><th>终局存活</th><th>结局</th></tr></thead><tbody>{rows}</tbody></table></div>
<p>固定种子复跑的佩兰诺在第 {pel['first']['coalition_attack']} 回合开始交战，第 {pel['events'].get('rohan',3)} 回合洛汗骑兵入场，第 {pel['events'].get('ships',7)} 回合南港登陆，共记录 {pel['actions']} 次攻击。巫王退场后战役继续至第 {pel['turn']} 回合。新旧均使用电脑指挥回放，结局仅代表该次战术选择。</p>
<p>海尔姆的守城和黎明反击已跑通，另有守军留守测试覆盖涵洞渗透与延时爆破。黑门直接决战完成毁戒，潜行序幕保留完整路线。佩拉基尔独立规则测试已验证活人接管两泊位、阿拉贡亲临及亡者离去；电脑对战该次未能完成胜局。孤山该次跑到既有时限。</p></section>
<section><h2>兵种差异与指挥官出场</h2>
<ul><li>刚铎王城卫队耐久 16.4，铁丘陵矮人 15.2。强兽人提高耐久、护甲和近战，精灵弓手远射命中提升至 89%。洛汗骑矛兵提高近战强度，冲锋仍走原有条件。</li>
<li>安格玛巫王耐久 31.0、护甲 6。格隆德耐久 44.0、护甲 7，并在攻击米纳斯提力斯大门时加重结构伤害。普通戒灵、猛犸、巨魔与比翁也有各自的单体数值。</li>
<li>伊欧温以冲击骑兵出场，完成巫王剧情击杀后转为步战。甘道夫在海尔姆黎明和黑门骑乘出场，黑门的阿拉贡以冲击骑兵出场。阿拉贡在海尔姆守城、佩拉基尔登陆时为步行。</li></ul>
</section>
<section><h2>操作与规则验证</h2>
<ul><li>框选、同类选择、预设战团与 Alt+1–5 自定组可直接使用。点地面分配区域阵位，点可见敌军集中攻击，或选择三格半径的攻击区域。</li>
<li>混合步、骑、弓批量移动测试验证路径、唯一落点、行动预算。集火测试中目标死亡后，后续单位保留未执行的行动点；死亡记录和击杀奖励各记一次。</li>
<li>有限援军使用固定 ID。满员后等待，剧情入场优先保留容量。存档恢复确认已入场 ID 不重复。旧版存档按原始队列载入。</li>
<li>模型显示只读正式战斗结果，切换阵列显示保持同一逻辑随机序列。中土章节沿用各自已启用的规则，士气和老兵机制在回归中验证。</li>
<li>相关回归共 {match.group(1)} 项通过。电脑回放和定向规则测试分别记录；定向测试只验证所描述的交互或胜负条件。</li></ul>
</section>
<section><h2>设备、响应与资源</h2>
<p>Apple M4，16 GB RAM，macOS 26.6.2。Chrome 以 1440×900 窗口运行，WebGL 设备为 {html.escape(peak['renderer'])}。原生 macOS 包已做启动与佩兰诺开局冒烟。Windows、Linux 归档完成结构与校验和验证。</p>
<ul><li>峰值交战片段采样 {frames['samples']} 帧，平均 {frames['mean']:.2f} ms，P95 {frames['p95']:.2f} ms，最大 {frames['max']:.2f} ms，超过 50 ms 共 {frames['slow']} 帧。该采样只覆盖当时机位与设备。</li>
<li>浏览器所测骑兵批量命令约 {browser['batch']['ms']} ms，包含界面刷新。固定种子佩兰诺 AI 半回合平均 {pel['aiMs']['mean']:.0f} ms，P95 {pel['aiMs']['p95']:.0f} ms，最大 {pel['aiMs']['max']:.0f} ms。</li>
<li>峰值采样的浏览器 JS 堆约 {peak['heapMB']:.1f} MiB，{peak['render']['calls']} 次绘制、{peak['textures']} 张在用纹理。13 张新贴图约 2.6 MiB 磁盘体积，按全量 RGBA8 含 mipmap 估算约 69 MiB 显存。</li>
<li>资源回收短测：{lifecycle}。长期游玩与其他设备的性能需分别复测。</li></ul></section>
<section><h2>本地素材与许可</h2>
<p>所有纹理随包从本地读取。颜色使用 sRGB，法线和粗糙度走线性数据通道。运行版 Three.js r186。</p>
<div class="scroll"><table><thead><tr><th>素材</th><th>来源</th><th>分辨率</th><th>通道</th><th>许可</th></tr></thead><tbody>{asset_rows}</tbody></table></div>
<p><a href="https://polyhaven.com/license">Poly Haven 许可</a> · <a href="https://docs.ambientcg.com/license/">ambientCG 许可</a></p>
</section>
</main></body></html>"""
output.write_text(docs, encoding='utf-8')
