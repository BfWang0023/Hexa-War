const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage({viewport:{width:1350,height:590}});
  await page.route('**/model-sheet.html',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><meta charset="utf-8"><body style="margin:0;background:#242721;color:#f0e8d4;font:16px system-ui;display:grid;grid-template-columns:repeat(6,1fr);gap:10px;padding:12px"></body>'}));
  await page.goto('http://127.0.0.1:8872/model-sheet.html');
  await page.evaluate(async()=>{
   const T=await import('/vendor/three/three.module.js');
   const {createFullModel}=await import('/ancient/full-models.mjs');
   const {ME_STATS}=await import('/ancient/middle-earth-data.mjs');
   const r=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
   r.setSize(208,224);
   for(const kind of ['meGuard','meRohan','meOrc','meUruk','meWarg','meElf','meDwarf','meNazgul','meDead','meShelob','meMumak','meFrodo']){
    const scene=new T.Scene();scene.background=new T.Color(0x3a3933);
    scene.add(new T.HemisphereLight(0xffeac8,0x6e6d79,2.0));
    const sun=new T.DirectionalLight(0xffe0b0,2.7);sun.position.set(6,8,4);scene.add(sun);
    const model=createFullModel({kind,team:'egypt'},'me_erebor',{});scene.add(model);
    const box=new T.Box3().setFromObject(model),size=box.getSize(new T.Vector3()),center=box.getCenter(new T.Vector3());
    const scale=Math.max(size.x,size.y,size.z)*.87;
    const camera=new T.OrthographicCamera(-scale,scale,scale*1.08,-scale*1.08,.1,100);
    camera.position.copy(center).add(new T.Vector3(7,4.4,7));camera.lookAt(center);r.render(scene,camera);
    const card=document.createElement('div'),img=document.createElement('img');
    img.src=r.domElement.toDataURL();img.alt=ME_STATS[kind].name;card.append(img,document.createElement('br'),ME_STATS[kind].name);document.body.append(card);
   }
   r.dispose();
  });
  await page.screenshot({path:'docs/middle-earth/models.png'});
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
