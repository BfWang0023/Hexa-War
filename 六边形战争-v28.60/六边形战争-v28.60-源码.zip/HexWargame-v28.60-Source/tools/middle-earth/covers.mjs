import {writeFileSync} from 'node:fs';
import {MIDDLE_EARTH,isMorannon,morannonWindows} from '../../web3d/ancient/middle-earth-data.mjs';
import {makeMiddleEarthMap} from '../../web3d/ancient/middle-earth-maps.mjs';
import {TERRAIN} from '../../web3d/ancient/engine.mjs';

for(const entry of MIDDLE_EARTH){
  const m=makeMiddleEarthMap(entry.id), cells=[];
  const [first,last]=isMorannon(entry.id)?morannonWindows(m)[entry.id.endsWith('final')?'front':'pass']:[0,m.cols];
  const width=720,height=230,dx=width/(last-first+.5),dy=height/m.rows;
  const xAt=(c,r)=>(c-first+.5+(r%2)*.5)*dx;
  const stride=Math.ceil(Math.max(last-first,m.rows)/82);
  for(let r=0;r<m.rows;r+=stride)for(let c=first;c<last;c+=stride){
    const t=m.terrain[r*m.cols+c],x=xAt(c,r),y=(r+.5)*dy;
    const h=Math.max(0,Math.min(9,m.elevations[r*m.cols+c]));
    const color=t&(TERRAIN.SEA|TERRAIN.RIVER)?'#40616c':t&TERRAIN.ROAD?'#b8a174':t&TERRAIN.MOUNTAIN?
      `rgb(${Math.round(91+7*h)},${Math.round(81+6*h)},${Math.round(74+5*h)})`:(c+r)%3?'#596151':'#515c4d';
    const ring=stride>1?[[x-dx*.5,y-dy*.5],[x+dx*(stride-.5),y-dy*.5],
      [x+dx*(stride-.5),y+dy*(stride-.5)],[x-dx*.5,y+dy*(stride-.5)]]:
      [[x-dx*.52,y],[x-dx*.26,y-dy*.54],[x+dx*.26,y-dy*.54],[x+dx*.52,y],[x+dx*.26,y+dy*.54],[x-dx*.26,y+dy*.54]];
    cells.push(`<polygon points="${ring.map(([a,b])=>a.toFixed(1)+','+b.toFixed(1)).join(' ')}" fill="${color}" stroke="#212a24" stroke-opacity=".22"/>`);
  }
  const features=m.units.filter(u=>u.c>=first&&u.c<last&&(u.kind==='fort'||u.kind==='meBlackShip')).map(u=>
    `<rect x="${xAt(u.c,u.r)-dx*.24}" y="${(u.r+.24)*dy}" width="${dx*.48}" height="${dy*.52}" rx="1.4" fill="${u.kind==='fort'?'#d0bd99':'#241f27'}"/>`);
  const labels=m.landmarks.filter(p=>p.c>=first&&p.c<last).slice(0,6).map(({c,r,label})=>
    `<text x="${Math.min(width-135,xAt(c,r)+dx*.12)}" y="${(r+.4)*dy}" fill="#fff3d2" font-size="12" stroke="#302b25" stroke-width="2" paint-order="stroke">${label}</text>`);
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="#293229"/>${cells.join('')}${features.join('')}${labels.join('')}</svg>`;
  writeFileSync(new URL(`../../web3d/ancient/assets/campaign-covers/${entry.id}.svg`,import.meta.url),svg);
}
