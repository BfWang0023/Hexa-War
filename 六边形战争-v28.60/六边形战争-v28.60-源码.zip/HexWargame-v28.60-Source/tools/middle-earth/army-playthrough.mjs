import * as E from '../../web3d/ancient/engine.mjs';
import {makeMiddleEarthMap} from '../../web3d/ancient/middle-earth-maps.mjs';
import {MIDDLE_EARTH, isMorannon} from '../../web3d/ancient/middle-earth-data.mjs';
import {frontUnit} from '../../web3d/ancient/middle-earth-armies.mjs';
import {createSave,restoreSave} from '../../web3d/ancient/save.mjs';
import assert from 'node:assert/strict';

const sides=['egypt','coalition'];
const initialCounts=m=>sides.map(team=>m.units.filter(u=>frontUnit(m,u)&&u.team===team).length);
const stats=(s,team,ids)=>Object.fromEntries(['alive','active','dead','routed','withdrawn'].map(k=>[k,s.map.units.filter(u=>ids.get(u.id)===team&&(
  k==='dead'?u.hp<=0:k==='routed'?u.hp>0&&!u.escaped&&E.isRouted(u):k==='withdrawn'?!!u.escaped:
    k==='alive'?u.hp>0&&!u.escaped:u.hp>0&&!u.escaped&&!E.isRouted(u))).length]));
const p95=times=>times.sort((a,b)=>a-b)[Math.ceil(times.length*.95)-1];
for(const id of MIDDLE_EARTH.map(x=>x.id).filter(id=>!process.argv[2]||id===process.argv[2])){
  for(const largeArmies of process.env.HEX_BASELINE==='1'?[false]:[true]){
    const map=makeMiddleEarthMap(id,{largeArmies});
    const seeds={me_isen_second:5,me_morannon_final:35};
    const s=E.startGame(map,{middleEarthSeed:seeds[id]||17,mutinySeed:17});
    const initial=initialCounts(s.map), all=new Map(), peak=[0,0], peakAlive=[0,0],both=[], bothAlive=[];
    const turns=[], times=[],first={};
    let restored=false;
    const observe=()=>{
      for(const u of s.map.units)if(frontUnit(s.map,u)&&!all.has(u.id))all.set(u.id,u.team);
      const summary=sides.map(team=>stats(s,team,all));
      summary.forEach((side,i)=>{peak[i]=Math.max(peak[i],side.active);peakAlive[i]=Math.max(peakAlive[i],side.alive);});
      bothAlive.push(summary.reduce((n,v)=>n+v.alive,0));
      both.push(summary.reduce((n,v)=>n+v.active,0));
      if(largeArmies){
        assert.equal(new Set(s.map.units.map(u=>u.id)).size,s.map.units.length);
        assert.ok(summary.every((v,i)=>v.alive<=map.victory.army.peak[i]));
      }
    };
    observe();
    for(let i=0;i<2*(map.victory.turnLimit+2)&&!s.over;i++){
      const t=performance.now(),turn=s.turn,team=s.side;
      const actions=E.aiTurn(s);
      times.push(performance.now()-t);
      for(const a of actions){first[team+'_'+a.type]??=turn;if(a.type==='attack'&&a.hit)first[team+'_hit']??=turn;}
      turns.push({turn,team,moves:actions.filter(a=>a.type==='move').length,attacks:actions.filter(a=>a.type==='attack').length});
      observe();
      if(largeArmies&&!restored&&Object.values(s.middleEarth.army.reserve).some(slots=>slots.some(v=>v.entered!==null))){
        const save=createSave(map,s,'egypt');
        const roundtrip=restoreSave(JSON.parse(JSON.stringify(save))).game;
        assert.deepEqual(roundtrip.middleEarth.army,s.middleEarth.army);
        assert.deepEqual(roundtrip.map.units.map(u=>u.id),s.map.units.map(u=>u.id));
        restored=true;
      }
    }
    const committed=sides.map(t=>[...all.values()].filter(team=>team===t).length);
    const reserve=largeArmies?sides.map(team=>map.victory.waves.filter(w=>w.team===team)
      .reduce((n,w)=>n+s.middleEarth.army.reserve[w.key].filter(v=>v.entered===null).length,0)):null;
    const planned=map.victory.waves.reduce((out,w)=>(out[sides.indexOf(w.team)]+=w.rows.length,out),[...initial]);
    if(largeArmies)assert.deepEqual(committed.map((n,i)=>n+reserve[i]),planned);
    assert.ok(s.over);
    console.log(JSON.stringify({id,largeArmies,initial,peak,peakAlive,peakTogether:Math.max(...both),peakAliveTogether:Math.max(...bothAlive),committed,planned,reserve,
      final:sides.map(team=>stats(s,team,all)),turn:s.turn,winner:s.winner,reason:s.victoryReason,first,restored,
      events:Object.fromEntries(Object.entries(s.middleEarth.events).map(([k,v])=>[k,v.turn])),
      actions:turns.reduce((n,v)=>n+v.attacks,0),idle:turns.filter(v=>!v.moves&&!v.attacks).length,
      aiMs:{mean:times.reduce((n,x)=>n+x,0)/times.length,p95:p95(times),max:Math.max(...times)},turns,logistics:!!map.logistics}));
  }
}
