const {chromium}=require(process.env.HEX_PLAYWRIGHT||'/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {mkdir,writeFile,rename}=require('node:fs/promises');
const assert=require('node:assert/strict');
const out=process.env.HEX_QA_DIR||'docs/middle-earth-army', viewport={width:1440,height:900};
const hook=`
window.armyQA={
 info(){const u=game.map.units.filter(u=>u.hp>0&&!u.escaped&&u.kind!=='fort');return {turn:game.turn,side:game.side,over:game.over,
   active:u.length,shown:liveUnits().length,people:typeof armyFormations==='undefined'?null:armyFormations.visibleMen,
   render:{...renderer.info.render},textures:renderer.info.memory.textures,geometries:renderer.info.memory.geometries,
   heapMB:performance.memory?.usedJSHeapSize/1048576,events:{...game.middleEarth.events},
   hint:document.querySelector('#hint').textContent,chosen:[...groupIds],ap:u.filter(v=>groupIds.has(v.id)).map(v=>v.actionsLeft),
   renderer:renderer.getContext().getParameter(renderer.getContext().getExtension('WEBGL_debug_renderer_info')?.UNMASKED_RENDERER_WEBGL||7937)};},
 focus(c,r,d,yaw=-.17,pitch=.97){const p=offsetToWorld(c,r);target.set(p.x,terrainObj.sample(p.x,p.z),p.z);boardView=false;cameraDistance=d;cameraYaw=yaw;cameraPitch=pitch;updateCamera();},
 all(){battleMode='ai-ai';refresh();},
 action(c,r){clickCell(c,r);},
 project(c,r){const v=offsetToWorld(c,r),p=new THREE.Vector3(v.x,terrainObj.sample(v.x,v.z),v.z).project(camera),b=stage.getBoundingClientRect();return {x:b.left+(p.x+1)*b.width/2,y:b.top+(1-p.y)*b.height/2};},
 async round(){const t=performance.now(),actions=aiTurn(game);runArmyQaAnimations(actions);refresh();return {ms:performance.now()-t,actions:actions.length,attacks:actions.filter(a=>a.type==='attack').length};},
 restart(){startForPlayer();autoRunning=false;cancelAutoTurn();selectedId=null;refresh();},
 cycle(id){scenario=makeScenario(id);startForPlayer();autoRunning=false;cancelAutoTurn();selectedId=null;refresh();},
 reload(){const snapshot=JSON.parse(JSON.stringify(createSave(scenario,game,playerTeam)));const restored=restoreSave(snapshot);game=restored.game;scenario=restored.scenario;selectedId=null;unitAnimator.clear();combatFx.clear();refresh();},
 select(c,r,extend){clickCell(c,r,extend);},
 title(text){let tag=document.getElementById('army-qa-title');if(!tag){tag=document.createElement('div');tag.id='army-qa-title';stage.append(tag);tag.style.cssText='position:absolute;z-index:45;bottom:14px;left:50%;transform:translateX(-50%);padding:9px 16px;background:#172221e8;color:#faf1d3;font:600 16px system-ui;pointer-events:none;white-space:nowrap';}tag.textContent=text;tag.hidden=!text;},
};
function runArmyQaAnimations(actions){
 unitAnimator.actions(actions,performance.now(),game.map,()=>true);
}
`;
async function open(browser,url,id,record){
 const context=await browser.newContext({viewport,...record&&{recordVideo:{dir:out,size:viewport}}});
 const page=await context.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.stack||e.message));
 page.on('console',m=>{if(/Shader Error|WebGLProgram.*Error|CONTEXT_LOST/.test(m.text()))errors.push(m.text());});
 page.on('requestfailed',r=>{if(r.url().endsWith('.jpg'))errors.push(r.url()+': '+r.failure()?.errorText);});
 await page.route('**/api/ancient/maps/*',r=>r.fulfill({status:404}));
 await page.route('**/ancient/app.mjs',async route=>{
   const res=await route.fetch();await route.fulfill({response:res,body:await res.text()+hook});
 });
 await page.goto(url+'/ancient/');
 await page.getByRole('button',{name:'战役选择',exact:true}).click();
 await page.getByRole('button',{name:/中土战役 · 六个独立章节/}).click();
 await page.locator(`[data-scenario="${id}"] > button`).click();
 if(id.startsWith('me_morannon')) {
   const open=page.getByRole('button',{name:'进入战役',exact:true});
   if(!await open.isVisible())await page.getByRole('button',{name:/直接决战/}).first().click();
 }
 await page.getByRole('button',{name:'进入战役',exact:true}).click();
 await page.waitForFunction(()=>document.body.dataset.page==='Battle'&&window.armyQA);
 return {context,page,errors};
}
const shot=(p,n)=>p.screenshot({path:`${out}/${n}.jpg`,type:'jpeg',quality:90});
const info=p=>p.evaluate(()=>armyQA.info());
const frames=p=>p.evaluate(()=>new Promise(resolve=>{
 const dt=[];let last,started=performance.now();
 function tick(t){if(last)dt.push(t-last);last=t;
  if(dt.length<42&&performance.now()-started<12000)requestAnimationFrame(tick);
  else {const sort=[...dt].sort((a,b)=>a-b),mean=dt.reduce((n,v)=>n+v,0)/dt.length;
    resolve({mean,p95:sort[Math.floor((sort.length-1)*.95)],max:sort.at(-1),slow:dt.filter(x=>x>50).length,samples:dt.length,fps:1000/mean});}}
 requestAnimationFrame(tick);
}));
(async()=>{
 await mkdir(out,{recursive:true});
 const browser=await chromium.launch({headless:true,executablePath:process.env.HEX_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--enable-precise-memory-info']});
 const base=process.env.HEX_V6_URL||'http://127.0.0.1:8922',next=process.env.HEX_URL||'http://127.0.0.1:8923',evidence={};
 const scenes={city:[8,27,163,-.38,.68],gate:[14,27,105,-.2],field:[25,23,134,-.14],river:[42,31,155,.28]};
 try{
   for(const [url,ver] of [[base,'old'],[next,'new']]){
     const {context,page,errors}=await open(browser,url,'me_pelennor',ver==='new');
     const video=page.video(),ev=evidence[ver]={errors,scenes:{},rounds:[]};
     ev.default=await info(page);
     if(ver==='new'){
       assert.equal(ev.default.active,88);
       await page.evaluate(()=>armyQA.focus(18,23,180,-.12));
       await page.locator('#army-group').selectOption('骑兵预备');
       const selected=await info(page);assert.ok(selected.chosen.length>1);
       await page.keyboard.press('Alt+Digit1');
       await page.evaluate(()=>armyQA.title('佩兰诺 · 骑兵预备队批量行军'));
       let t=Date.now();
       await page.evaluate(()=>armyQA.action(22,19));
       ev.batch={ms:Date.now()-t,...await info(page)};
       assert.match(ev.batch.hint,/批量命令/);
       await page.locator('#army-area').click();
       await page.locator('#army-stop').click();
       ev.stop=(await info(page)).hint;
       assert.match(ev.stop,/已取消/);
       await page.keyboard.press('Digit1');
       assert.ok((await info(page)).chosen.length>1);
       await page.locator('#group-cancel').click();
       await page.evaluate(()=>armyQA.title(''));
     }
     await page.evaluate(()=>armyQA.all());
     for(const [name,pose] of Object.entries(scenes)){
       await page.evaluate(pose=>armyQA.focus(...pose),pose);
       await page.waitForTimeout(700);
       await shot(page,`${ver}-${name}`);
       ev.scenes[name]=await info(page);
     }
     if(ver==='new'){
       await page.evaluate(()=>{armyQA.focus(25,23,184,-.14);armyQA.title('佩兰诺 · 围城、两翼与有限增援');});
       for(let i=0;i<54;i++){
         const s=await info(page);
         if(s.over)break;
         const turn=await page.evaluate(()=>armyQA.round());
         const after=await info(page);ev.rounds.push({...turn,turn:after.turn,active:after.active});
         if(turn.attacks>1&&i<9){
           await page.waitForTimeout(320);
           if(!ev.combat||after.active>ev.combat.active){
             ev.combat=after;await shot(page,'new-combat');
             ev.combatFrames=await frames(page);
           }
         }
         if(after.events.rohan&&!ev.rohan){
           ev.rohan=after;
           await page.evaluate(()=>armyQA.focus(21,13,140,-.10));
           await page.waitForTimeout(550);await shot(page,'new-rohan');
           await page.evaluate(()=>armyQA.focus(24,23,184,-.14));
         }
       }
       ev.terminal=await info(page);assert.ok(ev.terminal.over);
       await page.evaluate(()=>{armyQA.title('');armyQA.restart();armyQA.focus(25,23,184,-.14);});
       await page.waitForTimeout(400);ev.restart=await info(page);
       await page.evaluate(()=>armyQA.reload());
       await page.waitForTimeout(400);ev.reload=await info(page);
       assert.equal(ev.restart.active,88);assert.equal(ev.reload.active,88);
       await page.evaluate(()=>{armyQA.cycle('me_hornburg');armyQA.focus(27,16,184,-.14);});
       await page.waitForTimeout(400);ev.hornburg=await info(page);
       assert.equal(ev.hornburg.active,50);
       await page.evaluate(()=>{armyQA.cycle('me_pelennor');armyQA.focus(25,23,184,-.14);});
       await page.waitForTimeout(400);ev.return=await info(page);
       assert.equal(ev.return.active,88);
     }
     await writeFile(`${out}/browser.json`,JSON.stringify(evidence,null,2));
     assert.deepEqual(errors,[]);
     await context.close();
     if(video)await rename(await video.path(),`${out}/佩兰诺大军团会战实录.webm`);
   }
 } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
