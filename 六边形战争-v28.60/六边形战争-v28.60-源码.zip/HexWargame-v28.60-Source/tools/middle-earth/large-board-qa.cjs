const {chromium}=require(process.env.HEX_PLAYWRIGHT||'/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {mkdir,writeFile}=require('node:fs/promises');
const assert=require('node:assert/strict');
const out=process.env.HEX_QA_DIR||'docs/middle-earth-large';
const url=process.env.HEX_URL||'http://127.0.0.1:8881';
const version=Number(process.env.HEX_LAYOUT||5);
const scenarios=['me_isen_first','me_isen_second','me_hornburg','me_pelennor','me_erebor','me_pelargir','me_morannon','me_morannon_final'];

const inspectCode=`
window.largeBoardQA={
  inspect(){
    const m=game.map;
    const range=isMorannon(m.scenarioId)?morannonWindows(m)[game.middleEarth.view]:[0,m.cols];
    const chunks=[...terrainObj.chunks.values()];
    const boundsOK=chunks.every(({region})=>region.c0>=range[0]&&region.c1<=range[1]);
    return {cols:m.cols,rows:m.rows,range,turn:game.turn,layout:m.victory.layoutVersion,
      actions:m.units.map(u=>[u.id,u.actionsLeft]),view:game.middleEarth.view,
      camera:cameraDistance,focus:target.toArray(),chunks:chunks.length,boundsOK,
      render:{...renderer.info.render},heapMB:performance.memory?.usedJSHeapSize/1048576};
  }
};
`;

(async()=>{
  await mkdir(out,{recursive:true});
  const browser=await chromium.launch({headless:true,executablePath:process.env.HEX_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args:['--enable-precise-memory-info']});
  const rows=[],errors=[];
  try{
    for(const id of scenarios){
      const page=await browser.newPage({viewport:{width:1440,height:960}});
      const cdp=await page.context().newCDPSession(page);
      page.on('pageerror',e=>errors.push(e.message));
      page.on('console',m=>{if(/Shader Error|WebGLProgram.*Error|CONTEXT_LOST/.test(m.text()))errors.push(m.text());});
      await page.route('**/api/ancient/maps/*',route=>route.fulfill({status:404}));
      await page.route('**/ancient/app.mjs',async route=>{
        const res=await route.fetch();
        await route.fulfill({response:res,body:await res.text()+inspectCode});
      });
      await page.goto(url+'/ancient/');
      await page.getByRole('button',{name:'战役选择',exact:true}).click();
      await page.getByRole('button',{name:/中土战役 · 六个独立章节/}).click();
      await page.locator(`[data-scenario="${id}"] > button`).click();
      const enter=Date.now();
      await page.getByRole('button',{name:'进入战役',exact:true}).click();
      await page.waitForFunction(()=>document.body.dataset.page==='Battle'&&window.largeBoardQA);
      await page.getByRole('button',{name:'战场全景',exact:true}).waitFor();
      const startMs=Date.now()-enter;
      // Measure once the terrain and GPU pipelines have drawn a few frames.
      await page.evaluate(()=>new Promise(resolve=>{
        let left=12;
        const draw=()=>--left?requestAnimationFrame(draw):resolve();
        requestAnimationFrame(draw);
      }));
      const initial=await page.evaluate(()=>largeBoardQA.inspect());
      assert.equal(initial.layout,version);
      const minimum=version===6?25:version===5?100:200;
      assert.ok(initial.range[1]-initial.range[0]>=minimum&&initial.rows>=minimum&&initial.boundsOK);
      const frame=await page.evaluate(()=>new Promise(resolve=>{
        const a=[];let prev;
        const tick=t=>{if(prev!==undefined)a.push(t-prev);prev=t;
          if(a.length<48)requestAnimationFrame(tick);
          else{a.sort((a,b)=>a-b);resolve({p50:a[23],p95:a[45]});}
        };
        requestAnimationFrame(tick);
      }));
      await page.getByRole('button',{name:'战场全景',exact:true}).click();
      await page.getByRole('button',{name:'返回指挥视角',exact:true}).waitFor();
      const panorama=await page.evaluate(()=>largeBoardQA.inspect());
      assert.ok(panorama.camera>=minimum*10);
      await page.screenshot({path:`${out}/${id}.jpg`,type:'jpeg',quality:86});
      await page.getByRole('button',{name:'返回指挥视角',exact:true}).click();
      const returned=await page.evaluate(()=>largeBoardQA.inspect());
      assert.deepEqual(returned.focus,initial.focus);
      assert.equal(returned.camera,initial.camera);
      if(id==='me_morannon_final'){
        await page.getByRole('button',{name:'末日山',exact:true}).click();
        await page.waitForFunction(()=>{const v=largeBoardQA.inspect();return v.view==='doom'&&v.boundsOK;});
        const doom=await page.evaluate(()=>largeBoardQA.inspect());
        assert.equal(doom.view,'doom');
        assert.equal(doom.turn,initial.turn);
        assert.deepEqual(doom.actions,initial.actions);
        assert.ok(doom.boundsOK);
        await page.getByRole('button',{name:'战场全景',exact:true}).click();
        await page.screenshot({path:`${out}/me_morannon-doom.jpg`,type:'jpeg',quality:86});
        await page.getByRole('button',{name:'返回指挥视角',exact:true}).click();
        await page.getByRole('button',{name:'黑门正面',exact:true}).click();
      }
      const turn=Date.now();
      await page.locator('#end-turn').click();
      await page.waitForFunction(()=>largeBoardQA.inspect().turn===2);
      const turnMs=Date.now()-turn;
      await cdp.send('HeapProfiler.collectGarbage');
      const after=await page.evaluate(()=>largeBoardQA.inspect());
      rows.push({id,initial,panorama,after,frame,startMs,turnMs});
      console.log(id,startMs,turnMs,Math.round(after.heapMB),frame.p95.toFixed(1));
      await page.close();
    }
    assert.deepEqual(errors,[]);
  }finally{
    await writeFile(`${out}/browser.json`,JSON.stringify({rows,errors},null,2));
    await browser.close();
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
