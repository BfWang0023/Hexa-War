const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
  const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage({viewport:{width:1440,height:960}});
  const rows=[],errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(/THREE.*Shader Error|WebGLProgram.*Error/i.test(m.text()))errors.push(m.text());});
  page.on('dialog',d=>d.accept());
  await page.route('**/api/ancient/maps/*',async route=>{
    const id=new URL(route.request().url()).pathname.split('/').at(-1),p=`web3d/ancient/bundled-maps/${id}.json`;
    return fs.existsSync(p)?route.fulfill({path:p,contentType:'application/json'}):route.fulfill({status:404});
  });
  await page.route('**/ancient/app.mjs',async route=>{
    const res=await route.fetch();
    await route.fulfill({response:res,body:await res.text()+`
    window.__meQa={zoneReady(){const w=MORANNON_WINDOWS[game.middleEarth.view];return [...terrainObj.chunks.values()].length>0&&[...terrainObj.chunks.values()].every(x=>x.region.c0>=w[0]&&x.region.c1<=w[1]);},gate(){const g=game.map.units.find(u=>u.gate&&u.cityId==='黑门');const p=offsetToWorld(g.c,g.r);target.set(p.x,0,p.z);cameraDistance=62;cameraPitch=.85;updateCamera();refresh();}};
    `});
  });
  try{
    for(const id of ['me_isen_first','me_isen_second','me_hornburg','me_pelennor','me_erebor','me_pelargir','me_morannon','me_morannon_final']){
      await page.goto('http://127.0.0.1:8872/ancient/');
      await page.getByRole('button',{name:'战役选择',exact:true}).click();
      await page.getByRole('button',{name:/中土战役 · 六个独立章节/}).click();
      assert.equal(await page.locator('[data-scenario]').count(),8);
      await page.locator(`[data-scenario="${id}"] > button`).click();
      await page.getByRole('button',{name:'进入战役',exact:true}).click();
      await page.waitForFunction(()=>document.body.dataset.page==='Battle');
      await page.locator('#middle-earth-panel').waitFor();
      const title=await page.locator('#middle-earth-panel').innerText();
      await page.screenshot({path:`docs/middle-earth/${id}.png`});
      const medianFrameMs=await page.evaluate(()=>new Promise(resolve=>{
        const frames=[];let prior=performance.now();
        const sample=t=>{frames.push(t-prior);prior=t;if(frames.length===24)resolve(frames.sort((a,b)=>a-b)[12]);else requestAnimationFrame(sample);};
        requestAnimationFrame(sample);
      }));
      await page.locator('#board-view').click();
      await page.screenshot({path:`docs/middle-earth/${id}-board.png`});
      if(id==='me_morannon_final'){
        await page.locator('#board-view').click();
        await page.evaluate(()=>__meQa.gate());
        await page.screenshot({path:'docs/middle-earth/black-gate.png'});
        await page.getByRole('button',{name:'末日山',exact:true}).click();
        assert.match(await page.locator('#middle-earth-panel').innerText(),/谨慎潜行/);
        assert.match(await page.locator('#middle-earth-panel').innerText(),/第 1 \/ 28 回合/);
        await page.waitForFunction(()=>__meQa.zoneReady());
        await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
        await page.screenshot({path:'docs/middle-earth/me_morannon_doom.png'});
      }
      const start=Date.now();
      await page.locator('#end-turn').click();
      await page.waitForFunction(()=>document.querySelector('#middle-earth-panel').textContent.includes('第 2 /'));
      rows.push({id,title,medianFrameMs,endTurnUiMs:Date.now()-start});
    }
    assert.deepEqual(errors,[]);
  } finally{
    fs.writeFileSync('docs/middle-earth/browser.json',JSON.stringify({rows,errors},null,2));
    await browser.close();
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
