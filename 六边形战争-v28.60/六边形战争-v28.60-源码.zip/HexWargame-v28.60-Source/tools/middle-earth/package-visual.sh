#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."

source_release=${1:?请指定基础安装包目录}
output=${2:?请指定输出目录}
base_version=${3:-v28.47}
release_version=${4:-v28.48}
bundle_version=${release_version#v}
build_number=$(printf '%s' "$bundle_version" | tr -d '.')
mkdir -p "$output"
output=$(cd "$output" && pwd)
source_release=$(cd "$source_release" && pwd)
work=$(mktemp -d "${TMPDIR:-/tmp}/middle-earth-release.XXXXXX")
trap 'rm -rf "$work"' EXIT HUP INT TERM

bundle="$work/mac"
mkdir "$bundle"
ditto -xk "$source_release/六边形战争-$base_version-macOS.zip" "$bundle"
app="$bundle/古代战役.app"
codesign --verify --deep --strict "$app"
rm -rf "$app/Contents/Resources/web3d"
cp -RX web3d "$app/Contents/Resources/web3d"
find "$app" -name '.DS_Store' -delete
xattr -cr "$app"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $bundle_version" "$app/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $build_number" "$app/Contents/Info.plist"
codesign --force --deep --sign - "$app"
codesign --verify --deep --strict "$app"
ditto -c -k --norsrc --noextattr --keepParent "$app" "$work/六边形战争-$release_version-macOS.zip"

for platform in Windows-x64 Linux-x64 Linux-ARM64; do
    old="HexWargame-$base_version-$platform"
    new="HexWargame-$release_version-$platform"
    case "$platform" in
        Windows*) unzip -q "$source_release/$old.zip" -d "$work"; ext=zip ;;
        Linux*) tar -xzf "$source_release/$old.tar.gz" -C "$work"; ext=tar.gz ;;
    esac
    mv "$work/$old" "$work/$new"
    rm -rf "$work/$new/web3d"
    cp -RX web3d "$work/$new/web3d"
    find "$work/$new" -name '.DS_Store' -delete
    sed -i '' "s/$base_version/$release_version/g" "$work/$new/README.txt"
    if [ "$ext" = zip ]; then
        (cd "$work" && zip -qr "$new.zip" "$new")
    else
        COPYFILE_DISABLE=1 tar -czf "$work/$new.tar.gz" -C "$work" "$new"
    fi
done

for archive in "$work"/*.zip "$work"/*.tar.gz; do
    mv "$archive" "$output/"
done
(
    cd "$output"
    shasum -a 256 六边形战争-$release_version-macOS.zip HexWargame-$release_version-Windows-x64.zip \
        HexWargame-$release_version-Linux-x64.tar.gz HexWargame-$release_version-Linux-ARM64.tar.gz > SHA256SUMS.txt
    shasum -a 256 -c SHA256SUMS.txt
)
