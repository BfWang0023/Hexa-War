from pathlib import Path
import difflib, json, hashlib
docs=Path('docs/middle-earth')
patch={}
for p in (docs/'before').glob('*.mjs'):
    old=p.read_text().splitlines(keepends=True)
    new=Path('web3d/ancient',p.name).read_text().splitlines(keepends=True)
    edits=[]
    for op,a,b,c,d in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
        if op!='equal':
            edits.append(dict(at=len(''.join(new[:c]).encode('utf-16-le'))//2,
                              removed=''.join(old[a:b]),added=''.join(new[c:d])))
    if edits: patch[p.name]=edits
(docs/'authorized.json').write_text(json.dumps(patch,ensure_ascii=False,indent=2)+'\n')
p=Path('tools/interaction-v19/integrity.mjs')
s=p.read_text()
if 'authorized Middle-earth' not in s:
    marker='export function beforeInteraction(name,text){'
    s=s.replace(marker,marker+"""
const middleEarth=JSON.parse(fs.readFileSync(new URL('../../docs/middle-earth/authorized.json',import.meta.url)))[name];
if(middleEarth)for(const e of [...middleEarth].reverse()){
  assert.equal(text.slice(e.at,e.at+e.added.length),e.added,'authorized Middle-earth patch');
  text=text.slice(0,e.at)+e.removed+text.slice(e.at+e.added.length);
}
""")
    p.write_text(s)
p=Path('docs/interaction-v19/authorized-core.json')
core=json.loads(p.read_text())
for name in ('engine.mjs','save.mjs'):
    key='web3d/ancient/'+name
    core[key]=hashlib.sha256(Path(key).read_bytes()).hexdigest()
p.write_text(json.dumps(core,indent=2))
