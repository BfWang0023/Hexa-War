import * as E from '../../web3d/ancient/engine.mjs';
import {MIDDLE_EARTH,morannonWindows} from '../../web3d/ancient/middle-earth-data.mjs';
import {makeMiddleEarthMap} from '../../web3d/ancient/middle-earth-maps.mjs';
import {groundConnection} from '../../web3d/ancient/cliff-navigation.mjs';
import {setStealth} from '../../web3d/ancient/middle-earth-rules.mjs';

const routes={
  me_isen_first:[['meRohanFoot','exit',1],['meRiderLord','ford',0]],
  me_isen_second:[['meRohanFoot','exit',1],['meRiderLord','ford',1]],
  me_hornburg:[['meAragorn','gate',0],['meAragorn','sally',0],['meAragorn','culvert',0],['meAragorn','counter',0],['meRohanFoot','cave',0],['meBlast','blast',1],['meRiderLord','counter',0,'dawn']],
  me_erebor:[['meThorin','counter',0],['meElf','counter',0],['meBolg','counter',0]],
  me_pelennor:[['meGrond','gate',1],['meGondorHorse','counter',0],['meGondor','gate',0]],
  me_pelargir:[['meAragorn','core',1],['meGondor','dock0',1],['meGondor','dock2',1]],
  me_morannon:[['meFrodo','pass',0]],
  me_morannon_final:[['meFrodo','crack',0],['meAragorn','front',0]]
};

function march(map,kind,key,radius,wave){
  const state=E.startGame(map,{fogPolicy:{unitFog:false,terrainFog:false}});
  const p=map.victory.points[key]??(key==='gate'?map.units.find(u=>u.kind==='fort'&&u.gate&&E.distance(u,map.victory.points.sally)>1):null);
  let u=state.map.units.find(u=>u.kind===kind);
  if(wave){
    const w=state.map.victory.waves.find(w=>w.key===wave),[k,c,r]=w.rows[0];
    kind=k;
    if(!E.mobileAt(state.map,c,r)&&E.addUnit(state.map,k,w.team,c,r))u=state.map.units.at(-1);
  }
  if(!p||!u)return {kind,key,wave,unreachable:true};
  state.side=u.team;
  // Measure the route on intact terrain and defenses, with other formations off the route.
  state.map.units=state.map.units.filter(x=>x===u||x.kind==='fort');
  const origin={c:u.c,r:u.r};
  if(key==='crack')setStealth(state,'careful');
  const start=E.isFord(state.map,u.c,u.r)?1:0;
  const queue=[{...origin,time:start,ap:0,cells:0}],visited=new Map([[E.key(u.c,u.r),start]]);
  while(queue.length){
    queue.sort((a,b)=>b.time-a.time);
    const node=queue.pop(),k=E.key(node.c,node.r);
    if(visited.get(k)!==node.time)continue;
    if(E.distance(node,p)<=radius)return {kind,key,wave,radius,origin,goal:{c:p.c,r:p.r},ap:node.ap,turns:node.ap?Math.ceil(node.arrival/2):0,arrivesWithAP:node.ap===0||node.time%2===1&&!E.isFord(state.map,node.c,node.r),cells:node.cells};
    Object.assign(u,{c:node.c,r:node.r,actionsLeft:1});
    for(const d of E.reachable(state,u).values()){
      const k=E.key(d.c,d.r);
      const inWater=E.isFord(state.map,u.c,u.r),outWater=E.isFord(state.map,d.c,d.r);
      const arrival=node.time+d.actionCost;
      const time=inWater||outWater?Math.ceil(arrival/2)*2+(outWater?1:0):arrival;
      if((visited.get(k)??Infinity)<=time)continue;
      visited.set(k,time);
      queue.push({...d,time,arrival,ap:node.ap+d.actionCost,cells:node.cells+d.path.length});
    }
  }
  return {kind,key,wave,radius,origin,goal:{c:p.c,r:p.r},unreachable:true};
}

function audit(id,layoutVersion){
  const map=makeMiddleEarthMap(id,{layoutVersion});
  const zones=id.startsWith('me_morannon')?morannonWindows(map):{battle:[0,map.cols]};
  const s=E.startGame(map,{fogPolicy:{unitFog:false,terrainFog:false}});
  const m=s.map,forts=new Map(m.units.filter(u=>u.kind==='fort').map(f=>[E.key(f.c,f.r),f]));
  const areas=Object.fromEntries(Object.entries(zones).map(([name,[start,end]])=>{
    s.middleEarth.phase=name==='pass'?'prologue':name==='battle'?'battle':'final';
    const units=['meRohanFoot','meRohan'].map(kind=>{
      const u={kind,team:'egypt',c:start,r:0,actionsLeft:2};
      const passable=new Map(),seen=new Set(),components=[];
      const anchors=Object.values(m.victory.points).filter(p=>p.c>=start&&p.c<end);
      for(let r=0;r<m.rows;r++)for(let c=start;c<end;c++){
        const p={c,r},k=E.key(c,r);
        // With the probe on the cell, test standing/terrain independently of an incoming edge.
        u.c=c;u.r=r;
        if(E.moveCost(s,u,c,r)<Infinity&&E.canPassFort(u,forts.get(k)))passable.set(k,p);
      }
      for(const [k,origin] of passable){
        if(seen.has(k))continue;
        const queue=[origin];
        seen.add(k);
        for(let i=0;i<queue.length;i++)for(const q of E.neighbors(queue[i].c,queue[i].r)){
          const k=E.key(q.c,q.r);
          if(seen.has(k)||!passable.has(k)||groundConnection(m,u,queue[i],q))continue;
          seen.add(k);queue.push(q);
        }
        const goal=queue.some(p=>anchors.some(a=>E.distance(a,p)<=1));
        components.push({cells:queue.length,goal});
      }
      return {kind,passable:passable.size,taskArea:components.filter(p=>p.goal).reduce((n,p)=>n+p.cells,0),
        detached:components.filter(p=>!p.goal).length,largest:Math.max(0,...components.map(p=>p.cells))};
    });
    return [name,{width:end-start,height:map.rows,total:(end-start)*map.rows,units}];
  }));
  const units=map.units.filter(u=>u.kind!=='fort'),byTeam=team=>units.filter(u=>u.team===team).length;
  const fixedRules=['meRohanFoot','meRohan','meRohanBow','meAragorn','meFrodo','meGrond','meEagle'].map(kind=>{
    const stat=E.unitStats(m,{kind});
    return {kind,baseMove:stat.move,plainBudget:Math.ceil(stat.move*1.5),roadBudget:Math.ceil((stat.move+1)*1.5),
      range:stat.range,sight:stat.vision+2,ap:2};
  });
  return {dimensions:[map.cols,map.rows],turnLimit:map.victory.turnLimit,areas,army:[byTeam('egypt'),byTeam('coalition')],
    forts:map.units.length-units.length,fixedRules,
    waves:map.victory.waves.map(({key,team,turn,rows})=>({key,team,turn,rows})),
    routes:routes[id].map(args=>march(map,...args))};
}
const ids=new Set(process.argv.slice(2));
const rows=MIDDLE_EARTH.filter(({id})=>!ids.size||ids.has(id)).map(({id,name})=>({id,name,before:audit(id,5),after:audit(id,6)}));
console.log(JSON.stringify(rows,null,2));
