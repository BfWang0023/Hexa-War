const {chromium}=require(process.env.HEX_PLAYWRIGHT||'/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs/promises');
const assert=require('node:assert/strict');
const base=process.env.HEX_URL||'http://127.0.0.1:8872';
const out=process.env.HEX_QA_DIR||'docs/middle-earth-visual';
const legacy=process.env.HEX_LEGACY==='1';
const chapters=['me_hornburg','me_erebor','me_isen_first','me_isen_second','me_pelennor','me_pelargir','me_morannon','me_morannon_final'];

const instrumentation=`
window.visualQA={
  inspect(){
    return {layout:game.map.victory.layoutVersion||1,
      size:[game.map.cols,game.map.rows],view:game.middleEarth.view,
      live:liveUnits().filter(u=>u.kind!=='fort').length,
      chunks:terrainObj.chunks.size,render:{...renderer.info.render},memory:{...renderer.info.memory},
      heapMB:performance.memory?.usedJSHeapSize/1048576};
  },
  view(c,r,meters,pitch,yaw,board){
    const p=offsetToWorld(c,r);target.set(p.x,visualHeight(currentMap(),c,r),p.z);
    cameraDistance=meters;cameraPitch=pitch;cameraYaw=yaw;boardView=board;updateCamera();
  },
  compare(id){
    const fresh=game.map.victory.layoutVersion===2;
    const focus=id==='me_hornburg'?(fresh?[31,18]:[18,12]):(fresh?[25,19]:[19,12]);
    this.view(...focus,id==='me_hornburg'?295:345,.92,-.25,false);
  },
  overview(){
    const m=game.map,zone=isMorannon(m.scenarioId)?(m.victory.layoutVersion===2?morannonWindows(m):MORANNON_WINDOWS)[game.middleEarth.view]:[0,m.cols];
    const aspect=stage.clientWidth/stage.clientHeight;
    this.view(Math.floor((zone[0]+zone[1]-1)/2),Math.floor(m.rows/2),Math.max((zone[1]-zone[0])*10.4/aspect,m.rows*9)*1.25,1.10,0,true);
  },
  inputPlan(){
    const rivals=liveUnits().filter(u=>u.team!=='egypt'&&u.kind!=='fort');
    for(const u of liveUnits().filter(u=>u.team==='egypt'&&u.kind==='meElf')){
      const target=rivals.find(v=>attackPreview(game,u,v.c,v.r)?.target.id===v.id);
      if(!target)continue;
      const dest=[...reachable(game,u).values()].find(d=>d.steps===1&&d.cost<=1);
      if(dest)return {u:{id:u.id,c:u.c,r:u.r},target:{id:target.id,c:target.c,r:target.r},dest};
    }
    return null;
  },
  click(c,r,id){clickCell(c,r,false,id);},
  remaining(id){return game.map.units.find(u=>u.id===id)?.actionsLeft;},
  turn(){return game.turn;}
};`;

async function openChapter(page,id){
  await page.goto(base+'/ancient/');
  await page.getByRole('button',{name:'战役选择',exact:true}).click();
  await page.getByRole('button',{name:/中土战役 · 六个独立章节/}).click();
  await page.locator(`[data-scenario="${id}"] > button`).click();
  await page.getByRole('button',{name:'进入战役',exact:true}).click();
  await page.waitForFunction(()=>document.body.dataset.page==='Battle'&&window.visualQA);
  await page.locator('#middle-earth-panel').waitFor();
}
async function capture(page,name){await page.screenshot({path:`${out}/${name}.png`});}
const twoFrames=page=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));

(async()=>{
  await fs.mkdir(out,{recursive:true});
  const browser=await chromium.launch({executablePath:process.env.HEX_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,
    args:['--enable-precise-memory-info']});
  const recording=process.env.HEX_RECORD==='1';
  const context=await browser.newContext({viewport:{width:1440,height:960},
    ...(recording?{recordVideo:{dir:out,size:{width:1280,height:854}}}:{})});
  const page=await context.newPage(),rows=[],errors=[];
  const cdp=await context.newCDPSession(page);
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(/THREE.*Shader Error|WebGLProgram.*Error/i.test(m.text()))errors.push(m.text());});
  page.on('dialog',d=>d.accept());
  await page.route('**/api/ancient/maps/*',r=>r.fulfill({status:404}));
  await page.route('**/ancient/app.mjs',async route=>{
    const res=await route.fetch();
    await route.fulfill({response:res,body:await res.text()+instrumentation});
  });
  let recorded=false;
  try{
    if(recording){
      await openChapter(page,'me_erebor');
      const plan=await page.evaluate(()=>visualQA.inputPlan());
      assert.ok(plan,'孤山开局须有可见目标供弓兵实射');
      await page.evaluate(({u})=>visualQA.view(u.c,u.r,77,.9,-.48,false),plan);
      await page.evaluate(({u})=>visualQA.click(u.c,u.r,u.id),plan);
      await page.waitForTimeout(900);
      await page.evaluate(({target})=>visualQA.click(target.c,target.r,target.id),plan);
      assert.equal(await page.evaluate(id=>visualQA.remaining(id),plan.u.id),1);
      await page.waitForTimeout(1150);
      await page.evaluate(({dest})=>visualQA.click(dest.c,dest.r),plan);
      assert.equal(await page.evaluate(id=>visualQA.remaining(id),plan.u.id),0);
      await page.waitForTimeout(1350);
      await page.locator('#board-view').click();
      await page.mouse.move(575,460);
      await page.mouse.wheel(0,740);
      await page.waitForTimeout(1700);
      await page.locator('#board-view').click();
      await page.locator('#end-turn').click();
      await page.waitForFunction(()=>visualQA.turn()===2);
      await page.waitForTimeout(1900);
      assert.deepEqual(errors,[]);
      recorded=true;
      return;
    }
    for(const id of legacy?chapters.slice(0,2):chapters){
      await openChapter(page,id);
      await twoFrames(page);
      const before=await page.evaluate(()=>visualQA.inspect());
      assert.equal(before.layout,legacy?1:2);
      if(!legacy)await capture(page,id+'-default');
      const start=Date.now();
      await page.locator('#end-turn').click();
      await page.waitForFunction(()=>visualQA.turn()===2);
      const turnMs=Date.now()-start;
      const frame=await page.evaluate(()=>new Promise(resolve=>{
        const a=[];let prev;
        const tick=t=>{if(prev!==undefined)a.push(t-prev);prev=t;
          if(a.length<60)requestAnimationFrame(tick);
          else{a.sort((a,b)=>a-b);resolve({p50:a[29],p95:a[56]});}
        };
        requestAnimationFrame(tick);
      }));
      const preCollectionMB=await page.evaluate(()=>visualQA.inspect().heapMB);
      await cdp.send('HeapProfiler.collectGarbage');
      await twoFrames(page);
      const after=await page.evaluate(()=>visualQA.inspect());
      const viewport=await page.locator('#stage').boundingBox();
      await page.mouse.move(viewport.x+viewport.width*.52,viewport.y+viewport.height*.57);
      const zoomStart=Date.now();
      await page.mouse.wheel(0,-125);
      await twoFrames(page);
      rows.push({id,before,after,preCollectionMB,frame,turnMs,zoomMs:Date.now()-zoomStart});
      await openChapter(page,id);
      if(chapters.indexOf(id)<2){
        await page.evaluate(id=>visualQA.compare(id),id);
        // Landmarks are suppressed only for the explicit recognition comparison.
        await page.locator('#labels').evaluate(el=>el.style.visibility='hidden');
        await twoFrames(page);
        await capture(page,id+(legacy?'-before':'-after'));
        await page.locator('#labels').evaluate(el=>el.style.removeProperty('visibility'));
      }
      if(!legacy){
        await page.getByRole('button',{name:'战场全景',exact:true}).click();
        await page.getByRole('button',{name:'返回指挥视角',exact:true}).waitFor();
        await twoFrames(page);
        await capture(page,id+'-panorama');
        await page.getByRole('button',{name:'返回指挥视角',exact:true}).click();
        await page.locator('#board-view').click();
        await page.evaluate(()=>visualQA.overview());
        await twoFrames(page);
        await capture(page,id+'-overview');
        if(id==='me_morannon_final'){
          await page.getByRole('button',{name:'末日山',exact:true}).click();
          assert.equal(await page.evaluate(()=>visualQA.turn()),1);
          assert.equal(await page.evaluate(()=>visualQA.inspect().view),'doom');
          await page.evaluate(()=>visualQA.overview());await twoFrames(page);
          await capture(page,'me_morannon-doom');
          await page.getByRole('button',{name:'战场全景',exact:true}).click();
          await twoFrames(page);await capture(page,'me_morannon-doom-panorama');
        }
      }
    }
    assert.deepEqual(errors,[]);
  }finally{
    if(process.env.HEX_RECORD!=='1')await fs.writeFile(`${out}/browser${legacy?'-before':''}.json`,JSON.stringify({rows,errors},null,2));
    await context.close();
    if(recording){
      if(recorded)await page.video().saveAs(`${out}/孤山实战演示.webm`);
      await page.video().delete();
    }
    await browser.close();
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
