const {chromium}=require(process.env.HEX_PLAYWRIGHT||'/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {mkdir,writeFile,rename}=require('node:fs/promises');
const assert=require('node:assert/strict');
const out=process.env.HEX_QA_DIR||'docs/middle-earth-playability';
const current=process.env.HEX_URL||'http://127.0.0.1:8881';
const baseline=process.env.HEX_V5_URL||'http://127.0.0.1:8882';
const viewport={width:1440,height:960};
const hook=`
window.cliffQA={
  info:()=>({layout:game.map.victory.layoutVersion,turn:game.turn,focus:target.toArray(),cameraDistance,cameraYaw,cameraPitch,
    side:game.side,events:{...game.middleEarth.events},edges:markGroup.children.find(o=>o.name==='known-cliff-edges')?.geometry.attributes.position.count??0,
    selected:selectedUnit()&&{id:selectedUnit().id,c:selectedUnit().c,r:selectedUnit().r,actions:selectedUnit().actionsLeft},
    render:{...renderer.info.render},heapMB:performance.memory?.usedJSHeapSize/1048576}),
  comparison(){
    const g=game.map.victory.points.gate??game.map.units.filter(u=>u.gate).sort((a,b)=>a.r-b.r)[0];
    const p=offsetToWorld(g.c,g.r);
    target.set(p.x+18,terrainObj.sample(p.x,p.z),p.z+3);
    boardView=false;cameraDistance=208;cameraYaw=-.17;cameraPitch=.98;updateCamera();
  },
  focus(c,r,d){
    const p=offsetToWorld(c,r);
    target.set(p.x,terrainObj.sample(p.x,p.z),p.z);
    boardView=false;cameraDistance=d;cameraYaw=-.17;cameraPitch=.98;updateCamera();
  },
  select(c,r){const u=game.map.units.find(u=>u.team===playerTeam&&u.kind!=='fort'&&u.c===c&&u.r===r);
    if(!u)throw Error('没有己方机动棋子');clickCell(c,r,false,u.id);},
  click(c,r){clickCell(c,r);},
  seed(value){game.middleEarth.random=value;},
  present(title){
    let tag=document.getElementById('qa-caption');
    if(!tag){tag=document.createElement('div');tag.id='qa-caption';document.getElementById('stage').append(tag);
      tag.style.cssText='position:absolute;z-index:40;bottom:12px;left:50%;transform:translateX(-50%);background:#18201bf2;color:#fff7d6;border:1px solid #a99665;border-radius:5px;padding:8px 16px;white-space:nowrap;font:600 15px system-ui;pointer-events:none';}
    tag.textContent=title;tag.hidden=!title;
  }
};
`;

async function open(browser,url,record){
  const context=await browser.newContext({viewport,...record&&{recordVideo:{dir:out,size:viewport}}});
  const page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(/Shader Error|WebGLProgram.*Error|CONTEXT_LOST/.test(m.text()))errors.push(m.text());});
  await page.route('**/api/ancient/maps/*',route=>route.fulfill({status:404}));
  await page.route('**/ancient/app.mjs',async route=>{
    const res=await route.fetch();
    await route.fulfill({response:res,body:await res.text()+hook});
  });
  await page.goto(url+'/ancient/');
  await page.getByRole('button',{name:'战役选择',exact:true}).click();
  await page.getByRole('button',{name:/中土战役 · 六个独立章节/}).click();
  await page.locator('[data-scenario="me_hornburg"] > button').click();
  await page.getByRole('button',{name:'进入战役',exact:true}).click();
  await page.waitForFunction(()=>document.body.dataset.page==='Battle'&&window.cliffQA);
  return {context,page,errors};
}
const screenshot=(p,n)=>p.screenshot({path:`${out}/${n}.jpg`,type:'jpeg',quality:88});
const info=p=>p.evaluate(()=>cliffQA.info());
const frames=p=>p.evaluate(()=>new Promise(resolve=>{
  const intervals=[];let prev;
  const tick=t=>{if(prev)intervals.push(t-prev);prev=t;
    if(intervals.length<36)requestAnimationFrame(tick);
    else {intervals.sort((a,b)=>a-b);resolve({p50:intervals[18],p95:intervals[34]});}};
  requestAnimationFrame(tick);
}));
(async()=>{
  await mkdir(out,{recursive:true});
  const browser=await chromium.launch({headless:true,executablePath:process.env.HEX_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args:['--enable-precise-memory-info']});
  const evidence={};
  try{
    const old=await open(browser,baseline,false);
    assert.equal((await info(old.page)).layout,5);
    await old.page.evaluate(()=>cliffQA.comparison());await frames(old.page);
    await screenshot(old.page,'hornburg-v5-same-camera');evidence.v5=await info(old.page);
    assert.deepEqual(old.errors,[]);await old.context.close();

    const {context,page,errors}=await open(browser,current,true);
    const video=page.video();
    evidence.default=await info(page);assert.equal(evidence.default.layout,6);
    evidence.normalFrames=await frames(page);
    await screenshot(page,'hornburg-v6-default');
    await page.evaluate(()=>cliffQA.comparison());await frames(page);
    await screenshot(page,'hornburg-v6-same-camera');evidence.v6=await info(page);
    const caption=text=>page.evaluate(t=>cliffQA.present(t),text);

    await page.evaluate(()=>{cliffQA.focus(26,15,105);cliffQA.select(26,16);});
    await caption('主门：阿拉贡经门洞穿过防线');
    await page.evaluate(()=>cliffQA.click(27,16));await page.waitForTimeout(550);
    const gate=(await info(page)).selected;assert.deepEqual([gate.c,gate.r],[27,16]);
    await page.evaluate(()=>cliffQA.click(28,16));await page.waitForTimeout(530);
    assert.equal((await info(page)).selected.c,28);
    await page.evaluate(()=>{cliffQA.focus(26,14,111);cliffQA.select(25,16);});
    await caption('换防：步兵沿内院台地前往北侧墙脚');
    await page.evaluate(()=>cliffQA.click(26,13));await page.waitForTimeout(1300);
    const ridge=await info(page);assert.deepEqual([ridge.selected.c,ridge.selected.r],[26,13]);assert.ok(ridge.edges>0);
    await caption('琥珀线：直上崖坡被阻断');
    await page.evaluate(()=>cliffQA.click(26,12));await page.waitForTimeout(700);
    assert.match(await page.locator('#hint').innerText(),/崖坡/);
    assert.deepEqual((await info(page)).selected,ridge.selected);
    await screenshot(page,'hornburg-v6-cliff');
    await caption('沿崖转移：从合法通路到相邻阵位');
    await page.evaluate(()=>cliffQA.click(27,13));await page.waitForTimeout(900);
    assert.equal((await info(page)).selected.c,27);
    evidence.combatFrames=await frames(page);

    await caption('防守行动：封堵溪流涵洞');
    await page.evaluate(()=>{cliffQA.focus(27,22,104);cliffQA.select(25,21);cliffQA.click(26,21);});
    await page.waitForTimeout(560);
    await page.getByRole('button',{name:'封堵涵洞',exact:true}).click();
    assert.ok((await info(page)).events.seal);
    await page.waitForTimeout(800);
    await screenshot(page,'hornburg-v6-culvert');

    await caption('切换俯视棋盘与战场全景');
    await page.locator('#board-view').click();await page.waitForTimeout(650);
    await screenshot(page,'hornburg-v6-board');
    await page.getByRole('button',{name:'战场全景',exact:true}).click();await page.waitForTimeout(900);
    await page.getByRole('button',{name:'返回指挥视角',exact:true}).click();
    await page.evaluate(()=>{cliffQA.focus(27,22,124);cliffQA.seed(17);});
    await caption('继续结算：爆破装置就位，撤出预警区');
    for(let i=0;i<3&&!(await info(page)).events['blast-ready'];i++){
      const next=(await info(page)).turn+1;
      await page.locator('#end-turn').click();
      await page.waitForFunction(turn=>cliffQA.info().turn>=turn,next);
    }
    assert.ok((await info(page)).events['blast-ready']);
    await page.waitForTimeout(850);await screenshot(page,'hornburg-v6-blast-ready');
    await caption('三级深谷墙被炸开：两格内双方地面部队受伤');
    await page.locator('#end-turn').click();
    await page.waitForFunction(()=>cliffQA.info().events.breach);
    await page.waitForTimeout(720);await screenshot(page,'hornburg-v6-breach');
    evidence.blast=await info(page);
    await caption('');
    assert.deepEqual(errors,[]);
    evidence.errors=errors;
    await context.close();
    await rename(await video.path(),`${out}/海尔姆深谷通行实录.webm`);
    await writeFile(`${out}/hornburg-browser.json`,JSON.stringify(evidence,null,2));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
