"""Build the offline V6 acceptance report from the recorded run data."""
import argparse
import base64
import html
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("evidence", type=Path)
parser.add_argument("destination", type=Path)
args = parser.parse_args()
root = args.evidence
output = args.destination

def read(name):
    return json.loads((root / name).read_text())

def records(name):
    return [json.loads(line) for line in (root / name).read_text().splitlines()]

def esc(value):
    return html.escape(str(value))

def table(headers, rows):
    head = "".join(f'<th scope="col">{esc(cell)}</th>' for cell in headers)
    body = "".join("<tr>" + "".join(f"<td>{esc(cell)}</td>" for cell in row) + "</tr>" for row in rows)
    return f'<div class="scroll"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'

def embedded(path):
    return base64.b64encode(path.read_bytes()).decode("ascii")

def image(name, caption):
    return (f'<figure><img loading="lazy" width="1440" height="960" alt="{esc(caption)}" '
            f'src="data:image/jpeg;base64,{embedded(root / (name + ".jpg"))}">'
            f'<figcaption>{esc(caption)}</figcaption></figure>')

titles = {
    "me_isen_first": "艾辛河渡口·第一次", "me_isen_second": "艾辛河渡口·第二次",
    "me_hornburg": "海尔姆深谷", "me_pelennor": "佩兰诺平原", "me_erebor": "孤山·五军之战",
    "me_pelargir": "佩拉基尔", "me_morannon": "黑门·含序幕", "me_morannon_final": "黑门·直接决战",
}
kind_names = {
    "meRohanFoot": "西谷步兵", "meRohan": "洛汗骑矛兵", "meRohanBow": "洛汗步弓手",
    "meAragorn": "阿拉贡", "meRiderLord": "洛汗将领", "meBlast": "萨鲁曼炸药", "meGandalf": "甘道夫",
    "meThorin": "索林", "meElf": "林地精灵", "meBolg": "波尔格", "meGrond": "格龙德",
    "meGondorHorse": "刚铎重骑兵", "meGondor": "刚铎盾矛兵", "meFrodo": "弗罗多", "meEagle": "巨鹰",
}
names = {
    "gate": "主门", "sally": "侧门", "culvert": "涵洞", "counter": "反击／控制节点",
    "cave": "洞窟", "blast": "爆破墙段", "core": "码头核心", "ford": "渡口",
    "exit": "撤离区", "dock0": "北泊位", "dock2": "南泊位", "pass": "山口出口",
    "crack": "末日裂隙", "front": "黑门正面", "front_zone": "黑门正面",
    "pass_zone": "西力斯昂哥", "doom_zone": "末日山", "battle_zone": "主战场",
}
wave_names = {
    "rescue": "接应队", "flank": "艾辛格侧翼", "dawn": "黎明援军", "rohan": "洛汗骑兵",
    "harad": "哈拉德援军", "ships": "黑船援军", "eagles": "巨鹰", "beorn": "比翁",
    "mordor-1": "魔多首批", "mordor-2": "魔多末批",
}
before_after = read("routes.json")
plays = {row["id"]:row for row in records("playthrough-v6.jsonl")}
morannon = next(row for row in records("morannon-approaches.jsonl") if row["seed"] == 17 and row["strategy"] == "rush")
failure = records("hornburg-failure.jsonl")[0]
v5_helm = records("playthrough-v5-hornburg.jsonl")[0]
browser = read("browser.json")
helm_browser = read("hornburg-browser.json")
logs = (root / "regression.log").read_text()
assert re.search(r"^# fail 0$", logs, re.M)
count = re.search(r"^# pass (\d+)$", logs, re.M)[1]
assert len(browser["rows"]) == 8 and not browser["errors"] and not helm_browser["errors"]
assert helm_browser["blast"]["events"]["breach"]
assert all(row["winner"]=="egypt" for key,row in plays.items() if key!="me_morannon") and morannon["winner"]=="egypt"

def dimensions(x):
    return "×".join(str(n) for n in x["dimensions"])

def total_area(x):
    return sum(v["total"] for v in x["areas"].values())

def area(x, ix):
    return f'{x["units"][ix]["passable"]:,} / {x["units"][ix]["taskArea"]:,} / {x["units"][ix]["detached"]:,}'

def coordinate(p):
    return f'({p["c"]}, {p["r"]})'

def march(r):
    if r.get("unreachable"):
        return "未找到路线"
    reserve = "，尚可行动" if r["arrivesWithAP"] else "，耗尽行动"
    return f'{r["turns"]} 回合 / {r["ap"]} 次移动 / {r["cells"]} 格{reserve}'

def milestone(row):
    return "、".join(f'{event["turn"]} 回合 {event["text"]}' for key,event in row["events"].items() if key!="ending")

maps=[]
zones=[]
route_details=[]
for row in before_after:
    title = titles[row["id"]]
    old,new = row["before"],row["after"]
    maps.append([title, f"{dimensions(old)} → {dimensions(new)}", f"{total_area(old):,} → {total_area(new):,}",
                 f'{old["turnLimit"]} → {new["turnLimit"]}', " / ".join(map(str,new["army"])),
                 f'{old["forts"]} → {new["forts"]}'])
    for key,entry in new["areas"].items():
        zones.append([title, names[key+"_zone"], area(old["areas"][key],0), area(entry,0),
                      area(old["areas"][key],1), area(entry,1)])
    routes=[]
    for prev,now in zip(old["routes"],new["routes"]):
        goal=names[now["key"]]+(f'（距目标 ≤{now["radius"]} 格）' if now["radius"] else "")
        source=kind_names.get(now["kind"],now["kind"])
        if now.get("wave"):
            source+=f'（{wave_names[now["wave"]]}）'
        routes.append([source,goal,coordinate(now["origin"]),march(prev),march(now)])
    route_table=table(["部队", "目标", "V6 起点", "V5", "V6"],routes)
    waves=table(["波次", "阵营", "触发回合", "队数", "V6 入口"],
        [[wave_names.get(w["key"],w["key"]),"西方" if w["team"]=="egypt" else "敌军",w["turn"],len(w["rows"]),
          "、".join(f"({r[1]}, {r[2]})" for r in w["rows"])] for w in new["waves"]]) if new["waves"] else ""
    route_details.append(f"<details><summary>{esc(title)}</summary>{route_table}{waves}</details>")

ends=[]
for key,row in plays.items():
    if key=="me_morannon":
        t=morannon["journey"][-1]["turn"]
        ends.append([titles[key],morannon["seed"],"正面牵制，持戒者快进",t,morannon["reason"],
                     f'序幕正常抵达出口后进入末日山。全托管对照在第 {row["turn"]} 回合失败。'])
    else:
        turn=row["first"].get("egypt_hit")
        ends.append([titles[key],row["seed"],f'第 {turn} 回合首次命中' if turn else "首轮布防，未记录西方命中",
                     row["turn"],row["reason"],milestone(row)])
ends.append(["海尔姆不操作对照",failure["seed"],"玩家持续结束回合",failure["turn"],failure["reason"],"完成失败结算"])

perf=[]
for row in browser["rows"]:
    perf.append([titles[row["id"]],f'{row["startMs"]} ms',f'{row["turnMs"]} ms',
                 f'{row["frame"]["p50"]:.1f} / {row["frame"]["p95"]:.1f} ms',f'{row["after"]["heapMB"]:.0f} MiB'])

rules=before_after[0]["after"]["fixedRules"]
rule_table=table(["兵种","基础移动","平地单次上限","道路出发单次上限","基础射程","视野（含章节加成）"],
    [[kind_names.get(r["kind"],r["kind"]),r["baseMove"],r["plainBudget"],r["roadBudget"],r["range"],r["sight"]] for r in rules])
media=output.parent/"海尔姆深谷通行实录.mp4"
screen_names=[
    ("hornburg-v6-default","V6 默认指挥视角。"),
    ("hornburg-v6-cliff","换防后尝试直上崖坡。琥珀线标记受阻边，蓝线标记可达落点。"),
    ("hornburg-v6-culvert","守军从内侧接近并封堵涵洞。"),
    ("hornburg-v6-board","纯俯视棋盘。"),
    ("hornburg-v6-blast-ready","下一敌方阶段引爆。橙色边框标记两格伤害范围。"),
    ("hornburg-v6-breach","同一段三级墙炸开后出现缺口。"),
]
styles="""
:root{color-scheme:dark;--bg:#141b18;--paper:#1f2924;--line:#485747;--ink:#f0f1e9;--muted:#bdc7b9;--accent:#efc474}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.62 system-ui,-apple-system,sans-serif}
main{width:min(1280px,calc(100% - 38px));margin:38px auto 70px}header{padding:32px;background:#273327;border:1px solid var(--line);border-radius:10px}
h1{font-size:clamp(26px,5vw,46px);margin:.25em 0;line-height:1.2}h2{margin-top:38px;color:var(--accent)}h3{font-size:17px;margin-top:26px}
p{margin:.6em 0 1em}.version,figcaption,.note{color:var(--muted)}.version{margin:0}a{color:#f1d390}
nav{display:flex;flex-wrap:wrap;gap:14px;margin-top:19px}section{scroll-margin:24px}
.scroll{overflow:auto;margin:12px 0 20px;border:1px solid var(--line);border-radius:7px}
table{border-collapse:collapse;width:100%;font-size:14px}td,th{text-align:left;padding:10px 13px;border-bottom:1px solid #36423b;vertical-align:top}th{background:#344238}tr:nth-child(even){background:#202a25}
details{margin:9px 0;padding:12px 15px;background:var(--paper);border:1px solid var(--line);border-radius:7px}summary{cursor:pointer;font-weight:650}
.gallery{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}figure{margin:0}img,video{display:block;width:100%;height:auto;border-radius:7px;background:#080b09}figcaption{margin:7px 0 14px}
li{margin:.4em 0}@media(max-width:760px){.gallery{grid-template-columns:1fr}header{padding:20px}}
"""
page=f"""<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>中土地形通行与可玩性整改验收</title><style>{styles}</style>
<main>
<header>
<p class="version">六边形战争 v28.52 · 2026-11-12 · 中土地图 V6</p>
<h1>中土地形通行与可玩性整改验收</h1>
<p>海尔姆深谷按城防、洞窟、外堤与增援入口重新排布。普通地面移动和近战受实际崖坡限制，六章八个开局各有一条走到胜利结算的固定种子回放。</p>
<nav><a href="#helm">海尔姆实录</a><a href="#routes">地图与路线</a><a href="#rules">悬崖与爆破规则</a><a href="#ends">终局</a><a href="#device">运行验收</a></nav>
</header>
<section id="helm"><h2>海尔姆深谷实录</h2>
<video controls playsinline preload="metadata" width="1440" height="960" src="data:video/mp4;base64,{embedded(media)}"></video>
<p>录屏使用实际指挥界面，依次通过主门、转移步兵、尝试跨崖、沿崖换防、封堵涵洞、切换视角，再继续结算到炸开墙段。</p>
<h3>同机位对照</h3>
<p class="note">两图相对主门使用相同偏移、镜头距离 208、偏航 −0.17、俯仰 0.98，默认玩家迷雾。</p>
<div class="gallery">{image("hornburg-v5-same-camera","V5，v28.51 原始资源。")}{image("hornburg-v6-same-camera","V6，紧凑布局。")}</div>
<div class="gallery">{''.join(image(name,caption) for name,caption in screen_names)}</div>
</section>
<section id="routes"><h2>八个开局的面积与路线</h2>
<p>V5 的 63 回合由早期海尔姆的 24 回合乘 2.6 并向上取整得出。V6 还原分章时限，海尔姆的黎明仍在第 6 回合。地图由各章手绘地形和入口位置决定。</p>
{table(["开局","外接范围 V5 → V6","战区内格数 V5 → V6","时限 V5 → V6","西方 / 敌方机动棋子","工事 V5 → V6"],maps)}
<p class="note">机动棋子列是完整开局名册里的非工事棋子，黑门含暂未激活单位，佩拉基尔包含固定泊位的黑船。黑门的三个窗口分开统计，窗口间隔离带不计入战区内格数。</p>
{table(["开局","战区","V5 步兵","V6 步兵","V5 骑兵","V6 骑兵"],zones)}
<p class="note">面积格内的三项依次为地形可站立与允许进入的格数、连通到任务点或其邻格的格数、与任务分离的连通区数量。以西谷步兵和洛汗骑矛兵为样本，按西方阵营通行权和开局设施计算。区域审计包含离主交战区较远的背景坡地。路线测算清空沿途机动占位，保留地形和工事，逐次使用引擎可达范围。抵达目标后有行动力仍要满足视线、距离与兵种限制才能攻击。</p>
{''.join(route_details)}
<h3>V5 与 V6 使用同一行军基线</h3>
{rule_table}
<p>行动力通常每回合 2 点。两版行军系数均为 1.5，射程为兵种基础值，视野加 2。道路加成、山地费用、桥与渡口、冲锋分步沿用原规则。悬崖会在计算移动费用前关闭通行边。谨慎潜行的弗罗多单次上限为 2 格。</p>
</section>
<section id="rules"><h2>悬崖、设施和炸药</h2>
<p>六边形外接半径 6 米，地形高程每级 3.45 米。每格一个站立锚点，地面网格分成中心平台和坡面。共享边的两格使用同一组角点与边中点。通行先检查站立面，再检查两侧通往共享边的三条采样线、横向坡度及边界接缝。人物移动按已批准的逐格路径贴地。</p>
{table(["单位类型","最大坡度","通行宽度","最大台阶"],[
["步兵","90%","1.2 米","0.75 米"],["骑兵","64%","2.2 米","0.50 米"],["车辆","52%","2.8 米","0.38 米"],["大型单位","56%","3.2 米","0.42 米"]])}
<ul>
<li>同高格心之间仍可能被陡边挡住。狭窄平台和沿崖路按方向与兵种判断。普通近战先判断能否接触，再结算伤害。远程、登墙、攻城及低空反制保留既有条件。</li>
<li>完整桥梁连接桥头道路，桥头还要符合坡度。城门继续按阵营和耐久判定。海尔姆涵洞只接两个入口，并受兵种和封堵状态限制。保持飞行的单位越过地面崖线，飞行无法占领地面目标。游戏没有独立降落指令。</li>
<li>深谷墙墙身为三级。常规攻击对墙身的耐久下限为 0.1，城门按既有规则。萨鲁曼炸药到位后等待下一敌方阶段。引爆炸毁指定墙段，中心及距离 1、2 格分别造成 9.0、6.0、3.0 点耐久伤害，波及双方地面部队。炸药自身消耗。封堵过的涵洞在爆破后重新开放。</li>
<li>选中地面单位时，蓝色显示可达格，琥珀色显示已知地形的受阻边。未知地形周围的坡面信息继续由迷雾控制。旧开局和旧存档保留原版地图、通行和爆破规则。</li>
</ul>
</section>
<section id="ends"><h2>流程与终局</h2>
<p>回放执行引擎正式移动、攻击与回合结算，使用默认迷雾和固定随机种子。佩拉基尔由脚本按玩家指令先接战再分兵；黑门序幕使用正常行进和正面牵制，其余胜局由托管完成。黑门的序幕转场由既有剧情规则触发。</p>
{table(["开局","种子","首战或打法","终局回合","结果","事件证据"],ends)}
<p>海尔姆同种子 V5 第 {v5_helm["first"].get("coalition_hit")} 回合敌军首次命中，第 {v5_helm["turn"]} 回合夺回反击点。V6 第 {plays["me_hornburg"]["first"]["coalition_hit"]} 回合敌军首次命中，黎明第 6 回合完成反击。实际伤害、爆破位置与兵团在场会随打法变化。</p>
<p>定向测试验证缓坡成本、同高格心之间的陡边、沿崖侧向通行、仅涂道路无法解封、不同兵种阈值、桥与涵洞、门洞穿行、隔崖近战、存读档重建及高程更新。爆破测试在装置已就位时存读档，并实测墙面耐久下限、双方受伤和范围外单位。历史回归通过 {count} 项。</p>
</section>
<section id="device"><h2>实际运行与验证范围</h2>
<p>MacBook Air，Apple M4，16 GB，macOS 26.6.2。下表来自该设备上的 Chromium 1440×960，加载安装包内 V6 网页资源。帧时间取开局 48 帧。首轮响应包含浏览器界面操作，内存为回收垃圾后 JavaScript 堆量。</p>
{table(["开局","进入战役","首轮结算","帧时间 P50 / P95","首轮后堆"],perf)}
<p>海尔姆录屏单独采样，默认视角帧时间 P95 为 {helm_browser["normalFrames"]["p95"]:.1f} ms，选中和换防场景 P95 为 {helm_browser["combatFrames"]["p95"]:.1f} ms。黑门视角切换核验了回合、行动力和战区范围。</p>
<p>macOS 应用验签并启动到战役菜单。原生窗口进入战局时，界面自动化超时，原生全程和长局帧时间未验证。Windows 与两种 Linux 包已校验文件和网页资源，跨平台运行未验证。批量寻路高负载和长时间内存趋势未验证。引擎回放到达八个胜利终局，孤山两翼高路的每个入口和所有可选退守变体未逐一手动验证。</p>
<p>可重跑源码中的 <code>tools/middle-earth/map-audit.mjs</code>、<code>compact-playthrough.mjs</code>、<code>morannon-playthrough.mjs</code> 与 <code>compact-visual-qa.cjs</code>。图像和视频内嵌，可离线查看。</p>
</section>
<section><h2>参考</h2>
<p>坡度、台阶和横向净宽分别判断。<a href="https://recastnav.com/structrcConfig.html">Recast Navigation</a></p>
<p>六边格的边可以独立关闭，保留同格其他方向。<a href="https://www.redblobgames.com/pathfinding/grids/graphs.html">Red Blob Games</a></p>
<p>保留号角堡岩台、深谷墙、涵洞与外堤的相对次序。<a href="https://tolkiengateway.net/wiki/Helm%27s_Gate">Helm’s Gate</a> · <a href="https://tolkiengateway.net/wiki/Helm%27s_Dike">Helm’s Dike</a></p>
<p>地图借鉴山谷和水系的空间关系。<a href="https://www.tolkienestate.com/painting/maps/">Tolkien Estate 地图</a></p>
</section>
</main></html>
"""
output.write_text(page, encoding="utf-8")
