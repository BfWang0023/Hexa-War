import * as E from '../../web3d/ancient/engine.mjs';
import {makeMiddleEarthMap} from '../../web3d/ancient/middle-earth-maps.mjs';
import {morannonCell,projectMiddleEarthCell} from '../../web3d/ancient/middle-earth-data.mjs';
import {setStealth,meZone,meRoll} from '../../web3d/ancient/middle-earth-rules.mjs';

const get=(s,k)=>s.map.units.find(u=>u.kind===k);
const alive=u=>u.hp>0&&!E.isRouted(u);
const strike=(s,u,t)=>E.attack(s,u.id,t.c,t.r,meRoll(s),meRoll(s),meRoll(s),meRoll(s));
const pursue=(s,u,goal,penalty=()=>0)=>{
  if(!u||!alive(u))return;
  const moves=[...E.reachable(s,u).values()].filter(p=>E.distance(p,goal)<E.distance(u,goal));
  const score=p=>E.distance(p,goal)+penalty(p);
  moves.sort((a,b)=>score(a)-score(b));
  if(moves.length)E.move(s,u.id,moves[0].c,moves[0].r);
};
for(const seed of [17,47])for(const strategy of ['careful','rush','abandon-front']){
  const s=E.startGame(makeMiddleEarthMap('me_morannon'),{middleEarthSeed:seed,mutinySeed:seed,reserveResponses:true});
  const f=get(s,'meFrodo'),sam=get(s,'meSam'),spider=get(s,'meShelob'),p=s.map.victory.points;
  const journey=[];
  for(let n=0;n<s.map.victory.turnLimit&&!s.over;n++){
    const pro=s.middleEarth.phase==='prologue';
    if(pro&&alive(sam)&&alive(spider)&&E.attackPreview(s,sam,spider.c,spider.r))strike(s,sam,spider);
    if(!pro&&strategy==='abandon-front'){
      // Failure fixture only: simulate complete permanent loss of the frontal force.
      for(const u of s.map.units)if(u.team==='egypt'&&meZone(u.c,s.map)==='front')u.hp=0;
      E.checkVictory(s);break;
    }
    if(!pro)for(const u of s.map.units.filter(u=>u.team==='egypt'&&meZone(u.c,s.map)==='front'&&alive(u))){
      const foes=s.map.units.filter(v=>v.team==='coalition'&&alive(v)&&meZone(v.c,s.map)==='front'&&E.knownTo(s,'egypt',v));
      for(let j=0;j<2&&u.actionsLeft>0;j++){
        const enemy=foes.find(v=>E.attackPreview(s,u,v.c,v.r));
        if(strategy==='careful'&&s.turn>=8&&u.hp<E.unitStats(s.map,u).hp*.65)
          pursue(s,u,projectMiddleEarthCell(s.map,4,u.r<p.front.r?10:20));
        else if(enemy)strike(s,u,enemy);
        else if(E.distance(u,p.front)>3)pursue(s,u,p.front);
      }
    }
    const goal=pro?(f.c<morannonCell(33,8,s.map).c?morannonCell(34,10,s.map):p.pass):p.crack;
    const risk=cell=>{
      if(strategy==='rush')return 0;
      const enemies=s.map.units.filter(u=>u.team==='coalition'&&meZone(u.c,s.map)===meZone(f.c,s.map)&&alive(u)&&E.knownTo(s,'egypt',u));
      return enemies.reduce((v,e)=>v+Math.max(0,4-E.distance(cell,e))*3,0)+
        (s.middleEarth.alert&&E.distance(cell,s.middleEarth.alert)<=2?5:0);
    };
    setStealth(s,pro||strategy==='rush'?'normal':'careful');
    for(let j=0;j<2&&!s.over;j++){
      if(strategy==='careful'&&!pro&&j===0)pursue(s,sam,f);
      pursue(s,f,goal,risk);
    }
    if(!s.over&&alive(sam))for(let j=0;j<2;j++)pursue(s,sam,f);
    journey.push({turn:s.turn,phase:s.middleEarth.phase,c:f.c,r:f.r,hp:f.hp});
    if(!s.over)E.endSide(s);if(!s.over)E.aiTurn(s);
  }
  console.log(JSON.stringify({seed,strategy,winner:s.winner,reason:s.victoryReason,events:Object.keys(s.middleEarth.events),journey}));
}
