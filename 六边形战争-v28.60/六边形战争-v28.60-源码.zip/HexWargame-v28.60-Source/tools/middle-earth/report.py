from pathlib import Path
from html import escape
import base64, json, sys

docs=Path('docs/middle-earth')
output=Path(sys.argv[1])
browser=json.loads((docs/'browser.json').read_text())
playthrough=[json.loads(line) for line in (docs/'morannon-playthrough.log').read_text().splitlines()]
regression=(docs/'full.log').read_text().splitlines()
stats='，'.join(line[2:] for line in regression if line.startswith(('# pass ','# fail ')))
def img(name,caption):
    data=base64.b64encode((docs/name).read_bytes()).decode()
    return f'<figure><img loading="lazy" src="data:image/png;base64,{data}" alt="{escape(caption)}"><figcaption>{escape(caption)}</figcaption></figure>'
def link(href,label):
    return f'<a href="{escape(href)}">{escape(label)}</a>'
def chapter(title, text, ids, ref):
    pictures=''.join(img(id+'-board.png',label+'俯视')+img(id+'.png',label+'正常视角') for id,label in ids)
    return f'<section><h2>{title}</h2><p>{text}</p><p>{ref}</p><div class="shots">{pictures}</div></section>'

rows=[
 ('艾辛河渡口之战','河槽、河中洲和两岸道路由实际涉水规则连接。第一次等埃尔夫海姆沿东岸入场后撤出三队，希奥杰德可以幸存。第二次以第 4 回合前保持渡口附近有效部队为迟滞门槛，随后从东南出口撤出四队。',
  [('me_isen_first','第一次渡口战'),('me_isen_second','第二次渡口战')],
  '《未完的传说》第三部分第五篇。'+link('https://tolkiengateway.net/wiki/First_Battle_of_the_Fords_of_Isen','第一次战斗索引')+' · '+link('https://tolkiengateway.net/wiki/Second_Battle_of_the_Fords_of_Isen','第二次战斗索引')),
 ('海尔姆深谷之战','外堤、深谷墙、号角堡与后方洞窟组成分层防线。涵洞只准小型步兵通行，可以封堵。爆破装置到达墙边并留过一次行动阶段才造成缺口。第 6 回合甘道夫与鄂肯布兰德带西谷步兵入场，守军需夺回外堤。失去组织的登兰德人可投降。胡恩仅在边界结算退出战斗的溃军。',
  [('me_hornburg','号角堡')],
  '《双塔殊途》卷三第七至第八章。'+link('https://tolkiengateway.net/wiki/Battle_of_the_Hornburg','号角堡之战索引')),
 ('佩兰诺平原之战','西侧是米那斯提力斯山体与城门，东侧是安都因河。格龙德攻击大门，北来洛汗第 3 回合入场，魔多后续兵力第 5 回合到达，阿拉贡第 7 回合从南方哈隆德登陆。梅里与伊欧温可在巫王低空时接战。巫王退场动摇附近战团，守军仍须夺回大道。',
  [('me_pelennor','佩兰诺')],
  '《王者归来》卷五第一、第四至第六章。'+link('https://tolkiengateway.net/wiki/Battle_of_the_Pelennor_Fields','佩兰诺之战索引')),
 ('孤山·五军之战','按第三纪元 2941 年设置孤山正门、乌鸦岭、另一道山脊、奔流河与河谷邦废墟。矮人、精灵和湖民合防。巨鹰和比翁分批抵达，联军须消灭波尔格、压制余部并打通山门。',
  [('me_erebor','孤山')],
  '《霍比特人》第十七至第十八章。'+link('https://tolkiengateway.net/wiki/Battle_of_Five_Armies','五军之战索引')),
 ('佩拉基尔夺船','使用三艘可见黑船作为固定港口任务目标。亡者靠近可造成有上限的恐惧，在阿拉贡附近活动。活人无争议地占住至少两个泊位，阿拉贡到达履约点时释放亡者并锁胜。',
  [('me_pelargir','佩拉基尔')],
  '《王者归来》卷五第二及第九章。'+link('https://tolkiengateway.net/wiki/Pelargir','佩拉基尔索引')+' · '+link('https://tolkiengateway.net/wiki/Oathbreakers','亡者索引')),
 ('黑门之战','可从西力斯昂哥序幕或黑门决战起步。序幕有实体尸罗、麻痹与山姆救援。决战两个战区共享回合、行动力、存档和终局，镜头只渲染当前战区。黑门正面为 27×23 格，末日山为 24×23 格。正面地图有双丘、积水和门楼，门楼使用自制深色铁板、石块和铆钉贴图。末日裂隙有独立的发光目标。',
  [('me_morannon','西力斯昂哥'),('me_morannon_final','黑门正面')],
  '《双塔殊途》卷四第九至第十章，《王者归来》卷五第九至第十章及卷六第二至第三章。'+link('https://tolkiengateway.net/wiki/Battle_of_the_Morannon','黑门之战索引')+' · '+link('https://tolkiengateway.net/wiki/Mount_Doom_(chapter)','末日山章节索引')),
]
chapters=''.join(chapter(*row) for row in rows)
names={'careful':'谨慎潜行与正面抵抗','rush':'快速穿越','abandon-front':'模拟正面覆灭'}
plays=''.join(f"<tr><td>{x['seed']}</td><td>{names[x['strategy']]}</td><td>{escape(x['reason'] or '未完成')}</td><td>{x['journey'][-1]['turn']}</td></tr>" for x in playthrough)
safe=next(x for x in playthrough if x['strategy']=='careful' and x['winner']=='egypt')
route=' → '.join(f"({p['c']},{p['r']})" for p in safe['journey'])
ranges=[x['endTurnUiMs'] for x in browser['rows']]
frames=[x['medianFrameMs'] for x in browser['rows']]
html=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>六边形战争 v28.47 · 中土战役开发报告</title>
<style>
:root{{color-scheme:dark;background:#171e1b;color:#eee7d6;font:16px/1.65 system-ui,sans-serif}}
body{{max-width:1160px;margin:auto;padding:38px 24px 72px}} h1,h2{{font-family:serif;line-height:1.22;color:#f0d6a2}}
h1{{font-size:clamp(30px,5vw,57px);margin-bottom:12px}} section{{margin:36px 0;padding-top:20px;border-top:1px solid #566054}}
a{{color:#e7c889}} .shots{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,390px),1fr));gap:14px}}
figure{{margin:0;background:#242d27;border-radius:8px;overflow:hidden}} img{{width:100%;display:block}}
figcaption{{padding:7px 12px;color:#d9d0bc}} table{{width:100%;border-collapse:collapse}}
td,th{{text-align:left;padding:8px;border-bottom:1px solid #566054}} code{{color:#d2d9b6}}
</style><body>
<h1>中土战役开发报告</h1>
<p>《六边形战争》v28.47 · 2026 年 11 月 11 日</p>
<p>战役选择 → 中土战役。六章各自开局，艾辛河和黑门各有两个起点。普通战场扩大至 40×26 格。</p>
{img('black-gate.png','游戏内近景 · 黑门专用黑石与铁栅')}
{chapters}
<section><h2>黑门操作与结局</h2>
<p>在西力斯昂哥让弗罗多携戒到达出口。山姆可在交战中驱退尸罗，解除麻痹。转场会保留伤亡与戒指状态。决战用任务卡在黑门和末日山之间切换，两边动作完成后统一结束回合。</p>
<p>索伦关注以魔多实际看到且位于正面关键格四格内的有效部队计算，每队权重 0.09，最近两回合实际交战另加 0.14。目标值封顶 1，新旧权重为 45% 和 55%。预警区域从公开地理候选和最后发现点抽取，半径 2 格，玩家行动结束后生效。下一次搜索间隔按关注程度为 1 至 3 回合，可信度高于 0.5 的踪迹使间隔缩至 1 回合。</p>
<p>谨慎潜行把弗罗多每次移动限制为一格，缩短巡逻队的识别距离。掩蔽行动消耗一点行动力，并须位于山地或建筑掩护。失去踪迹后，最后位置可信度每回合下降 0.28。戒灵调动需两个全局回合，保持同一个单位 ID。</p>
<p>咕噜夺戒后可以在其抵达逃离口前追回。山姆拾戒后靠近弗罗多可归还。魔多拾戒后也须带回营地才判败。弗罗多活着携戒抵达目标格即锁定胜利。若咕噜已死，界面提示改写结局。决战中弗罗多死亡、戒指不可追回或正面有效兵力全部丧失均判负。上限 28 回合。</p>
{img('me_morannon_doom.png','游戏内末日山 · 战区切换与搜索预警')}
<h3>可复现流程</h3>
<p>运行 <code>node tools/middle-earth/morannon-playthrough.mjs</code>。谨慎路线从序幕绕开尸罗，末日山利用较少巡逻的北线，正面部队向双丘靠拢并交战。种子 {safe['seed']} 的弗罗多回合末坐标依次为 {route}。</p>
<table><thead><tr><th>种子</th><th>操作</th><th>结果</th><th>最后记录回合</th></tr></thead><tbody>{plays}</tbody></table>
</section>
<section><h2>兵种模型与规则</h2>
{img('models.png','从游戏模型管线渲染的对照 · 关闭阵营标识')}
<p>新增 44 个规则编号，共用动画接口。刚铎卫队、洛汗骑兵、半兽人与强兽人有独立的体型和装备轮廓。座狼、蜘蛛、猛犸、巨鹰和戒灵飞兽使用单独网格。空中和地面分别占位。飞行单位攻击后进入低空窗口，可被地面近战反制。亡灵免疫普通攻击，恐惧每回合最多结算一次，活人负责接管泊位。大型单位受山坡、门楼和涵洞约束。</p>
<p>装备外形、兵力、容量、回合数、阵营控制分组和恐惧均为游戏设计。人物存活与关键遭遇可因玩家行动而改变。地理关系参照原著章节定位及公开索引。{link('https://www.tolkienestate.com/painting/maps/','托尔金遗产管理方公开地图')}</p></section>
<section><h2>验证与限制</h2>
<p>浏览器从菜单实际进入 {len(browser['rows'])} 个起点，完成首轮结算，测试黑门切换和截图。浏览器错误数 {len(browser['errors'])}。项目规则回归 {escape(stats)}。覆盖存读档、搜索计划不依赖隐藏坐标、增援事件去重、飞行与涵洞、撤离、夺船及终局。</p>
<p>Apple M4、16 GB，1440×960 Chromium 无头测试。每场采集 24 帧，帧间隔中位数 {min(frames):.1f}–{max(frames):.1f} ms。第一个结束回合从点击至界面更新耗时 {min(ranges)}–{max(ranges)} ms，包含浏览器交互开销。这些是开局短样本，M1、大量单位压力和 Windows/Linux 实机帧率未测。</p>
<p>首版采用规则驱动 AI。港口黑船以固定泊位呈现，未实现驶离动画。部分剧情通过事件日志或单位状态表现，未制作过场影片。巫王和飞兽使用一个作战实体与低空状态，尚无坐骑被击落后单独步战的状态。胡恩目前通过边界事件表现。AI 的晚期城防布置、所有随机分支和长期平衡尚未穷尽验证。黑门仅开放西方联军玩家对魔多电脑。</p>
<p>Apple 芯片 Mac 解压后启动应用。Windows x64 双击 <code>start.cmd</code>，Linux x64 或 ARM64 运行 <code>./start.sh</code>，随后打开 <code>http://127.0.0.1:8800/ancient/</code>。源码位于项目的 <code>web3d/ancient/</code>，中土逻辑按地图、事件、模型与黑门材质组织。</p>
</section></body></html>'''
output.write_text(html,encoding='utf-8')
