import json,pathlib,re
root=pathlib.Path('.');out=root/'docs/topographic-recon-20261029';read=lambda n:json.loads((out/n).read_text())
p=read('performance.json');g=read('generation-performance.json');march=read('march.json')['march'];oldmarch=read('march-before.json')['march'];audit=read('source-audit.json')
rows=[]
for id,name in [('china_muye','牧野'),('china_changping','长平'),('mantinea','曼提尼亚')]:
 b=next(s for s in p['scenes'] if s['id']==id and s['mode']=='before');a=next(s for s in p['scenes'] if s['id']==id and s['mode']=='after')
 rows.append(f"|{name}（{a['units']} 棋子，含工事）|{b['averageFPS']:.2f} → {a['averageFPS']:.2f}|{b['low1FPS']:.2f} → {a['low1FPS']:.2f}|{b['drawCalls']} → {a['drawCalls']}|{b['loadMs']} → {a['loadMs']}|{b['heapBytes']/1048576:.1f} → {a['heapBytes']/1048576:.1f}|")
files='\n'.join('- `'+x+'`' for x in audit['modified']+audit['added'])
report=f'''# 自动地形海拔与军事地形侦察小地图：开发和验证报告

2026-10-29 · 战斗规则 v13 / 自动海拔生成器 v1

## 已交付与使用方法

地图编辑器只需绘制平原、山地、山路、河流等既有地形类型。海拔立即自动生成，无需设置每格高度、主峰、谷底或控制点。连续山区形成连贯坡面；道路沿相同地表铺设。编辑器顶部新增撤销、重做按钮，支持 ⌘/Ctrl+Z 与 ⇧+⌘/Ctrl+Z。一次连续拖绘作为一个历史操作，最多保留 24 次；恢复地形的同时恢复高程及因绘制被移除的单位等地图数据。

战场左上角“地形侦察”可以收起、展开、放大。滚轮以鼠标位置为中心缩放；点击地图移动主镜头并退出士兵跟随；“定位部队”优先定位当前选中部队，否则定位己方部队中心。地形与部队图层可分别开关。编辑器中小地图移到右下角，避免遮挡绘图工具。

地图按正式逻辑高程分层设色，等高距 0.5；带山势明暗、道路、桥梁和已发现设施符号。鼠标悬停可查看已知逻辑高程和设施名称。己方圆点、可见敌军菱形、选中单位外环与镜头投影框分别标识。暗色地形是历史记录，黑色是未知。编辑器明确显示“全图地形”。

## 架构与规则边界

没有迁移 Three.js，没有重写渲染引擎。复用既有地形块缓存、连续网格、单位贴地采样、选格射线、行动范围、伤害接口和 `fog.visible/explored`。

`auto-elevation.mjs` 独立实现确定性高程：六角格到非山地边界的距离场（截断半径 8），乘以三个尺度的连贯、经坐标扭曲的山脊起伏。山麓较低，狭窄山带深度不足，因此低于宽阔山体；内部通过持续变化的起伏形成峰、脊、鞍部和谷地，而非同高平台。平原逻辑地面为 0，水面保持连续；山区道路轻微降低所在高程并随坡铺设，不改变路网与通行资格。高度量化为 0.01，固定种子 2718，元数据保存生成器版本、参数和地形指纹。

单格编辑最多重新计算八圈内 217 格，结果与全量重生成逐项一致。地形指纹仍是 O(地图格数) 的轻量扫描；不是声称所有工作均为 O(1)。随后既有地形缓存只重建受影响块与必要邻块。修复缓存邻域枚举的重复项，避免大批高度改变时重复处理同一格。

三维山体从逻辑高程插值，视觉纵向比例为每逻辑高度 3 个世界单位；细微表面纹理起伏不会参与伤害。低细节模式改用较少网格面，但仍使用同一份逻辑高度。单位底座、动画贴地和拾取沿实际生成网格采样。渲染不会改写规则数据。

**保留已确认的 v12 山地通行规则**：步兵、补给队无路山地一次行动一格，仍有两次行动；山路恢复平原能力，不额外 +1；骑兵、战车、战象、器械及列阵步兵只能走山路；补给队山区和山路行程粮耗双倍。不追加坡度税。伤害继续按相对逻辑高程，每级 ±15%，倍率 0.55–1.45，仅结算一次，反击重新确定攻守高差；不添加射程或视野能力。

新战局标注 v13。v10/v11/v12 存档保留各自规则和已保存海拔，不在加载时重生成。v13 保存数组和生成版本；地图导出、导入及战斗存档恢复保留它们。编辑旧地图后保存为自动高程地图是本次明确授权的设计变更。训练和评估继续使用原执行逻辑及规则版本记录；没有更改自主 AI 的战术选择。

本报告取代旧命令中的“人工指定海拔/主峰/谷底”“山地永远只改视觉”和“所有地图默认山地高度固定为 1”等冲突条款；旧版本兼容性测试仍保留。几项旧字节保护测试只更新了本次授权修改的接口摘要，旧实现副本保存在 `before/`，未删除测试。

## 侦察信息隔离与性能设计

`reconnaissance.mjs` 是独立权限边界。读取当前可见集合后才记录格子内容；双方分别保存观察记录。每次引擎视野重算同步记录，故关闭小地图或连续快速行军也能保留已经发现的地形。看不见后，只读历史记录，不从当前全知地图更新设施或高度。敌军不保留历史位置标记，只展示当前可见者。编辑器全知预览不写入战斗侦察记录。

旧存档若只有“探索过”的标记、没有地形观察快照，无法可靠恢复当时内容，因此未知部分保持遮罩，重新侦察后记录；不会倒推当前隐藏设施。

地形绘到 1024×1024 的静态 Canvas 图层，签名不变不重建；动态标记与镜头范围以 5 Hz 更新，不逐帧重绘复杂地形。战场形势变化时重建静态图层，而非每个单位移动的每帧重建。正式侦察记录不再为每次移动重复分配每个可见格对象，坐标缓存不进入存档。

## 实际验证

- 修改前：1,030 项 Node 测试通过；最终：1,043 项全部通过，0 失败。
- Rust：327 次测试执行通过，0 失败。
- 实际 Chromium 战场加载：85/85 场成功，浏览器错误 0。当前实际项目是 85 场、42 张人工修订图，并非旧交接中的 71/34。
- 42 张人工地图逐字节一致；兵种模型、动作控制和特效文件未改动。历史战役胜利条件未改。
- 新测试覆盖狭窄/宽阔山体、山麓/内部、非平台起伏、确定性、20 次局部/全量结果对照、撤销/重做、地图/存档往返、v12 冻结兼容、高低差、行动力、山路、桥梁叠加渡口、迷雾权限、观察快照持久化、低细节与共享边界一致性。
- 端到端验证包括：实际鼠标点选高起地表并绘制山路；按钮撤销/重做；键盘撤销/重做；真实浏览器地图导入导出及战斗保存恢复；小地图点击定位、滚轮缩放、选中部队定位、图层开关和放大；编辑器全图与战斗迷雾隔离；静态地形缓存计数保持不变。
- 通过真实传令官输入“所有轻步兵向东移动一格”：130/130 名士兵移动成功、失败 0，每名扣 1 行动力。使用本地解析，不涉及远程 API，也没有用模拟移动代替执行。

原始记录：`all-tests.txt`、`rust-tests.txt`、`new-tests.txt`、`e2e.json`、`ui-e2e.json`、`march.json`、`source-audit.json`。

## 性能测量

设备 Apple M4、16 GB；Chrome 无头浏览器，1440×1000，DPR=1，标准画质。新旧代码分别运行，同地图、同单位、同镜头位置，每场采样 600 帧约 10 秒。平均 FPS=1000/平均帧间隔，1% Low=1000/最慢 1% 帧的平均间隔。JS 堆为 Chrome `performance.memory` 数据，不是整机内存或精确 GPU 显存。页面加载时间包含导航和资源加载，单次结果受文件缓存影响，不能据此宣称载入提速。

|场景|平均 FPS：前→后|1% Low：前→后|Draw Calls：前→后|页面载入 ms：前→后|JS 堆 MiB：前→后|
|---|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

三场静态图层均只构建 1 次。最后一次小地图地形构建 {min(x['minimap']['terrainMs'] for x in p['scenes'] if x['mode']=='after'):.1f}–{max(x['minimap']['terrainMs'] for x in p['scenes'] if x['mode']=='after'):.1f} ms，动态绘制 {min(x['minimap']['dynamicMs'] for x in p['scenes'] if x['mode']=='after'):.1f}–{max(x['minimap']['dynamicMs'] for x in p['scenes'] if x['mode']=='after'):.1f} ms；0 表示低于计时分辨率，不等于零开销。观察及视图整理 {min(x['minimap']['observeMs'] for x in p['scenes'] if x['mode']=='after'):.1f}–{max(x['minimap']['observeMs'] for x in p['scenes'] if x['mode']=='after'):.1f} ms（具体采样见 `performance.json`）。

16,000 格纯高程生成：10 次全量，中位 {g['fullMs']['median']:.2f} ms、最大 {g['fullMs']['max']:.2f} ms；40 次局部编辑，中位 {g['localMs']['median']:.3f} ms、P95 {g['localMs']['p95']:.3f} ms，最多访问 {g['maxVisited']} 格。此项不含三维网格重建、GUI 和磁盘保存。实测逻辑高度范围 {g['heightRange'][0]}–{g['heightRange'][1]}。

130 人实际行军的 4 秒短样本：升级前平均 {oldmarch['averageFPS']:.2f} FPS / 1% Low {oldmarch['low1FPS']:.2f}；优化后平均 {march['averageFPS']:.2f} / 1% Low {march['low1FPS']:.2f}，最慢帧 {march['maxFrameMs']:.1f} ms，Draw Calls {march['drawCalls']}。本地解析 {march['metrics']['localParseMs']:.1f} ms，提交至首次动作 {march['metrics']['inputToFirstActionMs']:.1f} ms，全部完成 {march['metrics']['elapsedMs']:.1f} ms。第一轮曾出现约 66.6 ms 的慢帧（1% Low 29.94），已减少侦察临时对象分配并保留前后原始记录；短样本仍不能替代长时间压力测试。

**未测 M1、原生 WKWebView 长时间战斗及真实 GPU 显存。不能将这些 M4 短样本描述为 M1 稳定 60 FPS 已验收。**

## 截图与代码

实际运行截图：

- `mountain-road-pointer-edit.png`：实际鼠标绘制山路后的连续山体与编辑器侦察图。
- `automatic-mountains-editor.png`：山脊和谷地、编辑撤销/重做后的全图。
- `selected-troop-recon.png`：长平战场、放大的侦察图与选中部队。
- `recon-battle.png`、`recon-enlarged.png`：战斗迷雾和放大地图。
- `before-/after-china_muye.png`、`before-/after-china_changping.png`、`before-/after-mantinea.png`：固定视角前后对照。
- `130-soldiers-moving.png`：实际 130 人命令执行结果。

修改及新增游戏文件：

{files}

验证脚本位于 `tools/topographic-recon/`；四份既有摘要清单（officer-v2、hero-regalia、art-refinement、support-refinement）更新了授权变动的 engine/save/app 哈希，其余受保护内容仍按原哈希验证。源码差异见 `implementation.patch`，完整修改记录见 `source-audit.json`。

## 已知边界与后续建议

1. 镜头白框是地表投影近似，山体遮挡和近地视角下不等同于精确可见像素区域；战斗视野仍由原引擎判定。
2. 不显示敌军历史位置；已探索但缺少旧快照的存档区域需重新侦察。
3. 现有编辑器没有独立丘陵类型，本次没有扩展地形枚举或通行规则；可通过狭窄山带生成低山脊。
4. 自动高程会改变新 v13 战局的具体高差伤害，参数沿用已测试的 15% / 0.55–1.45；未宣称所有 85 场战役已完成长期平衡测试。
5. 下一步优先在 M1 和原生桌面长时间战斗中复测；超大图频繁改变视野时可进一步把静态侦察图拆成分块缓存。

macOS 包已构建，并从 ZIP 独立解压验证签名及全部网页文件一致性；构建后的 Finder 元数据问题已清理并重新验证。详细检查见 `package-verification.json`。
'''
(out/'自动海拔与地形侦察小地图交付报告.md').write_text(report)
