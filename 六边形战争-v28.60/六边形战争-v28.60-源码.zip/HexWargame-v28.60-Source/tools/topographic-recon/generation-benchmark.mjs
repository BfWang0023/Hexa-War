import fs from 'node:fs';import {newMap,setTerrain} from '../../web3d/ancient/engine.mjs';import {ensureAutoElevation,elevationGenerationStats,regenerateElevation} from '../../web3d/ancient/auto-elevation.mjs';
const m=newMap(160,100);for(let r=8;r<92;r++)for(let c=8;c<152;c++)m.terrain[r*160+c]=2;
const full=[];for(let i=0;i<10;i++)full.push(regenerateElevation(m).milliseconds);const edits=[];for(let i=0;i<40;i++){setTerrain(m,40+i,40+i%10,i%2?2:0);edits.push(elevationGenerationStats(m));}
const summary=xs=>{const a=[...xs].sort((a,b)=>a-b);return {min:a[0],median:a[Math.floor(a.length/2)],p95:a[Math.floor(a.length*.95)],max:a.at(-1)}};
fs.writeFileSync('docs/topographic-recon-20261029/generation-performance.json',JSON.stringify({cells:16000,fullRuns:10,localRuns:40,fullMs:summary(full),localMs:summary(edits.map(x=>x.milliseconds)),maxVisited:Math.max(...edits.map(x=>x.visited)),heightRange:[Math.min(...m.elevations),Math.max(...m.elevations)]},null,2));
