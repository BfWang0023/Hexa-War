from pathlib import Path
p=Path('web3d/ancient/engine.mjs');s=p.read_text()
light={'chariot':'skirmisher','parthianHorseArcher':'skirmisher','numidianHorse':'skirmisher','masinissaHorse':'skirmisher','masinissa':'skirmisher','cavalry':'maneuver','romanAlliedHorse':'maneuver','zamaPunicHorse':'maneuver'}
shock=['companionCavalry','parthianCataphract','pompeyHorse','romanHorse','punicHeavyHorse','chinaHeavyChariot','hittiteChariot','scythedChariot']
for kind,role in light.items():
 import re
 s=re.sub(r'(^  '+kind+r': \{ )(?:chargeClass: \'cavalry\', )?',lambda m:m[1]+"mountedRole: '"+role+"', ",s,flags=re.M)
for kind in shock:s=s.replace('  '+kind+': { chargeClass:',"  "+kind+": { mountedRole: 'shock', chargeClass:")
s=s.replace('18, 19, RULES_VERSION','18, 19, 20, RULES_VERSION')
s=s.replace('chargeClass(s.map,u)','chargeClass(s.map,u,s.rulesVersion)')
s="import {lightMobileAction} from './light-mobile-ai.mjs';\n"+s
needle='      const capture = captureGoal(u);'
insert="""      // Role policy sees only this faction's planning view; movement and attacks
      // remain separate paid engine actions. Commander protection stays above it.
      const mobileAction=lightMobileAction(s,u,{attacked:actions.some(a=>a.id===u.id&&a.type==='attack'),moved:actions.some(a=>a.id===u.id&&a.type==='move'),policyScore});
      if(mobileAction){
        if(mobileAction.type==='hold')break;
        if(mobileAction.type==='move'){const from={c:u.c,r:u.r},to=mobileAction.to,result=move(s,u.id,to.c,to.r);if(result.ok){actions.push({type:'move',id:u.id,from,to:{...to,path:result.path},result,roleIntent:mobileAction.intent});continue;}break;}
        const t=mobileAction.target,result=attack(s,u.id,t.c,t.r,rng(),rng(),rng(),rng());
        if(result.ok){actions.push({type:'attack',id:u.id,c:t.c,r:t.r,result,roleIntent:mobileAction.intent});continue;}break;
      }
"""
s=s.replace(needle,insert+needle);p.write_text(s)
p=Path('web3d/ancient/elevation-rules.mjs');p.write_text(p.read_text().replace('RULES_VERSION = 20','RULES_VERSION = 21'))
p=Path('web3d/ancient/charge-rules.mjs');s=p.read_text();s=s.replace('export function chargeClass(m,u){const c=u&&unitStats(m,u).chargeClass;',"// Older saves retain their explicit historical cavalry eligibility. New games use only shock profiles.\nconst legacyLightCharge=new Set(['cavalry','romanAlliedHorse','zamaPunicHorse','parthianHorseArcher','numidianHorse','masinissa','masinissaHorse']);\nexport function chargeClass(m,u,rulesVersion=21){const stat=u&&unitStats(m,u),c=rulesVersion<21?(stat?.chargeClass||(legacyLightCharge.has(u?.kind)?'cavalry':null)):(stat?.mountedRole==='shock'?stat.chargeClass:null);")
s=s.replace('chargeClass(s.map,u)','chargeClass(s.map,u,s.rulesVersion)');p.write_text(s)
p=Path('web3d/ancient/tactical-command.mjs');p.write_text(p.read_text().replace('chargeClass(j.map,u)','chargeClass(j.map,u,j.rulesVersion)'))
p=Path('web3d/ancient/app.mjs');p.write_text(p.read_text().replace('chargeClass(m,u)','chargeClass(m,u,game.rulesVersion)'))
p=Path('web3d/ancient/charge-copy.mjs');s=p.read_text().replace("if(!usesChargeRules(s)||!u||!unitStats(s.map,u).chargeClass)return '';const type=chargeClass(s.map,u);", "if(!usesChargeRules(s)||!u)return '';if(s.rulesVersion>=21&&['skirmisher','maneuver'].includes(unitStats(s.map,u).mountedRole))return '轻型机动兵种：保留普通近战；不享受两格冲锋增伤或冲锋专属暴击。移动与攻击分别消耗原行动力。';const type=chargeClass(s.map,u,s.rulesVersion);if(!type&&!unitStats(s.map,u).chargeClass)return '';")
s=s.replace('冲锋：骑兵×${cfg.cavalry',"冲锋：${s.rulesVersion>=21?'冲击型重骑兵':'骑兵'}×${cfg.cavalry");p.write_text(s)
p=Path('web3d/ancient/unit-registry.mjs');s=p.read_text();s="import {chargeClass} from './charge-rules.mjs';\n"+s;s=s.replace('buildUnitRegistry(map,team){','buildUnitRegistry(map,team,rulesVersion=21){').replace('charge:stats.chargeClass||null','charge:chargeClass(map,{kind:id,team,hp:1},rulesVersion),mountedRole:stats.mountedRole||null').replace('registryVocabulary(map,team){return buildUnitRegistry(map,team)','registryVocabulary(map,team,rulesVersion=21){return buildUnitRegistry(map,team,rulesVersion)');p.write_text(s)
p=Path('web3d/ancient/order-parser.mjs');p.write_text(p.read_text().replace('buildUnitRegistry(context.state?.map,context.team)','buildUnitRegistry(context.state?.map,context.team,context.state?.rulesVersion)'))
p=Path('web3d/ancient/battlefield-context.mjs');s=p.read_text().replace('registryVocabulary(state.map,team)','registryVocabulary(state.map,team,state.rulesVersion)').replace('requires:"合法连续接近至少2格后立即近战；其他行动中断；引擎判定，禁止伪造"','requires:state.rulesVersion>=21?"仅冲击型重骑兵/重战车；轻型骑兵/战车无增伤或冲锋暴击。移动和近战分步付费；最后两步持续接近；引擎判定":"合法连续接近至少2格后立即近战；其他行动中断；引擎判定，禁止伪造"');p.write_text(s)
p=Path('web3d/ancient/rules-manual.mjs');s=p.read_text().replace('`骑兵／近战重战车合法连续接近',"`${v>=21?'冲击型重骑兵（轻型骑兵/战车不享受此加成及专属暴击）':'骑兵'}／近战重战车合法连续接近");p.write_text(s)
# Keep historical eligibility tests explicitly tied to their v15 fixture.
p=Path('web3d/ancient/charge-bonus.test.mjs');s=p.read_text().replace('chargeClass(f.s.map,f.a)','chargeClass(f.s.map,f.a,f.s.rulesVersion)');p.write_text(s)
for name in ['classical-expansion.test.mjs','order-officer.test.mjs']:
 p=Path('web3d/ancient',name);s=p.read_text().replace('rulesVersion,20','rulesVersion,21').replace('authorized v20 naval profile','authorized v21 mounted roles');p.write_text(s)
