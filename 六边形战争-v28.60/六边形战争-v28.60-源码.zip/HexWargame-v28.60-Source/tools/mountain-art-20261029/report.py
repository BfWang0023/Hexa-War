from pathlib import Path
import json,hashlib,re
out=Path('docs/mountain-art-20261029');read=lambda n:json.loads((out/n).read_text());before,after=read('before-visual.json'),read('after-visual.json');baseline=read('before/hashes.json');modified=[k for k,h in baseline.items() if Path(k).is_file() and hashlib.sha256(Path(k).read_bytes()).hexdigest()!=h];added=[str(p) for p in Path('web3d/ancient').glob('*.mjs') if str(p) not in baseline];protected=['engine.mjs','auto-elevation.mjs','elevation-rules.mjs','fog-policy.mjs','knowledge-mist.mjs','reconnaissance.mjs','save.mjs','terrain.mjs','terrain-environment.mjs','app.mjs'];audit={'modified':modified,'added':added,'protectedUnchanged':{n:hashlib.sha256(Path('web3d/ancient',n).read_bytes()).hexdigest()==baseline['web3d/ancient/'+n] for n in protected},'manualMapsUnchanged':all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==h for k,h in baseline.items() if '/bundled-maps/' in k)};assert all(audit['protectedUnchanged'].values()) and audit['manualMapsUnchanged'];(out/'source-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
text=(out/'all-tests.txt').read_text();passed=re.findall(r'# pass (\d+)',text)[-1];assert re.findall(r'# fail (\d+)',text)[-1]=='0';rows=[]
for key,name in [('performance','复现场景 40×30'),('large','长平 4,428 格 / 384 棋子（含工事）')]:
 a,b=before[key],after[key];assert a['camera']==b['camera'];rows.append(f"|{name}|{a['averageFPS']:.2f} → {b['averageFPS']:.2f}|{a['low1FPS']:.2f} → {b['low1FPS']:.2f}|{a['drawCalls']} → {b['drawCalls']}|{a['triangles']:,} → {b['triangles']:,}|{a['heapAfterGCBytes']/1048576:.1f} → {b['heapAfterGCBytes']/1048576:.1f}|")
report=f'''# 山地视觉微调 v14.2：实现与验证

2026-10-29。小范围视觉补丁；战斗及存档规则仍为 v14。

## 主要变化

山地连续表面的视觉纵向比例从 3 调到 4.6，增加跨越十余格延伸的主脊、次脊和低频鞍谷变化。宽阔山体内部的视觉变化比山麓明显，狭窄低山带不会被抬成独立尖锥。继续使用原有全局连续高度场与共享边界，不增加六角柱、独立山峰模型或随机装饰。

按最新要求调整海拔配色：平原为低饱和草绿；山脚较深绿；中低山坡保持绿色，逐渐过渡灰绿；只有高海拔顶部和山脊出现暖灰岩色；极高处才出现少量近雪白。颜色按平滑插值的正式逻辑高程和实际坡面法线计算，在跨格边界连续，不直接按相机或随机装饰颜色计算。

|逻辑高程美术区间|主要表现|
|---|---|
|平原 0 附近|低饱和草绿|
|0.08–0.7|向深绿色山脚过渡|
|0.7–1.8|深绿山坡|
|1.8–3.8|逐渐转灰绿/橄榄绿|
|4.1–6.6|高处逐渐出现暖灰岩色|
|7.2–9.2|极高峰脊逐渐接近暖白，较缓顶部更明显|

这些是现有抽象逻辑高程的美术阈值，不是现实米数，也不新增冰雪移动或伤害规则。低山同样有深绿基调，不再沿用平原草绿/黄绿色；颜色保底按连续的山地区域覆盖率过渡，避免地形边缘生硬跳色。低海拔陡坡仍以绿色为主，不因坡度较陡就全部变灰。沙漠、干旱及条顿堡森林等特殊配色保留。

坡面明暗继续使用原有解析法线，由增强后的连续表面生成，另加轻量的法线驱动漫反射色调。没有改动全局光源、增加实时灯光、开启强烈山体投影或引入后处理。没有增加模型面数或装饰数量。道路和单位继续通过同一个实际网格采样接口贴地，桥梁和渡口维持原有水位与结构。

## 规则和信息安全

`engine.mjs`、`auto-elevation.mjs`、`elevation-rules.mjs`、迷雾权限和渲染模块、存档、全局光照、应用交互均保持原文件哈希。42 张人工地图原始内容不变。没有重生成或写回逻辑高程，没有更改移动预算、射程或高低差伤害。

增强后的表面仍只读取权限层提供的地图。未知区域的真实山地修改不会改变其允许访问的视觉高度场；不额外读取隐藏地图。Terrain Fog 仍保留三层状态和软边界。单位底座、兵模和生命/士气条使用原有地表/模型定位流程，没有另建一套高度判定。

## 实际画面验证

以同一张包含平原、山麓、连续山区、山路、河流、桥梁与渡口的 40×30 战场，对保存的旧代码和新代码分别运行，同镜头对照：

- `before-overview.png` / `after-overview.png`：完整地形、常用斜俯视。
- `before-mountain-low.png` / `after-mountain-low.png`：近地低视角、道路与坡面、兵模底座。
- `before-distant.png` / `after-distant.png`：拉远整体山势。
- `before-top.png` / `after-top.png`、`before-oblique.png` / `after-oblique.png`、`before-low.png` / `after-low.png`：相同战场开启地形迷雾，验证未知地形继续遮蔽。
- `before-reveal-*.png` / `after-reveal-*.png` 与 `reveal.webm`：通过游戏选格/移动处理实际执行高地弓兵侦察，保留 350 ms 揭雾。
- `after-extreme-highland.png`：额外 80×60 自动生成的宽阔山区，最高逻辑高程 {after['highland']['maxLogical']}，用于检查极高峰脊的暖白过渡；没有手动指定高度。
- `before-changping.png` / `after-changping.png`：长平代表性大地图。

当前消息未另附可读取的新截图文件，故采用同版本的可复现场景做固定相机对照，不宣称像素级匹配用户原截图。三个主要视角均实际打开检查，浏览器页面和着色器错误为 0。地形迷雾关闭后完整地形恢复。

## 测试

全量 Node 回归 {passed} 项通过，0 失败。新增 8 项专项测试覆盖连续高度增强、海拔/坡度配色、低坡深绿与极高雪色、逻辑状态/伤害不变、隐藏山地不泄露，实际顶点颜色缓冲、低山与平原色差，以及跨块共享高度、法线与颜色无缝衔接。既有单位、道路、桥渡、规则、AI、存档和双迷雾测试保留。

实际侦察移动消耗 1 AP，未知格数 {after['scout']['before']} → {after['scout']['after']}。运行记录见 `before-visual.json`、`after-visual.json`、`all-tests.txt` 和 `focused-tests.txt`。

## 性能

设备 Apple M4 16 GB，Chrome，1440×1000，DPR=1。前后使用相同场景、实际部署数量、固定镜头和标准画质，每场采样 600 帧。1% Low 是最慢 6 帧平均帧间隔的倒数。JS 堆在相同强制 GC 步骤后读取，不是进程总内存或 GPU 显存。

|场景|平均 FPS 前→后|1% Low 前→后|Draw Calls 前→后|三角形 前→后|GC 后 JS 堆 MiB 前→后|
|---|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

沿用原有网格细分和静态分块缓存；高度与颜色在网格构建时计算，没有增加逐帧几何或光照计算。更高的山体可能改变镜头裁剪结果，因此实际提交三角形数可能随固定镜头变化；不是通过减少地图或兵力提升帧率。

## 修改清单与边界

{chr(10).join('- `'+x+'`' for x in modified+added)}

验证脚本在 `tools/mountain-art-20261029/`；代码基线在 `before/`；保护文件和地图检查见 `source-audit.json`。

M1、原生 WKWebView 长期性能未测；此处 FPS 为短期样本。雪色仅为极高处的视觉表达，没有新增气候机制。低视角下山脊仍会自然遮住后方地物，战术视角下保留原有选择和状态条流程。没有重新制作全部 85 场战役截图，以全量自动化回归和上述代表场景验证交付。

安装包独立解压、签名与网页资源一致性见 `package-verification.json`。
'''
(out/'山地视觉微调验证报告.md').write_text(report)
