from pathlib import Path
import json,hashlib,re,math
out=Path('docs/spectator-follow');b=json.loads((out/'browser.json').read_text());f=json.loads((out/'fog-browser.json').read_text());base=json.loads((out/'before/hashes.json').read_text());tests=(out/'all-tests.txt').read_text();passed=int(re.findall(r'# pass (\d+)',tests)[-1]);assert re.findall(r'# fail (\d+)',tests)[-1]=='0' and not b['errors'] and not f['errors']
modified=[k for k,h in base.items() if Path(k).is_file() and hashlib.sha256(Path(k).read_bytes()).hexdigest()!=h]
expected={'web3d/ancient/'+n for n in ['app.mjs','soldier-camera.mjs','soldier-camera.test.mjs','style.css','hero-regalia.test.mjs','historical-models.test.mjs','support-models.test.mjs']};assert set(modified)==expected
protected=['engine.mjs','unit-animation.mjs','full-models.mjs','weapon-effects.mjs','fog-policy.mjs','auto-elevation.mjs','elevation-rules.mjs','save.mjs','terrain.mjs','terrain-environment.mjs','mountain-visual.mjs'];audit={'modified':modified,'protectedUnchanged':{n:hashlib.sha256(Path('web3d/ancient',n).read_bytes()).hexdigest()==base['web3d/ancient/'+n] for n in protected},'manualMapsUnchanged':all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==h for k,h in base.items() if '/bundled-maps/' in k)};assert all(audit['protectedUnchanged'].values()) and audit['manualMapsUnchanged'];(out/'source-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
text=f'''# v14.4 观战士兵跟随视角修复

2026-10-29。战斗及存档规则仍为 v14；继承 v14.3 地形美术。

## 修复结果与原因

观战不再重新创建当前战役，已有士兵跟随、镜头参数、动画队列、回合和行动资源得到保留。AI换边时，跟随观察采用所选目标所属阵营的情报，不再随着行动方换边，从而避免原目标突然被另一阵营迷雾过滤、模型移除并退出跟随。自由观战仍沿用原有按行动方观察的方式。

原先的阵亡处理会调用停止跟随及沙盘定位，立即改变镜头位置和焦距。现在引入独立的停留状态：目标阵亡、移除、登船或失去合法观察权限后，保留最后渲染的位置、方向和焦距，只提示玩家重新选择；默认不自动选择其他士兵。有效目标仅因模型暂时重建而缺少网格时，保留目标ID并等待模型恢复。

只有玩家主动返回沙盘、切换地图/重新开始/读档或进入编辑器等明确操作，才按原约定清理跟随。编辑器启动地图及两个普通人类控制模式之间的切换仍保留原先重开战局的行为；观战的进入/退出保持当前战局。

云台原有的转向限速75°/秒、响应时间0.22秒、单帧时间上限50ms和头顶稳定锚点保持不变。相机继续读取本体与底座共同的实际插值位置，不读取已提前提交的规则终点，不新增位置平滑滞后。

额外修复小地图覆盖跟随工具条、导致“返回沙盘”按钮无法点击的问题。跟随及停留期间，小地图根据工具条实际高度自动下移，窗口改变尺寸时同步调整。

## 使用方式

1. 选中士兵，点击“士兵视角”并进入跟随。
2. 将“交战”切换为“电脑 vs 电脑”，直接观战当前局。可暂停、单步或调整速度，跟随保留。
3. “更换部队”可选择当前情报规则允许观察的士兵；观战可切换至已可选择的另一阵营士兵，并采用该阵营视野。不会开放未发现敌军列表。
4. “返回沙盘”或Esc主动退出；随后可以自由拖动相机。
5. 阵亡后镜头停留，手动选择新目标，或返回沙盘。没有自动挑选下一名士兵的行为。

退出观战恢复人类控制时，己方有效目标继续跟随。若原来跟随敌方而新控制模式不再允许跟随敌军，则保留最后画面并提示重选，不继续跟踪隐藏敌军，也不回到地图中心。人机模式退出观战时，如果当前轮到电脑，沿用现有电脑行动接口完成其行动后交还玩家；不修改AI算法。

## 实际验证

全部 Node 回归 **{passed} 项通过，0失败**。专项相机/云台和模型集成检查49项通过。

浏览器使用Apple M4/16GB、Chrome、1440×1000运行实际游戏，不使用模拟相机或模拟行动返回值。主流程{len(b['checks'])}项断言及标准迷雾流程{len(f['checks'])}项断言通过，页面与着色器错误0。

- 进入观战：确认游戏对象身份、回合、当前行动方、单位生命与行动资源不变，目标ID、位置与焦距保留。
- 连续六次AI半回合推进至第4回合，再通过真实自动调度器推进。跟随轻步兵由第10列行军至第28列，涵盖绕过河流的转向；长距离行军场景明确配置Unit Fog OFF，使双方AI能获知目标，未修改AI寻敌逻辑。
- 记录{len(b['frames'])}个实际渲染帧，相机在X/Z上与模型根锚点一致，Y保持既定头顶高度，误差检查阈值1e-6。实际绕行最大单帧转角约{math.degrees(b['maxAngularStepRadians']):.3f}°，逐帧通过原75°/秒及50ms上限检查。此为镜头正确性采样，不是专用FPS基准。
- 标准Unit Fog ON：四次AI换边保持己方跟随与隐藏敌军隔离；明确选择可见敌军后，两次换边保持该目标阵营视野，未显示另一方隐藏君主。真实AI近战发生期间跟随保持。
- 近战和远程：调用真实规则引擎产生合法攻击与实际动画队列，相机保持跟随。
- 致死攻击：真实规则结算造成阵亡，镜头位置、旋转和60°跟随焦距保持；等待后无自动换人，手动换目标恢复跟随。
- 实际鼠标点击验证更换目标、返回沙盘；Esc退出后右键拖动相机成功；退出观战的友军跟随继续有效。
- 编辑器开局及非观战控制模式切换的既有行为通过浏览器回归。
- 自动化继续覆盖模型替换、近远LOD、抖动过滤、±π转向、30/60/144Hz一致性、各类兵种锚点、临时缺少模型、死亡重复通知和镜头恢复。

截图：

|场景|真实截图|
|---|---|
|进入观战前已启用跟随|[截图]({(out/'before-spectator.png').resolve()})|
|AI连续行军后仍跟随|[截图]({(out/'after-ai-march.png').resolve()})|
|近战攻击|[截图]({(out/'heavy-attack.png').resolve()})|
|远程攻击|[截图]({(out/'archer-attack.png').resolve()})|
|阵亡后保留观察位置并提示|[截图]({(out/'death-holds-position.png').resolve()})|
|标准迷雾下跟随敌方观察阵营|[截图]({(out/'standard-fog-enemy-follow.png').resolve()})|

原始记录：`browser.json/txt`、`fog-browser.json/txt`、`all-tests.txt`、`focused-tests.txt`。测试脚本在`tools/spectator-follow/`。

## 兼容性与文件

规则引擎、AI实现、单位动画和效果、正式高程、地形视觉、迷雾权限、存档文件及42张人工地图逐字节保持不变；见`source-audit.json`。没有新增存档字段，跟随与停留为临时呈现状态。

三个历史模型测试原先锁定整个app文件哈希，会拒绝任何合法相机改动。保留原始基线哈希和模型/动画断言，改为验证原始app完整性，并只允许相机选择回调、观战观察阵营、沙盘更新保护、模式切换处理这四处授权变更；其余app内容逐字节比较。另有测试确认篡改动画更新调用仍会被拒绝。没有修改历史基线文件或删除测试。

实际游戏代码及测试修改：

{chr(10).join('- `'+x+'`' for x in modified)}

新增验证辅助：`tools/spectator-follow/app-integrity.mjs`、`verify.cjs`、`fog.cjs`、`report.py`、`package.py`；基线/报告/截图位于`docs/spectator-follow/`。两份根目录交接说明增加补丁记录。

## 交付与范围

`dist/spectator-follow/古代战役-v02-macOS.zip`为新桌面包；`六边形战争-v14.4-观战跟随修复源码.zip`为完整源码。构建、独立解压签名与245个网页资源一致性检查见`build.txt`和`package-verification.json`。

本次没有重跑85场战役逐场视觉巡检；全部规则/战役/迷雾/存档自动化测试通过，运行验证聚焦上述相机场景。没有新增通用地形碰撞相机或自动选择继任目标，继续使用原有贴地模型和头顶高度范围。M1及原生WKWebView长时间运行未另测；不宣称本轮有新的性能提升。构建保留两条原有Rust警告，不影响构建成功。
'''
(out/'观战跟随修复验证报告.md').write_text(text);print('report ready',passed,'tests')
