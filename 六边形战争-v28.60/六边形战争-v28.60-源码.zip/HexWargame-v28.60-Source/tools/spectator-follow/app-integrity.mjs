import {beforeInteraction} from '../interaction-v19/integrity.mjs';
// Historical model tests used to freeze the entire app. Retain their original
// hash and compare every byte outside the four authorized camera integration edits.
import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const source=fs.readFileSync(new URL('../../docs/spectator-follow/before/app.mjs',import.meta.url),'utf8');
export function assertCameraOnlyAppChange(expectedHash,current=fs.readFileSync(new URL('../../web3d/ancient/app.mjs',import.meta.url),'utf8')){
 assert.equal(crypto.createHash('sha256').update(source).digest('hex'),expectedHash,'original app baseline is intact');
 current=beforeInteraction('app.mjs',current);
 function mask(text){
  text=text.replace("import {appendCaptureControls} from './fortification-capture-ui.mjs';\n",'').replace("  if(u&&!editing&&humanCanAct()&&u.team===playerTeam)appendCaptureControls({document,card,state:game,u,hint,refresh});\n",'');
  text=text.replace("const savedAge=localStorage.getItem('ancient-casualty-age');casualtyAge=savedAge!==null&&[0,4,8,16,32].includes(Number(savedAge))?Number(savedAge):8;", "casualtyAge=Number(localStorage.getItem('ancient-casualty-age'))||8;");
  text=text.replace("if (battleMode === 'human-ai'||game.battlePhase==='pursuit') for (let i = before;", "if (battleMode === 'human-ai') for (let i = before;");
  text=text.replace("battleMode === 'human-human'&&!game.battleOutcome ? !game.logOwners", "battleMode === 'human-human' ? !game.logOwners");

  text=text.replace("import {bindBattleEndingUI} from './battle-ending-ui.mjs';\n",'');
  text=text.replace("\nbindBattleEndingUI({document,getState:()=>game,getTeam:()=>playerTeam,getMode:()=>battleMode,label:victoryLabel,refresh,observe:team=>{playerTeam=team;},enemyTurn:()=>{playComputerTurn();refresh();}});\n",'');
  text=text.replace("if (!game.over && (battleMode === 'human-ai'||game.battlePhase==='pursuit')) playComputerTurn(before);", "if (!game.over && battleMode === 'human-ai') playComputerTurn(before);");
  text=text.replace("if (!game.over && !game.battleOutcome && battleMode === 'human-human') { playerTeam", "if (!game.over && battleMode === 'human-human') { playerTeam");

  text=text.replace("import {chargeUnitCopy,normalizeChargeCopy,updateChargeHelp} from './charge-copy.mjs';\n",'');
  text=text.replace("  const chargeLine=chargeUnitCopy(game,u);if(chargeLine)lines.push(chargeLine);\n  for (const line of lines.map(line=>normalizeChargeCopy(game,line)).filter(Boolean))", "  for (const line of lines)");
  text=text.split("  updateChargeHelp(game,$('help-body'));\n").join('');

  text=text.replace("import {chargeClass,chargeText} from './charge-rules.mjs';\n",'');
  text=text.replace("(preview?.elevation?'\\n'+elevationText(preview.elevation):'')+\n        (game.rulesVersion>=15&&chargeClass(m,u)?'\\n'+(preview?.chargeBonus?chargeText(preview.chargeBonus):'冲锋：本回合连续接近目标至少两格后立即近战；不能累积往返距离'):'');","(preview?.elevation?'\\n'+elevationText(preview.elevation):'');");

  text=text.replace("'+(game.rulesVersion>=15?'骑兵与近战重型战车需在同回合连续接近目标至少两格后立即近战，默认分别获得1.25与1.30倍伤害；不能累计往返步数。':'波斯镰刀战车移动至少2格后冲击未以方阵正面迎击的目标会额外造成3.0伤害。')+'",'波斯镰刀战车移动至少2格后冲击未以方阵正面迎击的目标会额外造成3.0伤害。');
  text=text.replace(/selected: id => \{[^\n]*?\}, isEditing:/,'<camera-selection>, isEditing:');
  text=text.replace("  // Follow uses the chosen faction's intelligence across both AI turns.\n  if (!soldierCamera.engaged) playerTeam = game.side;","  playerTeam = game.side;");
  text=text.replace('function updateCamera() {\n  if (soldierCamera.engaged) return;','function updateCamera() {\n  if (soldierCamera.active) return;');
  text=text.replace(/\$\('battle-mode'\)\.onchange = ev => \{[\s\S]*?(?=\$\('ai-difficulty'\)\.onchange)/,'<mode-switch>\n');
  return text;
 }
 assert.equal(mask(current),mask(source),'non-camera application integration must remain byte-identical');
}
