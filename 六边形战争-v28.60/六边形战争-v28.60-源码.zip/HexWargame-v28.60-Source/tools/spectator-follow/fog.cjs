const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),assert=require('assert/strict'),out='docs/spectator-follow';
(async()=>{const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),p=await b.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1}),data={checks:[],errors:[]};
const check=(name,value)=>{assert.ok(value,name);data.checks.push(name);console.log('PASS',name)};
p.on('pageerror',e=>data.errors.push(e.message));p.on('console',m=>{if(m.type()==='error')data.errors.push(m.text())});
try{
 await p.route('**/ancient/app.mjs',async r=>{const response=await r.fetch();await r.fulfill({response,body:(await response.text()).replace('bootSavedMaps().catch(e => hint(e.message));','window.__ready=false;bootSavedMaps().catch(e=>hint(e.message)).finally(()=>window.__ready=true);')+`
 window.__cam={view:soldierCamera,ui:soldierCameraUI,camera,renderer,anim:unitAnimator,get game(){return game},get models(){return unitModels},get team(){return playerTeam},get mode(){return battleMode},get map(){return currentMap()},get running(){return autoRunning},refresh,rebuildScene,clickCell,unitScreen,setup(m){cancelAutoTurn();scenario=m;startForPlayer();autoRunning=false;cancelAutoTurn();selectedId=null;refresh();rebuildScene();}};
 window.__actions=[];const actionTrace=unitAnimator.actions;unitAnimator.actions=function(actions,...args){__actions.push(...structuredClone(actions));return actionTrace.call(this,actions,...args)};
 `});});
 await p.goto('http://127.0.0.1:8840/ancient/?scenario=megiddo');await p.waitForFunction(()=>__ready&&window.__cam);
 
 async function setup(close=false){await p.evaluate(async close=>{const E=await import('/ancient/engine.mjs'),m=E.newMap(44,24);m.scenarioId='custom_follow_fog';E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,'hittiteKing','coalition',43,23);E.addUnit(m,'light','egypt',10,12);E.addUnit(m,'guard','coalition',close?11:37,12);__cam.setup(m);},close);}
 async function follow(kind){const id=await p.evaluate(kind=>__cam.map.units.find(u=>u.kind===kind)?.id,kind);assert.ok(id);await p.locator('#soldier-view').click();await p.selectOption('#camera-unit',id);await p.locator('#camera-confirm').click();return id;}
 await setup();const own=await follow('light');await p.selectOption('#battle-mode','ai-ai');await p.locator('#auto-toggle').click();
 for(let i=0;i<4;i++){await p.locator('#auto-step').click();await p.waitForTimeout(150);check('default fog half-turn '+i+' keeps own target and hidden enemy isolation',await p.evaluate(id=>__cam.game.fogPolicy.unitFog===true&&__cam.view.id===id&&__cam.team==='egypt'&&__cam.map.units.every(u=>u.team==='egypt'),own));}
 await p.locator('#follow-exit').click();await setup(true);const enemy=await follow('guard');check('explicit visible enemy follow uses its faction intelligence',await p.evaluate(id=>__cam.team==='coalition'&&__cam.view.id===id&&!__cam.map.units.some(u=>u.kind==='pharaoh'),enemy));
 for(let i=0;i<2;i++){await p.locator('#auto-step').click();await p.waitForTimeout(500);check('enemy target survives observer-side AI change '+i,await p.evaluate(id=>__cam.view.id===id&&__cam.view.active&&__cam.team==='coalition',enemy));}
 data.aiAttacks=await p.evaluate(()=>__actions.filter(a=>a.type==='attack').map(a=>({type:a.type,ok:a.result?.ok,from:a.result?.visual?.from,to:a.result?.visual?.to})));check('real AI combat occurred while following',data.aiAttacks.some(a=>a.ok));
 await p.screenshot({path:out+'/standard-fog-enemy-follow.png'});
 await p.selectOption('#battle-mode','human-ai');await p.waitForFunction(()=>__cam.view.holding);check('leaving spectator does not bypass enemy follow permissions or recenter',await p.evaluate(()=>__cam.view.holding&&!__cam.view.active));
 await p.keyboard.press('Escape');const free=await p.evaluate(()=>__cam.camera.position.toArray());await p.mouse.move(820,650);await p.mouse.down({button:'right'});await p.mouse.move(920,700,{steps:8});await p.mouse.up({button:'right'});check('manual exit permits free camera movement',await p.evaluate(a=>__cam.camera.position.toArray().some((v,i)=>Math.abs(v-a[i])>.01),free));
 await p.evaluate(()=>window.__previousBattle=__cam.game);await p.selectOption('#battle-mode','human-human');check('non-spectator control-mode changes retain legacy restart behavior',await p.evaluate(()=>__cam.game!==__previousBattle));
 await p.evaluate(()=>window.__previousBattle=__cam.game);await p.locator('#editor').click();await p.selectOption('#battle-mode','ai-ai');check('starting from editor still creates the edited battle',await p.evaluate(()=>__cam.game!==__previousBattle&&!__cam.view.engaged&&document.getElementById('editor-panel').classList.contains('hidden')));
 check('no browser or shader errors',!data.errors.length);
}finally{fs.writeFileSync(out+'/fog-browser.json',JSON.stringify(data,null,2));await b.close();}})().catch(e=>{console.error(e);process.exitCode=1});
