from pathlib import Path
import json,subprocess,tempfile,hashlib,zipfile
root=Path.cwd();out=root/'dist/gates-release';docs=root/'docs/gates-release';app=out/'古代战役.app';data={}
# Clear Finder-added metadata from the newly generated output bundle, not source files.
for _ in range(3):
 subprocess.run(['xattr','-cr',str(app)],check=True)
 result=subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,text=True)
 if result.returncode==0:break
data['outputAppSignatureValid']=result.returncode==0
with tempfile.TemporaryDirectory(prefix='terrain-refine-package-') as tmp:
 subprocess.run(['ditto','-xk',str(out/'古代战役-v02-macOS.zip'),tmp],check=True)
 unpack=Path(tmp)/'古代战役.app'
 r=subprocess.run(['codesign','--verify','--deep','--strict',str(unpack)],capture_output=True,text=True)
 data['zipSignatureValid']=r.returncode==0;data['mismatches']=[];count=0
 for source in (root/'web3d').rglob('*'):
  if source.is_file() and source.name!='.DS_Store':
   target=unpack/'Contents/Resources/web3d'/source.relative_to(root/'web3d');count+=1
   if not target.is_file() or source.read_bytes()!=target.read_bytes():data['mismatches'].append(str(source.relative_to(root)))
 data['verifiedWebFiles']=count
assert data['zipSignatureValid'] and data['outputAppSignatureValid'] and not data['mismatches'],data
(docs/'package-verification.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
# Do not include any credentials, build products or previous release archives.
roots=['src','web3d','assets','desktop','docs','examples','maps','tools'];files=[]
for folder in roots:
 files.extend(p for p in (root/folder).rglob('*') if p.is_file())
files.extend(p for p in root.iterdir() if p.is_file() and (p.suffix in ['.md','.toml','.lock','.sh','.cmd','.txt'] or p.name=='.gitignore'))
sourcezip=out/'六边形战争-v28.13-城门升级源码.zip';excluded=[]
with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):
  rel=p.relative_to(root);name=p.name.lower()
  if any(s in rel.parts for s in ['node_modules','target','__pycache__']) or name=='.ds_store' or 'apikey' in name or name.startswith('.env') or p.suffix.lower() in ['.pem','.key']:
   excluded.append(str(rel));continue
  z.write(p,'六边形战争-v28.13/'+str(rel))
 assert z.testzip() is None
checks={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'古代战役-v02-macOS.zip',sourcezip]}
(out/'SHA256SUMS.txt').write_text(''.join(v+'  '+k+'\n' for k,v in checks.items()))
(out/'交付校验.json').write_text(json.dumps({**data,'sha256':checks,'excludedCredentialFiles':len(excluded)},ensure_ascii=False,indent=2));print(json.dumps(data,ensure_ascii=False));print(sourcezip)
