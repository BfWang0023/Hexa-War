from pathlib import Path
import difflib,json
old=Path('docs/navigation-v20/before/app.mjs').read_text();new=Path('web3d/ancient/app.mjs').read_text();a=old.splitlines(keepends=True);b=new.splitlines(keepends=True);changes=[]
for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
 if op!='equal':changes.append(dict(at=len(''.join(b[:k]).encode('utf-16-le'))//2,removed=''.join(a[i:j]),added=''.join(b[k:l])))
Path('docs/navigation-v20/authorized-app.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2))
