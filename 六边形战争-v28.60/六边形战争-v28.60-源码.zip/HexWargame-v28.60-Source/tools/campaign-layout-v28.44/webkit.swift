import AppKit
import WebKit

final class Check: NSObject, NSApplicationDelegate, WKNavigationDelegate {
    let web = WKWebView(frame: NSRect(x: 0, y: 0, width: 820, height: 752))
    var window: NSWindow!
    func applicationDidFinishLaunching(_ notification: Notification) {
        window = NSWindow(contentRect: web.frame, styleMask: [.titled], backing: .buffered, defer: false)
        window.contentView = web
        window.orderFront(nil)
        web.navigationDelegate = self
        web.load(URLRequest(url: URL(string: "http://127.0.0.1:8864/ancient/")!))
        DispatchQueue.main.asyncAfter(deadline: .now() + 30) { exit(2) }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        web.evaluateJavaScript("""
        document.querySelector('#navigation .menu-panel button').click();
        (() => {
          const checks = [];
          for (const series of ['dawn','axial','empire']) {
            document.querySelector('[data-series="'+series+'"]').click();
            const cards = [...document.querySelectorAll('.campaign-cover')];
            const visible = cards.every(button => {
              const row = button.parentElement.getBoundingClientRect();
              const title = button.querySelector('span').getBoundingClientRect();
              return row.height >= 120 && title.top >= row.top && title.bottom <= row.bottom;
            });
            const last = cards.at(-1);
            last.scrollIntoView();
            const list = document.querySelector('.campaign-list').getBoundingClientRect();
            const box = last.getBoundingClientRect();
            checks.push({series, count:cards.length, visible, lastReachable: box.bottom <= list.bottom+1});
            document.querySelector('#navigation .menu-panel > button').click();
          }
          return JSON.stringify(checks);
        })()
        """) { value, error in
            if let error { print(error); exit(1) }
            guard let value = value as? String, let rows = try? JSONSerialization.jsonObject(with: Data(value.utf8)) as? [[String: Any]] else { exit(1) }
            print(value)
            let good = rows.compactMap { $0["count"] as? Int }.reduce(0,+) == 96 &&
                rows.allSatisfy { ($0["visible"] as? Bool) == true && ($0["lastReachable"] as? Bool) == true }
            exit(good ? 0 : 1)
        }
    }
}
let check = Check()
NSApplication.shared.delegate = check
NSApplication.shared.run()
