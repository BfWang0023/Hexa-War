const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
  const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage({viewport:{width:1440,height:1000}});
  const dir='docs/campaign-layout-v28.44',errors=[],counts={};
  try {
    page.on('pageerror',e=>errors.push(e.message));
    await page.route('**/api/ancient/maps/*',async r=>{
      const id=new URL(r.request().url()).pathname.split('/').at(-1);
      const p=`web3d/ancient/bundled-maps/${id}.json`;
      return fs.existsSync(p)?r.fulfill({path:p,contentType:'application/json'}):r.fulfill({status:404});
    });
    await page.goto('http://127.0.0.1:8863/ancient/');
    await page.getByRole('button',{name:'战役选择',exact:true}).click();
    assert.equal(await page.locator('[data-series]').count(),3);
    for(const series of ['dawn','axial','empire']){
      await page.locator(`[data-series="${series}"]`).click();
      counts[series]=await page.locator('.campaign-cover img').count();
      await page.locator('.campaign-cover img').evaluateAll(imgs=>Promise.all(imgs.map(img=>{img.loading='eager';return img.decode();})));
      const cards=await page.locator('.campaign-cover').evaluateAll(buttons=>buttons.map(button=>{
        const row=button.parentElement.getBoundingClientRect(), title=button.querySelector('span').getBoundingClientRect();
        return {height:row.height, titleVisible:title.top>=row.top && title.bottom<=row.bottom};
      }));
      assert.ok(cards.every(card=>card.height>=120 && card.titleVisible),JSON.stringify({series,first:cards[0]}));
      const last=page.locator('.campaign-cover').last();
      await last.scrollIntoViewIfNeeded();
      await last.click();
      await page.getByRole('button',{name:'进入战役',exact:true}).waitFor();
      const start=page.getByRole('button',{name:'进入战役',exact:true});
      await start.scrollIntoViewIfNeeded();
      await start.click({trial:true});
      await page.locator('.campaign-cover').first().scrollIntoViewIfNeeded();
      await page.screenshot({path:`${dir}/${series}.png`});
      if(series!=='empire')await page.getByRole('button',{name:'← 返回系列',exact:true}).click();
    }
    assert.equal(Object.values(counts).reduce((a,b)=>a+b),96);
    await page.getByPlaceholder('搜索战役 / 年代').fill('井陉');
    await page.locator('[data-scenario=china_jingxing] > button').click();
    await page.getByRole('button',{name:'进入战役',exact:true}).waitFor();
    assert.match(await page.locator('.campaign-detail').innerText(),/汉军 对 赵军/);
    await page.screenshot({path:`${dir}/jingxing-cover.png`});
    await page.getByRole('button',{name:'进入战役',exact:true}).click();
    await page.waitForFunction(()=>document.body.dataset.page==='Battle');
    const status=await page.locator('header').innerText();
    assert.match(status,/赵军井陉阵地/);
    assert.doesNotMatch(status,/第\s*30\s*回合/);
    assert.deepEqual(errors,[]);
    fs.writeFileSync(`${dir}/browser.json`,JSON.stringify({counts,status,errors},null,2));
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
