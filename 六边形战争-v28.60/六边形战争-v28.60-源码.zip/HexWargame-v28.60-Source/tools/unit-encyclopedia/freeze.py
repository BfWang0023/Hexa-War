from pathlib import Path
import difflib,json,hashlib
out={}
for p in Path('docs/unit-encyclopedia/before').glob('*.mjs'):
 old=p.read_text().splitlines(keepends=True);new=Path('web3d/ancient',p.name).read_text().splitlines(keepends=True)
 out[p.name]=[dict(at=len(''.join(new[:c]).encode('utf-16-le'))//2,removed=''.join(old[a:b]),added=''.join(new[c:d])) for op,a,b,c,d in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes() if op!='equal']
Path('docs/unit-encyclopedia/authorized.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
p=Path('tools/interaction-v19/integrity.mjs');s=p.read_text();needle='export function beforeInteraction(name,text){'
if 'authorized encyclopedia' not in s:s=s.replace(needle,needle+"const encyclopedia=JSON.parse(fs.readFileSync(new URL('../../docs/unit-encyclopedia/authorized.json',import.meta.url)))[name];if(encyclopedia)for(const e of [...encyclopedia].reverse()){assert.equal(text.slice(e.at,e.at+e.added.length),e.added,'authorized encyclopedia/navigation patch');text=text.slice(0,e.at)+e.removed+text.slice(e.at+e.added.length);}")
p.write_text(s)
p=Path('docs/interaction-v19/authorized-core.json');data=json.loads(p.read_text());
for name in ['engine.mjs','save.mjs','elevation-rules.mjs']:
 data['web3d/ancient/'+name]=hashlib.sha256(Path('web3d/ancient',name).read_bytes()).hexdigest()
p.write_text(json.dumps(data,indent=2))
