import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const review=JSON.parse(fs.readFileSync(new URL('../../docs/visibility-v28.37/maps-reviewed.json',import.meta.url))),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
export function campaignContract(id,actual,historical){const r=review.campaigns[id];assert.ok(r?.historical.includes(historical),'unrecognized historical contract '+id);assert.equal(actual,r.current,id+' reviewed current map');}
export function bundledContract(name,bytes){assert.equal(sha(bytes),review.files[name],name+' reviewed current file');}
export const bundledCount=Object.keys(review.files).length;
export function currentSnapshot(name){return fs.readFileSync(new URL('../../docs/visibility-v28.37/maps/'+name,import.meta.url));}
