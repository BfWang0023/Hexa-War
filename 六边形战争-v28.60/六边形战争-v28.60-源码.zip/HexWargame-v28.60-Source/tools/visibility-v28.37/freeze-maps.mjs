// Run explicitly at release review, never by tests. Preserve every older baseline.
import fs from 'node:fs';import crypto from 'node:crypto';
import {CAMPAIGN_CATALOG} from '../../web3d/ancient/campaign-catalog.mjs';
import {mapFor} from '../ai-training/maps.mjs';import {exportMap} from '../../web3d/ancient/engine.mjs';
const hash=x=>crypto.createHash('sha256').update(x).digest('hex'),out={version:'28.37',reason:'Previously authorized user map edits, automated elevations, gates and control cores; old snapshots retained',campaigns:{},files:{}};
for(const c of CAMPAIGN_CATALOG)out.campaigns[c.id]={current:hash(JSON.stringify(exportMap(mapFor(c.id)))),historical:[]};
for(const path of ['docs/greek-expansion/before-existing-maps.json','docs/greek-expansion-2/before-existing-maps.json','docs/hellenistic-expansion/before-existing-maps.json'])for(const r of JSON.parse(fs.readFileSync(path)))out.campaigns[r.id].historical.push(r.sha256);
fs.mkdirSync('docs/visibility-v28.37/maps',{recursive:true});
for(const name of fs.readdirSync('web3d/ancient/bundled-maps').filter(n=>n.endsWith('.json'))){const b=fs.readFileSync('web3d/ancient/bundled-maps/'+name);out.files[name]=hash(b);fs.writeFileSync('docs/visibility-v28.37/maps/'+name,b);}
fs.writeFileSync('docs/visibility-v28.37/maps-reviewed.json',JSON.stringify(out,null,2));
