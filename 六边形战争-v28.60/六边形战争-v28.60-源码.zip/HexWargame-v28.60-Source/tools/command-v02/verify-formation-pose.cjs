const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),p=await b.newPage({viewport:{width:1440,height:1000}}),errors=[],checks=[];
 p.on('pageerror',e=>errors.push(e.message));
 await p.route('**/ancient/app.mjs',async route=>{const r=await route.fetch();await route.fulfill({response:r,body:(await r.text())+`\nwindow.__formation={get map(){return currentMap()},get game(){return game},get units(){return unitGroup},renderer,clickCell,refresh,rebuildScene,setup(m){scenario=m;startForPlayer();const v=offsetToWorld(5,6);target.set(v.x,0,v.z);cameraDistance=75;updateCamera();refresh();rebuildScene();}};`});});
 await p.goto('http://127.0.0.1:8816/ancient/?scenario=mantinea');await p.waitForFunction(()=>window.__formation);
 await p.evaluate(async()=>{const E=await import('/ancient/engine.mjs'),m=E.newMap(20,14);m.scenarioId='custom_formation_demo';m.name='希腊与罗马列阵姿态验收';E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,'light','coalition',19,13);for(const [kind,c,r]of [['greekHoplite',4,5],['phalangite',7,5],['romanLegion',4,8],['romanTriarii',7,8]])E.addUnit(m,kind,'egypt',c,r);__formation.setup(m);});
 await p.waitForTimeout(250);await p.screenshot({path:'docs/formation-pose/marching.png'});
 for(const kind of ['greekHoplite','phalangite','romanLegion','romanTriarii']){
  await p.evaluate(kind=>{const u=__formation.map.units.find(u=>u.kind===kind);__formation.clickCell(u.c,u.r);},kind);
  await p.getByRole('button',{name:'列阵',exact:true}).click();await p.getByRole('button',{name:'→ 东',exact:true}).click();await p.waitForTimeout(80);
  assert.equal(await p.evaluate(kind=>__formation.map.units.find(u=>u.kind===kind).formed,kind),true);
 }
 await p.waitForTimeout(200);await p.screenshot({path:'docs/formation-pose/formed.png'});
 for(const kind of ['greekHoplite','romanLegion']){
 const samples=await p.evaluate(async kind=>{
  const E=await import('/ancient/engine.mjs'),T=await import('/vendor/three/three.module.js'),q=__formation,u=q.map.units.find(u=>u.kind===kind),dest=E.neighbors(u.c,u.r)[2],values=[];
  q.clickCell(u.c,u.r);q.clickCell(dest.c,dest.r);const render=q.renderer.render;
  q.renderer.render=function(...args){const m=q.units.children.find(m=>m.userData.unitId===u.id);m.updateMatrixWorld(true);const soldier=m.getObjectByName('near').getObjectByName('soldier'),tool=soldier.getObjectByName('formation-spear')||soldier.getObjectByName('melee-tool'),axis=new T.Vector3(0,1,0).transformDirection(tool.matrixWorld);values.push({position:m.position.toArray(),forwardDot:axis.x,shieldHeight:soldier.getObjectByName('shield').position.y});return render.apply(this,args);};
  await new Promise(r=>setTimeout(r,600));q.renderer.render=render;return {kind,formed:u.formed,facing:u.facing,actions:u.actionsLeft,values};
 },kind);
 assert.equal(samples.formed,true);assert.equal(samples.facing,0);assert.equal(samples.actions,0);assert.ok(samples.values.length>10);assert.ok(samples.values.every(v=>v.forwardDot>.999&&v.shieldHeight>2.65));assert.ok(Math.abs(samples.values[0].position[2]-samples.values.at(-1).position[2])>5);checks.push(samples);
 }
 await p.screenshot({path:'docs/formation-pose/formed-after-move.png'});
 assert.equal(errors.length,0,errors.join('\n'));fs.writeFileSync('docs/formation-pose/browser-validation.json',JSON.stringify({uiFormation:true,walkingMaintainsPose:true,checks,errors},null,2));await b.close();console.log('Greek/Roman UI formation and sideways walking posture verified in rendered frames.');
})().catch(e=>{console.error(e);process.exit(1)});
