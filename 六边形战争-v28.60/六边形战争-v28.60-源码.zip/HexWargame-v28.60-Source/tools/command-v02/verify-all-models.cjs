const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),p=await b.newPage({viewport:{width:1440,height:1000}}),errors=[];
 await p.route('**/favicon.ico',route=>route.fulfill({status:204,body:''}));
 p.on('response',r=>{if(r.status()>=400)errors.push(r.status()+' '+r.url())});
 p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await p.goto('http://127.0.0.1:8816/ancient/unit-lab.html?kind=heavy');await p.waitForFunction(()=>window.unitLab);
 const models=await p.evaluate(async()=>{
  const T=await import('/vendor/three/three.module.js'),E=await import('/ancient/engine.mjs'),M=await import('/ancient/models.mjs'),F=await import('/ancient/full-models.mjs'),P=await import('/ancient/visual-profiles.mjs');
  const catalog=await fetch('/ancient/unit_animation_catalog.json').then(r=>r.json()),result=[];
  const scene=new T.Scene();scene.background=new T.Color(0x14202a);scene.add(new T.HemisphereLight(0xe5f3ff,0x85755b,2.2));const sun=new T.DirectionalLight(0xffe3b7,3);sun.position.set(10,20,8);scene.add(sun);
  for(const kind of Object.keys(E.STATS).filter(k=>k!=='fort')){
   const context=catalog.units.find(x=>x.id===kind)?.contexts[0],scenario=context?.scenarioId||'china_chengpu',u={id:kind,kind,team:context?.team||'egypt',hp:100,c:0,r:0,ammo:999,morale:1},saved=JSON.stringify(u);
   const model=M.createUnitModel(u,scenario),profile=P.visualProfile(u,scenario);if(!model.userData.fullUnit)throw Error('Legacy model: '+kind);scene.add(model);
   const poses=[{name:'idle'},{name:'move',moving:true},{name:'rout',moving:true,routed:true}];
   if(profile.canMelee)poses.push({name:'melee',action:profile.meleeAction,progress:.45});
   if(profile.canRanged)poses.push({name:'ranged',action:profile.rangedAction,progress:.55});
   for(const pose of poses){F.animateFullModel(model,340,{distance:20,...pose});model.updateMatrixWorld(true);model.traverse(o=>{if(!o.matrixWorld.elements.every(Number.isFinite))throw Error(kind+' nonfinite pose');});unitLab.renderer.render(scene,unitLab.camera);if(unitLab.renderer.info.render.triangles<=0)throw Error(kind+' blank render');}
   F.animateFullModel(model,0,{distance:150});unitLab.renderer.render(scene,unitLab.camera);if(JSON.stringify(u)!==saved)throw Error(kind+' rules mutated');
   result.push({kind,scenario,fullModel:true,poses:poses.map(x=>x.name),farLOD:true});model.removeFromParent();
  }
  return result;
 });assert.equal(models.length,67);
 const samples=[['heavy','china_chengpu','move'],['archer','china_chengpu','ranged'],['chinaCrossbow','china_changping','ranged'],['cavalry','china_mobei','move'],['chinaHeavyChariot','china_chengpu','melee'],['chinaFireOx','china_tian_dan','melee']];
 for(const [kind,scenario,action]of samples){await p.goto(`http://127.0.0.1:8816/ancient/unit-lab.html?kind=${kind}&scenario=${scenario}&action=${action}`);await p.waitForFunction(()=>window.unitLab);await p.waitForTimeout(500);await p.screenshot({path:`docs/model-deploy-fire-ox/${kind}-${action}.png`});}
 assert.equal(errors.length,0,errors.join('\n'));fs.writeFileSync('docs/model-deploy-fire-ox/all-models-browser.json',JSON.stringify({count:models.length,models,samples,errors},null,2));await b.close();console.log('All 67 unit models, eligible attack poses, movement/rout and near/far LOD rendered successfully; 6 action samples captured.');
})().catch(e=>{console.error(e);process.exit(1)});
