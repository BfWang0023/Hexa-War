import fs from 'node:fs';
import {CLASSICAL_CAMPAIGNS} from '../../web3d/ancient/classical-data.mjs';
import {makeClassicalMap} from '../../web3d/ancient/classical-maps.mjs';
import {startGame,aiTurn,isRouted} from '../../web3d/ancient/engine.mjs';
import {seededRandom} from '../ai-training/maps.mjs';
const rows=[];
for(const info of CLASSICAL_CAMPAIGNS){
 const s=startGame(makeClassicalMap(info.id)),rng=seededRandom(20261027),start=performance.now(),counts={move:0,attack:0,phalanxMode:0},roster=t=>s.map.units.filter(u=>u.team===t&&!['fort','moraleGuard','moraleFlagship'].includes(u.kind));
 let sides=0;while(!s.over&&sides<2*s.map.victory.turnLimit+2){for(const a of aiTurn(s,rng))counts[a.type]=(counts[a.type]||0)+1;sides++;}
 if(!s.over)throw Error(info.id+' did not finish');
 const living=s.map.units.filter(u=>u.hp>0&&u.kind!=='fort'&&!u.aboard);if(new Set(living.map(u=>`${u.c},${u.r}`)).size!==living.length)throw Error('overlap '+info.id);
 const result={id:info.id,seed:20261027,sideTurns:sides,turn:s.turn,winner:s.winner,reason:s.victoryReason,counts,lost:Object.fromEntries(['egypt','coalition'].map(t=>[t,roster(t).filter(u=>u.hp<=0||isRouted(u)).length])),elapsedMs:Math.round(performance.now()-start)};rows.push(result);fs.writeFileSync('docs/greek-expansion/ai-games.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(result));
}
