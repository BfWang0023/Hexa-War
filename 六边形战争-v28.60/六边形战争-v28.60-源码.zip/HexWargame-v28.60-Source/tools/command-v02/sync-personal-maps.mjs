import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {importMap,startGame} from '../../web3d/ancient/engine.mjs';
import {createSave,restoreSave} from '../../web3d/ancient/save.mjs';
import {CAMPAIGN_CATALOG} from '../../web3d/ancient/campaign-catalog.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const source=process.argv[2];
if(!source||!path.isAbsolute(source))throw Error('Provide the absolute personal maps directory.');
const destination=path.join(root,'web3d/ancient/bundled-maps'),out=path.join(root,'docs/map-sync');
const sha=data=>crypto.createHash('sha256').update(data).digest('hex');
const catalog=new Map(CAMPAIGN_CATALOG.map(x=>[x.id,x]));
const manifestPath=path.join(out,'manifest.json');
const previous=fs.existsSync(manifestPath)?JSON.parse(fs.readFileSync(manifestPath)):null;
if(previous&&previous.sourceDirectory!==source)throw Error('Use a fresh audit directory for a different source.');
const records=[];
// Validate every source first. No bundled map is changed if validation fails.
for(const name of fs.readdirSync(source).filter(x=>x.endsWith('.json')).sort()){
 const file=path.join(source,name),bytes=fs.readFileSync(file),raw=JSON.parse(bytes),map=importMap(raw);
 if(name!==map.scenarioId+'.json'||!catalog.has(map.scenarioId))throw Error('Unexpected map identity: '+name);
 const game=startGame(map);restoreSave(JSON.parse(JSON.stringify(createSave(map,game,'egypt'))));
 const dest=path.join(destination,name),backup=path.join(out,'before',name),prior=previous?.records.find(r=>r.name===name);
 const before=fs.existsSync(backup)?fs.readFileSync(backup):prior?.added?null:fs.existsSync(dest)?fs.readFileSync(dest):null;
 records.push({name,id:map.scenarioId,title:catalog.get(map.scenarioId).name,sourceSha256:sha(bytes),sourceModifiedAt:fs.statSync(file).mtime.toISOString(),destinationSha256Before:before?sha(before):null,changed:!before||!bytes.equals(before),added:!before,validated:true,sourceUnits:raw.units.length,loadedUnits:map.units.length,changedFields:before?Object.keys(raw).filter(key=>JSON.stringify(raw[key])!==JSON.stringify(JSON.parse(before)[key])):Object.keys(raw),bytes});
}
fs.mkdirSync(out,{recursive:true});
for(const record of records){
 const current=fs.readFileSync(path.join(source,record.name));if(sha(current)!==record.sourceSha256)throw Error('Source changed during audit; rerun: '+record.name);
}
for(const r of records){
 const snapshot=path.join(out,'personal-snapshot',r.name);fs.mkdirSync(path.dirname(snapshot),{recursive:true});fs.writeFileSync(snapshot,r.bytes);
 const dest=path.join(destination,r.name),backup=path.join(out,'before',r.name);
 if(fs.existsSync(dest)&&fs.readFileSync(dest).equals(r.bytes))continue;
 if(!r.added&&fs.existsSync(dest)&&!fs.existsSync(backup)){fs.mkdirSync(path.dirname(backup),{recursive:true});fs.copyFileSync(dest,backup);}
 fs.writeFileSync(dest,r.bytes);
}
for(const r of records)if(sha(fs.readFileSync(path.join(destination,r.name)))!==r.sourceSha256)throw Error('Copy mismatch: '+r.name);
const manifest={syncedAt:new Date().toISOString(),sourceDirectory:source,sourceMapCount:records.length,updatedExisting:records.filter(r=>r.changed&&!r.added).length,addedToBundle:records.filter(r=>r.added).length,totalBundledMaps:fs.readdirSync(destination).filter(x=>x.endsWith('.json')).length,personalFilesReadOnly:true,records:records.map(({bytes,...record})=>record)};
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({...manifest,records:manifest.records.filter(r=>r.changed)},null,2));
