const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),context=await browser.newContext({viewport:{width:1440,height:1000}}),p=await context.newPage(),errors=[];
 p.on('pageerror',e=>errors.push(e.message));
 await p.route('**/ancient/app.mjs',async route=>{const response=await route.fetch();await route.fulfill({response,body:(await response.text())+`\nwindow.__sync={get map(){return currentMap()},get game(){return game},get units(){return unitGroup},clickCell,refresh,unitY,unitAnimator,renderer,camera,scene,setup(m){scenario=m;startForPlayer();const q=offsetToWorld(5,5);target.set(q.x,0,q.z);cameraDistance=65;updateCamera();refresh();rebuildScene();}};`});});
 await p.goto('http://127.0.0.1:8816/ancient/?scenario=china_changping');await p.waitForFunction(()=>window.__sync);
 await p.evaluate(async()=>{const E=await import('/ancient/engine.mjs'),m=E.newMap(20,12);m.scenarioId='custom_movement_sync';m.name='底座与士兵同步移动验证';E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,'light','coalition',19,11);E.addUnit(m,'heavy','egypt',5,5);__sync.setup(m);});
 await p.waitForTimeout(250);await p.screenshot({path:'docs/movement-sync/start.png'});
 const samples=await p.evaluate(async()=>{
  const T=await import('/vendor/three/three.module.js'),H=await import('/js/core/hex.js');const q=__sync,u=q.map.units.find(x=>x.kind==='heavy'),origin={c:u.c,r:u.r};q.clickCell(u.c,u.r);q.clickCell(u.c+1,u.r);const target={c:u.c,r:u.r},points=[];
  const start=performance.now(),render=q.renderer.render;
  q.renderer.render=function(...args){const model=q.units.children.find(m=>m.userData.unitId===u.id);model.updateMatrixWorld(true);const base=model.children.find(o=>o.isMesh&&o.geometry.type==='CylinderGeometry'),level=model.children.find(o=>o.visible&&(o.name==='near'||o.name==='far')),body=level.children[0],a=base.getWorldPosition(new T.Vector3()),b=body.getWorldPosition(new T.Vector3());points.push({elapsed:performance.now()-start,root:model.position.toArray(),base:a.toArray(),body:b.toArray(),xzDifference:Math.hypot(a.x-b.x,a.z-b.z)});return render.apply(this,args);};
  await new Promise(resolve=>setTimeout(resolve,750));q.renderer.render=render;
  return {origin,target,actionsLeft:u.actionsLeft,points};
 });
 fs.writeFileSync('docs/movement-sync/browser-validation.json',JSON.stringify({...samples,errors},null,2));
 assert.ok(samples.points.length>10);assert.ok(samples.points.every(x=>x.xzDifference<1e-6));assert.equal(samples.actionsLeft,1);assert.ok(Math.abs(samples.points[0].root[0]-samples.points.at(-1).root[0])>5);
 await p.screenshot({path:'docs/movement-sync/end.png'});assert.equal(errors.length,0,errors.join('\n'));
 fs.writeFileSync('docs/movement-sync/browser-validation.json',JSON.stringify({...samples,errors},null,2));await context.close();await browser.close();console.log('Actual battle move: base/body aligned in every sampled frame; action cost preserved.');
})().catch(e=>{console.error(e);process.exit(1)});
