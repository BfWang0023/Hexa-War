const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],checks=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.route('**/ancient/app.mjs',async route=>{const r=await route.fetch();await route.fulfill({response:r,body:(await r.text())+`\nwindow.__deployed={get map(){return currentMap()},get units(){return unitGroup},get terrain(){return terrainObj},renderer};`});});
 await page.goto('http://127.0.0.1:8816/ancient/unit-lab.html?kind=chinaFireOx&scenario=china_tian_dan');await page.waitForFunction(()=>window.unitLab?.group.children.length===1);
 assert.ok(await page.evaluate(()=>!!unitLab.group.children[0].getObjectByName('tail-tinder')));assert.equal(await page.evaluate(()=>!!unitLab.group.children[0].getObjectByName('ox-yoke')),false);
 for(const action of ['move','melee','rout']){await page.selectOption('#action',action);await page.waitForTimeout(500);assert.ok(await page.evaluate(()=>unitLab.group.children[0].getObjectByName('fire-tail').scale.x!==1));}
 await page.screenshot({path:'docs/model-deploy-fire-ox/deployed-model.png'});
 for(const id of ['china_tian_dan','china_changping','china_qin_chu','china_seven_states','china_longxi']){
  await page.goto('http://127.0.0.1:8816/ancient/?scenario='+id);await page.waitForFunction(id=>window.__deployed?.map.scenarioId===id,id);await page.waitForTimeout(250);
  checks.push(await page.evaluate(()=>({id:__deployed.map.scenarioId,units:__deployed.map.units.length,chunks:__deployed.terrain.chunks.size,rendered:__deployed.units.children.length})));
  if(id==='china_tian_dan'){
   const fire=await page.evaluate(()=>__deployed.units.children.filter(u=>u.getObjectByName('tail-tinder')).length);assert.ok(fire>0);await page.screenshot({path:'docs/model-deploy-fire-ox/tian-dan-battle.png'});
  }
 }
 assert.equal(errors.length,0,errors.join('\n'));fs.writeFileSync('docs/model-deploy-fire-ox/browser-validation.json',JSON.stringify({modelVisible:true,tailTinder:true,noYoke:true,moveChargeRout:true,campaigns:checks,errors},null,2));await browser.close();console.log('New model, animations and 5 campaign screens passed.');
})().catch(e=>{console.error(e);process.exit(1)});
