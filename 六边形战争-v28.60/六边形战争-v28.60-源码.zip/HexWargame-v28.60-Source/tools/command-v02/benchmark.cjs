const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
// Control implementation reproduces the previous whole-map terrain cache while
// retaining exactly the same integrated units, map data, camera and shaders.
const wholeMap=`import * as T from '../vendor/three/three.module.js';
import {createAncientTerrain,terrainHeight} from './terrain.mjs';import {createTerrainForts} from './terrain-forts.mjs';import {terrainSignature} from './terrain-environment.mjs';
const dispose=g=>{g?.removeFromParent();g?.traverse(o=>{if(o.isInstancedMesh)o.dispose();o.geometry?.dispose();for(const m of o.material?(Array.isArray(o.material)?o.material:[o.material]):[])if(!m.userData.sharedTerrain)m.dispose();});};
export function createTerrainRefresh(){const group=new T.Group(),forts=new T.Group(),grid={visible:true},chunks=new Map();let ground=null,wall=null,signature='',quality='standard',old=null;
const api={group,forts,grid,chunks,pickables:[],refresh(m){const key=terrainSignature(m);if(!ground||old!==m||key!==signature){dispose(ground?.group);ground=createAncientTerrain(m);group.add(ground.group);signature=key;}dispose(wall);wall=createTerrainForts(m,m.units.filter(u=>u.kind==='fort'),terrainHeight);forts.add(wall);old=m;api.pickables=ground.pickables;chunks.set('0,0',{terrain:ground,forts:wall});return api.lastUpdate={totalChunks:1,terrainChunks:['0,0']};},setQuality(q){quality=q;ground?.setQuality(q)},setGrid(v){grid.visible=v;if(ground)ground.grid.visible=v},update(t){ground?.update(t)}};return api;}`;
(async()=>{
 const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),data=[];
 for(const mode of ['whole-map-control','local-chunks']){
 const p=await b.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1}),errors=[];
 p.on('pageerror',e=>errors.push(e.message));
 if(mode==='whole-map-control')await p.route('**/ancient/terrain-refresh.mjs',route=>route.fulfill({contentType:'text/javascript',body:wholeMap}));
 await p.route('**/ancient/app.mjs',async route=>{const r=await route.fetch();await route.fulfill({response:r,body:(await r.text()).replace('bootSavedMaps().catch(e => hint(e.message));','window.__ready=false;bootSavedMaps().catch(e=>hint(e.message)).finally(()=>window.__ready=true);')+`\nwindow.__perf={renderer,camera,scene,get map(){return currentMap()},get terrain(){return terrainObj}};`});});
 for(const id of ['china_changping','china_qin_chu','china_seven_states','china_longxi']){
 const begin=performance.now();await p.goto('http://127.0.0.1:8816/ancient/?scenario='+id);await p.waitForFunction(id=>window.__ready&&window.__perf?.map.scenarioId===id,id);await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));const loadMs=performance.now()-begin;
 await p.waitForTimeout(1500);const cdp=await p.context().newCDPSession(p);await cdp.send('HeapProfiler.collectGarbage');await cdp.detach();
 const result=await p.evaluate(async()=>{
 const q=__perf,frames=[];let last=null;await new Promise(resolve=>{const start=performance.now();function frame(t){if(last!==null)frames.push(t-last);last=t;if(t-start<5000)requestAnimationFrame(frame);else resolve();}requestAnimationFrame(frame)});
 const sorted=[...frames].sort((a,b)=>a-b),low=sorted.slice(-Math.max(1,Math.ceil(sorted.length*.01))),gl=q.renderer.getContext(),ext=gl.getExtension('WEBGL_debug_renderer_info');
 return {cells:q.map.cols*q.map.rows,units:q.map.units.length,averageFPS:1000/(frames.reduce((a,b)=>a+b,0)/frames.length),low1FPS:1000/(low.reduce((a,b)=>a+b,0)/low.length),drawCalls:q.renderer.info.render.calls,triangles:q.renderer.info.render.triangles,heapBytes:performance.memory?.usedJSHeapSize??null,gpu:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):null};
 });
 const editing=await p.evaluate(async()=>{
 const e=await import('/ancient/engine.mjs'),q=__perf,m=q.map,empty=[];
 for(let r=3;r<m.rows-3;r++)for(let c=3;c<m.cols-3;c++)if(m.terrain[r*m.cols+c]===e.TERRAIN.PLAIN&&!m.units.some(u=>u.c===c&&u.r===r)&&!m.houses?.[r*m.cols+c]&&empty.length<8)empty.push({c,r});
 const times=[],counts=[];for(const p of empty){let t=performance.now();e.setTerrain(m,p.c,p.r,e.TERRAIN.MOUNTAIN);const update=q.terrain.refresh(m);times.push(performance.now()-t);counts.push(update.terrainChunks.length);e.setTerrain(m,p.c,p.r,e.TERRAIN.PLAIN);q.terrain.refresh(m);}
 return {meanEditMs:times.reduce((a,b)=>a+b,0)/times.length,maxEditMs:Math.max(...times),samples:times,rebuiltChunks:counts,totalChunks:q.terrain.chunks.size};
 });
 data.push({mode,id,loadMs,...result,...editing,errors});console.log(mode,id,result.averageFPS.toFixed(2),result.drawCalls,editing.meanEditMs.toFixed(2));
 }
 await p.close();
 }
 await b.close();fs.writeFileSync('docs/command-v02/performance.json',JSON.stringify({date:new Date().toISOString(),viewport:[1440,1000],dpr:1,sampleSeconds:5,warmupMs:1500,gcBeforeSample:true,control:'previous whole-map cache reproduced on current integrated code; not a pre-edit hardware capture',data},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
