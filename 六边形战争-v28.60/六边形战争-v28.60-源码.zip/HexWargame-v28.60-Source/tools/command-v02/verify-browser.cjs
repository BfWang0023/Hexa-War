const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
const root='http://127.0.0.1:8816',out='docs/command-v02';
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1}),errors=[],checks=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.route('**/ancient/app.mjs',async route=>{const response=await route.fetch();await route.fulfill({response,body:(await response.text()).replace('bootSavedMaps().catch(e => hint(e.message));','window.__bootReady=false;bootSavedMaps().catch(e=>hint(e.message)).finally(()=>window.__bootReady=true);')+`
 window.__qa={renderer,camera,scene,get map(){return currentMap()},get game(){return game},get terrain(){return terrainObj},get ids(){return [...groupIds]},get plan(){return groupPlan},get units(){return unitGroup},unitScreen,eventHex,clickCell,paintCell,refresh,rebuildScene,unitAnimator,setFixture(m){scenario=m;startForPlayer();editing=false;playerTeam='egypt';groupMap=game.map;const p=offsetToWorld(8,6);target.set(p.x,0,p.z);cameraDistance=100;updateCamera();refresh();},get target(){return target},setCamera(c,r,d){const p=offsetToWorld(c,r);target.set(p.x,0,p.z);cameraDistance=d;updateCamera();},get editing(){return editing},set brush(v){brush=v;lastPaint='';}};`});});
 async function load(id){await page.goto(root+'/ancient/?scenario='+id);await page.waitForFunction(id=>window.__qa?.map.scenarioId===id&&window.__bootReady,id);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));}
 await load('china_changping');const ids=await page.locator('#scenario-select option').evaluateAll(xs=>xs.map(x=>x.value));assert.equal(ids.length,71);
 for(const id of ids){await load(id);checks.push(await page.evaluate(()=>({id:__qa.map.scenarioId,units:__qa.map.units.length,chunks:__qa.terrain.chunks.size,calls:__qa.renderer.info.render.calls})));if(checks.length%10===0)console.log('Loaded',checks.length);}
 console.log('71 campaigns loaded');
 // Reproducible fixture uses actual UI gestures and never saves to disk.
 await page.evaluate(async()=>{const e=await import('/ancient/engine.mjs'),m=e.newMap(32,24);m.scenarioId='custom_command_demo';m.name='批量行军验收';e.addUnit(m,'pharaoh','egypt',1,1);e.addUnit(m,'light','coalition',25,20);for(const r of [5,6,7])e.addUnit(m,'heavy','egypt',6,r);e.addUnit(m,'archer','egypt',5,9);window.__qa.setFixture(m);});
 await page.waitForTimeout(300);
 const own=await page.evaluate(()=>__qa.map.units.filter(u=>u.kind==='heavy').map(u=>({id:u.id,c:u.c,r:u.r,...__qa.unitScreen(u)})));
 assert.ok(own.every(p=>p.x>0&&p.y>0));
 const x1=Math.min(...own.map(p=>p.x))-18,y1=Math.min(...own.map(p=>p.y))-18,x2=Math.max(...own.map(p=>p.x))+18,y2=Math.max(...own.map(p=>p.y))+18;
 await page.keyboard.down('Shift');await page.mouse.move(x1,y1);await page.mouse.down();await page.mouse.move(x2,y2,{steps:10});await page.mouse.up();await page.keyboard.up('Shift');
 assert.equal((await page.evaluate(()=>__qa.ids)).length,3);
 await page.screenshot({path:out+'/group-selection.png'});
 // Shift-click removes/re-adds a selected unit.
 await page.keyboard.down('Shift');await page.mouse.click(own[0].x,own[0].y);await page.keyboard.up('Shift');assert.equal((await page.evaluate(()=>__qa.ids)).length,2);
 await page.keyboard.down('Shift');await page.mouse.click(own[0].x,own[0].y);await page.keyboard.up('Shift');assert.equal((await page.evaluate(()=>__qa.ids)).length,3);
 await page.locator('#group-target').click();
 const target=await page.evaluate(()=>__qa.unitScreen({c:8,r:6}));await page.mouse.click(target.x,target.y);
 assert.equal(await page.evaluate(()=>__qa.plan?.entries.length),3);assert.equal(await page.evaluate(()=>__qa.plan.order.length),3);
 await page.screenshot({path:out+'/group-preview.png'});
 const paths=await page.evaluate(()=>__qa.plan.entries.map(e=>({id:e.id,path:e.path,from:e.from,to:e.to})));
 await page.locator('#group-confirm').click();assert.match(await page.locator('#hint').textContent(),/成功 3/);await page.waitForTimeout(1300);
 assert.ok(await page.evaluate(()=>__qa.ids.every(id=>__qa.map.units.find(u=>u.id===id).actionsLeft===1)));
 for(const path of paths)assert.ok(await page.evaluate(p=>{const e=__qa.map.units.find(x=>x.id===p.id);return e.c===p.to.c&&e.r===p.to.r},path));
 await page.screenshot({path:out+'/group-moved.png'});
 // Ordinary drag is pan; does not select additional units or issue moves.
 const before=await page.evaluate(()=>({ids:__qa.ids,target:__qa.target.toArray(),units:__qa.map.units.map(u=>[u.id,u.c,u.r,u.actionsLeft])}));
 await page.mouse.move(300,500);await page.mouse.down();await page.mouse.move(360,520,{steps:8});await page.mouse.up();
 const after=await page.evaluate(()=>({ids:__qa.ids,target:__qa.target.toArray(),units:__qa.map.units.map(u=>[u.id,u.c,u.r,u.actionsLeft])}));assert.deepEqual(after.ids,before.ids);assert.deepEqual(after.units,before.units);assert.notDeepEqual(after.target,before.target);
 await page.keyboard.press('Escape');assert.equal((await page.evaluate(()=>__qa.ids)).length,0);
 // Editor updates at a chunk boundary retain distant geometry and unit action state.
 await page.locator('#editor').click();await page.waitForTimeout(200);assert.equal(await page.evaluate(()=>__qa.editing),true);assert.equal(await page.locator('#group-controls').isVisible(),false);
 const terrain=await page.evaluate(()=>({far:__qa.terrain.chunks.get('0,1').terrain.surface.uuid,actions:__qa.map.units.filter(u=>u.kind!=='fort').map(u=>[u.id,u.actionsLeft])}));
 await page.evaluate(async()=>{const e=await import('/ancient/engine.mjs'),m=__qa.map;for(const [c,r,l]of [[9,5,1],[10,5,2],[11,5,3],[11,4,2],[12,4,2]])e.setFort(m,c,r,l,'egypt');for(let c=7;c<14;c++)e.setTerrain(m,c,8,e.TERRAIN.ROAD);for(let r=3;r<11;r++)e.setTerrain(m,12,r,e.TERRAIN.RIVER|(r===8?e.TERRAIN.ROAD:0));e.setBridge(m,12,8);__qa.refresh();__qa.setCamera(10,7,100);});
 await page.locator('[data-brush=fort2]').click();await page.locator('#collapse-editor').click();await page.waitForTimeout(250);await page.screenshot({path:out+'/terrain-connected.png'});
 assert.equal(await page.evaluate(()=>__qa.terrain.chunks.get('0,1').terrain.surface.uuid),terrain.far);
 const cell=await page.evaluate(()=>__qa.unitScreen({c:10,r:6}));await page.mouse.click(cell.x,cell.y);await page.waitForTimeout(100);
 assert.ok(await page.evaluate(()=>__qa.map.units.some(u=>u.kind==='fort'&&u.c===10&&u.r===6)));
 assert.equal(await page.evaluate(()=>__qa.terrain.lastUpdate.reset),false);
 // Remove junction and bridge via existing editing path, then show exposed ford.
 await page.evaluate(async()=>{const e=await import('/ancient/engine.mjs');e.setFort(__qa.map,11,5,0);e.setBridge(__qa.map,12,8,false);__qa.refresh();});await page.waitForTimeout(200);
 assert.equal(await page.evaluate(()=>!!__qa.terrain.group.getObjectByName('bridge-decks')),false);assert.equal(await page.evaluate(()=>!!__qa.terrain.group.getObjectByName('underlying-fords')),true);
 await page.screenshot({path:out+'/terrain-removed.png'});
 const saved=await page.evaluate(async()=>{const e=await import('/ancient/engine.mjs'),save=await import('/ancient/save.mjs'),q=__qa;const result=save.restoreSave(JSON.parse(JSON.stringify(save.createSave(q.game.map,q.game,'egypt'))));return result.game.map.bridges;});assert.ok(Array.isArray(saved));
 fs.writeFileSync(out+'/browser-validation.json',JSON.stringify({campaigns:checks,groupRectangle:true,shiftToggle:true,preview:true,move:true,panSeparation:true,escape:true,editorLocalRefresh:true,bridgeFord:true,saveRestore:true,errors},null,2));
 assert.equal(errors.length,0,errors.join('\n'));await browser.close();console.log('UI group commands, editor connectivity and 71 campaign loads passed.');
})().catch(e=>{console.error(e);process.exit(1)});
