const {chromium}=require('/Users/boriswang/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),p=await b.newPage({viewport:{width:1440,height:1000}}),errors=[],campaigns=[],purchases=[];
 p.on('pageerror',e=>errors.push(e.message));
 await p.route('**/ancient/app.mjs',async route=>{const r=await route.fetch();await route.fulfill({response:r,body:(await r.text()).replace('bootSavedMaps().catch(e => hint(e.message));','window.__bootReady=false;bootSavedMaps().catch(e=>hint(e.message)).finally(()=>window.__bootReady=true);')+`\nwindow.__recruit={get game(){return game},refresh,setup(team){playerTeam=team;game.side=team;game.deploying=false;game.map.logistics.routes[team]=[game.map.logistics.depots[team][0]];refresh();}};`});});
 async function load(id){await p.goto('http://127.0.0.1:8816/ancient/?scenario='+id);await p.waitForFunction(id=>window.__bootReady&&window.__recruit?.game.map.scenarioId===id,id);}
 await load('china_changping');const ids=await p.locator('#scenario-select option').evaluateAll(xs=>xs.map(x=>x.value));assert.equal(ids.length,71);
 for(const id of ids){await load(id);campaigns.push(await p.evaluate(()=>({id:__recruit.game.map.scenarioId,units:__recruit.game.map.units.length})));if(campaigns.length%10===0)console.log('Loaded',campaigns.length);}
 for(const id of ['china_changping','china_qin_chu','china_seven_states','china_longxi'])for(const team of ['egypt','coalition']){
  await load(id);await p.evaluate(team=>__recruit.setup(team),team);
  for(const [kind,label,cost]of [['chinaHeavyChariot','战车',150],['siegeRam','攻城槌',120]]){
   const button=()=>p.locator('#recruit-options button').filter({hasText:label});assert.equal(await button().count(),1);assert.match(await button().textContent(),new RegExp(cost+'金'));
   for(const money of [-10,0,cost-1]){await p.evaluate(({team,money})=>{__recruit.game.money[team]=money;__recruit.refresh();},{team,money});assert.equal(await button().isDisabled(),true);}
   await p.evaluate(({team,cost})=>{__recruit.game.money[team]=cost;__recruit.refresh();},{team,cost});assert.equal(await button().isEnabled(),true);
   const before=await p.evaluate(()=>__recruit.game.map.units.length);await button().click();
   const result=await p.evaluate(({team,kind})=>({money:__recruit.game.money[team],count:__recruit.game.map.units.length,unit:__recruit.game.map.units.at(-1),cooldown:__recruit.game.recruitmentReadyTurn[team][kind==='siegeRam'?'siegeRam':'chariot']}),{team,kind});
   assert.equal(result.money,0);assert.equal(result.count,before+1);assert.equal(result.unit.kind,kind);assert.equal(result.unit.team,team);assert.equal(result.unit.actionsLeft,0);assert.equal(result.cooldown,4);
   await p.evaluate(team=>{__recruit.game.money[team]=10000;__recruit.refresh();},team);assert.equal(await button().isDisabled(),true);assert.match(await button().textContent(),/再等3回合/);
   for(const turn of [2,3]){await p.evaluate(turn=>{__recruit.game.turn=turn;__recruit.refresh();},turn);assert.equal(await button().isDisabled(),true);}
   await p.evaluate(()=>{__recruit.game.turn=4;__recruit.refresh();});assert.equal(await button().isEnabled(),true);
   // Return to the same initial round to test each independent equipment pool.
   await p.evaluate(()=>{__recruit.game.turn=1;__recruit.refresh();});purchases.push({id,team,kind,cost,disabledBelowPrice:true,waitThreeRounds:true,saveTest:'covered by automated rules tests'});
  }
  if(id==='china_changping'){await p.locator('#recruit-card').scrollIntoViewIfNeeded();await p.screenshot({path:`docs/recruitment-funds/${team}-cooldown.png`});}
 }
 fs.writeFileSync('docs/recruitment-funds/browser-validation.json',JSON.stringify({campaigns,purchases,errors},null,2));assert.equal(errors.length,0,errors.join('\n'));await b.close();console.log('71 campaigns and 16 equipment purchases verified through actual UI buttons.');
})().catch(e=>{console.error(e);process.exit(1)});
