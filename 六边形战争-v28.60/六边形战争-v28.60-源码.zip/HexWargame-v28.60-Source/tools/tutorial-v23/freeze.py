from pathlib import Path
import difflib,json
p=Path('docs/tutorial-v23/before/app.mjs');old=p.read_text().splitlines(keepends=True);new=Path('web3d/ancient/app.mjs').read_text().splitlines(keepends=True)
out=[dict(at=len(''.join(new[:c]).encode('utf-16-le'))//2,removed=''.join(old[a:b]),added=''.join(new[c:d])) for op,a,b,c,d in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes() if op!='equal']
Path('docs/tutorial-v23/authorized-app.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
p=Path('tools/interaction-v19/integrity.mjs');s=p.read_text();needle='export function beforeInteraction(name,text){'
if 'authorized tutorial' not in s:s=s.replace(needle,needle+"if(name==='app.mjs')for(const e of JSON.parse(fs.readFileSync(new URL('../../docs/tutorial-v23/authorized-app.json',import.meta.url))).reverse()){assert.equal(text.slice(e.at,e.at+e.added.length),e.added,'authorized tutorial patch');text=text.slice(0,e.at)+e.removed+text.slice(e.at+e.added.length);}")
p.write_text(s)
