from pathlib import Path
import json,subprocess,tempfile,hashlib,zipfile
root=Path.cwd();out=root/'dist/end-turn-direct';docs=root/'docs/end-turn-direct';app=out/'古代战役.app';data={}
# Clear Finder-added metadata from the newly generated output bundle, not source files.
for _ in range(3):
 subprocess.run(['xattr','-cr',str(app)],check=True)
 result=subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,text=True)
 if result.returncode==0:break
data['outputAppSignatureValid']=result.returncode==0
with tempfile.TemporaryDirectory(prefix='terrain-refine-package-') as tmp:
 subprocess.run(['ditto','-xk',str(out/'古代战役-v02-macOS.zip'),tmp],check=True)
 unpack=Path(tmp)/'古代战役.app'
 r=subprocess.run(['codesign','--verify','--deep','--strict',str(unpack)],capture_output=True,text=True)
 data['zipSignatureValid']=r.returncode==0;data['mismatches']=[];count=0
 for source in (root/'web3d').rglob('*'):
  if source.is_file() and source.name!='.DS_Store':
   target=unpack/'Contents/Resources/web3d'/source.relative_to(root/'web3d');count+=1
   if not target.is_file() or source.read_bytes()!=target.read_bytes():data['mismatches'].append(str(source.relative_to(root)))
 data['verifiedWebFiles']=count
assert data['zipSignatureValid'] and data['outputAppSignatureValid'] and not data['mismatches'],data
(docs/'package-verification.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))

archive=out/'古代战役-v02-macOS.zip'
(out/'SHA256SUMS.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps(data,ensure_ascii=False))
