#!/usr/bin/env python3
"""Numerically quantify bridge-vs-road rendering discontinuities.

For every bridge plate, compare its surface Y with each adjacent road plate's
surface Y, and check whether the connector quad joining them actually reaches
the neighbour plate (a mismatch shows up as a vertical step / floating slab).
"""
import json
import pickle
import sys

sys.path.insert(0, "tools")
from road_preview import (  # noqa: E402
    T, axial_from_offset, offset_from_axial, tile_height, bridge_hexes,
)


def plate_map(quads):
    """centroid(col,row)-ish: map rounded centroid -> (y, is_bridge)."""
    out = {}
    for kind, pts, col, isb in quads:
        if kind != "plate":
            continue
        cx = sum(p[0] for p in pts) / len(pts)
        cz = sum(p[2] for p in pts) / len(pts)
        out[(round(cx, 1), round(cz, 1))] = (pts[0][1], isb)
    return out


def main():
    path = "maps/桥头堡之战.json"
    d = json.load(open(path, encoding="utf-8"))
    cols, rows = d["cols"], d["rows"]
    water = [axial_from_offset(c, r) for c, r in d["water"]]
    roads = [tuple(x) for x in d["roads"]]
    bridges = set(bridge_hexes(cols, rows, water, [axial_from_offset(c, r) for c, r in d["obstacles"]]))
    bridges_off = {offset_from_axial(*h) for h in bridges}

    # recompute cell Y the same way terrain.js does
    from road_preview import H_WATER, H_ROAD
    grid = [0] * (cols * rows)
    for c, r in roads:
        grid[r * cols + c] |= T["ROAD"]
    for (q, rr) in bridges:
        c, r = offset_from_axial(q, rr)
        grid[r * cols + c] |= T["BRIDGE"]
    h_of = [tile_height(grid, cols, rows, c, r) for r in range(rows) for c in range(cols)]

    for label, pkl in (("BEFORE", "tools/_preview/roads_before.pkl"),
                       ("AFTER ", "tools/_preview/roads_fixed.pkl")):
        quads = pickle.load(open(pkl, "rb"))
        pm = plate_map(quads)
        marks_bridge = sum(1 for k, p, c, b in quads if k == "mark" and b)
        rails = sum(1 for k, p, c, b in quads if k == "rail")
        max_step = 0.0
        steps = []
        for (c, r) in sorted(bridges_off):
            aq, ar = axial_from_offset(c, r)
            w = (round(__import__("road_preview").axial_to_world(aq, ar)[0], 1),
                 round(__import__("road_preview").axial_to_world(aq, ar)[1], 1))
            y_self = pm[w][0]
            for i in range(6):
                from road_preview import ANG_DIRS
                dq, dr = ANG_DIRS[i]
                nq, nr = aq + dq, ar + dr
                noff = (nq + ((nr - (nr & 1)) >> 1), nr)
                if not (0 <= noff[0] < cols and 0 <= noff[1] < rows):
                    continue
                if not (grid[noff[1] * cols + noff[0]] & T["ROAD"]):
                    continue
                nwx, nwz = __import__("road_preview").axial_to_world(nq, nr)
                nkey = (round(nwx, 1), round(nwz, 1))
                if nkey not in pm:
                    continue
                y_n = pm[nkey][0]
                steps.append(abs(y_self - y_n))
        max_step = max(steps) if steps else 0.0
        avg = sum(steps) / len(steps) if steps else 0.0
        print(f"{label} bridge plate Y={pm[w][0]:.3f} (last cell), "
              f"max|bridge-road| step={max_step:.3f}m avg={avg:.3f}m, "
              f"lane-mark quads on bridge={marks_bridge}, railing quads={rails}")

    # explicit per-bridge table (BEFORE)
    print("\nPer bridge cell: plate Y (BEFORE vs AFTER) and nearest road-neighbour Y")
    qb = pickle.load(open("tools/_preview/roads_before.pkl", "rb"))
    qa = pickle.load(open("tools/_preview/roads_fixed.pkl", "rb"))
    pmb, pma = plate_map(qb), plate_map(qa)
    for (c, r) in sorted(bridges_off):
        aq, ar = axial_from_offset(c, r)
        w = (round(__import__("road_preview").axial_to_world(aq, ar)[0], 1),
             round(__import__("road_preview").axial_to_world(aq, ar)[1], 1))
        print(f"  ({c:2d},{r:2d})  landY={h_of[r*cols+c]:+.3f}  "
              f"beforeY={pmb[w][0]:+.3f}  afterY={pma[w][0]:+.3f}")


if __name__ == "__main__":
    main()
