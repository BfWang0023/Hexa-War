// Preserve historical evidence while rerunning existing animation assertions on this build.
const fs=require('node:fs'),{spawnSync}=require('node:child_process');
for(const name of ['movement-sync','formation-pose','hit-flash']){const out='docs/art-repair-20261028/motion/'+name;fs.mkdirSync(out,{recursive:true});const source=fs.readFileSync('tools/command-v02/verify-'+name+'.cjs','utf8').replace(/127\.0\.0\.1:\d+/g,'127.0.0.1:8840').split('docs/'+name).join(out);const r=spawnSync(process.execPath,['-e',source],{stdio:'inherit',timeout:90000});if(r.status!==0)process.exit(r.status||1);}
