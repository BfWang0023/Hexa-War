from pathlib import Path
import json,hashlib,re
out=Path('docs/charge-bonus');read=lambda n:json.loads((out/n).read_text());browser=read('browser.json');balance=read('balance.json');cap=read('capabilities.json');base=read('before/hashes.json')
text=(out/'all-tests.txt').read_text();passed=int(re.findall(r'# pass (\d+)',text)[-1]);assert re.findall(r'# fail (\d+)',text)[-1]=='0' and not browser['errors'] and len(browser['campaigns'])==85
modified=[k for k,h in base.items() if Path(k).is_file() and hashlib.sha256(Path(k).read_bytes()).hexdigest()!=h];added=[str(p) for p in Path('web3d/ancient').glob('*.mjs') if str(p) not in base]
protected=['unit-animation.mjs','full-models.mjs','unit-presentation.mjs','visual-profiles.mjs','auto-elevation.mjs','terrain.mjs','terrain-environment.mjs','mountain-visual.mjs','soldier-camera.mjs','reconnaissance.mjs','knowledge-mist.mjs','campaign-catalog.mjs']
before=(out/'before/engine.mjs').read_text();after=Path('web3d/ancient/engine.mjs').read_text();marker='export function megiddoMap()'
audit={'modified':modified,'added':added,'protectedUnchanged':{n:hashlib.sha256(Path('web3d/ancient',n).read_bytes()).hexdigest()==base['web3d/ancient/'+n] for n in protected},'manualMapsUnchanged':all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==h for k,h in base.items() if '/bundled-maps/' in k),'builtInMapConstructorTailUnchanged':before[before.index(marker):]==after[after.index(marker):]}
assert all(audit['protectedUnchanged'].values()) and audit['manualMapsUnchanged'] and audit['builtInMapConstructorTailUnchanged'];(out/'source-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
rows=[]
for kind in ['cavalry','companionCavalry','parthianCataphract','hittiteChariot','chinaHeavyChariot','scythedChariot']:
 r=next(r for r in balance['rows'] if r['kind']==kind and r['defender']=='heavy' and r['gap']==0);rows.append(f"|{cap[kind]['name']}|{r['baseDamage']/10:.1f}|{r['chargeDamage']/10:.1f}|×{r['chargeMultiplier']:.2f}|")
metrics=browser['officer']['metrics'];planner=balance['planner']
report=f'''# 冲锋加成：规则 v15 实施与验证

2026-10-29。新增 Charge Bonus，保留 v14.4 观战跟随与 v14.3 地形美术。

## 已完成的规则

正式STATS数据库增加明确的`chargeClass`能力标记：{sum(v['chargeClass']=='cavalry' for v in cap.values())}类骑兵和{sum(v['chargeClass']=='heavyChariot' for v in cap.values())}类重型战车。资格还要求现有近战攻击力大于0、存活、未溃逃、未登船、未下马。没有使用名称中的骑兵/战车文字判断引擎资格。完整名单见`capabilities.json`。

重型战车为先秦四马重战车、赫梯重战车和波斯镰刀战车。普通战车弓兵和法老轻型战车未标记为重型冲锋单位；器械、战象、火牛及普通步兵不因此获得本次加成。骑射兵即使具有骑兵标记，射击仍不触发；只有原规则实际允许的近战才可判定。

合法移动由权威`move()`记录实际路径，包含移动前格、合法经过格、当前回合/阵营、兵种及行动资源指纹。攻击时重新计算最后三点到实际目标当前位置的六角距离，必须连续严格递减，且至少两步、每步相邻、完整助跑没有重复地格。

这是**立即行动链**：其他单位移动、任何有效攻击、转向/列阵/工程/登船等付费动作、招募/补给操作、明确停止或取消待执行冲锋都会中断。另一单位先行动也不能保留冲锋。纯选择、镜头操作及无效动作尝试不增加步数、也不支付行动；不得通过原地转向、往返或瞬移伪造记录。跨双方交接或回合重置清空记录。

每次合法攻击消耗当前助跑，命中和未命中均只尝试一次。目标移动和卫队代挡时按真正承伤目标重新核验；直接攻击城墙及溃兵一击处决沿用原有特殊结算，不额外套用这项部队冲锋。

每单位仍使用原行动力：正常平原移动2格或3格花1次行动，再近战花1次行动，合计2次。渡口耗尽行动、山路限制、不可通行地形、占格、视野与射程条件完全由原接口处理；行动不足不会攻击，也不恢复行动力。

## 参数与数值验证

默认骑兵 **×1.25**，近战重型战车 **×1.30**。`DEFAULT_CHARGE_RULES`及`startGame(map,{{chargeRules:{{cavalry:1.25,heavyChariot:1.30}}}})`可配置，参数随新存档保存；接受1到2之间的有限倍率，1可作数值对照。不永久修改攻击力。

实测选择理由：以0.1耐久为最小显示单位，骑兵的提升大多为0.3–1.5耐久，重战车在常见重步兵防护下增加约0.5–1.4耐久；能奖励助跑，又不授予额外行动或无条件翻倍。新规则替换赫梯、镰刀、部分骑兵和中国重战车原有按`movedSteps`给予的固定冲锋奖励，不与其重复叠加。

同高、满士气、无其他修正，目标为重步兵（护甲2）：

|攻击兵种|不加冲锋的伤害|冲锋伤害|配置倍率|
|---|---:|---:|---:|
{chr(10).join(rows)}

`balance.json`包含**54组**对照：6种攻击单位×3种防护目标×高差-2/0/+2。对照和冲锋均通过真实引擎移动、预览和攻击；数值测试固定命中随机输入以隔离伤害变化，浏览器操作仍使用游戏实际随机结算。超过目标剩余耐久时按原规则截断实际伤害。

高低差倍率原配置保持：每级±15%，最低0.55、最高1.45。两项在最终伤害处相乘并只做一次最终取整：例如重战车对重步兵，基础4.5、低打高两级×0.70、冲锋×1.30，结果**4.1**；如果错误地先取整高差再乘冲锋，会得到4.2，专项测试明确拒绝这种重复取整。默认最高高差与冲锋的组合分别为1.8125和1.885。

火牛的独立特例、扎马后侧位置奖励、反骑兵与方阵防护等其他战役规则保留；新通用冲锋不重复叠加被替换的旧移动冲锋定值。参数是经过功能与数值测试的初始值，尚未完成长期对战胜率平衡。

## 玩家界面、传令官与AI

- 攻击悬停预览显示是否触发、实际倍率和不满足原因。选中有能力的单位时显示当前存档参数与条件，旧固定+2/+3说明在v15界面中替换；旧版存档保留原说明。
- 复用原有轻量命中环和伤害字幕，增加“冲锋”/“冲锋未命中”；战斗日志记录倍率，不增加兵模、粒子系统或实时灯光。
- 本地解析支持“骑兵冲锋敌军左翼”“重型战车前进两格后冲击敌军步兵”。结构化`attack.charge=true`只是玩家的近战冲锋意图，不是加成状态；倍率、路径或AP字段不能由LLM注入。
- 战术接口在原有合法移动中寻找接敌位置，并再次调用真实移动、攻击。批量冲锋按每队的移动/近战成对执行，避免其他队插入而破坏立即行动链；明确的中途取消会阻止尚未执行的攻击，不回滚已花行动。
- 原有自主AI的攻击评价直接使用引擎预览伤害；原有战略/守备约束之后增加合法冲锋接近候选，并保留暴露渡口、部队协同检查。不会在已相邻时往返刷冲锋，也不绕过行动力。AI与玩家同用一个判定。
- 传令官可以本地解释本局冲锋条件与实际倍率，不会因低打高而擅自撤退或更换玩家指定的目标。

## 规则版本、保存与信息权限

新局为规则 **v15**。保存格式标识仍是`hex_wargame.ancient.save.v1`，新增保存的`chargeRules`及`chargeRuns`；恢复时校验记录、路径和参数。v10–v14保留原规则，**不会静默升级旧局冲锋效果**。旧局中相同自然语言命令仍只能产生该旧版原有的合法效果。

`attackPreview`增加`chargeBonus`，实际攻击将最终判定写入`visual.chargeBonus`，供字幕、日志与动画队列读取。候选规划仅在副本上推演，不写单位属性；实际状态只能由合法行动接口记录。训练工具原有版本元数据通过共享规则常量标注v15，没有修改训练目标、模型文件或学习算法。

阵营观察接口只允许访问本阵营的助跑记录，未知敌军的路径和行动不会进入AI/传令官快照。新候选规划在现有已知地图与可见目标上工作，真实执行依旧由权威地图检查。双迷雾与地图记忆规则保持。

## 真实测试结果

- 全部游戏Node测试：**{passed}项通过，0失败**；包括旧版伤害、85场战役数据、地图、财政、补给、山地/高差、迷雾、存档、模型和观战相机回归。
- 新增26项冲锋专项：兵种标记、两格与一格、原地、往返、动作打断、另一单位打断、跨回合、射击、无近战能力、倍率配置、一次性/未命中、目标移动/瞬移、障碍/AP、保存/旧规则、信息隔离、AI、传令官、批量原子行动对、取消、卫队代挡、低打高最终取整及阵营对称。
- 原AI训练单元测试：2项通过，训练源文件保持不变。未重新训练模型。
- 浏览器：{len(browser['checks'])}项端到端断言通过；实际鼠标选骑兵、两格移动、倍率预览、真实近战；中文输入→本地解析→重战车真实移动/攻击；自主AI真实冲锋；**85场战役实际加载通过**，页面/着色器错误0。本地命令的远程LLM请求为0。
- 观战/迷雾浏览器回归通过，记录在`camera-regression/`与`spectator-regression.txt`。

本地重战车命令本次实测：解析{metrics['localParseMs']:.2f}ms，结构校验{metrics['validationMs']:.2f}ms，输入至开始执行{metrics['inputToFirstActionMs']:.2f}ms。远程LLM未调用，不提供模拟网络延迟。

新增候选规划仅在行动/下令时计算，不放进渲染逐帧循环。M4 Node单单位、一个可见目标100次样本，中位{planner['medianMs']:.3f}ms、P95 {planner['p95Ms']:.3f}ms；这是小型CPU样本，不是完整AI回合或GPU性能基准。本轮未另测M1、原生WKWebView长期FPS或大规模长期对战性能，不宣称新的帧率提升。

## 真实画面

- [骑兵攻击预览]({(out/'cavalry-charge-preview.png').resolve()})
- [骑兵接敌字幕]({(out/'cavalry-charge-impact.png').resolve()})
- [中文传令官驱动重战车冲锋]({(out/'officer-heavy-charge.png').resolve()})
- [自主AI冲锋]({(out/'ai-charge.png').resolve()})

字幕实际渲染帧的DOM显示状态与边界记录在`browser.json`，没有用模拟攻击返回值替代执行。伤害、助跑、数值测试及日志均保留原始数据。

## 修改文件与保护边界

{chr(10).join('- `'+p+'`' for p in modified+added)}

辅助脚本位于`tools/charge-bonus/`；`tools/spectator-follow/app-integrity.mjs`扩展了精确的冲锋文字/UI允许范围。历史模型保护继续比较全部非授权代码，原模型/动画/效果时序保持。旧的“整个引擎不能改”“全部属性不能新增”等保护断言，调整为明确授权v15核心哈希、保留旧源码哈希、全部原数值属性不变与新行为测试；没有删除测试或修改历史基线数据。

42张人工地图、其他战役源码及引擎内置地图构造代码保持不变，见`source-audit.json`。地形、自动海拔、兵模动作、观战跟随相机源码保持原哈希。新增的规则模块独立封装，不重写战斗引擎。

桌面包与完整源码位于`dist/charge-bonus/`；构建、独立解压、签名及全部网页资源一致性见`build.txt`、`package-verification.json`。本轮实际游戏验证在Chrome运行，桌面应用已构建校验，尚未单独完成原生WebView长时间测试。
'''
(out/'冲锋机制v15开发与验证报告.md').write_text(report);print('report generated',passed,'tests',len(browser['campaigns']),'campaigns')
