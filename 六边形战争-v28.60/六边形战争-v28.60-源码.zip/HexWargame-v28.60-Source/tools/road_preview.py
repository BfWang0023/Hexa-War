#!/usr/bin/env python3
"""Faithful Python port of web3d/js/world/terrain.js `buildRoads` (and the
tile-height / bridge-identification logic it depends on), used only to
visualise the bridge-vs-road rendering discrepancy without a browser."""
import json
import math
import sys
from collections import deque

HEX_R = 6.0
SQRT3 = math.sqrt(3)
H_PLAIN, H_FOREST, H_BUILDING, H_ROCK = 0.0, 0.34, 0.12, 2.35
H_SLOPE_CAP = 0.5
H_WATER, H_WATER_BED, H_ROAD = -0.62, -1.55, 0.02
T = {"ROCK": 1, "FOREST": 2, "BUILDING": 4, "WATER": 8, "ROAD": 16, "BRIDGE": 32}
ANG_DIRS = [(1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1), (1, -1)]
NEI = [(1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1)]


def axial_from_offset(c, r):
    return (c - ((r - (r & 1)) >> 1), r)


def offset_from_axial(q, r):
    return (q + ((r - (r & 1)) >> 1), r)


def axial_to_world(q, r):
    return (SQRT3 * HEX_R * (q + r / 2), 1.5 * HEX_R * r)


def hex_corners(cx, cz, radius=HEX_R):
    return [(cx + radius * math.cos(math.pi / 6 + i * math.pi / 3),
             cz + radius * math.sin(math.pi / 6 + i * math.pi / 3)) for i in range(6)]


def hash2(col, row):
    h = (col * 73856093) ^ (row * 19349663)
    # emulate JS 32-bit int xor then >>> 13 (unsigned)
    h &= 0xFFFFFFFF
    h = (h ^ (h >> 13)) & 0xFFFFFFFF
    return (h % 1000) / 1000


def tile_height(grid, cols, rows, c, r):
    if c < 0 or r < 0 or c >= cols or r >= rows:
        return H_WATER - 0.3
    m = grid[r * cols + c]
    jitter = (hash2(c, r) - 0.5) * 0.22
    if m & T["WATER"]:
        return H_WATER_BED
    if m & T["ROCK"]:
        return H_ROCK + (hash2(c * 7 + 1, r * 3 + 5) - 0.5) * 0.9
    if m & T["FOREST"]:
        return H_FOREST + jitter * 0.6
    if m & T["BUILDING"]:
        return H_BUILDING + jitter * 0.3
    if m & T["ROAD"]:
        return H_ROAD + jitter * 0.25
    return H_PLAIN + jitter


# ---- port of src/map.rs `bridge_hexes` -------------------------------------
def bridge_hexes(cols, rows, water, obstacles):
    bridges = set()
    water_set = set(water)
    obst = set(obstacles)

    def contains(h):
        c, r = offset_from_axial(*h)
        return 0 <= c < cols and 0 <= r < rows

    def land(h):
        return contains(h) and h not in water_set and h not in obst

    def row_water_cols(r):
        return [c for c in range(cols) if axial_from_offset(c, r) in water_set]

    for r in range(rows):
        if row_water_cols(r):
            continue
        up = row_water_cols(r - 1) if r > 0 else []
        down = row_water_cols(r + 1) if r + 1 < rows else []
        if not up and not down:
            continue
        union = sorted(set(up + down))
        cmin, cmax = union[0], union[-1]
        if cmax - cmin <= 4:
            for c in range(cmin, cmax + 1):
                h = axial_from_offset(c, r)
                if land(h):
                    bridges.add(h)

    def water_at(h):
        return h in water_set

    def opposite(h):
        c, r = offset_from_axial(*h)
        return land(h) and (
            (water_at(axial_from_offset(c, r - 1)) and water_at(axial_from_offset(c, r + 1)))
            or (water_at(axial_from_offset(c + 1, r)) and water_at(axial_from_offset(c - 1, r)))
        )

    def wnei(h):
        return sum(1 for dq, dr in NEI if (h[0] + dq, h[1] + dr) in water_set)

    opp_set = set()
    for c in range(cols):
        for r in range(rows):
            h = axial_from_offset(c, r)
            if land(h) and opposite(h) and h not in bridges:
                opp_set.add(h)
    chain = set()
    for h in opp_set:
        if any((h[0] + dq, h[1] + dr) in opp_set for dq, dr in NEI):
            chain.add(h)
    extra = set()
    for h in chain:
        for dq, dr in NEI:
            n = (h[0] + dq, h[1] + dr)
            if land(n) and wnei(n) >= 1 and n not in chain:
                extra.add(n)
    bridges |= chain | extra
    return bridges


# When True, bridges are rendered exactly like ordinary roads (the fix).
BRIDGE_AS_ROAD = ("--fixed" in sys.argv) or (__import__("os").environ.get("BRIDGE_AS_ROAD") == "1")


def build_roads(cols, rows, grid, h_of, bridge_set):
    """Return list of quads: (kind, [(x,y,z) x4], color). kind = 'plate'|'link'|'mark'|'rail'."""
    quads = []
    ROAD = (0.360784, 0.352941, 0.337255)
    MARK = (0.839216, 0.768627, 0.470588)
    RAIL = (150 / 255, 142 / 255, 120 / 255)

    for r in range(rows):
        for c in range(cols):
            mask = grid[r * cols + c]
            if not (mask & T["ROAD"]):
                continue
            aq, ar = axial_from_offset(c, r)
            wx, wz = axial_to_world(aq, ar)
            is_bridge = bool(mask & T["BRIDGE"])
            special = is_bridge and not BRIDGE_AS_ROAD
            lift = 0.55 if special else 0.07
            surface_y = H_WATER if (mask & T["WATER"]) else h_of[r * cols + c]
            base_y = surface_y + lift
            half = 2.4
            corners = hex_corners(wx, wz, HEX_R * 0.99)
            plate = [(wx, base_y, wz)] + [
                (corners[i][0] * 0.999 + wx * 0.001, base_y, corners[i][1] * 0.999 + wz * 0.001)
                for i in range(6)]
            quads.append(("plate", plate, ROAD, is_bridge))

            for i in range(6):
                dq, dr = ANG_DIRS[i]
                nq, nr = aq + dq, ar + dr
                noff_c = nq + ((nr - (nr & 1)) >> 1)
                noff_r = nr
                if not (0 <= noff_c < cols and 0 <= noff_r < rows):
                    continue
                nmask = grid[noff_r * cols + noff_c]
                if not (nmask & T["ROAD"]):
                    continue
                nwx, nwz = axial_to_world(nq, nr)
                ang = math.pi / 6 + i * math.pi / 3
                ex = wx + HEX_R * 0.5 * math.cos(ang)
                ez = wz + HEX_R * 0.5 * math.sin(ang)
                ny = (H_WATER if (nmask & T["WATER"]) else h_of[noff_r * cols + noff_c]) + lift
                perp_x, perp_z = math.cos(ang + math.pi / 2), math.sin(ang + math.pi / 2)
                link = [
                    (wx + perp_x * half, base_y, wz + perp_z * half),
                    (ex + perp_x * half, (base_y + ny) / 2 + 0.02, ez + perp_z * half),
                    (ex - perp_x * half, (base_y + ny) / 2 + 0.02, ez - perp_z * half),
                    (wx - perp_x * half, base_y, wz - perp_z * half),
                ]
                quads.append(("link", link, ROAD, is_bridge))
                if not special:
                    dx, dz = ex - wx, ez - wz
                    ln = math.hypot(dx, dz)
                    ux, uz = dx / ln, dz / ln
                    mx, mz = wx + ux * ln * 0.55, wz + uz * ln * 0.55
                    seg, wid = 1.7, 0.32
                    py = (base_y + ny) / 2 + 0.06
                    mark = [
                        (mx + perp_x * wid, py, mz + perp_z * wid),
                        (mx + ux * seg + perp_x * wid, py, mz + uz * seg + perp_z * wid),
                        (mx + ux * seg - perp_x * wid, py, mz + uz * seg - perp_z * wid),
                        (mx - perp_x * wid, py, mz - perp_z * wid),
                    ]
                    quads.append(("mark", mark, MARK, is_bridge))
            if special:
                for i in range(6):
                    dq, dr = ANG_DIRS[i]
                    nq, nr = aq + dq, ar + dr
                    noff_c = nq + ((nr - (nr & 1)) >> 1)
                    noff_r = nr
                    if not (0 <= noff_c < cols and 0 <= noff_r < rows):
                        continue
                    if grid[noff_r * cols + noff_c] & T["ROAD"]:
                        continue
                    ang = math.pi / 6 + i * math.pi / 3
                    ex = wx + HEX_R * 0.92 * math.cos(ang)
                    ez = wz + HEX_R * 0.92 * math.sin(ang)
                    perp_x, perp_z = math.cos(ang + math.pi / 2), math.sin(ang + math.pi / 2)
                    for sgn in (1, -1):
                        bx, bz = wx + perp_x * half * sgn, wz + perp_z * half * sgn
                        sx, sz = ex + perp_x * half * sgn, ez + perp_z * half * sgn
                        h = 0.9
                        quads.append(("rail", [(bx, base_y, bz), (sx, base_y, sz),
                                               (sx, base_y + h, sz), (bx, base_y + h, bz)], RAIL, True))
    return quads


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "maps/桥头堡之战.json"
    d = json.load(open(path, encoding="utf-8"))
    cols, rows = d["cols"], d["rows"]
    water = [tuple(x) for x in d["water"]]
    roads = [tuple(x) for x in d["roads"]]
    forests = [tuple(x) for x in d["forests"]]
    bld = [tuple(x) for x in d["buildings"]]
    obstacles = [tuple(x) for x in d.get("obstacles", [])]
    water_ax = [axial_from_offset(c, r) for c, r in water]
    obstacles_ax = [axial_from_offset(c, r) for c, r in obstacles]
    bridges = bridge_hexes(cols, rows, water_ax, obstacles_ax)

    grid = [0] * (cols * rows)
    for c, r in obstacles:
        grid[r * cols + c] |= T["ROCK"]
    for c, r in forests:
        grid[r * cols + c] |= T["FOREST"]
    for c, r in bld:
        grid[r * cols + c] |= T["BUILDING"]
    for c, r in water:
        grid[r * cols + c] |= T["WATER"]
    for c, r in roads:
        grid[r * cols + c] |= T["ROAD"]
    for (q, rr) in bridges:
        c, r = offset_from_axial(q, rr)
        grid[r * cols + c] |= T["BRIDGE"]

    h_of = [tile_height(grid, cols, rows, c, r) for r in range(rows) for c in range(cols)]
    quads = build_roads(cols, rows, grid, h_of, bridges)

    print("bridge cells (col,row):", sorted(offset_from_axial(*h) for h in bridges))
    bridge_quads = [q for q in quads if q[3]]
    print(f"total quads {len(quads)}, bridge quads {len(bridge_quads)}")
    from collections import Counter
    print("bridge quad kinds:", Counter(q[0] for q in bridge_quads))

    # save geometry for plotting / inspection
    import pickle
    out = "tools/_preview/roads_fixed.pkl" if BRIDGE_AS_ROAD else "tools/_preview/roads_before.pkl"
    with open(out, "wb") as f:
        pickle.dump(quads, f)
    print("wrote", out, "BRIDGE_AS_ROAD=", BRIDGE_AS_ROAD)

    # text cross-section: for a given column band, list y of plate at bridge vs road
    if len(sys.argv) > 2 and sys.argv[2] == "prof":
        for (c0, r0) in sorted(offset_from_axial(*h) for h in bridges):
            print(f"  cell ({c0},{r0}) h={h_of[r0*cols+c0]:.3f} "
                  f"mask={grid[r0*cols+c0]:#04x} bridge={bool(grid[r0*cols+c0] & T['BRIDGE'])}")


if __name__ == "__main__":
    main()
