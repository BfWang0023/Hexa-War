from pathlib import Path
import difflib,json,hashlib
out={}
for name in ['app.mjs','engine.mjs']:
 old=Path('docs/scout-v21/before',name).read_text().splitlines(keepends=True);new=Path('web3d/ancient',name).read_text().splitlines(keepends=True);changes=[]
 for op,a,b,c,d in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
  if op!='equal':changes.append(dict(at=len(''.join(new[:c]).encode('utf-16-le'))//2,removed=''.join(old[a:b]),added=''.join(new[c:d])))
 out[name]=changes
Path('docs/scout-v21/authorized.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
p=Path('docs/interaction-v19/authorized-core.json');data=json.loads(p.read_text());data['web3d/ancient/engine.mjs']=hashlib.sha256(Path('web3d/ancient/engine.mjs').read_bytes()).hexdigest();p.write_text(json.dumps(data,indent=2))
