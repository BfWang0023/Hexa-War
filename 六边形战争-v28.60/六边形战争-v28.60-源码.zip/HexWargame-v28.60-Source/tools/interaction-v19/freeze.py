from pathlib import Path
import difflib,json,hashlib
root=Path.cwd();out={}
for name in ['app.mjs','engine.mjs','save.mjs','elevation-rules.mjs','unit-animation.mjs']:
 old=(root/'docs/interaction-v19/before'/name).read_text();new=(root/'web3d/ancient'/name).read_text();changes=[]
 oldlines=old.splitlines(keepends=True);newlines=new.splitlines(keepends=True)
 for op,a,b,c,d in difflib.SequenceMatcher(None,oldlines,newlines,autojunk=False).get_opcodes():
  if op!='equal':changes.append(dict(at=len(''.join(newlines[:c]).encode('utf-16-le'))//2,removed=''.join(oldlines[a:b]),added=''.join(newlines[c:d])))
 out[name]=changes
(root/'docs/interaction-v19/authorized-edits.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
(root/'docs/interaction-v19/authorized-core.json').write_text(json.dumps({f'web3d/ancient/{p}':hashlib.sha256((root/'web3d/ancient'/p).read_bytes()).hexdigest() for p in ['engine.mjs','save.mjs']},indent=2))
