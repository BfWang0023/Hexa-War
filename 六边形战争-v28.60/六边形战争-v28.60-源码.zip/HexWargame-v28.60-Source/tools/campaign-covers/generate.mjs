import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { CAMPAIGN_CATALOG } from '../../web3d/ancient/campaign-catalog.mjs';
import { seriesForYear } from '../../web3d/ancient/campaign-series.mjs';
import { loadCampaign } from '../../web3d/ancient/campaign-loader.mjs';
import { importMap, TERRAIN } from '../../web3d/ancient/engine.mjs';

const out = new URL('../../web3d/ancient/assets/campaign-covers/', import.meta.url);
mkdirSync(out, { recursive: true });
const palettes = {
  dawn: ['#272c35','#a85b40','#f3bd79','#605245','#463731','#241e22'],
  axial: ['#152f3b','#577e78','#e2c890','#58716d','#334c48','#1b2e2e'],
  empire: ['#30252b','#a45342','#efb882','#796352','#52423d','#27292b'],
  sea: ['#122c3d','#557780','#f2d19b','#547b82','#2d4d57','#172e37'],
};
const ship = '<path d="M-54 6Q-44 26 29 24Q53 18 57-3L39 8H-43L-55-3Z" fill="currentColor"/><path d="M0 9V-57M-27-47H28M-35 13l-14 24m31-24-14 24m31-24-14 24m31-24L2 37m31-24L19 37" stroke="currentColor" stroke-width="3"/><path d="M-25-45H26Q19-22 27-3H-23Q-31-22-25-45Z" fill="#c6a076"/><path d="M-25-45 26-45M-25-15H25" stroke="#ead3a4" opacity=".6"/>';
const tower = '<path d="M-39 20V-26h9v7h9v-7h9v7h9v-7h9v7h9v-7h9v7h9v-7h8v46Z" fill="currentColor"/><path d="M-8 20V4a8 8 0 0 1 16 0v16" fill="#181c20"/><path d="M17-24v-25l21 5-21 7" stroke="#a57959" fill="#a57959"/>';
const soldier = '<path d="M-9 17-11 38h6l5-17 4 17h7L7 14M-8 0l-6 19H9L6 0Z" fill="currentColor"/><path d="M-9-4q-1-11 7-12 10 0 10 12H-9" fill="#b0946b"/><path d="M-11-4H9M13 34l4-58m-1 2 3-8 1 8" stroke="#b0946b" stroke-width="2"/><path d="M-12 2q-9 6 0 20 9-6 7-18Z" fill="#8d654d"/>';
const standard = '<path d="M0 32V-59" stroke="#b39369" stroke-width="3"/><path d="M1-57q16-9 37 0v27q-20-9-37 0Z" fill="#9b5040"/><path d="M7-54v20m9-21v20" stroke="#d5aa70" opacity=".6"/>';
const use = (id,x,y,s,fill) => `<use href="#${id}" transform="translate(${x} ${y}) scale(${s})" color="${fill}"/>`;
for (const c of CAMPAIGN_CATALOG) {
  let state = [...c.id].reduce((h,x)=>Math.imul(h^x.charCodeAt(0),16777619),2166136261)>>>0;
  const next = () => {state=(Math.imul(state,1664525)+1013904223)>>>0;return state/2**32;};
  const bundled = new URL(`../../web3d/ancient/bundled-maps/${c.id}.json`,import.meta.url);
  const map = existsSync(bundled) ? importMap(JSON.parse(readFileSync(bundled))) : loadCampaign(c.id);
  const ratio = flag => map.terrain.filter(t=>t&flag).length / map.terrain.length;
  const naval = ratio(TERRAIN.SEA)>.25 || /海战/.test(c.name);
  const siege = !naval && (/围城|陷落|攻城/.test(c.name)||map.units.filter(u=>u.kind==='fort').length>15);
  const river = !naval && ratio(TERRAIN.RIVER)>.012;
  const height = c.id==='china_jingxing' ? 1.45 : .52+Math.min(.82,ratio(TERRAIN.MOUNTAIN)*4.5);
  const [sky,horizon,sun,far,mid,ink]=palettes[naval?'sea':seriesForYear(c.year)];
  const focus = 490+Math.round(next()*235);
  const hills = (y,amplitude,fill) => {
    let path = `M-60 ${y}`;
    for(let x=-60;x<980;x+=70) {
      const ridge = y - Math.round((.25+next()*.75)*amplitude);
      path+=` Q${x+34} ${ridge-15} ${x+70} ${ridge+9}`;
    }
    return `<path d="${path}V360H-60Z" fill="${fill}"/>`;
  };
  let scene = hills(229,naval?31:102*height,far)+hills(266,naval?26:85*height,mid);
  if(naval||river){
    scene+=naval?'<path d="M0 220Q430 208 960 225V360H0Z" fill="#466c75"/>':
      `<path d="M${focus-16} 209Q${focus-170} 243 ${focus-58} 256T${focus-110} 360H${focus+140}Q${focus+115} 300 ${focus+24} 260T${focus+35} 209Z" fill="#758681"/>`;
    for(let i=0;i<54;i++){const x=river?focus-65+next()*112:next()*960,y=235+next()*112;scene+=`<path d="M${x.toFixed(1)} ${y.toFixed(1)}h${(4+next()*45).toFixed(1)}" stroke="#e3c7a1" opacity=".27"/>`;}
  }
  if(naval)for(let i=0;i<6;i++)scene+=use('ship',390+i*92+next()*39,234+next()*56,.39+next()*.73,ink);
  else{
    if(siege)for(let i=0;i<7;i++)scene+=use('tower',focus-150+i*49,219+next()*9,.75+next()*.12,ink);
    scene+=hills(332,naval?0:36,ink);
    for(let i=0;i<13;i++)scene+=use('soldier',392+i*37+next()*26,270+next()*46,.43+next()*.76,ink);
    scene+=use('standard',focus+64,269,1.16,ink)+use('standard',focus+185,301,.91,ink);
  }
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 360"><defs><linearGradient id="sky" x2="0" y2="1"><stop stop-color="${sky}"/><stop offset="1" stop-color="${horizon}"/></linearGradient><radialGradient id="light"><stop stop-color="${sun}"/><stop offset="1" stop-color="${sun}" stop-opacity="0"/></radialGradient><linearGradient id="shade" x2="0" y2="1"><stop stop-color="#11191c" stop-opacity="0"/><stop offset="1" stop-color="#11191c" stop-opacity=".44"/></linearGradient><g id="ship">${ship}</g><g id="tower">${tower}</g><g id="soldier">${soldier}</g><g id="standard">${standard}</g></defs><path d="M0 0h960v360H0Z" fill="url(#sky)"/><ellipse cx="${focus}" cy="132" rx="280" ry="122" fill="url(#light)" opacity=".66"/><circle cx="${focus}" cy="112" r="29" fill="${sun}" opacity=".85"/>${scene}<path d="M0 0h960v360H0Z" fill="url(#shade)"/><rect x="13" y="13" width="934" height="334" fill="none" stroke="#eed6a4" opacity=".3"/></svg>`;
  writeFileSync(new URL(c.id+'.svg',out),svg);
}
console.log(`Generated ${CAMPAIGN_CATALOG.length} campaign illustrations`);
