import test from 'node:test';
import assert from 'node:assert/strict';
import { aiTurn, newMap, addUnit, startGame } from '../../web3d/ancient/engine.mjs';
import { graphScore, makePolicy, newModel, validateModel } from './graph-policy.mjs';
import { positionScore } from './position-score.mjs';

test('graph policy scores legal tactical choices and leaves baseline behavior intact at zero output', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 1, 6);
  addUnit(map, 'heavy', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 4, 3);
  const base = startGame(map), candidate = startGame(map);
  const actor = base.map.units.find(u => u.kind === 'heavy');
  const model = validateModel(newModel());
  assert.equal(graphScore(model, base, actor, { type: 'attack', target: base.map.units.find(u => u.team === 'coalition') }), 0);
  assert.ok(Number.isFinite(graphScore(model, base, actor, { type: 'move', to: { c: 2, r: 3 } })));
  const plain = aiTurn(base, () => 0.5).map(x => [x.type, x.id, x.c, x.r, x.to?.c, x.to?.r]);
  const withModel = aiTurn(candidate, () => 0.5, makePolicy(model))
    .map(x => [x.type, x.id, x.c, x.r, x.to?.c, x.to?.r]);
  assert.deepEqual(withModel, plain);
});

test('position evaluator exposes material, tempo and strategic space without mutating battle state', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 1, 6);
  addUnit(map, 'heavy', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 8, 3);
  const game = startGame(map), before = JSON.stringify(game.map.units);
  const score = positionScore(game);
  for (const dimension of ['material', 'tempo', 'space'])
    for (const side of ['egypt', 'coalition']) assert.ok(Number.isFinite(score[dimension][side]));
  assert.equal(score.material.egypt, 1);
  assert.equal(score.material.coalition, 1);
  assert.equal(JSON.stringify(game.map.units), before);
});
