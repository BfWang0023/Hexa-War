// Opt-in execution adapter only. Existing training decisions/evaluation are unchanged.
import {createTacticalCommandAPI} from '../../web3d/ancient/tactical-command.mjs';
export function createAITacticalAdapter(options){
 const api=createTacticalCommandAPI(options);
 return {execute(command,team){return api.submit(command,{team,actor:'ai',selectedIds:[]});},cancel:ids=>api.cancel(ids),reset:()=>api.reset(),get pending(){return api.pending}};
}
