import {DAWN_IDS} from '../../web3d/ancient/dawn-data.mjs';
import {makeDawnMap} from '../../web3d/ancient/dawn-maps.mjs';
import {HELLENISTIC_IDS} from '../../web3d/ancient/hellenistic-data.mjs';
import {makeHellenisticMap} from '../../web3d/ancient/hellenistic-maps.mjs';
import {CLASSICAL_IDS} from '../../web3d/ancient/classical-data.mjs';
import {makeClassicalMap} from '../../web3d/ancient/classical-maps.mjs';
import { existsSync, readFileSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CHINA_CAMPAIGN_IDS, makeChinaMap } from '../../web3d/ancient/china-campaigns.mjs';
import { IMPERIAL_CAMPAIGN_IDS, makeImperialMap } from '../../web3d/ancient/imperial-campaigns.mjs';
import { mantineaMap, aegospotamiMap } from '../../web3d/ancient/greek-campaigns.mjs';
import * as engine from '../../web3d/ancient/engine.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const other = {
  megiddo: engine.megiddoMap, kadesh: engine.kadeshMap, troy: engine.troyMap,
  qarqar: engine.qarqarMap, babylon: engine.babylonMap, salamis: engine.salamisMap,
  mantinea: mantineaMap, aegospotami: aegospotamiMap, issus: engine.issusMap,
  tyre: engine.tyreMap, gaugamela: engine.gaugamelaMap, cannae: engine.cannaeMap,
  syracuse: engine.syracuseMap, zama: engine.zamaMap, pydna: engine.pydnaMap,
  carthage: engine.carthageMap, carrhae: engine.carrhaeMap, alesia: engine.alesiaMap,
  pharsalus: engine.pharsalusMap, actium: engine.actiumMap,
  teutoburg: engine.teutoburgMap, jerusalem: engine.jerusalemMap,
};
export function mapFor(id, mapsDir = null) {
  for (const path of [mapsDir && join(resolve(mapsDir), `${id}.json`),
    join(root, 'web3d/ancient/bundled-maps', `${id}.json`)]) {
    if (path && existsSync(path)) return engine.importMap(JSON.parse(readFileSync(path, 'utf8')));
  }
  if (DAWN_IDS.has(id)) return makeDawnMap(id);
  if (HELLENISTIC_IDS.has(id)) return makeHellenisticMap(id);
  if (CLASSICAL_IDS.has(id)) return makeClassicalMap(id);
  if (CHINA_CAMPAIGN_IDS.has(id)) return makeChinaMap(id);
  if (IMPERIAL_CAMPAIGN_IDS.has(id)) return makeImperialMap(id);
  if (other[id]) return other[id]();
  throw new Error(`未知战役地图: ${id}`);
}
export function seededRandom(seed) {
  let n = seed >>> 0;
  return () => { n = (n * 1664525 + 1013904223) >>> 0; return n / 4294967296; };
}
export function seedFor(id, seed) {
  let n = seed >>> 0;
  for (const ch of id) n = (Math.imul(n, 31) + ch.charCodeAt(0)) >>> 0;
  return n;
}
