import {planningState} from '../../web3d/ancient/fog-policy.mjs';
import { TERRAIN, distance, fortAt, isFord, tile, unitStats } from '../../web3d/ancient/engine.mjs';

// A small, dependency-free graph network. Nodes are the acting unit and nearby
// units; edges connect units within three hexes. Friendly and hostile messages
// use separate trainable channels. A candidate move changes the acting node's
// position before the graph is evaluated.
export const FEATURE_COUNT = 8;
export const MODEL_VERSION = 1;
export function newModel() {
  return { version: MODEL_VERSION, weights: [
    ...Array(FEATURE_COUNT).fill(1), // own node
    ...Array(FEATURE_COUNT).fill(0.2), // friendly messages
    ...Array(FEATURE_COUNT).fill(0.2), // hostile messages
    ...Array(FEATURE_COUNT).fill(0), // bias
    ...Array(FEATURE_COUNT).fill(0), // output
    0, 0, // move and attack biases
  ] };
}
export function validateModel(model) {
  if (model?.version !== MODEL_VERSION || !Array.isArray(model.weights) ||
      model.weights.length !== FEATURE_COUNT * 5 + 2 ||
      model.weights.some(x => !Number.isFinite(x) || Math.abs(x) > 20))
    throw new Error('图网络模型格式或权重无效');
  return model;
}
const clamp = x => Math.max(-1, Math.min(1, x));
function features(s, unit, position) {
  const stats = unitStats(s.map, unit), ground = tile(s.map, position.c, position.r)?.terrain || 0;
  return [
    clamp((unit.hp || 0) / Math.max(1, stats.hp * 10)),
    clamp((stats.melee || 0) / 12),
    clamp((stats.ranged || 0) / 12),
    clamp((stats.armor || 0) / 8),
    clamp(((unit.hunger || 0) + Math.max(0, 2 - (unit.fedTurns || 0))) / 7),
    ground & TERRAIN.ROAD ? 1 : 0,
    ground & TERRAIN.MOUNTAIN ? 1 : isFord(s.map, position.c, position.r) ? -1 : 0,
    fortAt(s.map, position.c, position.r)?.team === unit.team ? 1 : 0,
  ];
}
export function graphScore(model, s, actor, action) {
  s=planningState(s,actor.team);
  const position = action.type === 'move' ? action.to : actor;
  const nearby = s.map.units.filter(u => u.id !== actor.id && u.hp > 0 && !u.aboard &&
    u.kind !== 'fort' && distance(u, position) <= 5)
    .sort((a, b) => distance(a, position) - distance(b, position)).slice(0, 16);
  const own = features(s, actor, position);
  const friends = Array(FEATURE_COUNT).fill(0), foes = Array(FEATURE_COUNT).fill(0);
  let friendlyWeight = 0, hostileWeight = 0;
  for (const u of nearby) {
    const d = distance(u, position);
    if (d > 3) continue;
    const weight = 1 / Math.max(1, d);
    const target = u.team === actor.team ? friends : foes;
    for (let i = 0, f = features(s, u, u); i < FEATURE_COUNT; i++) target[i] += f[i] * weight;
    if (u.team === actor.team) friendlyWeight += weight; else hostileWeight += weight;
  }
  const w = model.weights;
  let score = 0;
  for (let i = 0; i < FEATURE_COUNT; i++) {
    const hidden = Math.tanh(w[i] * own[i] + w[8 + i] * friends[i] / Math.max(1, friendlyWeight) +
      w[16 + i] * foes[i] / Math.max(1, hostileWeight) + w[24 + i]);
    score += hidden * w[32 + i];
  }
  score = score * 3 / FEATURE_COUNT + w[action.type === 'attack' ? 41 : 40];
  return Math.max(-4, Math.min(4, score));
}
export const makePolicy = model => {
  validateModel(model);
  return (s, actor, action) => graphScore(model, s, actor, action);
};
