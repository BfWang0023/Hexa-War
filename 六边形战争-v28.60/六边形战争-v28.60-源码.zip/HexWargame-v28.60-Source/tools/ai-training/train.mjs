#!/usr/bin/env node
import {STANDARD_FOG_POLICY} from '../../web3d/ancient/fog-policy.mjs';
import { RULES_VERSION, DEFAULT_ELEVATION_RULES } from '../../web3d/ancient/elevation-rules.mjs';
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CAMPAIGN_CATALOG } from '../../web3d/ancient/campaign-catalog.mjs';
import { aiTurn, beginBattle, endSide, startGame } from '../../web3d/ancient/engine.mjs';
import { makePolicy, newModel, validateModel } from './graph-policy.mjs';
import { mapFor, seededRandom, seedFor } from './maps.mjs';
import { positionScore } from './position-score.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const args = process.argv.slice(2);
const value = (flag, fallback) => {
  const i = args.indexOf(flag);
  return i < 0 ? fallback : args[i + 1];
};
const positive = (flag, fallback) => {
  const n = Number(value(flag, fallback));
  if (!Number.isInteger(n) || n < 1) throw new Error(`${flag} 必须是正整数`);
  return n;
};
if (args.includes('--help')) {
  console.log('用法: node tools/ai-training/train.mjs [--generations 3] [--candidates 3] [--max-turns 20] [--max-ms 30000] [--scenarios china_muye,china_seven_states,mantinea] [--output ai-training] [--maps-dir 地图目录]');
  process.exit(0);
}
const generations = positive('--generations', 3), candidates = positive('--candidates', 3);
const maxTurns = positive('--max-turns', 20), maxMs = positive('--max-ms', 30000);
const scenarios = value('--scenarios', 'china_muye,china_seven_states,mantinea').split(',').filter(Boolean);
for (const id of scenarios) if (!CAMPAIGN_CATALOG.some(x => x.id === id)) throw new Error(`未知战役: ${id}`);
const mapsDir = value('--maps-dir', null);
const output = resolve(value('--output', join(root, 'ai-training-results')));
mkdirSync(output, { recursive: true });
const checkpointPath = join(output, 'checkpoint.json');
const modelPath = join(output, 'model.best.json');
const historyPath = join(output, 'history.jsonl');
const config = { fogPolicy:STANDARD_FOG_POLICY,rulesVersion:RULES_VERSION, elevationRules:DEFAULT_ELEVATION_RULES, generations, candidates, maxTurns, maxMs, scenarios, mapsDir: mapsDir ? resolve(mapsDir) : null };
let checkpoint = existsSync(checkpointPath) ? JSON.parse(readFileSync(checkpointPath, 'utf8')) : null;
if (checkpoint && JSON.stringify({ ...checkpoint.config, generations }) !== JSON.stringify(config))
  throw new Error('已有训练目录的参数不同。请使用新的 --output 目录，或继续原参数。');
let best = checkpoint ? validateModel(checkpoint.model) : newModel();
const perturbRng = seededRandom(0x4a7d1c2e);
let spare = null;
function gaussian() {
  if (spare !== null) { const x = spare; spare = null; return x; }
  const radius = Math.sqrt(-2 * Math.log(Math.max(1e-12, perturbRng())));
  const angle = 2 * Math.PI * perturbRng();
  spare = radius * Math.sin(angle);
  return radius * Math.cos(angle);
}
function opponent(team) { return team === 'egypt' ? 'coalition' : 'egypt'; }
function duel(id, seed, candidateSide, model) {
  const s = startGame(mapFor(id, mapsDir));
  if (s.deploying) beginBattle(s);
  s.aiDifficulty = 'hard';
  const rng = seededRandom(seedFor(id, seed));
  const policy = makePolicy(model);
  const opening = positionScore(s);
  const started = Date.now();
  while (!s.over && s.turn <= maxTurns && Date.now() - started < maxMs) {
    aiTurn(s, rng, s.side === candidateSide ? policy : null);
    if (!s.over) endSide(s, rng);
  }
  const closing = positionScore(s, opening.rawMaterial);
  const swing = dimension =>
    closing[dimension][candidateSide] - closing[dimension][opponent(candidateSide)] -
    (opening[dimension][candidateSide] - opening[dimension][opponent(candidateSide)]);
  const outcome = s.winner === candidateSide ? 1 : s.winner === opponent(candidateSide) ? -1 : 0;
  const dimensions = { material: swing('material'), tempo: swing('tempo'), space: swing('space') };
  return { score: outcome + 0.4 * dimensions.material + 0.2 * dimensions.tempo +
      0.2 * dimensions.space, dimensions, winner: s.winner,
    completed: s.over, turn: s.turn, elapsedMs: Date.now() - started };
}
function assess(model) {
  let total = 0, n = 0, errors = 0;
  for (const id of scenarios) for (const side of ['egypt', 'coalition']) {
    try {
      const result = duel(id, 1, side, model);
      total += result.score; n++;
    } catch (error) {
      errors++;
      appendFileSync(historyPath, JSON.stringify({ fogPolicy:STANDARD_FOG_POLICY,rulesVersion:RULES_VERSION, elevationRules:DEFAULT_ELEVATION_RULES, event: 'duel_error', id, side, error: String(error.stack || error) }) + '\n');
    }
  }
  if (errors) throw new Error(`${errors} 局训练对战失败；查看 history.jsonl 中的 duel_error`);
  return total / Math.max(1, n);
}
let bestFitness = checkpoint?.fitness ?? assess(best);
if (!checkpoint) {
  checkpoint = { generation: 0, config, model: best, fitness: bestFitness };
  writeFileSync(checkpointPath, JSON.stringify(checkpoint, null, 2));
  writeFileSync(modelPath, JSON.stringify(best, null, 2));
  appendFileSync(historyPath, JSON.stringify({ fogPolicy:STANDARD_FOG_POLICY,rulesVersion:RULES_VERSION, elevationRules:DEFAULT_ELEVATION_RULES, generation: 0, candidate: 'baseline', fitness: bestFitness }) + '\n');
  console.log(`初始基准得分 ${bestFitness.toFixed(3)}`);
}
for (let generation = checkpoint.generation + 1; generation <= generations; generation++) {
  const sigma = Math.max(0.08, 0.35 * Math.pow(0.85, generation - 1));
  let winner = best, winnerFitness = bestFitness;
  for (let candidate = 1; candidate <= candidates; candidate++) {
    const weights = best.weights.map((weight, i) => i < 8 ? weight :
      Math.max(-4, Math.min(4, weight + gaussian() * sigma)));
    const proposed = validateModel({ version: 1, weights });
    const fitness = assess(proposed);
    appendFileSync(historyPath, JSON.stringify({ fogPolicy:STANDARD_FOG_POLICY,rulesVersion:RULES_VERSION, elevationRules:DEFAULT_ELEVATION_RULES, generation, candidate, fitness, sigma }) + '\n');
    console.log(`第 ${generation}/${generations} 代，候选 ${candidate}/${candidates}：${fitness.toFixed(3)}`);
    if (fitness > winnerFitness + 1e-6) { winner = proposed; winnerFitness = fitness; }
  }
  best = winner; bestFitness = winnerFitness;
  checkpoint = { generation, config, model: best, fitness: bestFitness };
  writeFileSync(checkpointPath, JSON.stringify(checkpoint, null, 2));
  writeFileSync(modelPath, JSON.stringify(best, null, 2));
  console.log(`第 ${generation} 代完成，保留得分 ${bestFitness.toFixed(3)}`);
}
console.log(`训练结束；模型：${modelPath}；历史：${historyPath}`);
