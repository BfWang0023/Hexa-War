#!/usr/bin/env node
import {STANDARD_FOG_POLICY} from '../../web3d/ancient/fog-policy.mjs';
import { RULES_VERSION, DEFAULT_ELEVATION_RULES } from '../../web3d/ancient/elevation-rules.mjs';
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { CAMPAIGN_CATALOG } from '../../web3d/ancient/campaign-catalog.mjs';
import { mapFor, seededRandom, seedFor } from './maps.mjs';
import { makePolicy, validateModel } from './graph-policy.mjs';
import { positionScore } from './position-score.mjs';
import * as engine from '../../web3d/ancient/engine.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const args = process.argv.slice(2);
const value = (flag, fallback) => {
  const i = args.indexOf(flag);
  return i < 0 ? fallback : args[i + 1];
};
const positive = (flag, fallback) => {
  const n = Number(value(flag, fallback));
  if (!Number.isInteger(n) || n < 1) throw new Error(`${flag} 必须是正整数`);
  return n;
};
if (args.includes('--help')) {
  console.log('用法: node tools/ai-training/evaluate.mjs [--all | --scenario 战役ID] [--validate] [--seeds 1] [--max-turns 60] [--max-ms 120000] [--output 目录] [--maps-dir 自定义地图目录] [--policy 模型JSON --candidate-side egypt|coalition|both]');
  process.exit(0);
}
const ids = args.includes('--all') ? CAMPAIGN_CATALOG.map(x => x.id) :
  value('--scenario', null) ? [value('--scenario', null)] :
    ['china_muye', 'china_changping', 'china_seven_states', 'china_longxi', 'syracuse', 'actium'];
for (const id of ids) if (!CAMPAIGN_CATALOG.some(x => x.id === id)) throw new Error(`未知战役: ${id}`);
const seeds = positive('--seeds', 1), maxTurns = positive('--max-turns', 60);
const maxMs = positive('--max-ms', 120000);
const output = resolve(value('--output', join(root, 'ai-results')));
const mapsDir = value('--maps-dir', null);
const mapSource = mapsDir ? resolve(mapsDir) : 'bundled';
const policyPath = value('--policy', null);
const candidateSide = policyPath ? value('--candidate-side', 'both') : 'none';
if (!['none', 'egypt', 'coalition', 'both'].includes(candidateSide)) throw new Error('candidate-side 无效');
const policyBytes = policyPath ? readFileSync(resolve(policyPath)) : null;
const policyId = policyBytes ? createHash('sha256').update(policyBytes).digest('hex').slice(0, 12) : 'baseline';
const policy = policyBytes ? makePolicy(validateModel(JSON.parse(policyBytes))) : null;
mkdirSync(output, { recursive: true });
const jsonl = join(output, 'battles.jsonl');
const prior = existsSync(jsonl) ? readFileSync(jsonl, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line)) : [];
const done = new Set(prior.map(x => x.runKey));
if (args.includes('--validate')) {
  for (const id of ids) {
    const map = mapFor(id, mapsDir);
    engine.startGame(map);
    console.log(`地图可用 ${id}`);
  }
  console.log(`已验证 ${ids.length} 张地图`);
  process.exit(0);
}
const kinds = ['attack', 'move', 'replenish', 'recruit', 'phalanxMode', 'turnShip'];
function measure(s, initial, counts, started, stopped, opening) {
  const survivors = Object.fromEntries(['egypt', 'coalition'].map(team => [team,
    s.map.units.filter(u => u.team === team && u.kind !== 'fort' && u.hp > 0 && !engine.isRouted(u)).length]));
  const hunger = Object.fromEntries(['egypt', 'coalition'].map(team => [team,
    s.map.units.filter(u => u.team === team && u.hp > 0 && (u.hunger || 0) >= 3).length]));
  const closing = positionScore(s, opening.rawMaterial);
  const dimensions = Object.fromEntries(['material', 'tempo', 'space'].map(name => [name,
    Object.fromEntries(['egypt', 'coalition'].map(team => [team,
      closing[name][team] - opening[name][team]]))]));
  return { winner: s.winner, over: s.over, stopReason: stopped, turn: s.turn,
    elapsedMs: Date.now() - started, initial, survivors, hunger, dimensions, actions: counts };
}
function play(id, seed) {
  const s = engine.startGame(mapFor(id, mapsDir));
  if (s.deploying) engine.beginBattle(s);
  s.aiDifficulty = 'hard';
  const rng = seededRandom(seedFor(id, seed));
  const initial = Object.fromEntries(['egypt', 'coalition'].map(team => [team,
    s.map.units.filter(u => u.team === team && u.kind !== 'fort' && u.hp > 0).length]));
  const opening = positionScore(s);
  const counts = Object.fromEntries(['egypt', 'coalition'].map(team => [team,
    Object.fromEntries([...kinds, 'failedActions', 'fortAttacks', 'wagonAttacks', 'roadMoves', 'mountainMoves', 'fordMoves'].map(k => [k, 0]))]));
  const started = Date.now();
  let stopped = 'victory';
  while (!s.over) {
    if (s.turn > maxTurns) { stopped = 'turn_limit'; break; }
    if (Date.now() - started > maxMs) { stopped = 'time_limit'; break; }
    const team = s.side;
    const actions = engine.aiTurn(s, rng,
      policy && (candidateSide === 'both' || candidateSide === team) ? policy : null);
    for (const a of actions) {
      if (a.type in counts[team]) counts[team][a.type]++;
      if (a.result?.ok === false) counts[team].failedActions++;
      if (a.type === 'attack') {
        if (a.result?.visual?.defenderKind === 'fort') counts[team].fortAttacks++;
        if (a.result?.visual?.defenderKind === 'supplyWagon') counts[team].wagonAttacks++;
      }
      if (a.type === 'move' && a.to) {
        const ground = engine.tile(s.map, a.to.c, a.to.r)?.terrain || 0;
        if (ground & engine.TERRAIN.ROAD) counts[team].roadMoves++;
        if (ground & engine.TERRAIN.MOUNTAIN) counts[team].mountainMoves++;
        if (engine.isFord(s.map, a.to.c, a.to.r)) counts[team].fordMoves++;
      }
    }
    if (!s.over) engine.endSide(s, rng);
  }
  return measure(s, initial, counts, started, stopped, opening);
}
function report(rows) {
  const selected = rows.filter(x => ids.includes(x.scenarioId) && x.maxTurns === maxTurns &&
    x.maxMs === maxMs && x.mapSource === mapSource && x.policyId === policyId &&
    x.candidateSide === candidateSide);
  const lines = ['# AI 对抗测试报告', '',
    `生成时间：${new Date().toISOString()}`, '',
    '每行代表一张战役地图；胜负只在达到游戏内胜利条件时计入。达到回合或时间上限记为未完成。', '',
    '| 战役 | 局数 | 埃及/进攻方胜 | 联军/防守方胜 | 未完成 | 平均回合 |',
    '|---|---:|---:|---:|---:|---:|'];
  for (const id of ids) {
    const group = selected.filter(x => x.scenarioId === id);
    if (!group.length) continue;
    const title = CAMPAIGN_CATALOG.find(x => x.id === id).title;
    const wins = side => group.filter(x => x.over && x.winner === side).length;
    lines.push(`| ${title} | ${group.length} | ${wins('egypt')} | ${wins('coalition')} | ${group.filter(x => !x.over).length} | ${(group.reduce((n, x) => n + x.turn, 0) / group.length).toFixed(1)} |`);
  }
  lines.push('', '详细数据：`battles.jsonl`。若要比较新旧 AI，须分别在两个源码版本中使用相同参数和种子运行，然后比较两份结果。');
  writeFileSync(join(output, 'report.md'), lines.join('\n') + '\n');
}
let rows = prior;
for (const id of ids) for (let seed = 1; seed <= seeds; seed++) {
  const runKey = `${RULES_VERSION}:${id}:hard:${seed}:${maxTurns}:${maxMs}:${mapSource}:${policyId}:${candidateSide}`;
  if (done.has(runKey)) { console.log(`跳过已完成 ${runKey}`); continue; }
  console.log(`开始 ${id}，种子 ${seed}/${seeds}`);
  let result;
  try { result = play(id, seed); }
  catch (error) { result = { stopReason: 'error', error: String(error.stack || error), over: false, winner: null, turn: 0 }; }
  const row = { fogPolicy:STANDARD_FOG_POLICY,rulesVersion:RULES_VERSION, elevationRules:DEFAULT_ELEVATION_RULES, runKey, scenarioId: id, seed, maxTurns, maxMs, mapSource,
    policyId, candidateSide, ...result };
  appendFileSync(jsonl, JSON.stringify(row) + '\n');
  rows.push(row); report(rows);
  console.log(`${id}: ${row.stopReason}，回合 ${row.turn}，胜方 ${row.winner || '无'}`);
}
report(rows);
console.log(`报告已保存：${join(output, 'report.md')}`);
