import { TERRAIN, distance, isRouted, isShip, neighbors, tile, unitMaxHp, unitStats } from '../../web3d/ancient/engine.mjs';

const teams = ['egypt', 'coalition'];
const opponent = team => team === 'egypt' ? 'coalition' : 'egypt';
const active = (s, team) => s.map.units.filter(u => u.team === team && u.hp > 0 &&
  !u.aboard && !isRouted(u) && !['fort', 'captive', 'supplyWagon'].includes(u.kind));
const strength = (s, u) => {
  const stat = unitStats(s.map, u);
  const endurance = Math.max(0, Math.min(1, u.hp / Math.max(1, unitMaxHp(s.map, u))));
  const support = ['moraleGuard', 'moraleFlagship'].includes(u.kind) ? 2 : 0;
  return endurance * (2 + Math.max(0, stat.melee || 0) +
    Math.max(0, stat.ranged || 0) * 0.8 + Math.max(0, stat.armor || 0) * 0.7 +
    Math.max(0, stat.move || 0) * 0.4 + support);
};
const point = value => value && Number.isInteger(value.c) && Number.isInteger(value.r) ?
  { c: value.c, r: value.r } : null;
function strategicSites(map) {
  const victory = map.victory || {};
  const sites = [victory.objective, victory.capture, victory.rescue, victory.harbor,
    victory.byrsa, victory.escape, { c: Math.floor(map.cols / 2), r: Math.floor(map.rows / 2) }];
  for (const team of teams) sites.push(...(map.logistics?.depots?.[team] || []).slice(0, 2));
  for (const bridge of (map.bridges || []).slice(0, 6))
    sites.push(Array.isArray(bridge) ? { c: bridge[0], r: bridge[1] } : bridge);
  const junctions = [];
  for (let r = 1; r < map.rows - 1; r++) for (let c = 1; c < map.cols - 1; c++) {
    if (!(tile(map, c, r).terrain & TERRAIN.ROAD)) continue;
    const roads = neighbors(c, r).filter(p => p.c >= 0 && p.r >= 0 &&
      p.c < map.cols && p.r < map.rows && (tile(map, p.c, p.r).terrain & TERRAIN.ROAD)).length;
    if (roads >= 3) junctions.push({ c, r });
  }
  const center = { c: map.cols / 2, r: map.rows / 2 };
  junctions.sort((a, b) => distance(a, center) - distance(b, center));
  for (const junction of junctions) {
    if (sites.filter(Boolean).some(site => point(site) && distance(junction, point(site)) < 6)) continue;
    sites.push(junction);
    if (sites.length >= 14) break;
  }
  const seen = new Set();
  return sites.map(point).filter(p => {
    if (!p || p.c < 0 || p.r < 0 || p.c >= map.cols || p.r >= map.rows) return false;
    const key = `${p.c},${p.r}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}
export function positionScore(s, initialMaterial = null) {
  const units = Object.fromEntries(teams.map(team => [team, active(s, team)]));
  const rawMaterial = Object.fromEntries(teams.map(team => [team,
    units[team].reduce((sum, u) => sum + strength(s, u), 0)]));
  const material = Object.fromEntries(teams.map(team => [team,
    rawMaterial[team] / Math.max(1, initialMaterial?.[team] || rawMaterial[team])]));
  const tempo = Object.fromEntries(teams.map(team => [team, (() => {
    const foes = units[opponent(team)];
    if (!foes.length || !units[team].length) return 0;
    return units[team].reduce((sum, u) => {
      const nearest = Math.min(...foes.filter(e => isShip(e) === isShip(u)).map(e => distance(u, e)));
      if (!Number.isFinite(nearest)) return sum;
      const stat = unitStats(s.map, u);
      const reach = Math.max(1, stat.range || 1);
      return sum + (nearest <= reach ? 1 : Math.max(0, 1 - (nearest - reach) / 10));
    }, 0) / units[team].length;
  })()]));
  const sites = strategicSites(s.map);
  const space = Object.fromEntries(teams.map(team => [team, sites.length ? sites.reduce((sum, site) => {
    const own = Math.min(...units[team].map(u => distance(u, site)));
    const foe = Math.min(...units[opponent(team)].map(u => distance(u, site)));
    return sum + (own < foe ? Math.max(0, 1 - own / 10) : 0);
  }, 0) / sites.length : 0]));
  return { material, tempo, space, rawMaterial, sites: sites.length };
}
