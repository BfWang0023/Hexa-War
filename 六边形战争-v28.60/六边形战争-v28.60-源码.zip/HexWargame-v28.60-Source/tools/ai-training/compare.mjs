#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { CAMPAIGN_CATALOG } from '../../web3d/ancient/campaign-catalog.mjs';

const root = resolve(process.argv[2] || 'ai-results');
const rows = name => readFileSync(join(root, name, 'battles.jsonl'), 'utf8').trim()
  .split('\n').filter(Boolean).map(line => JSON.parse(line));
const baseline = rows('baseline'), egypt = rows('candidate-egypt'), coalition = rows('candidate-coalition');
const get = (list, id, seed) => list.find(x => x.scenarioId === id && x.seed === seed);
const lines = ['# 图网络候选指挥官对比', '',
  '每场保持相同地图和随机种子。候选方分别执掌两阵营，对手使用现有规则 AI。胜率变化须结合逐局记录复盘，不能单凭总胜场判定策略提升。', '',
  '| 战役 | 基准胜方 | 候选执掌甲方时胜方 | 候选执掌乙方时胜方 | 甲方子力/时间/空间变化 | 乙方子力/时间/空间变化 | 异常 |',
  '|---|---|---|---|---|---|---|'];
for (const campaign of CAMPAIGN_CATALOG) {
  const id = campaign.id, b = get(baseline, id, 1), e = get(egypt, id, 1), c = get(coalition, id, 1);
  if (!b && !e && !c) continue;
  const name = row => row?.stopReason === 'error' ? '报错' : row?.over ? row.winner || '无' : row?.stopReason || '缺失';
  const flag = [b, e, c].some(row => !row || row.stopReason === 'error') ? '需检查' : '';
  const changes = (candidate, side) => ['material', 'tempo', 'space'].map(d => {
    const x = candidate?.dimensions?.[d]?.[side], y = b?.dimensions?.[d]?.[side];
    return Number.isFinite(x) && Number.isFinite(y) ? (x - y).toFixed(2) : '—';
  }).join(' / ');
  lines.push(`| ${campaign.title} | ${name(b)} | ${name(e)} | ${name(c)} | ${changes(e, 'egypt')} | ${changes(c, 'coalition')} | ${flag} |`);
}
lines.push('', '原始逐局数据分别保存在三个子目录的 `battles.jsonl`。下一步应查看候选方败局、未完成局、异常粮车与工事攻击，再决定是否把图网络用于游戏默认 AI。');
const report = join(root, '对抗对比报告.md');
writeFileSync(report, lines.join('\n') + '\n');
console.log(`对比报告：${report}`);
