from pathlib import Path
import json,hashlib,re,os
root=Path('.');out=root/'docs/fog-art-20261029';read=lambda n:json.loads((out/n).read_text())
a,b=read('before-visual.json'),read('after-visual.json');baseline=read('before/hashes.json');modified=[k for k,h in baseline.items() if Path(k).is_file() and hashlib.sha256(Path(k).read_bytes()).hexdigest()!=h];added=[str(p) for p in Path('web3d/ancient').glob('*.mjs') if str(p) not in baseline];protected=['engine.mjs','fog-policy.mjs','reconnaissance.mjs','save.mjs','elevation-rules.mjs','app.mjs','tactical-command.mjs','order-officer.mjs'];audit={'modified':modified,'added':added,'protectedUnchanged':{n:hashlib.sha256(Path('web3d/ancient',n).read_bytes()).hexdigest()==baseline['web3d/ancient/'+n] for n in protected},'manualMapsUnchanged':all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==h for k,h in baseline.items() if '/bundled-maps/' in k),'finalHashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('web3d').rglob('*') if p.is_file()}}
(out/'source-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));assert all(audit['protectedUnchanged'].values()) and audit['manualMapsUnchanged']
rows=[]
for key,name in [('performance','复现战场，40×30'),('large','长平，4,428 格 / 384 棋子（含工事）')]:
 old,new=a[key],b[key];assert old['camera']==new['camera'];rows.append(f"|{name}|{old['averageFPS']:.2f} → {new['averageFPS']:.2f}|{old['low1FPS']:.2f} → {new['low1FPS']:.2f}|{old['drawCalls']} → {new['drawCalls']}|{old['triangles']:,} → {new['triangles']:,}|{old.get('heapAfterGCBytes',old['heapBytes'])/1048576:.1f} → {new.get('heapAfterGCBytes',new['heapBytes'])/1048576:.1f}|")
full=(out/'all-tests.txt').read_text();passed=re.findall(r'# pass (\d+)',full)[-1];fail=re.findall(r'# fail (\d+)',full)[-1];assert fail=='0';trace=b.get('animation',[]);middle=sum(0<(v.get('blend') or 0)<1 for v in trace);assert middle>0
report=f'''# Terrain Fog 视觉专项：v14.1 交付报告

2026-10-29。视觉补丁 v14.1，战斗和存档规则继续为 v14。

## 完成的效果

未知区域改为低饱和橄榄灰，加入极轻的世界坐标多尺度纹理；不发光、不透明展示真实地形，不再采用浅蓝灰色或纯黑底。未知区碎石装饰一并隐藏，减少亮点和错误的地表暗示。

迷雾直接合成在地表、道路、水面和静态装饰材质上，替代旧的每格透明雾平面。没有悬浮覆盖网格，不增加后处理、粒子或实时光源。地表原有几何和单位贴地接口保持；未知地表仍来自权限层的安全替代地图。

边界使用世界空间连续蒙版、两次可分离平滑和双线性采样，约一个六角格量级羽化。低频扰动减少机械感；未知区网格强度降到原来的约 1.8%，已知区网格仍正常。边界不是通过透明显示真实未知地形形成的。

三层状态：当前可见正常显示；历史已知地形适度降低饱和度与亮度；完全未知显示统一的橄榄灰雾背景。敌军实时/历史标记沿用 v14 权限。地形迷雾关闭后材质分支直接跳过雾处理。

揭雾采用 350 ms 的旧/新蒙版插值，从首个实际渲染帧开始计时，避免地形块重建吞掉动画。连续变化时从当前显示状态继续，避免跳变。侦察和 AP 立即由引擎结算；渐变仅改变画面，不写回地图或规则状态。切换地图或阵营不会把上一观察者的画面渐变给下一观察者。

小地图采用协调的暗橄榄灰未知底色，同样柔化边界、保留高程设色、等高线、道路、设施、单位和镜头框。蒙版采样密度为三维版本的一半，生成后缓存；渐变阶段只混合缓存图层，不逐帧重绘复杂地形。

## 实际验证

- 全量 Node 测试：{passed} 通过，0 失败；新增美术测试覆盖安全蒙版、连续边界、350 ms 中间状态、连续更新、资源释放、同面积尺寸改变、雾关闭、未知装饰过滤、小地图低成本采样。
- 原双迷雾、地形记忆、敌情历史、AI/传令官输入隔离、移动及高差伤害测试均保留。
- 实际浏览器检查俯视、斜视及低视角，并监听页面错误与 WebGL 着色器错误，均未发现错误。
- 复现场景包含不规则侦察区域、连续山区、道路、河流、桥梁和渡口。通过游戏原有选格/移动处理执行高地弓兵侦察移动，消耗 1 AP；未知格由 {b['scout']['before']} 减少至 {b['scout']['after']}。
- 动画录制取得 {len(trace)} 个渲染采样，其中 {middle} 个为 0 与 1 之间的真实插值状态；不是模拟动画返回值。
- 验证关闭 Terrain Fog 后全部静态地形恢复。规则、权限、存档、地形逻辑高程与 42 张人工地图文件哈希不变，见 `source-audit.json`。

## 前后截图与动画

使用保存的旧版源文件与优化后代码分别启动同一游戏。复现相同地图、单位、侦察范围、分辨率和固定镜头。当前消息没有另附可读取的新截图文件，因此采用与现有浅蓝六角雾画面接近的实际运行场景，不宣称逐像素匹配用户原图。

|视角/状态|优化前|优化后|
|---|---|---|
|俯视|`before-top.png`|`after-top.png`|
|斜视|`before-oblique.png`|`after-oblique.png`|
|低视角|`before-low.png`|`after-low.png`|
|揭雾开始/中间/结束|`before-reveal-*.png`|`after-reveal-*.png`|
|长平大地图|`before-changping.png`|`after-changping.png`|
|关闭地形迷雾|`before-fog-off.png`|`after-fog-off.png`|

`reveal.webm` 为实际游戏画布录制的侦察移动与揭雾动画；`after-visual.json` 保存实际移动、AP、逐帧渐变采样和运行指标。

## 性能

设备 Apple M4 / 16 GB，Chrome，1440×1000，DPR=1；标准画质。每场 600 帧约 10 秒，前后分别运行，固定相同相机。平均 FPS 为平均帧间隔的倒数；1% Low 为最慢 6 帧平均间隔的倒数。堆内存在相同的 Chrome 强制 GC 步骤后读取，仍是 JS 堆近似，不是进程总内存或 GPU 显存。

|场景|平均 FPS 前→后|1% Low 前→后|Draw Calls 前→后|三角形 前→后|GC 后 JS 堆 MiB 前→后|
|---|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

实际地图规模与部署数量保持，减少的是旧雾平面及未知区的装饰绘制。GPU 蒙版共两张 RGBA 小纹理；不会逐帧重新生成，低细节模式仍沿用原有降级。小地图静态构建的单次采样：复现场景 {a['performance']['recon']['terrainMs']:.2f} → {b['performance']['recon']['terrainMs']:.2f} ms；长平 {a['large']['recon']['terrainMs']:.2f} → {b['large']['recon']['terrainMs']:.2f} ms。这是一次缓存构建时间，不能解释为每帧开销；动态标记绘制数据见 JSON。

## 主要修改

{chr(10).join('- `'+x+'`' for x in modified+added)}

验证脚本位于 `tools/fog-art-20261029/`，源文件基线保存在 `before/`。没有修改引擎、AI、传令官权限、侦察记录、存档规则或战役地图。

## 边界与未验证项

- 本轮完成要求内的渲染实现与上述实际验证。M1 及原生 WKWebView 长时间性能未测，不能宣称已经达到 M1 稳定 60 FPS。
- FPS 为短期静止镜头样本，动画视频用于验证视觉渐变，不能替代长期大规模行军压力测试。
- 地图外缘保留原战棋地图的外轮廓；本次柔化的是已知/未知信息边界。
- 本轮未对全部 85 场逐一重拍 GPU 画面；使用完整自动化回归及代表性平原/山地/河流/桥渡/大地图运行验证。
- 没有新增网络调用或远程 LLM 测量；此项为渲染专项，信息权限模块保持原样。

安装包独立解压、签名和资源一致性检查结果见 `package-verification.json`。
'''
(out/'地形迷雾视觉专项优化报告.md').write_text(report)
summary={'device':'Apple M4 16 GB','viewport':[1440,1000],'framesPerScene':600,'before':{'small':a['performance'],'large':a['large']},'after':{'small':b['performance'],'large':b['large']},'renderedAnimationSamples':len(trace),'intermediateSamples':middle,'testsPassed':int(passed),'testsFailed':int(fail)};(out/'performance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
