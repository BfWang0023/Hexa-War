import fs from 'node:fs';
import {initializeMutiny,settleMutiny,MUTINY_RULES} from '../../web3d/ancient/mutiny.mjs';
import {distance} from '../../web3d/ancient/engine.mjs';
const trials=1000,units=200,rounds=30,rows=[];
for(const mode of ['healthy','brief-arrears','prolonged-arrears','prolonged-veterans','propagation']){
 let battles=0,total=0,largest=0;
 for(let seed=1;seed<=trials;seed++){
  const s={turn:1,log:[],map:{logistics:{},units:Array.from({length:units},(_,i)=>({id:'u'+i,kind:'light',team:i%2?'egypt':'coalition',c:i%20,r:Math.floor(i/20),hp:70,actionsLeft:2,veteranLevel:mode==='prolonged-veterans'?4:0}))}};
  initializeMutiny(s,Math.imul(seed,2654435761));
  if(mode==='propagation'){const u=s.map.units[100];u.mutinous=true;s.mutinyState.pending=[{id:u.id,turn:0}];}
  for(let turn=1;turn<=rounds;turn++){
   s.turn=turn;
   for(const u of s.map.units)u.unpaidTurns=mode==='brief-arrears'&&turn>=10&&turn<=12?3:mode.startsWith('prolonged')?turn:0;
   settleMutiny(s,distance);
  }
  const count=s.map.units.filter(u=>u.mutinous).length-Number(mode==='propagation');
  battles+=Number(count>0);total+=count;largest=Math.max(largest,count);
 }
 rows.push({mode,trials,units,rounds,atLeastOne:battles/trials,meanMutinies:total/trials,maximumMutinies:largest});
}
const report={config:MUTINY_RULES,rows};fs.writeFileSync('docs/mutiny-veterancy/probability.json',JSON.stringify(report,null,2));console.log(JSON.stringify(rows));
