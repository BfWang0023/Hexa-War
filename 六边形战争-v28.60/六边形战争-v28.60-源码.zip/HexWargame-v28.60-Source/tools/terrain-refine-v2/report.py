from pathlib import Path
import json,hashlib,re
out=Path('docs/terrain-refine-v2');read=lambda n:json.loads((out/n).read_text());before,after=read('before-visual.json'),read('after-visual.json');baseline=read('before/hashes.json')
modified=[k for k,h in baseline.items() if Path(k).is_file() and hashlib.sha256(Path(k).read_bytes()).hexdigest()!=h]
added=[str(p) for p in Path('web3d/ancient').glob('*.mjs') if str(p) not in baseline]
protected=['app.mjs','engine.mjs','auto-elevation.mjs','elevation-rules.mjs','fog-policy.mjs','knowledge-mist.mjs','reconnaissance.mjs','save.mjs','tactical-command.mjs']
protected=[n for n in protected if 'web3d/ancient/'+n in baseline]
audit={'modified':modified,'added':added,'protectedUnchanged':{n:hashlib.sha256(Path('web3d/ancient',n).read_bytes()).hexdigest()==baseline['web3d/ancient/'+n] for n in protected},'manualMapsUnchanged':all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==h for k,h in baseline.items() if '/bundled-maps/' in k),'manualMapFiles':sum('/bundled-maps/' in k for k in baseline)}
assert all(audit['protectedUnchanged'].values()) and audit['manualMapsUnchanged'];(out/'source-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
tests=(out/'all-tests.txt').read_text();passed=re.findall(r'# pass (\d+)',tests)[-1];assert re.findall(r'# fail (\d+)',tests)[-1]=='0';e2e=read('e2e.json');assert len(e2e['campaigns'])==85 and not e2e['errors'] and not after['errors']
rows=[]
for key,name in [('performance','复现场景 / 地形迷雾开启'),('fullPerformance','复现场景 / 完整地形'),('large','长平 4,428 格 / 384 棋子（含工事）')]:
 a,b=before[key],after[key];assert a['camera']==b['camera'];heap=f"{a['heapAfterGCBytes']/1048576:.1f} → {b['heapAfterGCBytes']/1048576:.1f}" if 'heapAfterGCBytes' in a else '未单独采集';rows.append(f"|{name}|{a['averageFPS']:.2f} → {b['averageFPS']:.2f}|{a['low1FPS']:.2f} → {b['low1FPS']:.2f}|{a['drawCalls']} → {b['drawCalls']}|{a['triangles']:,} → {b['triangles']:,}|{heap}|")
shots=[]
for stem,title in [('overview','常用斜俯视'),('road-close','近距离坡面与转弯山路'),('mountain-low','低角度山脊轮廓'),('distant','拉远整体山势'),('oblique','地形迷雾 / 斜视'),('low','地形迷雾 / 低视角'),('changping','长平实际大地图')]:
 shots.append(f"|{title}|[优化前]({(out/('before-'+stem+'.png')).resolve()})|[优化后]({(out/('after-'+stem+'.png')).resolve()})|")
report=f'''# 地形美术精修 v2 / v14.3 实施与验证报告

2026-10-29。视觉补丁；正式战斗、地形生成及存档规则仍为 v14。

## 诊断与实际修改

原有连续表面已有足够的整体高差，问题主要来自山地区域覆盖率强制叠加的深绿色底色，以及较宽的高程平滑范围。大面积颜色带压低了坡面反差，掩盖了真实几何。道路原来由格中心到邻格边缘的直线半段组成；装饰物主要按逐格随机概率散布。

|范围|本次实现|
|---|---|
|几何与高差|保留显示纵向比例 4.6，不修改正式海拔。自动地形插值权重分母 78 调为 64，稍收紧过度平滑；既有跨格山脊细节由 3.4 调为 5.0，鞍部改为有正负变化，次级起伏由 0.65 调为 1.4。增强轮廓而非抬高整片山体；不增加单格山峰。|
|颜色与材质|移除深绿覆盖率保底。平原低饱和草绿，山麓黄绿，坡面土黄/浅棕，高处暖灰褐岩色；仅极高逻辑海拔逐渐接近暖白。连续逻辑高程、坡度和法线共同决定颜色，保留世界坐标连续细纹，不增加逐格随机色。|
|光照与法线|保留同一连续高度场的解析法线及跨块一致性。环境光 1.55→1.35、方向光 1.75→1.85，太阳高度 180→160；微调地面反射色。修复拉远整图近黑的问题，环境距离雾起止由 260/700 调整到 320/1400，不影响独立地形迷雾。沿用原有缓存阴影，不新增灯光、后处理或山体实时自阴影。|
|道路|新增独立纯视觉路径模块；两方向道路用二次曲线连接两侧共享端点，端点切线一致。交汇保留所有合法分支；宽度统一，外沿颜色融入地表。道路各顶点采样实际三角网格，分块边缘使用所属格的网格采样。没有改变 ROAD 位、通行格或寻路拓扑。|
|植被与石块|用已知逻辑高程、邻域坡度、谷地/脊顶及世界坐标连续斑块组织分布。谷地/山麓集中、脊顶更少；山石改为稀疏小组，平原碎石概率下降。保留实例化、材质复用、低画质降级和原有灌木尺寸；道路、河桥、房屋和工事区域保持清楚。|
|网格|连续表面网格透明度 0.23→0.16，保留设置中的网格开关及原拾取流程。|

材质的美术分段约为：0–1 黄绿山麓，0.9–2.5 土黄色坡面，2.3–4.6 浅棕/灰黄，4.2–6.6 暖灰岩色，7.2–9.2 极高处暖白。这些是抽象逻辑高程区间，不是现实米数，不新增雪地规则。沙漠和条顿堡等已有特殊配色保留。

## 真实截图与运行验证

本条请求没有新增可读取的最新截图文件，采用当前版本的固定复现场景，并补充长平战场。复现场景包含平原、山麓、连续山体、鞍部与山口通道、转弯山路、河流、桥梁和渡口。旧代码完整保存到 `before/`，浏览器通过相同脚本加载旧/新代码，场景、镜头、分辨率一致。

|视角|前|后|
|---|---|---|
{chr(10).join(shots)}

另有 `after-extreme-highland.png`：80×60 宽阔山区，自动生成最高逻辑高程 {after['highland']['maxLogical']}，用于观察峰群、鞍谷和极高处暖白；没有手动添加海拔。`selection-and-move-range.png` 为实际鼠标选择山路弓兵并显示行动范围。

实际侦察移动通过游戏选格/行动处理完成，消耗一次行动，未知格 {after['scout']['before']} → {after['scout']['after']}；`reveal.webm` 与 `after-reveal-start/mid/end.png` 保留原有揭雾过程。检测到真实中间动画帧，关闭地形迷雾恢复完整地形。页面及着色器错误为 0。

## 规则、存档与信息安全

未改正式逻辑高程生成、移动/AP、道路奖励、山地兵种限制、高低差伤害、AI、传令官、存档、侦察权限或小地图的正式高程配色。未写回地图或使用装饰高度结算战斗。主地图的视觉细节不要求与地形图颜色完全一致，小地图继续依据相同的正式海拔显示等高线和层色。

`source-audit.json` 验证规则、应用、自动海拔、迷雾权限/蒙版和侦察等保护文件逐字节不变；42 张人工地图原文不变。原有 85 场战役全部保留。

新增地形分析仅读取已授权地图，忽略未知邻格。已有隐藏山区修改不影响已知视觉场、双方情报隔离、AI/传令官上下文、四种迷雾组合及旧存档测试均继续通过。未知区域仍为安全替代地表，未为了柔化画面开放真实山峰、道路或设施。

## 自动化与端到端测试

- 全部 `web3d/ancient/*.test.mjs`：**{passed} 项通过、0 失败**，含规则、AI、传令官、地形编辑、存档、高低差、桥渡和双迷雾回归。原有测试未删除；山地配色断言按本轮黄绿/土黄方向调整，保留几何、信息安全及规则不变断言。
- 新增 8 项专项：道路曲线及共享端点/切线、交汇分支不丢失、装饰确定性与未知区隔离、已知邻域分析、移除深绿带、道路转弯/分块贴地、跨多格山脊/鞍部连续起伏、远视距离雾与降级。
- 浏览器：**85 场实际加载通过**，默认情报规则及双迷雾四种组合通过；单位本体/底座锚点与实际山体网格一致；投影山格准确拾取；真实鼠标点击选中山路弓兵。运行记录 `e2e.json/txt`。
- 实际地表三角形、跨块高度/法线/颜色一致、单格中心射线拾取和缓存刷新继续由既有测试覆盖。新增道路使用相同网格采样；不更换选格接口。

## 性能实测

Apple M4 / 16 GB，Chrome，1440×1000，DPR 1，标准画质；前后相同镜头、部署和地图，每场 600 帧，顺序运行。1% Low 为最慢 6 帧平均帧间隔的倒数。没有降低地图规模或单位数量。

|场景|平均 FPS 前→后|1% Low 前→后|Draw Calls 前→后|三角形 前→后|GC 后 JS 堆 MiB 前→后|
|---|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

页面导航到游戏准备就绪的实测耗时（含资源/脚本/地图与初始化，不是单独地图生成时间）：美吉多 {before['loads'][0]['readyMs']}→{after['loads'][0]['readyMs']} ms；长平 {before['loads'][1]['readyMs']}→{after['loads'][1]['readyMs']} ms。缓存状态随顺序加载，单次样本不能代表稳定加载分布。

JS 堆在请求 GC 后，通过 Chrome 调试接口 Runtime.getHeapUsage 实时读取，避免 performance.memory 的缓存值误判；对象保留时机仍影响单次样本，不把其差异当作可靠内存优化比例。未获取进程总内存或 GPU 显存。FPS 受 60 Hz 刷新上限限制，不能据此推断 GPU 剩余性能。

曲线路面仍按原静态分块合批，未增加每段道路独立 Draw Call；表面/颜色/分布均只在构建或刷新时计算。装饰更稀疏使实际提交量下降；没有通过减少兵力或修改规则获取性能。既有低画质与植被降级保留。

## 文件清单

{chr(10).join('- `'+x+'`' for x in modified+added)}

辅助脚本：`tools/terrain-refine-v2/visual.cjs`、`regression.cjs`、`report.py`；基线、真实截图、录像、原始数据和日志：`docs/terrain-refine-v2/`。根目录两份交接说明增加本次补丁记录。

## 交付与限制

安装包和源码：`dist/terrain-refine-v2/`；安装包独立解压、签名与网页资源一致性校验见 `package-verification.json`。

未在 M1 或原生 WKWebView 中完成长时间性能测试；不能宣称已满足所有 M1 场景稳定 60 FPS。此次实际画面验证为代表场景和长平，不是全部 85 场的美术逐帧检查。道路多方向交汇保留六角网络所有分支，仍具有策略地图的简洁轮廓；本轮未引入高成本样条路网重建。低角度下真实山体仍可能遮住后方地物，使用原有战术视角、部队列表与标识操作。
'''
(out/'地形美术精修v2验证报告.md').write_text(report)
print('report generated',passed,'tests',len(e2e['campaigns']),'campaigns')
