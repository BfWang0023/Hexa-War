// Historical metadata and initial deployment hints, never combat modifiers.
const A='https://www.gutenberg.org/files/46976/46976-h/46976-h.htm';
export const HELLENISTIC_CAMPAIGNS=Object.freeze([
 {id:'granicus',year:-334,name:'格拉尼库斯河之战',factions:['亚历山大马其顿联军','波斯小亚细亚诸总督联军'],focus:[33,21],camera:200,
  terrain:'格拉尼库斯河贯通南北，东岸为较陡的河岸，保留三段此前涉渡区。开局双方已在河东展开。地貌按相对关系重建，具体古河道、渡点位置并不确定。',
  forces:'阿里安1.11—14记远征军约3万步兵、5000骑兵，波斯约2万骑兵及近2万希腊雇佣步兵；后两项争议较大。部署马军40枚步兵（每枚约750人）及10骑兵（约500人），波军20骑兵、20重步兵（约千人），采用阿里安口径，非定论。',
  deployment:'采用狄奥多罗斯17.19所述渡河后展开的截面；与阿里安的强渡叙述不同，并非唯一复原。亚历山大在右翼、帕尔梅尼奥在左翼，波斯骑兵在前、希腊雇佣兵在后。兵数另采用阿里安口径。',
  sources:[['阿里安《亚历山大远征记》1.11—16',A],['狄奥多罗斯17.19：渡河后展开的另一叙述','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Diodorus_Siculus/17B%2A.html'],['剑桥：格拉尼库斯河战役研究','https://www.cambridge.org/core/journals/journal-of-hellenic-studies/article/abs/battle-of-the-granicus-river/1C19CEF8F59308BED47331BE7063BB2C']]},
 {id:'hydaspes',year:-326,name:'希达斯皮斯河之战',factions:['亚历山大渡河部队','波罗斯印度军'],focus:[36,22],camera:210,
  terrain:'西缘希达斯皮斯河（今杰赫勒姆河）上下贯通，东侧为决战平地。地图从亚历山大迂回渡河后开始；浅滩仅示意此前渡河区，不把洪水河段设成普遍可涉。',
  forces:'阿里安5.14—15记亚历山大先遣约6000步兵、5000骑兵：24步兵枚各约250人、10骑兵各约500人。波罗斯按阿里安约3万步兵、4000骑兵、300战车、200战象部署30、4、4、10枚，分别约1000人、1000骑、75车、20象。其他古作者的象与兵数不同。',
  deployment:'马其顿已在河东，骑兵集中在右翼，科伊诺斯骑兵另置侧翼；波罗斯象群在步兵前，战车和骑兵分置两翼。现有双马投射战车代演印度战车，未新增印度专属造型或泥泞惩罚。',
  sources:[['阿里安5.8—19',A],['希达斯皮斯河战役与渡点争议','https://www.livius.org/articles/battle/hydaspes/']]},
 {id:'ipsus',year:-301,name:'伊普苏斯之战',factions:['安提柯与德米特里联军','塞琉古与利西马科斯联军'],focus:[35,22],camera:205,
  terrain:'采用弗里吉亚开阔内陆战场；边缘低丘，中间留出方阵、骑兵与象群机动空间。确切战场位置及详细地形没有可靠定论，不虚构贯穿战线的大河。',
  forces:'普鲁塔克《德米特里传》28记安提柯逾7万步兵、1万骑兵、75象，对盟军6.4万步兵、1.05万骑兵、400象及120战车。压缩为35步兵、10骑兵、3象，对32步兵、10骑兵、16象、2镰刀车；约每步兵枚2000人、骑兵枚1000骑、象枚25头、战车枚60辆。',
  deployment:'两军方阵居中，德米特里主力骑兵在安提柯右翼，塞琉古象群除前列外保留后续梯队。阻断骑兵回援由玩家运用既有阻挡规则完成，不强迫历史追击。',
  sources:[['普鲁塔克《德米特里传》28—29','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Plutarch/Lives/Demetrius%2A.html']]},
 {id:'heraclea',year:-280,name:'赫拉克利亚之战',factions:['拉埃维努斯罗马军','皮洛士伊庇鲁斯军'],focus:[34,22],camera:200,
  terrain:'西部西里斯河贯通上下边界，东部为会战平原；西南向爱奥尼亚海方向。以罗马渡河展开后的截面开局，渡口与侧翼通道保留。',
  forces:'双方实到总数不确定，不采用罗马动辄数倍优势的断言。以罗马约2万步兵、2000骑，皮洛士约2万步兵、3000骑作工作估计：40步兵对40步兵，4骑对6骑（每枚约500人）；20战象缩为2枚。普鲁塔克所记皮洛士渡海兵数不等于全部实到决战人数。',
  deployment:'罗马军在河东展开三线，皮洛士方阵在对面，两翼骑兵，象群居后。轻装兵作泛用投射与掩护抽象，现有罗马、希腊模型复用。',
  sources:[['普鲁塔克《皮洛士传》15—17','https://classics.mit.edu/Plutarch/pyrrhus.html'],['古代史学者Bret Devereaux：兵力估计讨论','https://acoup.blog/2024/03/08/collections-phalanxs-twilight-legions-triumph-part-iiib-pyrrhus/']]},
 {id:'raphia',year:-217,name:'拉菲亚之战',factions:['托勒密四世埃及军','安条克三世塞琉古军'],focus:[35,22],camera:210,
  terrain:'拉菲亚附近开阔干燥平原；地图左缘为沿海沙地示意，海岸不紧贴中央战线。中央不添加虚构河流、桥梁或城墙障碍。',
  forces:'波利比乌斯5.65、79—85；托勒密步兵有5万或7万两种读法，本局取7万口径，另5000骑、73象；塞琉古6.2万步兵、6000骑、102象。步兵每枚约2000人、骑兵约1000骑、象约20头：35/5/4枚对31/6/5枚。帮助明确保留争议。',
  deployment:'托勒密原生埃及与马其顿式方阵居中，左翼象群较多；安条克在对面右翼集中骑兵与象群。共用现有战象模型代演两类象，不附加未经规则定义的非洲象畏惧机制。',
  sources:[['波利比乌斯第5卷','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Polybius/5%2A.html'],['牛津古典辞典：拉菲亚兵数歧义','https://academic.oup.com/edited-volume/61673/chapter-abstract/550566764']]},
 {id:'cynoscephalae',year:-197,name:'库诺斯克法莱之战',factions:['弗拉米尼努斯罗马联军','腓力五世马其顿军'],focus:[34,21],camera:205,
  terrain:'色萨利犬头山丘陵及多条起伏山脊，中间保留谷道与开放坡面。按相对高低表现遭遇战；浓雾只作背景说明，不新增能见度或战斗修正。',
  forces:'李维33.4列马其顿1.6万方阵、7500其他步兵、2000骑，罗马联军总数约相当。马军32方阵、15轻兵、4骑；罗马48步兵、5骑（每枚约500人），再以2枚象队表现史载战象，具体头数未确定。',
  deployment:'罗马左翼与已登高的马其顿右翼相对，马其顿左翼尚在展开。山地按既有列阵限制生效，罗马象队在右翼；不使用脚本强制方阵崩溃。',
  sources:[['李维33.4—10','https://thelatinlibrary.com/livy/liv.33.shtml'],['波利比乌斯18.19—27','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Polybius/18%2A.html']]},
 {id:'magnesia',year:-190,name:'马格尼西亚之战',factions:['卢基乌斯·西庇阿与欧迈尼斯联军','安条克三世塞琉古军'],focus:[35,22],camera:210,
  terrain:'弗里吉乌斯河沿战场北侧贯通地图，罗马左翼倚河，中央为利于军团、方阵与骑兵展开的平原。东侧为塞琉古营地，西侧罗马营地以木栅留门示意。',
  forces:'采用李维37.37—44与阿庇安30—33的传统数：罗马联军约3万人，塞琉古约7万—7.2万人，有夸张与重建争议。罗马27步兵、3骑、1预备象队（16象）；塞军60步兵含16方阵、12骑、3象、2镰刀车。普通枚约千人，塞军象每枚约18头；车队只示意存在，不断言精确车数。',
  deployment:'罗马左翼贴河，欧迈尼斯骑兵与轻装兵在右翼；塞军方阵居中、象群分布其间，镰刀车在前，安条克亲率右翼骑兵。罗马象在后方预备，不强迫历史溃败。',
  sources:[['李维第37卷','https://thelatinlibrary.com/livy/liv.37.shtml'],['阿庇安《叙利亚战争》31—33','https://www.livius.org/sources/content/appian/appian-the-syrian-wars/appian-the-syrian-wars-7/'],['剑桥：马格尼西亚战场研究','https://www.cambridge.org/core/books/seleucid-army/battle-of-magnesia-190-bc/68772C1D9DE667069C0CE8F21E2CFFC6']]},
]);
export const HELLENISTIC_IDS=new Set(HELLENISTIC_CAMPAIGNS.map(c=>c.id));
export const hellenisticInfo=id=>HELLENISTIC_CAMPAIGNS.find(c=>c.id===id);
const sides={
 granicus:[['phalangite','light','archer','companionCavalry'],['cavalry','greekHoplite']],
 hydaspes:[['phalangite','light','archer','companionCavalry'],['heavy','archer','cavalry','hittiteChariot','warElephant']],
 ipsus:[['phalangite','light','archer','companionCavalry','warElephant'],['phalangite','light','archer','companionCavalry','warElephant','scythedChariot']],
 heraclea:[['romanHastati','romanPrincipes','romanTriarii','romanVelites','romanAlliedHorse'],['phalangite','light','archer','companionCavalry','warElephant']],
 raphia:[['phalangite','greekHoplite','light','archer','companionCavalry','warElephant'],['phalangite','guard','light','archer','companionCavalry','warElephant']],
 cynoscephalae:[['romanHastati','romanPrincipes','romanTriarii','romanVelites','romanAlliedHorse','light','warElephant'],['phalangite','light','cavalry']],
 magnesia:[['romanHastati','romanPrincipes','romanTriarii','romanVelites','romanAlliedHorse','light','archer','warElephant'],['phalangite','guard','light','archer','companionCavalry','parthianCataphract','parthianHorseArcher','warElephant','scythedChariot']],
};
export function hellenisticKinds(id,team){return team?sides[id]?.[team==='egypt'?0:1]||[]:[...new Set(sides[id]?.flat()||[])];}
export function hellenisticApproach(m,u,team){
 const c=team==='egypt'?34:33;
 return HELLENISTIC_IDS.has(m.scenarioId)?{c,r:Math.max(6,Math.min(m.rows-6,u.r))}:null;
}
