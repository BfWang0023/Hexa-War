// Formation posture is visual state derived from the existing formed/facing rules.
import * as T from '../vendor/three/three.module.js';
import {materials as M,part,rod,joint,poseHumanArm} from './models-v02.mjs';
const rigCache=new WeakMap();
export function prepareFormationModel(root,profile,low){
 if(!profile.formed)return;
 root.traverse(o=>{
  if(o.name!=='soldier')return;
  const grip=o.getObjectByName('weapon')?.getObjectByName('hand-grip');
  // Roman sword-bearing ranks retain their original equipment in marching mode.
  if(grip && profile.weapon!=='spear'){
   const spear=joint(grip,'formation-spear',[0,0,0]);
   rod(spear,M.wood,[0,-.95,0],[0,2.15,0],.03);
   part(spear,new T.ConeGeometry(.09,.3,low?4:6),M.bronze,[0,2.3,0]);
  }
 });
 applyFormationPose(root,profile);
 rigCache.delete(root); // Templates are cloned; do not retain the pre-flatten far hierarchy.
}
export function applyFormationPose(root,profile=root.userData.profile,{action='none',progress=0}={}){
 if(!profile?.formed)return;
 // The far rig is flattened after this stance is authored, retaining the same silhouette.
 let rigs=rigCache.get(root);
 if(!rigs){
  rigs=[];const near=root.getObjectByName('near')||root;
  near.traverse(o=>{if(o.name!=='soldier')return;const weapon=o.getObjectByName('weapon'),shield=o.getObjectByName('shield');if(!weapon||!shield)return;const grip=weapon.getObjectByName('hand-grip');rigs.push({o,weapon,shield,grip,tool:grip.getObjectByName('formation-spear')||grip.getObjectByName('melee-tool'),sword:grip.getObjectByName('melee-tool'),breath:o.getObjectByName('breath')});});
  rigCache.set(root,rigs);
 }
 for(const {o,weapon,shield,tool,sword,breath} of rigs){
  o.rotation.y=Math.PI/2;
  if(breath)breath.rotation.x=0;
  weapon.rotation.set(0,0,0);
  const thrust=action!=='none'?Math.max(0,Math.sin(Math.max(0,Math.min(1,progress))*Math.PI))*.08:0;
  poseHumanArm(weapon,new T.Vector3(.13,-.13,.49+thrust));
  if(tool){tool.visible=true;tool.rotation.set(Math.PI/2,0,0);}
  if(profile.weapon!=='spear'&&sword)sword.visible=false;
  shield.position.y=2.79;shield.rotation.set(-.26,0,0);
  poseHumanArm(shield,new T.Vector3(-.13,-.10,.51));
 }
}
