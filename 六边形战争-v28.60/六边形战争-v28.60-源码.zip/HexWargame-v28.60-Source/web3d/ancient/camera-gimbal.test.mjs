import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {createSoldierCamera,SOLDIER_CAMERA} from './soldier-camera.mjs';
import {createUnitModel,UNIT_SCENE_SCALE} from './unit-presentation.mjs';
import {animateFullModel} from './full-models.mjs';
const delta=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
function fixture(kind='heavy'){
 const u={id:'u1',kind,team:'egypt',hp:100,c:3,r:3,morale:1},model=createUnitModel(u,'china_changping'),camera=new T.PerspectiveCamera(45,1,.8,2200),lost=[],view=createSoldierCamera(camera,r=>lost.push(r));
 model.scale.setScalar(UNIT_SCENE_SCALE);model.position.set(35,4,25);model.rotation.y=0;view.start(u,model);view.update(u,model,true,0);
 return {u,model,camera,view,lost,yaw(){const d=camera.getWorldDirection(new T.Vector3());return -Math.atan2(d.z,d.x);},tick(t){view.update(u,model,true,t);return this.yaw();}};
}
test('gimbal is enabled by default and caps automatic rotation after an abrupt half turn',()=>{
 const f=fixture();assert.equal(f.view.stabilized,true);f.model.rotation.y=Math.PI;let previous=f.yaw();for(let t=16;t<=3200;t+=16){const next=f.tick(t);assert.ok(Math.abs(delta(previous,next))<=SOLDIER_CAMERA.turnRate*.016+1e-8);previous=next;if(t===160)assert.ok(Math.abs(next)<.25);}
 assert.ok(Math.abs(delta(previous,Math.PI))<.01);
});
test('rotation around ±pi follows the short arc instead of making a full circle',()=>{
 const f=fixture();f.view.stop();f.model.rotation.y=T.MathUtils.degToRad(179);f.view.start(f.u,f.model);f.tick(0);f.model.rotation.y=T.MathUtils.degToRad(-179);let previous=f.yaw(),total=0;for(let t=10;t<=1000;t+=10){const next=f.tick(t);total+=Math.abs(delta(previous,next));previous=next;}assert.ok(total<T.MathUtils.degToRad(2.1));assert.ok(Math.abs(delta(previous,f.model.rotation.y))<.001);
});
test('manual mouse look remains immediate while automatic follow is eased',()=>{
 const f=fixture(),before=f.yaw();f.model.rotation.y=Math.PI;f.view.rotate(100,0);f.tick(0);assert.ok(Math.abs(delta(before,f.yaw())+.6)<1e-8);f.view.setPitch(45);f.tick(0);assert.ok(Math.abs(f.camera.getWorldDirection(new T.Vector3()).y+Math.SQRT1_2)<1e-8);
});
test('camera position follows the whole piece but rejects animated body bob and orbit',()=>{
 const f=fixture(),before=f.camera.position.clone();for(let i=0;i<20;i++){f.model.rotation.y=i*.1;animateFullModel(f.model,i*43,{moving:true,complex:true,distance:10});f.tick(i*16);assert.ok(f.camera.position.distanceTo(before)<1e-7);}
 f.model.position.add(new T.Vector3(5,2,-7));f.tick(400);assert.ok(f.camera.position.distanceTo(before.add(new T.Vector3(5,2,-7)))<1e-7);
});
test('30/60/144 FPS produce close results with the same elapsed time',()=>{
 const results=[];for(const fps of [30,60,144]){const f=fixture();f.model.rotation.y=Math.PI;for(let i=1;i<=fps;i++)f.tick(i*1000/fps);results.push(f.yaw());}assert.ok(Math.max(...results)-Math.min(...results)<.01);
});
test('background-tab resume and invalid timestamps cannot jump the camera around',()=>{
 const f=fixture();f.model.rotation.y=Math.PI;const before=f.yaw();f.tick(100000);assert.ok(Math.abs(delta(before,f.yaw()))<=SOLDIER_CAMERA.turnRate*.05+1e-8);f.tick(-1);f.view.update(f.u,f.model,true,NaN);assert.ok(f.camera.position.toArray().every(Number.isFinite));assert.ok(f.camera.quaternion.toArray().every(Number.isFinite));
});
test('rapid alternating directions are filtered instead of whipping back and forth',()=>{
 const f=fixture(),angles=[];for(let i=1;i<=120;i++){f.model.rotation.y=i%2?Math.PI/2:-Math.PI/2;angles.push(f.tick(i*1000/60));}assert.ok(Math.max(...angles)-Math.min(...angles)<.06);
});
test('disabling restores direct follow; reenabling starts without a first-frame angular jump',()=>{
 const f=fixture();f.view.setStabilized(false);f.model.rotation.y=Math.PI/2;f.tick(16);assert.ok(Math.abs(delta(f.yaw(),Math.PI/2))<1e-8);const before=f.yaw();f.view.setStabilized(true);f.model.rotation.y=-Math.PI/2;f.tick(32);assert.ok(Math.abs(delta(before,f.yaw()))<1e-8);f.tick(48);assert.ok(Math.abs(delta(before,f.yaw()))<.03);
});
test('switching target and model rebuild do not carry old target rotation across units',()=>{
 const f=fixture();f.model.rotation.y=Math.PI;f.tick(200);const replacement=createUnitModel(f.u,'china_changping');replacement.position.copy(f.model.position);replacement.scale.copy(f.model.scale);replacement.rotation.y=f.model.rotation.y;const before=f.yaw();f.view.update(f.u,replacement,true,216);assert.ok(Math.abs(delta(before,f.yaw()))<.03);
 const other={...f.u,id:'u2'};replacement.rotation.y=-Math.PI/2;f.view.start(other,replacement);assert.ok(Math.abs(delta(f.yaw(),-Math.PI/2))<1e-8);f.view.stop();assert.equal(f.camera.fov,45);assert.equal(f.camera.near,.8);
});
test('death still requires explicit replacement and never adds camera state to the unit',()=>{
 const f=fixture(),before=JSON.stringify(f.u);f.model.rotation.y=2;f.tick(16);assert.equal(JSON.stringify(f.u),before);f.view.update({...f.u,hp:0},f.model,true,32);assert.equal(f.view.active,false);assert.equal(f.lost.length,1);assert.match(f.lost[0],/阵亡/);f.view.update(f.u,f.model,true,48);assert.equal(f.lost.length,1);
});
test('gimbal anchors work for riders, vehicles, ships, legacy and low-detail models',()=>{
 for(const kind of ['cavalry','chinaHeavyChariot','supplyWagon','warship','chinaFireOx','siegeRam']){const f=fixture(kind);for(const distance of [150,15]){animateFullModel(f.model,200,{distance,moving:true});f.tick(16+distance);assert.ok(f.camera.position.toArray().every(Number.isFinite));}}
});
