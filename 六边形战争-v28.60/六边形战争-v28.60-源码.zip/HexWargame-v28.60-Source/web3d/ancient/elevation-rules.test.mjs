import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {elevationEffect,ruleConfig,logicalElevation} from './elevation-rules.mjs';
import {createSave,restoreSave} from './save.mjs';
import {createVisualField} from './continuous-landform.mjs';
import {terrainHeight} from './terrain.mjs';
import {createTacticalCommandAPI} from './tactical-command.mjs';
function fixture(kind='light', heights=[0,0], options={}) {
 const m=E.newMap(16,10);m.scenarioId='custom_elevation_rules';
 E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,'light','coalition',14,8);E.addUnit(m,kind,'egypt',5,4);E.addUnit(m,'light','coalition',kind==='archer'?8:6,4);
 const s=E.startGame(m,{rulesVersion:12,...options}),a=E.mobileAt(s.map,5,4),d=E.mobileAt(s.map,kind==='archer'?8:6,4);
 if(s.map.elevations){s.map.elevations[E.index(s.map,a.c,a.r)]=heights[0];s.map.elevations[E.index(s.map,d.c,d.r)]=heights[1];}
 E.recomputeFog(s);return {s,a,d,m};
}
test('mountain infantry spends one AP per step and retains two actions; roads restore normal movement',()=>{
 for(const terrain of [0,2,3]){const {s,a}=fixture('heavy');s.map.units=s.map.units.filter(u=>u.team==='egypt'||u.c===14);E.setTerrain(s.map,6,4,terrain);E.recomputeFog(s);
  const route=E.reachable(s,a).get('6,4');assert.equal(E.moveCost(s,a,6,4),1);assert.equal(route.actionCost,1);
  assert.equal(E.move(s,a.id,6,4).ok,true);assert.equal(a.actionsLeft,1);
 }
 const {s,a}=fixture('heavy');s.map.units=s.map.units.filter(u=>u.team==='egypt'||u.c===14);E.setTerrain(s.map,6,4,2);E.recomputeFog(s);a.actionsLeft=0;
 assert.equal(E.reachable(s,a).has('6,4'),false);assert.equal(E.move(s,a.id,6,4).ok,false);assert.equal(a.actionsLeft,0);
});
test('equal AP grants two one-cell mountain actions versus two two-cell plain actions',()=>{
 for(const mountain of [false,true]){const {s,a}=fixture();s.map.units=s.map.units.filter(u=>u.team==='egypt'||u.c===14);for(let c=5;c<=9;c++)E.setTerrain(s.map,c,4,mountain?2:0);E.recomputeFog(s);
  const step=mountain?1:2;
  for(let n=1;n<=2;n++){for(let c=0;c<16;c++)for(let r=0;r<10;r++)s.fog.egypt.visible.add(E.key(c,r));assert.equal(E.move(s,a.id,5+n*step,4).ok,true);assert.equal(a.actionsLeft,2-n);}
  assert.equal(E.move(s,a.id,a.c+1,4).ok,false);
 }
});
for(const kind of ['light','archer','chinaCrossbow','heavy'])test(`${kind}: relative height multiplier is applied exactly once`,()=>{
 let base;for(const [from,to,mult]of [[0,0,1],[1,0,1.15],[0,1,.85],[3,3,1],[100,0,1.45],[0,100,.55]]){
  const {s,a,d}=fixture(kind,[from,to]);const p=E.attackPreview(s,a,d.c,d.r);assert.ok(p);if(base===undefined)base=p.damage;
  assert.equal(p.elevation.multiplier,mult);assert.equal(p.damage,Math.round(base*mult));
  const ap=a.actionsLeft;const result=E.attack(s,a.id,d.c,d.r,0,0,0);assert.ok(result.ok);assert.equal(a.actionsLeft,ap-1);assert.ok(s.log.some(x=>x.includes('伤害 ×')));
 }
});
test('reverse direct attack recomputes height and both sides obey the same rule',()=>{
 const {s,a,d}=fixture('light',[1,0]);assert.equal(E.attackPreview(s,a,d.c,d.r).elevation.multiplier,1.15);
 s.side='coalition';E.recomputeFog(s);assert.equal(E.attackPreview(s,d,a.c,a.r).elevation.multiplier,.85);
});
test('wall platform replaces the old independent +1 bonus; Eyu gets no second downhill bonus',()=>{
 const {s,a,d}=fixture('light',[0,0]),base=E.attackPreview(s,a,d.c,d.r).damage;
 E.setFort(s.map,a.c,a.r,2,'egypt');assert.equal(logicalElevation(s.map,a.c,a.r),2);
 assert.equal(E.attackPreview(s,a,d.c,d.r).damage,Math.round(base*1.3));
 const x=fixture('light',[1,0]);x.s.map.scenarioId='china_eyu';const raised=E.attackPreview(x.s,x.a,x.d.c,x.d.r).damage;x.s.map.elevations[E.index(x.s.map,x.a.c,x.a.r)]=0;const normal=E.attackPreview(x.s,x.a,x.d.c,x.d.r).damage;assert.equal(raised,Math.round(normal*1.15));
});
test('configuration is bounded and archived with logical elevation; future saves reject',()=>{
 assert.throws(()=>ruleConfig({floor:0}));assert.throws(()=>ruleConfig({gain:NaN}));
 const {s,m,a,d}=fixture('light',[2,0],{elevationRules:{gain:.1,ceiling:1.2}}),saved=createSave(m,s,'egypt');
 const restored=restoreSave(JSON.parse(JSON.stringify(saved)));const state=restored.game;
 assert.equal(state.rulesVersion,12);assert.equal(elevationEffect(state,a,d).multiplier,1.2);
 assert.deepEqual(state.map.elevations,s.map.elevations);
 assert.throws(()=>restoreSave({...saved,rulesVersion:13}));
 const broken=structuredClone(saved);delete broken.game.map.elevations;assert.throws(()=>restoreSave(broken));
});
test('legacy saves retain v10 and old mountain movement after restore and resave',()=>{
 const {s,m}=fixture('heavy',[0,0],{rulesVersion:10});const saved=createSave(m,s,'egypt');delete saved.game.rulesVersion;delete saved.game.elevationRules;
 const state=restoreSave(saved).game;assert.equal(state.rulesVersion,10);assert.equal(createSave(m,state,'egypt').rulesVersion,10);
 state.map.units=state.map.units.filter(u=>u.team==='egypt');const a=state.map.units.find(u=>u.kind==='heavy');E.setTerrain(state.map,6,4,2);E.recomputeFog(state);
 assert.equal(E.move(state,a.id,6,4).ok,true);assert.equal(a.actionsLeft,1);
});
test('logical map export/import and visual sampling do not alter combat',()=>{
 const {s,a,d}=fixture('light',[2,0]);const before=JSON.stringify(s),damage=E.attackPreview(s,a,d.c,d.r).damage;
 const map=E.importMap(E.exportMap(s.map));assert.deepEqual(map.elevations,s.map.elevations);
 for(let q=0;q<3;q++){const field=createVisualField(s.map,terrainHeight);for(let i=0;i<50;i++)field.height(i*2,i*3);field.clear();}
 assert.equal(JSON.stringify(s),before);assert.equal(E.attackPreview(s,a,d.c,d.r).damage,damage);
 E.setTerrain(s.map,a.c,a.r,2);assert.equal(s.map.elevations[E.index(s.map,a.c,a.r)],1);
 E.setTerrain(s.map,a.c,a.r,3);assert.equal(s.map.elevations[E.index(s.map,a.c,a.r)],1);
});
test('persistent command executes an unfavorable legal attack without changing intent',async()=>{
 const {s,a,d}=fixture('light',[0,1]);const api=createTacticalCommandAPI({getState:()=>s,pace:false});
 const r=api.submit({v:1,confidence:1,clarification:'',orders:[{select:{scope:'all',ids:[a.id]},steps:[{type:'attack',target:{scope:'all',ids:[d.id]}}]}]},{team:'egypt'});await r.promise;
 assert.equal(r.rulesVersion,12);assert.ok(a.actionsLeft<2);assert.equal(r.results[0].attacks>0,true);
});

test('mountain flags cannot stack old archer or Eyu bonuses on the new multiplier',()=>{
 for(const kind of ['archer','light']){const {s,a,d}=fixture(kind);if(kind==='light')s.map.scenarioId='china_eyu';
  const base=E.attackPreview(s,a,d.c,d.r).damage;E.setTerrain(s.map,a.c,a.r,2);E.recomputeFog(s);
  assert.equal(E.attackPreview(s,a,d.c,d.r).damage,Math.round(base*1.15));
  s.map.elevations[E.index(s.map,a.c,a.r)]=0;
  assert.equal(E.attackPreview(s,a,d.c,d.r).damage,base);
 }
});
test('stale command guard includes height and rule config; a matching snapshot executes',async()=>{
 const {commandSnapshot}=await import('./command-snapshot.mjs');
 const {s,a}=fixture('heavy');s.map.units=s.map.units.filter(u=>u.c!==6);E.recomputeFog(s);
 const command={v:1,confidence:1,clarification:'',orders:[{select:{scope:'all',ids:[a.id]},steps:[{type:'move',direction:'E',distance:1}]}]},api=createTacticalCommandAPI({getState:()=>s,pace:false});
 let snapshot=commandSnapshot(s);s.map.elevations[0]=1;assert.throws(()=>api.submit(command,{team:'egypt',snapshot}),/快照/);
 snapshot=commandSnapshot(s);s.elevationRules.gain=.1;assert.throws(()=>api.submit(command,{team:'egypt',snapshot}),/快照/);
 const record=api.submit(command,{team:'egypt',snapshot:commandSnapshot(s)});await record.promise;assert.equal(record.completed,1);assert.equal(a.c,6);
});
test('malformed logical elevations reject on map import',()=>{
 const {m}=fixture(),map=E.exportMap(m);for(const elevations of [[0],Array(m.cols*m.rows).fill(NaN),Array(m.cols*m.rows).fill(101)])assert.throws(()=>E.importMap({...map,elevations}));
});
test('cosmetic field follows custom logical elevations without writing them back',()=>{
 const {s}=fixture(),old=createVisualField(s.map,terrainHeight).height(70,60);s.map.elevations.fill(2);const before=JSON.stringify(s.map.elevations),raised=createVisualField(s.map,terrainHeight).height(70,60);assert.ok(raised>old+5.9);assert.equal(JSON.stringify(s.map.elevations),before);
});

test('mountain roads restore plain speed and never grant the road bonus, even when entering from a plain road',()=>{
 for(const kind of ['light','supplyWagon','cavalry','warElephant','chinaHeavyChariot','siegeRam','romanOnager','siegeTower']){
  const m=E.newMap(20,12);m.scenarioId='custom_mountain_road';E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,'light','coalition',18,10);assert.ok(E.addUnit(m,kind,'egypt',5,5),kind);
  const s=E.startGame(m),u=E.mobileAt(s.map,5,5);for(let c=5;c<13;c++)E.setTerrain(s.map,c,5,3);E.recomputeFog(s);for(let c=0;c<20;c++)for(let r=0;r<12;r++)s.fog.egypt.visible.add(E.key(c,r));
  const budget=E.movementAllowance(s,u).baseSteps;assert.equal(E.movementAllowance(s,u).roadBonus,0,kind);
  assert.equal(E.reachable(s,u).get(E.key(5+budget,5))?.actionCost,1,kind);assert.equal(E.reachable(s,u).has(E.key(6+budget,5)),false,kind);
  E.setTerrain(s.map,5,5,1);assert.equal(E.reachable(s,u).has(E.key(6+budget,5)),false,kind+' cannot carry plain-road bonus into mountains');
  assert.equal(E.move(s,u.id,6,5).ok,true,kind);assert.equal(u.actionsLeft,1,kind);
 }
});
test('cavalry, elephants, chariots, engines and formed infantry cannot enter roadless mountains',()=>{
 for(const kind of ['cavalry','warElephant','chariot','chinaHeavyChariot','siegeRam','romanOnager','siegeTower','companionCavalry','phalangite','greekHoplite','romanLegion']){
  const m=E.newMap(20,12);m.scenarioId='custom_rough_forbidden';E.addUnit(m,'pharaoh','egypt',0,0);E.addUnit(m,'light','coalition',18,10);E.addUnit(m,kind,'egypt',5,5);E.setTerrain(m,6,5,2);const s=E.startGame(m),u=E.mobileAt(s.map,5,5);if(E.isFormableInfantry(u))u.formed=true;
  assert.equal(E.moveCost(s,u,6,5),Infinity,kind);assert.equal(E.move(s,u.id,6,5).ok,false,kind);assert.equal(u.actionsLeft,2);
  E.setTerrain(s.map,6,5,3);E.recomputeFog(s);assert.equal(E.move(s,u.id,6,5).ok,true,kind+' mountain road');assert.equal(u.actionsLeft,1);
 }
});
test('wagon mountain travel, including roads, consumes food at exactly twice the existing travel rate',()=>{
 for(const terrain of [0,2,3]){const {s,a}=fixture('supplyWagon');s.map.units=s.map.units.filter(u=>u.c!==6);s.map.logistics={depots:{egypt:[],coalition:[]}};a.supplyStock=24;a.supplyTravel=4;
  E.setTerrain(s.map,6,4,terrain);E.recomputeFog(s);assert.equal(E.move(s,a.id,6,4).ok,true);assert.equal(a.actionsLeft,1);
  assert.equal(a.supplyTravel,terrain===0?5:0);assert.equal(a.supplyStock,terrain===0?24:23);
 }
});
test('v11 interim saves preserve their old two-AP mountain step instead of silently adopting v12',()=>{
 const {s,m,a}=fixture('heavy',[0,0],{rulesVersion:11});s.map.units=s.map.units.filter(u=>u.c!==6);E.setTerrain(s.map,6,4,2);E.recomputeFog(s);
 const restored=restoreSave(createSave(m,s,'egypt')).game;assert.equal(restored.rulesVersion,11);assert.equal(E.move(restored,a.id,6,4).ok,true);assert.equal(restored.map.units.find(u=>u.id===a.id).actionsLeft,0);
});
test('shrubs are exactly three times their previous linear scale, with unchanged instance count and map',async()=>{
 const {vegetationPoints,createVegetation}=await import('./terrain-vegetation.mjs'),m=E.newMap(30,24),before=JSON.stringify(m),points=vegetationPoints(m);
 assert.ok(points.grass.length>0);for(const p of points.grass){const n=Math.sin(p.c*127.1+p.r*311.7+107*74.7)*43758.5453,old=.9+(n-Math.floor(n))*.2;assert.equal(p.scale,3*old);}
 const layer=createVegetation(m,()=>0);assert.equal(layer.group.children.find(x=>x.name==='vegetation-grass').count,points.grass.length);assert.ok(layer.group.children.length<=2);assert.equal(JSON.stringify(m),before);
});
