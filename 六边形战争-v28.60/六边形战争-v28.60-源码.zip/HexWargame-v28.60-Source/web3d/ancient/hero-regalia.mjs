import * as T from '../vendor/three/three.module.js';
import {loft,panel,cloth,sweep} from './historical-geometry.mjs';
// Original decorative equipment attached to the established joints. No motion,
// capability or damage data lives here. Egyptian pharaoh regalia is excluded.
export function addHeroRegalia(person,body,p,team,kit,{rider=false}={}){
 if(!p.heroicRegalia||!p.commander||p.royalStyle==='egypt')return;
 const {M,box,oval,rod,part,joint,low}=kit,china=p.culture==='china',eastern=['hittite','assyria','persia'].includes(p.royalStyle);
 const plate=china?M.lamellar:eastern?M.bronze:M.bronze,accent=team==='egypt'?M.royalBlue:M.cinnabar;
 const regalia=joint(body,'hero-regalia',[0,0,0]);regalia.userData.style=china?'chinese-lamellar':eastern?'royal-scale':'heroic-bronze';
 // Remove only the replaced headpiece; face and original body rig are untouched.
 for(const name of ['officer-cap','commander-crest','eastern-royal-crown']){const old=body.getObjectByName(name);if(old){old.traverse(o=>o.geometry?.dispose());old.removeFromParent();}}
 const cuirass=joint(regalia,'hero-cuirass',[0,0,0]);
 loft(cuirass,plate,[[0,1.84,0,.33,.27],[0,2.02,0,.37,.30],[0,2.27,0,.40,.29],[0,2.46,0,.37,.25],[0,2.56,0,.19,.17]],{axis:'y',sides:low?10:18});
 if(china||eastern){
  for(const side of [-1,1])for(let row=0;row<(low?3:6);row++)for(let col=0;col<(low?4:7);col++){
   const n=low?4:7,x=(col-(n-1)/2)*(.67/n),y=1.96+row*(low?.16:.085),z=side*(.316-.09*Math.pow(x/.36,2));
   const a=box(cuirass,row%2?plate:M.gold,[x,y,z],[.67/n-.008,low?.13:.073,.026]);
   if(!low){oval(cuirass,M.gold,[x,y+.019,z+side*.019],[.010,.010,.009]);}
  }
 }else {
  // Sculpted bronze breastplate and raised abdominal ridges.
  for(const side of [-1,1])oval(cuirass,plate,[side*.18,2.29,.26],[.18,.17,.075]);
  for(const y of [2.02,2.10,2.18])for(const side of [-1,1])oval(cuirass,plate,[side*.095,y,.30],[.09,.045,.025]);
 }
 for(const side of [-1,1])sweep(cuirass,M.gold,[[side*.10,2.55,.17],[side*.30,2.47,.23],[side*.39,2.25,.11],[side*.33,1.87,.15]],[.018,.018],{steps:low?7:16,sides:5});
 sweep(cuirass,M.gold,[[-.31,1.89,.19],[0,1.87,.30],[.31,1.89,.19]],[.025,.025],{steps:10,sides:5});
 const badge=joint(cuirass,'royal-breast-emblem',[0,2.40,.295]);
 const diamond=panel(badge,M.gold,[[0,.13],[.10,0],[0,-.13],[-.10,0]],.025);oval(badge,accent,[0,0,.038],[.041,.052,.018]);
 if(!low)for(const side of [-1,1])for(let i=0;i<3;i++)rod(badge,M.gold,[side*.09,0,.015],[side*(.17+i*.035),.04-i*.035,.015],.01);
 box(regalia,M.leather,[0,1.85,0],[.70,.12,.58]);box(regalia,M.gold,[0,1.85,.31],[.20,.11,.035]);
 // Overlapping tassets, with gilded tips; a split skirt leaves leg motion free.
 for(const side of [-1,1])for(let i=0;i<4;i++){
  const x=side*(.055+i*.095),z=.27-.04*i;const t=panel(regalia,china?M.lamellar:M.leather,[[-.04,1.81],[.04,1.81],[.06,1.29],[-.045,1.31]],.035);t.position.set(x,0,z);
  box(regalia,M.gold,[x,1.34,z+.045],[.075,.045,.018]);
 }
 // Armor is parented below each articulated arm, so it follows the same IK.
 for(const side of [-1,1]){
  const arm=body.getObjectByName(side===1?'weapon':'shield'),upper=arm?.getObjectByName('upper-arm'),lower=arm?.getObjectByName('lower-arm');if(!upper)continue;
  const shoulder=joint(upper,'hero-pauldron',[0,0,0]);
  for(let i=0;i<3;i++){
   const shell=oval(shoulder,plate,[side*.035,-.12-i*.20,0],[.20-i*.018,.22,.18-i*.015]);
   sweep(shoulder,M.gold,[[-.17+i*.018,-.18-i*.20,.07],[0,-.22-i*.20,.185-i*.015],[.17-i*.018,-.18-i*.20,.07]],[.012,.012],{steps:8,sides:4});
  }
  const bracer=joint(lower,'hero-vambrace',[0,0,0]);rod(bracer,plate,[0,-.18,0],[0,-.84,0],.10,.12);
  for(const y of [-.19,-.78])rod(bracer,M.gold,[0,y+.028,0],[0,y-.028,0],.116,.116);
  rod(bracer,M.gold,[0,-.25,.11],[0,-.72,.10],.012);
  const leg=person.getObjectByName('leg'+side),greave=joint(leg,'hero-greave',[0,0,0]);
  const a=rider?[side*.22,-.39,.28]:[side*.025,-.56,.04],b=rider?[side*.25,-.87,.15]:[side*.04,-.99,0];
  rod(greave,plate,a,b,.09,.11);rod(greave,M.gold,[a[0],a[1],a[2]+.108],[b[0],b[1],b[2]+.09],.014);
  oval(greave,M.gold,a,[.105,.09,.10]);
 }
 // Headpiece silhouettes differ by culture, with an open face at eye level.
 const helm=joint(regalia,'hero-helmet',[0,3.03,0]);
 if(eastern){
  loft(helm,accent,[[0,-.03,0,.26,.24],[0,.17,-.015,.28,.25],[0,.40,-.02,.23,.21],[0,.51,-.02,.15,.15]],{axis:'y',sides:low?10:16});
  for(const y of [.01,.22,.39])part(helm,new T.TorusGeometry(y===.39?.23:.27,.018,4,16),M.gold,[0,y,-.01]).rotation.x=Math.PI/2;
  for(const side of [-1,1]){const guard=panel(helm,plate,[[-.07,.06],[.07,.06],[.06,-.25],[-.06,-.30]],.03);guard.position.set(side*.245,-.03,.03);guard.rotation.y=side*.8;}
 }else{
  part(helm,new T.SphereGeometry(.275,low?10:18,8,0,Math.PI*2,0,Math.PI*.57),plate,[0,.025,0]);
  sweep(helm,M.gold,[[-.265,-.02,0],[-.20,-.015,.19],[0,.025,.275],[.20,-.015,.19],[.265,-.02,0]],[.023,.023],{steps:16,sides:5});
  for(const side of [-1,1]){const guard=panel(helm,plate,[[0,.04],[.12,-.01],[.10,-.28],[.025,-.32],[-.045,-.18]],.035);guard.position.set(side*.175,-.02,.15);guard.rotation.y=side*.5;}
  if(china){
   const neck=panel(helm,plate,[[-.24,0],[.24,0],[.29,-.28],[-.29,-.28]],.04);neck.position.z=-.23;
   loft(helm,M.gold,[[0,.23,0,.09,.09],[0,.35,0,.055,.055],[0,.41,0,.018,.018]],{axis:'y',sides:8});
   sweep(helm,M.cinnabar,[[0,.39,0],[0,.50,-.14],[0,.40,-.36],[0,.20,-.47]],[.07,.10,.045],{steps:14,sides:8});
  }else{
   const crest=joint(helm,'hero-crest',[0,.08,0]);
   // A broad horsehair crest with a shaped top edge, rather than a thin rod.
   const plume=panel(crest,team==='egypt'?M.cinnabar:M.mane,[[-.30,.08],[-.32,.33],[-.12,.52],[.18,.51],[.37,.33],[.30,.12],[.14,.23],[-.12,.24]],.11);plume.rotation.y=Math.PI/2;plume.position.x=-.055;
   sweep(crest,M.gold,[[0,.12,-.29],[0,.26,-.12],[0,.25,.15],[0,.13,.30]],[.03,.03],{steps:14,sides:5});
  }
 }
 const crestJewel=panel(helm,M.gold,[[0,.17],[.075,.08],[0,-.025],[-.075,.08]],.025);crestJewel.position.z=.27;
 // Broad lined mantle. It breathes with the torso, with no cloth simulation.
 const cape=joint(regalia,'hero-mantle',[0,0,0]);
 const rows=[[[-.31,2.53,-.24],[0,2.55,-.31],[.31,2.53,-.24]],[[-.46,2.16,-.37],[0,2.09,-.48],[.46,2.16,-.37]],[[-.58,1.68,-.47],[0,1.60,-.59],[.58,1.68,-.47]],[[-.60,1.12,-.53],[0,1.02,-.64],[.60,1.12,-.53]]];
 cloth(cape,team==='egypt'?M.cinnabar:M.royalBlue,rows);
 for(const side of [-1,1])sweep(cape,M.gold,[[side*.31,2.53,-.24],[side*.46,2.16,-.37],[side*.58,1.68,-.47],[side*.60,1.12,-.53]],[.018,.018],{steps:12,sides:4});
 sweep(cape,M.gold,[[-.60,1.12,-.53],[0,1.02,-.64],[.60,1.12,-.53]],[.02,.02],{steps:12,sides:4});
 for(const side of [-1,1])oval(regalia,M.gold,[side*.28,2.49,.15],[.055,.055,.025]);
 // Jewel/bands are children of the real weapon grip; attacks keep their anchors.
 const tool=body.getObjectByName('melee-tool');if(tool){const detail=joint(tool,'hero-weapon-inlay',[0,0,0]);
  if(p.weapon==='sword'){box(detail,M.gold,[0,.05,0],[.33,.085,.105]);oval(detail,accent,[0,.05,.064],[.048,.035,.015]);rod(detail,M.gold,[0,.16,.027],[0,.79,.027],.009);}
  else if(p.weapon==='spear'){for(const y of [.96,1.06,1.16])rod(detail,M.gold,[0,y-.02,0],[0,y+.02,0],.042);}
 }
}
