// A bounded tactical preference, not an alternative movement/attack executor.
import {unitStats,unitMaxHp,isRouted,distance,reachable,attackPreview,fortAt,mobileAt} from './engine.mjs';
import {planningState} from './fog-policy.mjs';
export function lightMobileAction(state,unit,{attacked=false,moved=false,policyScore=null}={}){
 if(state.rulesVersion<21||!unit||unit.onFoot||unit.aboard||isRouted(unit)||unit.actionsLeft<=0)return null;
 const role=unitStats(state.map,unit).mountedRole;if(!['skirmisher','maneuver'].includes(role))return null;
 const s=planningState(state,unit.team),u=s.map.units.find(x=>x.id===unit.id);if(!u)return null;
 const stat=unitStats(s.map,u),foes=s.map.units.filter(e=>e.team!==u.team&&e.hp>0&&!e.aboard&&e.kind!=='fort'&&e.kind!=='captive'&&!isRouted(e));
 if(!foes.length)return null; // Existing campaign objectives handle unopposed marching.
 const near=p=>Math.min(...foes.map(e=>distance(p,e))),gap=near(u),ranged=stat.ranged>0&&stat.range>1&&u.ammo>0;
 const legal=[...reachable(s,u).values()].filter(p=>!mobileAt(s.map,p.c,p.r)&&!fortAt(s.map,p.c,p.r));
 const policy=a=>{const n=policyScore?.(s,u,a);return Number.isFinite(n)?Math.max(-10,Math.min(10,n)):0;};
 const shot=(actor,target,position=null)=>{const t=position?{...s,observationSimulation:true,map:{...s.map,units:s.map.units.map(x=>x.id===actor.id?{...actor,c:position.c,r:position.r,actionsLeft:actor.actionsLeft-1}:x)}}:s;return attackPreview(t,t.map.units.find(x=>x.id===actor.id),target.c,target.r);};
 const options=foes.map(target=>({target,preview:shot(u,target)})).filter(x=>x.preview);
 const weak=target=>{const t=unitStats(s.map,target);return !target.formed&&(t.ranged>0&&t.armor<=1||target.hp<=Math.max(10,stat.melee*10));};
 const retreat=()=>{
  const score=p=>Math.min(6,near(p))*20-foes.filter(e=>distance(p,e)<=2).length*12-distance(u,p)*.2+policy({type:'move',to:p});
  let choices=legal.filter(p=>near(p)>gap&&near(p)>=2);
  // With a shot still available, favor a safe firing distance over needless flight.
  if(ranged&&!attacked&&u.actionsLeft>=2&&u.hp>=unitMaxHp(s.map,u)*.4){const firing=choices.filter(p=>foes.some(e=>distance(p,e)<=stat.range&&shot(u,e,p)?.melee===false));if(firing.length)choices=firing;}
  const to=choices.sort((a,b)=>score(b)-score(a)||a.cost-b.cost||a.r-b.r||a.c-b.c)[0];
  return to?{type:'move',to,intent:'withdraw'}:null;
 };
 // After firing, or when caught next to a stronger enemy, spend the remaining
 // normal move on disengagement. There is never a free third action.
 if(attacked||(gap<=1&&(ranged||!options.some(x=>x.preview.melee&&weak(x.target))))||u.hp<unitMaxHp(s.map,u)*.4||(role==='skirmisher'&&!ranged)){
  const exit=retreat();if(exit)return exit;
 }
 if(ranged){
  const targets=options.filter(x=>!x.preview.melee).sort((a,b)=>b.preview.damage*b.preview.hit-a.preview.damage*a.preview.hit+policy({type:'attack',target:b.target,preview:b.preview})-policy({type:'attack',target:a.target,preview:a.preview}));
  if(targets.length&&!attacked)return {type:'attack',target:targets[0].target,intent:'harass'};
  if(u.actionsLeft>=2&&!moved){
   const candidates=[];
   for(const to of legal){if(near(to)<2)continue;for(const target of foes){if(distance(to,target)>stat.range)continue;const preview=shot(u,target,to);if(preview&&!preview.melee)candidates.push({to,target,score:near(to)*8+preview.damage*preview.hit/100-to.cost*.2+policy({type:'move',to})});}}
   candidates.sort((a,b)=>b.score-a.score||a.to.r-b.to.r||a.to.c-b.to.c);
   if(candidates.length)return {type:'move',to:candidates[0].to,intent:'ranged-position'};
  }
  if(!moved){
   // Advance toward a distant observed target without granting an extra shot.
   const to=legal.filter(p=>near(p)>=2&&near(p)<gap).sort((a,b)=>Math.abs(near(a)-stat.range)-Math.abs(near(b)-stat.range)||a.cost-b.cost||a.r-b.r||a.c-b.c)[0];
   if(to)return {type:'move',to,intent:'ranged-approach'};
  }
  const trapped=options.find(x=>x.preview.melee&&weak(x.target));
  if(trapped&&!attacked)return {type:'attack',target:trapped.target,intent:'light-melee'};
  return {type:'hold',intent:'avoid-frontal-charge'};
 }

 const close=options.filter(x=>x.preview.melee&&weak(x.target));
 if(close.length)return {type:'attack',target:close[0].target,intent:'light-melee'};
 if(role==='skirmisher')return {type:'hold',intent:'out-of-ammunition'};
 if(!moved&&u.actionsLeft>=2){
  // Light melee cavalry seek exposed shooters/flanks, not a pike front.
  const candidates=[];
  for(const to of legal){if(foes.some(e=>!weak(e)&&distance(to,e)<=1))continue;const target=foes.find(e=>weak(e)&&distance(to,e)===1);if(target&&shot(u,target,to)?.melee)candidates.push({to,target});}
  candidates.sort((a,b)=>a.to.cost-b.to.cost||a.to.r-b.to.r);
  if(candidates.length)return {type:'move',to:candidates[0].to,intent:'flank-soft-target'};
  const nearest=foes.slice().sort((a,b)=>distance(u,a)-distance(u,b))[0],point=p=>({x:p.c+(p.r&1)/2,z:p.r*Math.sqrt(3)/2}),a=point(u),e=point(nearest),vx=a.x-e.x,vz=a.z-e.z,len=Math.hypot(vx,vz)||1;
  const flank=p=>{const q=point(p);return Math.abs(vx*(q.z-e.z)-vz*(q.x-e.x))/len;};
  const to=legal.filter(p=>near(p)>=2&&distance(p,nearest)<=Math.max(3,gap)&&flank(p)>=.8).sort((a,b)=>(flank(b)-distance(b,nearest))-(flank(a)-distance(a,nearest))||a.cost-b.cost)[0];
  if(to)return {type:'move',to,intent:'flank-maneuver'};
 }
 return {type:'hold',intent:'avoid-frontal-charge'};
}
