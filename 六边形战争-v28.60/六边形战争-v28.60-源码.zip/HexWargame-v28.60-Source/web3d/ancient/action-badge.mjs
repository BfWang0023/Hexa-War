// Screen-space pixels. AP is remaining actions, never movement allowance.
export function actionBadge(value,detail='full'){
 const count=Number.isFinite(value)?Math.max(0,Math.trunc(value)):0;
 const radius=detail==='full'?10:detail==='compact'?8.5:7;
 return {text:String(count),count,color:count===0?'#f4d65d':count===1?'#66b7ff':'#69df91',radius,font:detail==='full'?13:detail==='compact'?11:10};
}
export function drawActionBadge(ctx,value,detail,left,hpY,hpThickness){
 const b=actionBadge(value,detail),x=left-4-b.radius,y=hpY+hpThickness/2;
 ctx.save();ctx.globalAlpha=1;ctx.beginPath();ctx.arc(x,y,b.radius,0,Math.PI*2);ctx.fillStyle='rgba(12,22,20,.88)';ctx.fill();ctx.strokeStyle=b.color;ctx.lineWidth=1.6;ctx.stroke();ctx.fillStyle=b.color;ctx.font=`800 ${b.font}px system-ui, sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(b.text,x,y+.4,b.radius*1.55);ctx.restore();return {x:x-b.radius,y:y-b.radius,w:b.radius*2,h:b.radius*2};
}
// Spatial buckets keep collision checks local even with large selected armies.
export function hudPlacement(){const cells=new Map(),step=64;const keys=r=>{const out=[];for(let x=Math.floor(r.x/step);x<=Math.floor((r.x+r.w)/step);x++)for(let y=Math.floor(r.y/step);y<=Math.floor((r.y+r.h)/step);y++)out.push(`${x},${y}`);return out;};return rect=>{for(const lift of [0,20,40]){const r={...rect,y:rect.y-lift};if(r.y<0)continue;const ks=keys(r);if(ks.some(k=>(cells.get(k)||[]).some(v=>r.x<v.x+v.w+2&&r.x+r.w+2>v.x&&r.y<v.y+v.h+2&&r.y+r.h+2>v.y)))continue;for(const k of ks){if(!cells.has(k))cells.set(k,[]);cells.get(k).push(r);}return lift;}return null;};}
