// Ancient accounts constrain relative terrain and deployments; coordinates are schematic.
const TH='https://www.gutenberg.org/files/7142/7142-h/7142-h.htm',X='https://www.gutenberg.org/files/1174/1174-h/1174-h.htm';
export const MORE_CLASSICAL_CAMPAIGNS=Object.freeze([
 {id:'delium',year:-424,name:'德利翁之战',factions:['帕贡达斯波奥提亚联军','希波克拉底雅典军'],focus:[33,21],camera:190,
  terrain:'起伏旱地和边缘沟谷，中央保留开阔接战面；波奥提亚左翼后方有可绕行低丘。具体战场位置有争议，不把现代海岸贴进主战线。',
  forces:'修昔底德4.93记双方各约7000重装步兵，均缩为28枚（每枚约250人）。波奥提亚1000骑缩为4枚；其逾万轻兵压缩为10轻兵加2投射分队，并非逐人等比换算。雅典骑兵仅示意2枚，不部署已经离开的非正规轻装大队。',
  deployment:'波奥提亚右侧底比斯重兵纵深较厚，雅典主线较薄。采用会战而非后续火攻神庙截面；骑兵绕丘和两翼变化交由玩家，未设置历史强制溃败。',
  sources:[['修昔底德4.89—96',TH],['牛津古典辞典：德利翁','https://academic.oup.com/edited-volume/61673/chapter-abstract/548732646']]},
 {id:'amphipolis',year:-422,name:'安菲波利斯之战',factions:['克里昂雅典远征军','布拉西达斯斯巴达联军'],focus:[36,24],camera:210,
  terrain:'斯特律蒙河西侧为刻尔迪利翁高地，东岸城垒与通向埃昂的西南陆路相接；南缘河口入海。河道、两座出击门与城墙轮廓均为缩放示意。',
  forces:'修昔底德5.2、6—11：雅典1200重兵、300骑兵和数量不详的盟军；用24重兵、6骑兵（约50人/枚）与4盟军轻兵示意。斯巴达方约2000重兵用40枚，含布拉西达斯150人突击队3枚；另10轻兵示意2500名已记载辅助兵，6骑兵示意300骑。未将不详盟军和埃多尼亚人编成伪精确总数。',
  deployment:'采用突击队已出门、雅典开始回撤的截面，前出小队与城内后续队分置。雅典可选择让24支陆军退到埃昂方向撤离区；这是既有撤离机制的可玩性目标，不预定指挥官阵亡或全军奔逃。',
  sources:[['修昔底德5.2、5.6—11','https://classics.mit.edu/Thucydides/pelopwar.5.fifth.html']]},
 {id:'coronea_394',year:-394,name:'科罗尼亚之战',factions:['阿格西劳斯斯巴达联军','底比斯·阿尔戈斯联军'],focus:[33,21],camera:195,
  terrain:'会战平原置于刻菲索斯河与赫利孔山麓之间。地图将推进轴旋转为左右，河流在斯巴达后方、山地在联军后方；不作为正北测绘复原。',
  forces:'色诺芬没有给双方精确总数。本局各32枚重装步兵，斯巴达方6轻兵、对方4轻兵，双方各2骑兵，等量重兵是本局接战规模假设，轻兵与骑兵相对关系依色诺芬；棋子数为相对规模，不换算成确定历史人数。',
  deployment:'斯巴达右翼由阿格西劳斯部队担任，左翼为奥尔科墨诺斯；对方右翼底比斯、左翼阿尔戈斯。选择初次接战截面，双方右翼突破和回身交战由玩家完成，不强迫历史路线。',
  sources:[['色诺芬《希腊史》4.3.15—21',X]]},
 {id:'mantinea_362',year:-362,name:'曼提尼亚会战：底比斯决战',factions:['伊巴密浓达底比斯联军','斯巴达·雅典·曼提尼亚联军'],focus:[35,22],camera:200,
  terrain:'阿卡迪亚盆地保持开阔，西侧向特该亚的山麓及谷道用连续山区与道路示意；主接战区不添加虚构河流。',
  forces:'狄奥多罗斯15.84记底比斯方逾3万步兵、至少3000骑，对方逾2万步兵、约2000骑。用24重兵+6轻兵+3骑，对18重兵+2轻兵+2骑，约千人/枚，仅取该古代估计量级；各盟邦具体分配是部署抽象。',
  deployment:'底比斯左翼纵深集中、其余部队后置，骑兵前出并配轻兵；对方以重装步兵迎击。与前418年旧曼提尼亚地图分开；不强制伊巴密浓达阵亡，也不强制任何一方获胜。',
  sources:[['色诺芬《希腊史》7.5.18—27',X],['狄奥多罗斯15.84—87','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Diodorus_Siculus/15E%2A.html']]},
]);
export const MORE_CLASSICAL_IDS=new Set(MORE_CLASSICAL_CAMPAIGNS.map(c=>c.id));
const kinds={delium:[['greekHoplite','light','archer','cavalry'],['greekHoplite','cavalry']],amphipolis:[['greekHoplite','light','cavalry'],['greekHoplite','light','cavalry']],coronea_394:[['greekHoplite','light','cavalry'],['greekHoplite','light','cavalry']],mantinea_362:[['greekHoplite','light','cavalry'],['greekHoplite','light','cavalry']]};
export const moreClassicalKinds=(id,team)=>team?kinds[id]?.[team==='egypt'?0:1]||[]:[...new Set(kinds[id]?.flat()||[])];
export function moreClassicalApproach(m,u,team){return m.scenarioId==='amphipolis'?team==='egypt'?{c:21,r:36}:{c:32,r:Math.max(12,Math.min(31,u.r))}:{c:team==='egypt'?33:34,r:u.r};}
