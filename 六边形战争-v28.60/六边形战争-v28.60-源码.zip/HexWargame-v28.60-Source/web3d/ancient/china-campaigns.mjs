import { TERRAIN, addUnit, applyCampaignFinances, expandLogisticsConvoys, inBounds, mobileAt, newMap, setBridge, setFort, setHouse, setTerrain,
  tile, validateMap } from './engine.mjs';
import { CHINA_BATTLE_PLANS } from './china-battle-plans.mjs';
import { isChinaIronAgeScenario } from './china-era.mjs';

// Each entry is a playable tactical episode. Dates and positions are indicative;
// long campaigns are represented by a specific confrontation or siege.
const records = `
mingtiao|-1600|鸣条之战|商汤联军|夏王朝军|商汤|夏桀|field|plain|夏桀中军|《尚书序》记伊尹辅佐商汤伐夏，于鸣条之野与桀交战；《史记·殷本纪》记夏师败绩。确切战场与兵数未定，本图采用步兵对阵的战术示意。
muye|-1046|牧野之战|周与盟国联军|商王朝军|周武王|帝辛|field|plain|商军王旗|周军以战车与虎贲为前锋、较少的普通步兵为后列；商军兵力众多，以轻步兵为主但士气脆弱。
three_guards|-1042|周公平定三监之战|周王师|三监与殷遗军|周公旦|武庚|siege|plain|殷旧都|周公东征，平定三监与殷遗军。
zhou_xu|-960|西周征伐徐夷之战|西周王师|徐夷诸部|周王师统帅|徐夷首领|river|river|徐国渡口|王师东征，争夺淮泗通道；具体年代为示意。
xuge|-707|繻葛之战|郑国军|周王室联军|郑庄公|周桓王|field|plain|繻葛阵地|郑军与周王室联军交战。
hongshui|-638|泓水之战|楚国军|宋国军|楚军统帅|宋襄公|river|river|泓水南岸|楚宋隔泓水对阵。
chengpu|-632|城濮之战|晋国联军|楚国联军|晋文公|子玉|field|plain|城濮中军|晋楚争夺中原霸权。
xiao|-627|秦袭郑与崤山之战|秦国归师|晋国伏兵|孟明视|先轸|breakout|pass|崤山西出口|秦袭郑不成，返军经过崤山遭晋军伏击。
bi|-597|邲之战|楚国军|晋国军|楚庄王|荀林父|river|river|邲地渡口|晋楚两军争夺河岸与中军阵地。
yanling|-575|鄢陵之战|晋国军|楚国军|晋厉公|楚共王|field|plain|鄢陵中军|晋楚再度决战。
boju|-506|柏举之战|吴蔡联军|楚国军|吴王阖闾|楚军统帅|pass|pass|柏举通道|吴蔡联军突破楚军防线。
zuili|-496|吴越槜李之战|越国军|吴国军|越王勾践|吴王阖闾|ambush|forest|槜李阵地|越军在槜李迎击吴军。
guiji|-494|吴越会稽之战|吴国军|越国军|吴王夫差|越王勾践|siege|coast|会稽山口|吴军追击越军至会稽。
yue_wu|-473|越灭吴之战|越国军|吴国军|越王勾践|吴王夫差|siege|coast|吴都城门|越军围攻吴都，结束长期吴越争雄。
jin_partition|-453|三家分晋·晋阳之战|赵韩魏联军|智氏军|赵襄子|智伯瑶|river|river|智氏围城主营|以晋阳之战表现三家分晋的关键转折；正式列侯在前403年。
wei_zhongshan|-406|魏灭中山之战|魏国军|中山国军|乐羊|中山守将|siege|pass|中山城|乐羊率魏军攻中山；战役为长期围攻的压缩表现。
hexi_second|-389|秦魏第二次河西之战·阴晋|秦国军|魏国军|秦军统帅|吴起|field|river|阴晋防线|秦军攻魏西河，魏军据险防守。
guiling|-353|桂陵之战|齐国援军|魏国军|田忌|庞涓|relief|plain|魏军归路|齐军攻魏以救赵，截击回师魏军。
maling|-341|马陵之战|齐国军|魏国军|田忌|庞涓|ambush|pass|马陵道|齐军利用马陵地形伏击魏军。
hexi_third|-330|秦魏第三次河西之战·雕阴|秦国军|魏国军|秦军统帅|魏军统帅|pass|river|河西要塞|秦魏河西争夺后期，秦军收复失地。
alliance_qin|-318|五国第一次合纵攻秦|魏赵韩燕楚联军|秦国军|合纵联军统帅|秦军统帅|pass|pass|函谷关|五国联军向函谷关推进。
qin_bashu|-316|秦灭巴蜀之战|秦国军|蜀国与巴国军|司马错|蜀国守将|pass|pass|蜀道关口|秦军越秦岭进入巴蜀。
qi_yan|-314|齐灭燕之战|齐国军|燕国军|齐军统帅|燕国守将|siege|plain|燕都城门|燕国内乱后齐军进攻燕国。
lantian|-312|秦楚蓝田之战|秦国军|楚国军|秦军统帅|楚怀王|field|river|蓝田阵地|秦楚在蓝田交战。
chui_sha|-301|齐韩魏联合攻楚·垂沙|齐韩魏联军|楚国军|匡章|唐昧|river|river|垂沙渡口|齐韩魏联军进攻楚国。
yique|-293|伊阙之战|秦国军|韩魏联军|白起|韩魏联军统帅|pass|pass|伊阙隘口|秦军迎战韩魏联军。
qi_song|-286|齐国灭宋之战|齐国军|宋国军|齐军统帅|宋康王|siege|plain|宋都城门|齐军攻宋，夺取宋国。
alliance_qi|-284|五国合纵攻齐·济西|燕秦赵魏韩联军|齐国军|乐毅|齐军统帅|field|river|济西阵地|五国联军在济西击败齐军后深入齐地。
tian_dan|-279|田单复国·即墨反击|齐国即墨军|燕国围城军|田单|燕军统帅|breakout|plain|燕军围城营|即墨守军出城反击，以火牛阵为战术表现。
yan_ying|-279|秦楚鄢郢之战|秦国军|楚国军|白起|楚军统帅|siege|river|鄢郢防线|秦军攻入楚国腹地；鄢与郢的战事在此压缩为一图。
eyu|-270|秦赵阏与之战|赵国援军|秦国军|赵奢|秦军统帅|relief|pass|阏与要道|赵军先据北山，秦军争山不得，赵奢乘势反击。
changping|-260|秦赵长平之战|秦国军|赵国军|白起|赵括|pass|pass|长平营垒|秦军自空仓岭以西分北、中、南三路东进，步兵在前、弩兵在后；赵军以空仓岭前卫、丹水主阵、百里石长城北翼纵深布防，韩王山设指挥营，大粮山留后队。
handan|-257|秦赵邯郸之战|赵魏楚联军|秦国围城军|信陵君|秦军统帅|relief|plain|秦军围城主营|赵军与魏楚援军合力解邯郸之围。
qin_zhao|-228|秦灭赵之战|秦国军|赵国军|王翦|赵王迁|siege|pass|邯郸城门|秦军进攻赵国都城。
qin_chu|-224|秦灭楚之战|秦国军|楚国军|王翦|项燕|field|river|楚军主阵|以王翦坚壁待楚军东移后的追击阶段为战术场景。
`;

export const CHINA_CAMPAIGNS = Object.freeze(records.trim().split('\n').map(line => {
  const [key, year, name, attacker, defender, attackerLeader, defenderLeader,
    type, terrain, objectiveName, note] = line.split('|');
  return Object.freeze({ id: `china_${key}`, year: Number(year), name, attacker, defender,
    attackerLeader, defenderLeader, type, terrain, objectiveName, note });
}));
export const CHINA_CAMPAIGN_IDS = new Set(CHINA_CAMPAIGNS.map(x => x.id));

const UNIT_CODES = Object.freeze({ C: 'chinaHeavyChariot', H: 'heavy', L: 'light', A: 'archer',
  G: 'guard', X: 'chinaCrossbow', V: 'cavalry', R: 'siegeRam', O: 'chinaFireOx' });
function ground(m, c, r, kind) { if (inBounds(m, c, r)) setTerrain(m, c, r, kind); }
function line(c1, r1, c2, r2, fn) {
  const n = Math.max(Math.abs(c2 - c1), Math.abs(r2 - r1));
  for (let i = 0; i <= n; i++) fn(Math.round(c1 + (c2 - c1) * i / (n || 1)),
    Math.round(r1 + (r2 - r1) * i / (n || 1)));
}
function paintFeature(m, f, cityId) {
  const [type, a, b, c, d, e, team] = f;
  if (type === 'rv') {
    for (let r = b; r <= c; r++) for (let x = a; x < a + d; x++) ground(m, x, r, TERRAIN.RIVER);
  } else if (type === 'rh') {
    for (let r = a; r < a + d; r++) for (let x = b; x <= c; x++) ground(m, x, r, TERRAIN.RIVER);
  } else if (type === 'water' || type === 'sea') {
    for (let r = b; r <= d; r++) for (let x = a; x <= c; x++)
      ground(m, x, r, type === 'water' ? TERRAIN.RIVER : TERRAIN.SEA);
  } else if (type === 'ridge') {
    line(a, b, c, d, (x, y) => {
      for (let dr = -Math.floor(e / 2); dr <= Math.floor(e / 2); dr++)
        for (let dc = -Math.floor(e / 2); dc <= Math.floor(e / 2); dc++)
          ground(m, x + dc, y + dr, TERRAIN.MOUNTAIN);
    });
  } else if (type === 'road') {
    line(a, b, c, d, (x, y) => {
      const t = tile(m, x, y);
      if (t && t.terrain !== TERRAIN.SEA) ground(m, x, y, t.terrain | TERRAIN.ROAD);
    });
  } else if (type === 'city') {
    const side = team || 'coalition';
    for (let x = a - c; x <= a + c; x++) for (const y of [b - d, b + d])
      if (!setFort(m, x, y, e, side, cityId)) throw new Error(`${cityId}:城墙不可放置 ${x},${y}`);
    for (let y = b - d + 1; y < b + d; y++) for (const x of [a - c, a + c])
      if (!setFort(m, x, y, e, side, cityId)) throw new Error(`${cityId}:城墙不可放置 ${x},${y}`);
    for (const [x, y] of [[a - 2, b - 2], [a + 2, b - 2], [a - 2, b + 2], [a + 2, b + 2]])
      setHouse(m, x, y);
  } else if (type === 'wall') {
    line(a, b, c, d, (x, y) => {
      if (!setFort(m, x, y, e, team || 'coalition', cityId))
        throw new Error(`${cityId}:防线不可放置 ${x},${y}`);
    });
  } else if (type === 'posts') {
    let offset = 0;
    line(a, b, c, d, (x, y) => {
      if (offset++ % 4 === 0 && !setFort(m, x, y, e, team || 'coalition', cityId))
        throw new Error(`${cityId}:营垒不可放置 ${x},${y}`);
    });
  } else throw new Error(`未知战场地形：${type}`);
}
function placeNear(m, kind, team, c, r) {
  for (let radius = 0; radius <= 9; radius++) for (let dr = -radius; dr <= radius; dr++)
    for (let dc = -radius; dc <= radius; dc++) {
      const x = c + dc, y = r + dr;
      if (Math.max(Math.abs(dc), Math.abs(dr)) !== radius || !inBounds(m, x, y)) continue;
      if (!mobileAt(m, x, y) && addUnit(m, kind, team, x, y)) return m.units.at(-1);
    }
  throw new Error(`${m.name}无法部署${team}:${kind}于${c},${r}`);
}

export function makeChinaMap(id) {
  const entry = CHINA_CAMPAIGNS.find(x => x.id === id), plan = CHINA_BATTLE_PLANS[id];
  if (!entry || !plan) throw new Error(`未知先秦战役：${id}`);
  const [cols, rows] = plan.size || [70, 46], m = newMap(cols, rows);
  const objective = { c: plan.objective[0], r: plan.objective[1] };
  m.scenarioId = entry.id;
  m.name = entry.name;
  m.factions = { egypt: entry.attacker, coalition: entry.defender };
  m.unitNames = {
    'egypt:chinaGeneral': entry.attackerLeader, 'coalition:chinaGeneral': entry.defenderLeader,
    'heavy': '持戈重步兵', 'light': '轻装步兵', 'archer': '弓兵',
    'guard': '亲卫', 'chinaHeavyChariot': '四马重战车', 'chariot': '战车', 'cavalry': '骑兵',
    'chinaCrossbow': '弩兵', 'siegeRam': '攻城槌车', 'chinaFireOx': '火牛阵',
  };
  m.intro = `${id === 'china_mingtiao' ? '约' : ''}前${-entry.year}年 · ${entry.note}${plan.historicalForce || ''}${isChinaIronAgeScenario(id) ? '双方陆上士兵采用铁器时代战斗规格：耐久 +6.0、护甲 +1、近战与已有远程攻击各 +1.5；攻城槌和火牛不享受加成。' : ''}${id === 'china_mingtiao' ? '地图仅表现两军在平原接战，不作古战场地理复原。' : '地形与队列据史料重构；具体坐标、兵数及阵列距离为游戏化推定。'}`;
  m.victory = { mode: 'china', attacker: 'egypt', objective, objectiveName: entry.objectiveName,
    losses: plan.losses || { egypt: 11, coalition: 11 },
    turnLimit: plan.turnLimit || (plan.breach ? 34 : 28), breach: !!plan.breach };
  m.landmarks = plan.landmarks.map(([c, r, label]) => ({ c, r, label }));
  for (const feature of plan.features) paintFeature(m, feature, entry.objectiveName);
  const mainBridges = {
    china_changping: [[42, 28], [43, 28]],
    china_qin_chu: [[48, 27], [49, 27]],
  };
  for (const [c, r] of mainBridges[id] || [])
    if (!setBridge(m, c, r)) throw new Error(`${id}:主桥必须建在渡口上`);
  if (id === 'china_changping') m.landmarks.push({ c: 42, r: 28, label: '丹水中路桥（可拆）' });
  if (id === 'china_qin_chu') m.landmarks.push({ c: 48, r: 27, label: '楚军东移中路桥（可拆）' });
  for (const [team, position] of [['egypt', plan.leaders[0]], ['coalition', plan.leaders[1]]])
    placeNear(m, 'chinaGeneral', team, ...position);
  for (const [team, name, c, r, shorthand] of plan.groups) {
    for (const token of shorthand.split(/\s+/)) {
      const kind = UNIT_CODES[token[0]], count = Number(token.slice(1));
      if (!kind || !Number.isInteger(count) || count < 1) throw new Error(`${id}:无效编组 ${name}:${token}`);
      for (let i = 0; i < count; i++) {
        const unit = placeNear(m, kind, team, c, r);
        unit.formation = name;
        if (id === 'china_changping' && team === 'egypt' && kind === 'cavalry' &&
            (name === '秦军北路后队' || name === '秦军南路后队')) unit.deepRaider = true;
        if (plan.formationMorale?.[name] !== undefined) unit.morale = plan.formationMorale[name];
      }
    }
  }
  if (id === 'china_changping' || id === 'china_qin_chu') {
    for (const [team, [c, r]] of [['egypt', plan.leaders[0]], ['coalition', plan.leaders[1]]]) {
      const guard = placeNear(m, 'moraleGuard', team, c + (team === 'egypt' ? -2 : 2), r + 2);
      guard.formation = `${m.factions[team]}后方督战队`;
    }
  }
  if (id === 'china_changping' || id === 'china_qin_chu') {
    const changping = id === 'china_changping';
    m.logistics = changping ? {
      startingMoney: { egypt: 800, coalition: 340 }, income: { egypt: 360, coalition: 155 },
      depots: { egypt: [{ c: 4, r: 28 }], coalition: [{ c: 76, r: 28 }] },
      musters: { egypt: [{ c: 7, r: 30 }], coalition: [{ c: 73, r: 30 }] },
      routes: { egypt: [{ c: 7, r: 28 }, { c: 14, r: 28 }, { c: 20, r: 28 }],
        coalition: [{ c: 73, r: 28 }, { c: 66, r: 28 }, { c: 58, r: 28 }] },
    } : {
      startingMoney: { egypt: 850, coalition: 330 }, income: { egypt: 400, coalition: 165 },
      depots: { egypt: [{ c: 5, r: 27 }], coalition: [{ c: 83, r: 27 }] },
      musters: { egypt: [{ c: 8, r: 29 }], coalition: [{ c: 80, r: 29 }] },
      routes: { egypt: [{ c: 8, r: 27 }, { c: 15, r: 27 }, { c: 23, r: 27 }],
        coalition: [{ c: 80, r: 27 }, { c: 73, r: 27 }, { c: 66, r: 27 }] },
    };
    const wagonPositions = changping ? {
      egypt: [[5, 28], [9, 16], [10, 39], [17, 22], [17, 34]],
      coalition: [[75, 28], [31, 20], [50, 27], [62, 20], [62, 39]],
    } : {
      egypt: [[6, 27], [16, 18], [16, 36], [29, 18], [29, 36]],
      coalition: [[82, 27], [68, 18], [68, 36], [76, 28]],
    };
    for (const team of ['egypt', 'coalition']) for (const [c, r] of wagonPositions[team])
      placeNear(m, 'supplyWagon', team, c, r);
    expandLogisticsConvoys(m);
  }
  applyCampaignFinances(m);
  validateMap(m);
  return m;
}
