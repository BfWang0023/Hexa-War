import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {STATS,isFormableInfantry,neighbors,newMap,addUnit,startGame,setPhalanxMode,move,mobileAt,reachable,exportMap,importMap} from './engine.mjs';
import {createUnitModel} from './models.mjs';
import {animateFullModel} from './full-models.mjs';
import {createUnitAnimator,headingBetween} from './unit-animation.mjs';
import {createSave,restoreSave} from './save.mjs';
import {signature} from '../../tools/hero-geometry-signature.mjs';
const kinds=Object.keys(STATS).filter(kind=>isFormableInfantry({kind}));
const unit=(kind,formed=true,facing=0)=>({id:kind,kind,team:'egypt',hp:100,c:4,r:4,formed,facing,morale:1});
function pole(soldier){return soldier.getObjectByName('formation-spear')||soldier.getObjectByName('melee-tool');}
function check(model,u){
 model.updateMatrixWorld(true);const expected=new T.Vector3(1,0,0).applyAxisAngle(new T.Vector3(0,1,0),headingBetween(u,neighbors(u.c,u.r)[u.facing]));
 const soldiers=[];model.getObjectByName('near').traverse(o=>{if(o.name==='soldier')soldiers.push(o);});assert.ok(soldiers.length);
 for(const soldier of soldiers){const tool=pole(soldier),direction=new T.Vector3(0,1,0).transformDirection(tool.matrixWorld);assert.ok(direction.dot(expected)>.999,'spear points along specified facing');assert.ok(tool.visible,'formed spear is visible');const shield=soldier.getObjectByName('shield');assert.ok(shield.position.y>2.65,'shield is raised');}
}
for(const kind of kinds)test(`${kind}: formation spears and shields hold through six facings, walking and low quality`,()=>{
 for(let facing=0;facing<6;facing++){
  const u=unit(kind,true,facing),m=createUnitModel(u,'mantinea'),anim=createUnitAnimator(),g=new T.Group(),cam=new T.PerspectiveCamera();m.userData.unitId=u.id;g.add(m);anim.observe([u],0,{scenarioId:'mantinea'});
  anim.update(g,cam,0);check(m,u);
  for(const time of [80,170,340,700]){animateFullModel(m,time,{moving:true,complex:false,distance:20});check(m,u);}
  animateFullModel(m,1000,{distance:150,moving:true});assert.equal(m.getObjectByName('far').visible,true);
 }
});
test('formation silhouette is horizontal in the baked far LOD, not only the articulated near rig',()=>{
 for(const kind of kinds){const m=createUnitModel(unit(kind),'mantinea'),far=m.getObjectByName('far'),near=m.getObjectByName('near');far.visible=true;near.visible=false;
 const geometry=new T.Box3().setFromObject(far);const width=geometry.max.x-geometry.min.x;assert.ok(width>3.1*.69,`${kind} far spear extends forward`);}
});
test('formed melee keeps the specified spear facing even when target is on another side',()=>{
 const u=unit('romanLegion',true,2),m=createUnitModel(u,'cannae'),anim=createUnitAnimator(),g=new T.Group();m.userData.unitId=u.id;g.add(m);anim.observe([u],0,{scenarioId:'cannae'});
 anim.attack({ok:true,visual:{from:u,to:neighbors(u.c,u.r)[0],attackerId:u.id,attackerKind:u.kind,attackerTeam:u.team,melee:true}},0,{scenarioId:'cannae'});
 for(const t of [200,400,650]){anim.update(g,new T.PerspectiveCamera(),t);check(m,u);}
});
test('formation and marching templates are isolated and toggling off restores the original pose',()=>{
 for(const kind of kinds){const u=unit(kind,false),a=createUnitModel(u,'mantinea'),before=signature(a);createUnitModel({...u,formed:true},'mantinea');const b=createUnitModel(u,'mantinea');assert.equal(signature(b),before);animateFullModel(b,500,{moving:true});const tool=b.getObjectByName('near').getObjectByName('melee-tool');assert.ok(Math.abs(tool.rotation.x)<.01);assert.equal(b.getObjectByName('formation-spear'),undefined);}
});
test('formed movement uses existing one-step budget and keeps stance after game/save restore',()=>{
 const m=newMap(12,8);m.scenarioId='custom_formation';addUnit(m,'pharaoh','egypt',0,0);addUnit(m,'greekHoplite','egypt',3,3);addUnit(m,'light','coalition',11,7);const s=startGame(m),u=mobileAt(s.map,3,3);
 assert.ok(setPhalanxMode(s,u.id,true,0).ok);const dest=reachable(s,u).get('4,3');assert.ok(dest);assert.equal(reachable(s,u).has('5,3'),false);assert.ok(move(s,u.id,4,3).ok);assert.equal(u.actionsLeft,0);assert.equal(u.formed,true);assert.equal(u.facing,0);
 const save=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,'egypt')))).game,v=save.map.units.find(v=>v.id===u.id);assert.equal(v.formed,true);assert.equal(v.facing,0);assert.ok(importMap(exportMap(s.map)));const model=createUnitModel(v,'mantinea');animateFullModel(model,200,{moving:true});check(model,v);
});

test('queued formation movement keeps the chosen facing when marching sideways or backward',()=>{
 for(const kind of kinds)for(let facing=0;facing<6;facing++){
  const u=unit(kind,true,facing),dest=neighbors(u.c,u.r)[(facing+2)%6],model=createUnitModel(u,'mantinea'),anim=createUnitAnimator(),g=new T.Group();model.userData.unitId=u.id;g.add(model);anim.observe([u],0,{scenarioId:'mantinea'});anim.move(u.id,u,[dest],0);anim.observe([{...u,...dest}],1,{scenarioId:'mantinea'});
  for(const time of [45,160,300,400]){anim.update(g,new T.PerspectiveCamera(),time);check(model,{...u,...dest});}
 }
});
