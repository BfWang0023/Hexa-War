import {planningState} from './fog-policy.mjs';
// Player-authorized nearest allocation. No fixed ratio, combat scoring or invented movement rules.
import {reachable,neighbors,key,inBounds,mobileAt,distance} from './engine.mjs';
import {battlefronts,knownArmies,projection,hexFromPlane,around} from './battlefield-space.mjs';
import {resolveLocation} from './tactical-location.mjs';
export function* iterateFlankRally(state,units,step,context){state=planningState(state,context.team);
 const {own,enemy}=knownArmies(state,context.team),fronts=battlefronts(own,context.frame,enemy);
 let ref;
 if(step.reference){const x=resolveLocation(state,step.reference,context,units);ref={units:own.filter(u=>distance(u,x.position)<=8),frame:x.frame,description:x.description};}
 else {const groups=fronts.filter(g=>g.units.some(u=>units.some(v=>u.id===v.id)));if(groups.length!==1)throw Error('存在多条独立战线，请指定第几战线或参照编组后就近向两翼集结');ref={...groups[0],description:'第'+groups[0].id+'战线'};}
 const frame=ref.frame,core=ref.units.length?ref.units:units,projected=core.map(u=>projection(u,frame)),left=Math.max(...projected.map(p=>p.left)),right=Math.min(...projected.map(p=>p.left)),front=projected.map(p=>p.front).sort((a,b)=>a-b)[Math.floor(projected.length/2)],center=frame.origin;
 const targets={left:[],right:[]};
 for(const side of ['left','right']){const lateral=side==='left'?left+2:right-2,point=hexFromPlane({x:center.x+frame.forward.x*front+frame.forward.z*lateral,z:center.z+frame.forward.z*front-frame.forward.x*lateral});targets[side]=around(point,3).filter(p=>inBounds(state.map,p.c,p.r)&&projection(p,frame).left*(side==='left'?1:-1)>0);}
 const ids=new Set(units.map(u=>u.id)),shadow={...state,map:{...state.map,units:state.map.units.filter(u=>!ids.has(u.id))}},reserved=new Set(),assignments=[];
 for(const u of units){
  // Repeated original reachable calls on read-only virtual actors extend the path-cost
  // search across this turn's AP budget. The real move API validates each committed move.
  const paths=new Map([[key(u.c,u.r),{c:u.c,r:u.r,cost:0,spent:0}]]);let frontier=[{...u,cost:0,spent:0}];
  for(let n=0;n<Math.min(3,Math.max(0,u.actionsLeft));n++){const next=[];for(const v of frontier){for(const p of reachable(shadow,{...u,c:v.c,r:v.r,actionsLeft:u.actionsLeft-v.spent,formationSteps:(u.formationSteps||0)+(v.marchedSteps||0),movesUsed:(u.movesUsed||0)+n}).values()){const k=key(p.c,p.r),cost=v.cost+p.cost,old=paths.get(k);if(!old||cost<old.cost){const item={...p,cost,spent:v.spent+(p.actionCost||1),marchedSteps:(v.marchedSteps||0)+p.steps};paths.set(k,item);next.push(item);}}}frontier=next;yield;}
  const options=[];for(const side of ['left','right'])for(const p of targets[side]){const route=paths.get(key(p.c,p.r));if(route&&!reserved.has(key(p.c,p.r))&&!mobileAt(shadow.map,p.c,p.r))options.push({side,p,cost:route.cost});}
  options.sort((a,b)=>a.cost-b.cost||distance(u,a.p)-distance(u,b.p)||a.p.r-b.p.r||a.p.c-b.p.c);const best=options[0];if(best){reserved.add(key(best.p.c,best.p.r));assignments.push({id:u.id,to:{c:best.p.c,r:best.p.r},side:best.side,pathCost:best.cost,from:{c:u.c,r:u.r}});}else assignments.push({id:u.id,to:null,reason:u.actionsLeft<=0?'行动力不足':'本回合没有可达且空余的翼侧阵位'});yield;
 }
 const counts={left:assignments.filter(a=>a.side==='left').length,right:assignments.filter(a=>a.side==='right').length};return {label:'就近两翼集结',reference:ref.description,heading:frame.heading,assignments,counts,stance:false,note:`${ref.description}：左翼${counts.left}、右翼${counts.right}；${counts.left&&counts.right?'两翼均有合法分配':'两翼未能同时满足，未报告为两翼完成'}`};
}
