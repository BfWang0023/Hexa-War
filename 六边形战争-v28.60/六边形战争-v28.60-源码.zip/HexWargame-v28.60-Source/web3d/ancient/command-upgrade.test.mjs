import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three/three.module.js';
import {newMap,TERRAIN,setTerrain,setFort,setBridge,bridgeAt,fortAt,addUnit,mobileAt,startGame,reachable,move,attack,attackPreview,aiTurn,recomputeFog,destroyBridge,canDestroyBridge,neighbors,exportMap,importMap,setUnitStats} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
import {createTerrainRefresh} from './terrain-refresh.mjs';
import {adjacency,wallNeighbors,crossingAxis} from './terrain-adjacency.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {createTerrainForts} from './terrain-forts.mjs';
import {terrainHeight} from './terrain.mjs';
import {createUnitAnimator,headingBetween} from './unit-animation.mjs';
import {createUnitModel} from './models.mjs';
import {planGroupMove,executeGroupMove,rectangleSelection,toggleSelection,gestureMode,axial} from './group-command.mjs';
function battle(kind='light') {
 const m=newMap(20,12);m.scenarioId='custom_command';addUnit(m,'pharaoh','egypt',0,0);addUnit(m,'light','coalition',19,11);
 for(const [c,r] of [[3,4],[3,5],[3,6]])assert.ok(addUnit(m,kind,'egypt',c,r));
 const s=startGame(m),units=s.map.units.filter(u=>u.kind===kind&&u.team==='egypt');
 return {s,units,ids:units.map(u=>u.id)};
}
function fingerprint(m){return JSON.stringify(exportMap(m));}
for(const row of [4,5])for(let direction=0;direction<6;direction++)test(`wall auto-connect row ${row}, direction ${direction}`,()=>{
 const m=newMap(12,10),a={c:5,r:row},b=neighbors(a.c,a.r)[direction];setFort(m,a.c,a.r,1,'egypt');setFort(m,b.c,b.r,3,'egypt');fortAt(m,b.c,b.r).hp=50;
 const walls=m.units,by=new Map(walls.map(u=>[`${u.c},${u.r}`,u]));
 assert.equal(wallNeighbors(m,walls[0],by)[0].direction,direction);
 const g=createTerrainForts(m,walls,terrainHeight);g.traverse(o=>{if(o.isInstancedMesh)assert.ok(o.instanceMatrix.array.every(Number.isFinite));});
 const mesh=g.getObjectByName('wall-masonry'),matrix=new THREE.Matrix4();mesh.getMatrixAt(1,matrix);const center=new THREE.Vector3().setFromMatrixPosition(matrix),p=offsetToWorld(a.c,a.r),q=offsetToWorld(b.c,b.r);assert.ok(Math.abs(center.x-(p.x+(q.x-p.x)/4))<1e-4);assert.ok(Math.abs(center.z-(p.z+(q.z-p.z)/4))<1e-4);
 assert.equal(mesh.count,5); // two nodes, two arms, one tower
});
test('wall corners, triple/multiple junctions and removal update adjacent chunks',()=>{
 const m=newMap(48,48),v=createTerrainRefresh(8);setFort(m,15,16,2,'egypt');
 for(const n of neighbors(15,16).filter((_,i)=>[0,1,3,4].includes(i)))setFort(m,n.c,n.r,2,'egypt');
 v.refresh(m);const far=v.chunks.get('5,5').forts.uuid;
 const wall=fortAt(m,15,16),by=new Map(m.units.map(u=>[`${u.c},${u.r}`,u]));assert.equal(wallNeighbors(m,wall,by).length,4);
 setFort(m,15,16,0);const result=v.refresh(m);assert.ok(result.fortChunks.includes('1,2'));assert.ok(result.fortChunks.includes('2,2'));assert.equal(result.terrainChunks.length,0);assert.equal(v.chunks.get('5,5').forts.uuid,far);v.dispose();
});
test('editor cell changes rebuild only local chunks and share exact corner heights',()=>{
 const m=newMap(48,48),v=createTerrainRefresh(8);v.refresh(m);const far=v.chunks.get('5,5').terrain.surface.uuid;
 setTerrain(m,7,8,TERRAIN.MOUNTAIN|TERRAIN.ROAD);setTerrain(m,8,8,TERRAIN.ROAD);const result=v.refresh(m);
 assert.ok(result.terrainChunks.length<=4);assert.equal(v.chunks.get('5,5').terrain.surface.uuid,far);
 const seen=new Map();for(const x of v.chunks.values()) {const a=x.terrain.surface.geometry.attributes.position;for(let i=0;i<a.count;i++){
 const key=`${a.getX(i).toFixed(3)},${a.getZ(i).toFixed(3)}`;if(seen.has(key))assert.ok(Math.abs(seen.get(key)-a.getY(i))<1e-5);else seen.set(key,a.getY(i));}}
 assert.equal(adjacency(m,7,8,TERRAIN.ROAD).length,1);assert.equal(v.refresh(m).terrainChunks.length,0);v.dispose();
});
test('continuous water, bridge axis and underlying ford survive edits and map/save restore',()=>{
 const {s}=battle(),m=s.map,v=createTerrainRefresh(8);
 for(const r of [3,4,5])setTerrain(m,8,r,TERRAIN.RIVER);setTerrain(m,8,4,TERRAIN.RIVER|TERRAIN.ROAD);setTerrain(m,7,4,TERRAIN.ROAD);setTerrain(m,9,4,TERRAIN.ROAD);setBridge(m,8,4);
 assert.ok(Math.abs(Math.sin(crossingAxis(m,8,4)))<1e-6);v.refresh(m);assert.ok(v.group.getObjectByName('bridge-decks'));assert.ok(v.group.getObjectByName('underlying-fords'));
 for(const x of v.chunks.values()){const a=x.terrain.group.getObjectByName('continuous-water')?.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)assert.ok(Math.abs(a.getY(i)+.42)<1e-6);}
 setBridge(m,8,4,false);assert.ok(v.refresh(m).terrainChunks.length<=4);assert.equal(v.group.getObjectByName('bridge-decks'),undefined);assert.ok(v.group.getObjectByName('underlying-fords'));assert.equal(m.terrain[4*m.cols+8],TERRAIN.RIVER|TERRAIN.ROAD);
 const copy=importMap(exportMap(m));v.refresh(copy);assert.equal(v.group.getObjectByName('bridge-decks'),undefined);
 const restored=restoreSave(JSON.parse(JSON.stringify(createSave(m,s,'egypt')))).game;v.refresh(restored.map);assert.ok(v.group.getObjectByName('underlying-fords'));v.dispose();
});
test('wall damage/destruction and a reverted edit refresh their derived state',()=>{
 const m=newMap(32,32),v=createTerrainRefresh(8);setFort(m,9,9,3,'egypt');v.refresh(m);const old=v.chunks.get('1,1').forts.uuid;fortAt(m,9,9).hp=1;
 assert.equal(v.refresh(m).terrainChunks.length,0);assert.notEqual(v.chunks.get('1,1').forts.uuid,old);
 fortAt(m,9,9).hp=0;v.refresh(m);assert.ok(v.forts.getObjectByName('wall-rubble'));
 setTerrain(m,3,3,TERRAIN.MOUNTAIN);v.refresh(m);setTerrain(m,3,3,TERRAIN.PLAIN);assert.ok(v.refresh(m).terrainChunks.length);v.dispose();
});
test('rectangle selection and Shift toggling filter enemy, dead, routed, embarked and static units',()=>{
 const {s,units,ids}=battle(),u=units[0],project=x=>({x:x.c*10,y:x.r*10});
 assert.deepEqual([...rectangleSelection(s.map.units,'egypt',{x1:35,y1:65,x2:25,y2:35},project)],ids);
 let selected=toggleSelection([],u,'egypt');assert.ok(selected.has(u.id));selected=toggleSelection(selected,u,'egypt');assert.equal(selected.size,0);
 for(const extra of [{team:'coalition'},{hp:0},{routed:true},{aboard:'ship'},{kind:'fort'},{kind:'defenseTower'}])assert.equal(toggleSelection([],{...u,...extra},'egypt').size,0);
 assert.equal(rectangleSelection(units,'egypt',{x1:0,y1:0,x2:100,y2:100},()=>({x:50,y:50,visible:false})).size,0);
});
test('selection gesture is distinct from camera drag and editor painting',()=>{
 const b={button:0,editing:false,space:false,shift:false,box:false,canSelect:true};
 assert.equal(gestureMode(b),'select-pending');assert.equal(gestureMode({...b,shift:true}),'select-pending');assert.equal(gestureMode({...b,box:true}),'select-pending');
 assert.equal(gestureMode({...b,button:1,shift:true}),'rotate');assert.equal(gestureMode({...b,button:2,shift:true}),'pan-pending');assert.equal(gestureMode({...b,space:true,box:true}),'pan');assert.equal(gestureMode({...b,editing:true,shift:true,box:true}),'paint');assert.equal(gestureMode({...b,canSelect:false,shift:true}),'pending');
});
test('group preview is side-effect-free and movement preserves axial formation across odd/even rows',()=>{
 const {s,units,ids}=battle(),before=fingerprint(s.map),plan=planGroupMove(s,ids,{c:5,r:5});assert.equal(fingerprint(s.map),before);assert.equal(plan.order.length,3);
 assert.ok(plan.entries.every(p=>!p.changedFormation));assert.deepEqual(executeGroupMove(s,plan).success,3);
 const shifts=units.map((u,i)=>{const a=axial(u),b=axial(plan.entries.find(p=>p.id===u.id).from);return [a.q-b.q,a.r-b.r];});assert.ok(shifts.every(p=>p.join()==shifts[0].join()));assert.ok(units.every(u=>u.actionsLeft===1));
});
test('front ranks vacate before rear ranks, without target overlaps',()=>{
 const {s,units,ids}=battle('cavalry');for(let i=0;i<3;i++){units[i].c=3+i;units[i].r=4;}recomputeFog(s);
 const plan=planGroupMove(s,ids,{c:5,r:4});assert.equal(plan.order.length,3);const result=executeGroupMove(s,plan);assert.equal(result.success,3);assert.equal(new Set(units.map(u=>`${u.c},${u.r}`)).size,3);
});
test('partial failure does not prevent other moves or restore exhausted actions',()=>{
 const {s,units,ids}=battle();units[0].actionsLeft=0;const origin={c:units[0].c,r:units[0].r};const plan=planGroupMove(s,ids,{c:5,r:5});const result=executeGroupMove(s,plan);
 assert.equal(result.success,2);assert.equal(result.failed,1);assert.deepEqual({c:units[0].c,r:units[0].r},origin);assert.equal(units[0].actionsLeft,0);
});
test('terrain/enemy blocking and occupied destinations never become teleporting or attacks',()=>{
 const {s,units,ids}=battle('chinaHeavyChariot');for(let r=0;r<s.map.rows;r++)setTerrain(s.map,4,r,TERRAIN.MOUNTAIN);recomputeFog(s);
 const plan=planGroupMove(s,ids,{c:7,r:5});assert.equal(plan.order.length,0);assert.equal(executeGroupMove(s,plan).success,0);
 const other=battle();other.s.map.units.find(u=>u.team==='coalition').c=5;other.s.map.units.find(u=>u.team==='coalition').r=5;recomputeFog(other.s);
 const p=planGroupMove(other.s,other.ids,{c:5,r:5});executeGroupMove(other.s,p);assert.equal(mobileAt(other.s.map,5,5).team,'coalition');
});
for(const bridge of [false,true])test(`group moves obey ${bridge?'bridge':'ford'} action and distance rules`,()=>{
 const {s,units,ids}=battle('chinaHeavyChariot');
 for(let r=0;r<s.map.rows;r++)setTerrain(s.map,4,r,TERRAIN.RIVER);
 for(const u of units){setTerrain(s.map,u.c,u.r,TERRAIN.ROAD);setTerrain(s.map,u.c+1,u.r,TERRAIN.RIVER|TERRAIN.ROAD);if(bridge)setBridge(s.map,u.c+1,u.r);}
 const plan=planGroupMove(s,ids,{c:6,r:5});const original=new Map(units.map(u=>[u.id,{...u}]));const result=executeGroupMove(s,plan);assert.ok(result.success>0);
 for(const e of plan.entries.filter(e=>e.status==='move')){const u=units.find(u=>u.id===e.id);assert.equal(u.actionsLeft,bridge?1:0);if(!bridge)assert.equal(u.c,original.get(u.id).c+1);}
});
test('changed/stale plans and enemy-phase/deployment requests are refused legally',()=>{
 const {s,units,ids}=battle(),plan=planGroupMove(s,ids,{c:5,r:5});for(const e of plan.entries)assert.ok(addUnit(s.map,'heavy','egypt',e.to.c,e.to.r));
 assert.equal(executeGroupMove(s,plan).success,0);assert.ok(units.every(u=>u.actionsLeft===2));s.side='coalition';assert.equal(executeGroupMove(s,plan).success,0);s.side='egypt';s.deploying=true;assert.equal(executeGroupMove(s,plan).success,0);
});
test('group execution delivers exact accepted paths to the existing direction/animation controller',()=>{
 const {s,units,ids}=battle(),anim=createUnitAnimator();anim.observe(s.map.units,0,s.map);const plan=planGroupMove(s,ids,{c:5,r:5});
 executeGroupMove(s,plan,(state,id,c,r)=>{const u=state.map.units.find(u=>u.id===id),from={c:u.c,r:u.r},result=move(state,id,c,r);if(result.ok)anim.move(id,from,result.path,0);return result;});
 anim.observe(s.map.units,1,s.map);const group=new THREE.Group();for(const u of units){const model=createUnitModel(u,s.map.scenarioId,{map:s.map});model.userData.unitId=u.id;group.add(model);}
 anim.update(group,new THREE.PerspectiveCamera(),5000);
 for(const e of plan.entries.filter(e=>e.status==='move'))assert.ok(Math.abs(anim.inspect(e.id).heading-headingBetween(e.path.length>1?e.path.at(-2):e.from,e.path.at(-1)))<1e-8);
});
function bridgeBattle(kind='light',range=1) {
 const m=newMap(12,8);m.scenarioId='custom_bridge';setTerrain(m,5,3,TERRAIN.RIVER|TERRAIN.ROAD);setBridge(m,5,3);
 addUnit(m,'pharaoh','egypt',0,0);addUnit(m,kind,'egypt',5-range,3);addUnit(m,'light','coalition',5,3);addUnit(m,'heavy','coalition',11,7);
 const s=startGame(m);return {s,u:mobileAt(s.map,5-range,3)};
}
for(const [kind,range] of [['light',1],['archer',3],['chinaCrossbow',3]])test(`${kind} attacks bridge garrison without damaging/removing its bridge`,()=>{
 const {s,u}=bridgeBattle(kind,range),before=structuredClone(s.map.bridges);assert.ok(attackPreview(s,u,5,3));assert.ok(attack(s,u.id,5,3,0).ok);assert.deepEqual(s.map.bridges,before);
});
test('explicit demolition consumes exactly one action, keeps ford/garrison and is saved',()=>{
 const {s,u}=bridgeBattle(),victim=mobileAt(s.map,5,3),hp=victim.hp,before=u.actionsLeft;
 assert.ok(canDestroyBridge(s,u,5,3));assert.ok(destroyBridge(s,u.id,5,3).ok);assert.equal(u.actionsLeft,before-1);assert.equal(bridgeAt(s.map,5,3),false);assert.equal(victim.hp,hp);assert.equal(s.map.terrain[3*s.map.cols+5],TERRAIN.RIVER|TERRAIN.ROAD);
 const restored=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,'egypt')))).game;assert.equal(bridgeAt(restored.map,5,3),false);assert.equal(mobileAt(restored.map,5,3).hp,hp);const ap=u.actionsLeft;assert.equal(destroyBridge(s,u.id,5,3).ok,false);assert.equal(u.actionsLeft,ap);
});
test('bridge removal beneath a unit preserves its HP, location and existing remaining actions',()=>{
 const {s,u}=bridgeBattle();const foe=mobileAt(s.map,5,3);foe.team='egypt';s.map.units=s.map.units.filter(x=>x.id!==u.id);foe.actionsLeft=2;const hp=foe.hp;assert.ok(destroyBridge(s,foe.id,5,3).ok);assert.deepEqual([foe.c,foe.r,foe.hp,foe.actionsLeft],[5,3,hp,1]);
});
test('illegal demolitions consume nothing',()=>{
 for(const change of [({u})=>u.actionsLeft=0,({u})=>u.routed=true,({u})=>u.team='coalition',({u})=>u.c=0,({s})=>s.over=true,({s})=>s.deploying=true,({u})=>u.aboard='ship',({u})=>u.kind='fort',({u})=>u.kind='transport']){
 const x=bridgeBattle();change(x);const ap=x.u.actionsLeft;assert.equal(destroyBridge(x.s,x.u.id,5,3).ok,false);assert.equal(x.u.actionsLeft,ap);assert.equal(bridgeAt(x.s.map,5,3),true);}
});
test('AI normal ranged combat preserves bridges, while explicit demolition is a separate paid order',()=>{
 const {s,u}=bridgeBattle('archer',3);u.actionsLeft=1;s.map.units.find(u=>u.kind==='pharaoh').actionsLeft=0;const orders=aiTurn(s,()=>0);
 assert.ok(orders.some(a=>a.type==='attack'));assert.equal(orders.some(a=>a.type==='destroyBridge'),false);assert.ok(bridgeAt(s.map,5,3));
 const second=bridgeBattle();second.u.actionsLeft=1;second.s.map.units.find(u=>u.kind==='pharaoh').actionsLeft=0;const demolition=aiTurn(second.s,()=>0);
 assert.ok(demolition.some(a=>a.type==='destroyBridge'));assert.equal(second.u.actionsLeft,0);assert.equal(bridgeAt(second.s.map,5,3),false);
});

test('batch marching crosses own low walls and never offers them as stopping cells',()=>{
 const {s,units,ids}=battle('chinaHeavyChariot');
 for(let r=0;r<s.map.rows;r++)setTerrain(s.map,4,r,TERRAIN.RIVER);
 for(const u of units){setTerrain(s.map,4,u.r,TERRAIN.PLAIN);setFort(s.map,4,u.r,1,'egypt');}
 const plan=planGroupMove(s,ids,{c:5,r:5});assert.equal(plan.order.length,3);assert.ok(plan.entries.every(p=>p.to.c>=5));assert.equal(executeGroupMove(s,plan).success,3);assert.ok(units.every(u=>!fortAt(s.map,u.c,u.r)));
});

for(const id of ['china_changping','china_qin_chu','china_seven_states','china_longxi'])test(`${id}: large real formations retain legality, population and individual action budgets`,async()=>{
 const {mapFor}=await import('../../tools/ai-training/maps.mjs');const s=startGame(mapFor(id));
 const units=s.map.units.filter(u=>u.hp>0&&u.team===s.side&&u.actionsLeft>0&&!u.aboard&&!['fort','defenseTower','captive','moraleGuard'].includes(u.kind)).slice(0,40),ids=units.map(u=>u.id);
 const count=s.map.units.length,before=new Map(units.map(u=>[u.id,{c:u.c,r:u.r,actions:u.actionsLeft}])),anchor=units[Math.floor(units.length/2)],target={c:Math.min(s.map.cols-1,anchor.c+3),r:anchor.r};
 const plan=planGroupMove(s,ids,target);const result=executeGroupMove(s,plan);assert.equal(s.map.units.length,count);assert.equal(result.success+result.failed,ids.length);
 const live=s.map.units.filter(u=>u.hp>0&&!u.aboard&&u.kind!=='fort');assert.equal(new Set(live.map(u=>`${u.c},${u.r}`)).size,live.length);
 for(const u of units){const old=before.get(u.id),entry=result.results.find(e=>e.id===u.id&&e.ok);assert.equal(u.actionsLeft,entry?(entry.riverMove?0:old.actions-1):old.actions);}
});
