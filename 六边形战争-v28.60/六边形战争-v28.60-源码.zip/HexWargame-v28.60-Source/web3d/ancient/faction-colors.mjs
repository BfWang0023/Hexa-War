// Local presentation preferences, never part of authoritative combat state.
export const DEFAULT_COLORS=Object.freeze({egypt:'#185675',coalition:'#9a4736'});
let colors={...DEFAULT_COLORS};
export function setFactionColors(value,storage=globalThis.localStorage){
 for(const team of Object.keys(DEFAULT_COLORS))if(/^#[0-9a-f]{6}$/i.test(value?.[team]||''))colors[team]=value[team].toLowerCase();
 try{storage?.setItem('ancient-faction-colors',JSON.stringify(colors));}catch{}
 return {...colors};
}
try{setFactionColors(JSON.parse(globalThis.localStorage?.getItem('ancient-faction-colors')||'{}'));}catch{}
export function factionColor(team){return colors[team]||DEFAULT_COLORS.egypt;}
