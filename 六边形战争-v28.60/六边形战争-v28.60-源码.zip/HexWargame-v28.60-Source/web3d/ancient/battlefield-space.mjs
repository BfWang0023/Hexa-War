import {planningState} from './fog-policy.mjs';
// Deterministic military space. Every enemy input must already be filtered by observer visibility.
import {neighbors,distance,visibleTo,inBounds,key} from './engine.mjs';
import {axial,offset,selectable} from './group-command.mjs';
export const plane=p=>({x:p.c+(p.r&1)*.5,z:p.r*Math.sqrt(3)/2});
export const centroid=xs=>xs.length?xs.reduce((a,p)=>{const v=plane(p);return {x:a.x+v.x/xs.length,z:a.z+v.z/xs.length}},{x:0,z:0}):{x:0,z:0};
export function hexFromPlane({x,z}){const r=z/(Math.sqrt(3)/2),q=x-r/2;let a=Math.round(q),b=Math.round(r),c=Math.round(-q-r);const da=Math.abs(a-q),db=Math.abs(b-r),dc=Math.abs(c+q+r);if(da>db&&da>dc)a=-b-c;else if(db>dc)b=-a-c;return offset({q:a,r:b});}
export const vectorFor=heading=>{const a=plane({c:0,r:0}),b=plane(neighbors(0,0)[heading]);return {x:b.x-a.x,z:b.z-a.z};};
export function makeFrame(units,heading){return {origin:centroid(units),heading,forward:vectorFor(heading)};}
export const oppositeFrame=(frame,units)=>makeFrame(units,(frame.heading+3)%6);
export function facingToward(units,targets,fallback){if(!units.length||!targets.length)return makeFrame(units,fallback);const a=centroid(units),b=centroid(targets),scores=Array.from({length:6},(_,h)=>{const v=vectorFor(h);return v.x*(b.x-a.x)+v.z*(b.z-a.z)});return makeFrame(units,Math.max(...scores)<.01?fallback:scores.indexOf(Math.max(...scores)));}
export function projection(p,frame){const v=plane(p),x=v.x-frame.origin.x,z=v.z-frame.origin.z;return {front:x*frame.forward.x+z*frame.forward.z,left:x*frame.forward.z-z*frame.forward.x};}
export function knownArmies(state,team){state=planningState(state,team);const own=state.map.units.filter(u=>selectable(u,team)),enemy=state.map.units.filter(u=>u.team!==team&&u.hp>0&&!u.aboard&&u.kind!=='fort'&&visibleTo(state,team,u.c,u.r));return {own,enemy};}
export function battlefronts(units,baseFrame,opponents=[],link=4){
 // Spatial buckets bound work for large armies; singleton commanders do not create extra battlefronts.
 const buckets=new Map(),left=new Set(units),groups=[];for(const u of units){const p=plane(u),k=Math.floor(p.x/link)+','+Math.floor(p.z/link);if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(u);}
 for(const seed of units){if(!left.delete(seed))continue;const xs=[seed];for(let i=0;i<xs.length;i++){const p=plane(xs[i]),bx=Math.floor(p.x/link),bz=Math.floor(p.z/link);for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)for(const u of buckets.get((bx+dx)+','+(bz+dz))||[])if(left.has(u)&&distance(xs[i],u)<=link){left.delete(u);xs.push(u);}}
  groups.push(xs);
 }
 const significant=groups.filter(xs=>xs.length>=2),result=(significant.length?significant:groups).map(xs=>{const a=centroid(xs),near=opponents.length?[...opponents].sort((u,v)=>{const p=plane(u),q=plane(v);return (p.x-a.x)**2+(p.z-a.z)**2-(q.x-a.x)**2-(q.z-a.z)**2}).slice(0,Math.max(2,Math.ceil(opponents.length/4))):[];return {units:xs,frame:facingToward(xs,near,baseFrame.heading)};});
 result.sort((a,b)=>projection(hexFromPlane(b.frame.origin),baseFrame).left-projection(hexFromPlane(a.frame.origin),baseFrame).left||a.frame.origin.x-b.frame.origin.x);
 return result.map((g,i)=>({...g,id:i+1}));
}
export function selectSpatial(pool,selector,frame,opponents=[]){
 let candidates=pool,active=frame;
 if(selector.front){const group=battlefronts(pool,frame,opponents)[selector.front-1];if(!group)return [];candidates=group.units;active=group.frame;}
 const vectors=candidates.map(u=>({u,...projection(u,active)}));let ids=null;
 const constrain=(sortKey,part)=>{const sorted=[...vectors].sort((a,b)=>a[sortKey]-b[sortKey]||a.u.id.localeCompare(b.u.id)),n=Math.max(1,Math.ceil(sorted.length/3));const chosen=part==='high'?sorted.slice(-n):part==='middle'?sorted.slice(Math.floor((sorted.length-n)/2),Math.floor((sorted.length-n)/2)+n):sorted.slice(0,n),set=new Set(chosen.map(p=>p.u.id));ids=ids?new Set([...ids].filter(id=>set.has(id))):set;};
 if(selector.wing)constrain('left',selector.wing==='left'?'high':selector.wing==='center'?'middle':'low');
 if(selector.zone)constrain('front',selector.zone==='front'?'high':'low');
 if(selector.rank){const rows=[...new Set(vectors.map(p=>Math.round(p.front*2)))].sort((a,b)=>b-a),row=rows[selector.rank-1],set=new Set(vectors.filter(p=>Math.round(p.front*2)===row).map(p=>p.u.id));ids=ids?new Set([...ids].filter(id=>set.has(id))):set;}
 return candidates.filter(u=>!ids||ids.has(u.id));
}
export function offsetRegion(point,frame,relation='center',steps=0){if(!steps||relation==='center')return {...point};const heading=({front:frame.heading,rear:(frame.heading+3)%6,left:(frame.heading+2)%6,right:(frame.heading+5)%6})[relation];let p={...point};for(let n=0;n<steps;n++)p=neighbors(p.c,p.r)[heading];return p;}
export function around(p,radius){const xs=[];for(let r=p.r-radius;r<=p.r+radius;r++)for(let c=p.c-radius-1;c<=p.c+radius+1;c++){const v={c,r};if(distance(p,v)<=radius)xs.push(v);}return xs.sort((a,b)=>distance(a,p)-distance(b,p)||a.r-b.r||a.c-b.c);}
