import * as T from '../vendor/three/three.module.js';

const textures=new Map();
function hash(x,y){
  return (Math.imul(x+97,19349663)^Math.imul(y+257,83492791))>>>0;
}
// Authored tile for the Morannon: broad iron plates, offset seams, pitted
// charcoal, and oxidized rivets. This map is used on the rendered gate itself.
export function blackGateTexture(iron=false){
  if(textures.has(iron))return textures.get(iron);
  const size=128,bytes=new Uint8Array(size*size*4);
  const plate=iron?32:22;
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const row=Math.floor(y/plate), px=(x+(row%2)*16)%32, py=y%plate;
    const seam=px<2||py<2, edge=px===2||py===2;
    const d=Math.hypot(px-5,py-6),rivet=iron&&d<2.6;
    const base=(iron?56:47)+(hash(Math.floor(x/3),Math.floor(y/3))%17)-8+
      (hash(x,y)%11)-5+(row%3)*4;
    const shade=rivet?base+(py<6?46:19):seam?base-24:edge?base+14:base;
    const i=(y*size+x)*4;
    bytes[i]=Math.max(0,shade+(iron?3:7));
    bytes[i+1]=Math.max(0,shade);
    bytes[i+2]=Math.max(0,shade+(iron?6:-2));
    bytes[i+3]=255;
  }
  const map=new T.DataTexture(bytes,size,size);
  map.colorSpace=T.SRGBColorSpace;map.wrapS=map.wrapT=T.RepeatWrapping;
  map.magFilter=T.LinearFilter;map.minFilter=T.LinearMipmapLinearFilter;
  map.generateMipmaps=true;map.needsUpdate=true;
  textures.set(iron,map);
  return map;
}
