import {makeMoreClassicalMap} from './classical-expansion-maps.mjs';
import {TERRAIN as T,newMap,index,neighbors,distance,addUnit,mobileAt,setFort,setHouse,validateMap} from './engine.mjs';
import {classicalInfo} from './classical-data.mjs';
function base(id,cols,rows,turnLimit){const m=newMap(cols,rows),info=classicalInfo(id);m.scenarioId=id;m.name=info.name;m.factions={egypt:info.factions[0],coalition:info.factions[1]};m.unitNames={greekHoplite:'希腊重装步兵',phalangite:'马其顿长枪方阵',companionCavalry:'马其顿骑兵',light:'轻装步兵',archer:'弓箭手',heavy:'波斯持盾步兵',guard:'波斯精锐步兵',cavalry:'骑兵','egypt:athenianTrireme':'雅典三列桨分舰队','coalition:phoenicianTrireme':'叙拉古与盟邦分舰队'};m.victory={mode:'classical',variant:id,losses:{egypt:1,coalition:1},turnLimit};m.intro=(`${info.name}：${info.deployment}地形与兵数为史料约束下的战术缩放；帮助页列出采用数字与争议。`).slice(0,200);return m;}
const paint=(m,c,r,t)=>{m.terrain[index(m,c,r)]=t;};
function terrain(m,fn){for(let r=0;r<m.rows;r++)for(let c=0;c<m.cols;c++)paint(m,c,r,fn(c,r));}
function route(m,points,type=T.ROAD){for(let i=1;i<points.length;i++){let p={c:points[i-1][0],r:points[i-1][1]},to={c:points[i][0],r:points[i][1]};for(let n=0;n<m.cols+m.rows;n++){paint(m,p.c,p.r,m.terrain[index(m,p.c,p.r)]|type);if(distance(p,to)===0)break;p=neighbors(p.c,p.r).filter(q=>q.c>=0&&q.r>=0&&q.c<m.cols&&q.r<m.rows).sort((a,b)=>distance(a,to)-distance(b,to))[0];}}}
function put(m,team,kind,c,r,name,facing=team==='egypt'?0:3){if(mobileAt(m,c,r)||!addUnit(m,kind,team,c,r))throw Error(`${m.scenarioId}: 部署失败 ${kind} ${c},${r}`);const u=mobileAt(m,c,r);u.formation=name;if(['greekHoplite','phalangite','athenianTrireme','phoenicianTrireme'].includes(kind))u.facing=facing;return u;}
function block(m,team,kind,c,r,count,width,name,dc=1,dr=2,facing){for(let i=0;i<count;i++)put(m,team,kind,c+(i%width)*dc,r+Math.floor(i/width)*dr,name,facing);}
const mark=(m,c,r,label)=>m.landmarks.push({c,r,label});
function finish(m){validateMap(m);return m;}
export function marathonMap(){
 const m=base('marathon',64,40,24);
 terrain(m,(c,r)=>c>=58?T.SEA:c===57?T.BEACH:c<9||r>35&&c<25?T.MOUNTAIN:c>=47&&r<9?((c+r)%3?T.RIVER:T.RIVER|T.ROAD):T.PLAIN);
 route(m,[[3,28],[15,25],[29,25]]);
 block(m,'egypt','greekHoplite',23,8,2,2,'普拉提亚左翼');block(m,'egypt','greekHoplite',23,10,6,2,'雅典左翼');block(m,'egypt','greekHoplite',24,17,4,1,'较薄的雅典中军');block(m,'egypt','greekHoplite',23,25,8,2,'雅典右翼');
 block(m,'coalition','light',39,8,10,2,'波斯北翼');block(m,'coalition','heavy',39,18,8,4,'波斯与萨迦中军');block(m,'coalition','guard',41,22,4,4,'波斯精锐');block(m,'coalition','light',39,26,10,2,'波斯南翼');block(m,'coalition','archer',44,12,8,2,'波斯弓手');
 mobileAt(m,23,10).customName='米太亚得所属部队';mark(m,51,5,'大沼泽（浅水示意）');mark(m,60,21,'马拉松海湾');mark(m,8,25,'通往雅典的山麓道路');return finish(m);
}
export function thermopylaeMap(){
 const m=base('thermopylae',68,38,18);m.victory.capture={team:'coalition',c:59,r:11,name:'通向希腊腹地的关后出口'};m.victory.holdWinner='egypt';
 terrain(m,(c,r)=>r<8?T.SEA:r===8?T.BEACH:r>=14?T.MOUNTAIN:c>=30&&c<=40&&r>=12?T.MOUNTAIN:T.PLAIN);
 route(m,[[0,10],[67,10]]);route(m,[[16,12],[20,20],[22,28],[46,28],[53,20],[53,11]]);
 for(const r of [9,11])setFort(m,36,r,1,'egypt','佛基斯旧墙');
 block(m,'egypt','greekHoplite',37,9,12,4,'关隘主防线',1,1,3);block(m,'egypt','greekHoplite',42,9,8,4,'希腊盟军预备队',1,1,3);block(m,'egypt','greekHoplite',47,23,4,2,'佛基斯山路守军',1,2,3);block(m,'egypt','greekHoplite',46,11,4,2,'忒斯庇亚与底比斯分队',1,2,3);
 mobileAt(m,37,9).customName='列奥尼达斯与斯巴达三百人';
 block(m,'coalition','light',12,9,24,6,'正面进攻梯队',1,1,0);block(m,'coalition','heavy',20,9,12,4,'波斯持盾步兵',1,1,0);block(m,'coalition','archer',4,9,12,4,'波斯弓手',1,1,0);block(m,'coalition','guard',13,21,12,4,'希达尔涅斯迂回分队',1,2,0);
 mark(m,37,7,'马利亚湾古海岸');mark(m,36,13,'温泉关中门');mark(m,33,28,'阿诺帕亚山路');mark(m,49,23,'佛基斯警戒线');mark(m,59,11,'关后出口（波斯目标）');return finish(m);
}
export function plataeaMap(){
 const m=base('plataea',72,44,28);
 terrain(m,(c,r)=>r>=37?T.MOUNTAIN:r===9?T.RIVER:T.PLAIN);route(m,[[12,43],[18,32],[23,26]]);route(m,[[45,43],[46,28]]);for(const c of [18,36,55])paint(m,c,9,T.RIVER|T.ROAD);
 for(let c=28;c<=40;c++)if(c!==34)setFort(m,c,5,1,'coalition','波斯木栅营垒');
 block(m,'egypt','greekHoplite',9,27,8,4,'雅典左翼',1,2,1);block(m,'egypt','greekHoplite',22,27,20,10,'希腊盟军中军',1,2,1);block(m,'egypt','greekHoplite',39,27,2,2,'特该亚分队',1,2,1);block(m,'egypt','greekHoplite',44,27,10,5,'斯巴达与拉栖代梦右翼',1,2,1);block(m,'egypt','light',17,32,8,4,'辅助轻兵',2,2,1);
 block(m,'coalition','greekHoplite',10,17,8,4,'亲波斯希腊盟军',1,2,4);block(m,'coalition','light',23,17,28,7,'波斯诸族步兵',1,2,4);block(m,'coalition','heavy',44,17,8,4,'波斯主力',1,2,4);block(m,'coalition','archer',40,12,12,6,'波斯弓手',1,2,4);block(m,'coalition','cavalry',35,24,4,4,'波斯骑兵',2,1,4);
 mobileAt(m,44,27).customName='保萨尼阿斯所属部队';mobileAt(m,44,17).customName='马尔多尼奥斯所属部队';mark(m,6,9,'阿索波斯河');mark(m,34,4,'波斯营垒');mark(m,49,34,'加尔加菲亚泉附近');mark(m,30,40,'基泰隆山麓');mark(m,8,32,'普拉提亚方向');return finish(m);
}
export function sphacteriaMap(){
 const m=base('sphacteria',48,38,16);m.victory.holdWinner='coalition';
 terrain(m,(c,r)=>c<17||c>29||r<3||r>34?T.SEA:c===17||c===29||r===3||r===34?T.BEACH:r<11||c===18&&r<28?T.MOUNTAIN:T.PLAIN);
 // Broken coastal rocks leave both a central approach and a slower side route.
 for(const [c,r] of [[23,6],[24,6],[25,6]])setFort(m,c,r,1,'coalition','北端旧石垒');
 put(m,'coalition','greekHoplite',23,28,'南端前哨',4);block(m,'coalition','greekHoplite',22,16,5,2,'埃皮塔达斯中央主力',1,2,4);block(m,'coalition','greekHoplite',23,7,2,2,'北端石垒守军',1,2,4);mobileAt(m,22,16).customName='埃皮塔达斯所属部队';
 block(m,'egypt','greekHoplite',20,30,16,8,'雅典两岸登陆重步兵',1,1,1);block(m,'egypt','archer',19,23,8,2,'雅典弓手',8,2,1);block(m,'egypt','light',19,14,8,2,'轻盾兵与美塞尼亚分队',8,2,1);
 mark(m,12,20,'西侧外海');mark(m,35,19,'皮洛斯湾');mark(m,24,5,'北端陡坡与旧石垒');mark(m,24,15,'中央平地与水源');mark(m,24,33,'雅典登陆区');return finish(m);
}
export function leuctraMap(){
 const m=base('leuctra',68,40,26);terrain(m,(c,r)=>r<4||r>35||c>=58?T.MOUNTAIN:T.PLAIN);
 block(m,'egypt','greekHoplite',26,7,16,4,'底比斯左翼纵深集团',1,2,0);block(m,'egypt','greekHoplite',22,22,8,2,'后撤的中军与右翼',1,3,0);block(m,'egypt','cavalry',32,7,4,1,'底比斯前出骑兵',1,5,0);mobileAt(m,29,7).customName='佩洛皮达斯与圣队';mobileAt(m,28,9).customName='伊巴密浓达所属部队';
 block(m,'coalition','greekHoplite',42,7,10,2,'斯巴达右翼精锐',1,2,3);block(m,'coalition','greekHoplite',42,18,30,5,'伯罗奔尼撒盟军中左翼',1,3,3);block(m,'coalition','cavalry',38,7,4,1,'斯巴达前出骑兵',1,5,3);mobileAt(m,42,7).customName='克里奥姆布罗托斯所属部队';
 mark(m,23,6,'底比斯左翼：纵深集中');mark(m,44,5,'斯巴达右翼');mark(m,34,21,'留克特拉平原');mark(m,61,20,'坡地营地');return finish(m);
}
export function chaeroneaMap(){
 const m=base('chaeronea',72,42,26);terrain(m,(c,r)=>r===5?T.RIVER:r<3||r>36?T.MOUNTAIN:T.PLAIN);for(const c of [14,37,58])paint(m,c,5,T.RIVER|T.ROAD);
 route(m,[[2,33],[21,32],[48,32],[68,32]]);
 block(m,'egypt','phalangite',24,11,24,3,'马其顿方阵战线',1,3,0);block(m,'egypt','light',19,9,6,1,'马其顿轻装掩护',1,5,0);put(m,'egypt','companionCavalry',25,7,'亚历山大左翼',0).customName='亚历山大与左翼骑兵';put(m,'egypt','companionCavalry',21,34,'右翼骑兵预备队',0);mobileAt(m,26,32).customName='腓力二世所属方阵';
 block(m,'coalition','greekHoplite',43,10,10,2,'底比斯右翼',1,2,3);block(m,'coalition','greekHoplite',43,21,8,2,'希腊盟军中军',1,2,3);block(m,'coalition','greekHoplite',43,30,10,5,'雅典左翼',1,2,3);block(m,'coalition','light',49,15,4,1,'城邦轻装预备队',1,5,3);mobileAt(m,43,10).customName='底比斯圣队三百人';
 for(const [c,r] of [[48,35],[50,35],[52,35]])setHouse(m,c,r);mark(m,35,5,'刻菲索斯河');mark(m,51,36,'喀罗尼亚城');mark(m,25,6,'马其顿左翼');mark(m,43,8,'底比斯右翼与圣队');mark(m,42,35,'雅典左翼');return finish(m);
}
export function sicily413Map(){
 const m=base('sicily_413',76,50,24);m.victory.holdWinner='coalition';m.victory.escape=[{team:'egypt',ships:true,cMin:70,cMax:75,rMin:29,rMax:40,needed:8},{team:'egypt',ships:false,cMin:0,cMax:3,rMin:18,rMax:31,needed:10}];
 terrain(m,(c,r)=>c>=67&&r>=23||c>=35&&r>=28&&r<=43?T.SEA:c>=35&&r===27?T.BEACH:r<12&&c<49?T.MOUNTAIN:T.PLAIN);
 // Plemmyrium peninsula is land south of the harbour, not a bridge across it.
 for(let c=52;c<67;c++)for(let r=44;r<50;r++)paint(m,c,r,T.PLAIN);
 route(m,[[0,24],[17,24],[32,24]]);route(m,[[0,35],[34,35]],T.RIVER);for(const c of [12,24])paint(m,c,35,T.RIVER|T.ROAD);
 for(let r=12;r<=25;r++)if(r!==20)setFort(m,51,r,2,'coalition','叙拉古城防');for(let c=52;c<=62;c++)setFort(m,c,25,2,'coalition','阿克拉迪纳南墙');
 for(const [c,r] of [[54,16],[57,18],[60,20]])setHouse(m,c,r);
 for(let r=26;r<=31;r++)if(r!==28)setFort(m,32,r,1,'egypt','雅典营地木栅');
 block(m,'egypt','greekHoplite',27,23,20,4,'雅典营地重步兵',1,2,0);block(m,'egypt','archer',24,25,4,1,'营地弓手',1,2,0);block(m,'egypt','light',21,24,4,1,'雅典撤退掩护队',1,2,3);mobileAt(m,27,23).customName='尼基阿斯所属部队';
 block(m,'coalition','greekHoplite',42,17,12,3,'吉利普斯与盟军',1,2,3);block(m,'coalition','greekHoplite',31,39,4,2,'奥林匹亚神庙分队',-2,2,3);
 block(m,'coalition','archer',46,18,4,1,'叙拉古弓手',1,2,3);block(m,'coalition','cavalry',20,39,4,2,'叙拉古骑兵封锁队',3,2,3);
 block(m,'egypt','athenianTrireme',37,30,17,4,'雅典大港舰队',3,3,0);block(m,'coalition','phoenicianTrireme',57,29,15,3,'叙拉古封口舰队',3,3,3);mobileAt(m,37,30).commander='德摩斯梯尼';mobileAt(m,57,29).commander='叙拉古舰队司令';
 mark(m,22,8,'厄庇波莱高地');mark(m,58,15,'叙拉古与奥提伽方向');mark(m,27,22,'雅典营地');mark(m,15,35,'阿纳波斯河与涉渡点');mark(m,59,46,'普莱米里翁岬');mark(m,47,42,'大港');mark(m,72,33,'东侧海上撤离区');mark(m,2,24,'西侧陆上撤离区');return finish(m);
}
const makers={marathon:marathonMap,thermopylae:thermopylaeMap,plataea:plataeaMap,sphacteria:sphacteriaMap,leuctra:leuctraMap,chaeronea:chaeroneaMap,sicily_413:sicily413Map};
export function makeClassicalMap(id){if(makers[id])return makers[id]();const m=makeMoreClassicalMap(id);if(m)return m;throw Error('未知希腊战役 '+id);}
