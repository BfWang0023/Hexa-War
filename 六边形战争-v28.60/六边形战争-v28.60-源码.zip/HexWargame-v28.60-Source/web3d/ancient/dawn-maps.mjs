import * as E from './engine.mjs';import {DAWN_CAMPAIGNS} from './dawn-data.mjs';
export function makeDawnMap(id){const info=DAWN_CAMPAIGNS.find(c=>c.id===id);if(!info)throw Error('未知曙光战役');const m=E.newMap(20,14),T=E.TERRAIN;m.scenarioId=id;m.name=info.name;m.factions={egypt:info.factions[0],coalition:info.factions[1]};m.intro=`入门·${info.lesson}。${info.note}双方击溃敌方75%获胜；20回合后比较损失比例。`;m.unitNames={light:'青铜时代轻步兵',heavy:'青铜时代持盾步兵',archer:'青铜时代弓手',warship:'早期桨帆战船'};m.victory={mode:'classical',variant:id,turnLimit:20,losses:{egypt:1,coalition:1}};
const paint=(c,r,t)=>E.setTerrain(m,c,r,t),put=(kind,team,c,r)=>{if(!E.addUnit(m,kind,team,c,r))throw Error(`部署失败${id}:${c},${r}`);};
if(id==='dawn_delta'){
 for(let r=0;r<14;r++)for(let c=0;c<20;c++)paint(c,r,r<3||r>10?T.PLAIN:T.SEA);
 for(const [c,r]of [[4,5],[4,7],[6,8]])put('warship','egypt',c,r);for(const [c,r]of [[14,5],[14,7],[16,8]])put('warship','coalition',c,r);put('archer','egypt',8,2);put('archer','coalition',12,11);
}else{
 if(['dawn_zhuolu','dawn_babylon'].includes(id))for(let r=0;r<14;r++)for(let c=8;c<=11;c++)if(r<5||r>8)paint(c,r,T.MOUNTAIN);
 if(['dawn_sanmiao','dawn_larsa'].includes(id)){for(let r=0;r<14;r++)for(let c=9;c<=10;c++)paint(c,r,T.RIVER);for(const c of [9,10]){paint(c,7,T.RIVER|T.ROAD);if(id==='dawn_larsa')E.setBridge(m,c,7);}}
 for(const [kind,c,r]of [['light',3,5],['light',4,8],['heavy',5,6],['archer',3,7]])put(kind,'egypt',c,r);
 for(const [kind,c,r]of [['light',15,5],['light',16,8],['heavy',14,6],['archer',16,7]])put(kind,'coalition',c,r);
 if(['dawn_ur','dawn_larsa'].includes(id)){for(const r of [4,5,6,8,9])E.setFort(m,13,r,1,'coalition','城防');E.setFort(m,13,7,1,'coalition','城防');const gate=E.fortAt(m,13,7);gate.gate=true;gate.hp=Math.round(E.FORT_HP[1]*.7);paint(12,7,T.ROAD);paint(13,7,T.ROAD);paint(14,7,T.ROAD);m.gateRules=1;}
}
for(const team of ['egypt','coalition'])m.victory.losses[team]=Math.ceil(m.units.filter(u=>u.team===team&&u.kind!=='fort').length*.75);E.validateMap(m);return E.importMap(E.exportMap(m));}
