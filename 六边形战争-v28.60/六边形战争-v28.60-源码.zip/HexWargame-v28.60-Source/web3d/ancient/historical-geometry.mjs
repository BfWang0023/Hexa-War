import * as T from '../vendor/three/three.module.js';
// Authored cross sections, not downloaded meshes. Ring topology stays continuous
// across shoulders/necks and gives every silhouette an explicit profile.
export function loft(parent,material,rings,{axis='x',sides=12,name=''}={}){
 const positions=[],uv=[],indices=[];
 for(let i=0;i<rings.length;i++){const [x,y,z,a,b]=rings[i];for(let j=0;j<=sides;j++){const t=j/sides*Math.PI*2,c=Math.cos(t),s=Math.sin(t);positions.push(axis==='x'?x:x+a*c,axis==='x'?y+a*c:y,axis==='x'?z+b*s:z+b*s);uv.push(j/sides,i/(rings.length-1));}}
 for(let i=0;i<rings.length-1;i++)for(let j=0;j<sides;j++){const a=i*(sides+1)+j,b=a+sides+1;indices.push(a,a+1,b,b,a+1,b+1);}
 for(const end of [0,rings.length-1]){const center=positions.length/3;positions.push(...rings[end].slice(0,3));uv.push(.5,.5);for(let j=0;j<sides;j++){const a=end*(sides+1)+j;indices.push(center,...(end===0?[a+1,a]:[a,a+1]));}}
 // Y rings need reversed winding; X rings already face outward.
 if(axis==='y')for(let i=0;i<indices.length;i+=3)[indices[i+1],indices[i+2]]=[indices[i+2],indices[i+1]];
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.setIndex(indices);geo.computeVertexNormals();const m=new T.Mesh(geo,material);m.name=name;parent.add(m);return m;
}
export function sweep(parent,material,points,radii,{sides=8,steps=24,name=''}={}){
 const curve=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p))),frames=curve.computeFrenetFrames(steps,false),vertices=[],uv=[],indices=[];
 for(let i=0;i<=steps;i++){const t=i/steps,p=curve.getPointAt(t),f=t*(radii.length-1),k=Math.min(radii.length-2,Math.floor(f)),r=T.MathUtils.lerp(radii[k],radii[k+1],f-k);for(let j=0;j<=sides;j++){const a=j/sides*Math.PI*2,v=p.clone().addScaledVector(frames.normals[i],r*Math.cos(a)).addScaledVector(frames.binormals[i],r*Math.sin(a));vertices.push(...v.toArray());uv.push(j/sides,t);}}
 for(let i=0;i<steps;i++)for(let j=0;j<sides;j++){const a=i*(sides+1)+j,b=a+sides+1;indices.push(a,b,a+1,b,b+1,a+1);}
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(vertices,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.setIndex(indices);geo.computeVertexNormals();const m=new T.Mesh(geo,material);m.name=name;parent.add(m);return m;
}
export function panel(parent,material,points,depth=.04){const s=new T.Shape();points.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();const geo=new T.ExtrudeGeometry(s,{depth,bevelEnabled:false});const m=new T.Mesh(geo,material);parent.add(m);return m;}
export function cloth(parent,material,rows){const pos=[],uv=[],idx=[];for(let i=0;i<rows.length;i++)for(let j=0;j<rows[i].length;j++){pos.push(...rows[i][j]);uv.push(j/(rows[i].length-1),i/(rows.length-1));}const w=rows[0].length;for(let i=0;i<rows.length-1;i++)for(let j=0;j<w-1;j++){const a=i*w+j;idx.push(a,a+w,a+1,a+1,a+w,a+w+1);}
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.setIndex(idx);geo.computeVertexNormals();const mesh=new T.Mesh(geo,material);parent.add(mesh);return mesh;
}
