import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {CLIFF_RULES,culvertBanks,groundCell,groundConnection,groundStand} from './cliff-navigation.mjs';
import {makeMiddleEarthMap} from './middle-earth-maps.mjs';
import {createSave,restoreSave} from './save.mjs';
import {sealCulvert} from './middle-earth-rules.mjs';
import {createTerrainRefresh} from './terrain-refresh.mjs';

const a={c:4,r:4},b={c:5,r:4};
const foot={kind:'meRohanFoot'},horse={kind:'meRohan'},cart={kind:'meBlast'},air={kind:'meEagle'};
function fixture(){
  const m=E.newMap(12,10);
  m.scenarioId='me_hornburg';
  m.elevations=Array(m.cols*m.rows).fill(0);
  m.victory={mode:'middle-earth',layoutVersion:6,turnLimit:24,
    points:{core:{c:2,r:5},cave:{c:2,r:7},counter:{c:10,r:5},culvert:{c:9,r:7},blast:{c:9,r:8}},waves:[]};
  return m;
}
const level=(m,p,h)=>m.elevations[E.index(m,p.c,p.r)]=h;
const neighbors=(m,p)=>E.neighbors(p.c,p.r).filter(q=>E.inBounds(m,q.c,q.r));
const show=(m,c,r)=>groundCell(m,c,r).center.y;
const walk=(m,u,x,y)=>groundConnection(m,u,x,y)==='';

test('A/E/F: only geometry changes the cliff edge; a wider mounted frontage can fail on a walkable grade',()=>{
  const m=fixture();
  level(m,b,.5);
  assert.ok(walk(m,foot,a,b));
  level(m,b,8);
  assert.ok(E.setTerrain(m,b.c,b.r,E.TERRAIN.ROAD));
  assert.equal(show(m,b.c,b.r),8*CLIFF_RULES.metresPerLevel);
  assert.equal(walk(m,foot,a,b),false);
  assert.equal(walk(m,foot,b,a),false);
  level(m,b,1.35);
  assert.ok(walk(m,foot,a,b));
  assert.equal(walk(m,horse,a,b),false);
  assert.equal(walk(m,cart,a,b),false);
  level(m,b,0);
  assert.ok(walk(m,horse,a,b));
  assert.ok(walk(m,cart,a,b));
});

test('B/C/D: equal anchors can be separated by a steep edge; along-cliff links stay on the anchored platform',()=>{
  const m=fixture();
  const common=neighbors(m,a).filter(p=>E.distance(p,b)===1);
  for(const p of common)level(m,p,9);
  assert.equal(show(m,a.c,a.r),show(m,b.c,b.r));
  assert.equal(walk(m,foot,a,b),false);
  assert.ok(walk(m,air,a,b));
  const c={c:3,r:4},d={c:2,r:4};
  E.setTerrain(m,a.c,a.r,E.TERRAIN.ROAD);
  E.setTerrain(m,c.c,c.r,E.TERRAIN.ROAD);
  E.setTerrain(m,d.c,d.r,E.TERRAIN.ROAD);
  assert.ok(walk(m,foot,a,c));
  assert.ok(walk(m,foot,c,d));
  assert.equal(walk(m,foot,a,common[0]),false);
  assert.ok(groundStand(m,foot,a.c,a.r));
});

test('G: bridge deck uses its road approaches, culvert only its two mouths, gate allows friendly passage',()=>{
  const m=fixture();
  const left={c:3,r:4};
  for(const p of [left,b])E.setTerrain(m,p.c,p.r,E.TERRAIN.ROAD);
  E.setTerrain(m,a.c,a.r,E.TERRAIN.RIVER|E.TERRAIN.ROAD);
  assert.ok(E.setBridge(m,a.c,a.r));
  assert.ok(walk(m,horse,left,a)&&walk(m,horse,a,b));
  assert.equal(walk(m,horse,a,{c:4,r:3}),false);
  level(m,b,9);
  assert.equal(walk(m,foot,a,b),false);

  const h=makeMiddleEarthMap('me_hornburg'),p=h.victory.points;
  const s=E.startGame(h,{middleEarthSeed:17});
  const [west,east]=culvertBanks(h);
  assert.ok(walk(h,foot,west,p.culvert)&&walk(h,foot,p.culvert,east));
  assert.equal(walk(h,foot,p.culvert,{c:26,r:23}),false);
  const aragorn=s.map.units.find(u=>u.kind==='meAragorn');
  assert.ok(E.move(s,aragorn.id,p.gate.c,p.gate.r).ok);
  assert.ok(E.move(s,aragorn.id,28,16).ok);
  const nearby=s.map.units.find(u=>u.kind==='meRohanFoot'&&u.r===21);
  assert.ok(E.move(s,nearby.id,west.c,west.r).ok);
  assert.ok(sealCulvert(s));
  assert.equal(E.reachable(s,nearby).has(E.key(p.culvert.c,p.culvert.r)),false);
});

test('H/I/J: true preview and execution reject a cliff, melee requires contact and saved geometry rebuilds',()=>{
  const m=fixture();
  for(const p of neighbors(m,a).filter(p=>E.distance(p,b)===1))level(m,p,9);
  assert.ok(E.addUnit(m,foot.kind,'egypt',a.c,a.r));
  assert.ok(E.addUnit(m,'meUruk','coalition',b.c,b.r));
  const s=E.startGame(m,{middleEarthSeed:17,fogPolicy:{terrainFog:false,unitFog:false}});
  const u=s.map.units.find(x=>x.team==='egypt');
  assert.equal(E.attackPreview(s,u,b.c,b.r),null);
  assert.equal(E.move(s,u.id,b.c,b.r).ok,false);
  for(const p of neighbors(m,a).filter(p=>E.distance(p,b)===1))level(s.map,p,0);
  E.recomputeFog(s);
  assert.ok(E.attackPreview(s,u,b.c,b.r)?.melee);
  const enemy=s.map.units.find(x=>x.team==='coalition');
  enemy.hp=0;
  E.recomputeFog(s);
  assert.equal(E.reachable(s,u).get(E.key(b.c,b.r)).cost,1);
  level(s.map,b,9);
  assert.equal(E.move(s,u.id,b.c,b.r).ok,false);

  const loaded=restoreSave(JSON.parse(JSON.stringify(createSave(m,s,'egypt')))).game;
  const v=loaded.map.units.find(x=>x.id===u.id);
  assert.equal(E.move(loaded,v.id,b.c,b.r).ok,false);
  assert.equal(groundStand(loaded.map,horse,b.c,b.r),false);
  assert.equal(E.addUnit(loaded.map,horse.kind,'egypt',b.c,b.r),false);
  assert.ok(E.addUnit(loaded.map,air.kind,'egypt',b.c,b.r));

  const visual=createTerrainRefresh(8);
  visual.refresh(loaded.map);
  assert.ok(Math.abs(visual.height(b.c,b.r)-show(loaded.map,b.c,b.r))<1e-5);
  level(loaded.map,b,0);
  assert.ok(visual.refresh(loaded.map).terrainChunks.length>0);
  assert.equal(visual.height(b.c,b.r),0);
  visual.dispose();
});

test('Deeping Wall is level 3 and ordinary attacks cannot open it; delayed blast damages both sides',()=>{
  const map=makeMiddleEarthMap('me_hornburg',{largeArmies:false}),p=map.victory.points.blast;
  const pieces=map.units.filter(u=>u.cityId==='深谷墙'&&!u.gate);
  assert.ok(pieces.length&&pieces.every(f=>f.level===3));
  const device=map.units.find(u=>u.kind==='meBlast');
  map.units=map.units.filter(u=>u!==device);
  assert.ok(E.addUnit(map,'meBlast','coalition',28,22));
  assert.ok(E.addUnit(map,'meGrond','coalition',28,23));
  assert.ok(E.addUnit(map,'meRohanFoot','egypt',p.c,p.r));
  assert.ok(E.addUnit(map,'meRohanFoot','egypt',25,23));
  assert.ok(E.addUnit(map,'meRohanFoot','egypt',24,23));
  assert.ok(E.addUnit(map,'meEagle','egypt',p.c,p.r));
  const initial=E.startGame(map,{middleEarthSeed:17,fogPolicy:{terrainFog:false,unitFog:false}});
  E.endSide(initial);
  const wall=E.fortAt(initial.map,p.c,p.r),ram=initial.map.units.find(u=>u.kind==='meGrond');
  assert.ok(initial.middleEarth.events['blast-ready']);
  wall.hp=11;
  initial.middleEarth.preferredTarget=wall.id;
  const attack=E.attack(initial,ram.id,p.c,p.r,0,.5,.8,.9);
  delete initial.middleEarth.preferredTarget;
  assert.equal(attack.fortDamage,10);
  assert.equal(wall.hp,1);

  const s=restoreSave(JSON.parse(JSON.stringify(createSave(map,initial,'egypt')))).game;
  const targets=s.map.units.filter(u=>u.kind!=='fort'&&u.kind!=='meBlast');
  const garrison=targets.find(u=>u.kind==='meRohanFoot'&&E.distance(u,p)===0);
  const near=targets.find(u=>u.kind==='meGrond');
  const outer=targets.find(u=>u.c===25&&u.r===23);
  const far=targets.find(u=>u.c===24&&u.r===23);
  const eagle=targets.find(u=>u.kind==='meEagle');
  const blast=s.map.units.find(u=>u.kind==='meBlast');
  E.endSide(s);
  assert.ok(E.fortAt(s.map,p.c,p.r));
  const hp=[garrison,near,outer,far,eagle].map(u=>u.hp);
  E.endSide(s);
  assert.ok(s.middleEarth.events.breach);
  assert.equal(E.fortAt(s.map,p.c,p.r),null);
  assert.equal(blast.escaped,true);
  assert.deepEqual([garrison,near,outer,far,eagle].map((u,i)=>hp[i]-u.hp),[90,60,30,0,0]);
  assert.ok(s.map.units.filter(u=>u.cityId==='深谷墙'&&!u.gate&&u.id!==wall.id).every(u=>u.hp>0));
});
