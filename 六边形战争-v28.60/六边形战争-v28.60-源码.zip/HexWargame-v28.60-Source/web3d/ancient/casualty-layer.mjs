// Static authored bodies instanced by appearance/pose. Corpses never join picking or simulation.
import * as T from '../vendor/three/three.module.js';
import {isShip,bridgeAt,fortAt,TERRAIN} from './engine.mjs';
import {offsetToWorld} from '../js/core/hex.js';
import {bakeFallenModel,bakeSunkMarker,simplifyFallenModel} from './fallen-model.mjs';
export const CASUALTY_LIMIT=512,LOW_CASUALTY_LIMIT=128,ATLAS_CELLS=16,ATLAS_TILE=64;
export const sunkCasualty=(map,u)=>isShip(u)||!!(map.terrain[u.r*map.cols+u.c]&(TERRAIN.SEA|TERRAIN.RIVER))&&!bridgeAt(map,u.c,u.r);
export const casualtyMarkers=(map,visible=()=>true)=>map.units.filter(u=>u.hp<=0&&u.kind!=='fort'&&!u.aboard&&visible(u));
export const cosmeticCasualties=(map,visible=()=>true)=>casualtyMarkers(map,visible).filter(u=>!sunkCasualty(map,u));
export function casualtyYaw(map,u){const key=[map.scenarioId??'',u.id??'',u.kind,u.c,u.r].join(':');let hash=2166136261;for(let i=0;i<key.length;i++){hash^=key.charCodeAt(i);hash=Math.imul(hash,16777619);}hash^=hash>>>16;hash=Math.imul(hash,0x7feb352d);hash^=hash>>>15;hash=Math.imul(hash,0x846ca68b);hash^=hash>>>16;return (hash>>>0)/4294967296*Math.PI*2;}
export function createCasualtyLayer({scene,createModel,heightOf}){
 const group=new T.Group();group.name='cosmetic-casualties';scene.add(group);const templates=new Map(),material=new T.MeshLambertMaterial({vertexColors:true,transparent:true}),o=new T.Object3D();let map=null,candidates=[],enabled=true,quality='standard',limit=CASUALTY_LIMIT,lifetime=8,turn=1,lastKey='',lastLOD=0;const firstSeen=new Map();let ageSignature='';
 const fade={value:330};material.onBeforeCompile=shader=>{shader.uniforms.fallenCutoff=fade;shader.vertexShader='varying float vFallenDistance;\n'+shader.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\nvFallenDistance=length(mvPosition.xyz);');shader.fragmentShader='uniform float fallenCutoff;varying float vFallenDistance;\n'+shader.fragmentShader.replace('#include <alphatest_fragment>','diffuseColor.a*=1.0-smoothstep(fallenCutoff-45.0,fallenCutoff,vFallenDistance);if(diffuseColor.a<0.005)discard;\n#include <alphatest_fragment>');};
 // Project the splatter into the body mesh, so every stain follows the fallen pose.
 const distanceShader=material.onBeforeCompile;
 material.onBeforeCompile=shader=>{
  distanceShader(shader);
  shader.vertexShader='attribute vec2 bloodUV; varying vec2 vBloodUV; varying float vBloodSeed;\n'+
    shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
      vBloodUV=bloodUV;
      // The corpse yaw is seeded by unit identity and survives instance reordering.
      vBloodSeed=0.0;
      #ifdef USE_INSTANCING
        vBloodSeed=floor((atan(instanceMatrix[0].z,instanceMatrix[0].x)+3.141593)*256.0);
      #endif
    `);
  shader.fragmentShader=`
    varying vec2 vBloodUV;
    varying float vBloodSeed;
    float bloodRandom(float salt) {
      float seed=floor(vBloodSeed+.5);
      return fract(sin(seed*.6173+salt*78.23)*43758.5453);
    }
  `+shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
    float stain=0.0;
    if (max(abs(vBloodUV.x),abs(vBloodUV.y))<4.0) {
      vec2 center=(vec2(bloodRandom(1.0),bloodRandom(2.0))-.5)*1.45;
      float size=mix(.54,1.08,bloodRandom(3.0));
      vec2 p=(vBloodUV-center)/size;
      float a=atan(p.y,p.x)+bloodRandom(23.0)*6.283185;
      float edge=.61+.16*sin(7.0*a)+.11*cos(13.0*a);
      stain=1.0-smoothstep(edge-.04,edge,length(p));
      float drops=2.0+floor(bloodRandom(4.0)*5.0);
      for (int i=0;i<6;i++) {
        if (float(i)>=drops) break;
        float salt=5.0+float(i)*3.0;
        float angle=bloodRandom(salt)*6.283185;
        float spread=mix(.76,1.36,bloodRandom(salt+1.0));
        float radius=mix(.045,.16,bloodRandom(salt+2.0));
        vec2 offset=vec2(cos(angle),sin(angle))*spread;
        stain=max(stain,1.0-smoothstep(radius*.7,radius,length(p-offset)));
      }
    }
    diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.23,.012,.016),stain*.82);
  `);
 };
 const stats={visible:0,candidates:0,prototypes:0,queued:0,captures:0,limit,near:0,far:0,expired:0};
 const prototypeKey=u=>JSON.stringify([sunkCasualty(map,u),u.kind,u.team,!!u.onFoot,Math.floor(casualtyYaw(map,u)/Math.PI),map.unitNames?.[u.kind],map.scenarioId]);
 const ageKey=m=>'ancient.visual.casualty-ages.v1:'+JSON.stringify([m.scenarioId,m.cols,m.rows]);
 function persistAges(){const data=JSON.stringify({turn,ages:[...firstSeen].slice(-1024)});if(data===ageSignature)return;ageSignature=data;try{localStorage.setItem(ageKey(map),data);}catch{}}
 function restoreAges(){try{const cached=JSON.parse(localStorage.getItem(ageKey(map)));if(turn>1&&cached?.ages)for(const [id,age]of cached.ages)if(age<=turn)firstSeen.set(id,age);}catch{}}
 function clearMeshes(){for(const m of [...group.children]){m.removeFromParent();m.dispose();}}
 function rebuild(){clearMeshes();if(!enabled||!map){stats.visible=0;return;}const buckets=new Map();stats.expired=0;
  for(const u of candidates){const age=turn-(firstSeen.get(u.id)||turn);if(lifetime>0&&age>=lifetime){stats.expired++;continue;}const key=prototypeKey(u);if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(u);}
  for(const [key,units] of buckets){let geometry=templates.get(key);if(!geometry){if(templates.size>=128)continue;const model=createModel({...units[0],hp:1,formed:false},map);geometry=sunkCasualty(map,units[0])?bakeSunkMarker():bakeFallenModel(model,Math.floor(casualtyYaw(map,units[0])/Math.PI));if(!geometry.attributes.bloodUV)geometry.setAttribute('bloodUV',new T.Float32BufferAttribute(new Float32Array(geometry.attributes.position.count*2).fill(10),2));geometry={near:geometry,far:simplifyFallenModel(geometry)};templates.set(key,geometry);stats.captures++;const materials=new Set();model.traverse(n=>{if(!n.isMesh)return;if(!n.geometry.userData.sharedUnitV02)n.geometry.dispose();for(const m of Array.isArray(n.material)?n.material:[n.material])materials.add(m);});for(const m of materials)m.dispose();}
   for(const lod of ['near','far']){const mesh=new T.InstancedMesh(geometry[lod],material,units.length);mesh.userData.lod=lod;mesh.name='fallen-bodies';mesh.userData.units=units;mesh.userData.fullCount=units.length;mesh.castShadow=false;mesh.receiveShadow=true;group.add(mesh);}
  }stats.prototypes=templates.size;updateLOD(null,true);
 }
 function updateLOD(camera,force=false){if(!force&&performance.now()-lastLOD<180)return;lastLOD=performance.now();let total=0,near=0,far=0;const accepted=new Set();for(const mesh of group.children){let n=0;for(const u of mesh.userData.units){const p=offsetToWorld(u.c,u.r),y=sunkCasualty(map,u)?0:heightOf(map,u),distance=camera?camera.position.distanceTo(new T.Vector3(p.x,y,p.z)):0;
    // Both LODs retain volume. Smooth distance alpha precedes culling.
    const cutoff=quality==='low'?180:330;fade.value=cutoff;const lod=quality!=='low'&&distance<100?'near':'far';if(mesh.userData.lod!==lod||distance>cutoff+12||accepted.has(u.id)||total>=limit)continue;accepted.add(u.id);if(lod==='near')near++;else far++;const fort=fortAt(map,u.c,u.r);
    const onDeck=fort?.hp>0&&!(u.gateTransit&&fort.gate)&&!sunkCasualty(map,u);
    // Keep the whole pile inside the solid central platform at every yaw.
    // Rotation must not send loose weapons beyond the edge of a narrow wall.
    const box=mesh.geometry.boundingBox;
    const radius=Math.hypot(Math.max(Math.abs(box.min.x),Math.abs(box.max.x)),Math.max(Math.abs(box.min.z),Math.abs(box.max.z)));
    const fit=onDeck?Math.min(1,(fort.gate?2.55:1.57)/Math.max(.01,radius)):1;
    o.position.set(p.x,y+(onDeck && !fort.gate ? .1 : 0)-box.min.y+.005,p.z);
    o.rotation.set(0,casualtyYaw(map,u),0);o.scale.set(fit,1,fit);o.updateMatrix();mesh.setMatrixAt(n++,o.matrix);total++;}mesh.count=n;mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();}stats.visible=total;stats.near=near;stats.far=far;}
 function sync(m,visible,{editing=false,show=true,detail='standard',budget=CASUALTY_LIMIT,maxAgeTurns=8,currentTurn=1}={}){const reset=map!==m;map=m;enabled=show&&!editing;quality=detail;limit=Math.min(detail==='low'?LOW_CASUALTY_LIMIT:CASUALTY_LIMIT,Math.max(0,budget));lifetime=maxAgeTurns;turn=currentTurn;group.visible=enabled;
  if(reset){for(const g of templates.values()){g.near.dispose();g.far.dispose();}templates.clear();firstSeen.clear();ageSignature='';restoreAges();lastKey='';}
  const all=casualtyMarkers(m,visible);stats.candidates=all.length;stats.limit=limit;for(const u of all)if(!firstSeen.has(u.id))firstSeen.set(u.id,turn);persistAges();
  candidates=all.slice(-CASUALTY_LIMIT);const key=JSON.stringify([enabled,quality,limit,lifetime,turn,candidates.map(u=>[u.id,u.kind,u.c,u.r])]);if(key!==lastKey){lastKey=key;rebuild();}}
 return {group,stats,sync,update(camera){if(enabled)updateLOD(camera);},clear(){map=null;candidates=[];firstSeen.clear();lastKey='';clearMeshes();stats.visible=0;},dispose(){clearMeshes();for(const g of templates.values()){g.near.dispose();g.far.dispose();}material.dispose();group.removeFromParent();}};
}
