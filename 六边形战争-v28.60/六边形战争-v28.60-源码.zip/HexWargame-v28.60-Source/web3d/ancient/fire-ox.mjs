import * as T from '../vendor/three/three.module.js';
import {buildDraughtOx} from './support-models.mjs';
import {materials as M,part,rod,joint} from './models-v02.mjs';
import {loft} from './historical-geometry.mjs';
// The approved supply-cart animal, without its working yoke; original light flame meshes.
const flameMaterial=color=>{const m=new T.MeshBasicMaterial({color,side:T.DoubleSide});m.userData.atlasCell=5;return m;};
const ember=flameMaterial(0xf36d16),orange=flameMaterial(0xffbc35),gold=flameMaterial(0xffec9c);
export function buildFireOx(parent,low){
 const ox=buildDraughtOx(parent,low,{position:[-.30,.25,0],harness:false});
 const tail=ox.getObjectByName('tail');
 const bundle=joint(tail,'tail-tinder',[-.13,-.81,.04]);
 for(const z of [-.045,.045])rod(bundle,M.wood,[.03,-.06,z],[-.35,.10,z],.035);
 part(bundle,new T.TorusGeometry(.078,.018,4,8),M.leather,[-.08,0,0]).rotation.z=-1.1;
 const fire=joint(bundle,'fire-tail',[-.18,.02,0]);
 for(const [z,h,lean] of [[-.09,.58,-.27],[.04,.85,-.42],[.14,.45,-.16]]){
  loft(fire,ember,[[0,0,z,.11,.09],[-.05,h*.35,z,.14,.095],[lean,h,z,.005,.005]],{axis:'y',sides:low?5:8});
  loft(fire,orange,[[.015,.015,z+.012,.08,.075],[-.04,h*.28,z+.015,.105,.08],[lean*.65,h*.76,z+.02,.003,.003]],{axis:'y',sides:low?5:8});
  loft(fire,gold,[[.035,.02,z+.035,.045,.045],[-.025,h*.22,z+.04,.065,.045],[lean*.35,h*.47,z+.035,.003,.003]],{axis:'y',sides:5});
 }
}
