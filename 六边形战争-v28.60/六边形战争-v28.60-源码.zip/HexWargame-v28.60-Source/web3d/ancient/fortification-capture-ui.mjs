import {captureOptions} from './fortification-capture.mjs';
import {distance} from './engine.mjs';
// Inform the player; there is deliberately no separate handover action or capture button.
export function appendCaptureControls({document,card,state,u}){
 if(!captureOptions(state,u).some(t=>distance(u,t.target)<=6))return;
 const help=document.createElement('p');help.className='rule-line';help.textContent='空工事：合法移动至外围相邻格即可夺取，无额外消耗；内部存活敌兵（含溃逃）仍能阻止。';card.append(help);
}
