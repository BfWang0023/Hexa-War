import {DAWN_CAMPAIGNS,DAWN_IDS} from './dawn-data.mjs';
import {MORE_CLASSICAL_CAMPAIGNS,MORE_CLASSICAL_IDS,moreClassicalKinds,moreClassicalApproach} from './classical-expansion-data.mjs';
import {HELLENISTIC_CAMPAIGNS,hellenisticInfo,hellenisticKinds,hellenisticApproach} from './hellenistic-data.mjs';
// Research notes are presentation metadata, never combat modifiers. Map distances
// and figure counts are tactical abstractions, not survey coordinates or exact OOBs.
const H='https://classics.mit.edu/Herodotus/', T='https://classics.mit.edu/Thucydides/';
const ORIGINAL_CLASSICAL_CAMPAIGNS=Object.freeze([
 {id:'marathon',year:-490,name:'马拉松之战',factions:['雅典与普拉提亚联军','波斯远征军'],focus:[31,19],camera:190,
  terrain:'西侧山麓、东侧海岸与东北大沼泽；开阔正面保留包抄空间。沼泽用浅水和可涉边缘示意。',
  forces:'采用希腊约1万人、波斯约2万—2.5万人的工作估计：希腊20枚重装步兵，波斯40枚混合步兵。主要按每枚约500人缩放，人数并非史料定论。',
  deployment:'希腊两翼较厚、中军较薄，普拉提亚在左翼。波斯较强步兵居中，轻兵与弓手分列。骑兵是否及时参战有争议，本开战截面不部署骑兵。',
  sources:[['希腊文化部：马拉松', 'https://2500years.culture.gov.gr/en/chapters/i-machi-tou-marathona'],['希罗多德6.109—117',H+'history.6.vi.html']]},
 {id:'thermopylae',year:-480,name:'温泉关之战',factions:['列奥尼达斯希腊联军','薛西斯波斯军'],focus:[37,15],camera:190,
  terrain:'按古代海岸线，海湾紧邻山脚，正面仅留狭窄陆路；南侧山地道路表现阿诺帕亚迂回路线，佛基斯守军在山路上。地图上方为海侧，并非现代海岸。',
  forces:'希腊全军约7000人，含300斯巴达人、700忒斯庇亚人及其他盟军。28枚约250人一队，斯巴达单独1枚。波斯总军估计7万—30万，不全挤进关口：只部署60枚进攻梯队，约1.5万人。',
  deployment:'希腊守关并分兵防山路；波斯主力在西侧集结，迂回分队从山路入口出发。旧关墙残缺，中央仍可通行；防守时还须注意侧后。',
  sources:[['希腊文化部：温泉关古地貌与兵力','https://2500years.culture.gov.gr/en/chapters/i-machi-ton-thermopilon/anopaia-atrapos'],['希罗多德第7卷',H+'history.7.vii.html']]},
 {id:'plataea',year:-479,name:'普拉提亚之战',factions:['保萨尼阿斯希腊联军','马尔多尼奥斯波斯联军'],focus:[33,24],camera:210,
  terrain:'北侧阿索波斯河及波斯营垒、南侧基泰隆山麓、中间起伏平原与加尔加菲亚泉附近；从平原到南侧坡地保留多条道路。',
  forces:'希罗多德列希腊重装步兵38700人；其庞大轻兵、波斯30万等总数争议很大。本局用希腊40枚重步兵加8枚辅助兵，对波斯60枚混合兵，作为作战正面的压缩部署，不将古代夸张总数换算成棋子。',
  deployment:'选取波斯军跨河追击、希腊战线展开的战术截面；斯巴达及特该亚在希腊右翼，雅典在左翼，面对亲波斯的希腊部队。河水不截断中央决战区。',
  sources:[['希罗多德9.28—32、49—63',H+'history.9.ix.html']]},
 {id:'sphacteria',year:-425,name:'斯法克特里亚之战',factions:['德摩斯梯尼与克里昂雅典军','埃皮塔达斯拉栖代梦守军'],focus:[24,18],camera:150,
  terrain:'狭长岛屿，西侧外海、东侧皮洛斯湾；北端陡坡和旧石垒，中部较平坦且有水源。林火后的岛面不另设茂密森林。',
  forces:'原载岛上420名重步兵；雅典先登800名重步兵，后有800弓手、800轻盾兵和舰队人员。部署8枚守军对16枚雅典重兵、8弓手、8轻兵；重兵约50人一枚，辅助兵约100人一枚，舰队桨手不全列战斗兵。',
  deployment:'采用雅典已在南部两侧登陆的截面；守军前哨、中央主力与北端石垒分置。轻盾兵按近战轻步兵表现，投射支援由弓手承担。',
  sources:[['修昔底德4.29—38',T+'pelopwar.4.fourth.html']]},
 {id:'leuctra',year:-371,name:'留克特拉之战',factions:['伊巴密浓达底比斯联军','克里奥姆布罗托斯斯巴达联军'],focus:[34,20],camera:190,
  terrain:'中央为可供骑兵活动的平原；边缘低丘，斯巴达后方营地位于坡地。没有横贯战线的虚构河流或山墙。',
  forces:'底比斯约6000步兵的记载与斯巴达联军约1万步兵的常见估计用于24对40枚重步兵；双方各4枚骑兵为屏护分队抽象，不把不确定的骑兵总数当定论。',
  deployment:'底比斯左翼纵深集中，右翼后撤；斯巴达精锐在其右翼，双方骑兵在步兵前方。五十盾深与十二盾深以初始队列纵深差异表现，仍按普通列阵规则作战。',
  sources:[['色诺芬《希腊史》6.4','https://sourcebooks.web.fordham.edu/ancient/371leuctra.asp'],['狄奥多罗斯15.52—56','https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Diodorus_Siculus/15C%2A.html']]},
 {id:'chaeronea',year:-338,name:'喀罗尼亚之战',factions:['腓力二世马其顿军','雅典与底比斯联军'],focus:[34,21],camera:195,
  terrain:'北缘刻菲索斯河、南缘山麓，中央平原保持连续；喀罗尼亚城镇位于希腊左翼一侧。古河道和具体战线均为示意重建。',
  forces:'狄奥多罗斯记马其顿步兵逾3万、骑兵不少于2000；采用24长枪方阵、6轻兵、2骑兵。希腊总数不确定，以约3万作工作估计：28重兵、4轻兵。普通步兵每枚约千人，圣队300人单独标记1枚。',
  deployment:'马其顿右翼腓力面对雅典左翼，左翼亚历山大面对底比斯右翼及圣队。具体佯退和骑兵冲破方式存在争议，玩家自行决定，不以脚本强迫历史结果。',
  sources:[['狄奥多罗斯16.85—86','https://www.livius.org/sources/content/diodorus/the-battle-of-chaeronea/']]},
 {id:'sicily_413',year:-413,name:'西西里远征：叙拉古决战',factions:['尼基阿斯雅典远征军','吉利普斯叙拉古联军'],focus:[38,29],camera:215,
  terrain:'东北城防与奥提伽、北侧厄庇波莱高地、西岸雅典营地、南侧阿纳波斯河及浅滩、东南大港出口和普莱米里翁岬。',
  forces:'采用月食延误后、港口封锁形成的陆海截面：修昔底德7.52记雅典86艘对叙拉古76艘，缩为17对15枚（每枚约5艘）。不同于后来110艘的最后海战。陆上28对24枚仅抽象营地守军及封锁部队，不声称等于全远征军。',
  deployment:'雅典舰队在大港西部，叙拉古舰队靠近东侧出口；陆军守营并可选择西撤。陆海两种撤离目标是可玩性推演，不是宣称历史上成功撤出。',
  sources:[['修昔底德7.42—54',T+'pelopwar.7.seventh.html']]},
]);
export const CLASSICAL_CAMPAIGNS=Object.freeze([...ORIGINAL_CLASSICAL_CAMPAIGNS,...MORE_CLASSICAL_CAMPAIGNS]);
export const CLASSICAL_IDS=new Set(CLASSICAL_CAMPAIGNS.map(c=>c.id));
export const classicalInfo=id=>CLASSICAL_CAMPAIGNS.find(c=>c.id===id);
export function classicalKinds(id,team){
 if(MORE_CLASSICAL_IDS.has(id))return moreClassicalKinds(id,team);
 const sides={
  marathon:[['greekHoplite'],['light','heavy','guard','archer']],
  thermopylae:[['greekHoplite'],['light','heavy','guard','archer']],
  plataea:[['greekHoplite','light'],['greekHoplite','light','heavy','archer','cavalry']],
  sphacteria:[['greekHoplite','light','archer'],['greekHoplite']],
  leuctra:[['greekHoplite','cavalry'],['greekHoplite','cavalry']],
  chaeronea:[['phalangite','companionCavalry','light'],['greekHoplite','light']],
  sicily_413:[['greekHoplite','light','archer','athenianTrireme'],['greekHoplite','light','archer','cavalry','phoenicianTrireme']],
 };return team?sides[id]?.[team==='egypt'?0:1]||[]:[...new Set(sides[id]?.flat()||[])];
}
// Initial advance points are scenario deployment data, not a replacement AI.
// Once foes are visible the existing combat/formation choices take over.
export function classicalApproach(m,u,team,ship){
 if(MORE_CLASSICAL_IDS.has(m.scenarioId))return moreClassicalApproach(m,u,team);
 const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
 switch(m.scenarioId){
  case 'marathon':return {c:team==='egypt'?33:30,r:u.r};
  case 'thermopylae':return team==='coalition'?m.victory.capture:u.formation?.includes('佛基斯')?null:{c:37,r:clamp(u.r,9,11)};
  case 'plataea':return {c:u.c,r:team==='egypt'?23:25};
  case 'sphacteria':return team==='egypt'?{c:23,r:14}:null;
  case 'leuctra':return {c:team==='egypt'?35:34,r:u.r};
  case 'chaeronea':return {c:team==='egypt'?34:35,r:u.r};
  case 'sicily_413':return ship?{c:team==='egypt'?62:54,r:clamp(u.r,29,41)}:team==='coalition'?{c:28,r:27}:null;
  default:return null;
 }
}

// Shared adapters preserve the original seven classical scenarios unchanged.
export const TACTICAL_IDS=new Set([...DAWN_CAMPAIGNS,...CLASSICAL_CAMPAIGNS,...HELLENISTIC_CAMPAIGNS].map(c=>c.id));
export const tacticalInfo=id=>DAWN_CAMPAIGNS.find(c=>c.id===id)||classicalInfo(id)||hellenisticInfo(id);
export const tacticalKinds=(id,team)=>DAWN_IDS.has(id)?(id==='dawn_delta'?['warship','archer']:['light','heavy','archer']):classicalInfo(id)?classicalKinds(id,team):hellenisticKinds(id,team);
export const tacticalApproach=(m,u,team,ship)=>DAWN_IDS.has(m.scenarioId)?{c:team==='egypt'?12:7,r:u.r}:classicalInfo(m.scenarioId)?classicalApproach(m,u,team,ship):hellenisticApproach(m,u,team);
