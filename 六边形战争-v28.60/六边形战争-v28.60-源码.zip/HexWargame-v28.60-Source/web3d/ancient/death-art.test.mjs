import test from 'node:test';import assert from 'node:assert/strict';import * as T from '../vendor/three/three.module.js';import {createUnitModel} from './unit-presentation.mjs';import {bakeFallenModel,bakeSunkMarker} from './fallen-model.mjs';import {cosmeticCasualties,casualtyMarkers,sunkCasualty} from './casualty-layer.mjs';import * as E from './engine.mjs';
for(const kind of ['heavy','chinaCrossbow','siegeRam','romanOnager','siegeTower','chariot','supplyWagon'])test(`${kind} static casualty is finite, grounded and strips its base`,()=>{const m=createUnitModel({kind,team:'egypt',hp:100},'gaugamela'),g=bakeFallenModel(m);assert.ok([...g.attributes.position.array].every(Number.isFinite));assert.ok(g.boundingBox.min.y>=.034);if(kind==='heavy'){const v=m.getObjectByName('visual'),people=[];v.traverse(o=>{if(o.name==='soldier')people.push(o);});assert.ok(new Set(people.map(o=>o.rotation.z)).size>1);const tools=[];v.traverse(o=>{if(o.name==='melee-tool')tools.push(o);});assert.ok(tools.every(o=>o.parent===v));assert.equal(v.getObjectByName('casualty-blood'),undefined);const shields=[];v.traverse(o=>{if(o.name==='fallen-shield')shields.push(o);});assert.ok(shields.length>0);assert.ok(shields.every(o=>o.parent===v));}if(kind==='chariot')m.traverse(o=>{if(o.name==='casualty-rein')assert.equal(o.visible,false);});});
test('ships, transports and dead soldiers in water leave X markers, never floating bodies; bridges retain bodies',()=>{const m=E.newMap(12,10);m.units=[{id:'boat',kind:'transport',c:3,r:3,hp:0},{id:'foot',kind:'light',c:4,r:3,hp:0},{id:'bridge',kind:'light',c:5,r:3,hp:0}];m.terrain[3*12+4]=8;m.terrain[3*12+5]=5;E.setBridge(m,5,3,true);const before=JSON.stringify(m);assert.equal(sunkCasualty(m,m.units[1]),true);assert.deepEqual(cosmeticCasualties(m).map(u=>u.id),['bridge']);assert.equal(casualtyMarkers(m).length,3);assert.equal(casualtyMarkers(m,u=>u.id==='bridge').length,1);assert.equal(JSON.stringify(m),before);const g=bakeSunkMarker();assert.ok(g.boundingBox.max.y<.1);assert.ok(g.attributes.position.count>0);});

test('fallen infantry skin and gear have a dark grayscale gradient and wall casualties fit the solid deck',async()=>{
 const {createCasualtyLayer}=await import('./casualty-layer.mjs');
 const m=E.newMap(12,10);E.setFort(m,4,4,1,'egypt');
 const u={id:'fallen',kind:'heavy',team:'egypt',c:4,r:4,hp:0};m.units.push(u);
 const createModel=u=>createUnitModel(u,'megiddo');
 const body=bakeFallenModel(createModel(u));const colors=body.attributes.color;
 for(let i=0;i<colors.count;i++){assert.equal(colors.getX(i),colors.getY(i));assert.equal(colors.getX(i),colors.getZ(i));assert.ok(colors.getX(i)>=.017&&colors.getX(i)<.175);}
 assert.ok(new Set(Array.from({length:colors.count},(_,i)=>colors.getX(i))).size>2);
 const layer=createCasualtyLayer({scene:new T.Scene(),createModel,heightOf:()=>2.8});layer.sync(m,()=>true);
 const mesh=layer.group.children.find(mesh=>mesh.count>0),matrix=new T.Matrix4();mesh.getMatrixAt(0,matrix);
 const bounds=mesh.geometry.boundingBox.clone().applyMatrix4(matrix),center=new T.Vector3().setFromMatrixPosition(matrix);
 assert.ok(Math.max(Math.abs(bounds.min.x-center.x),Math.abs(bounds.max.x-center.x),Math.abs(bounds.min.z-center.z),Math.abs(bounds.max.z-center.z))<1.68);
 assert.ok(Math.abs(bounds.min.y-2.905)<.001);layer.dispose();body.dispose();
});

for(const [kind,scenario] of [['chariot','megiddo'],['chinaHeavyChariot','china_chengpu'],['cavalry','gaugamela'],['scout','megiddo']]){
 test(`${kind}: rider, mount and all equipment gray; loose parts separately grounded`,()=>{
  const model=createUnitModel({kind,team:'egypt',hp:1},scenario,{casualty:true,withoutBase:true});
  const baked=bakeFallenModel(model),colors=baked.attributes.color;
  for(let i=0;i<colors.count;i++){
   assert.equal(colors.getX(i),colors.getY(i));assert.equal(colors.getY(i),colors.getZ(i));
  }
  const visual=model.getObjectByName('visual');
  for(const object of visual.children.filter(o=>o.isMesh&&o.visible)){
   assert.ok(new T.Box3().setFromObject(object).min.y<.045,`${object.name||object.geometry.type} grounded`);
  }
  visual.traverse(o=>{if(o.name==='casualty-rein')assert.equal(o.visible,false);});
  assert.ok(baked.attributes.bloodUV.array.some(value=>Math.abs(value)<1));
  baked.dispose();
 });
}
