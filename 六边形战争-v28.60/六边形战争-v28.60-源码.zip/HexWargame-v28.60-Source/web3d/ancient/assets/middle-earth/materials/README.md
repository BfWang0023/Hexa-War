# 中土战场材质

运行时使用本目录中的 1024 × 1024 JPEG。颜色贴图使用 sRGB，OpenGL 法线和粗糙度使用线性数据。源文件转存为 JPEG 以减少下载体积。Rock Face 的颜色降低了饱和度。

| 本地前缀 | 原始素材 | 通道 | 许可 |
|---|---|---|---|
| grass | [ambientCG Grass 001](https://ambientcg.com/a/Grass001) | 颜色、OpenGL 法线、粗糙度 | [CC0 1.0](https://docs.ambientcg.com/license/) |
| mud | [Poly Haven Brown Mud](https://polyhaven.com/a/brown_mud) | 颜色 | [CC0](https://polyhaven.com/license) |
| rock | [Poly Haven Rock Face](https://polyhaven.com/a/rock_face) | 颜色 | CC0 |
| stone | [Poly Haven Stone Tile Wall](https://polyhaven.com/a/stone_tile_wall) | 颜色、OpenGL 法线、粗糙度 | CC0 |
| wood | [Poly Haven Wooden Planks](https://polyhaven.com/a/wooden_planks) | 颜色、OpenGL 法线、粗糙度 | CC0 |
| slate | [Poly Haven Grey Roof Tiles](https://polyhaven.com/a/grey_roof_tiles) | 颜色 | CC0 |
| clay | [Poly Haven Ceramic Roof 01](https://polyhaven.com/a/ceramic_roof_01) | 颜色 | CC0 |
