import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
function setup(kind='chinaCrossbow',version=22,team='egypt') {
 const m=E.newMap(24,16);m.scenarioId='custom_uphill';E.addUnit(m,'pharaoh','egypt',0,0);
 E.addUnit(m,kind,team,4,6);E.addUnit(m,'heavy',team==='egypt'?'coalition':'egypt',7,6);
 for(let c=5;c<=7;c++)E.setTerrain(m,c,6,E.TERRAIN.MOUNTAIN);
 const s=E.startGame(m,{rulesVersion:version,fogPolicy:{terrainFog:false,unitFog:true}});
 s.side=team;s.map.elevations=Array(24*16).fill(0);
 for(let c=5;c<=7;c++)s.map.elevations[E.index(s.map,c,6)]=(c-4)*.4;
 const a=E.mobileAt(s.map,4,6),d=E.mobileAt(s.map,7,6);
 E.recomputeFog(s);return {s,a,d};
}
for(const version of [12,22])for(const kind of ['chinaCrossbow','archer','romanArcher'])for(const team of ['egypt','coalition'])test(`${kind} v${version} ${team}: see and actually shoot a rising unobstructed slope`,()=>{
 const {s,a,d}=setup(kind,version,team);
 assert.equal(E.visibleTo(s,team,d.c,d.r),false);E.addUnit(s.map,"light",team,8,6);E.recomputeFog(s);
 assert.equal(E.visibleTo(s,team,d.c,d.r),true);
 const preview=E.attackPreview(s,a,d.c,d.r);assert.ok(preview);assert.equal(preview.melee,false);
 assert.equal(preview.elevation.label,'低打高');assert.ok(Math.abs(preview.elevation.multiplier-.82)<1e-9);
 const ap=a.actionsLeft,ammo=a.ammo,hp=d.hp,result=E.attack(s,a.id,d.c,d.r,0,0,0);
 assert.equal(result.ok,true);assert.equal(result.unitDamage,preview.damage);assert.equal(d.hp,hp-preview.damage);
 assert.equal(a.actionsLeft,ap-1);assert.equal(a.ammo,ammo-1);assert.ok(s.log.some(x=>x.includes('低打高')));
});
test('a higher intervening ridge still blocks both sight and attack',()=>{
 const {s,a,d}=setup();s.map.elevations[E.index(s.map,5,6)]=3;E.recomputeFog(s);
 assert.equal(E.visibleTo(s,a.team,d.c,d.r),false);assert.equal(E.attackPreview(s,a,d.c,d.r),null);
 assert.equal(E.attack(s,a.id,d.c,d.r,0).ok,false);assert.equal(a.actionsLeft,2);
});
test('an enemy wall or intervening enemy continues to block uphill fire',()=>{
 for(const obstruction of ['wall','unit']){const {s,a,d}=setup();
 if(obstruction==='wall')E.setFort(s.map,5,6,2,'coalition');else E.addUnit(s.map,'light','coalition',5,6);
 E.recomputeFog(s);assert.equal(E.attackPreview(s,a,d.c,d.r),null,obstruction);assert.equal(E.attack(s,a.id,d.c,d.r,0).ok,false);}
});
test('uphill does not grant extra range, ammunition or actions',()=>{
 for(const reason of ['range','ammo','ap']){const {s,a,d}=setup();
 if(reason==='range'){d.c=8;s.map.elevations[E.index(s.map,8,6)]=2;}else if(reason==='ammo')a.ammo=0;else a.actionsLeft=0;
 E.recomputeFog(s);assert.equal(E.attackPreview(s,a,d.c,d.r),null,reason);assert.equal(E.attack(s,a.id,d.c,d.r,0).ok,false);}
});
test('equal or descending endpoint does not bypass a plain shooter’s mountain blocker',()=>{
 for(const h of [0,-1]){const {s,a,d}=setup();s.map.elevations[E.index(s.map,d.c,d.r)]=h;E.recomputeFog(s);assert.equal(E.attackPreview(s,a,d.c,d.r),null);}
});
test('old v10 terrain obstruction remains unchanged',()=>{
 const {s,a,d}=setup('chinaCrossbow',10);assert.equal(E.attackPreview(s,a,d.c,d.r),null);
});
test('save and restore retain the logical slope and executable uphill shot',()=>{
 const {s,a,d}=setup();E.addUnit(s.map,'light',a.team,8,6);E.recomputeFog(s);const loaded=restoreSave(JSON.parse(JSON.stringify(createSave(s.map,s,a.team)))).game;
 const u=loaded.map.units.find(u=>u.id===a.id);assert.deepEqual(loaded.map.elevations,s.map.elevations);
 assert.equal(E.attackPreview(loaded,u,d.c,d.r).damage,E.attackPreview(s,a,d.c,d.r).damage);
 assert.equal(E.attack(loaded,u.id,d.c,d.r,0).ok,true);
});
