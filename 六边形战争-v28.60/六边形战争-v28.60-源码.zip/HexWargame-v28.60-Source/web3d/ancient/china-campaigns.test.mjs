import test from 'node:test';
import assert from 'node:assert/strict';
import { CHINA_CAMPAIGNS, makeChinaMap } from './china-campaigns.mjs';
import { isChinaIronAgeScenario } from './china-era.mjs';
import { STATS, TERRAIN, addUnit, aiTurn, attack, attackPreview, checkVictory, endSide, exportMap, fortAt,
  importMap, isRouted, meleePower, mobileAt, rangedPower, reachable, recomputeFog, setFort, setTerrain,
  startGame, tile, unitArmor, unitMaxHp } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

test('all 35 pre-Qin campaigns have distinct playable and saveable maps', () => {
  assert.equal(CHINA_CAMPAIGNS.length, 35);
  assert.equal(new Set(CHINA_CAMPAIGNS.map(x => x.id)).size, 35);
  assert.equal(new Set(CHINA_CAMPAIGNS.map(x => x.name)).size, 35);
  for (const entry of CHINA_CAMPAIGNS) {
    const map = makeChinaMap(entry.id);
    assert.equal(map.scenarioId, entry.id);
    assert.equal(map.victory.mode, 'china');
    assert.ok(map.units.some(u => u.kind === 'chinaGeneral' && u.team === 'egypt'));
    assert.ok(map.units.some(u => u.kind === 'chinaGeneral' && u.team === 'coalition'));
    assert.deepEqual(importMap(exportMap(map)).victory, map.victory);
    assert.equal(startGame(map).over, false);
  }
  const s = startGame(makeChinaMap('china_changping'));
  const saved = createSave(s.map, s, 'egypt', null, new Set());
  assert.equal(restoreSave(saved).game.map.scenarioId, 'china_changping');
});

test('Mingtiao is an earlier infantry battle with named commanders and no speculative chariots', () => {
  const m = makeChinaMap('china_mingtiao');
  assert.equal(m.victory.objectiveName, '夏桀中军');
  assert.equal(m.units.filter(u => u.team === 'egypt').length, 23);
  assert.equal(m.units.filter(u => u.team === 'coalition').length, 26);
  assert.equal(m.victory.losses.egypt, 17);
  assert.equal(m.victory.losses.coalition, 19);
  assert.ok(m.units.every(u => !['chinaHeavyChariot', 'chariot', 'cavalry', 'chinaCrossbow'].includes(u.kind)));
  assert.ok(m.landmarks.some(p => p.label.includes('位置未定')));
  assert.equal(m.unitNames['egypt:chinaGeneral'], '商汤');
  assert.equal(m.unitNames['coalition:chinaGeneral'], '夏桀');
  assert.equal(startGame(m).over, false);
});

test('Muye puts Zhou chariots and tiger guards ahead of reduced infantry against a larger brittle Shang army', () => {
  const m = makeChinaMap('china_muye');
  assert.equal(m.cols, 76);
  const zhou = m.units.filter(u => u.team === 'egypt');
  const shang = m.units.filter(u => u.team === 'coalition');
  assert.equal(zhou.length, 33);
  assert.equal(shang.length, 75);
  assert.equal(m.victory.losses.egypt, 24);
  assert.equal(m.victory.losses.coalition, 56);
  const count = (units, kind) => units.filter(u => u.kind === kind).length;
  assert.equal(count(zhou, 'chinaHeavyChariot'), 13);
  assert.equal(count(zhou, 'guard'), 5);
  assert.equal(count(zhou, 'heavy') + count(zhou, 'light') + count(zhou, 'archer'), 14);
  const advance = zhou.filter(u => ['chinaHeavyChariot', 'guard'].includes(u.kind));
  const rear = zhou.filter(u => ['heavy', 'light', 'archer'].includes(u.kind));
  assert.ok(Math.min(...advance.map(u => u.c)) > Math.max(...rear.map(u => u.c)));
  assert.equal(count(shang, 'light'), 36);
  assert.equal(count(shang, 'chinaHeavyChariot'), 5);
  assert.ok(shang.filter(u => u.kind !== 'chinaGeneral').every(u => u.morale <= 0.6 && !isRouted(u)));
  assert.ok(shang.filter(u => u.formation === '商军前列').every(u => u.morale === 0.34));
  assert.equal(importMap(exportMap(m)).units.find(u => u.formation === '商军前列').morale, 0.34);
  assert.ok(m.landmarks.some(p => p.label.includes('朝歌')));
});

test('Muye Shang front line loses morale but does not rout after one nearby casualty', () => {
  const s = startGame(makeChinaMap('china_muye'));
  const front = s.map.units.filter(u => u.formation === '商军前列');
  const casualty = front[0], neighbor = front[1];
  const chariot = s.map.units.find(u => u.team === 'egypt' && u.kind === 'chinaHeavyChariot');
  casualty.c = 35; casualty.r = 25; casualty.hp = 1;
  neighbor.c = 36; neighbor.r = 25;
  chariot.c = 34; chariot.r = 25;
  recomputeFog(s);
  const result = attack(s, chariot.id, casualty.c, casualty.r, 0, 0, 0);
  assert.equal(result.ok, true);
  assert.equal(casualty.hp, 0);
  assert.equal(neighbor.morale, 0.31);
  assert.equal(isRouted(neighbor), false);
});

test('ordinary Chinese three-army deployments gather along connected road lanes', () => {
  for (const id of ['china_xuge', 'china_chengpu', 'china_yanling', 'china_alliance_qi']) {
    const m = makeChinaMap(id), roads = [];
    for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++)
      if (tile(m, c, r).terrain & TERRAIN.ROAD) roads.push({ c, r });
    for (const team of ['egypt', 'coalition']) {
      const soldiers = m.units.filter(u => u.team === team && u.kind !== 'chinaGeneral');
      assert.ok(Math.max(...soldiers.map(u => u.r)) - Math.min(...soldiers.map(u => u.r)) <= 17, id);
      assert.ok(soldiers.every(u => roads.some(p => Math.max(Math.abs(u.c - p.c),
        Math.abs(u.r - p.r)) <= 2)), `${id}:${team}`);
    }
  }
  const muye = makeChinaMap('china_muye');
  assert.ok(muye.units.filter(u => u.team === 'coalition' && u.kind !== 'chinaGeneral')
    .every(u => u.r >= 15 && u.r <= 34));
  const qinChu = makeChinaMap('china_qin_chu');
  assert.ok(qinChu.units.filter(u => u.team === 'egypt' && u.formation === '秦军南路追击')
    .every(u => u.r >= 34 && u.r <= 38));
  const changping = makeChinaMap('china_changping');
  assert.ok(changping.units.some(u => u.formation === '赵军石长城东段' && u.r < 15));
  const maling = makeChinaMap('china_maling');
  assert.ok(maling.units.some(u => u.formation === '齐军北坡伏弩' && u.r < 17));
});

test('fourth-century BCE Chinese armies receive the Western iron-age combat upgrade on both sides', () => {
  for (const entry of CHINA_CAMPAIGNS)
    assert.equal(isChinaIronAgeScenario(entry.id), entry.year >= -400, entry.id);
  const early = makeChinaMap('china_wei_zhongshan'); // 406 BCE
  const iron = makeChinaMap('china_hexi_second'); // 389 BCE
  for (const team of ['egypt', 'coalition']) {
    const soldier = iron.units.find(u => u.team === team && u.kind === 'heavy');
    assert.equal(soldier.hp, STATS.heavy.hp + 60);
    for (const kind of ['heavy', 'light', 'archer', 'guard', 'chinaGeneral',
      'chinaHeavyChariot', 'chinaCrossbow', 'cavalry']) {
      const u = { kind, team };
      assert.equal(unitMaxHp(iron, u), unitMaxHp(early, u) + 60, kind);
      assert.equal(unitArmor(iron, u), unitArmor(early, u) + 1, kind);
      assert.equal(meleePower(u, iron), meleePower(u, early) + 1.5, kind);
      if (STATS[kind].ranged)
        assert.equal(rangedPower(iron, u), rangedPower(early, u) + 1.5, kind);
    }
  }
  for (const kind of ['fort', 'siegeRam', 'chinaFireOx']) {
    const u = { kind, team: 'egypt' };
    assert.equal(unitMaxHp(iron, u), unitMaxHp(early, u), kind);
    assert.equal(unitArmor(iron, u), unitArmor(early, u), kind);
  }
  assert.equal(importMap(exportMap(iron)).units.find(u => u.kind === 'heavy').hp,
    STATS.heavy.hp + 60);
});

test('an older Warring States save gains the new health while retaining existing damage', () => {
  const scenario = makeChinaMap('china_changping');
  const game = startGame(scenario);
  const soldier = game.map.units.find(u => u.kind === 'heavy');
  const currentId = soldier.id;
  soldier.hp = STATS.heavy.hp - 17;
  const save = createSave(scenario, game, 'egypt');
  delete save.rulesVersion;
  const restored = restoreSave(save);
  assert.equal(restored.game.map.units.find(u => u.id === currentId).hp, STATS.heavy.hp + 60 - 17);
  assert.equal(restoreSave(createSave(scenario, restored.game, 'egypt')).game.map.units
    .find(u => u.id === currentId).hp, STATS.heavy.hp + 60 - 17);
});

test('a siege requires a broken wall before the attacker may capture its goal', () => {
  const s = startGame(makeChinaMap('china_three_guards'));
  const goal = s.map.victory.objective;
  const occupant = mobileAt(s.map, goal.c, goal.r);
  if (occupant) occupant.hp = 0;
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  soldier.c = goal.c; soldier.r = goal.r;
  checkVictory(s);
  assert.equal(s.over, false);
  const wall = s.map.units.find(u => u.kind === 'fort' && u.team === 'coalition');
  wall.hp = 0;
  checkVictory(s);
  assert.equal(s.winner, 'egypt');
  assert.equal(s.victoryReason, 'china_capture');
});

test('the defender wins when its pre-Qin campaign holds to the turn limit', () => {
  const s = startGame(makeChinaMap('china_xuge'));
  s.turn = s.map.victory.turnLimit;
  s.side = 'coalition';
  endSide(s, () => 0.99);
  assert.equal(s.winner, 'coalition');
  assert.equal(s.victoryReason, 'china_hold');
});

test('Jimo fire ox charges harder after crossing two hexes', () => {
  const s = startGame(makeChinaMap('china_tian_dan'));
  const ox = s.map.units.find(u => u.kind === 'chinaFireOx');
  const foe = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  foe.c = 33; foe.r = 20;
  ox.c = 32; ox.r = 20;
  recomputeFog(s);
  const ordinary = attackPreview(s, ox, foe.c, foe.r);
  ox.movedSteps = 2;
  const charge = attackPreview(s, ox, foe.c, foe.r);
  assert.ok(charge.damage > ordinary.damage);
});

test('computer attacker advances toward a campaign objective before contact', () => {
  const s = startGame(makeChinaMap('china_xuge'));
  s.side = 'egypt';
  const before = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  const start = { c: before.c, r: before.r };
  const actions = aiTurn(s, () => 0.99);
  assert.ok(actions.some(a => a.type === 'move' && a.id === before.id));
  assert.notDeepEqual({ c: before.c, r: before.r }, start);
});

test('Eyu starts with Zhao on the northern height and rewards descent into Qin troops', () => {
  const s = startGame(makeChinaMap('china_eyu'));
  assert.ok(s.map.landmarks.some(x => x.label.includes('北山')));
  assert.ok(s.map.units.some(u => u.team === 'egypt' && u.kind === 'heavy' &&
    (tile(s.map, u.c, u.r).terrain & TERRAIN.MOUNTAIN) && u.r < 17));
  const zhao = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  const qin = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  zhao.c = 41; zhao.r = 8; qin.c = 41; qin.r = 9;
  recomputeFog(s);
  const downhill = attackPreview(s, zhao, qin.c, qin.r);
  setTerrain(s.map, zhao.c, zhao.r, TERRAIN.PLAIN);
  const level = attackPreview(s, zhao, qin.c, qin.r);
  assert.ok(downhill.damage > level.damage);
});

test('Changping sends every Qin unit east from west of Kongcang against continuous graded Zhao defenses', () => {
  const m = makeChinaMap('china_changping');
  assert.ok(m.cols > 70);
  const qin = m.units.filter(u => u.team === 'egypt' && !['fort', 'supplyWagon', 'moraleGuard'].includes(u.kind));
  const zhao = m.units.filter(u => u.team === 'coalition' && !['fort', 'supplyWagon', 'moraleGuard'].includes(u.kind));
  assert.equal(qin.length, 68);
  assert.equal(zhao.length, 72);
  const composition = units => Object.fromEntries(['heavy', 'cavalry', 'chinaCrossbow', 'guard']
    .map(kind => [kind, units.filter(u => u.kind === kind).length]));
  assert.deepEqual(composition(qin), { heavy: 35, cavalry: 10, chinaCrossbow: 19, guard: 3 });
  assert.deepEqual(composition(zhao), { heavy: 43, cavalry: 0, chinaCrossbow: 25, guard: 3 });
  assert.ok(qin.every(u => u.c < 23));
  assert.ok(zhao.every(u => u.c > 26));
  const unitOf = name => m.units.filter(u => u.formation === name);
  for (const [front, bows] of [
    ['秦军北路前锋', '秦军北路弩队'],
    ['秦军高平关攻坚队', '秦军中路弩队'],
    ['秦军南路前锋', '秦军南路弩队'],
  ]) assert.ok(Math.min(...unitOf(front).map(u => u.c)) >
    Math.max(...unitOf(bows).map(u => u.c)));
  for (const line of ['空仓岭', '丹水']) {
    const sectors = ['北段', '北中段', line === '空仓岭' ? '关口' : '中段', '南中段', '南段'];
    for (const sector of sectors) {
      const front = unitOf(`赵军${line}${sector}步阵`);
      const bows = unitOf(`赵军${line}${sector}弩队`);
      assert.ok(front.length > 0 && bows.length > 0);
      assert.ok(Math.max(...front.map(u => u.c)) < Math.min(...bows.map(u => u.c)));
    }
  }
  assert.equal(zhao.filter(u => u.formation?.startsWith('赵军空仓岭')).length, 20);
  assert.equal(zhao.filter(u => u.formation?.startsWith('赵军丹水')).length, 28);
  assert.equal(zhao.filter(u => u.formation?.startsWith('赵军石长城')).length, 13);
  assert.deepEqual([zhao.find(u => u.kind === 'chinaGeneral').c,
    zhao.find(u => u.kind === 'chinaGeneral').r], [58, 18]);
  assert.match(m.intro, /四十五万人/);
  assert.ok(tile(m, 24, 28).terrain & TERRAIN.MOUNTAIN); // 空仓岭
  assert.ok(tile(m, 42, 28).terrain & TERRAIN.RIVER); // 丹水
  for (let r = 10; r <= 44; r++) {
    assert.equal(fortAt(m, 27, r)?.team, 'coalition');
    assert.equal(fortAt(m, 27, r)?.level, 1);
  }
  for (let r = 12; r <= 42; r++) {
    assert.equal(fortAt(m, 46, r)?.team, 'coalition');
    assert.equal(fortAt(m, 46, r)?.level, 2);
  }
  for (let c = 45; c <= 77; c++) {
    assert.equal(fortAt(m, c, 11)?.team, 'coalition');
    assert.equal(fortAt(m, c, 11)?.level, 2);
  }
  assert.notEqual(mobileAt(m, m.victory.objective.c, m.victory.objective.r)?.team, 'egypt');
  const restored = importMap(exportMap(m));
  assert.ok(restored.units.some(u => u.formation === '秦军中军预备队'));
});

test('Qin conquest of Chu uses large grouped armies without assigning a fabricated Chu headcount', () => {
  const m = makeChinaMap('china_qin_chu');
  assert.deepEqual([m.cols, m.rows], [88, 54]);
  assert.equal(m.units.filter(u => u.team === 'egypt' && !['fort', 'supplyWagon', 'moraleGuard'].includes(u.kind)).length, 74);
  assert.equal(m.units.filter(u => u.team === 'coalition' && !['fort', 'supplyWagon', 'moraleGuard'].includes(u.kind)).length, 70);
  assert.match(m.intro, /六十万.*楚军确数未载/);
  assert.ok(m.units.some(u => u.formation === '秦军追击前锋' && u.c > 30));
  assert.ok(m.units.some(u => u.formation === '楚军后队' && u.c > 70));
});

test('relief battles aim at the siege camp rather than their own city', () => {
  for (const id of ['china_jin_partition', 'china_handan']) {
    const m = makeChinaMap(id), { c, r } = m.victory.objective;
    assert.notEqual(mobileAt(m, c, r)?.team, 'egypt');
    assert.ok(m.units.some(u => u.kind === 'fort' && u.team === 'egypt'));
  }
});

test('legacy v14 Chinese heavy chariots retain their original fixed charge and rough-ground rules', () => {
  const s = startGame(makeChinaMap('china_xuge'),{rulesVersion:14});
  const chariot = s.map.units.find(u => u.team === 'egypt' && u.kind === 'chinaHeavyChariot');
  const foe = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  assert.ok(chariot);
  assert.ok(STATS.chinaHeavyChariot.melee > STATS.heavy.melee);
  assert.ok(STATS.chinaHeavyChariot.ranged > STATS.archer.ranged);
  assert.equal(STATS.chariot.melee, 2); // Other historical campaigns retain their own chariot.
  chariot.c = 3; chariot.r = 3;
  setTerrain(s.map, 4, 3, TERRAIN.MOUNTAIN | TERRAIN.ROAD);
  setTerrain(s.map, 3, 4, TERRAIN.RIVER | TERRAIN.ROAD);
  recomputeFog(s);
  assert.equal(reachable(s, chariot).has('4,3'), true); // v12 mountain road, no extra road distance
  assert.equal(reachable(s, chariot).has('3,4'), true);
  assert.equal(addUnit(s.map, 'chinaHeavyChariot', 'egypt', 4, 3), true);
  s.map.units=s.map.units.filter(u=>u.c!==4||u.r!==3);
  assert.equal(addUnit(s.map, 'chinaHeavyChariot', 'egypt', 3, 4), true);
  setTerrain(s.map, 4, 3, TERRAIN.PLAIN);
  assert.equal(setFort(s.map, 4, 3, 2, 'egypt'), true);
  assert.equal(reachable(s, chariot).has('4,3'), false);
  setFort(s.map, 4, 3, 0);
  foe.c = 5; foe.r = 3;
  recomputeFog(s);
  const shot = attackPreview(s, chariot, foe.c, foe.r);
  assert.equal(shot.melee, false);
  assert.ok(shot.damage > 0);
  foe.c = 4; foe.r = 3;
  recomputeFog(s);
  const melee = attackPreview(s, chariot, foe.c, foe.r);
  assert.equal(melee.melee, true);
  chariot.movedSteps = 2;
  assert.ok(attackPreview(s, chariot, foe.c, foe.r).damage > melee.damage);
});
