import {chargeClass,chargeConfig,chargeCriticalConfig,usesChargeRules} from './charge-rules.mjs';
import {unitStats} from './engine.mjs';
const phrases=[
 ['具装骑兵：移动至少 2 格后发动近战冲击，额外造成伤害。',''],
 ['，移动至少两格后近战冲击额外造成2.0伤害。','。'],
 ['移动至少 2 格后冲击未以方阵正面迎击的敌人，近战额外伤害 +3.0。',''],
 ['；移动至少 2 格后，近战步兵额外造成 2.0 伤害。','。'],
 ['平原冲击移动至少两格后近战伤害另加 2.0。','冲锋采用本局的统一近战倍率。'],
 ['移动至少 2 格后冲击步兵 +2.0 伤害。','冲锋采用本局的统一近战倍率。'],
 ['波斯镰刀战车移动至少2格后冲击未以方阵正面迎击的目标会额外造成3.0伤害。','波斯镰刀战车采用本局的统一近战冲锋倍率。'],
];
export function normalizeChargeCopy(s,text){if(!usesChargeRules(s))return text;for(const [a,b]of phrases)text=text.split(a).join(b);return text;}
const criticalCopy=s=>s.rulesVersion>=17?`命中后有${(chargeCriticalConfig(s.chargeCriticalRules).chance*100).toFixed(0)}%概率暴击，基础伤害乘${chargeCriticalConfig(s.chargeCriticalRules).multiplier.toFixed(2)}，替代普通冲锋倍率。`:'';
export function chargeUnitCopy(s,u){if(!usesChargeRules(s)||!u)return '';if(s.rulesVersion>=21&&['skirmisher','maneuver'].includes(unitStats(s.map,u).mountedRole))return '轻型机动兵种：保留普通近战；不享受两格冲锋增伤或冲锋专属暴击。移动与攻击分别消耗原行动力。';const type=chargeClass(s.map,u,s.rulesVersion);if(!type&&!unitStats(s.map,u).chargeClass)return '';return type?`冲锋：伤害 ×${chargeConfig(s.chargeRules)[type].toFixed(2)}。同回合最后两步持续接近目标后立即近战；其他部队行动、停止或其他付费动作会打断，攻击只加成一次。${criticalCopy(s)}`:'当前状态不能发动近战冲锋。';}
export function updateChargeHelp(s,body){if(!usesChargeRules(s))return;body.innerHTML=normalizeChargeCopy(s,body.innerHTML);const p=body.ownerDocument.createElement('p'),cfg=chargeConfig(s.chargeRules);p.textContent=`规则 v${s.rulesVersion} 冲锋：${s.rulesVersion>=21?'冲击型重骑兵':'骑兵'}×${cfg.cavalry.toFixed(2)}、近战重型战车×${cfg.heavyChariot.toFixed(2)}。同回合合法连续接近至少两格并立即近战；往返、转向、跨回合或无关行动不能积累冲锋。移动、攻击各付原行动成本，失手也消耗机会；不重复叠加旧移动冲锋定值，高差修正另结算一次。${criticalCopy(s)}`;body.prepend(p);}
