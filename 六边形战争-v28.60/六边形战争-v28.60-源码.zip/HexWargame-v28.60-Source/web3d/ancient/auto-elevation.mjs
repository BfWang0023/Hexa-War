// Versioned, bounded-support generation. No rendering state or random generator.
import {axialFromOffset,offsetFromAxial} from '../js/core/hex.js';
export const AUTO_ELEVATION = Object.freeze({version:1,seed:2718,radius:8});
const rings=Array.from({length:9},()=>[]);
for(let q=-8;q<=8;q++)for(let r=-8;r<=8;r++){const d=(Math.abs(q)+Math.abs(r)+Math.abs(q+r))/2;if(d<=8)rings[d].push([q,r]);}
const stats=new WeakMap();
export const elevationGenerationStats=m=>stats.get(m);
export function terrainFingerprint(m){let h=2166136261;for(const n of [m.cols,m.rows,...m.terrain])h=Math.imul(h^n,16777619);return h>>>0;}
export function validateAutoElevation(m){if(m.autoElevation===undefined)return;const a=m.autoElevation;if(!a||a.version!==1||a.seed!==2718||a.radius!==8||!Number.isInteger(a.fingerprint)||!Array.isArray(m.elevations)||m.elevations.length!==m.cols*m.rows)throw Error('不支持或损坏的自动高程数据');}
function heightAt(m,c,r){const t=m.terrain[r*m.cols+c];if(!(t&2)||t&(4|8))return 0;const a=axialFromOffset(c,r);let depth=8;
 outer:for(let d=1;d<=8;d++)for(const [dq,dr] of rings[d]){const p=offsetFromAxial(a.q+dq,a.r+dr);if(p.col<0||p.row<0||p.col>=m.cols||p.row>=m.rows||!(m.terrain[p.row*m.cols+p.col]&2)){depth=d;break outer;}}
 // Coherent warped ridges on three scales, modulated by distance to the foothills.
 const x=a.q+r*.5,z=r*.866,s=AUTO_ELEVATION.seed*.001;
 const broad=.5+.5*Math.sin(x*.19-z*.13+s+Math.sin(z*.12));
 const ridge=Math.pow(.5+.5*Math.sin(x*.41+z*.23+Math.sin(z*.21)*1.1+s),1.5);
 const fine=.5+.5*Math.sin(x*.83-z*.54+s);
 const h=(.38+(depth-1)*.66)*(.65+.55*broad+.50*ridge+.12*fine);
 return Math.round(h*(t&1?.92:1)*100)/100;
}
export function regenerateElevation(m,changed=null){const started=performance.now(),local=changed&&m.autoElevation&&m.elevations?.length===m.cols*m.rows,affected=new Set();
 if(local)for(const p of changed){const a=axialFromOffset(p.c,p.r);for(const ring of rings)for(const [dq,dr] of ring){const v=offsetFromAxial(a.q+dq,a.r+dr);if(v.col>=0&&v.row>=0&&v.col<m.cols&&v.row<m.rows)affected.add(v.row*m.cols+v.col);}}
 else {m.elevations=Array(m.cols*m.rows).fill(0);for(let i=0;i<m.elevations.length;i++)affected.add(i);}
 const updated=[];for(const i of affected){const h=heightAt(m,i%m.cols,Math.floor(i/m.cols));if(m.elevations[i]!==h)updated.push(i);m.elevations[i]=h;}
 m.autoElevation={...AUTO_ELEVATION,fingerprint:terrainFingerprint(m)};
 const result={local:!!local,visited:affected.size,changed:updated,milliseconds:performance.now()-started};stats.set(m,result);return result;
}
export function ensureAutoElevation(m){if(m.victory?.mode==='middle-earth'&&m.victory.layoutVersion>=2&&m.elevations)return null;validateAutoElevation(m);if(!m.autoElevation||m.autoElevation.fingerprint!==terrainFingerprint(m))return regenerateElevation(m);return null;}
