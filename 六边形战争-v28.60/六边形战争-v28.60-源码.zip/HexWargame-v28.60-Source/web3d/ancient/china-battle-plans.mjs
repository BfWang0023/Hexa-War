// Coordinates are schematic hex positions. Formations and relative terrain follow the
// cited accounts in docs/中国先秦战场考据.md; exact ancient coordinates are not asserted.
// Units: C chariot, H heavy infantry, L light infantry, A archer, G guard,
// X crossbow, V cavalry, R siege ram, O fire ox.
const p = (objective, features, leaders, groups, landmarks = [], extra = {}) =>
  ({ objective, features, leaders, groups, landmarks, ...extra });
const g = (team, name, c, r, units) => [team, name, c, r, units];

const RAW_CHINA_BATTLE_PLANS = {
  china_mingtiao: p([51, 23], [
    ['road', 5, 23, 62, 23], ['road', 13, 17, 28, 20],
    ['road', 13, 29, 28, 26], ['road', 43, 20, 58, 17],
    ['road', 43, 26, 58, 29],
  ], [[12, 23], [55, 23]], [
    g('egypt', '商汤中军', 18, 23, 'H4 G2 L2'),
    g('egypt', '伊尹策应左翼', 20, 17, 'H3 A2 L2'),
    g('egypt', '诸侯联军右翼', 20, 29, 'H3 A2 L2'),
    g('coalition', '夏桀中军', 52, 23, 'H4 G2 L3'),
    g('coalition', '夏军左翼', 50, 17, 'H3 A2 L3'),
    g('coalition', '夏军右翼', 50, 29, 'H3 A2 L3'),
  ], [[33, 23, '鸣条之野（位置未定）'], [18, 23, '商汤本阵（示意）'],
    [51, 23, '夏桀中军（示意）']], { size: [68, 46], turnLimit: 28, evidence: 'low',
    historicalForce: '没有可靠的双方参战人数或具体军阵记录。棋子数量、道路和攻守方位均为玩法设计；不配置缺乏这个时代实证的马拉战车。' }),

  china_muye: p([60, 25], [
    ['road', 4, 24, 71, 24], ['road', 8, 17, 64, 17],
    ['road', 8, 33, 64, 33], ['ridge', 69, 5, 73, 13, 1],
    ['ridge', 69, 36, 73, 44, 1],
  ], [[14, 25], [65, 25]], [
    g('egypt', '周军战车与虎贲中锋', 24, 25, 'C5 G3'),
    g('egypt', '周军战车与虎贲左翼', 24, 17, 'C4 G1'),
    g('egypt', '周军战车与虎贲右翼', 24, 33, 'C4 G1'),
    g('egypt', '诸侯联军后列左翼', 12, 19, 'H3 A2'),
    g('egypt', '诸侯联军后列中军', 13, 25, 'H3 L2'),
    g('egypt', '诸侯联军后列右翼', 12, 31, 'H2 A2'),
    g('coalition', '商军前列', 47, 25, 'L24 H4'),
    g('coalition', '商王亲军', 62, 25, 'C3 G4 H5'),
    g('coalition', '商军左翼', 59, 17, 'C1 H6 L6 A4'),
    g('coalition', '商军右翼', 59, 33, 'C1 H6 L6 A4'),
  ], [[37, 24, '牧野接战地带'], [47, 25, '商军前列'], [63, 25, '帝辛王旗'],
    [71, 24, '朝歌方向']], { size: [76, 50], turnLimit: 34,
    losses: { egypt: 24, coalition: 56 }, evidence: 'medium',
    formationMorale: { '商军前列': 0.34, '商王亲军': 0.6,
      '商军左翼': 0.45, '商军右翼': 0.45 },
    historicalForce: '《史记》记周军战车三百乘、虎贲三千、甲士四万五千；商军七十万为古书记载，确数不可考。商军编组较多但不按该数字换算。' }),

  china_three_guards: p([56, 23], [
    ['ridge', 32, 7, 39, 15, 2], ['rv', 44, 4, 42, 1], ['road', 4, 23, 60, 23],
    ['road', 25, 10, 49, 17], ['city', 56, 23, 5, 5, 1],
  ], [[12, 22], [55, 23]], [
    g('egypt', '周公中军', 14, 22, 'C2 H4 G2'),
    g('egypt', '西路王师', 17, 10, 'C2 H3 A2'),
    g('egypt', '南路东征军', 20, 34, 'C2 H3 L2'),
    g('coalition', '武庚殷军', 54, 23, 'C2 H4 G2'),
    g('coalition', '三监北翼', 52, 11, 'C2 H3 A2'),
    g('coalition', '三监南翼', 51, 35, 'C2 H3 L2'),
  ], [[44, 17, '殷畿水道'], [56, 23, '殷旧都']], { breach: true }),

  china_zhou_xu: p([52, 22], [
    ['rv', 36, 3, 43, 2], ['rv', 48, 17, 42, 1], ['ridge', 51, 5, 58, 13, 2],
    ['road', 5, 22, 58, 22], ['road', 26, 33, 46, 31],
  ], [[11, 22], [55, 22]], [
    g('egypt', '王师中路', 12, 22, 'C3 H4 G2'),
    g('egypt', '淮北策应', 17, 10, 'C2 H3 A2'),
    g('egypt', '南渡部队', 19, 34, 'C1 H3 L2'),
    g('coalition', '徐夷渡口守军', 49, 22, 'C2 H4 A2'),
    g('coalition', '北岸诸部', 54, 11, 'C2 H3 L2'),
    g('coalition', '南岸诸部', 55, 34, 'C1 H3 A2'),
  ], [[36, 22, '淮泗渡口（示意）'], [48, 31, '支流']], { evidence: 'low' }),

  china_xuge: p([51, 22], [
    ['road', 5, 22, 61, 22], ['road', 27, 8, 40, 36],
  ], [[15, 22], [55, 22]], [
    g('egypt', '郑左拒·祭足', 20, 10, 'C3 H3 L1'),
    g('egypt', '鱼丽中军', 18, 23, 'C3 H4 G2'),
    g('egypt', '郑右拒·曼伯', 20, 35, 'C3 H3 L1'),
    g('coalition', '蔡卫右军', 48, 10, 'C2 H3 L2'),
    g('coalition', '周王中军', 53, 23, 'C3 H4 G2'),
    g('coalition', '陈国左军', 48, 35, 'C2 H3 L2'),
  ], [[31, 22, '鱼丽阵推进线'], [48, 35, '陈军薄弱翼']]),

  china_hongshui: p([51, 23], [
    ['rv', 33, 2, 44, 2], ['road', 6, 23, 57, 23], ['road', 28, 13, 38, 13],
    ['road', 28, 34, 38, 34],
  ], [[13, 22], [52, 22]], [
    g('egypt', '楚军先渡队', 31, 23, 'C1 H3 L2'),
    g('egypt', '楚军后队', 17, 18, 'C3 H4 A2'),
    g('egypt', '楚左翼', 17, 34, 'C2 H3 L2'),
    g('coalition', '宋襄公中军', 52, 23, 'C3 H4 G2'),
    g('coalition', '宋军北翼', 49, 10, 'C2 H3 A1'),
    g('coalition', '宋军南翼', 49, 35, 'C2 H3 A1'),
  ], [[33, 23, '泓水主渡口'], [52, 23, '宋军已成列']], { evidence: 'high' }),

  china_chengpu: p([51, 22], [
    ['road', 5, 22, 60, 22], ['ridge', 31, 8, 35, 12, 1],
    ['ridge', 30, 35, 36, 38, 1],
  ], [[15, 22], [54, 22]], [
    g('egypt', '晋下军·胥臣', 21, 9, 'C3 H3 L2'),
    g('egypt', '晋中军·先轸', 18, 22, 'C3 H4 G2'),
    g('egypt', '晋上军·狐毛', 21, 35, 'C3 H3 A2'),
    g('coalition', '楚右军·陈蔡', 49, 9, 'C2 H3 L2'),
    g('coalition', '楚中军·子玉', 53, 22, 'C3 H4 G2'),
    g('coalition', '楚左军', 49, 35, 'C3 H3 A2'),
  ], [[31, 9, '晋下军突破方向'], [31, 35, '晋上军佯退方向']]),

  china_xiao: p([7, 22], [
    ['ridge', 4, 7, 62, 7, 3], ['ridge', 4, 38, 62, 38, 3],
    ['ridge', 29, 11, 32, 17, 2], ['ridge', 39, 28, 43, 35, 2],
    ['road', 4, 22, 64, 22], ['road', 36, 18, 44, 23],
  ], [[55, 22], [32, 8]], [
    g('egypt', '秦归师前队', 29, 21, 'C2 H3 L2'),
    g('egypt', '孟明视中军', 47, 22, 'C2 H4 G2'),
    g('egypt', '秦军后队', 58, 25, 'C2 H3 A2'),
    g('coalition', '晋北侧伏兵', 31, 13, 'H4 A3 L2'),
    g('coalition', '晋南侧伏兵', 39, 32, 'H4 A3 L2'),
    g('coalition', '先轸阻截军', 15, 22, 'C2 H3 G2'),
  ], [[56, 22, '秦袭郑后返军'], [32, 22, '崤山狭道'], [7, 22, '秦归路']], { evidence: 'medium' }),

  china_bi: p([51, 22], [
    ['rv', 57, 2, 44, 3], ['road', 5, 22, 62, 22], ['road', 51, 12, 62, 12],
    ['road', 52, 33, 62, 33],
  ], [[13, 22], [52, 22]], [
    g('egypt', '楚庄王中军', 15, 22, 'C3 H4 G2'),
    g('egypt', '楚左军', 18, 11, 'C2 H3 A2'),
    g('egypt', '楚右军', 18, 34, 'C2 H3 L2'),
    g('coalition', '晋中军', 49, 22, 'C3 H4 G2'),
    g('coalition', '晋上军', 48, 11, 'C2 H3 A2'),
    g('coalition', '晋下军', 48, 34, 'C2 H3 L2'),
  ], [[57, 22, '黄河退路'], [49, 22, '晋军争渡方向']]),

  china_yanling: p([51, 22], [
    ['water', 29, 16, 35, 20], ['water', 28, 27, 34, 31],
    ['road', 6, 22, 60, 22], ['road', 31, 7, 31, 36],
  ], [[14, 22], [54, 22]], [
    g('egypt', '晋中军', 18, 22, 'C3 H4 G2'),
    g('egypt', '晋上军', 20, 10, 'C2 H3 A2'),
    g('egypt', '晋下军', 20, 35, 'C2 H3 L2'),
    g('coalition', '楚王卒', 53, 22, 'C3 H4 G2'),
    g('coalition', '楚左军', 50, 10, 'C2 H3 L2'),
    g('coalition', '郑军侧翼', 50, 35, 'C2 H3 A2'),
  ], [[31, 22, '晋军前方泽地'], [50, 35, '郑军不整翼']]),

  china_boju: p([51, 22], [
    ['rv', 55, 3, 43, 2], ['ridge', 32, 5, 41, 12, 2],
    ['ridge', 34, 32, 43, 39, 2], ['road', 6, 22, 62, 22],
    ['road', 38, 14, 45, 22],
  ], [[14, 22], [52, 22]], [
    g('egypt', '夫概先发队', 32, 20, 'H4 L3'),
    g('egypt', '吴王主力', 16, 22, 'C2 H4 G2'),
    g('egypt', '蔡军侧翼', 19, 34, 'C1 H3 A2'),
    g('coalition', '囊瓦楚中军', 50, 22, 'C2 H4 G2'),
    g('coalition', '楚北翼', 48, 11, 'C2 H3 A2'),
    g('coalition', '楚南翼', 48, 34, 'C2 H3 L2'),
  ], [[55, 22, '汉水退路'], [32, 20, '夫概突击方向']]),

  china_zuili: p([51, 22], [
    ['ridge', 26, 5, 34, 14, 2], ['ridge', 28, 30, 39, 40, 2],
    ['road', 5, 22, 60, 22], ['road', 33, 12, 35, 30],
  ], [[13, 22], [53, 22]], [
    g('egypt', '越王中军', 15, 22, 'C2 H4 G2'),
    g('egypt', '越军先锋', 29, 18, 'H4 L3'),
    g('egypt', '越军南翼', 20, 34, 'C1 H3 A2'),
    g('coalition', '吴王中军', 52, 22, 'C2 H4 G2'),
    g('coalition', '吴军北翼', 49, 10, 'C2 H3 A2'),
    g('coalition', '吴军南翼', 49, 34, 'C1 H3 L2'),
  ], [[30, 18, '槜李前沿'], [51, 22, '吴王本阵']]),

  china_guiji: p([51, 22], [
    ['ridge', 40, 6, 59, 16, 3], ['ridge', 40, 36, 59, 27, 3],
    ['ridge', 50, 14, 57, 28, 2], ['road', 4, 22, 56, 22],
    ['sea', 3, 41, 65, 45],
  ], [[13, 22], [52, 22]], [
    g('egypt', '吴军追击前锋', 28, 22, 'C2 H4 L2'),
    g('egypt', '夫差主力', 15, 22, 'C2 H4 G2'),
    g('egypt', '吴军南翼', 19, 33, 'C1 H3 A2'),
    g('coalition', '勾践会稽守军', 51, 22, 'H5 G2 A3'),
    g('coalition', '山口伏守', 45, 12, 'H2 L2 A2'),
    g('coalition', '山南警戒', 45, 33, 'H2 L2 A2'),
  ], [[50, 22, '会稽山口'], [55, 15, '越军山地据点']], { evidence: 'medium' }),

  china_yue_wu: p([55, 22], [
    ['rv', 39, 2, 40, 2], ['road', 4, 22, 61, 22],
    ['road', 30, 11, 55, 11], ['city', 55, 22, 5, 6, 2],
    ['sea', 3, 41, 66, 45],
  ], [[13, 22], [55, 22]], [
    g('egypt', '越军围城中军', 20, 22, 'H5 X3 G2 R2'),
    g('egypt', '越军北围', 20, 10, 'H4 A3'),
    g('egypt', '越军南围', 20, 34, 'H4 L2'),
    g('coalition', '吴王城防中军', 55, 22, 'H4 G2 A3'),
    g('coalition', '吴城北墙', 54, 13, 'H3 A2'),
    g('coalition', '吴城南墙', 54, 31, 'H3 A2'),
  ], [[55, 22, '姑苏城'], [39, 22, '城外水道']], { breach: true }),

  china_jin_partition: p([16, 22], [
    ['rh', 32, 4, 63, 2], ['road', 4, 22, 59, 22],
    ['city', 52, 22, 6, 6, 1, 'egypt'],
    ['water', 43, 14, 44, 31],
  ], [[49, 22], [15, 22]], [
    g('egypt', '赵氏晋阳守军', 52, 22, 'H4 G2 A2'),
    g('egypt', '韩军夜袭', 29, 9, 'C1 H4 L2'),
    g('egypt', '魏军截击', 27, 35, 'C1 H4 A2'),
    g('coalition', '智氏围城中军', 15, 22, 'C2 H5 G2'),
    g('coalition', '引水堤守军', 37, 30, 'H3 A2'),
    g('coalition', '智氏北营', 23, 9, 'C1 H3 A2'),
  ], [[46, 32, '引水堤'], [52, 22, '晋阳城']], { evidence: 'medium' }),

  china_wei_zhongshan: p([54, 22], [
    ['ridge', 32, 4, 42, 13, 2], ['ridge', 33, 38, 43, 29, 2],
    ['road', 4, 22, 60, 22], ['city', 54, 22, 5, 5, 1],
  ], [[12, 22], [54, 22]], [
    g('egypt', '乐羊攻城中军', 17, 22, 'C2 H5 X2 R2 G2'),
    g('egypt', '魏军北围', 20, 10, 'H3 A2'),
    g('egypt', '魏军南围', 20, 34, 'H3 L2'),
    g('coalition', '中山城守军', 54, 22, 'H5 G2 A3'),
    g('coalition', '中山北门', 51, 13, 'H3 A2'),
    g('coalition', '中山南门', 51, 31, 'H3 A2'),
  ], [[54, 22, '中山城'], [36, 22, '山间进军道']], { breach: true }),

  china_hexi_second: p([52, 22], [
    ['rv', 42, 2, 44, 2], ['ridge', 48, 4, 52, 17, 2],
    ['ridge', 48, 38, 52, 28, 2], ['road', 5, 22, 61, 22],
    ['wall', 49, 16, 49, 28, 1],
  ], [[13, 22], [52, 22]], [
    g('egypt', '秦军攻阴晋中军', 15, 22, 'C3 H5 G2'),
    g('egypt', '秦军北翼', 19, 10, 'C2 H3 A2'),
    g('egypt', '秦军南翼', 19, 35, 'C2 H3 L2'),
    g('coalition', '吴起魏武卒', 50, 22, 'H6 X3 G2'),
    g('coalition', '魏军北阵', 53, 11, 'H3 A2'),
    g('coalition', '魏军南阵', 53, 34, 'H3 A2'),
  ], [[42, 22, '河西水道'], [49, 22, '阴晋防线']]),

  china_guiling: p([45, 23], [
    ['road', 4, 23, 62, 23], ['road', 34, 7, 40, 39],
    ['ridge', 28, 7, 38, 13, 2], ['ridge', 31, 35, 42, 38, 2],
  ], [[14, 22], [53, 23]], [
    g('egypt', '齐军截击中军', 18, 23, 'C2 H4 X3 G2'),
    g('egypt', '齐北侧机动军', 30, 12, 'V2 H3 A2'),
    g('egypt', '齐南侧机动军', 31, 34, 'V2 H3 A2'),
    g('coalition', '庞涓魏军归师', 50, 23, 'C2 H5 G2'),
    g('coalition', '魏军先遣', 42, 21, 'V2 H3'),
    g('coalition', '魏军后队', 57, 30, 'C1 H3 X2'),
  ], [[45, 23, '魏军归路'], [36, 23, '桂陵截击点']]),

  china_maling: p([44, 22], [
    ['ridge', 5, 6, 63, 9, 3], ['ridge', 5, 38, 63, 35, 3],
    ['ridge', 31, 11, 36, 18, 2], ['ridge', 35, 29, 41, 35, 2],
    ['road', 5, 22, 62, 22],
  ], [[16, 10], [53, 22]], [
    g('egypt', '齐军北坡伏弩', 35, 14, 'X5 A2 H2'),
    g('egypt', '齐军南坡伏弩', 40, 31, 'X5 A2 H2'),
    g('egypt', '齐军截归路', 24, 22, 'H4 V2 G2'),
    g('coalition', '魏军前锋', 43, 22, 'V2 H4'),
    g('coalition', '庞涓中军', 52, 22, 'C2 H5 G2'),
    g('coalition', '魏军后队', 59, 28, 'C1 H3 X2'),
  ], [[38, 22, '马陵狭道'], [35, 14, '北坡伏弩'], [40, 31, '南坡伏弩']]),

  china_hexi_third: p([52, 22], [
    ['rv', 37, 2, 43, 2], ['ridge', 45, 4, 51, 15, 2],
    ['ridge', 45, 39, 51, 30, 2], ['road', 5, 22, 62, 22],
    ['wall', 51, 17, 51, 28, 1],
  ], [[13, 22], [54, 22]], [
    g('egypt', '秦军西河中军', 16, 22, 'C2 H5 X3 G2'),
    g('egypt', '秦北路', 20, 11, 'V2 H3 X2'),
    g('egypt', '秦南路', 20, 34, 'V2 H3 L2'),
    g('coalition', '魏军雕阴守军', 53, 22, 'H5 X3 G2'),
    g('coalition', '魏北翼', 53, 10, 'C1 H3 A2'),
    g('coalition', '魏南翼', 53, 35, 'C1 H3 A2'),
  ], [[37, 22, '河西水道'], [51, 22, '雕阴防线']]),

  china_alliance_qin: p([13, 22], [
    ['ridge', 26, 3, 29, 17, 3], ['ridge', 26, 40, 29, 27, 3],
    ['road', 4, 22, 62, 22], ['wall', 26, 18, 26, 26, 2],
  ], [[54, 22], [15, 22]], [
    g('egypt', '魏军合纵中军', 50, 22, 'C2 H4 X2 G2'),
    g('egypt', '赵燕北路', 49, 10, 'V2 H3 A2'),
    g('egypt', '韩楚南路', 49, 34, 'C1 H4 X2'),
    g('coalition', '秦军函谷关守军', 25, 22, 'H5 X4 G2'),
    g('coalition', '秦关西北备队', 17, 11, 'V2 H3'),
    g('coalition', '秦关西南备队', 17, 34, 'V2 H3'),
  ], [[26, 22, '函谷关'], [13, 22, '关西通道']], { evidence: 'medium' }),

  china_qin_bashu: p([51, 22], [
    ['ridge', 5, 5, 62, 8, 3], ['ridge', 6, 39, 62, 36, 3],
    ['ridge', 31, 13, 40, 18, 2], ['road', 4, 22, 62, 22],
    ['road', 36, 17, 41, 28],
  ], [[12, 22], [53, 22]], [
    g('egypt', '司马错石牛道主力', 15, 22, 'H5 X3 G2'),
    g('egypt', '秦军山道先遣', 31, 22, 'H4 L3'),
    g('egypt', '秦军南侧队', 18, 32, 'H3 A2'),
    g('coalition', '蜀军葭萌守兵', 52, 22, 'H5 G2 A3'),
    g('coalition', '蜀军北坡', 46, 12, 'H3 A2'),
    g('coalition', '巴地南侧警戒', 47, 34, 'H3 L2'),
  ], [[35, 22, '石牛道（示意）'], [52, 22, '葭萌要道']], { evidence: 'medium' }),

  china_qi_yan: p([54, 22], [
    ['rv', 35, 2, 43, 2], ['road', 5, 22, 61, 22],
    ['city', 54, 22, 5, 5, 1],
  ], [[13, 22], [54, 22]], [
    g('egypt', '齐军攻燕中军', 17, 22, 'C2 H5 X3 R2 G2'),
    g('egypt', '齐军北路', 20, 10, 'V2 H3 X2'),
    g('egypt', '齐军南路', 20, 34, 'V2 H3 L2'),
    g('coalition', '燕都守军', 54, 22, 'H5 X2 G2'),
    g('coalition', '燕北城防', 52, 12, 'H3 A2'),
    g('coalition', '燕南城防', 52, 33, 'H3 A2'),
  ], [[54, 22, '燕都'], [35, 22, '进军渡口']], { breach: true }),

  china_lantian: p([50, 22], [
    ['rv', 38, 2, 44, 2], ['ridge', 29, 5, 35, 15, 2],
    ['ridge', 29, 40, 35, 30, 2], ['road', 5, 22, 62, 22],
  ], [[14, 22], [52, 22]], [
    g('egypt', '秦军蓝田中军', 17, 22, 'C2 H5 X3 G2'),
    g('egypt', '秦军北路', 21, 11, 'V2 H3 X2'),
    g('egypt', '秦军南路', 21, 34, 'V2 H3 L2'),
    g('coalition', '楚军主阵', 51, 22, 'C3 H5 G2'),
    g('coalition', '楚军北翼', 50, 10, 'C2 H3 A2'),
    g('coalition', '楚军南翼', 50, 35, 'C2 H3 A2'),
  ], [[38, 22, '蓝田水道'], [50, 22, '楚军中军']]),

  china_chui_sha: p([52, 22], [
    ['rv', 39, 2, 44, 2], ['ridge', 46, 5, 50, 14, 2],
    ['road', 5, 22, 62, 22], ['road', 35, 11, 44, 11],
    ['road', 35, 34, 44, 34],
  ], [[13, 22], [54, 22]], [
    g('egypt', '匡章齐军中军', 18, 22, 'H5 X4 G2'),
    g('egypt', '韩军北渡', 24, 10, 'H4 X2'),
    g('egypt', '魏军南渡', 24, 34, 'C1 H4 X2'),
    g('coalition', '唐昧楚军守渡', 53, 22, 'C2 H5 G2 A2'),
    g('coalition', '楚军上游警戒', 49, 10, 'H3 A3'),
    g('coalition', '楚军下游警戒', 49, 34, 'H3 A3'),
  ], [[39, 22, '沘水浅滩（推定）'], [52, 22, '楚军河东阵地']], { evidence: 'medium' }),

  china_yique: p([51, 22], [
    ['ridge', 30, 3, 36, 17, 3], ['ridge', 30, 41, 36, 27, 3],
    ['road', 5, 22, 62, 22], ['road', 34, 12, 43, 16],
  ], [[13, 22], [53, 22]], [
    g('egypt', '白起秦军中军', 17, 22, 'H5 X4 G2'),
    g('egypt', '秦军北侧迂回', 29, 13, 'V2 H3 X2'),
    g('egypt', '秦军南侧迂回', 29, 33, 'V2 H3 X2'),
    g('coalition', '韩军北阵', 50, 10, 'H5 X2 G1'),
    g('coalition', '魏军南阵', 50, 34, 'H5 X2 G1'),
    g('coalition', '韩魏接合部', 51, 22, 'H3 X2'),
  ], [[34, 22, '伊阙山口'], [51, 22, '韩魏两军接合部']]),

  china_qi_song: p([54, 22], [
    ['rv', 33, 2, 43, 2], ['road', 4, 22, 62, 22],
    ['city', 54, 22, 5, 5, 1],
  ], [[13, 22], [54, 22]], [
    g('egypt', '齐军攻宋中军', 17, 22, 'H5 X3 R2 G2'),
    g('egypt', '齐军北围', 20, 10, 'V2 H3 X2'),
    g('egypt', '齐军南围', 20, 34, 'V2 H3 L2'),
    g('coalition', '宋都守军', 54, 22, 'H5 X2 G2'),
    g('coalition', '宋北城防', 53, 12, 'H3 A2'),
    g('coalition', '宋南城防', 53, 33, 'H3 A2'),
  ], [[54, 22, '宋都'], [33, 22, '城西水道']], { breach: true }),

  china_alliance_qi: p([50, 22], [
    ['rv', 37, 2, 44, 2], ['road', 5, 22, 62, 22],
    ['ridge', 30, 5, 35, 15, 2], ['ridge', 30, 40, 35, 30, 2],
  ], [[13, 22], [52, 22]], [
    g('egypt', '乐毅燕军中军', 17, 22, 'H5 X4 G2'),
    g('egypt', '秦赵北翼', 21, 10, 'V3 H3 X2'),
    g('egypt', '韩魏南翼', 21, 34, 'C1 H4 X2'),
    g('coalition', '齐军济西中军', 51, 22, 'H5 X3 G2'),
    g('coalition', '齐军北翼', 51, 10, 'V2 H3 A2'),
    g('coalition', '齐军南翼', 51, 34, 'V2 H3 A2'),
  ], [[37, 22, '济水渡口'], [50, 22, '济西齐军主阵']]),

  china_tian_dan: p([15, 22], [
    ['road', 5, 22, 63, 22], ['city', 55, 22, 5, 6, 2, 'egypt'],
    ['ridge', 28, 5, 35, 12, 1], ['ridge', 28, 38, 35, 31, 1],
  ], [[54, 22], [15, 22]], [
    g('egypt', '田单即墨守军', 55, 22, 'H4 X3 G2'),
    g('egypt', '火牛突击队', 47, 22, 'O4 H3 L2'),
    g('egypt', '城门接应队', 51, 31, 'H3 X2'),
    g('coalition', '燕军围城主营', 16, 22, 'H5 X3 G2'),
    g('coalition', '燕北围营', 24, 10, 'V2 H3 A2'),
    g('coalition', '燕南围营', 24, 34, 'V2 H3 A2'),
  ], [[55, 22, '即墨城'], [47, 22, '火牛出击口'], [15, 22, '燕军主营']]),

  china_yan_ying: p([55, 22], [
    ['rv', 38, 2, 44, 2], ['road', 5, 22, 62, 22],
    ['city', 55, 22, 5, 6, 2], ['water', 48, 9, 51, 13],
  ], [[13, 22], [55, 22]], [
    g('egypt', '白起秦军中军', 17, 22, 'H6 X4 R2 G2'),
    g('egypt', '秦军北路', 21, 10, 'V2 H3 X2'),
    g('egypt', '秦军南路', 21, 34, 'V2 H3 L2'),
    g('coalition', '楚军鄢郢守军', 55, 22, 'H5 X2 G2'),
    g('coalition', '楚北城防', 53, 12, 'H3 A2'),
    g('coalition', '楚南城防', 53, 33, 'H3 A2'),
  ], [[38, 22, '鄢郢水系（概化）'], [55, 22, '楚都防线']], { breach: true, evidence: 'low' }),

  china_eyu: p([55, 26], [
    ['ridge', 25, 11, 48, 11, 3], ['ridge', 42, 13, 50, 20, 2],
    ['ridge', 31, 3, 43, 7, 2], ['road', 5, 28, 63, 28],
    ['road', 23, 24, 34, 11], ['road', 40, 12, 53, 26],
  ], [[16, 25], [55, 26]], [
    g('egypt', '赵军北山先占队', 37, 10, 'H5 X3 L2'),
    g('egypt', '赵奢急行中军', 18, 25, 'H5 G2 X2'),
    g('egypt', '赵军山脚接应', 29, 29, 'H3 V2'),
    g('coalition', '秦军攻山前队', 46, 20, 'H5 X3'),
    g('coalition', '秦军阏与中军', 55, 26, 'H5 G2 X2'),
    g('coalition', '秦军南翼', 52, 36, 'V2 H3 X2'),
  ], [[37, 10, '北山：赵军先占'], [46, 20, '秦军山脚'], [55, 26, '秦军主阵']],
  { size: [70, 46], evidence: 'high' }),

  china_changping: p([57, 28], [
    ['ridge', 24, 5, 24, 49, 2],
    ['rv', 42, 3, 51, 2],
    ['wall', 45, 11, 77, 11, 2],
    ['ridge', 55, 7, 60, 15, 2], ['ridge', 57, 36, 64, 45, 2],
    ['road', 4, 28, 78, 28], ['road', 19, 18, 48, 18],
    ['road', 19, 40, 50, 40], ['road', 38, 28, 58, 28],
    ['road', 59, 14, 60, 43],
    ['wall', 27, 10, 27, 44, 1],
    ['wall', 46, 12, 46, 42, 2],
  ], [[11, 28], [58, 18]], [
    g('egypt', '秦军北路前锋', 19, 15, 'H5 V3'),
    g('egypt', '秦军北路弩队', 15, 16, 'X3'),
    g('egypt', '秦军高平关攻坚队', 19, 27, 'H9 G3'),
    g('egypt', '秦军中路弩队', 15, 27, 'X6'),
    g('egypt', '秦军南路前锋', 19, 39, 'H5 V3'),
    g('egypt', '秦军南路弩队', 15, 39, 'X3'),
    g('egypt', '秦军北路后队', 9, 18, 'H5 V2 X2'),
    g('egypt', '秦军南路后队', 9, 36, 'H5 V2 X2'),
    g('egypt', '秦军中军预备队', 7, 28, 'H6 X3'),
    g('coalition', '赵军空仓岭北段步阵', 29, 13, 'H3'),
    g('coalition', '赵军空仓岭北段弩队', 32, 13, 'X1'),
    g('coalition', '赵军空仓岭北中段步阵', 29, 20, 'H2'),
    g('coalition', '赵军空仓岭北中段弩队', 32, 20, 'X2'),
    g('coalition', '赵军空仓岭关口步阵', 29, 27, 'H3'),
    g('coalition', '赵军空仓岭关口弩队', 32, 27, 'X1'),
    g('coalition', '赵军空仓岭南中段步阵', 29, 34, 'H2'),
    g('coalition', '赵军空仓岭南中段弩队', 32, 34, 'X2'),
    g('coalition', '赵军空仓岭南段步阵', 29, 41, 'H3'),
    g('coalition', '赵军空仓岭南段弩队', 32, 41, 'X1'),
    g('coalition', '赵军丹水北段步阵', 48, 15, 'H3'),
    g('coalition', '赵军丹水北段弩队', 51, 15, 'X2'),
    g('coalition', '赵军丹水北中段步阵', 48, 21, 'H3'),
    g('coalition', '赵军丹水北中段弩队', 51, 21, 'X2'),
    g('coalition', '赵军丹水中段步阵', 48, 27, 'H4 G1'),
    g('coalition', '赵军丹水中段弩队', 51, 27, 'X2'),
    g('coalition', '赵军丹水南中段步阵', 48, 34, 'H3'),
    g('coalition', '赵军丹水南中段弩队', 51, 34, 'X2'),
    g('coalition', '赵军丹水南段步阵', 48, 40, 'H3'),
    g('coalition', '赵军丹水南段弩队', 51, 40, 'X3'),
    g('coalition', '赵军石长城西段', 55, 12, 'H5 X3'),
    g('coalition', '赵军石长城东段', 68, 12, 'H3 X2'),
    g('coalition', '赵军韩王山指挥营', 58, 20, 'H2 X1 G2'),
    g('coalition', '赵军大粮山后队', 61, 40, 'H4 X1'),
  ], [[24, 19, '空仓岭'], [27, 25, '赵军空仓岭一级防线'], [42, 28, '丹水'],
    [46, 25, '赵军丹水二级防线'], [59, 11, '百里石长城二级防线'],
    [58, 18, '韩王山'], [61, 40, '大粮山'], [11, 28, '秦军自西向东进攻']],
  { size: [82, 54], turnLimit: 42, losses: { egypt: 35, coalition: 36 }, evidence: 'high',
    historicalForce: '《史记》记赵军前后损失四十五万人；秦军在场确数未载。68枚秦军、72枚赵军棋子代表大编组，并非一枚对应固定人数。' }),

  china_handan: p([17, 22], [
    ['road', 4, 22, 62, 22], ['city', 54, 22, 5, 6, 2, 'egypt'],
    ['ridge', 32, 4, 37, 14, 1], ['ridge', 32, 39, 37, 30, 1],
  ], [[55, 22], [17, 22]], [
    g('egypt', '邯郸赵军守城', 54, 22, 'H5 X3 G2'),
    g('egypt', '信陵君魏军援兵', 27, 10, 'H5 X3 V2'),
    g('egypt', '楚军南路援兵', 27, 34, 'H5 X2 V2'),
    g('coalition', '秦军围城中军', 17, 22, 'H6 X3 G2'),
    g('coalition', '秦军北围营', 39, 10, 'H3 X2'),
    g('coalition', '秦军南围营', 39, 34, 'H3 X2'),
  ], [[54, 22, '邯郸城'], [27, 10, '魏军解围方向'], [27, 34, '楚军解围方向']]),

  china_qin_zhao: p([54, 22], [
    ['ridge', 28, 5, 35, 15, 2], ['ridge', 28, 39, 35, 30, 2],
    ['road', 5, 22, 62, 22], ['city', 54, 22, 5, 6, 2],
  ], [[13, 22], [54, 22]], [
    g('egypt', '王翦秦军攻城中军', 17, 22, 'H6 X4 R2 G2'),
    g('egypt', '秦军北路', 21, 10, 'V2 H4 X2'),
    g('egypt', '秦军南路', 21, 34, 'V2 H4 X2'),
    g('coalition', '赵军邯郸城守', 54, 22, 'H5 X3 G2'),
    g('coalition', '赵军北外郭', 51, 12, 'H3 X2'),
    g('coalition', '赵军南外郭', 51, 33, 'H3 X2'),
  ], [[54, 22, '邯郸城'], [33, 22, '西面进攻通道']], { breach: true }),

  china_qin_chu: p([68, 27], [
    ['rv', 48, 3, 51, 2], ['road', 5, 27, 82, 27],
    ['road', 27, 18, 67, 18], ['road', 27, 36, 67, 36],
    ['ridge', 34, 6, 41, 18, 2], ['ridge', 35, 46, 41, 36, 2],
    ['posts', 21, 18, 21, 36, 1, 'egypt'],
  ], [[17, 27], [68, 27]], [
    g('egypt', '王翦秦军营垒', 19, 27, 'H12 X7 G4'),
    g('egypt', '秦军北路预备', 25, 18, 'V6 H8 X4'),
    g('egypt', '秦军南路追击', 28, 36, 'V6 H8 X4'),
    g('egypt', '秦军追击前锋', 37, 28, 'V4 H7 X3'),
    g('coalition', '项燕楚军主力', 68, 27, 'H13 X6 G4'),
    g('coalition', '楚军北翼', 65, 18, 'V6 H8 A3'),
    g('coalition', '楚军南翼', 65, 36, 'V6 H8 A3'),
    g('coalition', '楚军后队', 77, 28, 'H8 X4'),
  ], [[21, 27, '秦军坚壁营'], [48, 27, '楚军东移通道'], [68, 27, '项燕主阵'],
    [28, 36, '秦军追击南路'], [77, 28, '楚军东撤后队']],
  { size: [88, 54], turnLimit: 40, losses: { egypt: 37, coalition: 35 }, evidence: 'medium',
    historicalForce: '《史记》记王翦统兵六十万、楚悉国中兵；楚军确数未载。74枚秦军、70枚楚军棋子代表大编组，并非一枚对应固定人数。' }),
};

// Most open-field armies use three nearby lanes off the main road. Preserve
// separate ambush, mountain, siege-wall and deep-defense positions by keeping
// those battle plans outside this list.
const COMPACT_THREE_ARMY_IDS = new Set([
  'china_three_guards', 'china_zhou_xu', 'china_xuge', 'china_hongshui',
  'china_chengpu', 'china_bi', 'china_yanling', 'china_boju', 'china_zuili',
  'china_yue_wu', 'china_wei_zhongshan', 'china_hexi_second',
  'china_hexi_third', 'china_alliance_qin', 'china_qin_bashu', 'china_qi_yan',
  'china_lantian', 'china_qi_song', 'china_alliance_qi', 'china_yan_ying',
  'china_handan', 'china_qin_zhao',
]);

function compactThreeArmies(plan) {
  const mainRoad = plan.features.filter(f => f[0] === 'road' && f[2] === f[4])
    .sort((a, b) => Math.abs(b[3] - b[1]) - Math.abs(a[3] - a[1]))[0];
  if (!mainRoad) return plan;
  const centerRow = mainRoad[2], city = plan.features.find(f => f[0] === 'city');
  const atCity = ([, , c]) => city && Math.abs(c - city[1]) <= city[3] + 2;
  const nearerRow = r => Math.abs(r - centerRow) < 8 ? r :
    centerRow + Math.round((r - centerRow) * 0.55);
  const compacted = plan.groups.map(group => {
    const [team, name, c, r, units] = group;
    return atCity(group) ? group : g(team, name, c, nearerRow(r), units);
  });
  const spurs = [];
  for (let i = 0; i < compacted.length; i++) {
    const [, , c, r] = compacted[i];
    if (r === plan.groups[i][3]) continue;
    spurs.push(['road', c, centerRow, c, r], ['road', c - 3, r, c + 3, r]);
  }
  const landmarks = plan.landmarks.map(([c, r, label]) => {
    const i = plan.groups.findIndex(group => group[2] === c && group[3] === r);
    return i < 0 ? [c, r, label] : [c, compacted[i][3], label];
  });
  // Draw spurs first so rivers, ridges, walls and city features keep priority.
  return { ...plan, groups: compacted, landmarks, features: [...spurs, ...plan.features] };
}

export const CHINA_BATTLE_PLANS = Object.freeze(Object.fromEntries(
  Object.entries(RAW_CHINA_BATTLE_PLANS).map(([id, plan]) =>
    [id, COMPACT_THREE_ARMY_IDS.has(id) ? compactThreeArmies(plan) : plan])));
