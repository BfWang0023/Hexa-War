// Authoritative, saved movement evidence. No renderer or model state participates.
import {distance,unitStats,meleePower,isRouted} from './engine.mjs';
export const CHARGE_RULES_VERSION=15;
export const DEFAULT_CHARGE_RULES=Object.freeze({cavalry:1.25,heavyChariot:1.30});
export const usesChargeRules=s=>s.rulesVersion>=CHARGE_RULES_VERSION;
export function chargeConfig(value=DEFAULT_CHARGE_RULES){if(!value||typeof value!=='object'||Array.isArray(value))throw Error('冲锋规则参数无效');const v={...DEFAULT_CHARGE_RULES,...value};if(Object.keys(v).some(k=>!Object.hasOwn(DEFAULT_CHARGE_RULES,k))||Object.values(v).some(n=>!Number.isFinite(n)||n<1||n>2))throw Error('冲锋倍率须在1至2之间');return v;}
// Older saves retain their explicit historical cavalry eligibility. New games use only shock profiles.
const legacyLightCharge=new Set(['cavalry','romanAlliedHorse','zamaPunicHorse','parthianHorseArcher','numidianHorse','masinissa','masinissaHorse']);
export function chargeClass(m,u,rulesVersion=21){const stat=u&&unitStats(m,u),c=rulesVersion<21?(stat?.chargeClass||(legacyLightCharge.has(u?.kind)?'cavalry':null)):(stat?.mountedRole==='shock'?stat.chargeClass:null);return u&&u.hp>0&&!u.aboard&&!u.onFoot&&!isRouted(u)&&meleePower(u,m)>0&&['cavalry','heavyChariot'].includes(c)?c:null;}
export const DEFAULT_CHARGE_CRITICAL_RULES=Object.freeze({chance:0.20,multiplier:1.9});
export function chargeCriticalConfig(value=DEFAULT_CHARGE_CRITICAL_RULES){
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('冲锋暴击规则无效');
 const v={...DEFAULT_CHARGE_CRITICAL_RULES,...value};
 if(Object.keys(v).some(k=>!Object.hasOwn(DEFAULT_CHARGE_CRITICAL_RULES,k))||!Number.isFinite(v.chance)||v.chance<0||v.chance>1||!Number.isFinite(v.multiplier)||v.multiplier<1||v.multiplier>3)throw Error('冲锋暴击概率或倍率无效');return v;
}
export function resolveChargeCritical(s,effect,roll){const cfg=chargeCriticalConfig(s.chargeCriticalRules),eligible=s.rulesVersion>=17&&!!effect?.triggered;
 const triggered=eligible&&Number.isFinite(roll)&&roll>=0&&roll<1&&roll<cfg.chance;
 return {eligible,triggered,chance:eligible?cfg.chance:0,multiplier:triggered?cfg.multiplier:1};
}
const point=p=>({c:p.c,r:p.r}),same=(a,b)=>a&&b&&a.c===b.c&&a.r===b.r;
export function interruptCharge(s,id){if(s.rulesVersion>=20)s.ramRuns={};if(usesChargeRules(s)&&s.chargeRuns)s.chargeRuns={};}
export function runMatches(s,u,run){return !!run&&run.turn===s.turn&&run.team===s.side&&u.team===run.team&&run.kind===u.kind&&run.actionsLeft===u.actionsLeft&&run.movesUsed===(u.movesUsed||0)&&run.attacksUsed===(u.attacksUsed||0)&&same(run.points.at(-1),u);}
export function movementRun(s,u,from,path,previous){const points=[...(runMatches(s,{...u,...from,actionsLeft:previous?.actionsLeft,movesUsed:previous?.movesUsed},previous)?previous.points:[point(from)]),...path.map(point)];return {turn:s.turn,team:u.team,kind:u.kind,actionsLeft:u.actionsLeft,movesUsed:u.movesUsed||0,attacksUsed:u.attacksUsed||0,points,blocked:!!previous?.blocked||new Set(points.map(p=>p.c+','+p.r)).size!==points.length||points.length>32};}
// One uninterrupted action chain: another unit acting also breaks the run.
// Called with the actor before any mutation; a paid unrelated action invalidates
// its resource fingerprint even when that action has no movement animation.
export function recordChargeMove(s,u,from,path,before){if(!usesChargeRules(s))return;const previous=s.chargeRuns?.[u.id];const continuing=runMatches(s,before,previous);s.chargeRuns={};if(chargeClass(s.map,u,s.rulesVersion))s.chargeRuns[u.id]=movementRun(s,u,from,path,continuing?previous:null);else delete s.chargeRuns[u.id];}
export function chargeEffect(s,u,target,melee,record=s.chargeRuns?.[u?.id]){const type=chargeClass(s.map,u,s.rulesVersion),answer={eligible:!!type,triggered:false,multiplier:1,reason:!usesChargeRules(s)?'本局采用旧版冲锋规则':!type?'本兵种不具备近战冲锋能力':!melee?'仅近战可触发':'需立即接近目标至少两格'};if(!usesChargeRules(s)||!type||!melee||!target||target.team===u.team||target.kind==='fort'||target.kind==='captive'||isRouted(target)||distance(u,target)!==1)return answer;
 if(!runMatches(s,u,record))return {...answer,reason:'本回合没有未中断的合法助跑'};if(record.blocked)return {...answer,reason:'助跑包含往返或重复地格'};if(record.points.length<3)return {...answer,reason:'实际连续移动不足两格'};
 const tail=record.points.slice(-3),ds=tail.map(p=>distance(p,target));if(!tail.slice(1).every((p,i)=>distance(tail[i],p)===1)||!(ds[0]>ds[1]&&ds[1]>ds[2]))return {...answer,reason:'最后两步未持续接近当前目标'};
 return {...answer,triggered:true,multiplier:chargeConfig(s.chargeRules)[type],...(s.rulesVersion>=17?{critical:chargeCriticalConfig(s.chargeCriticalRules)}:{}),reason:'合法连续推进，近战冲锋'};
}
export const chargeText=e=>e.triggered?`冲锋：伤害 ×${e.multiplier.toFixed(2)}（最后两步持续接近）${e.critical?`；命中后 ${(e.critical.chance*100).toFixed(0)}% 暴击，基础伤害 ×${e.critical.multiplier.toFixed(2)}（替代冲锋倍率）`:''}`:`冲锋未触发：${e.reason}`;
export function validateChargeState(s){chargeConfig(s.chargeRules);if(s.rulesVersion>=17){if(!s.chargeCriticalRules)throw Error('新版存档缺少冲锋暴击规则');chargeCriticalConfig(s.chargeCriticalRules);}if(!s.chargeRuns||typeof s.chargeRuns!=='object'||Array.isArray(s.chargeRuns)||Object.keys(s.chargeRuns).length>10000)throw Error('存档冲锋记录无效');for(const [id,r]of Object.entries(s.chargeRuns)){const u=s.map.units.find(u=>u.id===id);if(!u||!r||!Array.isArray(r.points)||r.points.length<2||r.points.length>32||typeof r.blocked!=='boolean'||!runMatches(s,u,r)||r.points.some(p=>!Number.isInteger(p.c)||!Number.isInteger(p.r)||p.c<0||p.r<0||p.c>=s.map.cols||p.r>=s.map.rows)||r.points.slice(1).some((p,i)=>distance(r.points[i],p)!==1))throw Error('存档冲锋路径无效');}}
