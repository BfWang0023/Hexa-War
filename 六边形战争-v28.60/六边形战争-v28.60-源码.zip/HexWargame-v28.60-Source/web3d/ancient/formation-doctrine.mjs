import {planningState} from './fog-policy.mjs';
// Layout geometry grants no combat bonuses. Only the original move/form actions may mutate a game.
import {reachable,inBounds,mobileAt,neighbors,distance,visibleTo,key,TERRAIN,tile,isFormableInfantry} from './engine.mjs';
import {centroid,hexFromPlane,plane,vectorFor,around} from './battlefield-space.mjs';
import {resolveLocation} from './tactical-location.mjs';
import {directionIndex} from './tactical-units.mjs';
export const FORMATION_DOCTRINE=Object.freeze({
 line:{name:'横队',rows:2,spacing:1,description:'正面宽、纵深浅；逐单位支付移动，防御姿态另用原列阵动作'},
 column:{name:'纵队',columns:2,spacing:1,description:'窄正面行军队形；道路模式只分配已知道路阵位'},
 square:{name:'方阵',spacing:1,description:'方形几何部署，无额外防御或反骑兵规则'},
 wedge:{name:'楔形阵',spacing:1,description:'前窄后宽，按朝向生成尖端和后续梯队'},
 skirmish:{name:'散兵阵',rows:2,spacing:2,description:'扩大格间距离，不改变命中或防御数值'},
 dense:{name:'密集防御阵型',rows:3,spacing:1,formed:true,description:'紧密多排；可列阵兵种须按原规则付行动，无列阵能力者反馈姿态不受支持'},
});
export function formationSlots(count,{shape='line',rows,columns,spacing,direction=0,anchor}={}){
 if(!FORMATION_DOCTRINE[shape]||!Number.isInteger(count)||count<1||count>1024)throw Error('阵型或规模无效');const doctrine=FORMATION_DOCTRINE[shape],gap=spacing??doctrine.spacing,f=vectorFor(direction),l={x:f.z,z:-f.x},a=plane(anchor),coords=[];
 if(shape==='wedge'){for(let r=0;coords.length<count;r++)for(let c=-r;c<=r&&coords.length<count;c++)coords.push({front:-r,left:c});}
 else {const width=shape==='column'?columns||2:shape==='square'?Math.ceil(Math.sqrt(count)):Math.ceil(count/(rows||doctrine.rows||2)),depth=Math.ceil(count/width);for(let i=0;i<count;i++){const r=Math.floor(i/width),c=i%width;coords.push({front:(depth-1)/2-r,left:c-(Math.min(width,count-r*width)-1)/2});}}
 const used=new Set();return coords.map((v,i)=>{const ideal=hexFromPlane({x:a.x+gap*(v.front*f.x+v.left*l.x),z:a.z+gap*(v.front*f.z+v.left*l.z)});const p=around(ideal,1).find(p=>!used.has(key(p.c,p.r)));if(!p)throw Error('阵型几何产生重叠');used.add(key(p.c,p.r));return {...p,slot:i+1,row:shape==='wedge'?Math.round(-v.front)+1:Math.floor(i/(shape==='column'?columns||2:shape==='square'?Math.ceil(Math.sqrt(count)):Math.ceil(count/(rows||doctrine.rows||2))))+1};});
}
export function createPlacementProbe(state,units){state=planningState(state,state.side);
 const selected=new Set(units.map(u=>u.id)),map={...state.map,units:state.map.units.filter(u=>!selected.has(u.id))},shadow={...state,map},cache=new Map();
 return (u,p)=>{if(!inBounds(map,p.c,p.r)||!visibleTo(state,u.team,p.c,p.r)||mobileAt(map,p.c,p.r))return false;const k=[u.kind,u.team,u.onFoot?1:0,p.c,p.r].join(':');if(cache.has(k))return cache.get(k);let ok=false;
  // Ask reachable about a one-edge destination on a read-only virtual actor. No copied terrain rules.
  for(const n of neighbors(p.c,p.r)){if(!inBounds(map,n.c,n.r))continue;const virtual={...u,...n,actionsLeft:2,formed:false,formationSteps:0,movesUsed:0};if(reachable(shadow,virtual).has(key(p.c,p.r))){ok=true;break;}}
  cache.set(k,ok);return ok;};
}
export function* iterateFormationPlan(state,units,parameters,context){state=planningState(state,context.team);
 const start=performance.now(),ref=parameters.anchor?resolveLocation(state,parameters.anchor,context,units):{position:hexFromPlane(centroid(units)),frame:context.frame,description:'当前部队中心'},heading=parameters.direction!==undefined?directionIndex(parameters.direction,ref.frame):ref.frame.heading;
 const slots=formationSlots(units.length,{...parameters,direction:heading,anchor:ref.position}),probe=createPlacementProbe(state,units),remaining=[...units],reserved=new Set(),assignments=[];
 const fixed=new Set(units.filter(u=>u.actionsLeft<=0).map(u=>key(u.c,u.r)));let adjusted=0;
 for(const slot of slots){remaining.sort((a,b)=>distance(a,slot)-distance(b,slot)||a.id.localeCompare(b.id));let choice=null;
  for(const u of remaining){const p=around(slot,parameters.adjustRadius??2).find(p=>!reserved.has(key(p.c,p.r))&&(!fixed.has(key(p.c,p.r))||p.c===u.c&&p.r===u.r)&&(!parameters.alongRoad||(tile(state.map,p.c,p.r)?.terrain&TERRAIN.ROAD))&&probe(u,p));if(p){choice={u,p};break;}}
  if(!choice){const u=remaining.shift();assignments.push({id:u.id,from:{c:u.c,r:u.r},desired:{c:slot.c,r:slot.r},to:null,reason:'阵位被地形、视野或占据限制，附近没有合法空位',row:slot.row});yield;continue;}
  const {u,p}=choice;remaining.splice(remaining.indexOf(u),1);reserved.add(key(p.c,p.r));const changed=distance(slot,p)>0;if(changed)adjusted++;assignments.push({id:u.id,from:{c:u.c,r:u.r},desired:{c:slot.c,r:slot.r},to:{c:p.c,r:p.r},changedFormation:changed,row:slot.row,reason:u.actionsLeft<=0&&distance(u,p)>0?'行动力不足':''});yield;
 }
 return {shape:parameters.shape,label:FORMATION_DOCTRINE[parameters.shape].name,heading,anchor:ref.position,reference:ref.description,assignments,adjusted,planningMs:performance.now()-start,stance:parameters.formed??FORMATION_DOCTRINE[parameters.shape].formed??false,legality:'阵位由原reachable只读校验，实际路径与行动仍由move逐次验证'};
}
export function planFormation(...args){const iterator=iterateFormationPlan(...args);let next;do{next=iterator.next();}while(!next.done);return next.value;}
export function createFormationAPI({getState,tacticalAPI}){return {doctrines:FORMATION_DOCTRINE,plan(ids,parameters,context){const s=getState();return planFormation(s,s.map.units.filter(u=>ids.includes(u.id)&&u.team===context.team&&u.hp>0),parameters,context);},deploy(select,parameters,context){return tacticalAPI.submit({v:1,confidence:1,clarification:'',orders:[{select,steps:[{type:'deploy',...parameters}]}]},context);}};}
