import {knownMap,unitKnown} from './fog-policy.mjs';
// Observer permission belongs to presentation, never to either AI's state.
export const isOmniscientObserver=(mode,editing=false)=>mode==='ai-ai'&&!editing;
export function presentationMap(game,team,mode,editing=false,map=game.map){return editing?map:isOmniscientObserver(mode)?game.map:knownMap(game,team,false);}
export function presentationUnitKnown(game,team,mode,u){return isOmniscientObserver(mode)||unitKnown(game,team,u);}
