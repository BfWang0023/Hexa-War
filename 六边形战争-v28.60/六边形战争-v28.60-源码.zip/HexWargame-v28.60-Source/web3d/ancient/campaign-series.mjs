import {CAMPAIGN_CATALOG} from './campaign-catalog.mjs';
export const CAMPAIGN_SERIES=Object.freeze([
 {id:'dawn',name:'文明曙光',period:'远古—前1000年',cover:'dawn.png'},
 {id:'axial',name:'轴心文明',period:'前1000—前250年',cover:'axial.png'},
 {id:'empire',name:'帝国时代',period:'前250年起',cover:'empire.png'}
]);
// Boundary years belong to the newer era; every campaign belongs to exactly one.
export const seriesForYear=year=>year< -1000?'dawn':year< -250?'axial':'empire';
export const campaignSeries=id=>{const c=CAMPAIGN_CATALOG.find(c=>c.id===id);return c?seriesForYear(c.year):null;};
