import {roadYieldPlan} from './road-priority.mjs';
import {planningState} from './fog-policy.mjs';
import {canTransitGarrison,neighbors,inBounds,key,distance,moveCost,reachable,mobileAt,fortAt,canPassFort} from './engine.mjs';
export function delegatedDestination(state,unit,target,radius,options={}){const view=planningState(state,unit.team),m=view.map,start={c:unit.c,r:unit.r};if(distance(start,target)<=radius)return {arrived:true};
 const heap=[],push=v=>{heap.push(v);let i=heap.length-1;while(i){const p=(i-1)>>1;if(heap[p].f<=v.f)break;heap[i]=heap[p];i=p;}heap[i]=v;},pop=()=>{const v=heap[0],last=heap.pop();if(heap.length){let i=0;while(i*2+1<heap.length){let j=i*2+1;if(j+1<heap.length&&heap[j+1].f<heap[j].f)j++;if(heap[j].f>=last.f)break;heap[i]=heap[j];i=j;}heap[i]=last;}return v;};
 const costs=new Map([[key(start.c,start.r),0]]),parents=new Map();push({...start,g:0,f:distance(start,target)});let end=null,visited=0;
 while(heap.length&&visited++<m.cols*m.rows*4){const p=pop(),pk=key(p.c,p.r);if(p.g!==costs.get(pk))continue;if(distance(p,target)<=radius&&!canTransitGarrison(m,unit,p.c,p.r)){end=p;break;}
  for(const n of neighbors(p.c,p.r)){if(!inBounds(m,n.c,n.r)||options.transport&&m.terrain[n.r*m.cols+n.c]===8)continue;const occupied=mobileAt(m,n.c,n.r);if(occupied&&occupied.id!==unit.id&&!canTransitGarrison(m,unit,n.c,n.r)&&!roadYieldPlan(view,unit,p,n))continue;if(!canPassFort(unit,fortAt(m,n.c,n.r)))continue;const cost=moveCost(view,{...unit,c:p.c,r:p.r},n.c,n.r);if(!Number.isFinite(cost))continue;const nk=key(n.c,n.r),g=p.g+(options.transport?cost*((m.terrain[n.r*m.cols+n.c]&1)?.8:1)+((m.terrain[n.r*m.cols+n.c]&12)?0:.05):cost);if(g>=(costs.get(nk)??Infinity))continue;costs.set(nk,g);parents.set(nk,p);push({...n,g,f:g+Math.max(0,distance(n,target)-radius)*(options.transport?.8:1)});}
 }
 if(!end)return {reason:'已知路径暂时受阻；等待下次本方回合重新规划'};
 const path=[];for(let p=end;parents.has(key(p.c,p.r));p=parents.get(key(p.c,p.r)))path.unshift({c:p.c,r:p.r});const legal=reachable(view,unit);let destination=null;for(const p of path){const option=legal.get(key(p.c,p.r));if(option)destination=option;}
 return {destination,path,reason:destination?'':unit.actionsLeft<=0?'本回合行动力已耗尽':'本回合没有可合法到达的路径节点'};
}
