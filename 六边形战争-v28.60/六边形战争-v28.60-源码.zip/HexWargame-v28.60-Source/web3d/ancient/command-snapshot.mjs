import {planningState} from './fog-policy.mjs';
// Shared stale-command guard, including the active simulation rules.
export function commandSnapshot(state){state=planningState(state,state.side);return JSON.stringify([state.rulesVersion,state.elevationRules,state.chargeRules,state.chargeRuns,state.map.elevations,state.turn,state.side,state.over,state.deploying,state.map.units.map(u=>[u.id,u.kind,u.team,u.hp,u.c,u.r,u.actionsLeft,u.aboard,u.formed]),Array.from(state.map.terrain),state.map.bridges,state.map.units.filter(u=>u.kind==='fort').map(u=>[u.id,u.hp,u.level,u.team])]);}
