import {offsetToWorld} from '../js/core/hex.js';
// World north is -Z. Legacy six edge directions: E,NE,NW,W,SW,SE.
export const validFacing=f=>Number.isFinite(f)&&Number.isInteger(f*2)&&f>=0&&f<6;
export const clockToFacing=hour=>((3-hour+12)%12)/2;
export const facingToClock=f=>((3-2*f+12)%12);
export const facingYaw=f=>f*Math.PI/3;
export const facingName=f=>Number.isInteger(f)?['东','东北','西北','西','西南','东南'][f]:`${facingToClock(f)||12}点方向`;
export const facingDelta=(a,b)=>Math.abs(((a-b+9)%6)-3);
export const inFront=(f,d)=>d>=0&&facingDelta(f,d)<=1+1e-8;
export function bindDirectionClock(document,container,{facing=0,allowHalf=true,formation=false,preview=()=>{},apply=()=>{}}){
 let chosen=facing;container.classList.add('direction-clock');container.replaceChildren();const dial=document.createElement('div');dial.className='clock-dial';const arrow=document.createElement('span');arrow.className='clock-arrow';arrow.textContent='↑';dial.append(arrow);let sector;if(formation){sector=document.createElement('div');sector.className='clock-front';dial.prepend(sector);}const show=()=>{arrow.style.transform=`rotate(${facingToClock(chosen)*30}deg)`;if(sector)sector.style.transform=`rotate(${facingToClock(chosen)*30}deg)`;preview(chosen);};
 for(let hour=0;hour<12;hour++){const f=clockToFacing(hour);if(!allowHalf&&!Number.isInteger(f))continue;const b=document.createElement('button');b.textContent=String(hour||12);b.title=facingName(f);b.style.left=(50+40*Math.sin(hour*Math.PI/6))+'%';b.style.top=(50-40*Math.cos(hour*Math.PI/6))+'%';b.onclick=()=>{chosen=f;show();};dial.append(b);}const confirm=document.createElement('button');confirm.textContent='确认朝向';confirm.onclick=()=>apply(chosen);const cancel=document.createElement('button');cancel.textContent='取消';cancel.onclick=()=>{preview(null);container.remove();};container.append(dial,confirm,cancel);if(formation){const key=document.createElement('p');key.className='formation-clock-key';key.textContent='绿：正面180°（含±90°）；红：背面防御0。世界北方固定在12点。';container.append(key);}show();return container;
}

export function clockToward(a,b){const p=offsetToWorld(a.c,a.r),q=offsetToWorld(b.c,b.r);return (Math.round(Math.atan2(q.x-p.x,p.z-q.z)/(Math.PI/6))+12)%12;}
