import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../vendor/three/three.module.js';
import {createUnitModel} from './models.mjs';
import {animateFullModel} from './full-models.mjs';
import {animateV02} from './models-v02.mjs';
import {createUnitAnimator} from './unit-animation.mjs';
const unit=()=>({id:'hit',kind:'heavy',team:'egypt',hp:100,c:3,r:3,morale:1});
const meshes=m=>{const a=[];m.traverse(o=>{if(o.isMesh)a.push(o)});return a;};
const materials=m=>meshes(m).flatMap(o=>Array.isArray(o.material)?o.material:[o.material]);
const transforms=m=>{const a=[];m.traverse(o=>a.push([o.position.toArray(),o.rotation.toArray(),o.scale.toArray()]));return JSON.stringify(a);};
const gray=m=>materials(m).every(x=>x.userData.hitFlash && Math.abs(x.color.r-x.color.g)<1e-8 && Math.abs(x.color.g-x.color.b)<1e-8);
for(const phase1 of [false,true])test(`${phase1?'phase1':'full'}: hit is a whole-piece gray flash without any pose jitter`,()=>{
 const m=createUnitModel(unit(),'china_chengpu',{phase1}),animate=phase1?animateV02:animateFullModel;
 animate(m,337,{moving:true,hit:0});const pose=transforms(m),original=meshes(m).map(o=>o.material);
 animate(m,337,{moving:true,hit:1});assert.equal(transforms(m),pose);assert.ok(gray(m),'base, near body and far body all flash gray');
 animate(m,400,{hit:0});assert.deepEqual(meshes(m).map(o=>o.material),original,'exact original material references restored');
});
test('shared unit materials never recolor an unhit neighbor, and gray variants are reused',()=>{
 const a=createUnitModel(unit(),'china_chengpu'),b=createUnitModel({...unit(),id:'other'},'china_chengpu');const originals=materials(b),colors=originals.map(x=>x.color.getHex());
 animateFullModel(a,100,{hit:1});assert.ok(gray(a));assert.deepEqual(materials(b),originals);assert.deepEqual(materials(b).map(x=>x.color.getHex()),colors);assert.ok(materials(b).some(x=>!x.userData.hitFlash));
 const variants=meshes(a).map(o=>o.material);animateFullModel(a,110,{hit:1});assert.deepEqual(meshes(a).map(o=>o.material),variants);animateFullModel(b,110,{hit:1});assert.deepEqual(meshes(b).map(o=>o.material),variants);
 animateFullModel(a,300,{hit:0});assert.ok(gray(b));
});
test('HP loss triggers one short flash, heals/misses do not, and models rebuilt during it remain gray',()=>{
 const u=unit(),anim=createUnitAnimator(),group=new T.Group(),camera=new T.PerspectiveCamera(),m=createUnitModel(u,'china_chengpu');m.userData.unitId=u.id;group.add(m);anim.observe([u],0);u.hp=90;anim.observe([u],10);anim.update(group,camera,50);assert.ok(gray(m));
 const replacement=createUnitModel(u,'china_chengpu');replacement.userData.unitId=u.id;group.clear();group.add(replacement);anim.update(group,camera,100);assert.ok(gray(replacement));
 anim.update(group,camera,220);assert.ok(materials(replacement).every(x=>!x.userData.hitFlash));
 u.hp=95;anim.observe([u],230);anim.update(group,camera,240);assert.ok(materials(replacement).every(x=>!x.userData.hitFlash));anim.observe([u],250);anim.update(group,camera,260);assert.ok(materials(replacement).every(x=>!x.userData.hitFlash));
});
test('repeated damage refreshes flash briefly, including far LOD and low animation quality',()=>{
 const u=unit(),anim=createUnitAnimator(),group=new T.Group(),camera=new T.PerspectiveCamera(),m=createUnitModel(u,'china_chengpu');m.userData.unitId=u.id;group.add(m);anim.setQuality('low');anim.observe([u],0);u.hp=90;anim.observe([u],10);anim.update(group,camera,170);assert.ok(gray(m));u.hp=80;anim.observe([u],175);anim.update(group,camera,260);assert.ok(gray(m));assert.ok(m.getObjectByName('far').visible);anim.update(group,camera,400);assert.ok(materials(m).every(x=>!x.userData.hitFlash));
});
test('gray feedback preserves formation stance, movement transforms and input rule state',()=>{
 const u={...unit(),kind:'greekHoplite',formed:true,facing:2},before=JSON.stringify(u),m=createUnitModel(u,'mantinea');animateFullModel(m,250,{moving:true,action:'thrust',progress:.4});const pose=transforms(m);animateFullModel(m,250,{moving:true,action:'thrust',progress:.4,hit:1});assert.equal(transforms(m),pose);assert.ok(gray(m));assert.equal(JSON.stringify(u),before);assert.ok(m.getObjectByName('near').getObjectByName('shield').position.y>2.65);
});
