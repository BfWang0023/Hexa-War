// Authoritative ground mesh for cliff-enabled maps. World distances are metres
// in the existing 6 m radius hex coordinate system. Mesh data is independent
// of the renderer, camera, and the querying unit's visibility.
import {hexCorners,offsetToWorld,worldToOffset} from '../js/core/hex.js';
import {meKind,meMountedRole} from './middle-earth-data.mjs';

const ROAD=1,RIVER=4,SEA=8;
export const CLIFF_RULES=Object.freeze({
  metresPerLevel:3.45,
  foot:Object.freeze({grade:.90,width:1.2,step:.75}),
  mounted:Object.freeze({grade:.64,width:2.2,step:.50}),
  vehicle:Object.freeze({grade:.52,width:2.8,step:.38}),
  heavy:Object.freeze({grade:.56,width:3.2,step:.42}),
});
export const hasCliffNavigation=m=>m?.victory?.layoutVersion===6&&m.victory.mode==='middle-earth';
const inside=(m,c,r)=>c>=0&&r>=0&&c<m.cols&&r<m.rows;
const at=(m,c,r)=>r*m.cols+c;
const mix=(a,b,t)=>a+(b-a)*t;
const cache=new WeakMap();
export function groundAnchorHeight(m,c,r){
  const i=at(m,c,r);
  const t=m.terrain[i];
  if(t&(RIVER|SEA))return (t&ROAD)&&!bridge(m,{c,r})?-.12:-.88;
  return (m.elevations?.[i]??0)*CLIFF_RULES.metresPerLevel;
}
function adjacent(m,x,z,c,r){
  const toward=offsetToWorld(c,r);
  const q=worldToOffset(x+(x-toward.x)*.04,z+(z-toward.z)*.04);
  return inside(m,q.col,q.row)?{c:q.col,r:q.row}:null;
}
function makeCell(m,c,r){
  const center=offsetToWorld(c,r),corners=hexCorners(center.x,center.z);
  const y=groundAnchorHeight(m,c,r);
  const sides=corners.map(([x,z],i)=>{
    const [xx,zz]=corners[(i+1)%6];
    return adjacent(m,(x+xx)/2,(z+zz)/2,c,r);
  });
  const weights=sides.map(p=>p?groundAnchorHeight(m,p.c,p.r):y);
  const wet=(c,r)=>Boolean(m.terrain[at(m,c,r)]&(RIVER|SEA));
  const localWet=wet(c,r);
  const touchesBank=(...ps)=>ps.some(p=>p&&wet(p.c,p.r)!==localWet);
  // A vertex belongs to this hex and the hexes across its two incident edges.
  // At the map perimeter average only existing cells.
  const cornerHeights=corners.map((_,i)=>{
    const a=sides[(i+5)%6],b=sides[i];
    const height=(y+(a?weights[(i+5)%6]:0)+(b?weights[i]:0))/(1+Number(!!a)+Number(!!b));
    return touchesBank(a,b)?Math.max(height,.12):height;
  });
  const rim=corners.flatMap(([x,z],i)=>{
    const j=(i+1)%6,[xx,zz]=corners[j];
    const height=(cornerHeights[i]+cornerHeights[j]+y+weights[i])/4;
    const edgeHeight=touchesBank(sides[i])?Math.max(height,.10):
      localWet?Math.min(height,(y+weights[i])/2+.07):height;
    return [[x,cornerHeights[i],z],[(x+xx)/2,edgeHeight,(z+zz)/2]];
  });
  const hs=rim.map(v=>v[1]);
  const range=Math.max(y,...hs)-Math.min(y,...hs);
  const pad=range>8.5&&Math.abs(y-(hs.reduce((a,b)=>a+b,0)/hs.length))>2.8?.12:.34;
  const inner=rim.map(([x,,z])=>[mix(center.x,x,pad),y,mix(center.z,z,pad)]);
  return {center:{...center,y},rim,inner,pad,sides,range,connections:new WeakMap()};
}
export function groundCell(m,c,r){
  let cells=cache.get(m);
  if(!cells){cells=new Map();cache.set(m,cells);}
  // Shared corners depend only on adjacent cells. Local signatures also
  // cover undo/redo, restore, fog snapshots, and direct editor height edits.
  const levels=[];
  for(let rr=Math.max(0,r-1);rr<=Math.min(m.rows-1,r+1);rr++)
    for(let cc=Math.max(0,c-1);cc<=Math.min(m.cols-1,c+1);cc++)levels.push(groundAnchorHeight(m,cc,rr),m.terrain[at(m,cc,rr)]&(RIVER|SEA));
  const key=at(m,c,r),sig=levels.join(','),existing=cells.get(key);
  if(existing?.sig===sig)return existing.cell;
  const cell=makeCell(m,c,r);
  cells.set(key,{sig,cell});
  return cell;
}
function profile(m,u){
  const p=meKind(u?.kind);
  if(p?.large)return CLIFF_RULES.heavy;
  if(['supplyWagon','chariot','chinaHeavyChariot','siegeRam'].includes(u?.kind))return CLIFF_RULES.vehicle;
  if(meMountedRole(m,u)||['meWarg','meWolf','cavalry','pharaoh'].includes(u?.kind))return CLIFF_RULES.mounted;
  return CLIFF_RULES.foot;
}
function bridge(m,p){return !!m.bridges?.some(b=>b.c===p.c&&b.r===p.r);}
export function groundStand(m,u,c,r){
  if(!hasCliffNavigation(m)||meKind(u?.kind)?.air||u?.kind==='meBlackShip')return true;
  if(!inside(m,c,r))return false;
  if(m.terrain[at(m,c,r)]&SEA)return false;
  if(bridge(m,{c,r}))return true;
  const cell=groundCell(m,c,r),p=profile(m,u),radius=p.width/2,padRadius=cell.pad*Math.sqrt(27);
  if(radius<=padRadius)return true;
  return cell.rim.every(([x,y,z])=>
    Math.abs(y-cell.center.y)/Math.max(.01,Math.hypot(x-cell.center.x,z-cell.center.z)*(1-cell.pad))<=p.grade);
}

function lanes(cell,side,p,deck){
  const a=cell.rim[side*2],mid=cell.rim[side*2+1],b=cell.rim[(side*2+2)%12];
  const half=Math.hypot(a[0]-b[0],a[2]-b[2])/2,reach=(p.width/2)/half;
  if(reach>1)return null;
  if(deck)return {grade:0,heights:[.5,.5,.5]};
  const points=[a,mid,b].map(v=>[mix(mid[0],v[0],reach),mix(mid[1],v[1],reach),mix(mid[2],v[2],reach)]);
  const grade=Math.max(...points.map(([x,h,z])=>Math.abs(h-cell.center.y)/(Math.hypot(x-cell.center.x,z-cell.center.z)*(1-cell.pad))),
    Math.abs(points[0][1]-mid[1])/(p.width/2),Math.abs(points[2][1]-mid[1])/(p.width/2));
  return {grade,heights:points.map(v=>v[1])};
}

export function knownGroundEdge(m,from,to){
  if(!hasCliffNavigation(m)||!inside(m,from.c,from.r)||!inside(m,to.c,to.r))return false;
  if(!m.unknown)return true;
  return [from,to].every(({c,r})=>groundCell(m,c,r).sides.every(p=>!p||!m.unknown[at(m,p.c,p.r)])&&!m.unknown[at(m,c,r)]);
}

const same=(a,b)=>a?.c===b?.c&&a?.r===b?.r;
export function bridgeEnds(m,p){
  const center=groundCell(m,p.c,p.r).center;
  const roads=groundCell(m,p.c,p.r).sides.filter(q=>q&&m.terrain[at(m,q.c,q.r)]&ROAD);
  let best=[],score=-Infinity;
  for(let i=0;i<roads.length;i++)for(let j=i+1;j<roads.length;j++){
    const a=offsetToWorld(roads[i].c,roads[i].r),b=offsetToWorld(roads[j].c,roads[j].r);
    const dot=(a.x-center.x)*(b.x-center.x)+(a.z-center.z)*(b.z-center.z);
    if(-dot>score){score=-dot;best=[roads[i],roads[j]];}
  }
  return best.length?best:roads;
}
export function culvertBanks(m){
  const p=m.victory?.points?.culvert;
  return p&&hasCliffNavigation(m)?[{c:p.c-1,r:p.r-1},{c:p.c+1,r:p.r}]:null;
}
export function groundConnection(m,u,from,to){
  if(!hasCliffNavigation(m)||meKind(u?.kind)?.air)return '';
  if(!inside(m,from.c,from.r)||!inside(m,to.c,to.r))return '超出战场';
  const banks=culvertBanks(m),culvert=m.victory.points?.culvert;
  if(banks&&(same(culvert,from)||same(culvert,to))&&
    !banks.some(p=>same(p,same(culvert,from)?to:from)))return '涵洞只连接两端入口';
  if(!groundStand(m,u,from.c,from.r)||!groundStand(m,u,to.c,to.r))return '没有可站立平台';
  const a=groundCell(m,from.c,from.r),b=groundCell(m,to.c,to.r);
  const side=a.sides.findIndex(v=>v?.c===to.c&&v.r===to.r),back=b.sides.findIndex(v=>v?.c===from.c&&v.r===from.r);
  if(side<0||back<0)return '通路不相接';
  const p=profile(m,u),deckA=bridge(m,from),deckB=bridge(m,to);
  if(deckA||deckB){
    if(deckA&&!bridgeEnds(m,from).some(q=>same(q,to))||deckB&&!bridgeEnds(m,to).some(q=>same(q,from)))
      return '桥面只连接桥头道路';
    const bank=deckA?b:a;
    if(deckA!==deckB&&Math.abs(bank.center.y-.5)>p.grade*Math.sqrt(27))return '桥头落差过大';
    return '';
  }
  let byDestination=a.connections.get(b);
  if(!byDestination){byDestination=new Map();a.connections.set(b,byDestination);}
  if(byDestination.has(p))return byDestination.get(p);
  const left=lanes(a,side,p,false),right=lanes(b,back,p,false);
  let reason='';
  if(!left||!right)reason='通道过窄';
  else if(left.heights.some((h,i)=>Math.abs(h-right.heights[2-i])>p.step+1e-6))reason='悬崖断面，无法跨越';
  else if(Math.max(left.grade,right.grade)>p.grade+1e-6)reason='崖坡过陡，无法跨越';
  byDestination.set(p,reason);
  return reason;
}
