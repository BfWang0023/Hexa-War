// Character-specific authored silhouette: crest, mantle, shoulder guards and
// personal standard vary independently. Shared primitive buffers remain legal.
export function addCharacterModel(g,p,{M,box,oval,rod,joint},low){
 const type=p.character,seed=type.seed,people=[];g.traverse(o=>{if(o.name==='soldier'||o.name==='rider')people.push(o);});
 const leader=people.find(person=>person.userData.characterLead)||people[0];
 for(const person of leader?[leader]:[]){const body=person.getObjectByName('breath');if(!body)continue;
 const kit=joint(body,'character-kit',[0,0,0]);kit.userData.typeId=type.id;
 const hue=[M.gold,M.bronze,M.royalBlue,M.cinnabar,M.linen,M.indigo][seed%6];
 const crown=joint(kit,'personal-crest',[0,3.12,0]);
 const points=2+(seed%4),height=.18+((seed>>>4)%7)*.035;
 for(let i=0;i<points;i++){const x=(i-(points-1)/2)*.10;rod(crown,hue,[x,0,0],[x,height*(i%2?.8:1),-.025],.035);}
 for(const side of [-1,1]){const pad=oval(kit,hue,[side*.37,2.43,-.04],[.17,.12+((seed>>>9)%4)*.018,.22]);pad.rotation.z=side*.25;}
 const mantle=box(kit,[M.indigo,M.cinnabar,M.royalBlue,M.linen][(seed>>>13)%4],[0,2.10,-.30],[.63,.80+((seed>>>16)%5)*.06,.055]);mantle.rotation.x=-.10;
 // A unique binary crest pattern provides a stable identity even for commanders
 // that share a historical combat role. It is decoration, never rule data.
 const standard=joint(person,'personal-standard',[-.55,0,-.35]);rod(standard,M.wood,[0,.3,0],[0,3.9,0],.025);
 box(standard,hue,[.23,3.55,0],[.46,.55,.04]);for(let bit=0;bit<12;bit++)if(seed&(1<<bit))box(standard,M.gold,[.07+(bit%3)*.13,3.36+Math.floor(bit/3)*.12,.027],[.065,.055,.02]);
 }
 // Naval commanders keep their real vessel and receive a personal stern pennant.
 if(!people.length||p.family==='ship'){const standard=joint(g,'character-standard',[-2,0,0]);standard.userData.typeId=type.id;rod(standard,M.wood,[0,1,0],[0,3.8,0],.035);box(standard,M.gold,[0,3.4,.35],[.05,.7,.7]);for(let i=0;i<8;i++)if(seed&(1<<i))box(standard,M.indigo,[.035,3.15+(i%4)*.15,.18+Math.floor(i/4)*.3],[.02,.08,.13]);}
 g.userData.characterType=type.id;
}
