import * as T from '../vendor/three/three.module.js';
import {loft,panel,cloth,sweep} from './historical-geometry.mjs';
// All coordinates are in the existing human rig (+Z forward). Clothing follows
// the existing breath/arm/leg joints; weapon anchors and motion are unchanged.
export function historicalDress(body,p,team,kit){
 const {M,box,oval,rod,part,joint,low}=kit,china=p.culture==='china',royal=!!p.royalStyle;
 if(!china&&!royal)return;
 const color=team==='egypt'?M.indigo:M.cinnabar,armor=p.period==='early'?M.lacquer:M.lamellar;
 const garment=joint(body,china?'chinese-robe':'royal-garment',[0,0,0]);
 if(china){
  loft(garment,color,[[0,1.18,0,.43,.29],[0,1.42,0,.40,.27],[0,1.85,0,.30,.23],[0,2.18,0,.34,.24],[0,2.44,0,.34,.23],[0,2.57,0,.16,.15]],{axis:'y',sides:low?8:14});
  rod(garment,M.linen,[-.13,2.56,.15],[.26,2.20,.255],.025);rod(garment,M.linen,[.12,2.56,.15],[-.08,2.36,.25],.025);
  box(garment,M.leather,[0,1.88,0],[.65,.115,.51]);box(garment,M.bronze,[0,1.88,.265],[.14,.09,.035]);
  if(p.armor>0||p.commander){
   const cuirass=joint(garment,'lamellar-cuirass',[0,0,0]);
   loft(cuirass,armor,[[0,1.91,0,.335,.255],[0,2.18,0,.37,.27],[0,2.43,0,.36,.25]],{axis:'y',sides:12});
   if(!low)for(const side of [-1,1])for(let row=0;row<5;row++)for(let col=0;col<6;col++){const x=(col-2.5)*.112,z=side*(.278-.07*Math.pow(x/.34,2)),y=1.98+row*.105;
    box(cuirass,armor,[x,y,z],[.102,.094,.028]);for(const dx of [-.028,.028])rod(cuirass,M.linen,[x+dx,y-.025,z+side*.017],[x+dx,y+.025,z+side*.017],.006);
   }
   for(const side of [-1,1]){const skirt=box(garment,armor,[side*.25,1.64,.04],[.19,.38,.53]);skirt.rotation.z=side*.12;}
  }
  const hair=joint(body,p.commander?'officer-cap':'topknot',[0,3.12,0]);
  if(p.commander){loft(hair,M.mane,[[0,-.02,0,.25,.23],[0,.12,-.02,.23,.21],[0,.28,-.05,.19,.14]],{axis:'y',sides:10});for(const x of [-.1,.1])box(hair,M.lacquer,[x,.22,-.03],[.065,.20,.22]).rotation.z=x<0?-.2:.2;}
  else if(p.armor>0&&p.period!=='qin'){
   part(hair,new T.SphereGeometry(.255,12,6,0,Math.PI*2,0,Math.PI*.57),p.period==='early'?M.bronze:M.lamellar,[0,-.06,0]);
   for(const s of [-1,1])box(hair,armor,[s*.22,-.22,-.01],[.055,.24,.22]);
  }else {part(hair,new T.SphereGeometry(.243,12,6,0,Math.PI*2,0,Math.PI*.57),M.mane,[0,-.10,0]);oval(hair,M.mane,[.08,.03,-.035],[.11,.14,.10]);rod(hair,M.bronze,[-.06,.06,-.035],[.2,.06,-.035],.018);}
  if(p.commander){for(const side of [-1,1])sweep(body,M.mane,[[side*.03,2.79,.226],[side*.10,2.76,.23],[side*.15,2.74,.18]],[.025,.012],{steps:6,sides:5});}
 }else {
  const style=p.royalStyle;
  if(style==='egypt'){
   const regalia=joint(body,'khepresh-crown',[0,3.03,0]);loft(regalia,M.royalBlue,[[0,0,0,.25,.23],[0,.18,-.025,.27,.25],[0,.40,-.045,.22,.21],[0,.46,-.03,.12,.14]],{axis:'y',sides:14});
   sweep(regalia,M.gold,[[0,.03,.24],[0,.16,.28],[0,.22,.24],[0,.18,.20]],[.022,.018],{steps:10});oval(regalia,M.gold,[0,.18,.27],[.05,.06,.025]);
   // Broad collar, white pleated kilt, gold apron: silhouette of a New Kingdom ruler.
   for(let row=0;row<3;row++)sweep(garment,row===1?M.royalBlue:M.gold,[[-.3,2.52,.04],[-.23,2.37-row*.04,.19],[0,2.30-row*.05,.26],[.23,2.37-row*.04,.19],[.3,2.52,.04]],[.025,.025],{steps:14});
   loft(garment,M.linen,[[0,1.23,0,.44,.29],[0,1.50,0,.37,.27],[0,1.88,0,.30,.23]],{axis:'y',sides:16});
   const apron=panel(garment,M.gold,[[-.12,1.85],[.12,1.85],[.24,1.28],[-.24,1.28]],.025);apron.position.z=.29;
   for(const side of [-1,1])rod(garment,M.gold,[side*.34,2.44,0],[side*.38,2.30,0],.11);
  }else if(style==='persia'||style==='assyria'||style==='hittite'){
   loft(garment,color,[[0,1.12,0,.43,.29],[0,1.8,0,.32,.25],[0,2.42,0,.36,.25]],{axis:'y',sides:12});
   const crown=joint(body,'eastern-royal-crown',[0,3.07,0]);loft(crown,M.linen,[[0,0,0,.25,.23],[0,.23,0,.24,.22],[0,.38,0,.19,.19]],{axis:'y',sides:12});
   part(crown,new T.TorusGeometry(.245,.035,5,16),M.gold,[0,.06,0]).rotation.x=Math.PI/2;
   for(let i=0;i<5;i++){const x=(i-2)*.07;rod(body,M.mane,[x,2.80,.2],[x*.8,2.58,.24],.035,.04);}
   for(const y of [1.17,1.26])box(garment,M.gold,[0,y,.29],[.72,.035,.035]);
  }else {
   // Mediterranean commander: crested helmet/diadem and mantle, no Egyptian crown.
   const crest=joint(body,'commander-crest',[0,3.15,0]);sweep(crest,M.cinnabar,[[0,-.04,-.23],[0,.19,-.16],[0,.23,.05],[0,.09,.24]],[.075,.07],{steps:12,sides:6});
   part(crest,new T.SphereGeometry(.26,12,6,0,Math.PI*2,0,Math.PI*.55),M.bronze,[0,-.12,0]);
  }
  if(style!=='egypt')cloth(body,color,[[[-.3,2.49,-.2],[0,2.53,-.26],[.3,2.49,-.2]],[[-.38,2.0,-.32],[0,1.95,-.41],[.38,2.0,-.32]],[[-.43,1.15,-.38],[0,1.12,-.46],[.43,1.15,-.38]]]);
 }
 // Defined brow, eyes and ears replace the featureless mannequin head.
 for(const side of [-1,1]){oval(body,M.skin,[side*.22,2.92,0],[.045,.085,.055]);oval(body,M.mane,[side*.085,2.96,.212],[.026,.014,.013]);rod(body,M.mane,[side*.04,3.008,.21],[side*.13,3.008,.20],.012);}
}
export function dressSleeve(arm,p,team,{M,rod,low}){if(p.culture!=='china'&&!['persia','assyria','hittite'].includes(p.royalStyle))return;const upper=arm.getObjectByName('upper-arm'),lower=arm.getObjectByName('lower-arm');if(!upper)return;
 rod(upper,team==='egypt'?M.indigo:M.cinnabar,[0,0,0],[0,-.87,0],.14,.17);rod(lower,team==='egypt'?M.indigo:M.cinnabar,[0,-.02,0],[0,-.58,0],.10,.135);
 if(p.armor>0&&p.culture==='china'){const side=arm.userData.armSide;for(let i=0;i<(low?1:3);i++)rod(upper,M.lamellar,[side*.05,-.10-i*.17,-.04],[side*.05,-.22-i*.17,.04],.16,.15);}
}

export function historicalShield(arm,team,{M,box,rod,oval}){
 const g=new T.Group();g.name='chinese-shield';g.position.set(-.13,-.38,.43);arm.add(g);
 const contour=[[-.32,-.51],[.32,-.51],[.34,.34],[.15,.52],[-.15,.52],[-.34,.34]];
 panel(g,M.darkWood,contour,.065);const paint=panel(g,team==='egypt'?M.indigo:M.cinnabar,contour.map(([x,y])=>[x*.90,y*.92]),.018);paint.position.z=.067;
 rod(g,M.gold,[0,-.43,.10],[0,.43,.10],.016);
 for(const side of [-1,1]){rod(g,M.gold,[0,.03,.10],[side*.23,.24,.10],.013);rod(g,M.lacquer,[side*.23,.24,.10],[side*.23,-.25,.10],.02);}
 oval(g,M.bronze,[0,0,.11],[.075,.09,.028]);
}
