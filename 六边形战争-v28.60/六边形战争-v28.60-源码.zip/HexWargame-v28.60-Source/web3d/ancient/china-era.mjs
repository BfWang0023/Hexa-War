// The first playable fourth-century BCE Chinese battle is Yinjin (-389).
// Iron weapon use spread gradually; this is a scenario balance boundary.
export const CHINA_IRON_AGE_IDS = new Set([
  'china_hexi_second', 'china_guiling', 'china_maling', 'china_hexi_third',
  'china_alliance_qin', 'china_qin_bashu', 'china_qi_yan', 'china_lantian',
  'china_chui_sha', 'china_yique', 'china_qi_song', 'china_alliance_qi',
  'china_tian_dan', 'china_yan_ying', 'china_eyu', 'china_changping',
  'china_handan', 'china_qin_zhao', 'china_qin_chu',
  'china_dingtao', 'china_julu', 'china_three_qin', 'china_puban',
  'china_pengcheng', 'china_jingxing', 'china_gaixia', 'china_seven_states',
  'china_mayi', 'china_hexi', 'china_mobei', 'china_dayuan',
  'china_kunyang', 'china_longxi',
]);
export const isChinaIronAgeScenario = id => CHINA_IRON_AGE_IDS.has(id);
