import {TACTICAL_IDS as CLASSICAL_IDS} from './classical-data.mjs';
const teams=['egypt','coalition'];
export const classicalFighter=u=>!['fort','moraleGuard','moraleFlagship','engineer','transport','supplyWagon','captive'].includes(u.kind);
export const inClassicalArea=(p,a)=>p.c>=a.cMin&&p.c<=a.cMax&&p.r>=a.rMin&&p.r<=a.rMax;
export function validateClassical(m,inBounds){
 const v=m.victory,point=p=>p&&Number.isInteger(p.c)&&Number.isInteger(p.r)&&inBounds(m,p.c,p.r);
 const roster=t=>m.units.filter(u=>u.team===t&&classicalFighter(u)).length;
 if(!CLASSICAL_IDS.has(m.scenarioId)||v.variant!==m.scenarioId||!Number.isInteger(v.turnLimit)||v.turnLimit<3||v.turnLimit>100||
  !teams.every(t=>Number.isInteger(v.losses?.[t])&&v.losses[t]>=1&&v.losses[t]<=roster(t))||
  (v.holdWinner!==undefined&&!teams.includes(v.holdWinner))||
  (v.capture!==undefined&&(!point(v.capture)||!teams.includes(v.capture.team)||typeof v.capture.name!=='string'||v.capture.name.length>32))||
  (v.escape!==undefined&&(!Array.isArray(v.escape)||!v.escape.length||v.escape.length>2||v.escape.some(a=>
   !teams.includes(a.team)||typeof a.ships!=='boolean'||!Number.isInteger(a.needed)||a.needed<1||a.needed>roster(a.team)||
   !point({c:a.cMin,r:a.rMin})||!point({c:a.cMax,r:a.rMax})||a.cMin>a.cMax||a.rMin>a.rMax))))throw Error('希腊战役兵力或目标无效');
}
export function importClassical(v){return {mode:'classical',variant:v.variant,turnLimit:v.turnLimit,losses:{...v.losses},
 ...(v.holdWinner===undefined?{}:{holdWinner:v.holdWinner}),...(v.capture===undefined?{}:{capture:{...v.capture}}),
 ...(v.escape===undefined?{}:{escape:structuredClone(v.escape)})};}
export function checkClassical(s,{isRouted,isShip},deadline=false){
 const v=s.map.victory,roster=t=>s.map.units.filter(u=>u.team===t&&classicalFighter(u)),lost=t=>roster(t).filter(u=>u.hp<=0||isRouted(u)).length;
 const active=u=>u.hp>0&&!u.aboard&&!isRouted(u)&&classicalFighter(u);
 const finish=(winner,reason)=>{s.over=true;s.winner=winner;s.victoryReason=reason;s.log.push(winner?`${s.map.factions[winner]}达成战役目标，${s.map.name}结束。`:`${s.map.name}双方战平。`);return winner;};
 const broken=teams.filter(t=>lost(t)>=v.losses[t]);
 if(broken.length)return finish(broken.length===2?null:broken[0]==='egypt'?'coalition':'egypt','classical_rout');
 const capture=v.capture;
 if(capture&&s.map.units.some(u=>active(u)&&!isShip(u)&&u.team===capture.team&&u.c===capture.c&&u.r===capture.r)&&
  !s.map.units.some(u=>u.kind==='fort'&&u.hp>0&&u.team!==capture.team&&u.c===capture.c&&u.r===capture.r))return finish(capture.team,'classical_capture');
 for(const area of v.escape||[])if(s.map.units.filter(u=>active(u)&&u.team===area.team&&isShip(u)===area.ships&&inClassicalArea(u,area)).length>=area.needed)return finish(area.team,'classical_escape');
 if(deadline){
  if(v.holdWinner)return finish(v.holdWinner,'classical_hold');
  const a=lost('egypt')/roster('egypt').length,b=lost('coalition')/roster('coalition').length;
  return finish(a===b?null:a<b?'egypt':'coalition',a===b?'classical_draw':'classical_attrition');
 }
 return s.winner;
}
export function classicalBrief(m){
 const v=m.victory,terms=[`双方击溃敌方战斗部队至少四分之三获胜（${m.factions.egypt}损失${v.losses.egypt}支／${m.factions.coalition}损失${v.losses.coalition}支）。`];
 if(v.capture)terms.push(`${m.factions[v.capture.team]}也可派陆军占领黄色目标「${v.capture.name}」获胜。`);
 for(const a of v.escape||[])terms.push(`${m.factions[a.team]}也可让${a.needed}支${a.ships?'舰队':'陆军'}同时抵达${a.ships?'东侧海上':'西侧陆上'}黄色撤离区获胜；溃兵与登船乘员不计，撤离单位留在地图上，不重复计数。`);
 terms.push(v.holdWinner?`${m.factions[v.holdWinner]}守至第${v.turnLimit}回合双方行动结束获胜。`:`第${v.turnLimit}回合双方行动结束，损失比例较低者获胜，相同则战平。`);
 return terms.join('');
}
