const rows=[
 ['dawn_zhuolu',-3300,'涿鹿之战','约前3300年·传说年代','炎黄部落联盟','蚩尤部落联盟','山地与侦察','传说战事，年代、地点、兵力均无法可靠复原。采用用户指定年代作为排序，不作为史实断言。'],
 ['dawn_egypt_union',-3100,'古埃及统一','约前3100年','上埃及军','下埃及军','步弓配合','统一是长期历史过程；本图为小规模战术教学抽象，不复原某一场确定会战。'],
 ['dawn_sanmiao',-2100,'禹征三苗之战','约前2100年·传说年代','禹部落联盟','三苗部落联盟','涉水与渡口','传世叙事，确切年代、地点与军事细节不可考。地形为教学示意。'],
 ['dawn_ur',-2004,'乌尔陷落','约前2004年·中年表','埃兰进攻军','乌尔守军','一级城墙与入口','乌尔第三王朝末期陷落；年代依年表而异。城防与兵力为简化教学布局。'],
 ['dawn_larsa',-1763,'拉尔萨围城战','前1763年·中年表','巴比伦军','拉尔萨军','桥梁与围城','汉谟拉比征服拉尔萨。围城过程压缩为水道旁的一级城防争夺。桥梁只作机制演示，不宣称为史实遗址。'],
 ['dawn_babylon',-1595,'巴比伦陷落','约前1595年·中年表','赫梯远征军','古巴比伦守军','山口与突破','赫梯袭击古巴比伦，区别于游戏已有前539年巴比伦陷落。年代与路线存在争议，采用简化战术地图。'],
 ['dawn_delta',-1177,'古埃及反击海上民族之战','约前1177年（前1200年前后）','古埃及舰队','海上民族舰队','早期海战与岸射','拉美西斯三世第八年三角洲海战，通常约前1177年前后，非精确前1200年。仅用早期桨帆战船，普通接舷与射击，无冲角增伤。']
];
export const DAWN_CAMPAIGNS=Object.freeze(rows.map(([id,year,name,dateLabel,a,b,lesson,note])=>Object.freeze({id,year,name,dateLabel,factions:[a,b],lesson,note,focus:[8,7],camera:125,terrain:lesson,forces:"双方各4个作战单位；布局为入门缩放。",deployment:note,sources:[["大都会博物馆：古巴比伦时期","https://www.metmuseum.org/toah/hd/isin/hd_isin.htm"],["埃及文物部门：早王朝统一","https://egymonuments.gov.eg/en/historical-periods/early-dynastic-period"]]})));
export const DAWN_IDS=new Set(DAWN_CAMPAIGNS.map(c=>c.id));
