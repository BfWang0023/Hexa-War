// Static, volumetric, authored body silhouettes. No animation/physics or simulation mutation.
import * as T from '../vendor/three/three.module.js';
// A static, genuinely three-dimensional distance LOD. Cluster only the baked corpse,
// never the live model. Degenerate faces disappear while silhouette/colour remain.
export function simplifyFallenModel(source,cell=.24){
 const p=source.attributes.position,c=source.attributes.color,blood=source.attributes.bloodUV,clusters=new Map(),keys=[];
 for(let i=0;i<p.count;i++){const key=[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v/cell)).join(',');keys.push(key);let a=clusters.get(key);if(!a)clusters.set(key,a=[0,0,0,0]);a[0]+=p.getX(i);a[1]+=p.getY(i);a[2]+=p.getZ(i);a[3]++;}
 for(const a of clusters.values())for(let j=0;j<3;j++)a[j]/=a[3];
 const pos=[],colors=[],stains=[],faces=new Set();
 for(let i=0;i<p.count;i+=3){const ks=keys.slice(i,i+3);if(new Set(ks).size!==3)continue;const face=[...ks].sort().join('/');if(faces.has(face))continue;faces.add(face);for(let j=0;j<3;j++){pos.push(...clusters.get(ks[j]).slice(0,3));colors.push(c.getX(i+j),c.getY(i+j),c.getZ(i+j));stains.push(blood?.getX(i+j)??10,blood?.getY(i+j)??10);}}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.setAttribute('bloodUV',new T.Float32BufferAttribute(stains,2));g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function bakeSunkMarker(){
 const pieces=[],color=[];for(const angle of [Math.PI/4,-Math.PI/4]){const g=new T.BoxGeometry(2.2,.045,.22).toNonIndexed();g.rotateY(angle);const a=g.attributes.position;for(let i=0;i<a.count;i++){pieces.push(a.getX(i),.06+a.getY(i),a.getZ(i));color.push(.35,.24,.17);}g.dispose();}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pieces,3));g.setAttribute('color',new T.Float32BufferAttribute(color,3));g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function bakeFallenModel(model,pose=0){
 const level=model.getObjectByName('near')||model,visual=level.getObjectByName('visual')||level;
 model.rotation.set(0,0,0);for(const child of model.children)if(child!==level)child.visible=false;level.visible=true;
 model.traverse(o=>{if(o.userData.unitBase||o.name==='casualty-rein')o.visible=false;});model.updateMatrixWorld(true);
 const reinKeys=new Set(visual.userData.casualtyReins||[]);
 const reinSpace=new Map();
 if(reinKeys.size){
  const inverse=visual.matrixWorld.clone().invert();
  for(const child of visual.children)if(child.isMesh&&child.geometry.userData.sharedUnitV02){
   reinSpace.set(child,inverse.clone().multiply(child.matrixWorld));
  }
 }
 const persons=[];visual.traverse(o=>{if(['soldier','rider'].includes(o.name))persons.push(o);});
 // Detach riders before laying mounts down. Keep their authored dimensions.
 for(const o of persons)if(o.parent!==visual)visual.attach(o);
 const bodies=[...visual.children].filter(o=>['horse','beast-body','supply-assembly'].includes(o.name));
 const rand=i=>{const x=Math.sin((i+1)*127.1+(pose+1)*311.7)*43758.5453;return x-Math.floor(x);};
 const ground=o=>{model.updateMatrixWorld(true);const b=new T.Box3().setFromObject(o),sc=new T.Vector3();o.parent.getWorldScale(sc);o.position.y-=(b.min.y-.04)/sc.y;};
 const dropped=[];
 for(const [i,person] of persons.entries()){
  const arm=person.getObjectByName('shield');let looseShield=null;
  if(arm){const parts=arm.children.filter(o=>o.isMesh||o.name==='chinese-shield');if(parts.length){looseShield=new T.Group();looseShield.name='fallen-shield';arm.add(looseShield);model.updateMatrixWorld(true);for(const part of parts)looseShield.attach(part);}}
  const tools=looseShield?[looseShield]:[];person.traverse(o=>{if(['melee-tool','ranged-tool'].includes(o.name))tools.push(o);});
  for(const [j,tool]of tools.entries()){visual.attach(tool);tool.visible=true;tool.rotation.order='YXZ';tool.rotation.set(Math.PI/2,rand(i*7+j+20)*Math.PI*2,0);tool.position.x+=(rand(i*3+j+40)-.5)*2.8;tool.position.z+=(rand(i*3+j+50)-.5)*2.8;ground(tool);dropped.push(tool);}
  person.position.x+=(rand(i*3)-.5)*2;person.position.z+=(rand(i*3+1)-.5)*2;
  person.rotation.set((rand(i*3+2)>.5?1:-1)*Math.PI/2,0,rand(i*3+3)*Math.PI*2);ground(person);
 }
 for(const o of bodies){if(o.name==='supply-assembly')continue;o.rotation.x+=pose?Math.PI/2:-Math.PI/2;ground(o);}
 const family=model.userData.profile?.family;
 const wreck=['chariot','ram','onager','siegeTower','siege','wagon','defenseTower','trojanHorse'].includes(family)||['siegeRam','siegeTower','romanOnager'].includes(model.userData.kind);
 {const fragments=[];visual.traverse(o=>{if(!o.isMesh||!o.visible||o.userData.unitBase)return;let p=o.parent;while(p&&p!==visual){if(persons.includes(p)||dropped.includes(p)||(bodies.includes(p)&&p.name!=='supply-assembly'))return;p=p.parent;}fragments.push(o);});for(const [i,o]of fragments.entries()){visual.attach(o);o.position.x=(rand(i+91)-.5)*4.6;o.position.z=(rand(i+121)-.5)*4.6;o.rotation.set(Math.PI/2+rand(i+161)*.7,rand(i+191)*Math.PI*2,rand(i+221)*.9);o.scale.multiplyScalar(.72);ground(o);}}
 model.updateMatrixWorld(true);
 // Give small parts their own projection so a torso-sized mask cannot miss them.
 const stainRegions=new Map(),stainByMesh=new Map();
 const people=new Set(persons),horses=new Set(bodies.filter(o=>o.name==='horse'));
 level.traverseVisible(mesh=>{
  if(!mesh.isMesh||mesh.userData.unitBase)return;
  let region=null,head=false;
  for(let part=mesh;part&&part!==visual;part=part.parent){
   if(part.name.startsWith('horseleg:')||/^leg-?1$/.test(part.name)||part.userData.armSide)region=part;
   if(part.parent?.name==='breath'&&part.position.y>=2.70)head=true;
   if(people.has(part)){region=region||(head?part.uuid+':head':part);break;}
   if(horses.has(part)){
    const horseHead=mesh.parent===part&&mesh.position.x>=.80&&mesh.position.y>=2.0;
    region=region||(horseHead?part.uuid+':head':part);
    break;
   }
  }
  if(!region)return;
  if(!stainRegions.has(region))stainRegions.set(region,{bounds:new T.Box3(),angle:rand(stainRegions.size+270)*Math.PI*2});
  const entry=stainRegions.get(region);
  entry.bounds.expandByObject(mesh);
  stainByMesh.set(mesh,entry);
 });
 for(const entry of stainRegions.values()){
  entry.center=entry.bounds.getCenter(new T.Vector3());
  const size=entry.bounds.getSize(new T.Vector3());
  entry.xScale=Math.max(.11,size.x*.58);
  entry.zScale=Math.max(.11,size.z*.58);
  entry.cos=Math.cos(entry.angle);entry.sin=Math.sin(entry.angle);
 }
 const pos=[],norm=[],colors=[],stains=[],normalMatrix=new T.Matrix3(),v=new T.Vector3(),n=new T.Vector3();
 level.traverseVisible(o=>{if(!o.isMesh||o.userData.unitBase)return;let g=o.geometry.index?o.geometry.toNonIndexed():o.geometry;const p=g.attributes.position,no=g.attributes.normal;normalMatrix.getNormalMatrix(o.matrixWorld);
  const stainRegion=stainByMesh.get(o);
  for(let i=0;i<p.count;i++){if(i%3===0&&reinSpace.has(o)){const base=i,points=[];for(let j=0;j<3;j++){const q=new T.Vector3().fromBufferAttribute(p,base+j).applyMatrix4(reinSpace.get(o));points.push(q.toArray().map(x=>Math.round(x*10000)).join(','));}if(reinKeys.has(points.sort().join('/'))){i+=2;continue;}}v.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld);pos.push(v.x,v.y,v.z);if(stainRegion){
    const {center,xScale,zScale,cos,sin}=stainRegion;
    const x=(v.x-center.x)/xScale,z=(v.z-center.z)/zScale;
    stains.push(x*cos-z*sin,x*sin+z*cos);
   }else stains.push(10,10);n.fromBufferAttribute(no,i).applyMatrix3(normalMatrix).normalize();norm.push(n.x,n.y,n.z);const heightShade=Math.max(0,Math.min(1,(v.y-.04)/1.4));
   const shade=.018+.155*heightShade;
   colors.push(shade,shade,shade);}if(g!==o.geometry)g.dispose();});
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(pos,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(norm,3));geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));geometry.setAttribute('bloodUV',new T.Float32BufferAttribute(stains,2));if(wreck)geometry.scale(1,.32,1);geometry.computeBoundingBox();geometry.translate(0,.035-geometry.boundingBox.min.y,0);geometry.computeBoundingBox();geometry.computeBoundingSphere();
 return geometry;
}
