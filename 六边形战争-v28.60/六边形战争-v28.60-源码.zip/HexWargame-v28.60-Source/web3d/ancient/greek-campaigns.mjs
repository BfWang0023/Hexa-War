import { TERRAIN, addUnit, index, mobileAt, newMap, validateMap } from './engine.mjs';

function placeGroup(m, team, name, kind, c, r, count) {
  for (let i = 0; i < count; i++) {
    const row = r + Math.floor(i / 3) * 2;
    const col = c + i % 3;
    if (!addUnit(m, kind, team, col, row))
      throw new Error(`${m.scenarioId}: ${name} 无法部署在 ${col},${row}`);
    mobileAt(m, col, row).formation = name;
  }
}

// Thucydides 5.67–74 describes the relative wings; the hex coordinates are schematic.
export function mantineaMap() {
  const m = newMap(72, 48);
  m.scenarioId = 'mantinea';
  m.name = '曼提尼亚会战';
  m.factions = { egypt: '斯巴达与特该亚联军', coalition: '曼提尼亚·阿尔戈斯·雅典联军' };
  m.unitNames = { greekHoplite: '希腊重装步兵',
    'egypt:guard': '阿吉斯二世亲卫', 'coalition:guard': '阿尔戈斯千名精选兵',
    'coalition:cavalry': '雅典骑兵', 'coalition:archer': '雅典投射兵' };
  m.victory = { mode: 'peloponnesian', variant: 'mantinea',
    losses: { egypt: 17, coalition: 17 }, turnLimit: 24 };
  m.intro = '前418年曼提尼亚会战。斯巴达左翼面对曼提尼亚军与阿尔戈斯精选兵，斯巴达右翼与特该亚军迎击雅典翼。按修昔底德所记相对队列布阵；坡地、兵数与距离为游戏化示意。任一方击溃敌军四分之三获胜，第24回合按损失比例判定。';
  m.landmarks = [
    { c: 35, r: 7, label: '曼提尼亚平原北缘' },
    { c: 25, r: 12, label: '斯巴达左翼' },
    { c: 45, r: 12, label: '曼提尼亚与阿尔戈斯右翼' },
    { c: 24, r: 34, label: '斯巴达与特该亚右翼' },
    { c: 46, r: 34, label: '雅典左翼与骑兵' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    if ((r < 5 || r > 42) && c > 8 && c < 65 && (c + r) % 4 !== 0)
      m.terrain[index(m, c, r)] = TERRAIN.MOUNTAIN;
    else if (r === 23 && c >= 8 && c <= 63) m.terrain[index(m, c, r)] = TERRAIN.ROAD;
  }
  placeGroup(m, 'egypt', '斯基里泰与布拉西达旧部', 'greekHoplite', 24, 9, 9);
  placeGroup(m, 'egypt', '斯巴达中军', 'greekHoplite', 23, 20, 12);
  placeGroup(m, 'egypt', '斯巴达与特该亚右翼', 'greekHoplite', 24, 32, 9);
  placeGroup(m, 'coalition', '曼提尼亚右翼', 'greekHoplite', 45, 9, 9);
  placeGroup(m, 'coalition', '阿尔戈斯中军', 'greekHoplite', 45, 20, 12);
  placeGroup(m, 'coalition', '雅典左翼', 'greekHoplite', 45, 32, 9);
  for (const [kind, team, c, r, name] of [
    ['guard', 'egypt', 19, 24, '阿吉斯二世亲卫'],
    ['guard', 'coalition', 51, 21, '阿尔戈斯千名精选兵'],
    ['guard', 'coalition', 51, 23, '阿尔戈斯千名精选兵'],
    ['cavalry', 'coalition', 53, 34, '雅典骑兵'],
    ['cavalry', 'coalition', 53, 36, '雅典骑兵'],
    ['archer', 'coalition', 53, 38, '雅典投射兵'],
  ]) {
    if (!addUnit(m, kind, team, c, r)) throw new Error(`曼提尼亚部署失败 ${c},${r}`);
    mobileAt(m, c, r).formation = name;
  }
  for (const u of m.units) if (u.kind === 'greekHoplite') u.facing = u.team === 'egypt' ? 0 : 3;
  validateMap(m);
  return m;
}

// Xenophon, Hellenica 2.1.20–29: Lampsacus opposite the exposed Athenian beach.
export function aegospotamiMap() {
  const m = newMap(70, 44);
  m.scenarioId = 'aegospotami';
  m.name = '羊河口之战';
  m.factions = { egypt: '莱山德斯斯巴达舰队', coalition: '雅典舰队' };
  m.unitNames = { 'egypt:athenianTrireme': '斯巴达与盟邦三列桨战船',
    'coalition:phoenicianTrireme': '雅典三列桨战船' };
  m.victory = { mode: 'peloponnesian', variant: 'aegospotami',
    losses: { egypt: 12, coalition: 12 }, turnLimit: 18,
    escape: { cMax: 13, rMin: 12, rMax: 34 }, escapeShips: 4 };
  m.intro = '前405年羊河口。莱山德斯舰队自兰普萨库斯港突袭海峡对岸的雅典露天锚地；大部分雅典船员散在岸上，仅少数舰船可以及时驶离。雅典可护送4支分舰队到西侧出口；任一方击溃敌舰四分之三也可获胜，斯巴达封锁至第18回合获胜。每枚船棋是游戏化分舰队，船员分散以较低初始士气表现。';
  m.landmarks = [
    { c: 43, r: 5, label: '兰普萨库斯港' },
    { c: 42, r: 17, label: '莱山德斯突袭舰队' },
    { c: 42, r: 22, label: '赫勒斯滂海峡' },
    { c: 42, r: 37, label: '羊河口露天锚地' },
    { c: 12, r: 23, label: '西侧撤离航道' },
  ];
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
    m.terrain[index(m, c, r)] = r >= 10 && r <= 34 ? TERRAIN.SEA :
      r === 9 || r === 35 ? TERRAIN.BEACH : TERRAIN.PLAIN;
  }
  for (const [kind, team, c, r, name] of [
    ...Array.from({ length: 10 }, (_, i) => ['athenianTrireme', 'egypt', 27 + i * 4, 14, '斯巴达第一攻击线']),
    ...Array.from({ length: 10 }, (_, i) => ['athenianTrireme', 'egypt', 29 + i * 4, 18, '斯巴达第二攻击线']),
    ...Array.from({ length: 9 }, (_, i) => ['phoenicianTrireme', 'coalition', 28 + i * 4, 31, '雅典靠岸分舰队']),
    ...Array.from({ length: 9 }, (_, i) => ['phoenicianTrireme', 'coalition', 30 + i * 4, 33, '雅典靠岸分舰队']),
  ]) {
    if (!addUnit(m, kind, team, c, r)) throw new Error(`羊河口舰队部署失败 ${c},${r}`);
    const u = mobileAt(m, c, r);
    u.formation = name;
    u.facing = team === 'egypt' ? 5 : 4;
    if (team === 'coalition') u.morale = 0.72;
  }
  for (const [team, c, r, commander] of [
    ['egypt', 43, 14, '莱山德斯'], ['coalition', 30, 33, '科农'],
    ['coalition', 34, 33, '帕拉洛斯号']]) {
    const u = mobileAt(m, c, r);
    if (!u || u.team !== team) throw new Error(`羊河口指挥舰部署失败 ${commander}`);
    u.commander = commander;
    u.morale = 1;
  }
  for (const u of m.units.filter(u => u.team === 'egypt' && u.r === 14)) u.scout = true;
  validateMap(m);
  return m;
}
