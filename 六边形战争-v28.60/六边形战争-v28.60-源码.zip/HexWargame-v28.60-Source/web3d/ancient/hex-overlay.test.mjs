import test from 'node:test';import assert from 'node:assert/strict';
import {cellOutline} from './hex-overlay.mjs';
import {hexCorners,offsetToWorld,worldToOffset,HEX_R} from '../js/core/hex.js';
import * as T from '../vendor/three/three.module.js';
test('all outline corners use identical terrain centers, radius and orientation on both row parities',()=>{
 for(const [c,r] of [[0,0],[5,5],[5,6],[70,43]]){
  const p=offsetToWorld(c,r),corners=hexCorners(p.x,p.z),g=cellOutline(c,r);assert.equal(g.indices.length,288);
  for(let i=0;i<6;i++){const j=i*9*6;assert.equal(g.positions[j],corners[i][0]);assert.equal(g.positions[j+2],corners[i][1]);assert.ok(Math.abs(Math.hypot(corners[i][0]-p.x,corners[i][1]-p.z)-HEX_R)<1e-10);}
  assert.deepEqual(worldToOffset(p.x,p.z),{col:c,row:r});
 }
});
test('outline samples every edge subdivision on the same surface, including slopes',()=>{
 const sample=(x,z)=>x*.2+z*.05,g=cellOutline(2,3,{sample});
 for(let i=0;i<g.positions.length;i+=3)assert.ok(Math.abs(g.positions[i+1]-sample(g.positions[i],g.positions[i+2])-.065)<1e-10);
});
test('terrain and overlay corners project identically at rotations, zooms and orthographic top view',()=>{
 const p=offsetToWorld(8,8),g=cellOutline(8,8,{lift:0});
 for(const zoom of [50,180,450])for(const yaw of [0,.52,1.57,3.14])for(const top of [false,true]){
  const cam=top?new T.OrthographicCamera(-zoom,zoom,zoom,-zoom,.1,2000):new T.PerspectiveCamera(45,1,.1,2000);
  cam.position.set(p.x+Math.sin(yaw)*(top?0:zoom),top?zoom:zoom*.68,p.z+Math.cos(yaw)*(top?0:zoom));cam.up.set(0,top?0:1,top?-1:0);cam.lookAt(p.x,0,p.z);cam.updateMatrixWorld();
  hexCorners(p.x,p.z).forEach(([x,z],i)=>{const j=i*54,a=new T.Vector3(x,0,z).project(cam),b=new T.Vector3(g.positions[j],g.positions[j+1],g.positions[j+2]).project(cam);assert.ok(a.distanceTo(b)<1e-10);});
 }
});
