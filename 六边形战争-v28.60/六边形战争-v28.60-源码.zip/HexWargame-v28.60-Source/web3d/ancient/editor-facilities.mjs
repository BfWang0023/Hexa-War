import {inBounds,tile,TERRAIN} from './engine.mjs';
// Edit only existing campaign schemas; never silently enable a fiscal system.
export function editLogisticsPoint(map,tool,team,c,r){
 const fail=reason=>({ok:false,reason});
 if(!['egypt','coalition'].includes(team)||!Number.isInteger(c)||!Number.isInteger(r)||!inBounds(map,c,r))return fail('阵营或地图坐标无效');
 const erase=tool.startsWith('erase-'),depot=tool.includes('depot'),sea=tool==='sea-muster';
 if(!['depot','muster','sea-muster','erase-depot','erase-muster'].includes(tool))return fail('未知后勤工具');
 if(map.logistics){
  if(sea)return fail('本战役只支持陆地召集点');
  const points=map.logistics[depot?'depots':'musters'][team],at=points.findIndex(p=>p.c===c&&p.r===r);
  if(erase){if(at<0)return fail('此格没有所选阵营的该类设施');if(points.length===1)return fail('每方必须保留唯一设施；点击新格直接迁移');points.splice(at,1);return {ok:true};}
  const terrain=tile(map,c,r).terrain;if((terrain&(TERRAIN.SEA|TERRAIN.RIVER))&&!(terrain&TERRAIN.ROAD))return fail('陆地设施不能放在无路水域');
  if(map.logistics[depot?'depots':'musters'][team==='egypt'?'coalition':'egypt'].some(p=>p.c===c&&p.r===r))return fail('此格已有敌方同类设施，请先处理其归属');
  points.splice(0,points.length,{c,r});return {ok:true};
 }
 if(map.recruitment&&!depot){
  if(erase)return fail('此战役的固定召集点必须保留；请选择陆地/海上召集点并点击新格直接迁移');
  const terrain=tile(map,c,r).terrain;if(sea?terrain!==TERRAIN.SEA:!!(terrain&(TERRAIN.SEA|TERRAIN.RIVER)))return fail(sea?'海上召集点只能放在海域':'陆地召集点不能放在水域');
  map.recruitment.muster[team][sea?'sea':'land']={c,r};return {ok:true};
 }
 return fail(depot?'本战役没有粮秣后勤系统；堡垒补给请使用上方“放置补给点”':'本战役没有召集系统，不能放置无效召集点');
}
