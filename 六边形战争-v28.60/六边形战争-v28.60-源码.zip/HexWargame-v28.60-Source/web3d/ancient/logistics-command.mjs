import {planningState} from './fog-policy.mjs';
// Existing logistics only. Feeding remains the engine's end-turn settlement, never an officer side effect.
import {replenishConvoy,distance,key,inBounds,visibleTo,logisticsRouteCut} from './engine.mjs';
import {resolveUnits} from './tactical-units.mjs';
import {resolveLocation} from './tactical-location.mjs';
import {around,centroid,hexFromPlane} from './battlefield-space.mjs';
import {createPlacementProbe} from './formation-doctrine.mjs';
export function logisticsCapabilities(state){state=planningState(state,state.side);return {enabled:!!state.map.logistics,commands:['deliver','refill','connect','guard','reroute','relocate'],supported:state.map.logistics?['convoy_delivery','paid_refill','convoy_from_depot','guard_route']:[],unsupported:['edit_fixed_financial_routes','move_fixed_depots','instant_feed','create_supply_from_nothing'],feeding:'原本方回合补给结算，运输抵达不等于立即加粮'};}
export function logisticsSnapshot(state,team){state=planningState(state,team);const l=state.map.logistics;if(!l)return {enabled:false};const own=state.map.units.filter(u=>u.team===team&&u.hp>0);return {enabled:true,money:state.money?.[team]??0,depots:(l.depots[team]||[]).map(p=>({c:p.c,r:p.r})),routes:(l.routes[team]||[]).filter(p=>visibleTo(state,team,p.c,p.r)).slice(0,24).map(p=>({c:p.c,r:p.r})),convoys:own.filter(u=>u.kind==='supplyWagon').slice(0,16).map(u=>({id:u.id,c:u.c,r:u.r,stock:u.supplyStock||0,credit:u.supplyCredit||0,ap:u.actionsLeft})),rations:own.filter(u=>u.fedTurns!==undefined).slice(0,16).map(u=>({id:u.id,carried:u.fedTurns,hunger:u.hunger||0})),constraints:['粮车24载粮，1点=5饱食度','回仓装粮每点2金，受原仓库/路线/余额限制','到位后依原回合自动供粮，不即时回血加粮','固定财政路线与仓库不能在战局中编辑']};}
export function planLogistics(state,units,step,context){state=planningState(state,context.team);
 if(!state.map.logistics)throw Error('本战役未启用后勤系统，不能建立补给效果');
 if(['reroute','relocate'].includes(step.mode))throw Error(step.mode==='reroute'?'原规则的财政补给线路固定，不能在战局中改写；可明确下令粮车沿道路调运':'原规则不支持迁移固定仓库或补给节点；可调动粮车作为现有移动补给单位');
 const probe=createPlacementProbe(state,units),reserved=new Set(),assignments=[];
 if(step.mode==='guard'){
  const route=state.map.logistics.routes?.[context.team]?.filter(p=>visibleTo(state,context.team,p.c,p.r))||[];if(!route.length)throw Error('没有当前可见的己方补给通道');
  for(const u of units){const choices=[...route].sort((a,b)=>distance(a,u)-distance(b,u)||a.r-b.r||a.c-b.c),p=choices.flatMap(p=>around(p,1)).find(p=>!reserved.has(key(p.c,p.r))&&probe(u,p));if(p)reserved.add(key(p.c,p.r));assignments.push({id:u.id,to:p?{c:p.c,r:p.r}:null,reason:p?'':'通道附近没有可驻守空位'});}return {mode:step.mode,assignments,note:'仅调动现有部队守备，不增加拦截、防御或补给效果'};
 }
 if(units.some(u=>u.kind!=='supplyWagon'))throw Error('运输和回仓装粮命令只能由现有粮车执行');
 const targets=step.target?resolveUnits(state,step.target,context):[];if(step.mode!=='refill'&&!targets.length)throw Error('没有符合条件的受补给部队');
 const deliveryCells=new Map();if(step.mode!=='refill')for(const t of targets)for(const p of around(t,2))if(inBounds(state.map,p.c,p.r))deliveryCells.set(key(p.c,p.r),p);
 const deliveryCandidates=[...deliveryCells.values()].map(p=>({...p,coverage:targets.filter(t=>distance(t,p)<=2).length}));
 for(const u of units){let to=null,refill=null,reason='';if(step.mode==='refill'||step.mode==='connect'){
  const depots=[...(state.map.logistics.depots?.[context.team]||[])].sort((a,b)=>distance(a,u)-distance(b,u));
  refill=depots.flatMap(p=>around(p,1)).sort((a,b)=>distance(a,u)-distance(b,u)||a.r-b.r||a.c-b.c).find(p=>!reserved.has(key(p.c,p.r))&&(distance(u,p)===0||probe(u,p)));if(!refill)reason='己方仓库附近没有合法阵位';
 }
 if(step.mode!=='refill'){
  if(step.mode==='deliver'&&(u.supplyStock||0)*5+(u.supplyCredit||0)<=0)reason='粮车已经空载，请先明确下令回仓装粮';
  const ranked=[...deliveryCandidates].sort((a,b)=>b.coverage-a.coverage||distance(a,u)-distance(b,u)||a.r-b.r||a.c-b.c);
  to=ranked.find(p=>!reserved.has(key(p.c,p.r))&&(distance(u,p)===0||probe(u,p)))||null;if(!to)reason='目标部队两格内没有合法粮车位置';
 }else to=refill;
 if(to)reserved.add(key(to.c,to.r));assignments.push({id:u.id,to:to?{c:to.c,r:to.r}:null,refill:refill?{c:refill.c,r:refill.r}:null,reason});
 }
 return {mode:step.mode,assignments,targetIds:targets.map(u=>u.id),note:step.mode==='refill'?'实际抵仓后调用原付费装粮接口':'运输到位；供粮等待原本方回合结算，不改写固定财政线路'};
}
export function executeConvoyRefill(state,id){return replenishConvoy(state,id);}
export function createLogisticsCommandAPI({getState,tacticalAPI}){return {capabilities:()=>logisticsCapabilities(getState()),execute(select,parameters,context){return tacticalAPI.submit({v:1,confidence:1,clarification:'',orders:[{select,steps:[{type:'logistics',...parameters}]}]},context);}};}
