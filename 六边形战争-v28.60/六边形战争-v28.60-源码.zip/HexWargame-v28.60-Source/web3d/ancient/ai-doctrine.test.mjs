import test from 'node:test';
import assert from 'node:assert/strict';
import { makeChinaMap } from './china-campaigns.mjs';
import { createUnitModel } from './models.mjs';
import { createSave, restoreSave } from './save.mjs';
import { TERRAIN, addUnit, aiTurn, attack, attackPreview, distance, endSide, isRouted,
  mobileAt, moraleLossFactor, newMap, recomputeFog, setFort, setTerrain, startGame } from './engine.mjs';

test('computer occupies an open objective before striking nearby defenders', () => {
  const s = startGame(makeChinaMap('china_xuge'));
  const goal = s.map.victory.objective;
  const soldier = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  const enemy = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  Object.assign(soldier, { c: goal.c - 1, r: goal.r });
  Object.assign(enemy, { c: goal.c - 1, r: goal.r - 1 });
  recomputeFog(s);
  assert.ok(attackPreview(s, soldier, enemy.c, enemy.r));
  const orders = aiTurn(s, () => 0);
  assert.deepEqual(orders.find(a => a.id === soldier.id)?.to &&
    [orders.find(a => a.id === soldier.id).to.c, orders.find(a => a.id === soldier.id).to.r],
    [goal.c, goal.r]);
  assert.equal(s.winner, 'egypt');
});

test('computer soldiers favor a reachable enemy soldier over a wall', () => {
  const m = newMap(14, 9);
  addUnit(m, 'pharaoh', 'egypt', 1, 7);
  addUnit(m, 'heavy', 'egypt', 3, 3);
  addUnit(m, 'light', 'coalition', 4, 3);
  setFort(m, 3, 4, 1, 'coalition');
  const s = startGame(m), soldier = mobileAt(s.map, 3, 3);
  const orders = aiTurn(s, () => 0);
  assert.deepEqual([orders.find(a => a.id === soldier.id)?.type,
    orders.find(a => a.id === soldier.id)?.c, orders.find(a => a.id === soldier.id)?.r],
  ['attack', 4, 3]);
});

test('ordinary soldiers do not waste attacks on an empty unrelated fort', () => {
  const m = newMap(14, 9);
  addUnit(m, 'heavy', 'egypt', 3, 3);
  addUnit(m, 'pharaoh', 'egypt', 1, 7);
  setFort(m, 4, 3, 2, 'coalition');
  const s = startGame(m), soldier = mobileAt(s.map, 3, 3);
  const orders = aiTurn(s, () => 0);
  assert.ok(!orders.some(a => a.id === soldier.id && a.type === 'attack'));
});

test('a living commander follows the main body while staying behind contact', () => {
  const s = startGame(makeChinaMap('china_xuge'));
  const commander = s.map.units.find(u => u.team === 'egypt' && u.kind === 'chinaGeneral');
  commander.c = 4; commander.r = 22;
  recomputeFog(s);
  const before = commander.c;
  const orders = aiTurn(s, () => 0.99);
  assert.ok(orders.some(a => a.type === 'move' && a.id === commander.id));
  assert.ok(commander.c > before);
  assert.ok(s.map.units.filter(u => u.team === 'coalition' && u.hp > 0)
    .every(e => distance(commander, e) >= 3));
});

test('scout discovery direction persists after the scout is lost', () => {
  const m = newMap(32, 14);
  addUnit(m, 'pharaoh', 'egypt', 2, 7);
  addUnit(m, 'cavalry', 'egypt', 5, 7);
  addUnit(m, 'heavy', 'egypt', 4, 7);
  addUnit(m, 'light', 'coalition', 28, 7);
  const s = startGame(m);
  s.map.scenarioId = 'ai_recon_test';
  const scout = mobileAt(s.map, 5, 7), body = mobileAt(s.map, 4, 7);
  const first = aiTurn(s, () => 0.99);
  assert.ok(first.some(a => a.type === 'move' && a.id === scout.id));
  const trail = { ...s.aiIntel.egypt.scoutTrail };
  const restored = restoreSave(JSON.parse(JSON.stringify(createSave(s.map, s, 'egypt')))).game;
  assert.deepEqual(restored.aiIntel.egypt.scoutTrail, trail);
  scout.hp = 0;
  body.c = 4; body.r = 7;
  recomputeFog(s);
  endSide(s);
  const before = distance(body, trail);
  const orders = aiTurn(s, () => 0.99);
  assert.ok(orders.some(a => a.type === 'move' && a.id === body.id));
  assert.ok(distance(body, trail) < before);
});

test('computer force avoids an exposed ford while keeping fast troops near infantry', () => {
  const m = newMap(18, 10);
  addUnit(m, 'pharaoh', 'egypt', 1, 5);
  addUnit(m, 'cavalry', 'egypt', 4, 5);
  addUnit(m, 'heavy', 'egypt', 3, 5);
  addUnit(m, 'archer', 'coalition', 9, 5);
  setTerrain(m, 5, 5, TERRAIN.ROAD | TERRAIN.RIVER);
  setTerrain(m, 5, 6, TERRAIN.MOUNTAIN);
  const s = startGame(m), cavalry = mobileAt(s.map, 4, 5), infantry = mobileAt(s.map, 3, 5);
  const orders = aiTurn(s, () => 0.99);
  assert.ok(orders.filter(a => a.type === 'move' && a.id === cavalry.id)
    .every(a => !(a.to.c === 5 && a.to.r === 5)));
  assert.ok(distance(cavalry, infantry) <= 5);
});

test('distance alone does not drain morale; elite troops resist battle shock and routed bases turn gray', () => {
  const m = newMap(20, 10);
  addUnit(m, 'pharaoh', 'egypt', 1, 2);
  addUnit(m, 'guard', 'egypt', 12, 2);
  addUnit(m, 'light', 'egypt', 12, 3);
  addUnit(m, 'light', 'coalition', 13, 3);
  const s = startGame(m);
  s.map.scenarioId = 'ai_morale_test';
  s.battleJoined = true;
  const elite = mobileAt(s.map, 12, 2), recruit = mobileAt(s.map, 12, 3);
  endSide(s); endSide(s);
  assert.equal(elite.morale, 1);
  assert.equal(recruit.morale, 1);
  assert.ok(moraleLossFactor(elite) < moraleLossFactor(recruit));
  recruit.morale = 0.19;
  assert.equal(isRouted(recruit), true);
  const model = createUnitModel(recruit);
  assert.equal(model.children[0].material.color.getHex(), 0x777c80);
  assert.equal(model.children[1].material.color.getHex(), 0x777c80);
  recomputeFog(s);
  assert.ok(attackPreview(s, elite, recruit.c, recruit.r));
  s.side = 'coalition';
  recomputeFog(s);
  assert.ok(attackPreview(s, mobileAt(s.map, 13, 3), recruit.c, recruit.r));
  s.side = 'egypt';
  assert.equal(attack(s, elite.id, recruit.c, recruit.r, 0).ok, true);
});

test('an idle reserve does not rout because fighting started elsewhere', () => {
  const m = newMap(24, 10);
  addUnit(m, 'pharaoh', 'egypt', 1, 4);
  addUnit(m, 'light', 'egypt', 6, 4);
  addUnit(m, 'light', 'egypt', 20, 4);
  addUnit(m, 'light', 'coalition', 7, 4);
  const s = startGame(m);
  s.map.scenarioId = 'command_morale_test';
  s.battleJoined = true;
  const front = mobileAt(s.map, 6, 4), reserve = mobileAt(s.map, 20, 4);
  for (let i = 0; i < 22; i++) { endSide(s); endSide(s); }
  assert.equal(reserve.morale, 1);
  assert.equal(isRouted(reserve), false);
  assert.ok(front.morale >= 0.4);
  assert.equal(isRouted(front), false);
  front.moraleBoosts = [{ amount: 0.4, remaining: 3 }];
  for (let i = 0; i < 6; i++) { endSide(s); endSide(s); }
  assert.equal(isRouted(front), false);
});
