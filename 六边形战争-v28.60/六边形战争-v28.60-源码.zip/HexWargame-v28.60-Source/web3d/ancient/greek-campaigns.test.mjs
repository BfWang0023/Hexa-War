import test from 'node:test';
import assert from 'node:assert/strict';
import { mantineaMap, aegospotamiMap } from './greek-campaigns.mjs';
import { aiTurn, checkVictory, exportMap, importMap, isTrireme, setPhalanxMode, startGame } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

test('Mantinea preserves the opposing wings, hoplite formations and save state', () => {
  const m = mantineaMap();
  assert.equal(m.units.filter(u => u.team === 'egypt' && u.kind === 'greekHoplite').length, 30);
  assert.equal(m.units.filter(u => u.team === 'coalition' && u.kind === 'greekHoplite').length, 30);
  assert.ok(m.units.some(u => u.formation === '斯巴达与特该亚右翼'));
  assert.ok(m.units.some(u => u.formation === '雅典左翼'));
  const s = startGame(m);
  const hoplite = s.map.units.find(u => u.kind === 'greekHoplite' && u.team === 'egypt');
  assert.equal(setPhalanxMode(s, hoplite.id, true, 0).ok, true);
  assert.equal(restoreSave(createSave(m, s, 'egypt')).game.map.units.find(u => u.id === hoplite.id).formed, true);
  assert.deepEqual(importMap(exportMap(m)).victory, m.victory);
});

test('Aegospotami starts with the Athenians exposed at the beach and allows a squadron escape', () => {
  const m = aegospotamiMap();
  const athens = m.units.filter(u => u.team === 'coalition' && isTrireme(u));
  assert.equal(athens.length, 18);
  assert.ok(athens.every(u => u.r >= 30));
  assert.ok(athens.filter(u => !u.commander).every(u => u.morale === 0.72));
  assert.deepEqual(importMap(exportMap(m)).victory, m.victory);
  const s = startGame(m);
  for (const [i,u] of s.map.units.filter(u => u.team === 'coalition').slice(0, 4).entries()) {
    u.c = 12; u.r = 20 + i * 2;
  }
  checkVictory(s);
  assert.equal(s.winner, 'coalition');
  assert.equal(s.victoryReason, 'aegospotami_escape');
});

test('Greek commanders advance their battle lines and seek the Athenian escape lane', () => {
  for (const make of [mantineaMap, aegospotamiMap]) {
    for (const team of ['egypt', 'coalition']) {
      const s = startGame(make());
      s.side = team;
      const moves = aiTurn(s).filter(a => a.type === 'move');
      assert.ok(moves.length > 0, `${s.map.scenarioId}: ${team} should move`);
      if (s.map.scenarioId === 'aegospotami' && team === 'coalition')
        assert.ok(moves.some(a => a.to.c < a.from.c), 'Athens should head west to escape');
    }
  }
});
