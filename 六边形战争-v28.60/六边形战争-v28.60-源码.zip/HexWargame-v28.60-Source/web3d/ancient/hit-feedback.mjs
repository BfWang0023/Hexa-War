// One brief, per-piece feedback pulse. Shared army materials are never mutated.
export const HIT_FLASH_MS = 180;
const grayMaterials = new WeakMap(), states = new WeakMap();
function gray(material) {
 if (!grayMaterials.has(material)) {
  const copy = material.clone();
  copy.color?.setHex(0x8d8d8d);copy.emissive?.setHex(0x000000);
  copy.userData.hitFlash = true;
  grayMaterials.set(material,copy);
 }
 return grayMaterials.get(material);
}
export function applyHitFlash(root, active) {
 let state = states.get(root);
 if (!state && !active) return;
 if (!state) {
  const meshes=[];
  root.traverse(mesh=>{
   if (!mesh.isMesh || !mesh.material) return;
   const original=mesh.material;
   meshes.push({mesh,original,gray:Array.isArray(original)?original.map(gray):gray(original)});
  });
  state={active:false,meshes};states.set(root,state);
 }
 if (state.active===!!active) return;
 for (const item of state.meshes) item.mesh.material=active?item.gray:item.original;
 state.active=!!active;
}
