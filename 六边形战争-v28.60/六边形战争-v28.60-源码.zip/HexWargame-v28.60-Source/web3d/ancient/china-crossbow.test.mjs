import test from 'node:test';
import assert from 'node:assert/strict';
import { STATS, addUnit, aiTurn, attack, attackPreview, crossbowAttackLimit, meleePower,
  move, neighbors, newMap, reachable, setFort, startGame, unitArmor, unitMaxHp, rangedPower } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

function setup(support = 0) {
  const m = newMap(16, 12);
  m.scenarioId = 'china_maling';
  addUnit(m, 'pharaoh', 'egypt', 0, 0);
  addUnit(m, 'chinaCrossbow', 'egypt', 5, 5);
  for (const p of neighbors(5, 5).slice(2, 2 + support))
    addUnit(m, 'chinaCrossbow', 'egypt', p.c, p.r);
  addUnit(m, 'heavy', 'coalition', 8, 5);
  const s = startGame(m);
  const bow = s.map.units.find(u => u.kind === 'chinaCrossbow' && u.c === 5 && u.r === 5);
  const target = s.map.units.find(u => u.team === 'coalition');
  target.hp = 1000; // Keep the same target for all shots.
  return { s, bow, target };
}

test('Chinese crossbow attack limit follows zero, one or two adjacent friends', () => {
  for (const [support, expected] of [[0, 1], [1, 2], [2, 3]]) {
    const { s, bow, target } = setup(support);
    assert.equal(crossbowAttackLimit(s.map, bow), expected);
    for (let i = 0; i < expected; i++) {
      assert.ok(attackPreview(s, bow, target.c, target.r));
      assert.equal(attack(s, bow.id, target.c, target.r, 0).ok, true);
    }
    assert.equal(bow.attacksUsed, expected);
    assert.equal(bow.actionsLeft, Math.max(0, 2 - expected));
    assert.equal(attackPreview(s, bow, target.c, target.r), null);
    assert.equal(move(s, bow.id, 6, 5).ok, expected === 1);
  }
});

test('moving once allows only one shot; moving twice prevents all shots', () => {
  const once = setup(2);
  assert.equal(move(once.s, once.bow.id, 6, 5).ok, true);
  assert.equal(crossbowAttackLimit(once.s.map, once.bow), 1);
  assert.equal(attack(once.s, once.bow.id, once.target.c, once.target.r, 0).ok, true);
  assert.equal(attackPreview(once.s, once.bow, once.target.c, once.target.r), null);

  const twice = setup(2);
  assert.equal(move(twice.s, twice.bow.id, 6, 5).ok, true);
  assert.equal(move(twice.s, twice.bow.id, 7, 5).ok, true);
  assert.equal(crossbowAttackLimit(twice.s.map, twice.bow), 0);
  assert.equal(attackPreview(twice.s, twice.bow, twice.target.c, twice.target.r), null);
});

test('Chinese crossbowmen can climb and shoot over allied city walls, but enemy walls block bolts', () => {
  const map = newMap(12, 7);
  map.scenarioId = 'china_maling';
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'chinaCrossbow', 'egypt', 2, 2);
  addUnit(map, 'heavy', 'coalition', 5, 2);
  setFort(map, 4, 2, 3, 'egypt', '昆阳');
  const game = startGame(map), bow = game.map.units.find(u => u.kind === 'chinaCrossbow');
  assert.ok(attackPreview(game, bow, 5, 2), 'shoots over an allied wall');
  assert.equal(move(game, bow.id, 3, 2).ok, true);
  assert.ok(reachable(game, bow).has('4,2'), 'can climb the wall');
  assert.equal(move(game, bow.id, 4, 2).ok, true);
  assert.equal(setFort(game.map, 4, 2, 3, 'coalition'), false, 'occupied wall cannot change sides');
  const enemyMap = newMap(12, 7);
  enemyMap.scenarioId = 'china_maling';
  addUnit(enemyMap, 'pharaoh', 'egypt', 0, 0);
  addUnit(enemyMap, 'chinaCrossbow', 'egypt', 2, 2);
  addUnit(enemyMap, 'heavy', 'coalition', 5, 2);
  setFort(enemyMap, 4, 2, 3, 'coalition', '敌城');
  const enemyGame = startGame(enemyMap), enemyBow = enemyGame.map.units.find(u => u.kind === 'chinaCrossbow');
  assert.equal(attackPreview(enemyGame, enemyBow, 5, 2), null, 'cannot shoot through an enemy wall');
});

test('crossbow is stronger at range but weaker in close combat and protection', () => {
  const { s, bow } = setup();
  const archer = { kind: 'archer', team: 'egypt' };
  assert.equal(bow.ammo, 999);
  assert.ok(rangedPower(s.map, bow) > rangedPower(s.map, archer));
  assert.ok(meleePower(bow, s.map) < meleePower(archer, s.map));
  assert.ok(unitMaxHp(s.map, bow) < unitMaxHp(s.map, archer));
  assert.equal(unitArmor(s.map, bow), unitArmor(s.map, archer));
  assert.ok(STATS.chinaCrossbow.meleeHit <= STATS.archer.meleeHit);
});

test('older Chinese saves migrate crossbow health and bolts without healing damage', () => {
  const { s, bow } = setup();
  bow.hp = 70; // Old base 85 with 15 damage.
  bow.ammo = 6;
  const saved = createSave(s.map, s, 'egypt');
  delete saved.rulesVersion;
  const restored = restoreSave(saved).game.map.units.find(u => u.id === bow.id);
  assert.equal(restored.hp, STATS.chinaCrossbow.hp + 60 - 15);
  assert.equal(restored.ammo, 999);
});

test('computer crossbow group can use the third unmoved shot', () => {
  const { s, bow } = setup(2);
  const commands = aiTurn(s, () => 0);
  assert.equal(commands.filter(x => x.id === bow.id && x.type === 'attack').length, 3);
});
