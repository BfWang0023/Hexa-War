import test from 'node:test';
import assert from 'node:assert/strict';
import {makeChinaMap} from './china-campaigns.mjs';
import {mapFor} from '../../tools/ai-training/maps.mjs';
import {startGame,checkVictory,mobileAt,endSide,hasChinaCaptureObjective,armyRoutFraction} from './engine.mjs';
import {createSave,restoreSave} from './save.mjs';
function occupy(s){const p=s.map.victory.objective;const u=s.map.units.find(u=>u.team==='egypt'&&u.kind==='heavy');const present=mobileAt(s.map,p.c,p.r);if(present&&present!==u){present.c=1;present.r=1;}u.c=p.c;u.r=p.r;return u;}
for(const [name,make] of [['generated',()=>makeChinaMap('china_handan')],['bundled',()=>mapFor('china_handan')]]){
 test(`Handan ${name}: occupying Qin camp does not win, including subsequent turns`,()=>{
  const s=startGame(make());occupy(s);checkVictory(s);assert.equal(s.over,false);
  endSide(s,()=>.99);endSide(s,()=>.99);assert.equal(s.over,false);assert.equal(hasChinaCaptureObjective(s.map),false);assert.equal(armyRoutFraction(s.map),.75);
 });
 test(`Handan ${name}: original Qin losses threshold still wins for allied army`,()=>{
  const s=startGame(make());const fighters=s.map.units.filter(u=>u.team==='coalition'&&!['chinaGeneral','fort','supplyWagon','moraleGuard'].includes(u.kind));
  for(const u of fighters.slice(0,s.map.victory.losses.coalition))u.hp=0;
  checkVictory(s);assert.equal(s.winner,'egypt');assert.equal(s.victoryReason,'china_rout');
 });
}
test('Handan retains the original Qin victory conditions',()=>{
 const s=startGame(mapFor('china_handan'));s.map.units.find(u=>u.team==='egypt'&&u.kind==='chinaGeneral').hp=0;checkVictory(s);assert.equal(s.winner,'coalition');
 const hold=startGame(mapFor('china_handan'));hold.turn=hold.map.victory.turnLimit;hold.side='coalition';endSide(hold,()=>.99);assert.equal(hold.winner,'coalition');assert.equal(hold.victoryReason,'china_hold');
});
test('unfinished older Handan saves on Qin camp use the corrected rule on restore',()=>{
 const scenario=mapFor('china_handan'),game=startGame(scenario);occupy(game);
 const save=JSON.parse(JSON.stringify(createSave(scenario,game,'egypt'))),restored=restoreSave(save);checkVictory(restored.game);assert.equal(restored.game.over,false);
});
test('other Chinese campaigns keep their capture objectives',()=>{
 const s=startGame(makeChinaMap('china_xuge'));occupy(s);checkVictory(s);assert.equal(s.winner,'egypt');assert.equal(s.victoryReason,'china_capture');assert.equal(hasChinaCaptureObjective(s.map),true);
});
