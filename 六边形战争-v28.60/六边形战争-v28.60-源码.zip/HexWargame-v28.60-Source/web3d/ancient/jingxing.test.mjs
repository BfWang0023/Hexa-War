import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from './engine.mjs';
import { makeImperialMap } from './imperial-campaigns.mjs';
import { CAMPAIGN_CATALOG } from './campaign-catalog.mjs';

const raw = () => JSON.parse(readFileSync(new URL('./bundled-maps/china_jingxing.json', import.meta.url)));
const troops = (map, team) => map.units.filter(u => u.team === team && !['fort','moraleGuard'].includes(u.kind));
for (const [name, makeMap, count] of [
  ['bundled', () => E.importMap(raw()), 53],
  ['generated', () => makeImperialMap('china_jingxing'), 39],
]) {
  test(`Jingxing ${name}: expanded Zhao roster survives map round trip and has legal deployment`, () => {
    const map = E.importMap(E.exportMap(makeMap()));
    assert.equal(troops(map,'coalition').length,count);
    const added = map.units.slice(-16);
    assert.equal(added.length,16);
    for (const u of added) {
      assert.equal(u.team,'coalition');
      assert.equal(E.fortAt(map,u.c,u.r),null);
      assert.equal(map.units.filter(x=>x.c===u.c&&x.r===u.r).length,1);
    }
    assert.equal(E.startGame(map).map.victory.losses.coalition,Math.ceil((count-1)*.75));
  });
  test(`Jingxing ${name}: round 30 is not a victory; original combat and capture victories still work`, () => {
    const s = E.startGame(makeMap());
    assert.equal(s.map.victory.turnLimit,null);
    s.turn=30;s.side='coalition';
    E.endSide(s,()=>.99);
    assert.equal(s.over,false);
    assert.equal(s.turn,31);
    const han = troops(s.map,'egypt').filter(u=>u.kind!=='chinaGeneral');
    han.slice(0,s.map.victory.losses.egypt).forEach(u=>u.hp=0);
    assert.equal(E.checkVictory(s),'coalition');
    const capture=E.startGame(makeMap());
    const objective=capture.map.victory.objective;
    const occupant=E.mobileAt(capture.map,objective.c,objective.r);
    const attacker=troops(capture.map,'egypt').find(u=>u.kind==='heavy');
    if(occupant)Object.assign(occupant,{c:attacker.c,r:attacker.r});
    Object.assign(attacker,objective);
    assert.equal(E.checkVictory(capture),'egypt');
  });
}

test('bundled Jingxing keeps the existing map and units intact', () => {
  const prior=JSON.parse(readFileSync(new URL('../../docs/jingxing-v28.43/before/china_jingxing.json',import.meta.url)));
  const current=raw();
  assert.equal(current.victory.losses.coalition,39);
  current.units.splice(prior.units.length);
  current.victory=prior.victory;
  assert.deepEqual(current,prior);
});

test('legacy Jingxing maps with a stored deadline also continue past turn 30', () => {
  const data=raw();data.victory.turnLimit=30;
  const s=E.startGame(E.importMap(data));s.turn=30;s.side='coalition';
  E.endSide(s,()=>.99);assert.equal(s.over,false);assert.equal(s.turn,31);
});

test('every catalog campaign has its own illustration', () => {
  const art=CAMPAIGN_CATALOG.map(({id})=>readFileSync(new URL(`./assets/campaign-covers/${id}.svg`,import.meta.url),'utf8'));
  assert.ok(art.every(s=>s.startsWith('<svg ')));
  assert.equal(new Set(art).size,CAMPAIGN_CATALOG.length);
});
