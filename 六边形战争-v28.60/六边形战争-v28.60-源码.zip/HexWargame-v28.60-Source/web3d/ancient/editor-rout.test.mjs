import test from 'node:test';
import assert from 'node:assert/strict';
import { addUnit, aiTurn, applyNearbyRoutMorale, attack, attackPreview, exportMap, importMap,
  isRouted, meleePower, newMap, resolveRouts, setUnitStats, startGame, unitArmor,
  unitMaxHp, unitName, unitStats } from './engine.mjs';
import { createSave, restoreSave } from './save.mjs';

function sandbox() {
  const map = newMap(20, 12);
  map.scenarioId = 'custom_test';
  map.name = '我的战役';
  map.factions = { egypt: '蓝军', coalition: '红军' };
  assert.equal(addUnit(map, 'pharaoh', 'egypt', 2, 2), true);
  assert.equal(addUnit(map, 'heavy', 'coalition', 16, 8), true);
  return map;
}

test('custom campaign keeps terrain, unit type stats, type name and individual name through map and save', () => {
  const map = sandbox();
  assert.equal(addUnit(map, 'archer', 'egypt', 5, 5), true);
  const archer = map.units.at(-1);
  archer.customName = '左翼第一弩队';
  map.unitNames = { archer: '新式弓兵' };
  setUnitStats(map, 'archer', { hp: 90, armor: 3, move: 2, vision: 7, melee: 3,
    meleeHit: 75, ranged: 9, rangedHit: 88, range: 4, ammo: 40 });
  assert.equal(unitMaxHp(map, archer), 90);
  assert.equal(archer.hp, 90);
  assert.equal(unitArmor(map, archer), 3);
  assert.equal(unitStats(map, archer).ranged, 9);
  assert.equal(unitName(map, archer), '左翼第一弩队');
  const restored = importMap(exportMap(map));
  assert.equal(restored.unitNames.archer, '新式弓兵');
  assert.equal(restored.unitStats.archer.range, 4);
  assert.equal(unitName(restored, restored.units.find(u => u.kind === 'archer')), '左翼第一弩队');
  assert.equal(addUnit(restored, 'archer', 'egypt', 6, 5), true);
  assert.equal(restored.units.at(-1).hp, 90);
  assert.equal(restored.units.at(-1).ammo, 40);
  assert.equal(unitName(restored, restored.units.at(-1)), '新式弓兵');
  const save = createSave(restored, startGame(restored), 'egypt');
  const loaded = restoreSave(save);
  assert.equal(loaded.scenario.name, '我的战役');
  assert.equal(loaded.game.map.unitStats.archer.ranged, 9);
  assert.equal(loaded.game.map.units.find(u => u.customName)?.customName, '左翼第一弩队');
});

test('routed soldier has one health, no attack or armor, flees one cell and either side can spend one attack to kill', () => {
  const map = sandbox();
  assert.equal(addUnit(map, 'light', 'egypt', 8, 6), true);
  assert.equal(addUnit(map, 'light', 'egypt', 9, 6), true);
  assert.equal(addUnit(map, 'light', 'coalition', 10, 6), true);
  const game = startGame(map);
  const routed = game.map.units.find(u => u.c === 9 && u.r === 6);
  routed.morale = 0.1;
  const fled = resolveRouts(game);
  assert.equal(isRouted(routed), true);
  assert.equal(routed.hp, 10);
  assert.equal(unitArmor(game.map, routed), 0);
  assert.equal(meleePower(routed, game.map), 0);
  assert.ok(fled.filter(event => event.id === routed.id).length <= 1);
  const friendly = game.map.units.find(u => u.c === 8 && u.r === 6);
  routed.c = 9; routed.r = 6; friendly.actionsLeft = 2;
  assert.equal(attackPreview(game, friendly, 9, 6)?.hit, 100);
  const result = attack(game, friendly.id, 9, 6, 0.99);
  assert.equal(result.ok, true);
  assert.equal(routed.hp, 0);
  assert.equal(friendly.actionsLeft, 1);

  const foe = game.map.units.find(u => u.team === 'coalition' && u.c === 10 && u.r === 6);
  const second = game.map.units.find(u => u.team === 'egypt' && u.c === 8 && u.r === 6);
  second.routed = true; second.hp = 10;
  second.c = 9; second.r = 6;
  game.side = 'coalition'; foe.actionsLeft = 2;
  assert.equal(attack(game, foe.id, 9, 6, 0.99).ok, true);
  assert.equal(second.hp, 0);
  assert.equal(foe.actionsLeft, 1);
});

test('three adjacent friendly routed troops lower morale, and three enemy routed troops raise it', () => {
  const map = sandbox();
  assert.equal(addUnit(map, 'light', 'egypt', 9, 6), true);
  const game = startGame(map);
  const center = game.map.units.find(u => u.c === 9 && u.r === 6);
  const cells = [{ c: 8, r: 6 }, { c: 10, r: 6 }, { c: 9, r: 5 }];
  for (const p of cells) {
    assert.equal(addUnit(game.map, 'light', 'egypt', p.c, p.r), true);
    const unit = game.map.units.at(-1); unit.routed = true; unit.hp = 10;
  }
  game.map.units.find(u => u.c === cells[2].c && u.r === cells[2].r).routed = false;
  applyNearbyRoutMorale(game, 'egypt');
  assert.equal(center.morale, 1);
  game.map.units.find(u => u.c === cells[2].c && u.r === cells[2].r).routed = true;
  applyNearbyRoutMorale(game, 'egypt');
  assert.equal(center.morale, 0.95);
  applyNearbyRoutMorale(game, 'egypt');
  assert.equal(center.morale, 0.95);
  for (const p of cells) game.map.units.find(u => u.c === p.c && u.r === p.r).team = 'coalition';
  applyNearbyRoutMorale(game, 'egypt');
  assert.equal(center.morale, 1.05);
  applyNearbyRoutMorale(game, 'egypt');
  assert.equal(center.morale, 1.05);
  const loaded = restoreSave(createSave(map, game, 'egypt')).game;
  const loadedCenter = loaded.map.units.find(u => u.id === center.id);
  applyNearbyRoutMorale(loaded, 'egypt');
  assert.equal(loadedCenter.morale, 1.05);
});

test('fleeing soldiers do not count as combat capable encircling enemies', () => {
  const map = sandbox();
  addUnit(map, 'light', 'egypt', 9, 6);
  const game = startGame(map), center = game.map.units.find(u => u.c === 9 && u.r === 6);
  for (const p of [{ c: 8, r: 6 }, { c: 10, r: 6 }, { c: 9, r: 5 }]) {
    addUnit(game.map, 'light', 'coalition', p.c, p.r);
    game.map.units.at(-1).routed = true;
  }
  resolveRouts(game);
  assert.equal(center.morale, 1);
});

test('encirclement morale shock is not repeated while the same trap persists', () => {
  const map = sandbox();
  addUnit(map, 'light', 'egypt', 9, 6);
  const attackers = [{ c: 8, r: 6 }, { c: 10, r: 6 }, { c: 9, r: 5 }];
  for (const p of attackers) addUnit(map, 'light', 'coalition', p.c, p.r);
  const game = startGame(map), center = game.map.units.find(u => u.c === 9 && u.r === 6);
  assert.equal(center.morale, 0.88);
  for (let i = 0; i < 8; i++) resolveRouts(game);
  assert.equal(center.morale, 0.88);
  const attacker = game.map.units.find(u => u.c === 8 && u.r === 6);
  attacker.c = 3; attacker.r = 8;
  resolveRouts(game);
  attacker.c = 8; attacker.r = 6;
  resolveRouts(game);
  assert.equal(center.morale, 0.76);
});

test('computer can finish a friendly routed soldier when no enemy is in attack range', () => {
  const map = sandbox();
  addUnit(map, 'light', 'egypt', 8, 6);
  addUnit(map, 'light', 'egypt', 9, 6);
  const game = startGame(map);
  const routed = game.map.units.find(u => u.c === 9 && u.r === 6);
  routed.routed = true; routed.hp = 10;
  aiTurn(game, () => 0.1);
  assert.equal(routed.hp, 0);
});

test('an older save converts living routed soldiers to one health without changing normal troops', () => {
  const map = sandbox();
  addUnit(map, 'light', 'egypt', 7, 6);
  const game = startGame(map);
  const routed = game.map.units.find(u => u.c === 7 && u.r === 6);
  routed.morale = 0.1;
  const saved = createSave(map, game, 'egypt');
  saved.rulesVersion = 6;
  const loaded = restoreSave(saved).game;
  assert.equal(loaded.map.units.find(u => u.id === routed.id).hp, 10);
  assert.equal(loaded.map.units.find(u => u.id === routed.id).routed, true);
  assert.equal(loaded.map.units.find(u => u.kind === 'pharaoh').hp, 60);
});

test('invalid edited unit stats and names are rejected on import', () => {
  const base = exportMap(sandbox());
  assert.throws(() => importMap({ ...base, unitStats: { light: { move: 99 } } }), /兵种数值无效/);
  const named = structuredClone(base);
  named.units.find(u => u.kind === 'pharaoh').customName = 'X'.repeat(33);
  assert.throws(() => importMap(named), /部队名称无效/);
});
