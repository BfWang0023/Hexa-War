import test from 'node:test';
import assert from 'node:assert/strict';
import { TERRAIN, FORT_HP, FORT_SHARE, FORT_ARMOR, STATS, TROY_COSTS, TROY_UNIT_NAMES, addUnit, attack, attackPreview, beginBattle, canPlaceKind, checkVictory, cargoLoad, cargoOf, disembark, embark, heroPower, elephantPanicChance, recruit, troyMap, qarqarMap, babylonMap, salamisMap, advanceWeather, houseAt, setHouse, moraleOf, isRouted,
  aiTurn, deployUnit, distance, endSide, exportMap, fortAt, importMap, inBounds, index, inDeployment, key, kadeshMap, knownTo, knownUnitAt, megiddoMap, neighbors,
  mobileAt, move, moleLanes, nextMoleCell, nextMoleCells, buildMole, alesiaMap, pharsalusMap, actiumMap, teutoburgMap, jerusalemMap, carrhaeMap, syracuseMap, pydnaMap, alesiaWorkOptions, buildAlesiaWork, turnShip, turnRomanLine, withdrawCenter, setPhalanxMode, turnPhalanx, moveUncontrolledElephants, gaugamelaMap, issusMap, tyreMap, cannaeMap, zamaMap, carthageMap, carthageSeaSecured,
  unitMaxHp, unitArmor, rangedPower,
  newMap, reachable, recomputeFog, setFort, setSupplyPoint, setTerrain, setBridge, bridgeAt, destroyBridge, startGame as startGameCurrent, startTroyTurn65, tile, unitName, visibleTo, fmt, meleePower } from './engine.mjs';
// Legacy v10 regression contract; v11 is covered in elevation-rules.test.mjs.
const startGame = map => startGameCurrent(map,{rulesVersion:10});

function duel(level = 0) {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  if (level) setFort(map, 3, 2, level, 'coalition');
  addUnit(map, 'light', 'coalition', 3, 2);
  return startGame(map);
}

test('crossbowmen on mountain ground and mountain walls can shoot across a ridge', () => {
  for (const wall of [false, true]) {
    const map = newMap(9, 6);
    map.scenarioId = 'custom_crossbow_test';
    addUnit(map, 'pharaoh', 'egypt', 0, 0);
    setTerrain(map, 2, 2, TERRAIN.MOUNTAIN);
    setTerrain(map, 3, 2, TERRAIN.MOUNTAIN);
    if (wall) setFort(map, 2, 2, 2, 'egypt');
    addUnit(map, 'chinaCrossbow', 'egypt', 2, 2);
    addUnit(map, 'heavy', 'coalition', 4, 2);
    const game = startGame(map);
    const crossbow = mobileAt(game.map, 2, 2);
    assert.equal(visibleTo(game, 'egypt', 4, 2), true, wall ? 'mountain wall sight' : 'mountain sight');
    assert.ok(attackPreview(game, crossbow, 4, 2), wall ? 'mountain wall shot' : 'mountain shot');
  }
});

test('linked level-two walls give soldiers one extra movement along the wall only', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  for (const c of [2, 3, 4]) {
    setTerrain(map, c, 2, TERRAIN.MOUNTAIN);
    setFort(map, c, 2, 2, 'egypt');
  }
  addUnit(map, 'heavy', 'egypt', 2, 2);
  addUnit(map, 'heavy', 'coalition', 9, 5);
  const game = startGame(map), soldier = mobileAt(game.map, 2, 2);
  assert.equal(reachable(game, soldier).has(key(4, 2)), true);
  assert.equal(reachable(game, soldier).has(key(3, 3)), false);
  assert.equal(move(game, soldier.id, 4, 2).ok, true);
  const broken = startGame(map);
  const middle = fortAt(broken.map, 3, 2);
  middle.hp = 0;
  assert.equal(reachable(broken, mobileAt(broken.map, 2, 2)).has(key(4, 2)), false);
  const weak = startGame(map);
  fortAt(weak.map, 3, 2).level = 1;
  assert.equal(reachable(weak, mobileAt(weak.map, 2, 2)).has(key(4, 2)), false);
});

test('AI strength changes order budget and tactical target selection', () => {
  const setup = difficulty => {
    const map = newMap(12, 8);
    addUnit(map, 'pharaoh', 'egypt', 10, 7);
    addUnit(map, 'heavy', 'egypt', 5, 4);
    addUnit(map, 'light', 'egypt', 3, 4);
    addUnit(map, 'archer', 'coalition', 4, 4);
    const s = startGame(map);
    s.side = 'coalition'; s.aiDifficulty = difficulty;
    s.map.units.find(u => u.kind === 'heavy').hp = 5;
    recomputeFog(s);
    return s;
  };
  const easy = aiTurn(setup('easy'), () => 0);
  assert.equal(easy.filter(a => a.type === 'attack').length, 1);
  const normal = aiTurn(setup('normal'), () => 0);
  assert.deepEqual([normal[0].c, normal[0].r], [3, 4]);
  const hard = aiTurn(setup('hard'), () => 0);
  assert.deepEqual([hard[0].c, hard[0].r], [5, 4]);
});

test('computer infantry forms toward contact and leaves formation for a long approach', () => {
  const map = newMap(12, 8);
  addUnit(map, 'romanLegion', 'egypt', 3, 3);
  addUnit(map, 'heavy', 'coalition', 4, 3);
  addUnit(map, 'pharaoh', 'egypt', 10, 7);
  const close = startGame(map);
  const legion = mobileAt(close.map, 3, 3);
  close.side = 'egypt'; recomputeFog(close);
  const orders = aiTurn(close, () => 0.99);
  assert.deepEqual(orders[0], { type: 'phalanxMode', id: legion.id, formed: true, facing: 0 });
  assert.equal(legion.formed, true);

  const farMap = newMap(12, 8);
  addUnit(farMap, 'romanLegion', 'egypt', 2, 3);
  addUnit(farMap, 'heavy', 'coalition', 6, 3);
  addUnit(farMap, 'pharaoh', 'egypt', 10, 7);
  const far = startGame(farMap);
  const farLegion = mobileAt(far.map, 2, 3);
  farLegion.formed = true;
  far.side = 'egypt'; recomputeFog(far);
  const farOrders = aiTurn(far, () => 0.99);
  assert.equal(farOrders[0]?.type, 'phalanxMode');
  assert.equal(farOrders[0]?.formed, false);
});

test('computer siege engine spends its available shot on a wall before a field target', () => {
  const map = newMap(12, 8);
  addUnit(map, 'romanOnager', 'egypt', 2, 2);
  setFort(map, 5, 2, 2, 'coalition');
  addUnit(map, 'archer', 'coalition', 2, 5);
  addUnit(map, 'pharaoh', 'egypt', 10, 7);
  const s = startGame(map);
  const engine = mobileAt(s.map, 2, 2);
  s.side = 'egypt'; recomputeFog(s);
  const orders = aiTurn(s, () => 0.99);
  assert.deepEqual([orders[0]?.type, orders[0]?.id, orders[0]?.c, orders[0]?.r],
    ['attack', engine.id, 5, 2]);
});

test('computer infantry chooses a covered approach when routes are equally short', () => {
  const map = newMap(12, 8);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  addUnit(map, 'pharaoh', 'egypt', 10, 7);
  addUnit(map, 'heavy', 'coalition', 4, 1);
  setHouse(map, 2, 1);
  setTerrain(map, 3, 2, TERRAIN.RIVER);
  const s = startGame(map);
  s.side = 'egypt'; recomputeFog(s);
  const orders = aiTurn(s, () => 0.99);
  assert.deepEqual([orders[0]?.type, orders[0]?.to?.c, orders[0]?.to?.r], ['move', 2, 1]);
});

test('Syracuse and Pydna maps round trip with their objectives and both armies', () => {
  for (const make of [syracuseMap, pydnaMap]) {
    const original = make(), copy = importMap(exportMap(original));
    assert.equal(copy.scenarioId, original.scenarioId);
    assert.deepEqual(copy.victory, original.victory);
    assert.equal(copy.units.length, original.units.length);
    assert.ok(copy.units.some(u => u.team === 'egypt' && u.hp > 0));
    assert.ok(copy.units.some(u => u.team === 'coalition' && u.hp > 0));
    assert.equal(startGame(copy).over, false);
  }
});

test('Syracuse requires both wall breaches and infantry occupation', () => {
  const s = startGame(syracuseMap()), v = s.map.victory;
  const legion = s.map.units.find(u => u.team === 'egypt' && u.kind === 'romanLegion');
  Object.assign(legion, v.capture);
  checkVictory(s);
  assert.equal(s.over, false);
  for (const id of v.walls) s.map.units.find(u => u.kind === 'fort' && u.cityId === id).hp = 0;
  checkVictory(s);
  assert.equal(s.winner, 'egypt');
  const held = startGame(syracuseMap());
  held.turn = held.map.victory.turnLimit;
  held.side = 'coalition'; endSide(held);
  assert.equal(held.winner, 'coalition');
});

test('Pydna rough ground exposes phalangites and losses decide the battle', () => {
  const s = startGame(pydnaMap());
  const roman = s.map.units.find(u => u.team === 'egypt' && u.kind === 'romanLegion');
  const pike = s.map.units.find(u => u.team === 'coalition' && u.kind === 'phalangite');
  Object.assign(roman,{c:30,r:21,formed:false,actionsLeft:2});
  Object.assign(pike,{c:31,r:21,formed:false,hp:100});
  setTerrain(s.map,31,21,TERRAIN.PLAIN); recomputeFog(s);
  const open = attackPreview(s,roman,31,21)?.damage;
  setTerrain(s.map,31,21,TERRAIN.MOUNTAIN); recomputeFog(s);
  const rough = attackPreview(s,roman,31,21)?.damage;
  assert.ok(rough > open, `rough ${rough}, open ${open}`);
  for (const u of s.map.units.filter(u => u.team === 'coalition' && !['hannibal','fort'].includes(u.kind)).slice(0,s.map.victory.macedonianLosses)) u.hp=0;
  checkVictory(s);
  assert.equal(s.winner,'egypt');
});

test('Carrhae preserves its Roman escape, Parthian cavalry, and camel supply in exported maps', () => {
  const copy = importMap(exportMap(carrhaeMap()));
  assert.equal(copy.victory.mode, 'carrhae');
  assert.equal(copy.victory.escapeUnits, 10);
  assert.equal(copy.units.filter(u => u.kind === 'parthianHorseArcher').length, 8);
  assert.equal(copy.units.filter(u => u.kind === 'parthianCataphract').length, 2);
  assert.equal(copy.units.filter(u => u.kind === 'arrowCamel').length, 2);
  assert.equal(unitName(copy, copy.units.find(u => u.kind === 'scipio')), '马库斯·李锡尼·克拉苏');
});

test('Carrhae horse archer can shoot at contact, feign retreat, and replenish by camel', () => {
  const s = startGame(carrhaeMap());
  const archer = s.map.units.find(u => u.kind === 'parthianHorseArcher');
  const roman = s.map.units.find(u => u.kind === 'romanLegion');
  const camel = s.map.units.find(u => u.kind === 'arrowCamel');
  Object.assign(archer, {c:10,r:20,ammo:1});
  Object.assign(roman, {c:11,r:20});
  Object.assign(camel, {c:8,r:21});
  s.side = 'coalition'; recomputeFog(s);
  assert.equal(attackPreview(s,archer,11,20)?.melee,false);
  assert.equal(move(s,archer.id,8,20).ok,true);
  assert.equal(archer.feignedRetreat,true);
  const boosted = attackPreview(s,archer,11,20);
  archer.feignedRetreat = false;
  const ordinary = attackPreview(s,archer,11,20);
  assert.ok(boosted.damage > ordinary.damage);
  archer.feignedRetreat = true;
  assert.equal(attack(s,archer.id,11,20,0).ok,true);
  assert.equal(archer.ammo,0);
  assert.equal(attackPreview(s,archer,11,20),null);
  endSide(s); endSide(s);
  assert.equal(archer.ammo,3);
});

test('Carrhae resolves Roman escape, Parthian losses, Crassus death, and deadline', () => {
  const escape = startGame(carrhaeMap());
  const romans = escape.map.units.filter(u => u.team === 'egypt' && u.kind === 'romanLegion');
  const crassus = escape.map.units.find(u => u.kind === 'scipio');
  crassus.c = 5; crassus.r = 21;
  romans.slice(0,10).forEach((u,i) => { u.c = 5; u.r = 14+i; });
  assert.equal(checkVictory(escape),'egypt');
  const routed = startGame(carrhaeMap());
  routed.map.units.filter(u => u.kind === 'parthianHorseArcher').slice(0,routed.map.victory.parthianLosses)
    .forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(routed),'egypt');
  const leader = startGame(carrhaeMap());
  leader.map.units.find(u => u.kind === 'scipio').hp = 0;
  assert.equal(checkVictory(leader),'coalition');
  const held = startGame(carrhaeMap());
  held.turn = 24; held.side = 'coalition'; endSide(held);
  assert.equal(held.victoryReason,'carrhae_hold');
});

test('Teutoburg has a Roman road column, wooded flanks and a saveable escape rule', () => {
  const m = teutoburgMap(), copy = importMap(exportMap(m));
  assert.equal(copy.victory.mode, 'teutoburg');
  assert.equal(copy.units.filter(u => u.kind === 'romanLegion').length, 18);
  assert.equal(copy.units.filter(u => u.kind === 'gaulInfantry').length, 18);
  assert.equal(copy.units.filter(u => u.kind === 'punicSkirmisher').length, 12);
  assert.equal(unitName(copy, copy.units.find(u => u.kind === 'scipio')), '普布利乌斯·昆克蒂利乌斯·瓦卢斯');
  assert.equal(tile(copy, 40, 24).terrain, TERRAIN.ROAD);
  assert.equal(tile(copy, 40, 18).terrain, TERRAIN.MOUNTAIN);
  assert.equal(tile(copy, 24, 38).terrain, TERRAIN.RIVER);
});

test('Teutoburg can end by Roman escape, losses, Varus death or held road', () => {
  const escape = startGame(teutoburgMap());
  const roman = escape.map.units.filter(u => u.team === 'egypt' && u.kind !== 'scipio');
  const varus = escape.map.units.find(u => u.kind === 'scipio');
  varus.c = 9; varus.r = 24;
  roman.slice(0, 8).forEach((u, i) => { u.c = 8 + i % 3; u.r = 20 + i; });
  assert.equal(checkVictory(escape), 'egypt');
  assert.equal(escape.victoryReason, 'teutoburg_escape');
  const losses = startGame(teutoburgMap());
  losses.map.units.filter(u => u.team === 'coalition' && u.kind !== 'hannibal')
    .slice(0, losses.map.victory.germanLosses).forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(losses), 'egypt');
  const leader = startGame(teutoburgMap());
  leader.map.units.find(u => u.kind === 'scipio').hp = 0;
  assert.equal(checkVictory(leader), 'coalition');
  const deadline = startGame(teutoburgMap());
  deadline.turn = 18; deadline.side = 'coalition'; endSide(deadline);
  assert.equal(deadline.victoryReason, 'teutoburg_hold');
});

test('Teutoburg woodland ambush bonus expires after turn three', () => {
  const s = startGame(teutoburgMap());
  const attacker = s.map.units.find(u => u.kind === 'gaulInfantry');
  const defender = s.map.units.find(u => u.kind === 'romanLegion');
  Object.assign(attacker, { c: 40, r: 20 });
  Object.assign(defender, { c: 40, r: 21 });
  s.side = 'coalition'; recomputeFog(s);
  const ambush = attackPreview(s, attacker, 40, 21);
  assert.ok(ambush?.melee);
  s.turn = 4;
  assert.equal(ambush.damage - attackPreview(s, attacker, 40, 21).damage, 20);
});

test('Jerusalem has three northern walls, Antonia, Temple, and Roman siege weapons', () => {
  const m = jerusalemMap(), copy = importMap(exportMap(m));
  assert.equal(copy.victory.mode, 'jerusalem');
  assert.deepEqual(copy.victory.stages.map(s => s.name), ['新城','中城','安东尼亚堡','圣殿区','上城']);
  for (const id of ['第三道城墙','第二道城墙','第一道城墙','安东尼亚堡','圣殿区围墙'])
    assert.ok(copy.units.some(u => u.kind === 'fort' && u.cityId === id));
  assert.equal(copy.units.filter(u => u.kind === 'siegeTower').length, 2);
  assert.equal(copy.units.filter(u => u.kind === 'romanOnager').length, 3);
  assert.equal(copy.units.filter(u => u.kind === 'siegeRam').length, 3);
  assert.equal(unitName(copy, copy.units.find(u => u.kind === 'scipio')), '提图斯');
  assert.equal(startGame(copy).jerusalemStage, 0);
});

test('Jerusalem advances through each breached wall and captured sector', () => {
  const s = startGame(jerusalemMap());
  const roman = s.map.units.find(u => u.kind === 'romanLegion');
  for (let i = 0; i < s.map.victory.stages.length; i++) {
    const goal = s.map.victory.stages[i];
    for (const wall of goal.walls) s.map.units.find(u => u.kind === 'fort' && u.cityId === wall).hp = 0;
    roman.c = goal.c; roman.r = goal.r;
    checkVictory(s);
    assert.equal(s.jerusalemStage, i + 1);
  }
  assert.equal(s.winner, 'egypt');
  const lost = startGame(jerusalemMap());
  lost.map.units.find(u => u.kind === 'scipio').hp = 0;
  assert.equal(checkVictory(lost), 'coalition');
  const held = startGame(jerusalemMap());
  held.turn = 50; held.side = 'coalition'; endSide(held);
  assert.equal(held.victoryReason, 'jerusalem_hold');
});

test('Jerusalem siege tower fires once per round from range four', () => {
  const s = startGame(jerusalemMap());
  const tower = s.map.units.find(u => u.kind === 'siegeTower');
  const wall = s.map.units.find(u => u.kind === 'fort' && u.cityId === '第三道城墙' && u.c === 42);
  tower.c = 42; tower.r = 16; recomputeFog(s);
  assert.ok(attackPreview(s,tower,wall.c,wall.r));
  const result = attack(s,tower.id,wall.c,wall.r,0);
  assert.equal(result.ok,true);
  assert.equal(attackPreview(s,tower,wall.c,wall.r),null);
});

test('Pharsalus has opposing Roman armies, a fourth line, and saveable victory rules', () => {
  const m = pharsalusMap(), copy = importMap(exportMap(m));
  assert.equal(copy.victory.mode, 'pharsalus');
  assert.equal(copy.units.filter(u => u.kind === 'caesarReserve').length, 4);
  assert.equal(copy.units.filter(u => u.kind === 'pompeyHorse').length, 10);
  assert.equal(copy.units.filter(u => u.kind === 'pompeyLegion').length, 44);
  assert.equal(copy.units.filter(u => u.team === 'egypt' && u.kind !== 'fort' && u.kind !== 'scipio').length, 30);
  assert.equal(copy.units.filter(u => u.team === 'coalition' && u.kind !== 'fort' && u.kind !== 'hannibal').length, 59);
  assert.equal(unitName(copy, copy.units.find(u => u.kind === 'scipio')), '盖乌斯·尤利乌斯·恺撒');
  assert.ok(copy.terrain.some(t => t & TERRAIN.RIVER));
  assert.ok(copy.units.filter(u => u.kind === 'pompeyLegion').every(u => u.facing === 3));
  assert.equal(startGame(copy).side, 'egypt');
});

test('Pharsalus victory and turn limit compare combat losses', () => {
  const s = startGame(pharsalusMap());
  s.map.units.filter(u => u.team === 'coalition' && u.kind !== 'fort' && u.kind !== 'hannibal')
    .slice(0, s.map.victory.pompeyLosses).forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(s), 'egypt');
  const other = startGame(pharsalusMap());
  other.map.units.filter(u => u.team === 'egypt' && u.kind !== 'fort' && u.kind !== 'scipio')
    .slice(0, other.map.victory.caesarLosses).forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(other), 'coalition');
  const deadline = startGame(pharsalusMap());
  deadline.turn = 20; deadline.side = 'coalition'; endSide(deadline);
  assert.equal(deadline.victoryReason, 'pharsalus_draw');
});

test('Caesar fourth line deals extra melee damage to Pompeian cavalry', () => {
  const s = startGame(pharsalusMap());
  const reserve = s.map.units.find(u => u.kind === 'caesarReserve');
  const cavalry = s.map.units.find(u => u.kind === 'pompeyHorse');
  Object.assign(reserve, { c: 39, r: 10 });
  Object.assign(cavalry, { c: 40, r: 10 });
  recomputeFog(s);
  const withReserve = attackPreview(s, reserve, 40, 10);
  assert.ok(withReserve?.melee);
  s.map.scenarioId = 'cannae';
  const ordinary = attackPreview(s, reserve, 40, 10);
  assert.equal(withReserve.damage - ordinary.damage, 25);
});

test('Actium places fast and heavy fleets around a navigable gulf entrance', () => {
  const m = actiumMap(), copy = importMap(exportMap(m));
  assert.equal(copy.victory.mode, 'actium');
  assert.equal(copy.units.filter(u => u.kind === 'octavianLiburnian').length, 23);
  assert.equal(copy.units.filter(u => u.kind === 'antonyHeavyGalley').length, 24);
  assert.equal(copy.units.filter(u => u.kind === 'cleopatraGalley').length, 6);
  assert.ok(copy.units.some(u => u.commander === '阿格里帕'));
  assert.ok(copy.units.some(u => u.commander === '安东尼'));
  assert.ok(copy.units.some(u => u.commander === '克娄巴特拉'));
  assert.equal(tile(copy, 42, 25).terrain, TERRAIN.SEA);
  assert.equal(tile(copy, 42, 36).terrain, TERRAIN.PLAIN);
  assert.equal(tile(copy, 12, 24).terrain, TERRAIN.SEA);
  assert.equal(startGame(copy).side, 'egypt');
});

test('Actium can end by escorted breakout, ship losses or a held blockade', () => {
  const escape = startGame(actiumMap());
  const convoy = escape.map.units.filter(u => u.team === 'coalition' &&
    (u.commander === '安东尼' || u.commander === '克娄巴特拉' || u.kind === 'cleopatraGalley'));
  for (const [i,u] of convoy.slice(0, 5).entries()) Object.assign(u, { c: 11, r: 20 + i * 2 });
  assert.equal(checkVictory(escape), 'coalition');
  assert.equal(escape.victoryReason, 'actium_escape');
  const interception = startGame(actiumMap());
  interception.map.units.find(u => u.commander === '克娄巴特拉').hp = 0;
  assert.equal(checkVictory(interception), 'egypt');
  const losses = startGame(actiumMap());
  losses.map.units.filter(u => u.team === 'egypt' && !u.commander).slice(0, losses.map.victory.octavianLosses)
    .forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(losses), 'coalition');
  const deadline = startGame(actiumMap());
  deadline.turn = 18; deadline.side = 'coalition'; endSide(deadline);
  assert.equal(deadline.victoryReason, 'actium_hold');
});

test('Alesia begins with two half-built rings and rising outside reinforcements from round eight', () => {
  const m = alesiaMap(), copy = importMap(exportMap(m));
  assert.equal(copy.victory.turnLimit, 24);
  const cityWalls = copy.units.filter(u => u.kind === 'fort' && u.team === 'coalition' &&
    u.cityId === '阿莱西亚城墙');
  assert.equal(cityWalls.length, 30);
  assert.ok(cityWalls.every(u => u.level === 3 && u.hp === FORT_HP[3] &&
    distance(u, copy.victory.center) === 5));
  assert.ok(copy.units.filter(u => u.team === 'coalition' && u.alesiaOrigin === 'inner')
    .some(u => distance(u, copy.victory.center) < 6));
  assert.equal(copy.units.filter(u => u.team === 'coalition' && u.kind === 'cavalry' &&
    u.alesiaOrigin === 'inner' && distance(u, copy.victory.center) === 4).length, 4);
  assert.equal(copy.units.filter(u => u.team === 'egypt' && u.kind === 'romanVelites').length, 5);
  assert.equal(copy.units.filter(u => u.team === 'egypt' && u.kind === 'romanArcher').length, 13);
  for (const ring of [copy.victory.inner, copy.victory.outer])
    assert.equal(ring.filter(([c, r]) => !!fortAt(copy, c, r)).length, ring.length / 2);
  assert.deepEqual(copy.reinforcements.map(w => w.turn), Array.from({ length: 17 }, (_, i) => i + 8));
  assert.deepEqual(copy.reinforcements.map(w => w.units.length), Array.from({ length: 17 }, (_, i) => i + 1));
  const s = startGame(copy);
  while (s.turn < 8) { endSide(s); endSide(s); }
  assert.equal(s.map.units.filter(u => u.alesiaOrigin === 'outer').length, 0);
  endSide(s);
  assert.equal(s.map.units.filter(u => u.alesiaOrigin === 'outer' && u.hp > 0).length, 1);
});

test('Alesia inner cavalry can ride through its own city wall after relief arrives', () => {
  const s = startGame(alesiaMap());
  s.side = 'coalition'; s.turn = 8;
  const cavalry = s.map.units.filter(u => u.kind === 'cavalry' && u.alesiaOrigin === 'inner');
  assert.ok(cavalry.every(u => [...reachable(s, u).values()].some(p =>
    distance(p, s.map.victory.center) >= 5)));
});

test('Alesia city garrison holds its walls before relief arrives; assault does not end the Roman hold objective early', () => {
  const s = startGame(alesiaMap());
  const garrisonIds = s.map.units.filter(u => u.alesiaOrigin === 'inner' &&
    distance(u, s.map.victory.center) <= 5).map(u => u.id);
  endSide(s);
  aiTurn(s, () => 0.5);
  assert.ok(s.map.units.filter(u => garrisonIds.includes(u.id) && u.hp > 0)
    .every(u => distance(u, s.map.victory.center) <= 5));
  for (const u of s.map.units) if (u.team === 'coalition' && u.kind !== 'fort') u.hp = 0;
  checkVictory(s);
  assert.equal(s.over, false);
});

test('Alesia level-three city wall withstands a Roman legion assault', () => {
  const s = startGame(alesiaMap());
  const wall = fortAt(s.map, 45, 26);
  const legion = s.map.units.find(u => u.kind === 'romanLegion');
  legion.c = 46; legion.r = 26; legion.formed = true; legion.facing = 3;
  recomputeFog(s);
  const result = attack(s, legion.id, wall.c, wall.r, 0);
  assert.equal(result.ok, true);
  assert.equal(result.hit, true);
  assert.ok(result.fortDamage <= 15);
  assert.ok(wall.hp >= FORT_HP[3] - 15);
});

test('Alesia Roman computer builds its rings instead of attacking the city wall', () => {
  const s = startGame(alesiaMap());
  const city = new Set(s.map.units.filter(u => u.cityId === '阿莱西亚城墙')
    .map(u => key(u.c, u.r)));
  const built = () => [...s.map.victory.inner, ...s.map.victory.outer]
    .filter(([c, r]) => fortAt(s.map, c, r)?.team === 'egypt').length;
  const initial = built();
  let work = 0;
  for (let i = 0; i < 3 && !s.over; i++) {
    const actions = aiTurn(s, () => 0.5);
    work += actions.filter(a => a.type === 'alesiaWork').length;
    assert.ok(actions.filter(a => a.type === 'attack')
      .every(a => !city.has(key(a.c, a.r))));
    aiTurn(s, () => 0.5);
  }
  assert.ok(work >= 20);
  assert.ok(built() >= initial + 20);
});

test('Alesia engineers build and repair faster; unformed Roman soldiers repair only surviving walls', () => {
  const s = startGame(alesiaMap());
  const engineer = s.map.units.find(u => u.kind === 'engineer' && alesiaWorkOptions(s, u).some(p => p.build && !p.blocked));
  const gap = alesiaWorkOptions(s, engineer).find(p => p.build && !p.blocked);
  const soldier = s.map.units.find(u => u.kind === 'romanLegion');
  soldier.c = engineer.c; soldier.r = engineer.r; soldier.formed = false;
  assert.equal(buildAlesiaWork(s, soldier.id, gap.c, gap.r).ok, false);
  assert.equal(buildAlesiaWork(s, engineer.id, gap.c, gap.r).ok, true);
  const wall = fortAt(s.map, gap.c, gap.r);
  wall.hp -= 100;
  const before = wall.hp;
  soldier.formed = true;
  assert.equal(buildAlesiaWork(s, soldier.id, gap.c, gap.r).ok, false);
  soldier.formed = false;
  assert.equal(buildAlesiaWork(s, soldier.id, gap.c, gap.r).ok, true);
  assert.equal(wall.hp - before, 30);
  const afterSoldier = wall.hp;
  assert.equal(buildAlesiaWork(s, engineer.id, gap.c, gap.r).ok, true);
  assert.equal(wall.hp - afterSoldier, 70);
  wall.hp = 0;
  assert.equal(buildAlesiaWork(s, soldier.id, gap.c, gap.r).ok, false);
});

test('Alesia building and repair allow nearby Gauls but not an enemy on the work cell', () => {
  const s = startGame(alesiaMap());
  const engineer = s.map.units.find(u => u.kind === 'engineer' && alesiaWorkOptions(s, u).some(p => p.build && !p.blocked));
  const gap = alesiaWorkOptions(s, engineer).find(p => p.build && !p.blocked);
  const gaul = s.map.units.find(u => u.alesiaOrigin === 'inner');
  const interference = neighbors(gap.c, gap.r).find(p => distance(p, engineer) > 0);
  gaul.c = interference.c; gaul.r = interference.r;
  assert.equal(alesiaWorkOptions(s, engineer).find(p => p.c === gap.c && p.r === gap.r).blocked, false);
  assert.equal(buildAlesiaWork(s, engineer.id, gap.c, gap.r).ok, true);
  const wall = fortAt(s.map, gap.c, gap.r);
  wall.hp -= 100;
  const soldier = s.map.units.find(u => u.kind === 'romanLegion');
  soldier.c = engineer.c; soldier.r = engineer.r; soldier.formed = false;
  assert.equal(alesiaWorkOptions(s, soldier).find(p => p.c === gap.c && p.r === gap.r).blocked, false);
  assert.equal(buildAlesiaWork(s, soldier.id, gap.c, gap.r).ok, true);
  assert.equal(buildAlesiaWork(s, engineer.id, gap.c, gap.r).ok, true);
  assert.equal(wall.hp, FORT_HP[1]);
  wall.hp -= 10;
  gaul.c = gap.c; gaul.r = gap.r;
  assert.equal(alesiaWorkOptions(s, soldier).find(p => p.c === gap.c && p.r === gap.r).blocked, true);
  assert.equal(buildAlesiaWork(s, soldier.id, gap.c, gap.r).ok, false);

  const occupied = startGame(alesiaMap());
  const builder = occupied.map.units.find(u => u.kind === 'engineer' &&
    alesiaWorkOptions(occupied, u).some(p => p.build && !p.blocked));
  const site = alesiaWorkOptions(occupied, builder).find(p => p.build && !p.blocked);
  const foe = occupied.map.units.find(u => u.alesiaOrigin === 'inner');
  foe.c = site.c; foe.r = site.r;
  assert.equal(alesiaWorkOptions(occupied, builder).find(p => p.c === site.c && p.r === site.r).blocked, true);
  assert.equal(buildAlesiaWork(occupied, builder.id, site.c, site.r).ok, false);
});

test('Alesia Gauls win by joining; Rome wins after round 24', () => {
  const s = startGame(alesiaMap());
  const gaul = s.map.units.find(u => u.alesiaOrigin === 'inner');
  gaul.c = 40; gaul.r = 26;
  const other = { ...gaul, id: 'external-test', c: 50, r: 26, alesiaOrigin: 'outer' };
  gaul.c = 49; gaul.r = 26;
  s.map.units.push(other);
  checkVictory(s);
  assert.equal(s.winner, 'coalition');
  const held = startGame(alesiaMap());
  held.turn = 24; held.side = 'coalition';
  endSide(held);
  assert.equal(held.winner, 'egypt');
  assert.equal(held.victoryReason, 'alesia_hold');
});

test('Megiddo starts before the pass with 16 Egyptians, infantry led opposition, scouts and a hollow wall ring', () => {
  const map = megiddoMap();
  const egypt = map.units.filter(u => u.team === 'egypt' && u.kind !== 'fort');
  const enemy = map.units.filter(u => u.team === 'coalition' && u.kind !== 'fort');
  const walls = map.units.filter(u => u.kind === 'fort');
  assert.equal(egypt.length, 16);
  assert.equal(enemy.length, 20);
  assert.equal(enemy.filter(u => u.kind === 'chariot').length, 2);
  assert.equal(enemy.filter(u => u.scout).length, 2);
  assert.equal(walls.length, 12);
  assert.ok(walls.every(u => distance(u, { c: 63, r: 17 }) === 2));
  assert.ok(egypt.every(u => inDeployment(map, u.c, u.r)));
  assert.equal(mobileAt(map, 63, 17), null);
  assert.equal(fortAt(map, 63, 17), null);
  assert.equal(startGame(map).deploying, true);
});

test('deployment relocates pieces inside the region without spending actions', () => {
  const s = startGame(megiddoMap());
  const u = s.map.units.find(x => x.kind === 'pharaoh');
  const destination = { c: 14, r: 40 };
  assert.equal(deployUnit(s, u.id, destination.c, destination.r), true);
  assert.equal(u.actionsLeft, 2);
  assert.equal(deployUnit(s, u.id, 20, 20), false);
  assert.equal(beginBattle(s), true);
  assert.equal(deployUnit(s, u.id, 13, 40), false);
});

test('Egyptian computer turn advances through Megiddo and hands control to coalition', () => {
  const s = startGame(megiddoMap());
  assert.equal(beginBattle(s), true);
  const positions = new Map(s.map.units.filter(u => u.team === 'egypt').map(u => [u.id, [u.c, u.r]]));
  const actions = aiTurn(s, () => 0.99);
  assert.equal(s.side, 'coalition');
  assert.ok(actions.some(a => a.type === 'move' && positions.has(a.id)));
  assert.ok(s.map.units.some(u => u.team === 'egypt' && positions.has(u.id) &&
    String(positions.get(u.id)) !== String([u.c, u.r])));
});

test('Egyptian computer turn at Kadesh leaves Hittite units ready for the player', () => {
  const s = startGame(kadeshMap());
  const actions = aiTurn(s, () => 0.99);
  assert.ok(actions.length > 0);
  assert.equal(s.side, 'coalition');
  assert.ok(s.map.units.some(u => u.team === 'coalition' && u.kind !== 'fort' && u.actionsLeft > 0));
});

test('two actions can be two moves or a move and attack', () => {
  const s = duel();
  const u = s.map.units.find(x => x.kind === 'heavy');
  assert.equal(move(s, u.id, 2, 3).ok, true);
  assert.equal(u.actionsLeft, 1);
  assert.equal(move(s, u.id, 2, 2).ok, true);
  assert.equal(u.actionsLeft, 0);
  assert.equal(move(s, u.id, 2, 3).ok, false);
  endSide(s); endSide(s);
  assert.equal(u.actionsLeft, 2);
  assert.equal(move(s, u.id, 2, 3).ok, true);
  assert.equal(attack(s, u.id, 3, 2, 0).ok, true);
  assert.equal(u.actionsLeft, 0);
});

test('all mobile kinds use their per-action distance and gain one step when starting on a road', () => {
  for (const [kind, limit] of [['chariot', 3], ['hittiteChariot', 3], ['heavy', 1], ['archer', 1],
    ['guard', 2], ['light', 2], ['pharaoh', 2], ['hittiteKing', 1]]) {
    for (const road of [false, true]) {
      const map = newMap(20, 10);
      if (road) setTerrain(map, 4, 4, TERRAIN.ROAD);
      if (kind !== 'pharaoh') addUnit(map, 'pharaoh', 'egypt', 0, 0);
      const team = ['hittiteChariot', 'hittiteKing'].includes(kind) ? 'coalition' : 'egypt';
      addUnit(map, kind, team, 4, 4);
      addUnit(map, 'light', 'coalition', 18, 8);
      const s = startGame(map), u = mobileAt(s.map, 4, 4);
      if (team === 'coalition') endSide(s);
      const farthest = Math.max(...[...reachable(s, u).values()].map(p => distance(u, p)));
      assert.equal(farthest, limit + Number(road), `${kind} ${road ? 'road' : 'plain'}`);
      if (['chariot', 'archer', 'pharaoh'].includes(kind)) assert.equal(u.ammo, 999);
    }
  }
});

test('one-step infantry can still enter one adjacent mountain hex', () => {
  for (const kind of ['heavy', 'archer']) {
    const map = newMap(10, 6);
    addUnit(map, 'pharaoh', 'egypt', 0, 0);
    setTerrain(map, 5, 3, TERRAIN.MOUNTAIN);
    addUnit(map, kind, 'egypt', 4, 3);
    addUnit(map, 'light', 'coalition', 9, 5);
    const s = startGame(map), u = mobileAt(s.map, 4, 3);
    assert.equal(reachable(s, u).has('5,3'), true, kind);
    assert.ok([...reachable(s, u).values()].every(p => distance(u, p) <= 1));
  }
});

test('chariot ranged power is three and armor reduces the damage', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'chariot', 'egypt', 1, 2);
  addUnit(map, 'heavy', 'coalition', 3, 2);
  const s = startGame(map), chariot = mobileAt(s.map, 1, 2), defender = mobileAt(s.map, 3, 2);
  assert.equal(chariot.ammo, 999);
  assert.equal(attackPreview(s, chariot, 3, 2).damage, 10);
  const shot = attack(s, chariot.id, 3, 2, 0);
  assert.equal(shot.hit, true);
  assert.deepEqual(shot.visual.from, { c: 1, r: 2 });
  assert.deepEqual(shot.visual.to, { c: 3, r: 2 });
  assert.equal(shot.visual.melee, false);
  assert.equal(chariot.ammo, 998);
  assert.equal(defender.hp, 90);
});

test('archers can shoot three hexes but not four', () => {
  const map = newMap(12, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'archer', 'egypt', 2, 2);
  addUnit(map, 'light', 'coalition', 5, 2);
  addUnit(map, 'light', 'coalition', 6, 2);
  const s = startGame(map), archer = mobileAt(s.map, 2, 2);
  assert.equal(distance(archer, { c: 5, r: 2 }), 3);
  assert.equal(distance(archer, { c: 6, r: 2 }), 4);
  assert.ok(attackPreview(s, archer, 5, 2));
  assert.equal(attackPreview(s, archer, 6, 2), null);
});

test('Egyptian chariot can shoot a two-hex diagonal target after a full three-hex move', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'chariot', 'egypt', 2, 2);
  addUnit(map, 'light', 'coalition', 6, 3);
  addUnit(map, 'hittiteChariot', 'coalition', 5, 4);
  addUnit(map, 'light', 'coalition', 8, 2);
  const s = startGame(map), chariot = mobileAt(s.map, 2, 2);
  assert.equal(move(s, chariot.id, 5, 2).ok, true);
  assert.equal(chariot.movedSteps, 3);
  assert.equal(distance(chariot, { c: 5, r: 4 }), 2);
  assert.equal(distance(chariot, { c: 8, r: 2 }), 3);
  const preview = attackPreview(s, chariot, 5, 4);
  assert.equal(preview?.melee, false);
  assert.equal(preview?.damage, 10);
  assert.equal(attackPreview(s, chariot, 8, 2), null);
  assert.equal(attack(s, chariot.id, 5, 4, 0).hit, true);
  assert.equal(mobileAt(s.map, 5, 4).hp, 80);
  assert.equal(chariot.ammo, 998);
});

test('Egyptian chariot shoots an adjacent enemy instead of being forced into melee', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'chariot', 'egypt', 3, 2);
  addUnit(map, 'hittiteChariot', 'coalition', 3, 3);
  const s = startGame(map), chariot = mobileAt(s.map, 3, 2);
  assert.equal(distance(chariot, { c: 3, r: 3 }), 1);
  assert.equal(attackPreview(s, chariot, 3, 3)?.melee, false);
  assert.equal(attack(s, chariot.id, 3, 3, 0).hit, true);
  assert.equal(chariot.ammo, 998);
});

test('missed and melee attacks expose the correct battle animation mode', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'guard', 'egypt', 3, 2);
  addUnit(map, 'light', 'coalition', 3, 3);
  const s = startGame(map), guard = mobileAt(s.map, 3, 2);
  const miss = attack(s, guard.id, 3, 3, 1);
  assert.equal(miss.hit, false);
  assert.equal(miss.visual.melee, true);
  assert.deepEqual(miss.visual.to, { c: 3, r: 3 });
});

test('friendly soldiers do not block ranged attacks', () => {
  for (const kind of ['archer', 'chariot', 'hittiteChariot', 'pharaoh']) {
    const team = kind === 'hittiteChariot' ? 'coalition' : 'egypt';
    const enemy = team === 'egypt' ? 'coalition' : 'egypt';
    const targetC = kind === 'archer' ? 5 : 4;
    const map = newMap(12, 7);
    addUnit(map, 'pharaoh', 'egypt', kind === 'pharaoh' ? 2 : 0, kind === 'pharaoh' ? 2 : 0);
    if (kind !== 'pharaoh') addUnit(map, kind, team, 2, 2);
    addUnit(map, 'light', team, 3, 2);
    addUnit(map, 'heavy', enemy, targetC, 2);
    const s = startGame(map);
    if (team === 'coalition') endSide(s);
    const shooter = mobileAt(s.map, 2, 2), friend = mobileAt(s.map, 3, 2);
    const beforeActions = shooter.actionsLeft, beforeAmmo = shooter.ammo;
    assert.ok(attackPreview(s, shooter, targetC, 2), kind);
    assert.equal(attack(s, shooter.id, targetC, 2, 0).ok, true);
    assert.equal(shooter.actionsLeft, beforeActions - 1);
    assert.equal(shooter.ammo, beforeAmmo - 1);
    assert.equal(friend.hp, STATS.light.hp);
  }
});

test('an enemy in front must be attacked before a rear enemy', () => {
  for (const kind of ['archer', 'chariot', 'hittiteChariot', 'pharaoh']) {
    const team = kind === 'hittiteChariot' ? 'coalition' : 'egypt';
    const enemy = team === 'egypt' ? 'coalition' : 'egypt';
    const frontC = kind === 'archer' ? 4 : 3;
    const rearC = kind === 'archer' ? 5 : 4;
    const map = newMap(12, 7);
    addUnit(map, 'pharaoh', 'egypt', kind === 'pharaoh' ? 2 : 0, kind === 'pharaoh' ? 2 : 0);
    if (kind !== 'pharaoh') addUnit(map, kind, team, 2, 2);
    addUnit(map, 'light', enemy, frontC, 2);
    addUnit(map, 'heavy', enemy, rearC, 2);
    const s = startGame(map);
    if (team === 'coalition') endSide(s);
    const shooter = mobileAt(s.map, 2, 2), rear = mobileAt(s.map, rearC, 2);
    assert.equal(attackPreview(s, shooter, rearC, 2), null, kind);
    assert.match(attack(s, shooter.id, rearC, 2).reason, /前方有敌军/);
    assert.ok(attackPreview(s, shooter, frontC, 2), `${kind} can attack the front enemy`);
    assert.equal(attack(s, shooter.id, frontC, 2, 0).ok, true);
    assert.equal(rear.hp, STATS.heavy.hp);
  }
});

test('mountains and enemy walls block shots, while archers shoot over friendly walls', () => {
  const map = newMap(12, 7);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'archer', 'egypt', 2, 2);
  addUnit(map, 'light', 'egypt', 4, 3);
  addUnit(map, 'heavy', 'coalition', 5, 2);
  const s = startGame(map), archer = mobileAt(s.map, 2, 2);
  assert.ok(attackPreview(s, archer, 5, 2), 'off-line friendly soldier');
  for (const terrain of [TERRAIN.MOUNTAIN, TERRAIN.MOUNTAIN | TERRAIN.ROAD]) {
    setTerrain(s.map, 4, 2, terrain); recomputeFog(s);
    assert.equal(attackPreview(s, archer, 5, 2), null, `mountain ${terrain}`);
  }
  setTerrain(s.map, 4, 2, TERRAIN.RIVER | TERRAIN.ROAD); recomputeFog(s);
  assert.ok(attackPreview(s, archer, 5, 2), 'ford');
  setTerrain(s.map, 4, 2, TERRAIN.PLAIN);
  assert.equal(setFort(s.map, 4, 2, 2, 'egypt'), true);
  assert.ok(attackPreview(s, archer, 5, 2), 'friendly wall');
  assert.equal(attack(s, archer.id, 5, 2, 0).hit, true);
  assert.equal(fortAt(s.map, 4, 2).hp, FORT_HP[2], 'friendly wall takes no damage');
  assert.equal(setFort(s.map, 4, 2, 2, 'coalition'), true);
  assert.equal(attackPreview(s, archer, 5, 2), null, 'enemy wall in front');
  assert.ok(attackPreview(s, archer, 4, 2), 'enemy wall can be attacked first');
  assert.equal(setFort(s.map, 4, 2, 2, 'egypt'), true);
  assert.equal(addUnit(s.map, 'chariot', 'egypt', 3, 2), true);
  recomputeFog(s);
  assert.equal(attackPreview(s, mobileAt(s.map, 3, 2), 5, 2), null, 'friendly wall still blocks chariot');
});

test('Trojan archer inside or atop a wall can shoot through allied walls', () => {
  for (const atopWall of [false, true]) {
    const map = newMap(12, 7);
    addUnit(map, 'pharaoh', 'egypt', 0, 0);
    addUnit(map, 'light', 'egypt', 5, 2);
    if (atopWall) setFort(map, 2, 2, 2, 'coalition');
    setFort(map, 4, 2, 2, 'coalition');
    addUnit(map, 'archer', 'coalition', 2, 2);
    const s = startGame(map);
    endSide(s);
    const archer = mobileAt(s.map, 2, 2);
    assert.ok(attackPreview(s, archer, 5, 2), atopWall ? 'on wall' : 'inside wall');
    assert.equal(attack(s, archer.id, 5, 2, 0).hit, true);
    assert.equal(fortAt(s.map, 4, 2).hp, FORT_HP[2]);
  }
});

test('unused actions restore mobile units on plain and road, not mountain or river, with a friendly fort bonus', () => {
  const map = newMap(12, 8);
  setTerrain(map, 2, 2, TERRAIN.ROAD);
  setTerrain(map, 3, 2, TERRAIN.MOUNTAIN);
  setTerrain(map, 4, 2, TERRAIN.MOUNTAIN | TERRAIN.ROAD);
  setTerrain(map, 10, 2, TERRAIN.RIVER | TERRAIN.ROAD);
  setTerrain(map, 6, 2, TERRAIN.MOUNTAIN);
  setFort(map, 5, 2, 2, 'egypt');
  setFort(map, 6, 2, 1, 'egypt');
  setFort(map, 8, 2, 1, 'egypt');
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 1, 2);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  addUnit(map, 'archer', 'egypt', 3, 2);
  addUnit(map, 'guard', 'egypt', 4, 2);
  addUnit(map, 'chariot', 'egypt', 5, 2);
  addUnit(map, 'light', 'egypt', 6, 2);
  addUnit(map, 'light', 'egypt', 7, 2);
  addUnit(map, 'light', 'egypt', 8, 2);
  addUnit(map, 'light', 'egypt', 9, 2);
  addUnit(map, 'light', 'egypt', 10, 2);
  addUnit(map, 'light', 'coalition', 10, 6);
  const s = startGame(map);
  const at = (c, r) => s.map.units.find(u => u.kind !== 'fort' && u.c === c && u.r === r);
  for (const [c, r, hp] of [[0, 0, 55], [1, 2, 50], [2, 2, 80], [3, 2, 40],
    [4, 2, 70], [5, 2, 30], [6, 2, 50], [7, 2, 50], [8, 2, 50], [9, 2, 0], [10, 2, 50], [10, 6, 30]]) at(c, r).hp = hp;
  at(7, 2).actionsLeft = 0;
  at(8, 2).actionsLeft = 0;
  fortAt(s.map, 5, 2).hp = 150;
  endSide(s);
  assert.equal(s.side, 'coalition');
  for (const [c, r, hp] of [[0, 0, 60], [1, 2, 60], [2, 2, 90], [3, 2, 40],
    [4, 2, 70], [5, 2, 50], [6, 2, 70], [7, 2, 50], [8, 2, 50], [9, 2, 0], [10, 2, 50], [10, 6, 30]]) assert.equal(at(c, r).hp, hp, `${c},${r}`);
  assert.equal(fortAt(s.map, 5, 2).hp, 150);
  endSide(s);
  assert.equal(at(10, 6).hp, 40);
  assert.equal(at(1, 2).hp, 60);
  assert.equal(at(1, 2).actionsLeft, 2);
});

test('fort supply heals at the next own turn only when an action was saved', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 8, 4);
  setFort(map, 3, 2, 1, 'egypt', '测试堡垒');
  assert.equal(setSupplyPoint(map, 3, 3, 'egypt', '测试堡垒'), true);
  assert.deepEqual(importMap(exportMap(map)).supplyPoints, map.supplyPoints);
  const s = startGame(map), soldier = mobileAt(s.map, 3, 3);
  soldier.hp = 50;
  soldier.actionsLeft = 1;
  endSide(s);
  assert.equal(soldier.hp, 50);
  soldier.hp = 40;
  endSide(s);
  assert.equal(soldier.hp, 60);
  soldier.actionsLeft = 0;
  endSide(s);
  endSide(s);
  assert.equal(soldier.hp, 60);
  soldier.actionsLeft = 1;
  endSide(s);
  fortAt(s.map, 3, 2).hp = 0;
  endSide(s);
  assert.equal(soldier.hp, 60);
});

test('a garrison on a live friendly wall deals one extra damage to an enemy outside walls', () => {
  for (const [kind, enemyC] of [['heavy', 4], ['archer', 6]]) {
    const map = newMap(10, 6);
    addUnit(map, 'pharaoh', 'egypt', 0, 0);
    addUnit(map, kind, 'egypt', 3, 2);
    addUnit(map, 'light', 'coalition', enemyC, 2);
    setFort(map, 3, 2, 2, 'egypt');
    const s = startGame(map), attacker = mobileAt(s.map, 3, 2);
    const fortified = attackPreview(s, attacker, enemyC, 2);
    assert.ok(fortified);
    const wall = fortAt(s.map, 3, 2);
    wall.hp = 0;
    const ordinary = attackPreview(s, attacker, enemyC, 2);
    assert.equal(fortified.damage - ordinary.damage, 10);
    wall.hp = FORT_HP[2];
    setFort(s.map, enemyC, 2, 1, 'coalition');
    assert.equal(attackPreview(s, attacker, enemyC, 2)?.damage, ordinary.damage);
  }
});

test('every built-in fortress group has one internal supply point', () => {
  for (const [map, names] of [
    [megiddoMap(), ['美吉多']],
    [kadeshMap(), ['卡迭石']],
    [troyMap(), ['特洛伊', '特洛伊内城', '北滩头堡垒', '平原堡垒', '南滩头堡垒']],
  ]) {
    assert.deepEqual(map.supplyPoints.map(p => p.cityId).sort(), names.sort());
    for (const point of map.supplyPoints) {
      assert.equal(fortAt(map, point.c, point.r), null);
      assert.equal(tile(map, point.c, point.r).terrain & (TERRAIN.RIVER | TERRAIN.SEA), 0);
      assert.ok(map.units.some(u => u.kind === 'fort' && u.cityId === point.cityId && u.team === point.team));
    }
    assert.deepEqual(importMap(exportMap(map)).supplyPoints, map.supplyPoints);
  }
});

test('infantry can remount friendly walls of every level; chariots and Pharaoh need level two or three', () => {
  for (const kind of ['light', 'heavy', 'archer', 'guard', 'hittiteKing', 'chariot', 'hittiteChariot', 'pharaoh']) {
    for (const level of [1, 2, 3]) {
      const team = ['hittiteKing', 'hittiteChariot'].includes(kind) ? 'coalition' : 'egypt';
      const map = newMap(12, 8);
      addUnit(map, 'pharaoh', 'egypt', kind === 'pharaoh' ? 3 : 0, kind === 'pharaoh' ? 2 : 0);
      addUnit(map, 'light', 'coalition', 10, 6);
      setFort(map, 4, 2, level, team);
      if (kind !== 'pharaoh') assert.equal(addUnit(map, kind, team, 3, 2), true);
      const s = startGame(map);
      if (team === 'coalition') endSide(s);
      const u = mobileAt(s.map, 3, 2);
      const allowed = !['chariot', 'hittiteChariot', 'pharaoh'].includes(kind) || level >= 2;
      assert.equal(reachable(s, u).has('4,2'), allowed, `${kind} level ${level}`);
      if (!allowed) {
        assert.equal(move(s, u.id, 4, 2).ok, false);
        continue;
      }
      assert.equal(move(s, u.id, 4, 2).ok, true, `${kind} climbs level ${level}`);
      assert.equal(move(s, u.id, 3, 2).ok, true, `${kind} leaves level ${level}`);
      endSide(s); endSide(s);
      assert.equal(move(s, u.id, 4, 2).ok, true, `${kind} remounts level ${level}`);
    }
  }
});

test('soldiers can enter, leave, and pass through a damaged friendly fort', () => {
  const map = newMap(10, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'romanVelites', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 9, 7);
  setFort(map, 4, 3, 1, 'egypt');
  const s = startGame(map), soldier = mobileAt(s.map, 3, 3);
  fortAt(s.map, 4, 3).hp = 30;
  assert.deepEqual(reachable(s, soldier).get(key(5, 3)).path,
    [{ c: 4, r: 3 }, { c: 5, r: 3 }]);
  assert.equal(move(s, soldier.id, 4, 3).ok, true, 'enter damaged fort');
  assert.equal(move(s, soldier.id, 5, 3).ok, true, 'leave damaged fort');
  endSide(s); endSide(s);
  assert.equal(move(s, soldier.id, 3, 3).ok, true, 'pass through damaged fort');
  assert.equal(fortAt(s.map, 4, 3).hp, 30);
});

test('map editing cannot put a chariot or Pharaoh on a level-one wall', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'coalition', 10, 6);
  assert.equal(setFort(map, 4, 2, 1, 'egypt'), true);
  assert.equal(addUnit(map, 'chariot', 'egypt', 4, 2), false);
  assert.equal(addUnit(map, 'pharaoh', 'egypt', 4, 2), false);
  assert.equal(addUnit(map, 'guard', 'egypt', 4, 2), true);
  assert.equal(setFort(map, 4, 2, 2, 'egypt'), true);
  assert.equal(addUnit(map, 'chariot', 'egypt', 4, 2), true);
  assert.equal(setFort(map, 4, 2, 1, 'egypt'), false);
});

test('forts are immobile non-attacking pieces and armor reduces only their share in tenths', () => {
  for (const level of [1, 2, 3]) {
    const s = duel(level), wall = fortAt(s.map, 3, 2);
    const defender = mobileAt(s.map, 3, 2), attacker = mobileAt(s.map, 2, 2);
    assert.equal(wall.actionsLeft, 0);
    assert.equal(reachable(s, wall).size, 0);
    assert.equal(attackPreview(s, wall, 2, 2), null);
    const result = attack(s, attacker.id, 3, 2, 0);
    const allocatedFortDamage = 30 * FORT_SHARE[level] / 10;
    assert.equal(result.fortDamage, Math.max(0, allocatedFortDamage - FORT_ARMOR[level] * 10));
    assert.equal(result.unitDamage, 30 - allocatedFortDamage);
    assert.equal(wall.hp, FORT_HP[level] - result.fortDamage);
    assert.equal(defender.hp, 70 - result.unitDamage);
  }
});

test('direct strikes against empty walls subtract the wall level armor once', () => {
  for (const level of [1, 2, 3]) {
    const map = newMap(10, 6);
    addUnit(map, 'pharaoh', 'egypt', 0, 0);
    addUnit(map, 'guard', 'egypt', 2, 2);
    addUnit(map, 'light', 'coalition', 8, 4);
    setFort(map, 3, 2, level, 'coalition');
    const s = startGame(map), wall = fortAt(s.map, 3, 2);
    const attacker = mobileAt(s.map, 2, 2);
    const result = attack(s, attacker.id, 3, 2, 0);
    assert.equal(result.fortDamage, (meleePower(attacker) - FORT_ARMOR[level]) * 10);
    assert.equal(wall.hp, FORT_HP[level] - result.fortDamage);
  }
});

test('open-field soldier attacks deduct and report health to one decimal place', () => {
  const s = duel();
  const attacker = mobileAt(s.map, 2, 2), defender = mobileAt(s.map, 3, 2);
  defender.hp = 45; // 4.5 HP in internal tenths.
  const first = attack(s, attacker.id, 3, 2, 0);
  assert.equal(first.unitDamage, 30);
  assert.equal(defender.hp, 15);
  assert.equal(fmt(defender.hp), '1.5');
  const second = attack(s, attacker.id, 3, 2, 0);
  assert.equal(second.unitDamage, 15);
  assert.equal(defender.hp, 0);
  assert.ok(s.log.some(line => line.includes('守军 −1.5')));
});

test('breaching one wall opens that cell and leaves other wall segments intact', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  setFort(map, 3, 2, 1, 'coalition', '美吉多');
  setFort(map, 4, 2, 2, 'coalition', '美吉多');
  addUnit(map, 'light', 'coalition', 7, 2);
  const s = startGame(map), wall = fortAt(s.map, 3, 2);
  wall.hp = 10;
  attack(s, mobileAt(s.map, 2, 2).id, 3, 2, 0);
  assert.equal(wall.hp, 0);
  assert.equal(fortAt(s.map, 3, 2), null);
  assert.ok(fortAt(s.map, 4, 2).hp > 0);
  assert.equal(s.map.terrain[2 * s.map.cols + 3], TERRAIN.PLAIN);
  endSide(s); endSide(s);
  assert.equal(reachable(s, mobileAt(s.map, 2, 2)).has('3,2'), true);
});

test('Pharaoh death defeats Egypt, but intact empty walls do not prevent victory', () => {
  const loss = duel(1);
  loss.map.units.find(u => u.kind === 'pharaoh').hp = 0;
  assert.equal(checkVictory(loss), 'coalition');
  const win = duel(1);
  win.map.units.find(u => u.team === 'coalition' && u.kind !== 'fort').hp = 0;
  assert.equal(checkVictory(win), 'egypt');
  assert.ok(fortAt(win.map, 3, 2));
});

test('units reveal enemy only within line of sight, while reconnaissance has wider vision', () => {
  const map = newMap(16, 8);
  addUnit(map, 'pharaoh', 'egypt', 1, 3);
  addUnit(map, 'light', 'coalition', 11, 3);
  const s = startGame(map);
  assert.equal(visibleTo(s, 'egypt', 11, 3), false);
  assert.equal(move(s, s.map.units.find(u => u.kind === 'pharaoh').id, 3, 3).ok, true);
  assert.equal(visibleTo(s, 'egypt', 11, 3), false);
  const scout = s.map.units.find(u => u.team === 'coalition');
  assert.equal(visibleTo(s, 'coalition', 5, 3), false);
  scout.scout = true;
  recomputeFog(s);
  assert.equal(visibleTo(s, 'coalition', 5, 3), true);
});

test('both sides know fort positions while hidden garrisons remain unseen', () => {
  const map = newMap(20, 8);
  addUnit(map, 'pharaoh', 'egypt', 1, 3);
  assert.equal(setFort(map, 1, 4, 1, 'egypt'), true);
  assert.equal(setFort(map, 16, 3, 2, 'coalition'), true);
  addUnit(map, 'archer', 'coalition', 16, 3);
  const s = startGame(map);
  const greekWall = fortAt(s.map, 1, 4), enemyWall = fortAt(s.map, 16, 3);
  const garrison = mobileAt(s.map, 16, 3);
  assert.equal(visibleTo(s, 'egypt', 16, 3), false);
  assert.equal(visibleTo(s, 'coalition', 1, 4), false);
  assert.equal(knownTo(s, 'egypt', enemyWall), true);
  assert.equal(knownTo(s, 'coalition', greekWall), true);
  assert.equal(knownTo(s, 'egypt', garrison), false);
  assert.equal(knownUnitAt(s, 'egypt', 16, 3), enemyWall);
  assert.equal(knownUnitAt(s, 'coalition', 1, 4), greekWall);
  assert.equal(knownUnitAt(s, 'coalition', 16, 3), garrison);
});

test('river fords and map import/export preserve scenario metadata and one-decimal walls', () => {
  const map = megiddoMap();
  const raw = exportMap(map), restored = importMap(raw);
  assert.equal(raw.format, 'hex_wargame.ancient.v2');
  assert.deepEqual(restored.deployment, map.deployment);
  assert.equal(restored.units.filter(u => u.kind === 'fort').length, 12);
  assert.equal(restored.units.filter(u => u.scout).length, 2);
  raw.units.find(u => u.kind === 'fort').hp = 19.95;
  assert.throws(() => importMap(raw), /一位小数/);
  const large = newMap(120, 80);
  addUnit(large, 'pharaoh', 'egypt', 1, 1);
  addUnit(large, 'light', 'coalition', 118, 78);
  assert.equal(importMap(exportMap(large)).cols, 120);
  setTerrain(large, 2, 1, TERRAIN.RIVER | TERRAIN.ROAD);
  assert.equal(large.terrain[1 * large.cols + 2], 5);
});

test('legacy v1 fort tiles import as fort pieces, and mountain blocks sight without hiding terrain', () => {
  const old = {
    format: 'hex_wargame.ancient.v1', cols: 10, rows: 6,
    terrain: [[2, 2, TERRAIN.MOUNTAIN]], forts: [[6, 2, 1, 20.0]],
    units: [{ kind: 'pharaoh', team: 'egypt', c: 1, r: 2 },
      { kind: 'light', team: 'coalition', c: 4, r: 2 }],
  };
  const map = importMap(old), s = startGame(map);
  assert.equal(fortAt(map, 6, 2).hp, 200);
  assert.equal(map.terrain[2 * map.cols + 2], TERRAIN.MOUNTAIN);
  assert.equal(visibleTo(s, 'egypt', 4, 2), false);
});

test('Kadesh fields equally sized staged armies and keeps symmetric leader victory through export', () => {
  const map = kadeshMap();
  assert.equal(map.victory.mode, 'leader_duel');
  assert.equal(map.units.filter(u => u.kind === 'pharaoh').length, 1);
  assert.equal(map.units.filter(u => u.kind === 'hittiteKing').length, 1);
  assert.equal(map.units.filter(u => u.kind === 'hittiteChariot').length, 8);
  assert.deepEqual(importMap(exportMap(map)).reinforcements, map.reinforcements);
  const committed = team => map.units.filter(u => u.team === team && u.kind !== 'fort').length +
    map.reinforcements.filter(w => w.team === team).reduce((n, w) => n + w.units.length, 0);
  assert.equal(committed('egypt'), 34);
  assert.equal(committed('coalition'), 34);
  assert.deepEqual(map.reinforcements.map(w => [w.turn, w.team, w.units.length]),
    [[3, 'egypt', 7], [3, 'coalition', 4], [4, 'coalition', 4],
      [5, 'egypt', 8], [5, 'coalition', 4], [6, 'egypt', 6]]);
  const egyptLoss = startGame(map);
  egyptLoss.map.units.find(u => u.kind === 'pharaoh').hp = 0;
  assert.equal(checkVictory(egyptLoss), 'coalition');
  const hittiteLoss = startGame(map);
  hittiteLoss.map.units.find(u => u.kind === 'hittiteKing').hp = 0;
  assert.equal(checkVictory(hittiteLoss), 'egypt');
  const relief = startGame(map);
  assert.equal(relief.map.units.filter(u => u.team === 'egypt' && !['fort', 'moraleGuard'].includes(u.kind)).length, 13);
  assert.equal(relief.map.units.filter(u => u.team === 'coalition' && !['fort', 'moraleGuard'].includes(u.kind)).length, 22);
  const expected = [[13, 22], [13, 22], [13, 22], [20, 22], [20, 26],
    [20, 26], [20, 30], [28, 30], [28, 34], [34, 34]];
  for (const [egypt, coalition] of expected) {
    endSide(relief);
    assert.equal(relief.map.units.filter(u => u.team === 'egypt' && !['fort', 'moraleGuard'].includes(u.kind)).length, egypt);
    assert.equal(relief.map.units.filter(u => u.team === 'coalition' && !['fort', 'moraleGuard'].includes(u.kind)).length, coalition);
  }
  assert.equal(relief.turn, 6);
  assert.deepEqual(relief.arrivedReinforcements, [0, 1, 2, 3, 4, 5]);
});

test('Kadesh city wall forms one closed ring with no unintended entry gap', () => {
  const walls = kadeshMap().units.filter(u => u.kind === 'fort' && u.cityId === '卡迭石');
  const positions = new Set(walls.map(u => key(u.c, u.r)));
  assert.equal(walls.length, 18);
  assert.ok(walls.every(u => neighbors(u.c, u.r).filter(p => positions.has(key(p.c, p.r))).length === 2));
  const seen = new Set(), pending = [walls[0]];
  while (pending.length) {
    const wall = pending.pop(), at = key(wall.c, wall.r);
    if (seen.has(at)) continue;
    seen.add(at);
    pending.push(...neighbors(wall.c, wall.r).filter(p => positions.has(key(p.c, p.r))));
  }
  assert.equal(seen.size, walls.length);
});

test('Kadesh Hittite relief follows fords and reaches the west bank', () => {
  const map = kadeshMap(), initialIds = new Set(map.units.map(u => u.id));
  const s = startGame(map);
  for (let round = 0; round < 6; round++) {
    endSide(s);
    aiTurn(s, () => 0.99); // Misses preserve the armies while checking their route.
  }
  assert.equal(s.over, false);
  assert.ok(s.map.units.some(u => u.team === 'coalition' && u.kind !== 'fort' &&
    !initialIds.has(u.id) && u.c <= 35));
});

test('Hittite chariot throws one spear at two hexes, even if the throw misses', () => {
  const map = newMap(14, 8);
  map.victory = { mode: 'leader_duel', leaders: { egypt: 'pharaoh', coalition: 'hittiteKing' } };
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 6, 4);
  addUnit(map, 'hittiteKing', 'coalition', 12, 7);
  addUnit(map, 'hittiteChariot', 'coalition', 4, 4);
  const s = startGame(map), chariot = mobileAt(s.map, 4, 4);
  endSide(s);
  assert.equal(chariot.ammo, 1);
  assert.equal(attackPreview(s, chariot, 6, 4)?.damage, 30);
  assert.equal(attackPreview(s, chariot, 6, 4)?.melee, false);
  assert.equal(attack(s, chariot.id, 6, 4, 0.99).hit, false);
  assert.equal(chariot.ammo, 0);
  assert.equal(attackPreview(s, chariot, 6, 4), null);
  endSide(s); endSide(s);
  assert.equal(chariot.ammo, 0);
  assert.ok(s.log.some(line => line.includes('赫梯重战车投矛未命中')));
  const hitGame = startGame(map);
  endSide(hitGame);
  const thrown = mobileAt(hitGame.map, 4, 4);
  assert.equal(attack(hitGame, thrown.id, 6, 4, 0).unitDamage, 30);
  assert.equal(mobileAt(hitGame.map, 6, 4).hp, 40);
  assert.equal(thrown.ammo, 0);
});

test('revised melee values retain tenths and Hittite charge is added to the new base', () => {
  assert.deepEqual([STATS.heavy.melee, STATS.light.melee, meleePower({ kind: 'guard', team: 'egypt' }), STATS.hittiteChariot.melee],
    [3, 2.5, 3.5, 4.5]);
  assert.equal(meleePower({ kind: 'guard', team: 'coalition' }), 5);
  for (const [kind, damage] of [['heavy', 30], ['light', 25], ['guard', 35]]) {
    const map = newMap(10, 6);
    addUnit(map, 'pharaoh', 'egypt', 0, 0);
    addUnit(map, kind, 'egypt', 2, 2);
    addUnit(map, 'light', 'coalition', 3, 2);
    const s = startGame(map);
    assert.equal(attackPreview(s, mobileAt(s.map, 2, 2), 3, 2)?.damage, damage, kind);
  }
  const guardMap = newMap(12, 7);
  guardMap.victory = { mode: 'leader_duel', leaders: { egypt: 'pharaoh', coalition: 'hittiteKing' } };
  addUnit(guardMap, 'pharaoh', 'egypt', 0, 0);
  addUnit(guardMap, 'light', 'egypt', 3, 2);
  addUnit(guardMap, 'hittiteKing', 'coalition', 10, 6);
  addUnit(guardMap, 'guard', 'coalition', 2, 2);
  const guardGame = startGame(guardMap);
  endSide(guardGame);
  assert.equal(attackPreview(guardGame, mobileAt(guardGame.map, 2, 2), 3, 2)?.damage, 50);
  const map = newMap(14, 8);
  map.victory = { mode: 'leader_duel', leaders: { egypt: 'pharaoh', coalition: 'hittiteKing' } };
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 6, 4);
  addUnit(map, 'hittiteKing', 'coalition', 12, 7);
  addUnit(map, 'hittiteChariot', 'coalition', 3, 4);
  const s = startGame(map), chariot = mobileAt(s.map, 3, 4);
  endSide(s);
  assert.equal(move(s, chariot.id, 5, 4).ok, true);
  assert.equal(attackPreview(s, chariot, 6, 4)?.damage, 65);
});

test('Hittite chariot still charges infantry after a two-hex move', () => {
  const map = newMap(14, 8);
  map.victory = { mode: 'leader_duel', leaders: { egypt: 'pharaoh', coalition: 'hittiteKing' } };
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'hittiteKing', 'coalition', 12, 7);
  addUnit(map, 'heavy', 'egypt', 6, 4);
  addUnit(map, 'hittiteChariot', 'coalition', 3, 4);
  const s = startGame(map), chariot = mobileAt(s.map, 3, 4);
  endSide(s);
  assert.equal(attackPreview(s, chariot, 6, 4), null);
  assert.equal(move(s, chariot.id, 5, 4).ok, true);
  assert.equal(chariot.movedSteps, 2);
  assert.equal(attackPreview(s, chariot, 6, 4).damage, 45);
  endSide(s); endSide(s);
  assert.equal(move(s, chariot.id, 4, 4).ok, true);
  assert.equal(attackPreview(s, chariot, 6, 4)?.damage, 10);
  assert.equal(attackPreview(s, chariot, 6, 4)?.charge, false);
});

function terrainComponents(map, terrain) {
  const seen = new Set(), components = [];
  for (let r = 0; r < map.rows; r++) for (let c = 0; c < map.cols; c++) {
    if (!(map.terrain[index(map, c, r)] & terrain) || seen.has(key(c, r))) continue;
    const queue = [{ c, r }], component = [];
    seen.add(key(c, r));
    while (queue.length) {
      const point = queue.pop(); component.push(point);
      for (const next of neighbors(point.c, point.r)) {
        if (!inBounds(map, next.c, next.r) || !(map.terrain[index(map, next.c, next.r)] & terrain) || seen.has(key(next.c, next.r))) continue;
        seen.add(key(next.c, next.r)); queue.push(next);
      }
    }
    components.push(component);
  }
  return components;
}

test('Megiddo and Kadesh have one connected road network and continuous rivers', () => {
  for (const map of [megiddoMap(), kadeshMap()]) {
    assert.equal(terrainComponents(map, TERRAIN.ROAD).length, 1, `${map.name} road network`);
    assert.equal(terrainComponents(map, TERRAIN.RIVER).length, 1, `${map.name} river`);
    assert.ok(map.terrain.some(t => (t & (TERRAIN.RIVER | TERRAIN.ROAD)) === (TERRAIN.RIVER | TERRAIN.ROAD)));
  }
});

test('every ford step uses the entire turn for every troop type, including landing', () => {
  for (const kind of ['pharaoh', 'chariot', 'heavy', 'archer', 'guard', 'light', 'hittiteChariot', 'hittiteKing']) {
    const map = newMap(14, 8);
    for (let r = 0; r < map.rows; r++) for (const c of [5, 6]) setTerrain(map, c, r, TERRAIN.RIVER);
    for (const c of [5, 6]) setTerrain(map, c, 3, TERRAIN.RIVER | TERRAIN.ROAD);
    const team = kind.startsWith('hittite') ? 'coalition' : 'egypt';
    if (kind !== 'pharaoh') addUnit(map, 'pharaoh', 'egypt', 0, 0);
    addUnit(map, kind, team, 4, 3);
    if (team === 'egypt') addUnit(map, 'light', 'coalition', 12, 7);
    const s = startGame(map), unit = mobileAt(s.map, 4, 3);
    if (team === 'coalition') endSide(s);
    const first = reachable(s, unit);
    assert.equal(first.has('5,2'), false, `${kind} cannot enter open river`);
    assert.equal(first.has('5,3'), true, `${kind} can enter ford`);
    assert.equal(first.has('6,3'), false, `${kind} cannot cross two river cells in one action`);
    assert.equal(move(s, unit.id, 5, 3).ok, true);
    assert.equal(unit.actionsLeft, 0, `${kind} entering water ends its turn`);
    assert.equal(reachable(s, unit).size, 0);
    endSide(s); endSide(s);
    assert.equal(unit.actionsLeft, 1, `${kind} starts a water turn with one action`);
    assert.equal(reachable(s, unit).has('6,3'), true, `${kind} can take one water step next turn`);
    assert.equal(reachable(s, unit).has('7,3'), false, `${kind} cannot skip the far bank`);
    assert.equal(move(s, unit.id, 6, 3).ok, true);
    assert.equal(unit.actionsLeft, 0, `${kind} moving within water ends its turn`);
    endSide(s); endSide(s);
    assert.equal(unit.actionsLeft, 1, `${kind} still has only one action in water`);
    assert.equal(reachable(s, unit).has('7,3'), true, `${kind} can land next turn`);
    assert.equal(reachable(s, unit).has('8,3'), false, `${kind} cannot continue past the shore`);
    assert.equal(move(s, unit.id, 7, 3).ok, true);
    assert.equal(unit.actionsLeft, 0, `${kind} landing ends its turn`);
    endSide(s); endSide(s);
    assert.equal(unit.actionsLeft, 2, `${kind} regains two actions on land`);
  }
});

test('bridges cross two river cells at road speed; both armies can demolish them into fords', () => {
  const map = newMap(14, 8);
  for (let r = 0; r < map.rows; r++) for (const c of [5, 6]) setTerrain(map, c, r, TERRAIN.RIVER);
  for (const c of [5, 6]) {
    setTerrain(map, c, 3, TERRAIN.RIVER | TERRAIN.ROAD);
    assert.equal(setBridge(map, c, 3), true);
  }
  setTerrain(map, 4, 3, TERRAIN.ROAD);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 4, 3);
  addUnit(map, 'light', 'coalition', 8, 3);
  const exported = exportMap(map);
  assert.deepEqual(exported.bridges, [[5, 3], [6, 3]]);
  assert.deepEqual(importMap(exported).bridges, map.bridges);
  const s = startGame(map), egypt = mobileAt(s.map, 4, 3), coalition = mobileAt(s.map, 8, 3);
  assert.equal(reachable(s, egypt).has('6,3'), true);
  assert.equal(move(s, egypt.id, 6, 3).riverMove, false);
  assert.equal(egypt.actionsLeft, 1);
  assert.equal(destroyBridge(s, egypt.id, 5, 3).ok, true);
  assert.equal(bridgeAt(s.map, 5, 3), false);
  assert.equal(tile(s.map, 5, 3).terrain, TERRAIN.RIVER | TERRAIN.ROAD);
  endSide(s);
  assert.equal(move(s, coalition.id, 7, 3).ok, true);
  assert.equal(destroyBridge(s, coalition.id, 6, 3).ok, true);
  assert.equal(bridgeAt(s.map, 6, 3), false);
  endSide(s);
  assert.equal(egypt.actionsLeft, 1, 'standing on the demolished bridge is now a ford turn');
  assert.equal(reachable(s, egypt).has('5,3'), true);
  assert.equal(reachable(s, egypt).has('4,3'), false);
  assert.equal(move(s, egypt.id, 5, 3).riverMove, true);
  assert.equal(egypt.actionsLeft, 0);
  assert.equal(tile(s.map, 6, 3).terrain, TERRAIN.RIVER | TERRAIN.ROAD);
});

test('bridge data rejects non-ford and duplicate coordinates; Babylon has an intact stone bridge', () => {
  const map = newMap(10, 6);
  assert.equal(setBridge(map, 2, 2), false);
  setTerrain(map, 2, 2, TERRAIN.ROAD | TERRAIN.RIVER);
  setBridge(map, 2, 2);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'coalition', 9, 5);
  const duplicate = exportMap(map); duplicate.bridges.push([2, 2]);
  assert.throws(() => importMap(duplicate), /桥梁/);
  const bad = exportMap(map); bad.bridges = [[3, 2]];
  assert.throws(() => importMap(bad), /桥梁/);
  setTerrain(map, 2, 2, TERRAIN.PLAIN);
  assert.equal(bridgeAt(map, 2, 2), false);
  const babylon = babylonMap();
  assert.equal(bridgeAt(babylon, 52, 35), true);
  assert.equal(bridgeAt(babylon, 53, 35), true);
});

test('computer commander can demolish a bridge occupied by an enemy', () => {
  const map = newMap(10, 6);
  setTerrain(map, 5, 3, TERRAIN.ROAD | TERRAIN.RIVER);
  setBridge(map, 5, 3);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 4, 3);
  addUnit(map, 'light', 'coalition', 5, 3);
  const s = startGame(map);
  const actions = aiTurn(s, () => 0.5);
  assert.ok(actions.some(a => a.type === 'destroyBridge' && a.c === 5 && a.r === 3));
  assert.equal(bridgeAt(s.map, 5, 3), false);
  assert.equal(tile(s.map, 5, 3).terrain, TERRAIN.ROAD | TERRAIN.RIVER);
});

test('a piece beginning in water has one action and cannot move after firing', () => {
  const map = newMap(10, 6);
  setTerrain(map, 5, 3, TERRAIN.RIVER | TERRAIN.ROAD);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'chariot', 'egypt', 5, 3);
  addUnit(map, 'light', 'coalition', 4, 3);
  const s = startGame(map), chariot = mobileAt(s.map, 5, 3);
  assert.equal(chariot.actionsLeft, 1);
  assert.equal(attack(s, chariot.id, 4, 3, 0).ok, true);
  assert.equal(chariot.actionsLeft, 0);
  assert.equal(reachable(s, chariot).size, 0);
  endSide(s); endSide(s);
  assert.equal(chariot.actionsLeft, 1);
});

test('river changes damage by ten percent and fort shares stay in tenths', () => {
  const defendingFord = newMap(12, 7);
  setTerrain(defendingFord, 5, 3, TERRAIN.RIVER | TERRAIN.ROAD);
  addUnit(defendingFord, 'pharaoh', 'egypt', 0, 0);
  addUnit(defendingFord, 'heavy', 'egypt', 4, 3);
  addUnit(defendingFord, 'light', 'coalition', 5, 3);
  const s1 = startGame(defendingFord), heavy = mobileAt(s1.map, 4, 3);
  assert.equal(attackPreview(s1, heavy, 5, 3).damage, 33);
  assert.equal(attack(s1, heavy.id, 5, 3, 0).unitDamage, 33);

  const attackingFord = newMap(12, 7);
  setTerrain(attackingFord, 5, 3, TERRAIN.RIVER | TERRAIN.ROAD);
  setFort(attackingFord, 4, 3, 2, 'coalition');
  addUnit(attackingFord, 'pharaoh', 'egypt', 0, 0);
  addUnit(attackingFord, 'light', 'egypt', 5, 3);
  addUnit(attackingFord, 'light', 'coalition', 4, 3);
  const s2 = startGame(attackingFord), light = mobileAt(s2.map, 5, 3);
  assert.equal(attackPreview(s2, light, 4, 3).damage, 23);
  const result = attack(s2, light.id, 4, 3, 0);
  assert.equal(result.fortDamage, 0);
  assert.equal(result.unitDamage, 9);
  assert.equal(fortAt(s2.map, 4, 3).hp, 400);
});

test('river damage uses the actual guard tile when a guard intercepts for a monarch', () => {
  const map = newMap(12, 7);
  setTerrain(map, 5, 3, TERRAIN.RIVER | TERRAIN.ROAD);
  addUnit(map, 'pharaoh', 'egypt', 5, 2);
  addUnit(map, 'guard', 'egypt', 5, 3);
  addUnit(map, 'heavy', 'coalition', 4, 2);
  const s = startGame(map), attacker = mobileAt(s.map, 4, 2), guard = mobileAt(s.map, 5, 3);
  endSide(s);
  const result = attack(s, attacker.id, 5, 2, 0);
  assert.equal(result.defenderId, guard.id);
  assert.equal(result.unitDamage, 11);
  assert.equal(guard.hp, 79);
  assert.equal(mobileAt(s.map, 5, 2).hp, 60);
});

test('Troy retains sea, beach, walled city, heroes, cargo and capture rule across save and load', () => {
  const map = troyMap(), loaded = importMap(exportMap(map));
  assert.equal(loaded.victory.mode, 'troy');
  assert.equal(loaded.victory.horseUnlockTurn, 61);
  assert.equal(loaded.hectorSortieTurn, 21);
  assert.deepEqual(loaded.recruitment, map.recruitment);
  assert.equal(loaded.units.filter(u => u.kind === 'hero').length, 2);
  const walls = loaded.units.filter(u => u.kind === 'fort');
  assert.ok(walls.length > 50);
  assert.ok(walls.every(u => u.level === 2 && u.hp === FORT_HP[2]));
  assert.equal(loaded.units.filter(u => u.kind === 'transport').length, 6);
  assert.equal(loaded.units.filter(u => u.aboard).length, 10);
  assert.ok(loaded.houses.reduce((sum, present) => sum + present, 0) >= 35);
  assert.ok(houseAt(loaded, 44, 22) && houseAt(loaded, 44, 15));
  assert.deepEqual(loaded.garden, { cMin: 45, rMin: 22, cMax: 49, rMax: 25 });
  assert.ok(loaded.terrain.includes(TERRAIN.SEA));
  assert.ok(loaded.terrain.includes(TERRAIN.BEACH));
  assert.equal(loaded.unitNames['egypt:hero'], '阿喀琉斯');
  assert.equal(loaded.unitNames['coalition:hero'], '赫克托');
  for (const [cityId, count] of [['特洛伊', 61], ['特洛伊内城', 12],
    ['北滩头堡垒', 6], ['平原堡垒', 6], ['南滩头堡垒', 6]]) {
    const group = walls.filter(u => u.cityId === cityId);
    assert.equal(group.length, count);
    const wallSet = new Set(group.map(u => key(u.c, u.r)));
    const seenWalls = new Set(), pending = [group[0]];
    while (pending.length) {
      const wall = pending.pop(), at = key(wall.c, wall.r);
      if (seenWalls.has(at)) continue;
      seenWalls.add(at);
      for (const p of neighbors(wall.c, wall.r)) if (wallSet.has(key(p.c, p.r))) pending.push(p);
    }
    assert.equal(seenWalls.size, group.length);
  }
  const goal = loaded.victory.capture;
  assert.equal(mobileAt(loaded, goal.c, goal.r), null);
  assert.equal(walls.filter(u => u.cityId === '特洛伊内城')
    .every(u => distance(u, goal) === 2), true);
  for (const [c, r, kind] of [[26, 11, 'archer'], [29, 24, 'heavy'], [23, 30, 'light']]) {
    assert.equal(mobileAt(loaded, c, r)?.kind, kind);
    assert.equal(neighbors(c, r).every(p => fortAt(loaded, p.c, p.r)?.level === 2), true);
  }
  const roads = new Set([key(18, 18)]), roadQueue = [{ c: 18, r: 18 }];
  for (const p of roadQueue) for (const n of neighbors(p.c, p.r)) {
    if (!inBounds(loaded, n.c, n.r) || !(loaded.terrain[index(loaded, n.c, n.r)] & TERRAIN.ROAD) || roads.has(key(n.c, n.r))) continue;
    roads.add(key(n.c, n.r)); roadQueue.push(n);
  }
  assert.equal(roads.size, loaded.terrain.filter(t => t & TERRAIN.ROAD).length);
  assert.equal(roads.has(key(goal.c, goal.r)), true);
  const s = startGame(loaded), greek = s.map.units.find(u => u.kind === 'hero' && u.team === 'egypt');
  greek.c = loaded.victory.capture.c; greek.r = loaded.victory.capture.r;
  assert.equal(checkVictory(s), 'egypt');
});

test('old Troy exports migrate from the turn-40 event and level-three walls', () => {
  const old = exportMap(troyMap());
  delete old.victory.horseUnlockTurn;
  old.victory.horseTurn = 40;
  old.heroRelease.turn = 20;
  delete old.hectorSortieTurn;
  delete old.recruitment.costs.trojanHorse;
  delete old.recruitment.muster.egypt.land;
  for (const wall of old.units.filter(u => u.kind === 'fort')) {
    wall.level = 3;
    wall.hp = 100;
  }
  const map = importMap(old);
  assert.equal(map.victory.horseUnlockTurn, 61);
  assert.deepEqual(map.heroRelease, { team: 'egypt', turn: 25 });
  assert.equal(map.hectorSortieTurn, 21);
  assert.ok(map.units.filter(u => u.kind === 'fort').every(u => u.level === 2 && u.hp === FORT_HP[2]));
  assert.equal(map.recruitment.costs.trojanHorse, 600);
  assert.deepEqual(map.recruitment.muster.egypt.land, { c: 18, r: 20 });
});

test('previous Troy exports with the turn-41 horse also adopt the new deployment time and price', () => {
  const old = exportMap(troyMap());
  old.victory.horseUnlockTurn = 41;
  old.recruitment.costs.trojanHorse = 100;
  old.intro = '第 41 回合起可花 100 金购买一次木马';
  const map = importMap(old);
  assert.equal(map.victory.horseUnlockTurn, 61);
  assert.equal(map.recruitment.costs.trojanHorse, 600);
  assert.match(map.intro, /第 61 回合起可花 600 金/);
});

test('Troy starts with seven Achaean land units against a seven-piece coastal corps and open landing cells', () => {
  const map = troyMap();
  const achaean = map.units.filter(u => u.team === 'egypt' && u.kind !== 'fort');
  const trojan = map.units.filter(u => u.team === 'coalition' && u.kind !== 'fort');
  const ashore = achaean.filter(u => !u.aboard && !['warship', 'transport'].includes(u.kind));
  const coastalCorps = trojan.filter(u => [[22, 15], [24, 17], [23, 23], [24, 20],
    [25, 18], [22, 21], [25, 20]].some(([c, r]) => u.c === c && u.r === r));
  assert.equal(achaean.length, 25);
  assert.equal(ashore.length, 7);
  assert.equal(trojan.length, 32);
  assert.equal(achaean.filter(u => u.aboard).length, 10);
  assert.equal(coastalCorps.length, 7);
  assert.ok(trojan.some(u => u.c === 16 && u.r === 8));
  assert.ok(trojan.some(u => u.c === 17 && u.r === 31));
  for (const [c, r] of [[15, 13], [15, 18], [16, 29]]) {
    assert.ok(map.terrain[index(map, c, r)] & TERRAIN.BEACH);
    assert.equal(mobileAt(map, c, r), null);
  }
});

test('Achilles cannot be targeted before turn 25 and does not block an early Trojan beach victory', () => {
  const s = startGame(troyMap());
  const achilles = s.map.units.find(u => u.kind === 'hero' && u.team === 'egypt');
  const heavy = mobileAt(s.map, 24, 17), archer = mobileAt(s.map, 22, 15);
  heavy.c = 17; heavy.r = 16;
  archer.c = 16; archer.r = 15;
  endSide(s);
  assert.equal(s.side, 'coalition');
  recomputeFog(s);
  for (const attacker of [heavy, archer]) {
    const before = [attacker.actionsLeft, attacker.ammo, achilles.hp];
    assert.equal(attackPreview(s, attacker, achilles.c, achilles.r), null);
    assert.match(attack(s, attacker.id, achilles.c, achilles.r, 0).reason, /攻击无效/);
    assert.deepEqual([attacker.actionsLeft, attacker.ammo, achilles.hp], before);
  }
  s.turn = 25;
  assert.ok(attackPreview(s, heavy, achilles.c, achilles.r));
  assert.equal(attack(s, heavy.id, achilles.c, achilles.r, 0).ok, true);
  assert.ok(achilles.hp < STATS.hero.hp);

  const early = startGame(troyMap());
  for (const u of early.map.units) if (u.team === 'egypt' && !u.aboard &&
    !['hero', 'warship', 'transport'].includes(u.kind)) u.hp = 0;
  assert.equal(checkVictory(early), 'coalition');
});

test('Troy uses its own names for every available piece on both sides', () => {
  const map = troyMap();
  for (const team of ['egypt', 'coalition']) for (const kind of Object.keys(STATS)) {
    if (!canPlaceKind(kind, team) || kind.endsWith('Trireme') ||
        ['phalangite', 'companionCavalry', 'scythedChariot', 'warElephant',
          'romanVelites', 'romanHastati', 'romanPrincipes', 'romanTriarii', 'romanLegion',
          'romanOnager', 'siegeTower', 'romanArcher', 'defenseTower', 'romanHorse',
          'romanAlliedHorse', 'gaulInfantry', 'iberianInfantry', 'africanInfantry',
          'punicSkirmisher', 'punicHeavyHorse', 'numidianHorse', 'hannibal', 'paullus', 'varro',
          'scipio', 'masinissa', 'masinissaHorse', 'zamaPunicHorse', 'zamaVeteran',
          'caesarReserve', 'pompeyLegion', 'pompeyHorse', 'octavianLiburnian',
          'antonyHeavyGalley', 'cleopatraGalley', 'parthianHorseArcher',
          'parthianCataphract', 'arrowCamel'].includes(kind)) continue;
    const name = unitName(map, { team, kind });
    assert.equal(name, TROY_UNIT_NAMES[`${team}:${kind}`]);
    assert.doesNotMatch(name, /埃及|赫梯|法老|穆瓦塔利|拉美西斯/);
  }
  assert.equal(canPlaceKind('hittiteChariot', 'egypt'), false);
  assert.equal(canPlaceKind('hittiteKing', 'egypt'), false);
  assert.equal(canPlaceKind('pharaoh', 'coalition'), false);
  assert.equal(unitName(map, { team: 'egypt', kind: 'pharaoh' }), '阿伽门农');
  assert.equal(unitName(map, { team: 'coalition', kind: 'hittiteKing' }), '普里阿摩斯');
});

test('Troy defenders win when no Greek combat piece remains ashore, even if ships and cargo survive', () => {
  const s = startGame(troyMap());
  for (const u of s.map.units) if (u.team === 'egypt' && !u.aboard && !['warship', 'transport'].includes(u.kind)) u.hp = 0;
  assert.equal(checkVictory(s), 'coalition');
  assert.ok(s.map.units.some(u => u.team === 'egypt' && u.kind === 'warship' && u.hp > 0));
});

test('transport carries two infantry from sea to adjacent beach and preserves cargo when moving', () => {
  const s = startGame(troyMap()), ship = mobileAt(s.map, 13, 13);
  assert.equal(cargoOf(s.map, ship).length, 2);
  assert.equal(move(s, ship.id, 14, 13).ok, true);
  assert.ok(cargoOf(s.map, ship).every(u => u.c === 14 && u.r === 13));
  assert.equal(disembark(s, ship.id, 15, 13), true);
  const soldier = mobileAt(s.map, 15, 13);
  assert.equal(soldier.kind, 'heavy');
  assert.equal(cargoOf(s.map, ship).length, 1);
  assert.equal(embark(s, soldier.id, ship.id), true);
  assert.equal(cargoOf(s.map, ship).length, 2);
  assert.equal(disembark(s, ship.id, 14, 13), false);
});

test('warship can destroy light infantry with a hit but fires only once each turn', () => {
  const m = newMap(12, 7);
  setTerrain(m, 3, 3, TERRAIN.SEA);
  addUnit(m, 'pharaoh', 'egypt', 0, 0);
  addUnit(m, 'warship', 'egypt', 3, 3);
  addUnit(m, 'light', 'coalition', 4, 3);
  addUnit(m, 'light', 'coalition', 5, 3);
  const s = startGame(m), ship = mobileAt(s.map, 3, 3);
  assert.equal(attackPreview(s, ship, 4, 3).damage, 70);
  assert.equal(attack(s, ship.id, 4, 3, 0).unitDamage, 70);
  assert.equal(attackPreview(s, ship, 5, 3), null);
});

test('hero attack follows decreasing 6–12 damage distribution and has ten spears', () => {
  assert.deepEqual([0, .30, .54, .72, .84, .92, .97].map(heroPower), [6, 7, 8, 9, 10, 11, 12]);
  const m = newMap(12, 7);
  addUnit(m, 'pharaoh', 'egypt', 0, 0);
  addUnit(m, 'hero', 'egypt', 3, 3);
  addUnit(m, 'light', 'coalition', 5, 3);
  const s = startGame(m), hero = mobileAt(s.map, 3, 3);
  assert.equal(hero.hp, 400);
  assert.equal(STATS.hero.armor, 5);
  const strike = attack(s, hero.id, 5, 3, 0, .99);
  assert.equal(strike.unitDamage, 70);
  assert.equal(strike.actionRefunded, true);
  assert.equal(hero.actionsLeft, 2);
  assert.equal(hero.ammo, 9);
});

test('a hero with one action can chain direct kills without spending it', () => {
  const map = newMap(12, 7);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'hero', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 4, 3);
  addUnit(map, 'light', 'coalition', 3, 4);
  addUnit(map, 'light', 'coalition', 8, 6);
  const s = startGame(map), hero = mobileAt(s.map, 3, 3);
  hero.actionsLeft = 1;
  for (const [c, r] of [[4, 3], [3, 4]]) {
    const result = attack(s, hero.id, c, r, 0, .99);
    assert.equal(result.actionRefunded, true);
    assert.equal(mobileAt(s.map, c, r), null);
    assert.equal(hero.actionsLeft, 1);
  }
  assert.equal(s.over, false);
  assert.equal(s.log.filter(line => line.includes('返还 1 点行动力')).length, 2);
});

test('a miss, wall breach, or ordinary soldier kill does not refund an action', () => {
  const map = newMap(12, 7);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'hero', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 4, 3);
  const missed = startGame(map), hero = mobileAt(missed.map, 3, 3);
  hero.actionsLeft = 1;
  assert.equal(attack(missed, hero.id, 4, 3, .99, .99).hit, false);
  assert.equal(hero.actionsLeft, 0);

  const wallMap = newMap(12, 7);
  addUnit(wallMap, 'pharaoh', 'egypt', 0, 0);
  addUnit(wallMap, 'hero', 'egypt', 3, 3);
  setFort(wallMap, 4, 3, 1, 'coalition');
  addUnit(wallMap, 'light', 'coalition', 8, 6);
  const breached = startGame(wallMap), wallHero = mobileAt(breached.map, 3, 3);
  fortAt(breached.map, 4, 3).hp = 10;
  wallHero.actionsLeft = 1;
  const wallStrike = attack(breached, wallHero.id, 4, 3, 0, .99);
  assert.equal(wallStrike.actionRefunded, false);
  assert.equal(wallHero.actionsLeft, 0);

  const soldierMap = newMap(12, 7);
  addUnit(soldierMap, 'pharaoh', 'egypt', 0, 0);
  addUnit(soldierMap, 'heavy', 'egypt', 3, 3);
  addUnit(soldierMap, 'light', 'coalition', 4, 3);
  const ordinary = startGame(soldierMap), heavy = mobileAt(ordinary.map, 3, 3);
  mobileAt(ordinary.map, 4, 3).hp = 10;
  heavy.actionsLeft = 1;
  assert.equal(attack(ordinary, heavy.id, 4, 3, 0).actionRefunded, false);
  assert.equal(heavy.actionsLeft, 0);
});

test('ordinary troops deal half damage to heroes after armor, but hero duels do not', () => {
  const ordinary = newMap(10, 6);
  addUnit(ordinary, 'pharaoh', 'egypt', 0, 0);
  addUnit(ordinary, 'hero', 'egypt', 3, 3);
  addUnit(ordinary, 'heavy', 'coalition', 4, 3);
  const s = startGame(ordinary), defender = mobileAt(s.map, 3, 3);
  endSide(s);
  const heavy = mobileAt(s.map, 4, 3);
  assert.equal(attackPreview(s, heavy, 3, 3)?.damage, 5);
  assert.equal(attack(s, heavy.id, 3, 3, 0).unitDamage, 5);
  assert.equal(defender.hp, 395);

  const onWall = newMap(10, 6);
  addUnit(onWall, 'pharaoh', 'egypt', 0, 0);
  addUnit(onWall, 'hero', 'egypt', 3, 3);
  addUnit(onWall, 'heavy', 'coalition', 4, 3);
  setFort(onWall, 3, 3, 2, 'egypt');
  const wallGame = startGame(onWall);
  endSide(wallGame);
  const wallHit = attack(wallGame, mobileAt(wallGame.map, 4, 3).id, 3, 3, 0);
  assert.equal(wallHit.fortDamage, 0);
  assert.equal(wallHit.unitDamage, 2);

  const duel = newMap(10, 6);
  addUnit(duel, 'pharaoh', 'egypt', 0, 0);
  addUnit(duel, 'hero', 'egypt', 3, 3);
  addUnit(duel, 'hero', 'coalition', 4, 3);
  const heroGame = startGame(duel), attacker = mobileAt(heroGame.map, 3, 3);
  assert.equal(attackPreview(heroGame, attacker, 4, 3)?.damage, 10);
  assert.equal(attack(heroGame, attacker.id, 4, 3, 0, .99).unitDamage, 70);
});

test('heroes self-heal and gain supply regardless of remaining actions', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'hero', 'egypt', 3, 3);
  addUnit(map, 'light', 'coalition', 8, 4);
  setFort(map, 3, 2, 1, 'egypt', '英雄堡垒');
  setSupplyPoint(map, 3, 3, 'egypt', '英雄堡垒');
  const s = startGame(map), hero = mobileAt(s.map, 3, 3);
  hero.hp = 100;
  hero.actionsLeft = 1;
  endSide(s);
  assert.equal(hero.hp, 100);
  endSide(s);
  assert.equal(hero.hp, 150);
  hero.actionsLeft = 0;
  endSide(s); endSide(s);
  assert.equal(hero.hp, 200);
  hero.c = 3; hero.r = 2; hero.actionsLeft = 0;
  endSide(s); endSide(s);
  assert.equal(hero.hp, 240);
});

test('Achilles remains by the shore through turn 24 and joins on turn 25', () => {
  const map = troyMap(), loaded = importMap(exportMap(map));
  assert.deepEqual(loaded.heroRelease, { team: 'egypt', turn: 25 });
  const s = startGame(loaded), achilles = s.map.units.find(u => u.kind === 'hero' && u.team === 'egypt');
  assert.deepEqual([achilles.c, achilles.r], [16, 17]);
  assert.equal(achilles.actionsLeft, 0);
  assert.equal(reachable(s, achilles).size, 0);
  for (let turn = 2; turn <= 25; turn++) {
    endSide(s); endSide(s);
    assert.equal(s.turn, turn);
    assert.deepEqual([achilles.c, achilles.r], [16, 17]);
    assert.equal(achilles.actionsLeft, turn < 25 ? 0 : 2);
  }
  assert.ok(reachable(s, achilles).size > 0);
  assert.ok(s.log.some(line => line.includes('阿喀琉斯离开海边营帐')));
});

test('Hector waits in Troy through turn 20, then the computer sorties into the plain', () => {
  const s = startGame(troyMap());
  const hector = s.map.units.find(u => u.kind === 'hero' && u.team === 'coalition');
  assert.deepEqual([hector.c, hector.r, hector.actionsLeft], [41, 20, 0]);
  s.turn = 20;
  endSide(s);
  assert.equal(hector.actionsLeft, 0);
  endSide(s); endSide(s);
  assert.equal(s.turn, 21);
  assert.equal(hector.actionsLeft, 2);
  const first = aiTurn(s, () => 0.5);
  assert.ok(first.some(a => a.type === 'move' && a.id === hector.id));
  assert.ok(hector.c < 41);
  endSide(s);
  aiTurn(s, () => 0.5);
  assert.ok(hector.c < 35, 'Hector crosses the western city wall into the plain');
});

test('Troy pays income on each side turn and no longer grants free ships', () => {
  const s = startGame(troyMap());
  assert.deepEqual(s.money, { egypt: 42, coalition: 28 });
  assert.deepEqual(s.map.recruitment.costs, TROY_COSTS);
  for (let turn = 1; turn <= 3; turn++) {
    endSide(s);
    assert.equal(s.money.coalition, 28 + 10 * turn);
    endSide(s);
    assert.equal(s.money.egypt, 42 + 10 * turn);
    assert.equal(s.turn, turn + 1);
    assert.equal(s.map.units.filter(u => u.team === 'egypt' && u.kind === 'transport').length, 6);
    assert.equal(s.map.units.filter(u => u.team === 'egypt' && u.aboard).length, 10);
  }
});

test('Achaean recruits need a transport at sea muster, which holds two infantry or one chariot', () => {
  const s = startGame(troyMap());
  assert.match(recruit(s, 'heavy').reason, /运兵船/);
  assert.equal(s.money.egypt, 42);
  assert.equal(recruit(s, 'hero').ok, false);
  assert.equal(recruit(s, 'transport').ok, true);
  const at = s.map.recruitment.muster.egypt.sea, ship = mobileAt(s.map, at.c, at.r);
  assert.equal(ship.actionsLeft, 0);
  assert.equal(recruit(s, 'transport').ok, false);
  assert.equal(recruit(s, 'heavy').ok, true);
  assert.equal(recruit(s, 'light').ok, true);
  assert.equal(cargoLoad(s.map, ship), 2);
  assert.equal(cargoOf(s.map, ship).every(u => u.actionsLeft === 0), true);
  assert.equal(recruit(s, 'archer').ok, false);
  assert.equal(s.money.egypt, 10);
  const chariotRun = startGame(troyMap());
  chariotRun.money.egypt = 200; // Fund the transport and the updated 150-gold chariot.
  assert.equal(recruit(chariotRun, 'transport').ok, true);
  assert.equal(recruit(chariotRun, 'chariot').ok, true);
  const chariotShip = mobileAt(chariotRun.map, at.c, at.r);
  assert.equal(cargoLoad(chariotRun.map, chariotShip), 2);
  assert.equal(cargoOf(chariotRun.map, chariotShip)[0].kind, 'chariot');
  assert.equal(recruit(chariotRun, 'light').ok, false);
  endSide(chariotRun); endSide(chariotRun);
  chariotShip.c = 14; chariotShip.r = 13;
  for (const passenger of cargoOf(chariotRun.map, chariotShip)) { passenger.c = 14; passenger.r = 13; }
  recomputeFog(chariotRun);
  assert.equal(disembark(chariotRun, chariotShip.id, 15, 13), true);
  assert.equal(mobileAt(chariotRun.map, 15, 13)?.kind, 'chariot');
});

test('Trojan land and naval recruits spend money and wait until next turn to act', () => {
  const s = startGame(troyMap());
  endSide(s);
  assert.equal(s.side, 'coalition');
  const land = s.map.recruitment.muster.coalition.land;
  const heavy = recruit(s, 'heavy');
  assert.equal(heavy.ok, true);
  assert.deepEqual([heavy.unit.c, heavy.unit.r], [land.c, land.r]);
  assert.equal(heavy.unit.actionsLeft, 0);
  assert.equal(recruit(s, 'light').ok, false);
  assert.equal(recruit(s, 'transport').ok, true);
  const warship = recruit(s, 'warship');
  assert.equal(warship.ok, false, 'the remaining money cannot buy a warship');
  assert.equal(s.money.coalition, 14);
  endSide(s); endSide(s);
  assert.equal(heavy.unit.actionsLeft, 2);
  const naval = startGame(troyMap());
  endSide(naval);
  assert.equal(recruit(naval, 'warship').ok, true);
  const sea = naval.map.recruitment.muster.coalition.sea;
  assert.equal(mobileAt(naval.map, sea.c, sea.r)?.kind, 'warship');
  assert.equal(naval.money.coalition, 8);
});

test('Troy computer factions use the same money and rally rules', () => {
  const s = startGame(troyMap());
  const greekActions = aiTurn(s, () => 0.5);
  assert.equal(greekActions.filter(a => a.type === 'recruit').length, 3);
  assert.equal(s.money.egypt, 10);
  assert.equal(cargoLoad(s.map, mobileAt(s.map, 7, 18)), 2);
  const trojanActions = aiTurn(s, () => 0.5);
  assert.equal(trojanActions.some(a => a.type === 'recruit' && a.kind === 'heavy'), true);
  assert.equal(s.money.coalition, 26);
});

test('Achaean computer purchases its one Trojan horse after it unlocks', () => {
  const s = startGame(troyMap());
  s.turn = 61; s.money.egypt = 600;
  const actions = aiTurn(s, () => 0.5);
  assert.equal(actions.filter(a => a.type === 'recruit' && a.kind === 'trojanHorse').length, 1);
  assert.equal(s.trojanHorsePurchased, true);
  assert.equal(s.map.units.filter(u => u.kind === 'trojanHorse').length, 1);
});

test('Troy has no automatic victory at turn 40 and sells one slow horse from turn 61 for 600 gold', () => {
  const s = startGame(troyMap());
  assert.equal(STATS.trojanHorse.hp, 400);
  assert.equal(STATS.trojanHorse.armor, 30);
  assert.equal(STATS.trojanHorse.melee, 8);
  assert.equal(TROY_COSTS.trojanHorse, 600);
  s.turn = 39;
  endSide(s);
  assert.equal(s.side, 'coalition');
  assert.equal(s.over, false);
  endSide(s);
  assert.equal(s.turn, 40);
  assert.equal(s.side, 'egypt');
  assert.equal(s.over, false);
  s.turn = 60; s.money.egypt = 600;
  assert.match(recruit(s, 'trojanHorse').reason, /第 61 回合/);
  assert.equal(s.money.egypt, 600);
  endSide(s); endSide(s);
  assert.equal(s.turn, 61);
  assert.equal(s.over, false);
  s.money.egypt = 599;
  assert.match(recruit(s, 'trojanHorse').reason, /需要 600 金/);
  s.money.egypt = 600;
  const bought = recruit(s, 'trojanHorse');
  assert.equal(bought.ok, true);
  assert.equal(bought.cost, 600);
  assert.equal(bought.unit.actionsLeft, 0);
  assert.equal(s.money.egypt, 0);
  assert.equal(recruit(s, 'trojanHorse').ok, false);
  endSide(s); endSide(s);
  assert.match(recruit(s, 'trojanHorse').reason, /只能购买一次/);
});

test('Troy turn-65 trial starts with Achaean control, 1000 gold and both heroes active', () => {
  const s = startTroyTurn65();
  assert.equal(s.map.scenarioId, 'troy');
  assert.equal(s.turn, 65);
  assert.equal(s.side, 'egypt');
  assert.equal(s.money.egypt, 1000);
  assert.equal(s.over, false);
  assert.equal(s.deploying, false);
  assert.ok(s.map.units.filter(u => u.kind === 'hero').every(u => u.actionsLeft === 2));
  const hector = s.map.units.find(u => u.kind === 'hero' && u.team === 'coalition');
  assert.deepEqual({ c: hector.c, r: hector.r }, { c: 30, r: 20 });
  const bought = recruit(s, 'trojanHorse');
  assert.equal(bought.ok, true);
  assert.equal(bought.cost, 600);
  assert.equal(s.money.egypt, 400);
});

test('Troy horse moves only one hex per whole turn even when starting on a road', () => {
  const s = startGame(troyMap());
  s.turn = 61; s.money.egypt = 600;
  const result = recruit(s, 'trojanHorse');
  assert.equal(result.ok, true);
  const horse = result.unit;
  endSide(s); endSide(s);
  const from = { c: horse.c, r: horse.r };
  s.map.terrain[index(s.map, from.c, from.r)] = TERRAIN.ROAD;
  const destinations = [...reachable(s, horse).values()];
  assert.ok(destinations.length > 0);
  assert.ok(destinations.every(p => distance(p, from) === 1));
  const first = destinations[0];
  assert.equal(move(s, horse.id, first.c, first.r).ok, true);
  assert.equal(horse.actionsLeft, 1);
  assert.equal(reachable(s, horse).size, 0);
  endSide(s); endSide(s);
  assert.equal(horse.movesUsed, 0);
  assert.ok(reachable(s, horse).size > 0);
});

test('Troy horse crushes an enemy occupying its next hex and still moves only once', () => {
  const s = startGame(troyMap());
  s.turn = 61; s.money.egypt = 600;
  const horse = recruit(s, 'trojanHorse').unit;
  endSide(s); endSide(s);
  const target = neighbors(horse.c, horse.r).find(p => inBounds(s.map, p.c, p.r) &&
    !mobileAt(s.map, p.c, p.r) && !fortAt(s.map, p.c, p.r) &&
    tile(s.map, p.c, p.r).terrain !== TERRAIN.SEA);
  assert.ok(target);
  const enemy = s.map.units.find(u => u.kind === 'heavy' && u.team === 'coalition');
  enemy.c = target.c; enemy.r = target.r;
  recomputeFog(s);
  assert.equal(reachable(s, horse).has(key(target.c, target.r)), true);
  assert.equal(attackPreview(s, horse, target.c, target.r), null);
  const result = move(s, horse.id, target.c, target.r);
  assert.equal(result.ok, true);
  assert.equal(result.crushedId, enemy.id);
  assert.equal(enemy.hp, 0);
  assert.deepEqual({ c: horse.c, r: horse.r }, target);
  assert.equal(horse.hp, STATS.trojanHorse.hp);
  assert.equal(reachable(s, horse).size, 0);
});

test('Troy horse cannot be damaged by direct attacks or uncontrolled elephant trampling', () => {
  const s = startGame(troyMap());
  s.turn = 61; s.money.egypt = 600;
  const horse = recruit(s, 'trojanHorse').unit;
  const target = neighbors(horse.c, horse.r).find(p => inBounds(s.map, p.c, p.r) &&
    !mobileAt(s.map, p.c, p.r) && !fortAt(s.map, p.c, p.r) &&
    tile(s.map, p.c, p.r).terrain !== TERRAIN.SEA);
  assert.ok(target);
  const enemy = s.map.units.find(u => u.kind === 'heavy' && u.team === 'coalition');
  enemy.c = target.c; enemy.r = target.r; enemy.actionsLeft = 2;
  s.side = 'coalition';
  recomputeFog(s);
  assert.equal(attackPreview(s, enemy, horse.c, horse.r), null);
  assert.match(attack(s, enemy.id, horse.c, horse.r).reason, /不可破坏/);
  assert.equal(horse.hp, STATS.trojanHorse.hp);
  enemy.kind = 'warElephant'; enemy.uncontrolled = true;
  moveUncontrolledElephants(s, () => 0);
  assert.equal(horse.hp, STATS.trojanHorse.hp);
});

test('Troy horse attacks walls only and deals 40.0 damage through wall armor and a garrison', () => {
  const s = startGame(troyMap());
  s.turn = 61; s.money.egypt = 600;
  const horse = recruit(s, 'trojanHorse').unit;
  const wall = s.map.units.find(u => u.kind === 'fort' && u.cityId === '北滩头堡垒');
  const outside = neighbors(wall.c, wall.r).find(p =>
    !fortAt(s.map, p.c, p.r) && !mobileAt(s.map, p.c, p.r) && s.map.terrain[index(s.map, p.c, p.r)] !== TERRAIN.SEA);
  assert.ok(outside);
  horse.c = outside.c; horse.r = outside.r; horse.actionsLeft = 2;
  const soldier = s.map.units.find(u => u.kind === 'heavy' && u.team === 'coalition');
  soldier.c = wall.c; soldier.r = wall.r;
  recomputeFog(s);
  assert.equal(attackPreview(s, horse, wall.c, wall.r).target.kind, 'fort');
  assert.equal(attackPreview(s, horse, wall.c, wall.r).damage, 400);
  assert.equal(attackPreview(s, horse, wall.c, wall.r).hit, 100);
  const before = soldier.hp;
  const hit = attack(s, horse.id, wall.c, wall.r, 0.99);
  assert.equal(hit.ok, true);
  assert.equal(hit.fortDamage, 400);
  assert.equal(hit.unitDamage, 0);
  assert.equal(wall.hp, 0);
  assert.equal(soldier.hp, before);
  assert.equal(attackPreview(s, horse, soldier.c, soldier.r), null);
});

test('morale multiplies ordinary attack damage and a normal kill grants a three-turn bonus only on a successful roll', () => {
  const map = newMap(12, 7);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  addUnit(map, 'light', 'coalition', 3, 2);
  addUnit(map, 'light', 'coalition', 9, 5);
  const s = startGame(map), attacker = mobileAt(s.map, 2, 2), victim = mobileAt(s.map, 3, 2);
  attacker.morale = 0.5;
  assert.equal(attackPreview(s, attacker, 3, 2).damage, 15);
  attacker.morale = 1;
  victim.hp = 5;
  attack(s, attacker.id, 3, 2, 0, 0, 0.49);
  assert.equal(moraleOf(attacker), 1.2);
  assert.equal(moraleOf(s.map.units.find(u => u.kind === 'pharaoh')), 1);
  for (let remaining = 2; remaining >= 0; remaining--) {
    endSide(s);
    assert.equal(attacker.moraleBoosts?.[0]?.remaining ?? 0, remaining);
    if (remaining) endSide(s);
  }
  assert.equal(moraleOf(attacker), 1);
  const miss = startGame(map), noBonusAttacker = mobileAt(miss.map, 2, 2);
  mobileAt(miss.map, 3, 2).hp = 5;
  attack(miss, noBonusAttacker.id, 3, 2, 0, 0, 0.5);
  assert.equal(moraleOf(noBonusAttacker), 1);
});

test('hero and commander kills boost ordinary teammates while commanders themselves ignore morale', () => {
  const heroMap = newMap(12, 7);
  addUnit(heroMap, 'pharaoh', 'egypt', 0, 0);
  addUnit(heroMap, 'heavy', 'egypt', 2, 2);
  addUnit(heroMap, 'light', 'egypt', 1, 4);
  addUnit(heroMap, 'hero', 'coalition', 3, 2);
  addUnit(heroMap, 'light', 'coalition', 9, 5);
  const heroGame = startGame(heroMap);
  mobileAt(heroGame.map, 3, 2).hp = 5;
  attack(heroGame, mobileAt(heroGame.map, 2, 2).id, 3, 2, 0, 0, 0.99);
  assert.equal(moraleOf(mobileAt(heroGame.map, 2, 2)), 1.2);
  assert.equal(moraleOf(mobileAt(heroGame.map, 1, 4)), 1.2);
  assert.equal(moraleOf(mobileAt(heroGame.map, 0, 0)), 1);

  const leaderMap = newMap(12, 7);
  addUnit(leaderMap, 'pharaoh', 'egypt', 3, 2);
  addUnit(leaderMap, 'light', 'egypt', 1, 4);
  addUnit(leaderMap, 'heavy', 'coalition', 2, 2);
  addUnit(leaderMap, 'light', 'coalition', 9, 5);
  const leaderGame = startGame(leaderMap);
  mobileAt(leaderGame.map, 3, 2).hp = 5;
  endSide(leaderGame);
  attack(leaderGame, mobileAt(leaderGame.map, 2, 2).id, 3, 2, 0, 0, 0.99);
  assert.equal(moraleOf(mobileAt(leaderGame.map, 2, 2)), 1.3);
  assert.equal(moraleOf(mobileAt(leaderGame.map, 9, 5)), 1.3);
  assert.equal(moraleOf(mobileAt(leaderGame.map, 1, 4)), 0.75);
});

test('half health and encirclement lower morale; routed troops flee without player commands', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'light', 'egypt', 4, 3);
  for (const [c, r] of [[4, 2], [5, 3], [4, 4]]) addUnit(map, 'light', 'coalition', c, r);
  const s = startGame(map), runner = mobileAt(s.map, 4, 3);
  runner.hp = 34;
  runner.morale = 0.3;
  runner.encirclementMoraleApplied = false;
  endSide(s); endSide(s);
  assert.equal(runner.morale, 0.18);
  assert.equal(isRouted(runner), true);
  assert.equal(runner.actionsLeft, 0);
  assert.notDeepEqual([runner.c, runner.r], [4, 3]);
  assert.equal(move(s, runner.id, 2, 3).ok, false);
  assert.equal(attackPreview(s, runner, 4, 2), null);
});

test('the first attack that takes a survivor below half health applies one morale shock', () => {
  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  addUnit(map, 'light', 'coalition', 3, 2);
  addUnit(map, 'light', 'coalition', 8, 5);
  const s = startGame(map), attacker = mobileAt(s.map, 2, 2), defender = mobileAt(s.map, 3, 2);
  defender.hp = 36;
  attack(s, attacker.id, 3, 2, 0);
  assert.equal(moraleOf(defender), 0.9);
  assert.equal(defender.halfHealthShockUsed, true);
  defender.hp = 36;
  attack(s, attacker.id, 3, 2, 0);
  assert.equal(moraleOf(defender), 0.9);
});

test('Qarqar deploys a walled city, staged coalition and self-operated siege rams', () => {
  const map = qarqarMap(), loaded = importMap(exportMap(map));
  assert.equal(loaded.victory.mode, 'qarqar');
  assert.equal(loaded.units.filter(u => u.kind === 'siegeRam').length, 2);
  assert.equal(loaded.reinforcements.length, 2);
  assert.equal(loaded.units.filter(u => u.kind === 'fort' && u.cityId === '卡尔卡尔').length, 12);
  const s = startGame(loaded);
  assert.equal(s.map.factions.egypt, '亚述军');
  const objective = s.map.victory.objective, occupier = mobileAt(s.map, 42, 20);
  occupier.c = objective.c; occupier.r = objective.r;
  endSide(s); endSide(s); endSide(s);
  assert.equal(s.winner, 'egypt');
  assert.equal(s.victoryReason, 'qarqar_road');
  const held = startGame(map);
  held.side = 'coalition'; held.turn = 20;
  endSide(held);
  assert.equal(held.winner, 'coalition');

  const small = newMap(10, 6);
  addUnit(small, 'pharaoh', 'egypt', 0, 0);
  addUnit(small, 'siegeRam', 'egypt', 2, 2);
  setFort(small, 3, 2, 2, 'coalition');
  addUnit(small, 'archer', 'coalition', 3, 2);
  const siege = startGame(small), ram = mobileAt(siege.map, 2, 2);
  assert.ok(attackPreview(siege, ram, 3, 2));
  const result = attack(siege, ram.id, 3, 2, 0);
  assert.equal(result.fortDamage, 100);
  assert.equal(result.unitDamage, 0);
  assert.equal(mobileAt(siege.map, 3, 2).hp, STATS.archer.hp);
  assert.ok(attackPreview(siege, ram, 3, 2));
});

test('Babylon map preserves a large city, houses, garden and the immobile rescue target', () => {
  const map = babylonMap(), loaded = importMap(exportMap(map));
  assert.equal(loaded.scenarioId, 'babylon');
  assert.equal('turnLimit' in loaded.victory, false);
  assert.equal(loaded.cols, 104); assert.equal(loaded.rows, 72);
  assert.ok(loaded.houses.reduce((a, b) => a + b, 0) >= 100);
  assert.ok(loaded.units.filter(u => u.kind === 'fort').length >= 300);
  assert.ok(loaded.garden);
  const captive = loaded.units.find(u => u.kind === 'captive');
  assert.equal(captive.hp, STATS.captive.hp);
  assert.equal(captive.actionsLeft, 0);
  assert.equal(reachable(startGame(loaded), captive).size, 0);
  assert.equal(loaded.units.filter(u => u.pursuer).length, 2);
});

test('Babylon starts with fifty Persian combat pieces on both riverbanks and four siege rams', () => {
  const map = babylonMap();
  const persians = map.units.filter(u => u.team === 'egypt' && !['fort', 'captive'].includes(u.kind));
  const west = persians.filter(u => u.c < 52), east = persians.filter(u => u.c > 53);
  assert.equal(persians.length, 50);
  assert.equal(west.length, 30);
  assert.equal(east.length, 20);
  assert.equal(persians.filter(u => u.kind === 'chariot').length, 5);
  assert.equal(persians.filter(u => u.kind === 'cavalry').length, 6);
  assert.equal(persians.filter(u => u.kind === 'siegeRam').length, 4);
  assert.equal(west.filter(u => u.kind === 'siegeRam').length, 2);
  assert.equal(east.filter(u => u.kind === 'siegeRam').length, 2);
  assert.ok(persians.every(u => u.c < 34 || u.c > 77));
  assert.ok(persians.every(u => !fortAt(map, u.c, u.r)));
  const s = startGame(map);
  assert.equal(s.babylonAlarm, false);
  assert.ok(reachable(s, mobileAt(s.map, 32, 35)).size > 0);
  assert.ok(reachable(s, mobileAt(s.map, 81, 35)).size > 0);
});

test('Babylon battle has no turn limit, including maps exported with the old limit', () => {
  const oldMap = exportMap(babylonMap());
  oldMap.victory.turnLimit = 24;
  const s = startGame(importMap(oldMap));
  assert.equal('turnLimit' in s.map.victory, false);
  s.turn = 24; s.side = 'coalition';
  endSide(s);
  assert.equal(s.turn, 25);
  assert.equal(s.over, false);
  s.turn = 999; s.side = 'coalition';
  endSide(s);
  assert.equal(s.over, false);
  assert.equal(s.winner, null);
});

test('Babylon refuge is enclosed, and Persian infantry can climb its allied wall', () => {
  const map = babylonMap();
  const refuge = map.units.filter(u => u.kind === 'fort' && u.cityId === '犹大流亡者围院');
  assert.equal(refuge.length, 24);
  for (let r = 38; r <= 44; r++) for (let c = 61; c <= 67; c++) {
    if (c !== 61 && c !== 67 && r !== 38 && r !== 44) continue;
    assert.equal(fortAt(map, c, r)?.cityId, '犹大流亡者围院');
  }
  const s = startGame(map), infantry = s.map.units.find(u => u.team === 'egypt' && u.kind === 'heavy');
  infantry.c = 60; infantry.r = 41; recomputeFog(s);
  assert.equal(reachable(s, infantry).has(key(61, 41)), true);
  assert.equal(move(s, infantry.id, 61, 41).ok, true);
  assert.equal(reachable(s, infantry).has(key(62, 41)), true);
  assert.equal(move(s, infantry.id, 62, 41).ok, true);
  assert.equal(fortAt(s.map, 61, 41)?.hp, FORT_HP[1]);
});

test('Babylonian soldiers cannot attack or target the refuge wall before the city alarm', () => {
  const s = startGame(babylonMap());
  const soldier = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  soldier.c = 60; soldier.r = 41; soldier.actionsLeft = 2;
  s.side = 'coalition'; recomputeFog(s);
  const wall = fortAt(s.map, 61, 41), hp = wall.hp;
  assert.equal(attackPreview(s, soldier, 61, 41), null);
  assert.equal(attack(s, soldier.id, 61, 41, 0).ok, false);
  assert.equal(wall.hp, hp);
  s.babylonAlarm = true; recomputeFog(s);
  assert.ok(attackPreview(s, soldier, 61, 41));

  const aiState = startGame(babylonMap());
  const aiWall = fortAt(aiState.map, 61, 41), aiHp = aiWall.hp;
  const aiSoldier = aiState.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  aiSoldier.c = 60; aiSoldier.r = 41;
  aiState.side = 'coalition'; recomputeFog(aiState);
  const aiActions = aiTurn(aiState, () => 0);
  assert.equal(aiActions.some(a => a.type === 'attack' && a.c === 61 && a.r === 41), false);
  assert.equal(aiWall.hp, aiHp);
});

test('a house has no health and reduces garrison damage by 40 percent; mounted units cannot enter', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 2, 2);
  setHouse(map, 3, 2);
  addUnit(map, 'light', 'coalition', 3, 2);
  addUnit(map, 'cavalry', 'egypt', 4, 4);
  setHouse(map, 5, 4);
  addUnit(map, 'light', 'egypt', 4, 5);
  const s = startGame(map), attacker = mobileAt(s.map, 2, 2), guard = mobileAt(s.map, 3, 2);
  assert.equal(attackPreview(s, attacker, 3, 2).damage, 18);
  assert.equal(reachable(s, mobileAt(s.map, 4, 4)).has('5,4'), false);
  assert.equal(reachable(s, mobileAt(s.map, 4, 5)).has('5,4'), true);
  attack(s, attacker.id, 3, 2, 0);
  assert.equal(guard.hp, STATS.light.hp - 18);
  assert.equal(houseAt(s.map, 3, 2), true);
  assert.equal(s.map.units.some(u => u.kind === 'house'), false);
});

test('Babylon alarm starts only on breach, and rescue or either protected death ends the battle', () => {
  const map = babylonMap(), s = startGame(map);
  const captive = s.map.units.find(u => u.kind === 'captive');
  const pursuer = s.map.units.find(u => u.pursuer);
  const original = [pursuer.c, pursuer.r];
  s.side = 'coalition'; aiTurn(s, () => 0.1);
  assert.deepEqual([pursuer.c, pursuer.r], original);
  pursuer.c = 64; pursuer.r = 40; recomputeFog(s);
  assert.equal(attackPreview(s, pursuer, captive.c, captive.r), null);
  const ram = s.map.units.find(u => u.kind === 'siegeRam');
  const gate = fortAt(s.map, 34, 35);
  ram.c = 33; ram.r = 35; gate.hp = 1; s.side = 'egypt'; ram.actionsLeft = 2;
  recomputeFog(s);
  attack(s, ram.id, gate.c, gate.r, 0);
  assert.equal(s.babylonAlarm, true);
  s.side = 'coalition'; pursuer.actionsLeft = 2; recomputeFog(s);
  assert.ok(attackPreview(s, pursuer, captive.c, captive.r));
  captive.hp = 1;
  attack(s, pursuer.id, captive.c, captive.r, 0);
  assert.equal(s.winner, 'coalition');
  assert.equal(s.victoryReason, 'babylon_captive');

  const rescued = startGame(map);
  const infantry = rescued.map.units.find(u => u.kind === 'heavy' && u.team === 'egypt');
  infantry.c = 63; infantry.r = 41;
  endSide(rescued);
  assert.equal(rescued.winner, 'egypt');
  assert.equal(rescued.victoryReason, 'babylon_rescue');

  const fallenKing = startGame(map);
  fallenKing.map.units.find(u => u.kind === 'pharaoh').hp = 0;
  checkVictory(fallenKing);
  assert.equal(fallenKing.winner, 'coalition');
  assert.equal(fallenKing.victoryReason, 'babylon_cyrus');
});

function salamisDuel() {
  const map = newMap(12, 8);
  map.scenarioId = 'salamis';
  map.factions = { egypt: '希腊联军', coalition: '波斯舰队' };
  map.victory = { mode: 'salamis', bay: { cMin: 1, rMin: 1, cMax: 4, rMax: 4 },
    greekLosses: 1, persianLosses: 1, bayShips: 1 };
  map.weather = { windDir: 0, clouds: [] };
  map.terrain.fill(TERRAIN.SEA);
  addUnit(map, 'athenianTrireme', 'egypt', 2, 3);
  addUnit(map, 'phoenicianTrireme', 'coalition', 5, 3);
  // Historical v19 contract remains loadable; v20 sailing tests are in naval-ram.test.mjs.
  return startGame(map,{rulesVersion:19});
}

test('Salamis has four commanders, staged Persian squadrons, and preserves them in exported maps', () => {
  const map = salamisMap();
  assert.equal(map.units.filter(u => u.team === 'egypt').length, 20);
  assert.equal(map.units.filter(u => u.team === 'coalition').length, 18);
  assert.deepEqual(map.reinforcements.map(w => w.units.length), [6, 6]);
  assert.equal(map.units.filter(u => u.commander).length, 4);
  assert.equal(importMap(exportMap(map)).units.filter(u => u.commander).length, 4);
  assert.equal(startGame(map).weather.clouds.length, 2);
});

test('Salamis clouds conceal enemy ships for both sides, slow movement, and cap effective morale', () => {
  const s = salamisDuel(), greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  persian.c = 6;
  s.weather.clouds = [{ c: 2, r: 3, radius: 1 }];
  recomputeFog(s);
  assert.equal(greek.cloudCovered, true);
  assert.equal(moraleOf(greek), .9);
  assert.equal(reachable(s, greek).has('2,6'), false);
  assert.equal(visibleTo(s, 'coalition', 2, 3), false);
  s.weather.clouds = [{ c: 6, r: 3, radius: 1 }];
  recomputeFog(s);
  assert.equal(visibleTo(s, 'egypt', 6, 3), false);
  assert.equal(persian.cloudCovered, true);
  assert.equal(moraleOf(persian), .9);
  s.weather.clouds = [];
  recomputeFog(s);
  assert.equal(visibleTo(s, 'egypt', 6, 3), true);
  assert.equal(reachable(s, greek).has('2,6'), true);
  assert.equal(moraleOf(greek), 1);
  assert.equal(moraleOf(persian), 1);
});

test('Salamis wind changes after both sides act and carries clouds one hex', () => {
  const s = startGame(salamisMap()), before = { ...s.weather.clouds[0] };
  endSide(s, () => .51);
  assert.equal(s.weather.windDir, 0);
  endSide(s, () => .51);
  assert.equal(s.turn, 2);
  assert.equal(s.weather.windDir, 3);
  assert.deepEqual({ c: s.weather.clouds[0].c, r: s.weather.clouds[0].r }, neighbors(before.c, before.r)[3]);
});

test('Salamis bow-to-broadside hit deals exactly three times boarding damage', () => {
  const s = salamisDuel(), greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  assert.equal(move(s, greek.id, 4, 3).ok, true);
  assert.equal(greek.facing, 0);
  const ram = attackPreview(s, greek, 5, 3);
  assert.equal(ram.ram, true);
  greek.facing = 1;
  const normal = attackPreview(s, greek, 5, 3);
  assert.equal(normal.ram, false);
  assert.equal(ram.damage, normal.damage * 3);
  greek.facing = 0;
  const result = attack(s, greek.id, 5, 3, 0);
  assert.equal(result.visual.ram, true);
  assert.equal(persian.hp, STATS.phoenicianTrireme.hp - result.unitDamage);
  assert.equal(attackPreview(s, greek, 5, 3), null);
});

test('Salamis aligned bow fire at two hexes uses ordinary ranged damage', () => {
  const s = salamisDuel(), greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  persian.c = 4; persian.facing = 2; greek.facing = 0;
  recomputeFog(s);
  const preview = attackPreview(s, greek, persian.c, persian.r);
  assert.equal(preview.melee, false);
  assert.equal(preview.ram, false);
  greek.facing = 1;
  assert.equal(attackPreview(s, greek, persian.c, persian.r).damage, preview.damage);
  greek.facing = 0;
  const ammo = greek.ammo, hit = attack(s, greek.id, persian.c, persian.r, 0);
  assert.equal(hit.visual.melee, false);
  assert.equal(hit.visual.ram, false);
  assert.equal(hit.unitDamage, preview.damage);
  assert.equal(greek.ammo, ammo - 1);
});

test('Salamis supports all six bow directions, and enemy bow or stern takes normal damage', () => {
  const s = salamisDuel(), greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  for (let dir = 0; dir < 6; dir++) {
    const adjacent = neighbors(greek.c, greek.r)[dir];
    persian.c = adjacent.c; persian.r = adjacent.r;
    greek.facing = dir;
    const incoming = (dir + 3) % 6;
    persian.facing = (incoming + 1) % 6;
    recomputeFog(s);
    const broadside = attackPreview(s, greek, persian.c, persian.r);
    assert.equal(broadside?.ram, true, `direction ${dir}`);
    persian.facing = incoming;
    const bow = attackPreview(s, greek, persian.c, persian.r);
    assert.equal(bow?.ram, false, `bow direction ${dir}`);
    assert.equal(broadside.damage, bow.damage * 3);
    persian.facing = (incoming + 3) % 6;
    assert.equal(attackPreview(s, greek, persian.c, persian.r)?.ram, false, `stern direction ${dir}`);
  }
});

test('turning costs one action and can align a bow-to-broadside hit without movement', () => {
  const s = salamisDuel(), greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  persian.c = 3; recomputeFog(s);
  assert.equal(attackPreview(s, greek, 3, 3).ram, false);
  assert.equal(turnShip(s, greek.id, 0).ok, true);
  assert.equal(greek.actionsLeft, 1);
  assert.equal(greek.facing, 0);
  assert.equal(turnShip(s, greek.id, 0).ok, false);
  assert.equal(greek.actionsLeft, 1);
  assert.equal(attackPreview(s, greek, 3, 3).ram, true);
  assert.equal(attack(s, greek.id, 3, 3, 0).ok, true);
  assert.equal(greek.actionsLeft, 0);
  assert.equal(turnShip(s, greek.id, 1).ok, false);

  const ai = salamisDuel();
  const actions = aiTurn(ai, () => 0);
  assert.ok(actions.some(a => a.type === 'move'));
  assert.ok(actions.some(a => a.type === 'attack' && a.result.visual.ram));
});

test('computer ship turns its bow before striking an exposed broadside', () => {
  const s = salamisDuel();
  const greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  persian.c = 3;
  greek.facing = 1;
  persian.facing = 2;
  recomputeFog(s);
  const orders = aiTurn(s, () => 0);
  assert.deepEqual([orders[0]?.type, orders[0]?.facing], ['turnShip', 0]);
  assert.ok(orders.some(a => a.type === 'attack' && a.result.visual.ram));
});

test('Persian bow striking a Greek broadside receives the same threefold bonus', () => {
  const s = salamisDuel(), greek = mobileAt(s.map, 2, 3), persian = mobileAt(s.map, 5, 3);
  greek.facing = 2; s.side = 'coalition'; recomputeFog(s);
  assert.equal(move(s, persian.id, 3, 3).ok, true);
  assert.equal(persian.facing, 3);
  const ram = attackPreview(s, persian, greek.c, greek.r);
  assert.equal(ram.ram, true);
  greek.facing = 0;
  const normal = attackPreview(s, persian, greek.c, greek.r);
  assert.equal(normal.ram, false);
  assert.equal(ram.damage, normal.damage * 3);
  greek.facing = 2;
  const hit = attack(s, persian.id, greek.c, greek.r, 0);
  assert.equal(hit.visual.ram, true);
  assert.equal(hit.unitDamage, ram.damage);
});

test('Salamis loss and bay-control victories do not require a commander to survive', () => {
  const losses = startGame(salamisMap());
  losses.map.units.filter(u => u.team === 'coalition').forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(losses), null);
  for (let i = 0; i < 5; i++) endSide(losses, () => .1);
  losses.map.units.filter(u => u.team === 'coalition' && u.hp > 0).slice(0, 5)
    .forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(losses), 'egypt');
  const bay = startGame(salamisMap()), ships = bay.map.units.filter(u => u.team === 'coalition').slice(0, 4);
  ships.forEach((u, i) => { u.c = 22 + i; u.r = 20; });
  bay.side = 'coalition'; recomputeFog(bay);
  endSide(bay, () => .1);
  assert.equal(bay.salamisBayThreat, true);
  assert.equal(bay.over, false);
  endSide(bay, () => .1);
  assert.equal(bay.winner, 'coalition');
  assert.equal(bay.victoryReason, 'salamis_bay');
});

test('Gaugamela starts with opposed commanders, unformed phalanxes, chariots and reserve elephants', () => {
  const map = gaugamelaMap();
  assert.equal(map.cols, 88);
  assert.equal(map.rows, 52);
  assert.equal(map.units.filter(u => u.team === 'egypt').length, 30);
  assert.equal(map.units.filter(u => u.team === 'coalition').length, 44);
  assert.equal(map.units.filter(u => u.kind === 'phalangite' && !u.formed && u.facing === 0).length, 12);
  assert.equal(map.units.filter(u => u.kind === 'scythedChariot').length, 3);
  assert.equal(map.units.filter(u => u.kind === 'warElephant' && !u.uncontrolled).length, 2);
  const restored = importMap(exportMap(map));
  assert.equal(restored.victory.mode, 'gaugamela');
  assert.equal(restored.units.filter(u => u.kind === 'phalangite' && !u.formed).length, 12);
  assert.equal(restored.units.filter(u => u.kind === 'warElephant').length, 2);
});

test('threatened computer commander retreats and nearby guards intercept at Gaugamela', () => {
  const s = startGame(gaugamelaMap());
  s.side = 'coalition';
  const darius = s.map.units.find(u => u.kind === 'hittiteKing');
  const enemy = s.map.units.find(u => u.kind === 'companionCavalry');
  const guardIds = new Set(s.map.units.filter(u => u.kind === 'guard' && u.team === 'coalition' &&
    distance(u, darius) <= 3).map(u => u.id));
  enemy.c = 64; enemy.r = 25;
  recomputeFog(s);
  const before = distance(darius, enemy);
  const actions = aiTurn(s, () => 0.5);
  assert.ok(distance(darius, enemy) > before);
  assert.ok(actions.some(a => a.id === darius.id && a.type === 'move'));
  assert.ok(actions.every(a => a.id !== darius.id || a.type !== 'attack'));
  assert.ok(actions.some(a => guardIds.has(a.id) && ['move', 'attack'].includes(a.type)));
});

test('trapped computer commander holds fire while guards deal with the threat', () => {
  const m = newMap(10, 8);
  addUnit(m, 'pharaoh', 'egypt', 3, 3);
  for (const p of neighbors(3, 3)) addUnit(m, 'guard', 'egypt', p.c, p.r);
  addUnit(m, 'heavy', 'coalition', 5, 3);
  const s = startGame(m);
  const commander = s.map.units.find(u => u.kind === 'pharaoh');
  const actions = aiTurn(s, () => 0.5);
  assert.ok(actions.every(a => a.id !== commander.id));
  assert.ok(actions.some(a => s.map.units.find(u => u.id === a.id)?.kind === 'guard'));
});

test('later scenarios strengthen both armies while keeping earlier land units and elephant panic distinct', () => {
  const bronze = megiddoMap(), later = gaugamelaMap();
  const bronzeArcher = bronze.units.find(u => u.kind === 'archer');
  for (const ironMap of [qarqarMap(), babylonMap()]) {
    for (const team of ['egypt', 'coalition']) {
      const ironArcher = ironMap.units.find(u => u.kind === 'archer' && u.team === team);
      assert.equal(ironArcher.hp, bronzeArcher.hp + 60);
      assert.equal(unitArmor(ironMap, ironArcher), unitArmor(bronze, bronzeArcher) + 1);
      assert.equal(rangedPower(ironMap, ironArcher), rangedPower(bronze, bronzeArcher) + 1.5);
    }
  }
  const macedonianArcher = later.units.find(u => u.kind === 'archer' && u.team === 'egypt');
  const persianArcher = later.units.find(u => u.kind === 'archer' && u.team === 'coalition');
  for (const archer of [macedonianArcher, persianArcher]) {
    assert.equal(archer.hp, bronzeArcher.hp + 60);
    assert.equal(unitArmor(later, archer), unitArmor(bronze, bronzeArcher) + 1);
    assert.equal(meleePower(archer, later), meleePower(bronzeArcher, bronze) + 1.5);
    assert.equal(rangedPower(later, archer), rangedPower(bronze, bronzeArcher) + 1.5);
  }
  const elephant = later.units.find(u => u.kind === 'warElephant');
  assert.equal(STATS.warElephant.hp, 320);
  assert.equal(STATS.warElephant.melee, 8);
  assert.equal(unitMaxHp(later, elephant), STATS.warElephant.hp);
  assert.equal(unitArmor(later, elephant), STATS.warElephant.armor);
  elephant.uncontrolled = true;
  assert.equal(unitArmor(later, elephant), 0);
  assert.equal(meleePower(elephant, later), 3);
  const phalanx = later.units.find(u => u.kind === 'phalangite');
  assert.equal(phalanx.hp, 160);
  assert.equal(phalanx.formed, false);
  phalanx.formed = true;
  assert.equal(unitArmor(later, phalanx), 3);
  assert.equal(meleePower(phalanx, later), 5);
  const victory = startGame(later);
  const darius = victory.map.units.find(u => u.kind === 'hittiteKing');
  assert.equal(darius.hp, 140);
  darius.hp = 70;
  assert.equal(checkVictory(victory), 'egypt');
  assert.equal(victory.victoryReason, 'gaugamela_darius_retreat');

  const salamis = salamisMap();
  for (const ship of salamis.units.filter(u => u.kind.endsWith('Trireme'))) {
    assert.equal(ship.hp, STATS[ship.kind].hp);
    assert.ok(STATS[ship.kind].armor >= 2);
    assert.ok(STATS[ship.kind].melee >= 4.5);
  }
});

test('an iron-age archer survives two direct hits from an elite guard in one turn', () => {
  const map = newMap(8, 4);
  map.scenarioId = 'gaugamela';
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'guard', 'egypt', 2, 2);
  addUnit(map, 'archer', 'coalition', 3, 2);
  const battle = startGame(map);
  const guard = mobileAt(battle.map, 2, 2);
  const archer = mobileAt(battle.map, 3, 2);
  assert.equal(archer.hp, 120);
  assert.equal(attack(battle, guard.id, 3, 2, 0).hit, true);
  assert.equal(attack(battle, guard.id, 3, 2, 0).hit, true);
  assert.equal(archer.hp, 10);
  assert.equal(battle.over, false);
});

test('formed phalanx has strong frontal defense, a vulnerable rear and only one move per turn', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'phalangite', 'egypt', 4, 3);
  addUnit(map, 'light', 'coalition', 5, 3);
  addUnit(map, 'light', 'coalition', 3, 3);
  const s = startGame(map), phalanx = mobileAt(s.map, 4, 3);
  const front = mobileAt(s.map, 5, 3), rear = mobileAt(s.map, 3, 3);
  assert.equal(setPhalanxMode(s, phalanx.id, true).ok, true);
  s.side = 'coalition';
  const frontalDamage = attackPreview(s, front, 4, 3).damage;
  const rearDamage = attackPreview(s, rear, 4, 3).damage;
  assert.ok(rearDamage > frontalDamage);
  s.side = 'egypt';
  assert.ok(attackPreview(s, phalanx, 5, 3));
  assert.equal(attackPreview(s, phalanx, 3, 3), null);
  assert.equal(turnPhalanx(s, phalanx.id, 3).ok, true);
  assert.ok(attackPreview(s, phalanx, 3, 3) === null); // Turning spent the last action.

  const walking = newMap(12, 8);
  addUnit(walking, 'pharaoh', 'egypt', 0, 0);
  addUnit(walking, 'phalangite', 'egypt', 4, 3);
  addUnit(walking, 'light', 'coalition', 10, 3);
  const march = startGame(walking), unit = mobileAt(march.map, 4, 3);
  assert.equal(setPhalanxMode(march, unit.id, true).ok, true);
  assert.equal(move(march, unit.id, 5, 3).ok, true);
  assert.equal(reachable(march, unit).size, 0);
});

test('phalanx action mode attacks and defends like light infantry in all six directions', () => {
  for (const adjacent of neighbors(5, 4)) {
    const duel = kind => {
      const map = newMap(12, 8);
      map.scenarioId = 'gaugamela';
      addUnit(map, 'pharaoh', 'egypt', 0, 0);
      addUnit(map, kind, 'egypt', 5, 4);
      addUnit(map, 'light', 'coalition', adjacent.c, adjacent.r);
      const battle = startGame(map);
      const soldier = mobileAt(battle.map, 5, 4);
      soldier.facing = 0;
      const attackFromSoldier = attackPreview(battle, soldier, adjacent.c, adjacent.r);
      battle.side = 'coalition';
      const attacker = mobileAt(battle.map, adjacent.c, adjacent.r);
      const attackOnSoldier = attackPreview(battle, attacker, 5, 4);
      return { soldier, map: battle.map, attackFromSoldier, attackOnSoldier };
    };
    const action = duel('phalangite'), ordinary = duel('light');
    assert.equal(action.soldier.formed, false);
    assert.equal(STATS.phalangite.move, STATS.light.move);
    assert.equal(meleePower(action.soldier, action.map), meleePower(ordinary.soldier, ordinary.map));
    assert.equal(unitArmor(action.map, action.soldier), unitArmor(ordinary.map, ordinary.soldier));
    assert.deepEqual(
      [action.attackFromSoldier?.hit, action.attackFromSoldier?.damage, action.attackOnSoldier?.damage],
      [ordinary.attackFromSoldier?.hit, ordinary.attackFromSoldier?.damage, ordinary.attackOnSoldier?.damage]
    );
  }
});

test('elephant panic lowers armor and attack, blocks commands and tramples either army while fleeing', () => {
  const map = newMap(12, 8);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 3, 3);
  addUnit(map, 'light', 'egypt', 4, 4);
  addUnit(map, 'warElephant', 'coalition', 4, 3);
  addUnit(map, 'light', 'coalition', 5, 3);
  const s = startGame(map), heavy = mobileAt(s.map, 3, 3), elephant = mobileAt(s.map, 4, 3);
  const ally = mobileAt(s.map, 5, 3), enemy = mobileAt(s.map, 4, 4);
  const controlledAttack = STATS.warElephant.melee;
  const armoredDamage = attackPreview(s, heavy, 4, 3).damage;
  assert.equal(attack(s, heavy.id, 4, 3, 0, 0, 0).ok, true);
  assert.equal(elephant.uncontrolled, true);
  assert.equal(elephant.actionsLeft, 0);
  assert.ok(STATS.warElephant.armor > 0 && controlledAttack > 2);
  assert.ok(attackPreview(s, heavy, 4, 3).damage > armoredDamage);
  s.side = 'coalition';
  assert.equal(move(s, elephant.id, 5, 2).ok, false);
  assert.equal(attackPreview(s, elephant, heavy.c, heavy.r), null);
  const allyHp = ally.hp, enemyHp = enemy.hp;
  const events = moveUncontrolledElephants(s, () => 0);
  assert.ok(events.some(e => e.type === 'trample' && e.victimId === ally.id));
  assert.ok(events.some(e => e.type === 'trample' && e.victimId === enemy.id));
  assert.ok(ally.hp < allyHp && enemy.hp < enemyHp);
  assert.ok(events.some(e => e.type === 'elephantFlee'));
});

test('every scenario elephant has stronger health and attack, with high panic risk only after severe losses', () => {
  for (const map of [gaugamelaMap(), zamaMap()]) {
    const elephants = map.units.filter(u => u.kind === 'warElephant');
    assert.ok(elephants.length > 0);
    assert.ok(elephants.every(u => u.hp === 320 && meleePower(u, map) === 8));
    const elephant = elephants[0];
    const attacker = map.units.find(u => u.team !== elephant.team && u.kind !== 'fort');
    elephant.hp = 161;
    assert.equal(elephantPanicChance(map, attacker, elephant), 0.05);
    elephant.hp = 160;
    assert.equal(elephantPanicChance(map, attacker, elephant), 0.15);
    elephant.hp = 81;
    assert.equal(elephantPanicChance(map, attacker, elephant), 0.15);
    elephant.hp = 80;
    assert.equal(elephantPanicChance(map, attacker, elephant), 0.55);
  }
  const zama = zamaMap(), elephant = zama.units.find(u => u.kind === 'warElephant');
  const velites = zama.units.find(u => u.kind === 'romanVelites');
  elephant.hp = 320;
  assert.equal(elephantPanicChance(zama, velites, elephant), 0.15);
  elephant.hp = 80;
  assert.equal(elephantPanicChance(zama, velites, elephant), 0.65);

  const map = newMap(10, 6);
  addUnit(map, 'pharaoh', 'egypt', 0, 0);
  addUnit(map, 'heavy', 'egypt', 3, 3);
  addUnit(map, 'warElephant', 'coalition', 4, 3);
  const s = startGame(map), heavy = mobileAt(s.map, 3, 3), target = mobileAt(s.map, 4, 3);
  attack(s, heavy.id, 4, 3, 0, 0, 0.10);
  assert.equal(target.uncontrolled, false);
  target.hp = 80;
  attack(s, heavy.id, 4, 3, 0, 0, 0.10);
  assert.equal(target.uncontrolled, true);
});

test('Issus uses a continuous coastal river and road, opposed historical wings, and no later Gaugamela equipment', () => {
  const map = issusMap();
  assert.equal(map.victory.mode, 'issus');
  assert.equal(map.units.filter(u => u.team === 'egypt').length, 30);
  assert.equal(map.units.filter(u => u.team === 'coalition').length, 44);
  assert.equal(terrainComponents(map, TERRAIN.ROAD).length, 1);
  assert.equal(terrainComponents(map, TERRAIN.RIVER).length, 1);
  assert.equal(tile(map, 8, 24).terrain, TERRAIN.SEA);
  assert.ok(tile(map, 78, 24).terrain & TERRAIN.MOUNTAIN);
  assert.equal(tile(map, 43, 24).terrain & (TERRAIN.RIVER | TERRAIN.ROAD), TERRAIN.RIVER | TERRAIN.ROAD);
  assert.equal(tile(map, 55, 24).terrain, TERRAIN.RIVER);
  const fordColumns = Array.from({ length: 60 }, (_, i) => i + 13)
    .filter(c => (tile(map, c, 24).terrain & (TERRAIN.RIVER | TERRAIN.ROAD)) === (TERRAIN.RIVER | TERRAIN.ROAD));
  assert.deepEqual(fordColumns, [18,19,20,21,22,39,40,41,42,43,63,64,65]);
  assert.ok(map.units.every(u => !['warElephant', 'scythedChariot'].includes(u.kind)));
  assert.ok(map.units.filter(u => u.kind === 'phalangite').every(u => !u.formed && u.facing === 2));
  assert.ok(map.units.filter(u => u.team === 'coalition' && u.kind === 'cavalry').every(u => u.c < 30));
  assert.ok(map.units.filter(u => u.team === 'egypt' && u.kind === 'companionCavalry').every(u => u.c >= 60));
  assert.equal(map.reinforcements.length, 0);
  assert.equal(map.recruitment, null);
  const restored = importMap(exportMap(map));
  assert.equal(restored.victory.mode, 'issus');
  assert.equal(restored.units.filter(u => u.kind === 'phalangite' && !u.formed && u.facing === 2).length, 11);
});

test('Issus resolves Darius withdrawal, Alexander death and phalanx collapse for either player', () => {
  const dariusRetreat = startGame(issusMap());
  const darius = dariusRetreat.map.units.find(u => u.kind === 'hittiteKing');
  assert.equal(darius.hp, 140);
  darius.hp = 70;
  assert.equal(checkVictory(dariusRetreat), 'egypt');
  assert.equal(dariusRetreat.victoryReason, 'issus_darius_retreat');

  const alexanderLoss = startGame(issusMap());
  alexanderLoss.map.units.find(u => u.kind === 'pharaoh').hp = 0;
  assert.equal(checkVictory(alexanderLoss), 'coalition');
  assert.equal(alexanderLoss.victoryReason, 'issus_alexander');

  const phalanxLoss = startGame(issusMap());
  phalanxLoss.map.units.filter(u => u.kind === 'phalangite')
    .slice(0, phalanxLoss.map.victory.phalanxLosses).forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(phalanxLoss), 'coalition');
  assert.equal(phalanxLoss.victoryReason, 'issus_phalanx');
});

test('Tyre has one wide three-column mole, a smaller defending army and later naval support', () => {
  const map = tyreMap();
  assert.equal(map.victory.mode, 'tyre');
  assert.equal(tile(map, 23, 19).terrain, TERRAIN.SEA);
  assert.equal(tile(map, 31, 19).terrain, TERRAIN.ROAD);
  assert.equal(nextMoleCell(map).c, 23);
  assert.deepEqual(moleLanes(map).map(lane => lane.length), [17, 18, 18]);
  assert.deepEqual(nextMoleCells(map).map(({ c, r }) => [c, r]), [[23, 19], [23, 18], [23, 20]]);
  assert.ok([18, 19, 20].every(r => tile(map, 23, r).terrain === TERRAIN.SEA));
  assert.ok([18, 19, 20].every(r => tile(map, 22, r).terrain === TERRAIN.ROAD));
  assert.equal(map.units.filter(u => u.team === 'egypt' && u.kind !== 'fort' && !['alliedTrireme', 'siegeGalley', 'transport'].includes(u.kind)).length, 29);
  assert.equal(map.units.filter(u => u.team === 'coalition' && u.kind !== 'fort' && !['phoenicianTrireme', 'imperialTrireme'].includes(u.kind)).length, 22);
  assert.ok(map.units.filter(u => u.kind === 'fort' && u.cityId === '推罗城墙').length >= 40);
  assert.ok(map.units.some(u => u.team === 'coalition' && u.kind === 'phoenicianTrireme'));
  assert.ok(map.reinforcements.some(w => w.turn === 4 && w.units.some(u => u.kind === 'siegeGalley')));
  assert.deepEqual(importMap(exportMap(map)).victory.moles.map(lane => lane.length), [17, 18, 18]);
  const oldSave = exportMap(map);
  oldSave.victory = { ...oldSave.victory, mole: oldSave.victory.moles[0] };
  delete oldSave.victory.moles;
  assert.equal(moleLanes(importMap(oldSave)).length, 1);
});

test('an adjacent Macedonian engineer spends one action to extend the Tyre mole', () => {
  const s = startGame(tyreMap()), engineer = mobileAt(s.map, 21, 19);
  assert.equal(unitMaxHp(s.map, engineer), 60);
  assert.equal(unitArmor(s.map, engineer), 0);
  assert.equal(meleePower(engineer, s.map), 0);
  assert.equal(buildMole(s, engineer.id).ok, false);
  assert.equal(move(s, engineer.id, 22, 19).ok, true);
  const result = buildMole(s, engineer.id);
  assert.equal(result.ok, true);
  assert.equal(engineer.actionsLeft, 0);
  assert.equal(tile(s.map, 23, 19).terrain, TERRAIN.ROAD);
  assert.equal(nextMoleCell(s.map).c, 24);
  assert.equal(importMap(exportMap(s.map)).terrain[index(s.map, 23, 19)], TERRAIN.ROAD);
});

test('Tyre engineers cannot attack but remain vulnerable to enemy infantry', () => {
  const s = startGame(tyreMap()), engineer = mobileAt(s.map, 21, 19);
  const defender = s.map.units.find(u => u.team === 'coalition' && u.kind === 'heavy');
  defender.c = 22; defender.r = 19;
  recomputeFog(s);
  assert.equal(attackPreview(s, engineer, defender.c, defender.r), null);
  assert.equal(attack(s, engineer.id, defender.c, defender.r, 0).ok, false);
  s.side = 'coalition';
  assert.ok(attackPreview(s, defender, engineer.c, engineer.r));
  const hit = attack(s, defender.id, engineer.c, engineer.r, 0);
  assert.equal(hit.ok, true);
  assert.ok(hit.unitDamage > 0);
});

test('all three Tyre moles can be built independently and reach the island', () => {
  const s = startGame(tyreMap());
  const engineers = s.map.units.filter(u => u.kind === 'engineer');
  assert.equal(engineers.length, 3);
  for (const lane of moleLanes(s.map)) {
    const row = lane[0][1], engineer = engineers.find(u => u.r === row);
    assert.ok(engineer);
    for (const [c, r] of lane.slice(9)) {
      engineer.c = c - 1;
      engineer.actionsLeft = 1;
      assert.equal(buildMole(s, engineer.id, c, r).ok, true, `failed to build ${c},${r}`);
      assert.equal(tile(s.map, c, r).terrain, TERRAIN.ROAD);
    }
    const [endC, endR] = lane.at(-1);
    assert.equal(tile(s.map, endC + 1, endR).terrain === TERRAIN.SEA, false);
  }
  assert.deepEqual(nextMoleCells(s.map), []);
});

test('Macedonian computer engineers advance all three Tyre moles in one turn', () => {
  const s = startGame(tyreMap());
  for (const u of s.map.units.filter(u => u.team === 'egypt')) {
    if (u.kind === 'engineer') { u.c = 22; u.actionsLeft = 1; }
    else u.actionsLeft = 0;
  }
  const actions = aiTurn(s, () => .99);
  assert.deepEqual(actions.filter(a => a.type === 'buildMole').map(a => a.cell.r).sort(), [18, 19, 20]);
  assert.deepEqual(nextMoleCells(s.map).map(p => p.c), [24, 24, 24]);
});

test('Tyre ram attacks an occupied adjacent wall without an escort', () => {
  const map = tyreMap();
  assert.equal(addUnit(map, 'siegeRam', 'egypt', 32, 19), true);
  assert.equal(addUnit(map, 'archer', 'coalition', 33, 19), true);
  const s = startGame(map), ram = mobileAt(s.map, 32, 19), wall = fortAt(s.map, 33, 19);
  assert.equal(attackPreview(s, ram, 33, 19)?.target.id, wall.id);
  assert.equal(attack(s, ram.id, 33, 19, 0).ok, true);
  assert.ok(wall.hp < FORT_HP[3]);
  assert.equal(mobileAt(s.map, 33, 19).hp, unitMaxHp(s.map, { kind: 'archer' }));
});

test('Tyre naval artillery reaches the wall from open sea and victory depends on the citadel or deadline', () => {
  const map = tyreMap();
  assert.equal(addUnit(map, 'siegeGalley', 'egypt', 39, 10), true);
  const s = startGame(map), ship = mobileAt(s.map, 39, 10), wall = fortAt(s.map, 41, 13);
  const preview = attackPreview(s, ship, wall.c, wall.r);
  assert.equal(distance(ship, wall), 4);
  assert.ok(preview && !preview.melee && preview.damage >= 100);
  assert.equal(attack(s, ship.id, wall.c, wall.r, 0).ok, true);
  assert.ok(wall.hp < FORT_HP[3]);
  assert.equal(s.over, false);
  const attacker = s.map.units.find(u => u.kind === 'guard' && u.team === 'egypt');
  attacker.c = s.map.victory.capture.c; attacker.r = s.map.victory.capture.r;
  assert.equal(checkVictory(s), 'egypt');
  assert.equal(s.victoryReason, 'tyre_capture');
  const defense = startGame(tyreMap());
  defense.side = 'coalition'; defense.turn = 24;
  endSide(defense);
  assert.equal(defense.winner, 'coalition');
  assert.equal(defense.victoryReason, 'tyre_hold');
});

test('Tyrian warship rams the siege galley broadside for threefold melee damage', () => {
  const map = tyreMap();
  assert.equal(addUnit(map, 'siegeGalley', 'egypt', 36, 7), true);
  const s = startGame(map), warship = mobileAt(s.map, 35, 7), galley = mobileAt(s.map, 36, 7);
  s.side = 'coalition';
  warship.facing = 0;
  galley.facing = 1;
  recomputeFog(s);
  const broadside = attackPreview(s, warship, galley.c, galley.r);
  assert.equal(broadside?.ram, true);
  assert.equal(broadside.melee, true);
  galley.facing = 0;
  const bow = attackPreview(s, warship, galley.c, galley.r);
  assert.equal(bow?.ram, false);
  assert.equal(broadside.damage, bow.damage * 3);
  galley.facing = 1;
  const hit = attack(s, warship.id, galley.c, galley.r, 0);
  assert.equal(hit.visual.ram, true);
  assert.equal(hit.unitDamage, broadside.damage);
});

test('Tyre siege galley deals ordinary melee damage regardless of facing', () => {
  const map = tyreMap();
  assert.equal(addUnit(map, 'siegeGalley', 'egypt', 36, 7), true);
  const s = startGame(map), warship = mobileAt(s.map, 35, 7), galley = mobileAt(s.map, 36, 7);
  s.side = 'egypt';
  galley.facing = 3;
  warship.facing = 1;
  recomputeFog(s);
  const broadside = attackPreview(s, galley, warship.c, warship.r);
  assert.equal(broadside?.melee, true);
  assert.equal(broadside.ram, false);
  warship.facing = 0;
  const bow = attackPreview(s, galley, warship.c, warship.r);
  assert.equal(bow?.ram, false);
  assert.equal(broadside.damage, bow.damage);
  warship.facing = 1;
  const hit = attack(s, galley.id, warship.c, warship.r, 0);
  assert.equal(hit.visual.ram, false);
  assert.equal(hit.unitDamage, broadside.damage);
});

test('Cannae starts with historically shaped arms, connected camp roads and fixed forces', () => {
  const m = cannaeMap(), restored = importMap(exportMap(m));
  assert.equal(m.cols, 96);
  assert.equal(m.rows, 60);
  assert.equal(restored.victory.mode, 'cannae');
  assert.equal(m.units.filter(u => u.team === 'egypt' && !['fort', 'paullus', 'varro'].includes(u.kind)).length, 58);
  assert.equal(m.units.filter(u => u.team === 'coalition' && !['fort', 'hannibal'].includes(u.kind)).length, 39);
  assert.equal(m.units.filter(u => u.kind === 'romanHorse' || u.kind === 'romanAlliedHorse').length, 6);
  assert.equal(m.units.filter(u => u.kind === 'punicHeavyHorse').length, 6);
  assert.equal(m.units.filter(u => u.kind === 'numidianHorse').length, 6);
  assert.ok(m.units.filter(u => u.kind === 'punicSkirmisher').every(u => u.r === 39));
  assert.ok(m.units.filter(u => u.kind === 'punicSkirmisher').every(u =>
    u.r > Math.max(...m.units.filter(v => ['gaulInfantry', 'iberianInfantry'].includes(v.kind)).map(v => v.r))));
  assert.equal(m.victory.punicLosses, 30);
  assert.ok(m.units.some(u => u.kind === 'hannibal'));
  assert.ok(m.units.some(u => u.kind === 'paullus'));
  assert.ok(m.units.some(u => u.kind === 'varro'));
  assert.equal(m.recruitment, null);
  assert.deepEqual(m.reinforcements, []);
  assert.ok(m.terrain.some(t => t & TERRAIN.RIVER));
  assert.ok(m.terrain.some(t => t & TERRAIN.ROAD));
  assert.equal(startGame(restored).side, 'egypt');
});

test('Cannae computer keeps Punic skirmishers behind the center on the opening turn', () => {
  const s = startGame(cannaeMap());
  aiTurn(s, () => 0.35);
  aiTurn(s, () => 0.35);
  assert.ok(s.map.units.filter(u => u.kind === 'punicSkirmisher').every(u => u.r === 39));
});

test('Cannae center withdraws once per round and its next melee hit is reduced', () => {
  const s = startGame(cannaeMap()), gaul = mobileAt(s.map, 33, 37);
  s.side = 'coalition';
  const result = withdrawCenter(s, gaul.id);
  assert.equal(result.ok, true);
  assert.equal(gaul.r, 38);
  assert.equal(gaul.actionsLeft, 1);
  assert.equal(withdrawCenter(s, gaul.id).ok, false);
  const roman = mobileAt(s.map, 30, 27);
  roman.c = gaul.c; roman.r = gaul.r - 1;
  s.side = 'egypt'; recomputeFog(s);
  const guarded = attackPreview(s, roman, gaul.c, gaul.r);
  gaul.withdrawalGuard = false;
  const unguarded = attackPreview(s, roman, gaul.c, gaul.r);
  assert.ok(guarded.damage < unguarded.damage);
  gaul.withdrawalGuard = true;
  attack(s, roman.id, gaul.c, gaul.r, 0);
  assert.equal(gaul.withdrawalGuard, false);
});

test('Cannae Roman line turns and its front is stronger than its rear', () => {
  const s = startGame(cannaeMap()), roman = mobileAt(s.map, 30, 27);
  assert.equal(roman.formed, false);
  roman.formed = true;
  const punic = s.map.units.find(u => u.kind === 'punicHeavyHorse');
  punic.c = 30; punic.r = 28; s.side = 'coalition'; recomputeFog(s);
  const front = attackPreview(s, punic, roman.c, roman.r);
  roman.facing = 1;
  const rear = attackPreview(s, punic, roman.c, roman.r);
  assert.ok(front.damage < rear.damage);
  s.side = 'egypt';
  assert.equal(turnRomanLine(s, roman.id, 4).ok, true);
  assert.equal(roman.actionsLeft, 1);
  assert.equal(turnRomanLine(s, roman.id, 4).ok, false);
});

test('Cannae commanders affect morale without instant victory, and either side can win by losses', () => {
  const roman = startGame(cannaeMap());
  roman.map.units.find(u => u.kind === 'paullus').hp = 0;
  assert.equal(checkVictory(roman), null);
  const romanTarget = roman.map.victory.punicLosses;
  roman.map.units.filter(u => u.team === 'coalition' && !['fort', 'hannibal'].includes(u.kind)).slice(0, romanTarget - 1)
    .forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(roman), null);
  roman.map.units.filter(u => u.team === 'coalition' && !['fort', 'hannibal'].includes(u.kind))[romanTarget - 1].hp = 0;
  assert.equal(checkVictory(roman), 'egypt');

  const punic = startGame(cannaeMap());
  punic.map.units.filter(u => u.team === 'egypt' && !['fort', 'paullus', 'varro'].includes(u.kind))
    .slice(0, punic.map.victory.romanLosses)
    .forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(punic), 'coalition');

  const deadline = startGame(cannaeMap());
  deadline.turn = 20; deadline.side = 'coalition';
  endSide(deadline);
  assert.equal(deadline.over, true);
  assert.equal(deadline.winner, null);
  assert.equal(deadline.victoryReason, 'cannae_draw');
});

test('Cannae morale pressure needs both Punic wings and stops when one wing is driven off', () => {
  const s = startGame(cannaeMap());
  const roman = mobileAt(s.map, 35, 27);
  s.map.units.filter(u => u.kind === 'punicHeavyHorse').slice(0, 3)
    .forEach((u, i) => { u.c = 20 + i; u.r = 30; });
  s.map.units.filter(u => u.kind === 'numidianHorse').slice(0, 3)
    .forEach((u, i) => { u.c = 57 + i; u.r = 30; });
  endSide(s);
  endSide(s);
  assert.equal(roman.morale, 0.89);
  const firstPressure = roman.morale;
  endSide(s);
  endSide(s);
  assert.ok(roman.morale >= firstPressure);
  const rested = roman.morale;
  for (const u of s.map.units.filter(u => u.team === 'coalition' && u.c > 47 && u.r <= 31)) u.hp = 0;
  endSide(s);
  endSide(s);
  assert.ok(roman.morale >= rested);
});

test('Zama has the three Roman lines, elephant lanes, three Punic infantry lines and balanced fixed armies', () => {
  const m = zamaMap(), restored = importMap(exportMap(m));
  assert.equal(restored.victory.mode, 'zama');
  assert.equal(m.recruitment, null);
  assert.deepEqual(m.reinforcements, []);
  const combat = team => m.units.filter(u => u.team === team && !['scipio', 'masinissa', 'hannibal'].includes(u.kind));
  assert.equal(combat('egypt').length, 53);
  assert.equal(combat('coalition').length, 53);
  assert.equal(m.units.filter(u => u.kind === 'warElephant').length, 9);
  assert.equal(m.units.filter(u => u.kind === 'masinissaHorse').length, 8);
  assert.equal(m.units.filter(u => u.kind === 'zamaVeteran').length, 12);
  assert.ok(m.units.filter(u => u.kind === 'warElephant').every(elephant =>
    !m.units.some(u => u.kind === 'romanHastati' && u.c === elephant.c)));
  assert.ok(m.terrain.every(t => t === TERRAIN.PLAIN));
  assert.equal(unitName(m, m.units.find(u => u.kind === 'warElephant')), '迦太基战象');
});

test('Roman infantry can change formation and choose its facing with one action', () => {
  const s = startGame(zamaMap()), roman = mobileAt(s.map, 27, 26);
  assert.equal(roman.formed, false);
  assert.equal(unitArmor(s.map, roman), 1);
  assert.ok([...reachable(s, roman).values()].some(p => p.steps === 2));
  const before = roman.actionsLeft;
  assert.equal(setPhalanxMode(s, roman.id, true, 2).ok, true);
  assert.equal(roman.facing, 2);
  assert.equal(roman.actionsLeft, before - 1);
  assert.equal(turnRomanLine(s, roman.id, 4).ok, true);
  assert.equal(roman.actionsLeft, 0);
});

test('Macedonian infantry also chooses facing during the formation action', () => {
  const s = startGame(gaugamelaMap()), phalanx = s.map.units.find(u => u.kind === 'phalangite');
  assert.equal(phalanx.formed, false);
  assert.equal(setPhalanxMode(s, phalanx.id, true, 3).ok, true);
  assert.equal(phalanx.facing, 3);
  assert.equal(phalanx.actionsLeft, 1);
});

test('every formable heavy infantry unit starts outside formation', () => {
  for (const makeMap of [gaugamelaMap, issusMap, tyreMap, cannaeMap, zamaMap, carthageMap, alesiaMap, pharsalusMap]) {
    const map = makeMap();
    const infantry = map.units.filter(u => ['phalangite', 'romanHastati', 'romanPrincipes',
      'romanTriarii', 'romanLegion'].includes(u.kind));
    assert.ok(infantry.length > 0, map.name);
    assert.ok(infantry.every(u => u.formed === false), map.name);
    assert.ok(startGame(map).map.units.filter(u => infantry.some(v => v.id === u.id))
      .every(u => u.formed === false), map.name);
  }
  const custom = newMap(10, 8);
  addUnit(custom, 'pharaoh', 'egypt', 1, 2);
  addUnit(custom, 'phalangite', 'egypt', 2, 2);
  addUnit(custom, 'romanLegion', 'egypt', 4, 2);
  addUnit(custom, 'heavy', 'coalition', 8, 5);
  for (const u of custom.units.filter(u => ['phalangite', 'romanLegion'].includes(u.kind))) u.formed = true;
  assert.ok(startGame(custom).map.units.filter(u => ['phalangite', 'romanLegion'].includes(u.kind))
    .every(u => u.formed === false));
});

test('Zama formed Roman infantry is stronger to the front and cannot attack backwards', () => {
  const s = startGame(zamaMap()), roman = mobileAt(s.map, 27, 26);
  assert.equal(setPhalanxMode(s, roman.id, true, roman.facing).ok, true);
  const horse = s.map.units.find(u => u.kind === 'zamaPunicHorse');
  s.side = 'coalition';
  const front = neighbors(roman.c, roman.r)[roman.facing];
  horse.c = front.c; horse.r = front.r; recomputeFog(s);
  const frontHit = attackPreview(s, horse, roman.c, roman.r);
  const back = neighbors(roman.c, roman.r)[(roman.facing + 3) % 6];
  horse.c = back.c; horse.r = back.r; recomputeFog(s);
  const rearHit = attackPreview(s, horse, roman.c, roman.r);
  assert.ok(frontHit && rearHit && rearHit.damage > frontHit.damage);
  s.side = 'egypt'; recomputeFog(s);
  assert.equal(attackPreview(s, roman, horse.c, horse.r), null);
});

test('Zama commanders do not trigger instant victory; losses and deadline decide both sides', () => {
  const s = startGame(zamaMap());
  s.map.units.find(u => u.kind === 'scipio').hp = 0;
  assert.equal(checkVictory(s), null);
  s.map.units.filter(u => u.team === 'coalition' && u.kind !== 'hannibal')
    .slice(0, s.map.victory.punicLosses)
    .forEach(u => { u.hp = 0; });
  assert.equal(checkVictory(s), 'egypt');
  const deadline = startGame(zamaMap());
  deadline.turn = 22; deadline.side = 'coalition'; endSide(deadline);
  assert.equal(deadline.victoryReason, 'zama_draw');
});

test('Carthage siege round trips its harbor, Byrsa, walls and fixed armies', () => {
  const m = carthageMap(), restored = importMap(exportMap(m));
  assert.deepEqual(restored.victory, m.victory);
  assert.equal(m.recruitment, null);
  assert.ok(m.units.some(u => u.kind === 'siegeRam' && u.team === 'egypt'));
  assert.ok(m.units.some(u => u.kind === 'siegeGalley' && u.team === 'egypt'));
  assert.ok(m.units.some(u => u.kind === 'fort' && u.cityId === '比尔萨城堡'));
  assert.equal(tile(m, 55, 33).terrain, TERRAIN.SEA);
  assert.equal(tile(m, 61, 34).terrain, TERRAIN.SEA);
  assert.equal(tile(m, 59, 31).terrain, TERRAIN.SEA);
  assert.ok(tile(m, 59, 30).terrain & TERRAIN.BEACH);
  assert.equal(unitName(m, m.units.find(u => u.kind === 'hannibal')), '哈斯德鲁巴');
  assert.equal(fortAt(m, 38, 39)?.level, 2);
  assert.equal(m.units.filter(u => u.kind === 'defenseTower').length, 2);
  assert.equal(m.units.filter(u => u.kind === 'romanLegion' && !u.aboard).length, 20);
  assert.equal(m.units.filter(u => u.kind === 'romanOnager').length, 2);
  assert.equal(m.units.filter(u => u.kind === 'romanArcher').length, 4);
  assert.equal(m.units.filter(u => ['romanHastati', 'romanPrincipes', 'romanTriarii'].includes(u.kind)).length, 0);
  assert.equal(m.units.filter(u => u.kind === 'transport' && u.team === 'egypt').length, 2);
  assert.equal(m.units.filter(u => u.aboard).length, 4);
});

test('Carthage Roman legion can form; onager fires once from range and harbor tower cannot move', () => {
  const s = startGame(carthageMap());
  const legion = s.map.units.find(u => u.kind === 'romanLegion' && !u.aboard);
  assert.equal(legion.formed, false);
  assert.equal(setPhalanxMode(s, legion.id, true, 0).ok, true);
  assert.equal(legion.formed, true);
  assert.equal(turnRomanLine(s, legion.id, 1).ok, true);
  const onager = s.map.units.find(u => u.kind === 'romanOnager');
  onager.c = 33; onager.r = 22;
  assert.equal(attackPreview(s, onager, 38, 22)?.target.kind, 'fort');
  assert.equal(attack(s, onager.id, 38, 22, 0).ok, true);
  assert.equal(attackPreview(s, onager, 38, 22), null);
  const tower = s.map.units.find(u => u.kind === 'defenseTower');
  s.side = 'coalition';
  assert.equal(reachable(s, tower).size, 0);
  assert.equal(move(s, tower.id, tower.c + 1, tower.r).ok, false);
});

test('Carthage harbor ballista has higher durability and fires three stronger shots at ships', () => {
  const s = startGame(carthageMap());
  const tower = s.map.units.find(u => u.kind === 'defenseTower');
  const ship = s.map.units.find(u => u.kind === 'siegeGalley');
  s.side = 'coalition';
  ship.c = 63; ship.r = 33;
  assert.equal(tower.hp, 240);
  assert.equal(tower.actionsLeft, 3);
  assert.equal(attackPreview(s, tower, ship.c, ship.r)?.damage, 50);
  for (let i = 0; i < 3; i++) assert.equal(attack(s, tower.id, ship.c, ship.r, 0).ok, true);
  assert.equal(ship.hp, 80);
  assert.equal(tower.attacksUsed, 3);
  assert.equal(attackPreview(s, tower, ship.c, ship.r), null);
  assert.equal(attack(s, tower.id, ship.c, ship.r, 0).ok, false);
  endSide(s); endSide(s);
  assert.equal(tower.actionsLeft, 3);
  assert.equal(tower.attacksUsed, 0);
});

test('Carthage transport can enter the harbor and disembark onto its inner shore', () => {
  const s = startGame(carthageMap());
  const ship = s.map.units.find(u => u.kind === 'transport' && u.team === 'egypt');
  ship.c = 59; ship.r = 31;
  for (const passenger of cargoOf(s.map, ship)) { passenger.c = ship.c; passenger.r = ship.r; }
  recomputeFog(s);
  assert.equal(tile(s.map, ship.c, ship.r).terrain, TERRAIN.SEA);
  assert.equal(disembark(s, ship.id, 59, 30), true);
  assert.equal(move(s, ship.id, 58, 31).ok, true);
  assert.equal(disembark(s, ship.id, 58, 30), true);
  assert.equal(cargoOf(s.map, ship).length, 0);
});

test('Carthage Roman AI sails transports into the cleared military harbor', () => {
  const s = startGame(carthageMap());
  s.map.units = s.map.units.filter(u => u.kind === 'fort' ||
    u.team === 'egypt' && (u.kind === 'scipio' || u.kind === 'transport' || u.aboard));
  recomputeFog(s);
  const landingCells = [];
  for (let i = 0; i < 32 && !s.over; i++)
    landingCells.push(...aiTurn(s, () => 0.25).filter(a => a.type === 'disembark').map(a => a.to));
  assert.equal(carthageSeaSecured(s), true);
  assert.equal(landingCells.length, 4);
  assert.ok(landingCells.every(p => p.r === 30 && p.c >= 53 && p.c <= 59));
});

test('Rome must take the Carthage harbor before Byrsa; defenders can hold to the deadline', () => {
  const s = startGame(carthageMap());
  const roman = s.map.units.find(u => u.kind === 'romanLegion');
  s.map.units.find(u => u.kind === 'hannibal').c = 55;
  roman.c = s.map.victory.byrsa.c; roman.r = s.map.victory.byrsa.r;
  assert.equal(checkVictory(s), null);
  roman.c = s.map.victory.harbor.c; roman.r = s.map.victory.harbor.r;
  assert.equal(checkVictory(s), null);
  assert.equal(s.carthageHarborTaken, true);
  roman.c = s.map.victory.byrsa.c; roman.r = s.map.victory.byrsa.r;
  assert.equal(checkVictory(s), 'egypt');
  assert.equal(s.victoryReason, 'carthage_byrsa');
  const hold = startGame(carthageMap());
  hold.turn = hold.map.victory.turnLimit; hold.side = 'coalition'; endSide(hold);
  assert.equal(hold.winner, 'coalition');
  assert.equal(hold.victoryReason, 'carthage_hold');
});

test('Roman computer commander breaches Carthage and advances to the harbor', () => {
  const s = startGame(carthageMap());
  for (let i = 0; i < 22 && !s.over; i++) aiTurn(s, () => 0.5);
  assert.equal(s.carthageHarborTaken, true);
  assert.ok(s.map.units.some(u => u.team === 'egypt' && u.kind !== 'fort' && u.hp > 0 && u.c > 38));
});
