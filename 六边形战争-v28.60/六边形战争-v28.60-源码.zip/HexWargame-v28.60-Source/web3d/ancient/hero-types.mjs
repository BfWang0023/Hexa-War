// Independent character types sit above legacy combat-role IDs. Old maps/saves
// retain kind so victory predicates and special abilities keep their semantics.
const roles=new Set(['pharaoh','hittiteKing','hero','chinaGeneral','hannibal','paullus','varro','scipio','masinissa']);
// Explicit named command contingents from public campaign definitions; no name heuristics.
const namedCommandUnits=new Set(["亚历山大与左翼骑兵", "亚历山大所属骑兵", "伊巴密浓达所属部队", "佩洛皮达斯与圣队", "保萨尼阿斯所属部队", "克里奥姆布罗托斯所属部队", "列奥尼达斯与斯巴达三百人", "卢基乌斯·西庇阿所属军团", "埃皮塔达斯所属部队", "安提柯所属方阵", "安条克三世所属骑兵", "尼基阿斯所属部队", "弗拉米尼努斯所属军团", "德米特里所属骑兵", "托勒密四世所属骑兵", "欧迈尼斯所属骑兵", "波罗斯所属象队", "皮洛士所属骑兵", "米太亚得所属部队", "腓力二世所属方阵", "腓力五世所属方阵", "马尔多尼奥斯所属部队"]);
export function heroType(unit,scenario,map,name){
 if(!unit||!(roles.has(unit.kind)||unit.commander||namedCommandUnits.has(unit.customName)))return null;
 const title=unit.customName||name||map?.unitNames?.[`${unit.team}:${unit.kind}`]||unit.kind;
 const id=`character:${scenario||map?.scenarioId||'custom'}:${unit.team}:${title}`;
 let seed=2166136261;for(const c of id)seed=Math.imul(seed^c.codePointAt(0),16777619)>>>0;
 return {id,name:title,role:unit.kind,seed};
}
