//! 连排指挥官框架基准测试：Company（默认参数） vs Defender 冠军（当前游戏默认 AI）
//! 用法：cargo run --release --example company_test [场数]
use hex_wargame::ai;
use hex_wargame::game::{AiConfig, AiStyle, GameState};
use hex_wargame::mapdef::CustomMap;
use hex_wargame::unit::{Team, UnitKind};

// 用户指定：双方 400 招募点、每回合 +20 点（持续招募模式）；可用 --points/--per-turn 覆盖
const PER_TURN: i32 = 20;
const FAIR_POINTS: i32 = 400;
const MAX_TURNS: i32 = 40;

fn defender_champion() -> AiConfig {
    AiConfig {
        style: AiStyle::Defender,
        recon_units: 1,
        recon_forward: 6,
        focus_attacks: 3,
        arty_hit_center: 77,
        arty_hit_edge: 43,
        mortar_hit_center: 70,
        retreat_threats: 2,
        cover_search: 2,
        defend_radius: 11,
        assault_gap: 15,
        hq_spread: 1,
        village_hold: 1,
        platoon_points: 68,
        platoon_count: 2,
        arty_platoons: 2,
        recon_per: 1,
        armor_per: 2,
        recon_retreat: 2,
        platoon_retreat: 2,
        platoon_pattern: 0,
    }
}

fn company_default() -> AiConfig {
    // 参数覆盖：--ag N --pret N --pc N --pp N --armor N --recon N --rret N --rt N --arty N
    let ov = |key: &str| -> Option<i32> {
        let a: Vec<String> = std::env::args().collect();
        a.iter()
            .position(|x| x == key)
            .and_then(|i| a.get(i + 1))
            .and_then(|s| s.parse().ok())
    };
    if std::env::args().any(|x| x.starts_with("--ag") || x == "--pret" || x == "--pc" || x == "--pp"
        || x == "--armor" || x == "--recon" || x == "--rret" || x == "--rt" || x == "--arty") {
        let mut c = hex_wargame::game::company_champion();
        if let Some(v) = ov("--ag") { c.assault_gap = v; }
        if let Some(v) = ov("--pret") { c.platoon_retreat = v; }
        if let Some(v) = ov("--pc") { c.platoon_count = v; }
        if let Some(v) = ov("--pp") { c.platoon_points = v; }
        if let Some(v) = ov("--armor") { c.armor_per = v; }
        if let Some(v) = ov("--recon") { c.recon_per = v; }
        if let Some(v) = ov("--rret") { c.recon_retreat = v; }
        if let Some(v) = ov("--rt") { c.retreat_threats = v; }
        if let Some(v) = ov("--arty") { c.arty_platoons = v; }
        return c;
    }
    // --pattern N：指定连队构成模式（0-5），其余参数用默认冠军
    if let Some(i) = std::env::args().position(|a| a == "--pattern") {
        if let Some(p) = std::env::args().nth(i + 1).and_then(|s| s.parse::<i32>().ok()) {
            let mut c = hex_wargame::game::company_champion();
            c.platoon_pattern = p;
            return c;
        }
    }
    // --train-champion：使用 400 点桥头堡专项训练冠军（对比用）
    if std::env::args().any(|a| a == "--train-champion") {
        return AiConfig {
            style: AiStyle::Company,
            recon_units: 1,
            recon_forward: 3,
            focus_attacks: 3,
            arty_hit_center: 84,
            arty_hit_edge: 58,
            mortar_hit_center: 45,
            retreat_threats: 4,
            cover_search: 4,
            defend_radius: 6,
            assault_gap: 9,
            hq_spread: 3,
            village_hold: 2,
            platoon_points: 72,
            platoon_count: 5,
            arty_platoons: 1,
            recon_per: 1,
            armor_per: 3,
            recon_retreat: 2,
            platoon_retreat: 3,
            platoon_pattern: 4,
        };
    }
    hex_wargame::game::company_champion()
}

fn battle(
    custom: &CustomMap,
    seed: u64,
    cfg_a: AiConfig,
    cfg_b: AiConfig,
    points: i32,
    per_turn: i32,
) -> (Team, i32) {
    let mut g = GameState::new_custom_deploy(seed, custom.clone());
    g.enable_sustain(per_turn, per_turn);
    g.ai_configs.insert(Team::Player, cfg_a);
    g.ai_configs.insert(Team::Ai, cfg_b);
    g.recruit_points.insert(Team::Player, points);
    g.recruit_points.insert(Team::Ai, points);
    g.initial_points.insert(Team::Player, points);
    g.initial_points.insert(Team::Ai, points);
    ai::ai_deploy(&mut g, Team::Player);
    if g.finish_deploy().is_err() {
        return (Team::Ai, 0);
    }
    let mut log = Vec::new();
    for _ in 0..MAX_TURNS {
        if g.game_over() {
            break;
        }
        g.begin_turn(Team::Player);
        ai::run_ai_turn(&mut g, Team::Player, &mut log);
        if g.game_over() {
            break;
        }
        g.begin_turn(Team::Ai);
        ai::run_ai_turn(&mut g, Team::Ai, &mut log);
        log.clear();
        if g.turn - g.last_kill_turn > 8 {
            break;
        }
    }
    let turns = g.turn;
    if let Some(w) = g.winner {
        return (w, turns);
    }
    let value = |t: Team| -> i32 {
        g.units_of(t).iter().map(|u| u.kind.recruit_cost()).sum()
    };
    let pv = value(Team::Player);
    let av = value(Team::Ai);
    if pv != av {
        return (if pv > av { Team::Player } else { Team::Ai }, turns);
    }
    let hq_hp = |t: Team| -> i32 {
        g.units
            .iter()
            .find(|(_, u)| u.kind == UnitKind::Headquarters && u.team == t)
            .map(|(_, u)| u.hp)
            .unwrap_or(0)
    };
    let (phq, ahq) = (hq_hp(Team::Player), hq_hp(Team::Ai));
    if phq != ahq {
        return (if phq > ahq { Team::Player } else { Team::Ai }, turns);
    }
    use rand::{Rng, SeedableRng};
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
    if rng.gen::<bool>() {
        (Team::Player, turns)
    } else {
        (Team::Ai, turns)
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let log_game = args.iter().position(|a| a == "--log").map(|i| args.get(i + 1).and_then(|s| s.parse::<usize>().ok()).unwrap_or(1));
    let n: usize = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(20);
    let points_override = args
        .iter()
        .position(|a| a == "--points")
        .and_then(|i| args.get(i + 1))
        .and_then(|s| s.parse().ok());
    let per_turn_override = args
        .iter()
        .position(|a| a == "--per-turn")
        .and_then(|i| args.get(i + 1))
        .and_then(|s| s.parse().ok());
    let map_name = args
        .iter()
        .position(|a| a == "--map")
        .and_then(|i| args.get(i + 1))
        .cloned()
        .unwrap_or_else(|| "小镇巷战".to_string());
    let map_path = format!("maps/{}.json", map_name);
    let custom = CustomMap::load(std::path::Path::new(&map_path)).unwrap_or_else(|e| {
        eprintln!("无法加载 {map_path}: {e}");
        std::process::exit(1);
    });
    let points = points_override.unwrap_or(FAIR_POINTS);
    let per_turn = per_turn_override.unwrap_or(PER_TURN);
    let (d_cfg, c_cfg) = (defender_champion(), company_default());
    println!(
        "公司配置: platoon_count={} arty={} pp={} | 对局：双方 {} 点，每回合 +{} 点（持续招募）",
        c_cfg.platoon_count, c_cfg.arty_platoons, c_cfg.platoon_points, points, per_turn
    );
    let mut c_win = 0;
    let mut d_win = 0;
    let mut turns: Vec<i32> = Vec::new();
    for k in 0..n {
        let seed = 0x5f37_0000u64 + 3000 + k as u64;
        if log_game == Some(k + 1) {
            let mut g = GameState::new_custom_deploy(seed, custom.clone());
            g.enable_sustain(per_turn, per_turn);
            g.ai_configs.insert(Team::Player, c_cfg);
            g.ai_configs.insert(Team::Ai, d_cfg);
            g.recruit_points.insert(Team::Player, points);
            g.recruit_points.insert(Team::Ai, points);
            g.initial_points.insert(Team::Player, points);
            g.initial_points.insert(Team::Ai, points);
            ai::ai_deploy(&mut g, Team::Player);
            println!("—— 连排部署 ——");
            for l in g.units_of(Team::Player) {
                println!("  {} {} @{}", l.label, l.kind.name(), hex_wargame::hex::hex_label(l.pos));
            }
            if g.finish_deploy().is_err() {
                return;
            }
            println!("—— 稳守部署 ——");
            for l in g.units_of(Team::Ai) {
                println!("  {} {} @{}", l.label, l.kind.name(), hex_wargame::hex::hex_label(l.pos));
            }
            let mut log = Vec::new();
            for t in 0..MAX_TURNS {
                if g.game_over() {
                    break;
                }
                g.begin_turn(Team::Player);
                ai::run_ai_turn(&mut g, Team::Player, &mut log);
                println!("【回合 {} 连排】{}", t + 1, log.join(" | "));
                log.clear();
                if g.game_over() {
                    break;
                }
                g.begin_turn(Team::Ai);
                ai::run_ai_turn(&mut g, Team::Ai, &mut log);
                println!("【回合 {} 稳守】{}", t + 1, log.join(" | "));
                log.clear();
            }
            return;
        }
        let (w, t) = battle(&custom, seed, c_cfg, d_cfg, points, per_turn);
        turns.push(t);
        if w == Team::Player {
            c_win += 1;
            println!("场 {}: 连排胜（回合 {}）", k + 1, t);
        } else {
            d_win += 1;
            println!("场 {}: 稳守胜（回合 {}）", k + 1, t);
        }
    }
    println!(
        "═══ 连排指挥官 vs 稳守反击（{} 场）：连排 {} 胜 / 稳守 {} 胜 ═══",
        n, c_win, d_win
    );
    let mean = turns.iter().sum::<i32>() as f64 / turns.len() as f64;
    let mut s = turns.clone();
    s.sort_unstable();
    println!("回合数 平均 {:.1} / 中位 {} / {}-{}", mean, s[s.len() / 2], s[0], s[s.len() - 1]);
}
