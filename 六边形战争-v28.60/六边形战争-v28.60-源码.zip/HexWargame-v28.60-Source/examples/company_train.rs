//! 连排指挥官框架参数训练器：进化搜索连排参数，目标是在小镇巷战上
//! 稳定战胜现有最优 AI（稳守反击 Defender 冠军）。
//!
//! 用法：cargo run --release --example company_train [代数] [每代配置数] [每配置场数]
//! 每代：随机/变异生成配置 → 各 vs Defender 打 N 场（并行）→ 按胜率取 top 晋级 →
//! 晋级者变异 ±1 填满下一代 → 输出历代最优与最终冠军。

use rand::SeedableRng;
use rand::Rng;
use rayon::prelude::*;

use hex_wargame::ai;
use hex_wargame::game::{AiConfig, AiStyle, GameState};
use hex_wargame::mapdef::CustomMap;
use hex_wargame::unit::{Team, UnitKind};

// 默认 400 点、每回合 +20 点（用户指定）；可用 --points/--per-turn 覆盖
const PER_TURN: i32 = 20;
const FAIR_POINTS: i32 = 400;
const MAX_TURNS: i32 = 40;
const BATTLE_SEED_BASE: u64 = 0x5f37_0000 + 9000;

fn defender_champion() -> AiConfig {
    AiConfig {
        style: AiStyle::Defender,
        recon_units: 1,
        recon_forward: 6,
        focus_attacks: 3,
        arty_hit_center: 77,
        arty_hit_edge: 43,
        mortar_hit_center: 70,
        retreat_threats: 2,
        cover_search: 2,
        defend_radius: 11,
        assault_gap: 15,
        hq_spread: 1,
        village_hold: 1,
        platoon_points: 68,
        platoon_count: 2,
        arty_platoons: 2,
        recon_per: 1,
        armor_per: 2,
        recon_retreat: 2,
        platoon_retreat: 2,
        platoon_pattern: 0,
    }
}

fn battle(
    custom: &CustomMap,
    seed: u64,
    cfg_a: AiConfig,
    cfg_b: AiConfig,
    points: i32,
    per_turn: i32,
) -> (Team, i32) {
    let mut g = GameState::new_custom_deploy(seed, custom.clone());
    g.enable_sustain(per_turn, per_turn);
    g.ai_configs.insert(Team::Player, cfg_a);
    g.ai_configs.insert(Team::Ai, cfg_b);
    g.recruit_points.insert(Team::Player, points);
    g.recruit_points.insert(Team::Ai, points);
    g.initial_points.insert(Team::Player, points);
    g.initial_points.insert(Team::Ai, points);
    ai::ai_deploy(&mut g, Team::Player);
    if g.finish_deploy().is_err() {
        return (Team::Ai, 0);
    }
    let mut log = Vec::new();
    for _ in 0..MAX_TURNS {
        if g.game_over() {
            break;
        }
        g.begin_turn(Team::Player);
        ai::run_ai_turn(&mut g, Team::Player, &mut log);
        if g.game_over() {
            break;
        }
        g.begin_turn(Team::Ai);
        ai::run_ai_turn(&mut g, Team::Ai, &mut log);
        log.clear();
        if g.turn - g.last_kill_turn > 8 {
            break;
        }
    }
    let turns = g.turn;
    if let Some(w) = g.winner {
        return (w, turns);
    }
    let value = |t: Team| -> i32 {
        g.units_of(t).iter().map(|u| u.kind.recruit_cost()).sum()
    };
    let pv = value(Team::Player);
    let av = value(Team::Ai);
    if pv != av {
        return (if pv > av { Team::Player } else { Team::Ai }, turns);
    }
    let hq_hp = |t: Team| -> i32 {
        g.units
            .iter()
            .find(|(_, u)| u.kind == UnitKind::Headquarters && u.team == t)
            .map(|(_, u)| u.hp)
            .unwrap_or(0)
    };
    let (phq, ahq) = (hq_hp(Team::Player), hq_hp(Team::Ai));
    if phq != ahq {
        return (if phq > ahq { Team::Player } else { Team::Ai }, turns);
    }
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
    if rng.gen::<bool>() {
        (Team::Player, turns)
    } else {
        (Team::Ai, turns)
    }
}

/// 随机连排配置（各参数在范围内）
fn random_company(rng: &mut impl Rng) -> AiConfig {
    let mut r = |lo: i32, hi: i32| rng.gen_range(lo..=hi);
    AiConfig {
        style: AiStyle::Company,
        recon_units: r(1, 2),
        recon_forward: r(3, 6),
        focus_attacks: r(2, 4),
        arty_hit_center: r(70, 90),
        arty_hit_edge: r(35, 60),
        mortar_hit_center: r(45, 70),
        retreat_threats: r(1, 4),
        cover_search: r(1, 4),
        defend_radius: r(5, 10),
        assault_gap: r(6, 16),
        hq_spread: r(0, 3),
        village_hold: r(0, 2),
        platoon_points: r(60, 80),
        platoon_count: r(2, 5),
        arty_platoons: r(1, 3),
        recon_per: r(1, 2),
        armor_per: r(2, 3),
        recon_retreat: r(1, 4),
        platoon_retreat: r(1, 3),
        platoon_pattern: r(0, 5),
    }
}

/// 变异：每个参数 ±1（clamp 范围）
fn mutate(cfg: AiConfig, rng: &mut impl Rng) -> AiConfig {
    let mut c = cfg;
    let clamp = |v: i32, lo: i32, hi: i32| v.clamp(lo, hi);
    if rng.gen_bool(0.5) {
        c.platoon_points = clamp(c.platoon_points + rng.gen_range(-1..=1), 60, 80);
    }
    if rng.gen_bool(0.5) {
        c.platoon_count = clamp(c.platoon_count + rng.gen_range(-1..=1), 2, 5);
    }
    if rng.gen_bool(0.5) {
        c.arty_platoons = clamp(c.arty_platoons + rng.gen_range(-1..=1), 1, 3);
    }
    if rng.gen_bool(0.5) {
        c.recon_per = clamp(c.recon_per + rng.gen_range(-1..=1), 1, 2);
    }
    if rng.gen_bool(0.5) {
        c.armor_per = clamp(c.armor_per + rng.gen_range(-1..=1), 2, 3);
    }
    if rng.gen_bool(0.5) {
        c.recon_retreat = clamp(c.recon_retreat + rng.gen_range(-1..=1), 1, 4);
    }
    if rng.gen_bool(0.5) {
        c.platoon_retreat = clamp(c.platoon_retreat + rng.gen_range(-1..=1), 1, 3);
    }
    if rng.gen_bool(0.5) {
        c.retreat_threats = clamp(c.retreat_threats + rng.gen_range(-1..=1), 1, 5);
    }
    if rng.gen_bool(0.5) {
        c.assault_gap = clamp(c.assault_gap + rng.gen_range(-1..=1), 5, 20);
    }
    if rng.gen_bool(0.4) {
        c.platoon_pattern = clamp(c.platoon_pattern + rng.gen_range(-1..=1), 0, 5);
    }
    c
}

/// 评估一个配置 vs Defender 冠军：返回 (胜场, 场数, 回合数)
fn evaluate(
    custom: &CustomMap,
    cfg: AiConfig,
    n: usize,
    d_cfg: AiConfig,
    points: i32,
    per_turn: i32,
) -> (i32, Vec<i32>) {
    let mut wins = 0;
    let mut turns = Vec::new();
    for k in 0..n {
        let seed = BATTLE_SEED_BASE + (cfg.platoon_points as u64 * 7919)
            + (cfg.platoon_count as u64 * 104729)
            + (cfg.arty_platoons as u64 * 1299709)
            + (cfg.recon_per as u64 * 15485863)
            + (cfg.armor_per as u64 * 179424673)
            + (cfg.recon_retreat as u64 * 3)
            + (cfg.platoon_retreat as u64 * 5)
            + k as u64;
        let (w, t) = battle(custom, seed, cfg, d_cfg, points, per_turn);
        turns.push(t);
        if w == Team::Player {
            wins += 1;
        }
    }
    (wins, turns)
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let generations: usize = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(4);
    let popsize: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(48);
    let games: usize = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(4);
    let points = args
        .iter()
        .position(|a| a == "--points")
        .and_then(|i| args.get(i + 1))
        .and_then(|s| s.parse().ok())
        .unwrap_or(FAIR_POINTS);
    let per_turn = args
        .iter()
        .position(|a| a == "--per-turn")
        .and_then(|i| args.get(i + 1))
        .and_then(|s| s.parse().ok())
        .unwrap_or(PER_TURN);
    let map_name = args
        .iter()
        .position(|a| a == "--map")
        .and_then(|i| args.get(i + 1))
        .cloned()
        .unwrap_or_else(|| "小镇巷战".to_string());
    let map_path = format!("maps/{}.json", map_name);
    let custom = CustomMap::load(std::path::Path::new(&map_path)).unwrap_or_else(|e| {
        eprintln!("无法加载 {map_path}: {e}");
        std::process::exit(1);
    });
    let d_cfg = defender_champion();
    let mut rng = rand::rngs::StdRng::seed_from_u64(20250301);
    println!(
        "连排指挥官参数训练：{} 代 × {} 配置 × {} 场 vs 稳守反击（{}x{}，双方 {} 点，每回合 +{} 点）",
        generations, popsize, games, custom.cols, custom.rows, points, per_turn
    );
    let mut pop: Vec<AiConfig> = (0..popsize).map(|_| random_company(&mut rng)).collect();
    let mut best_ever: Option<(f64, AiConfig)> = None;
    for gen in 0..generations {
        // 并行评估
        let results: Vec<(i32, Vec<i32>)> = pop
            .par_iter()
            .map(|c| evaluate(&custom, *c, games, d_cfg, points, per_turn))
            .collect();
        // 排名（胜场 → 平均回合少胜）
        let mut ranked: Vec<(f64, AiConfig)> = pop
            .iter()
            .zip(results.iter())
            .map(|(c, (w, t))| {
                let wr = *w as f64 / games as f64;
                let mean_t = t.iter().sum::<i32>() as f64 / t.len().max(1) as f64;
                (wr * 1000.0 - mean_t * 0.1, *c)
            })
            .collect();
        ranked.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
        let (score, champ) = ranked[0];
        // 打印冠军的真实胜场：按排名重新统计
        let champ_wins = {
            let idx = pop.iter().position(|c| *c == champ).unwrap_or(0);
            results[idx].0
        };
        println!(
            "── 第 {} 代冠军：胜率 {:.0}%（{}胜/{}场，评分 {:.1}）",
            gen + 1,
            champ_wins as f64 * 100.0 / games as f64,
            champ_wins,
            games,
            score
        );
        println!(
            "    参数: pp={} pc={} arty={} recon={} armor={} rret={} pret={} rt={} ag={}",
            champ.platoon_points,
            champ.platoon_count,
            champ.arty_platoons,
            champ.recon_per,
            champ.armor_per,
            champ.recon_retreat,
            champ.platoon_retreat,
            champ.retreat_threats,
            champ.assault_gap
        );
        if best_ever.map_or(true, |(bs, _)| score > bs) {
            best_ever = Some((score, champ));
        }
        // 晋级 + 变异
        let elite = ranked.iter().take(8).map(|(_, c)| *c).collect::<Vec<_>>();
        let mut next: Vec<AiConfig> = elite.clone();
        while next.len() < popsize {
            let base = elite[rng.gen_range(0..elite.len())];
            let mut child = mutate(base, &mut rng);
            // 偶尔全随机
            if rng.gen_bool(0.1) {
                child = random_company(&mut rng);
            }
            next.push(child);
        }
        pop = next;
    }
    // 最终验证：冠军打 20 场
    if let Some((_, champ)) = best_ever {
        println!("\n══════ 最终冠军验证（20 场 vs 稳守反击） ══════");
        let mut wins = 0;
        let mut turns = Vec::new();
        for k in 0..20 {
            let seed = 0x5f37_0000u64 + 3000 + k as u64;
            let (w, t) = battle(&custom, seed, champ, d_cfg, points, per_turn);
            turns.push(t);
            if w == Team::Player {
                wins += 1;
            }
            print!(
                "{}",
                if w == Team::Player { "连" } else { "稳" }
            );
            if (k + 1) % 20 == 0 {
                println!();
            }
        }
        let mean = turns.iter().sum::<i32>() as f64 / turns.len() as f64;
        let mut s = turns.clone();
        s.sort_unstable();
        println!(
            "连排 {} 胜 / 稳守 {} 胜；回合数 平均 {:.1} / 中位 {} / {}-{}",
            wins,
            20 - wins,
            mean,
            s[s.len() / 2],
            s[0],
            s[s.len() - 1]
        );
        println!("冠军参数（写入 AiConfig::default 或 game 配置）:");
        println!("{:?}", champ);
    }
}
