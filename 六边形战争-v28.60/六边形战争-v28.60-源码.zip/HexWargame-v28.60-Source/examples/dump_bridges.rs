use hex_wargame::hex::{self};
use hex_wargame::map::GameMap;
use hex_wargame::mapdef::CustomMap;

fn main() {
    let cm = CustomMap::load(std::path::Path::new("maps/桥头堡之战.json")).unwrap();
    let mut m = GameMap::new(cm.cols, cm.rows);
    for (c, r) in &cm.water {
        m.add_water(*c, *r);
    }
    for (c, r) in &cm.forests {
        m.add_forest(*c, *r);
    }
    for (c, r) in &cm.buildings {
        m.add_building(*c, *r);
    }
    for (c, r) in &cm.roads {
        m.add_road(*c, *r);
    }
    let mut v: Vec<(i32, i32)> = m
        .bridge_hexes()
        .iter()
        .map(|h| hex::offset_from_axial(*h))
        .collect();
    v.sort_unstable();
    for (c, r) in &v {
        let mask_road = m.roads.contains(&hex::axial_from_offset(*c, *r));
        let mask_water = m.water.contains(&hex::axial_from_offset(*c, *r));
        println!("bridge ({},{}) road={} water={}", c, r, mask_road, mask_water);
    }
    println!("count={}", v.len());
    // dump roads count
    println!("roads={} water={}", m.roads.len(), m.water.len());
}
