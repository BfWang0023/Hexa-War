@echo off
setlocal
cd /d "%~dp0"
where cargo >nul 2>nul
if errorlevel 1 (
  echo Cargo not found. Install the Rust stable toolchain first; see README_编译与运行.md.
  exit /b 1
)
cargo run --locked --release --bin hex_wargame_web3d -- %*
exit /b %errorlevel%
