#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if ! command -v cargo >/dev/null 2>&1; then
  echo "未找到 Cargo。请先按 README_编译与运行.md 安装 Rust stable 工具链。" >&2
  exit 1
fi
exec cargo run --locked --release --bin hex_wargame_web3d -- "$@"
