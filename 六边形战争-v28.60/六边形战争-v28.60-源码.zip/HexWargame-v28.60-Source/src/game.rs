//! 游戏状态：地图、单位、回合流程、搭载与战斗结算。

#[allow(unused_imports)] // 仅测试模块使用
use crate::ai;
use crate::hex::{self, Hex};
use crate::map::GameMap;
use crate::mapdef::{CustomMap, VictoryRule};
use crate::unit::{Team, Unit, UnitKind};
use rand::{Rng, SeedableRng};
use rand_chacha::ChaCha12Rng;
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet, VecDeque};

/// 初始搭载的日志后缀，例如「（载：步枪手、补给）」；无货物时为空串。
fn cargo_suffix(cargo: &[UnitKind]) -> String {
    if cargo.is_empty() {
        return String::new();
    }
    let names: Vec<&str> = cargo.iter().map(|k| k.name()).collect();
    format!("（载：{}）", names.join("、"))
}

/// 一次攻击的结算结果。
#[allow(dead_code)] // hit/blocked 供测试断言使用
#[derive(Debug)]
pub struct AttackOutcome {
    pub message: String,
    pub hit: bool,          // 是否有任意命中检定通过
    pub blocked: bool,      // 命中但攻击力 < 目标护甲，被挡下
    pub killed: bool,       // 是否有单位被摧毁
    pub kills: Vec<Hex>,    // 被摧毁单位所在格
}

/// 一条同时攻击命令：攻击者格、目标格、以及同格双单位时是否以空中层为攻击者。
/// 同时记录下达命令时的武器模式，确认结算时使用该快照，避免后续切换武器改变命令。
#[derive(Clone, Copy, Debug, serde::Serialize, serde::Deserialize)]
pub struct SimulOrder {
    pub attacker: Hex,
    pub target: Hex,
    pub air_first: bool,
    /// 下达命令时的第三武器模式（特战 Stinger 防空导弹）
    pub aa_mode: bool,
    /// 下达命令时的副武器模式（M3E1 / XM1176 / M864 / TOW / M-SHORAD 导弹 / 坦克重机枪）
    pub missile_mode: bool,
}

/// 关卡类型。
#[derive(Clone, Copy, PartialEq, Eq, Debug, serde::Serialize, serde::Deserialize)]
pub enum Level {
    /// 开阔地遭遇战（默认）：双方 100 点，地图中部遭遇。
    OpenField,
    /// 村庄防守：玩家（150 点）从西边开阔地进攻东边靠山村庄，AI（300 点）防守村庄。
    VillageDefense,
    /// 自定义地图（编辑器制作，从 maps/ 目录加载；地图数据在 GameState::custom）。
    Custom,
}

impl Level {
    pub fn name(self) -> &'static str {
        match self {
            Level::OpenField => "开阔地遭遇战",
            Level::VillageDefense => "村庄防守战",
            Level::Custom => "自定义地图",
        }
    }
}

/// 关键据点/大本营：`center == false` 为关键据点（胜负目标），
/// `center == true` 为大本营（只决定增援部署区域，不参与胜负）。
/// 常规/持续部署模式由开局随机生成每方 1 大本营 + 2 关键据点；战役地图由编辑器逐格指定。
/// 陆军棋子（非空中）踏入敌方控制的格子即占领（颜色翻转）；被占领的格子
/// 可被敌方再次踏入夺回。胜负按地图为双方分别设定的胜利条件判定。
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct Keypoint {
    /// 据点的原始归属方（Player=蓝 / Ai=红）
    pub owner: Team,
    /// 当前控制方
    pub controller: Team,
    /// 是否大本营（`true` = 大本营，只决定增援部署区域，不参与胜负；
    /// `false` = 关键据点，是胜负目标）。旧地图用该字段表示大本营中心。
    pub center: bool,
}

/// 战役地图的一片可部署区域：区域内所有格连通，并共同连接**同一座**大本营。
/// 大本营被敌方夺取（`Keypoint.controller` 易主）时，该片区域停用；
/// 被夺回后恢复可用。初始招募与增援部署使用完全相同的区域。
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct DeployRegion {
    /// 该区域连接的大本营格
    pub hq: Hex,
    /// 区域内的可部署格
    pub cells: Vec<Hex>,
}

/// 一次击毁的成因。文本协议与日志都按此分类，避免不同措辞（"被摧毁"/"坠毁"）
/// 让消费者漏掉战损。
#[derive(Clone, Copy, PartialEq, Eq, Debug, serde::Serialize, serde::Deserialize)]
pub enum KillCause {
    /// 直射武器命中后血量归零
    DirectFire,
    /// 榴弹炮/迫击炮等范围火力
    Artillery,
    /// 直升机/重型运输直升机被命中要害直接坠毁（致命伤）
    FatalHit,
    /// 载具被击毁时车上搭载的步兵随之阵亡
    AboardCarrier,
}

impl KillCause {
    pub fn cn(self) -> &'static str {
        match self {
            KillCause::DirectFire => "直射",
            KillCause::Artillery => "炮击",
            KillCause::FatalHit => "致命伤",
            KillCause::AboardCarrier => "随载具阵亡",
        }
    }
}

/// 一次单位被击毁的结构化记录。受害方客户端据此得到「我损失了什么、被谁打掉的」，
/// 日志导出据此得到完整战损时间线（不再依赖对中文战报文本的字符串匹配）。
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct KillEvent {
    pub turn: i32,
    /// 被击毁单位所属方
    pub victim_team: Team,
    pub victim_label: char,
    pub victim_kind: UnitKind,
    pub victim_pos: Hex,
    /// 是否随载具一同阵亡（车上步兵）
    pub passenger: bool,
    pub attacker_team: Option<Team>,
    pub attacker_label: Option<char>,
    pub attacker_kind: Option<UnitKind>,
    pub attacker_pos: Option<Hex>,
    pub cause: KillCause,
}

/// 结构化战报事件：击毁、关键据点易手、胜负判定。
/// `seq` 单调递增，供多人主机按客户端已发送序号增量推送。
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub enum BattleEventKind {
    Kill(KillEvent),
    Keypoint {
        hex: Hex,
        center: bool,
        from: Team,
        to: Team,
        by_label: char,
        by_kind: UnitKind,
    },
    Victory {
        winner: Team,
        reason: String,
    },
}

#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct BattleEvent {
    pub seq: u32,
    pub turn: i32,
    pub kind: BattleEventKind,
}

fn default_test_place_team() -> Team {
    Team::Player
}

/// AI 版本选择：运行时可切换的“旧版 / 新版”AI 实现。
/// 默认 Legacy，旧存档（无该字段）反序列化后仍是旧版 AI，保证兼容。
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default, serde::Serialize, serde::Deserialize)]
pub enum AiVersion {
    /// 旧版 AI（src/ai.rs，行为保持不变）。
    #[default]
    Legacy,
    /// 新版 AI（src/ai_v2：期望伤害 + 统一效用 + 行动枚举 + 威胁图）。
    V2,
}

impl AiVersion {
    pub fn name(self) -> &'static str {
        match self {
            AiVersion::Legacy => "旧版",
            AiVersion::V2 => "新版",
        }
    }

    /// 在旧版/新版之间切换。
    pub fn toggled(self) -> Self {
        match self {
            AiVersion::Legacy => AiVersion::V2,
            AiVersion::V2 => AiVersion::Legacy,
        }
    }
}

/// 新版 AI 难度档位：控制搜索广度、行动策略与效用权重。
/// 默认 Regular；仅对 AiVersion::V2 生效（旧版忽略）。
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default, serde::Serialize, serde::Deserialize)]
pub enum AiDifficulty {
    /// 新兵：不移动后射击、候选落点少、不集火、易冒进。
    Recruit,
    #[default]
    Regular,
    /// 老兵：更多候选、强集火、重视掩体与侦察。
    Veteran,
    /// 精英：最大候选与最强集火/风险控制。
    Elite,
}

impl AiDifficulty {
    pub fn name(self) -> &'static str {
        match self {
            AiDifficulty::Recruit => "新兵",
            AiDifficulty::Regular => "常规",
            AiDifficulty::Veteran => "老兵",
            AiDifficulty::Elite => "精英",
        }
    }

    pub fn all() -> [AiDifficulty; 4] {
        [
            AiDifficulty::Recruit,
            AiDifficulty::Regular,
            AiDifficulty::Veteran,
            AiDifficulty::Elite,
        ]
    }
}

#[derive(Clone, serde::Serialize, serde::Deserialize)]
pub struct GameState {
    pub map: GameMap,
    /// 当前关卡
    pub level: Level,
    /// 自定义地图数据（level == Custom 时有值）
    pub custom: Option<CustomMap>,
    /// 地面单位（一格一个）
    pub units: BTreeMap<Hex, Unit>,
    /// 空中单位（直升机，可与地面单位同格）
    pub air_units: BTreeMap<Hex, Unit>,
    pub turn: i32,
    pub phase: Team,
    pub rng: ChaCha12Rng,
    /// 初始随机种子（配合事件日志可完全复原对局）
    pub seed: u64,
    pub winner: Option<Team>,
    /// 最近一次有单位被击杀的回合号（用于判断僵局平局）
    pub last_kill_turn: i32,
    /// 完整对局事件日志：记录部署、每回合行动、每次攻击/移动/搭载等全部事件，
    /// 配合 seed 可完全复原整场对局（用于 bug 反馈与复盘）。
    pub event_log: Vec<String>,
    /// 结构化战报事件（击毁 / 据点易手 / 胜负）：多人主机按客户端已发送序号增量推送，
    /// 日志导出直接引用，终端消费者无需解析中文文本。
    #[serde(default)]
    pub battle_events: Vec<BattleEvent>,
    /// battle_events 的序号计数器（下一个事件的 seq）。
    #[serde(default)]
    pub battle_seq: u32,
    /// 每方"最后已知敌方位置"（幽灵标记）：team → 格 → (单位种类, 记录回合)。
    /// 只在单位可见时刷新，单位离开视野后保留 2 回合；被击毁的格立即清除。
    /// 文本快照据此显示 `?`，避免直接暴露当前隐藏敌人的真实位置。
    #[serde(default)]
    pub ghosts: BTreeMap<Team, BTreeMap<Hex, (UnitKind, i32)>>,
    /// 是否处于部署阶段（第 0 回合：双方用招募点数选兵并放入出发区域）
    pub deploying: bool,
    /// 双方剩余招募点数
    pub recruit_points: BTreeMap<Team, i32>,
    /// 双方是否已完成部署
    pub deploy_done: BTreeMap<Team, bool>,
    /// 烟雾弹区域：格 → 剩余持续回合数（2 回合）。视野上完全遮挡（不穿透），但不阻挡移动。
    pub smoke: BTreeMap<Hex, i32>,
    /// 因"进入烟雾遭遇"而接触发现的敌方单位格（每回合开始清空）
    pub revealed_by_contact: BTreeMap<Team, BTreeSet<Hex>>,
    /// 最近被击毁的单位所在格（界面据此清除"最后已知位置"幽灵标记；每帧 drain）
    pub killed_hexes: Vec<Hex>,
    /// 迷雾开火警告：被警告方 → 开火位置 → 记录回合。
    /// 任何单位在对方视野之外开火时（无论命中与否），其位置都会被对方标记；
    /// 对方（玩家或 AI）可据此派兵查探。标记在单位被发现/阵亡/3 回合后失效。
    pub fog_fire_marks: BTreeMap<Team, BTreeMap<Hex, i32>>,
    /// 可持续部署模式：每回合双方获得部署点数，可在己方大本营区域追加部署
    pub sustain: bool,
    /// 双方每回合获得的部署点数（sustain 模式）
    pub sustain_per_turn: BTreeMap<Team, i32>,
    /// 是否处于"追加部署"状态（对局中按 d 进入；AI 回合自动部署）
    pub sustain_deploying: bool,
    /// 每队下一个可用的单位标签序号（单调递增，避免阵亡后标签复用）。
    #[serde(default)]
    pub next_label_seq: BTreeMap<Team, usize>,
    /// 只对该方可见的回合内提示（压制生效、主动防御生效等）。
    /// 该方回合开始时清空，随后由本回合发生的事件填充。
    #[serde(default)]
    pub notices: BTreeMap<Team, Vec<String>>,
    /// 每队初始招募点数（sustain 模式计算"已歼灭点数比例"用）
    pub initial_points: BTreeMap<Team, i32>,
    /// 每队已被歼灭单位的总点数（sustain 模式 AI 判定"接近全歼"用）
    pub killed_value: BTreeMap<Team, i32>,
    /// AI 记忆的敌方大本营中心位置（一旦发现永久记住；sustain 模式搜索/总攻用）
    pub hq_seen: BTreeMap<Team, Option<Hex>>,
    /// 关键据点 / 大本营：格 → 据点（sustain 模式每方 3 个：1 大本营 + 2 关键据点）
    pub keypoints: BTreeMap<Hex, Keypoint>,
    /// 战役地图：双方可部署区域（按大本营连通区划分）。其他模式为空，
    /// 沿用列部署区 + 大本营周围 2 格的旧规则。
    #[serde(default)]
    pub deploy_regions: BTreeMap<Team, Vec<DeployRegion>>,
    /// AI 待招募兵种计划：下一个要招募的单位类型（随机产生，点数攒够才买）
    pub ai_recruit_plan: BTreeMap<Team, Option<UnitKind>>,
    /// 每队 AI 的行动规则配置（参数化智能；对战/训练可给两队不同配置）
    pub ai_configs: BTreeMap<Team, AiConfig>,
    /// AI 版本（旧版/新版）；默认旧版，旧存档兼容。
    #[serde(default)]
    pub ai_version: AiVersion,
    /// 新版 AI 难度档位；默认常规，旧存档兼容。
    #[serde(default)]
    pub ai_difficulty: AiDifficulty,
    /// AI 回合级视野缓存：team → (缓存时的回合号, 可见敌方格集合)。
    /// is_unit_visible 在缓存回合内命中（O(1)），跨回合自动失效走真实 BFS。
    pub vis_cache: BTreeMap<Team, (i32, BTreeSet<Hex>)>,
    /// 连排指挥官框架：每队当前的排划分与连指挥官指令（AiStyle::Company 使用）
    pub company: BTreeMap<Team, CompanyPlan>,
    /// 上回合末己方防空单位数量（AI 检测"己方防空被击毁"：本回合更少 → 触发防空倾向）
    pub aa_count_last: BTreeMap<Team, i32>,
    /// 试验模式：开启后敌方 AI 不行动，所有敌方单位在地图上可见（视野外暗色显示），
    /// 并允许自由放置双方棋子（不消耗部署点数）。
    #[serde(default)]
    pub test_mode: bool,
    /// 试验模式中是否处于“放置棋子”子模式。
    #[serde(default)]
    pub test_placing: bool,
    /// 试验放置棋子时当前选择的阵营。
    #[serde(default = "default_test_place_team")]
    pub test_place_team: Team,
    /// 招募模式的「首个招募回合」：该回合内可在本方出发区域任意空格招募
    /// （多人空地图开局，双方全部单位都要自行招募）；此后只能在大本营周围 2 格内。
    /// 0 表示没有这种回合（单机的出发区域招募走部署阶段 `deploy_unit`）。
    #[serde(default)]
    pub recruit_zone_turn: i32,
    /// 供 GUI 回放动画的战斗/移动事件（不入存档；GUI 每帧取走后清空）。
    /// AI 回合瞬时结算，事件按发生顺序排队，由 GUI 错峰播放。
    #[serde(skip)]
    pub ui_events: Vec<UiEvent>,
}

/// 一次攻击击毁的单位（动画回放用：击毁特效落地前保持棋子显示）。
#[derive(Clone, Debug)]
pub struct KilledUnit {
    pub hex: Hex,
    pub team: Team,
    pub kind: UnitKind,
    pub label: char,
    /// 受击前血量（换算阵亡士兵数用）
    pub hp_before: i32,
}

/// 一次攻击的动画回放信息（不参与游戏逻辑）。
#[derive(Clone, Debug)]
pub struct UiFireEvent {
    /// 攻击方阵营/标签/兵种/位置
    pub team: Team,
    pub label: char,
    pub kind: UnitKind,
    pub from: Hex,
    /// 目标位置/身份/兵种
    pub target: Hex,
    pub target_team: Team,
    pub target_label: char,
    pub target_kind: UnitKind,
    /// 武器模式（防空导弹/副武器），决定弹道样式
    pub aa_mode: bool,
    pub missile_mode: bool,
    /// 范围攻击（榴弹炮/迫击炮）：blast 为爆炸格集合
    pub area: bool,
    pub smoke_shell: bool,
    pub blast: Vec<Hex>,
    pub hit: bool,
    /// 命中但被护甲/主动防御挡下
    pub blocked: bool,
    pub killed: bool,
    /// 目标受击前血量（换算阵亡士兵数用）
    pub target_hp_before: i32,
    pub dmg: i32,
    /// 本次攻击击毁的全部单位（直射 = 目标本身；范围炮击 = 所有被波及击毁者）
    pub killed_units: Vec<KilledUnit>,
}

/// GUI 动画事件：移动或开火。
#[derive(Clone, Debug)]
pub enum UiEvent {
    Move {
        team: Team,
        label: char,
        kind: UnitKind,
        /// 实际走过的路径（含起点与终点）
        path: Vec<Hex>,
        air: bool,
    },
    Fire(UiFireEvent),
}

/// 排类型：战斗排（侦察/装甲/步兵混编）或榴弹炮排（榴弹炮+卡车护卫）。
#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum PlatoonRole {
    Combat,
    Artillery,
}

/// 排组模板（连排指挥官框架）：AI 从以下排组中选择编成。
/// - `Cavalry`   装甲骑兵排：2 装甲骑兵战车（各搭载 Javelin/防空导弹手）+ 1 侦察车
/// - `Tank`      坦克排：2 主战坦克 + 1 侦察车（侦察前出，遇敌撤后，坦克开火）
/// - `Motorized` 摩托化步兵排：1 卡车（2 步枪手 + 1 精锐步兵）+ 1 侦察车 + 1 坦克
/// - `Mechanized`机械化步兵排：2 步兵战车（各载 1 步枪手 + 1 精锐步兵）+ 2 坦克 + 1 侦察车
/// - `AirDefense`防空排：3 M-SHORAD + 1 侦察无人机（无人机居中照亮；他排发现空中单位时连队派其支援）
/// - `AirDefenseInfantry`防空步兵排：1 卡车（载 3 队防空导弹手）+ 1 M-SHORAD
///   （廉价防空；场上存在敌方空中单位或己方防空被击毁时，连队更倾向出防空）
/// - `Heli`      直升机排：2 武装直升机 + 1 运输直升机（载 1 特战小队）+ 1 侦察无人机（连队下令空降点）
/// - `Artillery` 榴弹炮排：2 榴弹炮 + 2 卡车（卡车守炮）
#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum PlatoonType {
    Cavalry,
    Tank,
    Motorized,
    Mechanized,
    AirDefense,
    AirDefenseInfantry,
    Heli,
    Artillery,
}

/// 连指挥官给排的指令。
#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum PlatoonOrder {
    /// 向标记目标推进/攻击
    Advance,
    /// 到达目标后驻守（榴弹炮排/已就位排）
    Hold,
    /// 整排撤回己方安全区
    Retreat,
}

/// 一个排：成员（单位标签）+ 连指挥官标记的目标与指令。
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct PlatoonPlan {
    pub id: usize,
    pub role: PlatoonRole,
    /// 排组模板（决定构成与战术）
    pub ptype: PlatoonType,
    /// 成员单位标签（随增援扩充）
    pub members: Vec<char>,
    /// 连指挥官标记的目标位置（排的集结/攻击参考点）
    pub target: Hex,
    pub order: PlatoonOrder,
}

/// 连指挥部计划：排划分 + 每回合重算的目标与指令。
#[derive(Clone, Debug, Default, serde::Serialize, serde::Deserialize)]
pub struct CompanyPlan {
    pub platoons: Vec<PlatoonPlan>,
}

/// AI 策略类型：除参数外的行为取向差异。
/// - `Balanced`：通用均衡（现有默认 AI，淘汰赛冠军参数）
/// - `Defender`：稳守反击——纵深防御、重装增援、晚总攻
/// - `Blitzer` ：闪电突击——高速推进、高价值集火、早总攻
/// - `Harasser`：游击猎手——打了就跑、远程骚扰、专挑软柿子
/// - `Company` ：连排指挥官——部队按排编组，连指挥官分配目标/撤退/增援指令，
///   排指挥官按"侦察前出、步兵居中、装甲靠后"阵型执行
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub enum AiStyle {
    Balanced,
    Defender,
    Blitzer,
    Harasser,
    Company,
}

impl AiStyle {
    pub fn name(self) -> &'static str {
        match self {
            AiStyle::Balanced => "通用均衡",
            AiStyle::Defender => "稳守反击",
            AiStyle::Blitzer => "闪电突击",
            AiStyle::Harasser => "游击猎手",
            AiStyle::Company => "连排指挥官",
        }
    }
}

/// AI 行动规则配置：12 个可调整数参数，分别控制侦察/进攻/支援/防守/扫荡等决策。
/// 每个参数都有合理范围；默认值为经过淘汰赛训练选出的当前最优配置。
#[derive(Clone, Copy, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct AiConfig {
    /// 策略类型（行为取向）
    pub style: AiStyle,
    /// 侦察单位数量（最多几个单位前出开眼）1..=3
    pub recon_units: i32,
    /// 侦察前出距离（前出到距目标多近停止）3..=8
    pub recon_forward: i32,
    /// 集火主战坦克所需袭击次数（≥ 该值才集火）2..=5
    pub focus_attacks: i32,
    /// 榴弹炮常规弹中心命中率 % 65..=90
    pub arty_hit_center: i32,
    /// 榴弹炮常规弹边缘命中率 % 30..=65
    pub arty_hit_edge: i32,
    /// 自行迫击炮中心命中率 %（边缘 = 中心-30）45..=70
    pub mortar_hit_center: i32,
    /// 撤退触发的可见威胁单位数（被打且打不到时威胁数 ≥ 该值才撤退）1..=5
    pub retreat_threats: i32,
    /// 隐蔽地形（森林/楼房）搜索最大距离 1..=6
    pub cover_search: i32,
    /// 全面防御触发半径（己方指挥部周围几格内发现敌军即回防）5..=12
    pub defend_radius: i32,
    /// 总攻阈值：已歼灭点数 ≥ 敌军初始点数 P - N 时总攻 5..=20
    pub assault_gap: i32,
    /// 指挥部搜索分散系数（0=集中深入，越大越分散）0..=4
    pub hq_spread: i32,
    /// 村庄防守留守兵力分母（0=全员出击；N=可调动兵力 ÷ (N+1)）0..=3
    pub village_hold: i32,
    /// —— 连排指挥官框架（AiStyle::Company 专用）——
    /// 每个战斗排的招募预算（点数）60..=80
    pub platoon_points: i32,
    /// 战斗排数量上限 2..=4（实际按预算尽量多建）
    pub platoon_count: i32,
    /// 榴弹炮排数量（每排 2 榴弹炮 + 2 卡车）0..=3
    pub arty_platoons: i32,
    /// 每个战斗排的侦察单位数 1..=2
    pub recon_per: i32,
    /// 每个战斗排的装甲战车数（坦克/主战，不含侦察战车）2..=3
    pub armor_per: i32,
    /// 侦察遇敌后退距离（距最近可见敌军 ≤ 该值即退回步兵线）1..=4
    pub recon_retreat: i32,
    /// 排撤退触发：排内"被打且打不到"单位数 ≥ 该值且威胁达标 → 整排撤退 1..=3
    pub platoon_retreat: i32,
    /// 连队构成模式（排型组合，AiStyle::Company 专用）：
    /// 0=默认均衡  1=重装猛推（坦克/机械化）  2=火炮压制（多榴弹炮排）
    /// 3=机动打击（装甲骑兵/摩托化/直升机）  4=机械化强攻  5=防空压制
    pub platoon_pattern: i32,
}

impl Default for AiConfig {
    /// 当前默认 = **稳守反击（Defender）风格冠军**：3 种风格（稳守反击/闪电突击/
    /// 游击猎手）各 256 配置淘汰赛后，两两对局中稳守反击累计 96 分居首
    /// （15:5 胜闪电突击、17:3 胜游击猎手），故作为游戏默认 AI。
    /// 参数见 `cargo run --release --bin tune_ai` 训练输出。
    fn default() -> Self {
        Self {
            style: AiStyle::Defender,
            recon_units: 1,
            recon_forward: 6,
            focus_attacks: 3,
            arty_hit_center: 77,
            arty_hit_edge: 43,
            mortar_hit_center: 70,
            retreat_threats: 2,
            cover_search: 2,
            defend_radius: 11,
            assault_gap: 15,
            hq_spread: 1,
            village_hold: 1,
            platoon_points: 68,
            platoon_count: 2,
            arty_platoons: 2,
            recon_per: 1,
            armor_per: 2,
            recon_retreat: 2,
            platoon_retreat: 2,
            platoon_pattern: 0,
        }
    }
}

impl AiConfig {
    /// 参数化搜索用：在合理范围内随机生成一个**指定风格**的配置。
    /// 各风格的参数范围按行为侧重收窄（Defender 防高攻低、Blitzer 快攻、
    /// Harasser 骚扰/游走），保证策略差异可被淘汰赛放大。
    pub fn random_with_style(rng: &mut impl rand::Rng, style: AiStyle) -> Self {
        let mut r = |lo: i32, hi: i32| rng.gen_range(lo..=hi);
        if style == AiStyle::Company {
            return Self {
                style,
                recon_units: r(1, 3),
                recon_forward: r(3, 8),
                focus_attacks: r(2, 5),
                arty_hit_center: r(65, 90),
                arty_hit_edge: r(30, 65),
                mortar_hit_center: r(45, 70),
                retreat_threats: r(1, 5),
                cover_search: r(1, 6),
                defend_radius: r(5, 12),
                assault_gap: r(5, 20),
                hq_spread: r(0, 4),
                village_hold: r(0, 3),
                platoon_points: r(60, 80),
                platoon_count: r(2, 4),
                arty_platoons: r(0, 3),
                recon_per: r(1, 2),
                armor_per: r(2, 3),
                recon_retreat: r(1, 4),
                platoon_retreat: r(1, 3),
                platoon_pattern: r(0, 5),
            };
        }
        let (r1, r2, f, ac, ae, mc, rt, cs, dr, ag, hs, vh) = match style {
            AiStyle::Balanced => (r(1, 3), r(3, 8), r(2, 5), r(65, 90), r(30, 65), r(45, 70), r(1, 5), r(1, 6), r(5, 12), r(5, 20), r(0, 4), r(0, 3)),
            // 稳守反击：侦察少而稳、防御半径大、总攻晚、火炮命中高
            AiStyle::Defender => (r(1, 2), r(4, 8), r(3, 5), r(75, 90), r(40, 65), r(50, 70), r(1, 3), r(2, 6), r(9, 12), r(12, 20), r(0, 2), r(1, 3)),
            // 闪电突击：侦察多前出、集火快、总攻早、几乎不撤
            AiStyle::Blitzer => (r(2, 3), r(3, 6), r(2, 3), r(65, 85), r(30, 55), r(45, 60), r(3, 5), r(1, 4), r(5, 8), r(5, 12), r(1, 4), r(0, 2)),
            // 游击猎手：易撤退、善隐蔽、迫击炮/榴弹炮骚扰命中高
            AiStyle::Harasser => (r(1, 3), r(3, 7), r(2, 4), r(70, 90), r(40, 65), r(55, 70), r(1, 3), r(3, 6), r(6, 10), r(7, 15), r(1, 4), r(0, 3)),
            AiStyle::Company => unreachable!(),
        };
        Self {
            style,
            recon_units: r1,
            recon_forward: r2,
            focus_attacks: f,
            arty_hit_center: ac,
            arty_hit_edge: ae,
            mortar_hit_center: mc,
            retreat_threats: rt,
            cover_search: cs,
            defend_radius: dr,
            assault_gap: ag,
            hq_spread: hs,
            village_hold: vh,
            platoon_points: 68,
            platoon_count: 3,
            arty_platoons: 2,
            recon_per: 1,
            armor_per: 2,
            recon_retreat: 2,
            platoon_retreat: 2,
            platoon_pattern: 0,
        }
    }

    /// 兼容旧调用：随机生成一个通用均衡风格配置。
    pub fn random(rng: &mut impl rand::Rng) -> Self {
        Self::random_with_style(rng, AiStyle::Balanced)
    }
}

/// 连排指挥官（AiStyle::Company）推荐配置：**进化训练冠军**（见
/// `examples/company_train.rs`：6 代 × 48 配置 × 每配置 4 场 vs 稳守反击冠军；
/// 部署顺序 = 榴弹炮排优先），在小镇巷战地图上 20 场验证
/// **13:7 稳定战胜稳守反击**（回合数平均 15.9 / 中位 20）。
/// 要点：1 榴弹炮排（2 榴弹炮 + 2 卡车守炮）+ 3 战斗排，每排 61 点
/// （1 侦察 + 1 主战坦克 + 步枪/反坦克射手）；侦察遇敌 3 格内回撤、
/// 排内 3 个被打且打不到才整排撤退（不轻易放弃战线）、威胁 1 个即撤退保命。
pub fn company_champion() -> AiConfig {
    AiConfig {
        style: AiStyle::Company,
        recon_units: 1,
        recon_forward: 5,
        focus_attacks: 4,
        arty_hit_center: 87,
        arty_hit_edge: 40,
        mortar_hit_center: 52,
        retreat_threats: 1,
        cover_search: 2,
        defend_radius: 10,
        assault_gap: 9,
        hq_spread: 2,
        village_hold: 1,
        platoon_points: 61,
        platoon_count: 3,
        arty_platoons: 1,
        recon_per: 1,
        armor_per: 3,
        recon_retreat: 3,
        platoon_retreat: 3,
        platoon_pattern: 0,
    }
}

/// 连排指挥官**400 点大点数**推荐配置（桥头堡之战 400 点 +20/回合专项训练冠军）：
/// **机械化强攻（pattern 4）5 排**——20 场验证 **19:1 稳定战胜稳守反击**
/// （回合数平均 15.4 / 中位 19，多数对局在 20 回合内攻破敌方指挥部）。
/// 要点：5 个战斗排（机械化步兵排×2 + 坦克排 + 装甲骑兵排 + 防空排）、
/// 每排 1 侦察 + 3 装甲、排内 3 个被打才整排撤退（不轻易放弃战线）、
/// 威胁 4 个才单独撤退（稳守防线）、早总攻（ag=9 歼 391 点即直扑指挥部）。
pub fn company_champion_400() -> AiConfig {
    AiConfig {
        style: AiStyle::Company,
        recon_units: 1,
        recon_forward: 3,
        focus_attacks: 3,
        arty_hit_center: 84,
        arty_hit_edge: 58,
        mortar_hit_center: 45,
        retreat_threats: 4,
        cover_search: 4,
        defend_radius: 6,
        assault_gap: 9,
        hq_spread: 3,
        village_hold: 2,
        platoon_points: 72,
        platoon_count: 5,
        arty_platoons: 1,
        recon_per: 1,
        armor_per: 3,
        recon_retreat: 2,
        platoon_retreat: 3,
        platoon_pattern: 4,
    }
}

/// 开阔地遭遇战地图（默认 27×13）。
fn build_open_field(map: &mut GameMap) {
    for (c, r) in [
        (4, 2), (5, 2), (4, 3), (8, 5), (9, 5), (6, 1), (7, 2), (6, 7), (7, 7),
        (11, 3), (12, 3), (2, 6), (10, 1), (9, 7), (10, 7), (14, 1), (14, 3),
        (15, 6), (16, 4), (12, 7), (19, 3), (20, 2), (22, 5), (23, 8), (21, 10),
        (24, 11), (19, 12), (20, 9), (23, 1), (18, 10),
    ] {
        map.add_obstacle(c, r);
    }
    for (c, r) in [
        (3, 1), (3, 2), (3, 3), (8, 1), (9, 1), (10, 4), (10, 5), (10, 6),
        (7, 4), (5, 6), (6, 6), (11, 1), (12, 1), (12, 5), (13, 5), (15, 4),
        (16, 2), (11, 6), (13, 7), (19, 1), (20, 4), (21, 6), (18, 8),
        (22, 9), (23, 10), (24, 8), (21, 2), (19, 11), (17, 10), (22, 12), (16, 8),
    ] {
        map.add_forest(c, r);
    }
    for (c, r) in [
        (6, 3), (7, 3), (9, 2), (10, 2), (5, 5), (6, 5), (12, 4), (14, 4),
        (16, 6), (19, 4), (20, 6), (22, 7), (21, 12), (23, 3),
    ] {
        map.add_building(c, r);
    }
}

/// 村庄防守战地图：玩家从西边开阔地（cols 0-5）进攻东边村庄。
/// 村庄：cols 19-26 rows 3-9，房屋密集但有道路（纵向 col 21/24、横向 row 5/7/9）；
/// 北面（rows 0-2）为岩石山；南面（rows 10-12）与西面（cols 6-18 rows 8-12）为森林；
/// 两条林中小道（row 9、row 11）从村庄直通西边玩家出发地。
fn build_village_defense(map: &mut GameMap) {
    // 北面岩石山（村庄靠山）
    for (c, r) in [
        (14, 0), (15, 0), (16, 0), (17, 0), (18, 0), (19, 0), (20, 0), (21, 0),
        (22, 0), (23, 0), (24, 0), (25, 0), (26, 0),
        (16, 1), (17, 1), (18, 1), (19, 1), (20, 1), (21, 1), (22, 1), (23, 1),
        (24, 1), (25, 1), (26, 1),
        (18, 2), (20, 2), (22, 2), (24, 2), (26, 2),
    ] {
        map.add_obstacle(c, r);
    }
    // 村庄房屋：cols 19-26 rows 3-9，留出纵向道路（col 21、24）与横向道路（row 5、7、9）
    for col in [19, 20, 22, 23, 25, 26] {
        for row in [3, 4, 6, 8] {
            map.add_building(col, row);
        }
    }
    // 西面森林（cols 6-18 rows 8-12），留出两条林中小道 row 9、row 11
    for col in 6..=18 {
        for row in 8..=12 {
            if row == 9 || row == 11 {
                continue; // 林中小道
            }
            map.add_forest(col, row);
        }
    }
    // 村庄南面森林（cols 19-26 rows 10-12），row 11 为第二条小道（绕村南侧）
    for col in 19..=26 {
        for row in [10, 12] {
            map.add_forest(col, row);
        }
    }
}

/// 侦察结果：`terrain` = 地形可见的格子（BFS 最短路程 ≤ 视野）；
/// `enemy_units` = 被侦察到的敌方单位所在格（考虑隐蔽：隐蔽 2 的步兵
/// 处于森林/建筑中时，BFS 路程阈值再减 2，需更近才能发现）。
///
/// BFS 最短路程：从观测单位出发沿相邻格扩展，岩石不可达、楼房可见但不可
/// 穿透，森林每格计 2 步（森林减弱视野），其余地形 1 步。
pub struct VisionResult {
    pub terrain: BTreeSet<Hex>,
    pub enemy_units: BTreeSet<Hex>,
    /// 每格到最近己方单位的 BFS 路程（及其视野值），用于界面分层迷雾：
    /// 距离 ≤ 视野/隐蔽值 才可能发现该格上的单位。
    pub dist: HashMap<Hex, (i32, i32)>,
}

impl GameState {
    pub fn new() -> Self {
        Self::new_seeded(rand::random())
    }

    /// 部署模式开局（默认关卡）：双方各有 100 招募点，地图为空，进入部署阶段。
    pub fn new_deploy(seed: u64) -> Self {
        Self::new_seeded(seed).into_deploy()
    }

    /// 指定关卡进入部署模式。
    pub fn new_deploy_level(seed: u64, level: Level) -> Self {
        Self::new_seeded_level(seed, level).into_deploy()
    }

    /// 把一个标准对局（已部署）转为部署模式：清空双方单位并进入部署阶段。
    fn into_deploy(mut self) -> Self {
        self.units.clear();
        self.air_units.clear();
        self.deploying = true;
        self.deploy_done.insert(Team::Player, false);
        self.deploy_done.insert(Team::Ai, false);
        self
    }

    pub fn new_seeded(seed: u64) -> Self {
        Self::new_seeded_level(seed, Level::OpenField)
    }

    pub fn new_seeded_level(seed: u64, level: Level) -> Self {
        let mut map = GameMap::new(27, 13);
        match level {
            Level::OpenField => build_open_field(&mut map),
            Level::VillageDefense => build_village_defense(&mut map),
            Level::Custom => {}
        }
        let mut gs = GameState {
            map,
            level,
            custom: None,
            units: BTreeMap::new(),
            air_units: BTreeMap::new(),
            turn: 0,
            phase: Team::Player,
            rng: ChaCha12Rng::seed_from_u64(seed),
            seed,
            winner: None,
            event_log: Vec::new(),
            battle_events: Vec::new(),
            battle_seq: 0,
            ghosts: BTreeMap::new(),
            last_kill_turn: 0,
            deploying: false,
            next_label_seq: BTreeMap::new(),
            notices: BTreeMap::new(),
            recruit_points: BTreeMap::new(),
            deploy_done: BTreeMap::new(),
            smoke: BTreeMap::new(),
            revealed_by_contact: BTreeMap::new(),
            killed_hexes: Vec::new(),
            fog_fire_marks: BTreeMap::new(),
            sustain: false,
            sustain_per_turn: BTreeMap::new(),
            sustain_deploying: false,
            initial_points: BTreeMap::new(),
            killed_value: BTreeMap::new(),
            hq_seen: BTreeMap::new(),
            keypoints: BTreeMap::new(),
            deploy_regions: BTreeMap::new(),
            ai_recruit_plan: BTreeMap::new(),
            ai_configs: BTreeMap::new(),
            ai_version: AiVersion::Legacy,
            ai_difficulty: AiDifficulty::Regular,
            vis_cache: BTreeMap::new(),
            company: BTreeMap::new(),
            aa_count_last: BTreeMap::new(),
            test_mode: false,
            test_placing: false,
            test_place_team: Team::Player,
            recruit_zone_turn: 0,
            ui_events: Vec::new(),
        };
        // 招募点数按关卡：村庄防守关 AI 略多（玩家 150 / AI 300）
        let (pp, ap) = match level {
            Level::OpenField => (100, 100),
            Level::VillageDefense => (150, 300),
            Level::Custom => (100, 100),
        };
        gs.recruit_points.insert(Team::Player, pp);
        gs.recruit_points.insert(Team::Ai, ap);
        gs.initial_points.insert(Team::Player, pp);
        gs.initial_points.insert(Team::Ai, ap);
        gs.deploy_done.insert(Team::Player, true);
        gs.deploy_done.insert(Team::Ai, true);

        // 玩家（地图左侧）14 个单位：坦克×2、步枪手×2、TOW射手×2、
        // 步兵战车 D、卡车 E、榴弹炮 F、武装直升机 G、运输直升机 H、
        // 防空导弹手 I、M-SHORAD J、防空导弹发射车 K、坦克2 L、步枪手2 M、TOW射手2 N
        gs.spawn(UnitKind::Howitzer, Team::Player, hex::axial_from_offset(0, 0), 'F');
        gs.spawn(UnitKind::AaLauncher, Team::Player, hex::axial_from_offset(1, 0), 'K');
        gs.spawn(UnitKind::AttackHeli, Team::Player, hex::axial_from_offset(0, 1), 'G');
        gs.spawn(UnitKind::AaInfantry, Team::Player, hex::axial_from_offset(1, 1), 'I');
        gs.spawn(UnitKind::Truck, Team::Player, hex::axial_from_offset(0, 2), 'E');
        gs.spawn(UnitKind::AaMgv, Team::Player, hex::axial_from_offset(1, 2), 'J');
        gs.spawn(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(0, 3), 'B');
        gs.spawn(UnitKind::Tank, Team::Player, hex::axial_from_offset(1, 3), 'A');
        gs.spawn(UnitKind::Atgm, Team::Player, hex::axial_from_offset(0, 4), 'C');
        gs.spawn(UnitKind::Tank, Team::Player, hex::axial_from_offset(1, 4), 'L');
        gs.spawn(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(0, 5), 'M');
        gs.spawn(UnitKind::Atgm, Team::Player, hex::axial_from_offset(1, 5), 'N');
        gs.spawn(UnitKind::TransportHeli, Team::Player, hex::axial_from_offset(0, 6), 'H');
        gs.spawn(UnitKind::Ifv, Team::Player, hex::axial_from_offset(1, 6), 'D');
        // AI（地图右侧）14 个单位：标签 1-9 与 a-e
        gs.spawn(UnitKind::Howitzer, Team::Ai, hex::axial_from_offset(26, 0), '6');
        gs.spawn(UnitKind::AaLauncher, Team::Ai, hex::axial_from_offset(25, 0), 'b');
        gs.spawn(UnitKind::AttackHeli, Team::Ai, hex::axial_from_offset(26, 1), '7');
        gs.spawn(UnitKind::AaInfantry, Team::Ai, hex::axial_from_offset(25, 1), '9');
        gs.spawn(UnitKind::Truck, Team::Ai, hex::axial_from_offset(26, 2), '5');
        gs.spawn(UnitKind::AaMgv, Team::Ai, hex::axial_from_offset(25, 2), 'a');
        gs.spawn(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(26, 3), '2');
        gs.spawn(UnitKind::Tank, Team::Ai, hex::axial_from_offset(25, 3), '1');
        gs.spawn(UnitKind::Atgm, Team::Ai, hex::axial_from_offset(26, 4), '3');
        gs.spawn(UnitKind::Tank, Team::Ai, hex::axial_from_offset(25, 4), 'c');
        gs.spawn(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(26, 5), 'd');
        gs.spawn(UnitKind::Atgm, Team::Ai, hex::axial_from_offset(25, 5), 'e');
        gs.spawn(UnitKind::TransportHeli, Team::Ai, hex::axial_from_offset(26, 6), '8');
        gs.spawn(UnitKind::Ifv, Team::Ai, hex::axial_from_offset(25, 6), '4');
        gs
    }

    /// 多人持续部署开局：与 `new_seeded_level` 相同的地图与初始点数，但**不预置任何棋子**
    /// ——双方所有单位都要自行招募。首个招募回合（第 1 回合）可在本方出发区域任意空格
    /// 招募，第 2 回合起只能在大本营中心周围 2 格内（见 `recruit_unit`）。
    pub fn new_sustain_multiplayer(seed: u64, level: Level) -> Self {
        let mut g = Self::new_seeded_level(seed, level);
        g.units.clear();
        g.air_units.clear();
        g.recruit_zone_turn = 1;
        g
    }

    /// 出发区域列：玩家=最西 4 列；AI 按关卡（开阔地=最东 4 列，村庄=村庄区域）；
    /// 自定义地图用编辑器设定的部署列。
    ///
    /// 战役地图（逐格部署区）返回这些格子所在列的并集，供仍按列工作的旧 AI/文本逻辑使用；
    /// 精确的逐格判定请用 in_deploy_zone / deploy_cells。
    pub fn deploy_zone(&self, team: Team) -> Vec<i32> {
        if self.level == Level::Custom {
            // 战役地图：返回逐格部署区所在列的并集（精确判定走 in_deploy_zone）。
            if let Some(cells) = self.campaign_cells(team) {
                let mut cols: Vec<i32> = cells.iter().map(|(c, _)| *c).collect();
                cols.sort_unstable();
                cols.dedup();
                return cols;
            }
            return match team {
                Team::Player => self
                    .custom
                    .as_ref()
                    .map(|c| c.player_cols.clone())
                    .unwrap_or_default(),
                Team::Ai => self
                    .custom
                    .as_ref()
                    .map(|c| c.ai_cols.clone())
                    .unwrap_or_default(),
            };
        }
        match (self.level, team) {
            (_, Team::Player) => (0..4).collect(),
            (Level::OpenField, Team::Ai) => ((self.map.cols - 4)..self.map.cols).collect(),
            (Level::VillageDefense, Team::Ai) => (19..self.map.cols).collect(),
            (Level::Custom, _) => Vec::new(), // 上面已处理
        }
    }

    /// 战役地图的逐格部署区（若未绘制则回落到列部署区）。
    pub fn campaign_cells(&self, team: Team) -> Option<&Vec<(i32, i32)>> {
        let c = self.custom.as_ref()?;
        if !c.campaign {
            return None;
        }
        let cells = match team {
            Team::Player => &c.player_cells,
            Team::Ai => &c.ai_cells,
        };
        if cells.is_empty() {
            None
        } else {
            Some(cells)
        }
    }

    /// 本方出发区域内所有可放置格（精确到单格；非战役地图 = 部署列内全部格）。
    /// 战役地图返回所有**大本营仍由本方控制**的连通区格子；初始招募与增援部署共用。
    pub fn deploy_cells(&self, team: Team) -> Vec<Hex> {
        if self.custom.as_ref().map(|c| c.campaign).unwrap_or(false) {
            if let Some(regions) = self.deploy_regions.get(&team) {
                if !regions.is_empty() {
                    let mut v = Vec::new();
                    for r in regions {
                        if self.hq_controlled_by(r.hq, team) {
                            v.extend(r.cells.iter().copied());
                        }
                    }
                    return v;
                }
            }
            // 未建立连通区（加载前/旧地图）时回落到绘制的部署格
            if let Some(cells) = self.campaign_cells(team) {
                return cells
                    .iter()
                    .map(|(c, r)| hex::axial_from_offset(*c, *r))
                    .collect();
            }
        }
        let mut v = Vec::new();
        for col in self.deploy_zone(team) {
            for row in 0..self.map.rows {
                v.push(hex::axial_from_offset(col, row));
            }
        }
        v
    }

    /// 某格是否属于本方当前可用的出发区域（战役地图按大本营连通区逐格判定）。
    pub fn in_deploy_zone(&self, team: Team, pos: Hex) -> bool {
        if self.custom.as_ref().map(|c| c.campaign).unwrap_or(false) {
            if let Some(regions) = self.deploy_regions.get(&team) {
                if !regions.is_empty() {
                    return regions
                        .iter()
                        .any(|r| self.hq_controlled_by(r.hq, team) && r.cells.contains(&pos));
                }
            }
            if let Some(cells) = self.campaign_cells(team) {
                let (col, row) = hex::offset_from_axial(pos);
                return cells.contains(&(col, row));
            }
        }
        let (col, _) = hex::offset_from_axial(pos);
        self.deploy_zone(team).contains(&col)
    }

    /// 大本营 `hq` 当前是否仍由 `team` 控制（战役连通区是否可用）。
    pub fn hq_controlled_by(&self, hq: Hex, team: Team) -> bool {
        self.keypoints
            .get(&hq)
            .map(|kp| kp.center && kp.controller == team)
            .unwrap_or(false)
    }

    /// 用编辑器制作的自定义地图开局（部署模式）。返回 (GameState, 地图显示名)。
    pub fn new_custom_deploy(seed: u64, custom: CustomMap) -> Self {
        let mut map = GameMap::new(custom.cols, custom.rows);
        for (c, r) in &custom.obstacles {
            map.add_obstacle(*c, *r);
        }
        for (c, r) in &custom.forests {
            map.add_forest(*c, *r);
        }
        for (c, r) in &custom.buildings {
            map.add_building(*c, *r);
        }
        for (c, r) in &custom.water {
            map.add_water(*c, *r);
        }
        for (c, r) in &custom.roads {
            map.add_road(*c, *r);
        }
        let mut gs = GameState {
            map,
            level: Level::Custom,
            custom: Some(custom),
            units: BTreeMap::new(),
            air_units: BTreeMap::new(),
            turn: 0,
            phase: Team::Player,
            rng: ChaCha12Rng::seed_from_u64(seed),
            seed,
            winner: None,
            event_log: Vec::new(),
            battle_events: Vec::new(),
            battle_seq: 0,
            ghosts: BTreeMap::new(),
            last_kill_turn: 0,
            deploying: false,
            next_label_seq: BTreeMap::new(),
            notices: BTreeMap::new(),
            recruit_points: BTreeMap::new(),
            deploy_done: BTreeMap::new(),
            smoke: BTreeMap::new(),
            revealed_by_contact: BTreeMap::new(),
            killed_hexes: Vec::new(),
            fog_fire_marks: BTreeMap::new(),
            sustain: false,
            sustain_per_turn: BTreeMap::new(),
            sustain_deploying: false,
            initial_points: BTreeMap::new(),
            killed_value: BTreeMap::new(),
            hq_seen: BTreeMap::new(),
            keypoints: BTreeMap::new(),
            deploy_regions: BTreeMap::new(),
            ai_recruit_plan: BTreeMap::new(),
            ai_configs: BTreeMap::new(),
            ai_version: AiVersion::Legacy,
            ai_difficulty: AiDifficulty::Regular,
            vis_cache: BTreeMap::new(),
            company: BTreeMap::new(),
            aa_count_last: BTreeMap::new(),
            test_mode: false,
            test_placing: false,
            test_place_team: Team::Player,
            recruit_zone_turn: 0,
            ui_events: Vec::new(),
        };
        let (pp, ap) = gs
            .custom
            .as_ref()
            .map(|c| (c.player_points, c.ai_points))
            .unwrap_or((100, 100));
        gs.recruit_points.insert(Team::Player, pp);
        gs.recruit_points.insert(Team::Ai, ap);
        gs.initial_points.insert(Team::Player, pp);
        gs.initial_points.insert(Team::Ai, ap);
        // 桥头堡之战（40×30 中央河流 + 3 座桥、AI 400 点）：AI 默认使用
        // 优化后的连排指挥官（机械化强攻 5 排，400 点专项训练冠军），
        // 其余地图沿用默认 AI（稳守反击）；调用方可覆盖 ai_configs。
        if gs.custom.as_ref().map(|c| c.name.contains("桥头堡")).unwrap_or(false) {
            gs.ai_configs.insert(Team::Ai, company_champion_400());
            gs.ai_configs.insert(Team::Player, company_champion_400());
        }
        // 战役模式：预置棋子与指定大本营据点已在编辑器中确定，直接开战。
        // 第 1 回合为「首个招募回合」，可在绘制的逐格部署区内招募（招募即可行动）；
        // 第 2 回合起在大本营中心周围 2 格内追加部署（与持续部署模式一致）。
        if gs.custom.as_ref().map(|c| c.campaign).unwrap_or(false) {
            gs.apply_campaign_setup();
            gs.deploying = false;
            gs.deploy_done.insert(Team::Player, true);
            gs.deploy_done.insert(Team::Ai, true);
            gs.recruit_zone_turn = 1;
            let (pi, ai_i) = gs
                .custom
                .as_ref()
                .map(|c| (c.player_income, c.ai_income))
                .unwrap_or((10, 10));
            gs.enable_sustain(pi, ai_i);
            gs.begin_turn(Team::Player);
            return gs;
        }
        gs.into_deploy()
    }

    /// 战役地图：把编辑器预置的棋子与指定的大本营/关键据点放入对局。
    /// 地面/空中棋子分层放置（同层一格一枚，空中可与地面同格）；跳过被占用的同层格。
    fn apply_campaign_setup(&mut self) {
        let Some(custom) = self.custom.clone() else {
            return;
        };
        for kp in &custom.keypoints {
            let h = hex::axial_from_offset(kp.col, kp.row);
            self.keypoints.insert(
                h,
                Keypoint {
                    owner: kp.team,
                    controller: kp.team,
                    center: kp.center,
                },
            );
        }
        self.rebuild_deploy_regions();
        for pu in &custom.units {
            let h = hex::axial_from_offset(pu.col, pu.row);
            if !self.map.contains(h) {
                continue;
            }
            let occupied = if pu.kind.is_air() {
                self.air_units.contains_key(&h)
            } else {
                self.units.contains_key(&h)
            };
            if occupied {
                continue;
            }
            let label = self.next_label(pu.team);
            self.spawn_with_cargo(pu.kind, pu.team, h, label, &pu.passengers);
        }
        let mine = custom.units.iter().filter(|u| u.team == Team::Player).count();
        let foe = custom.units.iter().filter(|u| u.team == Team::Ai).count();
        let hqs = custom.keypoints.iter().filter(|k| k.center).count();
        let objs = custom.keypoints.iter().filter(|k| !k.center).count();
        self.elog(format!(
            "🏛 战役地图「{}」：预置 {} 蓝方 / {} 红方棋子，{} 座大本营、{} 个关键据点；胜利条件 蓝={} / 红={}",
            custom.name,
            mine,
            foe,
            hqs,
            objs,
            custom.player_victory.label(),
            custom.ai_victory.label()
        ));
    }

    /// 战役地图：按大本营连通区重建可部署区域（编辑器已校验每片只连一个大本营）。
    fn rebuild_deploy_regions(&mut self) {
        self.deploy_regions.clear();
        let Some(custom) = self.custom.clone() else {
            return;
        };
        if !custom.campaign {
            return;
        }
        for team in [Team::Player, Team::Ai] {
            let cells: Vec<Hex> = custom
                .deploy_cells_of(team)
                .iter()
                .map(|(c, r)| hex::axial_from_offset(*c, *r))
                .collect();
            if cells.is_empty() {
                continue;
            }
            let cell_set: BTreeSet<Hex> = cells.iter().copied().collect();
            let hqs: Vec<Hex> = self
                .keypoints
                .iter()
                .filter(|(_, kp)| kp.owner == team && kp.center)
                .map(|(h, _)| *h)
                .collect();
            let mut visited: BTreeSet<Hex> = BTreeSet::new();
            for start in &cell_set {
                if visited.contains(start) {
                    continue;
                }
                let mut comp: Vec<Hex> = Vec::new();
                let mut q: VecDeque<Hex> = VecDeque::new();
                q.push_back(*start);
                visited.insert(*start);
                while let Some(h) = q.pop_front() {
                    comp.push(h);
                    for n in h.neighbors() {
                        if cell_set.contains(&n) && visited.insert(n) {
                            q.push_back(n);
                        }
                    }
                }
                let hq = hqs
                    .iter()
                    .copied()
                    .find(|hq| comp.contains(hq) || comp.iter().any(|c| Hex::distance(*c, *hq) == 1));
                if let Some(hq) = hq {
                    self.deploy_regions
                        .entry(team)
                        .or_default()
                        .push(DeployRegion { hq, cells: comp });
                }
            }
        }
    }

    /// 部署阶段放置一个招募的单位。校验：部署阶段、点数足够、出发区域内、
    /// 格子为空、地面单位不上岩石、车辆不进楼房。返回错误信息或单位标签。
    pub fn deploy_unit(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
    ) -> Result<char, String> {
        self.deploy_unit_with_cargo(team, kind, pos, &[])
    }

    /// 同 `deploy_unit`，但可一次性部署**已装载 cargo 的运输单位**：
    /// 按「载具 + 货物」总费用扣点，货物受运力与兵种规则限制。
    pub fn deploy_unit_with_cargo(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
        cargo: &[UnitKind],
    ) -> Result<char, String> {
        if !self.deploying {
            return Err("当前不在部署阶段".into());
        }
        let total = kind.loaded_recruit_cost(cargo)?;
        let pts = *self.recruit_points.get(&team).unwrap_or(&0);
        if total > pts {
            return Err(format!(
                "招募点数不足（{} 需要 {} 点，剩余 {}）",
                kind.name(),
                total,
                pts
            ));
        }
        if self.unit_at(pos).is_some() {
            return Err("该格已有单位".into());
        }
        if !self.map.contains(pos) {
            return Err("超出地图".into());
        }
        // 出发区域：按关卡计算（玩家=西边，AI=东边/村庄；战役地图按单格精度）
        if !self.in_deploy_zone(team, pos) {
            return Err("只能在己方出发区域部署".into());
        }
        self.check_recruit_terrain(kind, pos)?;
        self.recruit_points.insert(team, pts - total);
        let label = self.next_label(team);
        self.spawn_with_cargo(kind, team, pos, label, cargo);
        self.elog(format!(
            "部署 {} {} {} @{}{}（{} 点）",
            team.cn(),
            label,
            kind.name(),
            hex::hex_label(pos),
            cargo_suffix(cargo),
            total
        ));
        Ok(label)
    }

    /// 可持续部署：追加部署一个新单位到大本营区域（GUI 点击式）。
    /// 校验：sustain 开启且处于追加部署状态、点数足够、区域内、格子为空、
    /// 大本营格未被敌军占领（距敌军 ≤5 不可部署）、地形合法。
    /// 追加部署的单位**本回合无行动次数**（下回合才可行动）。
    pub fn reinforce_unit(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
    ) -> Result<char, String> {
        self.reinforce_unit_impl(team, kind, pos, true, &[])
    }

    /// 同 `reinforce_unit`，但可一次性追加部署**已装载 cargo 的运输单位**。
    pub fn reinforce_unit_with_cargo(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
        cargo: &[UnitKind],
    ) -> Result<char, String> {
        self.reinforce_unit_impl(team, kind, pos, true, cargo)
    }

    /// 命令式追加部署（多人终端 / agent 指挥）：sustain 模式且轮到本方即可部署，
    /// 不依赖 GUI 的「追加部署」切换状态（sustain_deploying）——终端没有点击式
    /// 放置流程，dp 命令本身就是部署意图。其余规则与 reinforce_unit 完全一致。
    pub fn reinforce_unit_now(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
    ) -> Result<char, String> {
        self.reinforce_unit_impl(team, kind, pos, false, &[])
    }

    /// 同 `reinforce_unit_now`，但可一次性追加部署已装载 cargo 的运输单位。
    pub fn reinforce_unit_now_with_cargo(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
        cargo: &[UnitKind],
    ) -> Result<char, String> {
        self.reinforce_unit_impl(team, kind, pos, false, cargo)
    }

    fn reinforce_unit_impl(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
        require_deploying: bool,
        cargo: &[UnitKind],
    ) -> Result<char, String> {
        if !self.sustain {
            return Err("当前未启用可持续部署模式".into());
        }
        if require_deploying && !self.sustain_deploying {
            return Err("当前不在追加部署阶段（对局中按 d 进入）".into());
        }
        let total = kind.loaded_recruit_cost(cargo)?;
        let pts = *self.recruit_points.get(&team).unwrap_or(&0);
        if total > pts {
            return Err(format!(
                "部署点数不足（{} 需要 {} 点，剩余 {}）",
                kind.name(),
                total,
                pts
            ));
        }
        if self.unit_at(pos).is_some() {
            return Err("该格已有单位".into());
        }
        if !self.map.contains(pos) {
            return Err("超出地图".into());
        }
        // 部署区域：战役地图与初始招募使用完全相同的「大本营连通区」，
        // 大本营失守则对应区域停用；其他模式仍限定在大本营周围 2 格内。
        let is_campaign = self.custom.as_ref().map(|c| c.campaign).unwrap_or(false);
        if is_campaign {
            if !self.in_deploy_zone(team, pos) {
                return Err(
                    "只能部署在本方当前可用的可部署区域（须与大本营连通且大本营未被敌方占领）"
                        .into(),
                );
            }
        } else {
            let hq = self.hq_pos(team).ok_or("本方指挥部不存在")?;
            if Hex::distance(hq, pos) > 2 {
                return Err(format!(
                    "只能部署在指挥部（{}）周围 2 格范围内（目标距离 {} 格）",
                    hex::hex_label(hq),
                    Hex::distance(hq, pos)
                ));
            }
        }
        if self.zone_occupied(team, pos) {
            return Err(format!(
                "{} 距敌方地面单位 ≤5 格，不可部署",
                hex::hex_label(pos)
            ));
        }
        self.check_recruit_terrain(kind, pos)?;
        self.recruit_points.insert(team, pts - total);
        let label = self.next_label(team);
        self.spawn_with_cargo(kind, team, pos, label, cargo);
        // 追加部署的单位本回合不可行动（到下回合才可行动）
        if let Some(u) = self.unit_at_mut(pos) {
            u.actions_left = 0;
        }
        self.elog(format!(
            "🛠 增援部署 {} {} {} @{}{}（本回合不可行动，{} 点）",
            team.cn(),
            label,
            kind.name(),
            hex::hex_label(pos),
            cargo_suffix(cargo),
            total
        ));
        Ok(label)
    }

    /// 多人招募：空地图开局时双方全部单位都要自行招募。
    /// - 首个招募回合（`recruit_zone_turn`，默认第 1 回合）内：可在**本方出发区域**
    ///   任意空格招募（与部署阶段同一片区域，按关卡/自定义地图而定）；
    /// - 之后：只能在大本营中心周围 2 格内追加部署（沿用 `reinforce_unit` 规则）；
    ///   若该局没有大本营（经典模式），则仍在本方出发区域内招募。
    /// 首个招募回合招募的单位**本回合即可行动**（相当于把部署阶段放进第 1 回合）；
    /// 之后追加部署的单位当回合不可行动。
    pub fn recruit_unit(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
    ) -> Result<char, String> {
        self.recruit_unit_with_cargo(team, kind, pos, &[])
    }

    /// 同 `recruit_unit`，但可一次性招募**已装载 cargo 的运输单位**。
    pub fn recruit_unit_with_cargo(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
        cargo: &[UnitKind],
    ) -> Result<char, String> {
        if self.recruit_zone_turn <= 0 {
            return Err("当前对局未启用招募模式（本局为预置部队开局）".into());
        }
        if self.turn <= self.recruit_zone_turn {
            return self.recruit_in_deploy_zone(team, kind, pos, cargo);
        }
        if self.hq_pos(team).is_some() {
            return self.reinforce_unit_now_with_cargo(team, kind, pos, cargo);
        }
        self.recruit_in_deploy_zone(team, kind, pos, cargo)
    }

    /// 出发区域招募（首个招募回合 / 没有大本营时使用）：
    /// 校验点数、空格、本方出发区域列与地形；新单位本回合即可行动。
    fn recruit_in_deploy_zone(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
        cargo: &[UnitKind],
    ) -> Result<char, String> {
        let total = kind.loaded_recruit_cost(cargo)?;
        let pts = *self.recruit_points.get(&team).unwrap_or(&0);
        if total > pts {
            return Err(format!(
                "招募点数不足（{} 需要 {} 点，剩余 {}）",
                kind.name(),
                total,
                pts
            ));
        }
        if self.unit_at(pos).is_some() {
            return Err("该格已有单位".into());
        }
        if !self.map.contains(pos) {
            return Err("超出地图".into());
        }
        if !self.in_deploy_zone(team, pos) {
            let cols: Vec<String> = self
                .deploy_zone(team)
                .iter()
                .map(|c| (c + 1).to_string())
                .collect();
            return Err(format!(
                "只能在本方出发区域招募（战役地图为绘制的部署格；其他地图为 {} 列）",
                cols.join(",")
            ));
        }
        // 战役地图：初始招募与增援部署使用完全相同的规则（含「距敌军 ≤5 格不可用」），
        // 保证不会出现「初始可放、开战后只能在更小范围放」的情况。
        if self.custom.as_ref().map(|c| c.campaign).unwrap_or(false)
            && self.zone_occupied(team, pos)
        {
            return Err(format!(
                "{} 距敌方地面单位 ≤5 格，不可部署",
                hex::hex_label(pos)
            ));
        }
        self.check_recruit_terrain(kind, pos)?;
        self.recruit_points.insert(team, pts - total);
        let label = self.next_label(team);
        self.spawn_with_cargo(kind, team, pos, label, cargo);
        self.elog(format!(
            "🛠 招募 {} {} {} @{}{}（{} 点）",
            team.cn(),
            label,
            kind.name(),
            hex::hex_label(pos),
            cargo_suffix(cargo),
            total
        ));
        Ok(label)
    }

    /// 招募地形校验：地面单位不上岩石/水域，车辆不进楼房（空中单位不受限）。
    fn check_recruit_terrain(&self, kind: UnitKind, pos: Hex) -> Result<(), String> {
        if kind.is_air() {
            return Ok(());
        }
        if self.map.obstacles.contains(&pos) {
            return Err("岩石上不能部署地面单位".into());
        }
        if self.map.water.contains(&pos) {
            return Err("水域上不能部署地面单位".into());
        }
        if self.map.buildings.contains(&pos) && !kind.is_foot() {
            return Err("车辆不能部署在楼房内".into());
        }
        Ok(())
    }

    /// 试验模式：在地图任意空位放置一方棋子（不消耗部署点数）。
    /// 校验：试验模式已开启、格子为空、地面单位不上岩石/水域、车辆不进楼房。
    /// 新放置的单位按正常行动次数初始化，便于立即试验。
    pub fn test_place_unit(
        &mut self,
        team: Team,
        kind: UnitKind,
        pos: Hex,
    ) -> Result<char, String> {
        if !self.test_mode {
            return Err("当前未开启试验模式".into());
        }
        if self.unit_at(pos).is_some() {
            return Err("该格已有单位".into());
        }
        if !self.map.contains(pos) {
            return Err("超出地图".into());
        }
        if !kind.is_air() {
            if self.map.obstacles.contains(&pos) {
                return Err("岩石上不能放置地面单位".into());
            }
            if self.map.water.contains(&pos) {
                return Err("水域上不能放置地面单位".into());
            }
            if self.map.buildings.contains(&pos) && !kind.is_foot() {
                return Err("车辆不能放置在楼房内".into());
            }
        }
        let label = self.next_label(team);
        self.spawn(kind, team, pos, label);
        if let Some(u) = self.unit_at_mut(pos) {
            u.actions_left = u.kind.action_count();
        }
        self.elog(format!(
            "🧪 试验放置 {} {} {} @{}",
            team.cn(),
            label,
            kind.name(),
            hex::hex_label(pos)
        ));
        Ok(label)
    }

    /// 从部署阶段直接进入试验模式：
    /// - 立即结束部署，保留已部署棋子；
    /// - 清空双方大本营/关键据点；
    /// - 关闭可持续部署、追加部署、费用等设定；
    /// - 自动进入放置棋子模式，方便立即自由放置双方棋子。
    pub fn enter_test_mode(&mut self) {
        self.test_mode = true;
        self.test_placing = true;
        self.deploying = false;
        self.deploy_done.insert(Team::Player, true);
        self.deploy_done.insert(Team::Ai, true);
        self.sustain = false;
        self.sustain_deploying = false;
        self.sustain_per_turn.clear();
        self.keypoints.clear();
        self.hq_seen.clear();
        // 同时清掉可能存在的指挥部棋子（当前版本大本营通常以关键据点表示）
        self.units.retain(|_, u| u.kind != UnitKind::Headquarters);
        self.air_units.retain(|_, u| u.kind != UnitKind::Headquarters);
        self.elog("🧪 进入试验模式：大本营已清空，可自由放置双方棋子".to_string());
    }

    /// 部署阶段撤销：移除 pos 处本方单位并返还招募点数。
    pub fn undeploy_unit(&mut self, team: Team, pos: Hex) -> Result<i32, String> {
        if !self.deploying {
            return Err("当前不在部署阶段".into());
        }
        let u = self.unit_at(pos).ok_or("该格没有单位")?.clone();
        if u.team != team {
            return Err("不能撤销对方单位".into());
        }
        self.remove_unit(pos);
        let pts = self.recruit_points.get(&team).copied().unwrap_or(0);
        let refund = u.kind.recruit_cost()
            + u.passengers
                .iter()
                .map(|p| p.kind.recruit_cost())
                .sum::<i32>();
        self.recruit_points.insert(team, pts + refund);
        self.elog(format!(
            "撤销部署 {} {} @{}（返还 {} 点）",
            team.cn(),
            u.name_with_label(),
            hex::hex_label(pos),
            refund
        ));
        Ok(refund)
    }

    /// 撤退（主动撤离战场）：仅当单位位于**本方出发区域**（可部署区）内时可用。
    ///
    /// 单位立即消失（含车上搭载的单位），玩家按
    /// 「初始招募费用 × 当前 HP / 总 HP」获得招募点数补偿（四舍五入；搭载单位一并折算）。
    /// 撤退不属于被歼灭：不计入战损/被歼灭点数，也不触发"全灭"判负。
    pub fn retreat_unit(&mut self, team: Team, pos: Hex) -> Result<i32, String> {
        let u = self.unit_at(pos).ok_or("该格没有单位")?.clone();
        if u.team != team {
            return Err("不能撤退对方单位".into());
        }
        if u.kind == UnitKind::Headquarters {
            return Err("大本营不可撤退".into());
        }
        if !self.in_deploy_zone(team, pos) {
            return Err("只有位于本方出发区域内的单位才能撤退".into());
        }
        let refund = Self::retreat_refund(&u);
        self.remove_unit_inner(pos, false);
        let pts = self.recruit_points.get(&team).copied().unwrap_or(0);
        self.recruit_points.insert(team, pts + refund);
        self.elog(format!(
            "🏳 {} {} 从 {} 撤退（按血量返还 {} 点招募点）",
            team.cn(),
            u.name_with_label(),
            hex::hex_label(pos),
            refund
        ));
        Ok(refund)
    }

    /// 该格单位当前是否可以选择"撤退"（本方单位 + 位于本方出发区域）。
    pub fn can_retreat(&self, team: Team, pos: Hex) -> bool {
        match self.unit_at(pos) {
            Some(u) => {
                u.team == team
                    && u.kind != UnitKind::Headquarters
                    && self.in_deploy_zone(team, pos)
            }
            None => false,
        }
    }

    /// 撤退返还点数：招募费用 × 当前 HP / 总 HP（四舍五入），搭载单位一并折算。
    pub fn retreat_refund(u: &Unit) -> i32 {
        let max_hp = u.kind.max_hp().max(1);
        let hp = u.hp.clamp(0, max_hp);
        let own = (u.kind.recruit_cost() * hp + max_hp / 2) / max_hp;
        own + u.passengers.iter().map(Self::retreat_refund).sum::<i32>()
    }

    /// 完成部署：AI 尚未部署时自动部署，随后进入第 1 回合玩家行动阶段。
    pub fn finish_deploy(&mut self) -> Result<Vec<String>, String> {
        if !self.deploying {
            return Err("当前不在部署阶段".into());
        }
        let mut log = Vec::new();
        if !self.deploy_done.get(&Team::Ai).copied().unwrap_or(false) {
            log.extend(crate::ai_router::ai_deploy(self, Team::Ai));
        }
        self.deploying = false;
        self.winner = None; // 部署阶段撤销可能残留的误判胜负，开战前复位
        self.deploy_done.insert(Team::Player, true);
        self.deploy_done.insert(Team::Ai, true);
        self.elog("—— 部署完成，战斗开始 ——");
        // 可持续部署模式：双方大本营区域内各设 3 个关键据点（中心 + 2 个随机格）
        if self.sustain {
            self.spawn_keypoints(Team::Player);
            self.spawn_keypoints(Team::Ai);
        }
        self.begin_turn(Team::Player);
        self.turn = 0;
        Ok(log)
    }

    /// 在 team 的部署区域内随机设立大本营中心格（必不位于岩石/水域；避开已有单位），
    /// 并从其半径 2 区域内随机选 2 个非中心格，共同构成该方 3 个"关键据点"。
    /// 大本营不再是单位：不可被攻击，只有陆军棋子踏入敌方据点才能占领/夺回。
    fn spawn_keypoints(&mut self, team: Team) {
        let zone = self.deploy_zone(team);
        let mut cands: Vec<Hex> = Vec::new();
        for &col in &zone {
            for row in 0..self.map.rows {
                let h = hex::axial_from_offset(col, row);
                if self.map.obstacles.contains(&h) || self.map.water.contains(&h) {
                    continue; // 大本营中心必不位于岩石/水域上
                }
                cands.push(h); // 据点可叠在已有单位格（标记而已；陆军踏入才算占领）
            }
        }
        if cands.is_empty() {
            return;
        }
        let idx = {
            use rand::Rng;
            self.rng.gen_range(0..cands.len())
        };
        let center = cands[idx];
        // 半径 2 枚举：中心 6 邻 + 每个 6 邻的外围格
        let mut seen: Vec<Hex> = Vec::new();
        for n in center.neighbors() {
            for h in n.neighbors() {
                if h == center {
                    continue;
                }
                if !self.map.contains(h) {
                    continue;
                }
                if self.map.obstacles.contains(&h) || self.map.water.contains(&h) {
                    continue;
                }
                if !seen.contains(&h) {
                    seen.push(h);
                }
            }
        }
        let mut chosen: Vec<Hex> = Vec::new();
        if !seen.is_empty() {
            let n = seen.len();
            let i1 = self.rng.gen_range(0..n);
            chosen.push(seen[i1]);
            if n >= 2 {
                let i2 = self.rng.gen_range(0..n - 1);
                let mut j = i2;
                if j >= i1 {
                    j += 1;
                }
                chosen.push(seen[j]);
            }
        }
        self.keypoints.insert(
            center,
            Keypoint {
                owner: team,
                controller: team,
                center: true,
            },
        );
        for h in &chosen {
            self.keypoints.insert(
                *h,
                Keypoint {
                    owner: team,
                    controller: team,
                    center: false,
                },
            );
        }
        let names: Vec<String> = std::iter::once(center)
            .chain(chosen.iter().copied())
            .map(hex::hex_label)
            .collect();
        self.elog(format!(
            "🏛 {} 的大本营设于 {}，关键据点：{}",
            team.cn(),
            hex::hex_label(center),
            names.join(" / ")
        ));
    }

    /// 标签候选池：**双方一律使用数字**（蓝方与红方各自从 1 开始编号，
    /// 阵营由 `Unit::team` 区分，跨队重名无碍：`s <标签>` 只在本方单位里查找）。
    ///
    /// 数字用尽后依次使用全角数字、带圈数字、实心圈数字与括号数字（都仍是「数字」），
    /// 保证「整局内标签不复用」的不变式在大编制地图（如「空中突袭滨海机场」开局即有
    /// 42 个 AI 棋子）与持续部署大量增援时依然成立：共 71 个标签。
    fn label_pool(_team: Team) -> Vec<char> {
        let mut pool: Vec<char> = ('1'..='9').chain(std::iter::once('0')).collect();
        pool.extend(('１'..='９').chain(std::iter::once('０')));
        pool.extend(('①'..='⑳').chain(std::iter::once('⓪')));
        pool.extend('❶'..='❿');
        pool.extend('⑴'..='⒇');
        pool
    }

    /// 为本方新单位分配标签。**整局内单调递增、永不复用**：
    /// 早期实现用「存活数量」当序号，单位阵亡后序号回落，
    /// 新单位就会复用仍在使用中的标签——两个同标签单位只有第一个能被
    /// `s <标签>` 选中，另一个整局无法指挥；对手的敌情记录也会出现
    /// 「同一标签换了兵种」。
    fn next_label(&mut self, team: Team) -> char {
        let pool = Self::label_pool(team);
        let mut used: BTreeSet<char> = BTreeSet::new();
        for u in self.units_of(team) {
            used.insert(u.label);
            // 搭载中的步兵不占格但仍在编、仍用自己的标签（敌情里显示为 载[...]），
            // 因此同样不能把它的标签分配给新单位。
            for p in &u.passengers {
                used.insert(p.label);
            }
        }
        let seq = self.next_label_seq.entry(team).or_insert(0);
        let mut idx = *seq;
        while idx < pool.len() && used.contains(&pool[idx]) {
            idx += 1;
        }
        let label = if idx < pool.len() {
            pool[idx]
        } else {
            *pool.last().expect("label pool is not empty")
        };
        *seq = idx + 1;
        label
    }

    fn spawn(&mut self, kind: UnitKind, team: Team, pos: Hex, label: char) {
        let mut u = Unit::new(kind, team, pos);
        u.label = label;
        if kind.is_air() {
            self.air_units.insert(pos, u);
        } else {
            self.units.insert(pos, u);
        }
    }

    /// 生成一个带初始搭载货物的单位（战役地图预置用）。
    /// 逐件校验「可搭载 + 载重」，非法货物跳过并在日志中提示。
    /// 乘客标签独立分配，且随后由 `begin_turn` 统一恢复行动次数。
    fn spawn_with_cargo(
        &mut self,
        kind: UnitKind,
        team: Team,
        pos: Hex,
        label: char,
        cargo: &[UnitKind],
    ) {
        let mut u = Unit::new(kind, team, pos);
        u.label = label;
        if kind.is_air() {
            self.air_units.insert(pos, u);
        } else {
            self.units.insert(pos, u);
        }
        let mut used = 0i32;
        for c in cargo {
            if !kind.can_load_cargo(*c) || used + c.cargo_weight() > kind.capacity() {
                self.elog(format!(
                    "⚠ 战役地图：{} 无法搭载 {}，已忽略",
                    kind.name(),
                    c.name()
                ));
                continue;
            }
            used += c.cargo_weight();
            let plabel = self.next_label(team);
            let mut p = Unit::new(*c, team, pos);
            p.label = plabel;
            p.actions_left = 0; // 初始搭载等同登车状态：当回合不行动
            let carrier = if kind.is_air() {
                self.air_units.get_mut(&pos)
            } else {
                self.units.get_mut(&pos)
            };
            if let Some(vehicle) = carrier {
                vehicle.passengers.push(p);
            }
        }
    }

    pub fn unit_at(&self, h: Hex) -> Option<&Unit> {
        self.units.get(&h).or_else(|| self.air_units.get(&h))
    }

    pub fn unit_at_mut(&mut self, h: Hex) -> Option<&mut Unit> {
        if self.units.contains_key(&h) {
            self.units.get_mut(&h)
        } else {
            self.air_units.get_mut(&h)
        }
    }

    pub fn units_of(&self, team: Team) -> Vec<&Unit> {
        let mut v: Vec<&Unit> = self
            .units
            .values()
            .chain(self.air_units.values())
            .filter(|u| u.team == team)
            .collect();
        v.sort_by_key(|u| u.label);
        v
    }

    /// 场上存活单位数，**含已搭载的步兵**：搭载中的步兵仍在编，只是不单独占格。
    /// 否则"我方: 存活 13 · 已损失 0"会在有人上车时自相矛盾（13 + 0 ≠ 14）。
    pub fn alive_unit_count(&self, team: Team) -> usize {
        fn count(unit: &Unit) -> usize {
            1 + unit.passengers.iter().map(count).sum::<usize>()
        }
        self.units
            .values()
            .chain(self.air_units.values())
            .filter(|u| u.team == team)
            .map(count)
            .sum()
    }

    pub fn enemies_of(&self, team: Team) -> Vec<&Unit> {        self.units_of(team.opponent())
    }

    pub fn vision(&self, team: Team) -> VisionResult {
        let mut terrain = BTreeSet::new();
        let mut enemy_units = BTreeSet::new();
        let mut dist_map: HashMap<Hex, (i32, i32)> = HashMap::new();
        for u in self.units.values().chain(self.air_units.values()) {
            if u.team != team {
                continue;
            }
            let v = u.kind.vision();
            // BFS（加权：森林 2 步，其余 1 步）
            let mut dist: HashMap<Hex, i32> = HashMap::new();
            let mut queue: VecDeque<Hex> = VecDeque::new();
            dist.insert(u.pos, 0);
            queue.push_back(u.pos);
            while let Some(h) = queue.pop_front() {
                let d = dist[&h];
                // 地形视野上限为 v；但单位发现可达 v×2（空中单位隐蔽 0.5，
                // 发现距离 = 视野×2），故 BFS 扩展到 v×2（地形可见仍限 v）
                if d >= v * 2 {
                    continue;
                }
                for n in h.neighbors() {
                    if !self.map.contains(n) {
                        continue;
                    }
                    // 屋顶步兵：视野无视森林（步耗 1）与楼房遮挡（岩石/烟雾仍阻挡）
                    let step = if self.map.forests.contains(&n) && !u.rooftop {
                        2
                    } else {
                        1
                    };
                    let nd = d + step;
                    if nd > v * 2 || dist.get(&n).copied().unwrap_or(i32::MAX) <= nd {
                        continue;
                    }
                    dist.insert(n, nd);
                    // 岩石/楼房/烟雾可见但不可穿透（不扩展）；
                    // 无人机/直升机/屋顶步兵视野不受楼房影响（可看穿楼房），岩石与烟雾仍阻挡
                    if !self.map.obstacles.contains(&n)
                        && (u.kind.is_air() || u.rooftop || !self.map.buildings.contains(&n))
                        && !self.smoke.contains_key(&n)
                    {
                        queue.push_back(n);
                    }
                }
            }
            for (h, d) in &dist {
                if *d <= v {
                    terrain.insert(*h);
                }
                // 分层迷雾数据：记录每格最近己方单位的 (BFS 路程, 视野)
                match dist_map.get(h) {
                    Some((od, ov)) if *od < *d || (*od == *d && *ov >= v) => {}
                    _ => {
                        dist_map.insert(*h, (*d, v));
                    }
                }
                if let Some(e) = self.unit_at(*h) {
                    if e.team != team {
                        // 发现条件：BFS 路程 ≤ 视野/隐蔽值
                        // 隐蔽值 1（装甲/车辆/直升机）→ 视野；隐蔽值 2（步兵）→ 视野/2；
                        // 特战小队进入森林/楼房 → 隐蔽值乘 2 = 4（需更近才能发现）
                        let mut conceal = if e.rooftop {
                            // 屋顶：放弃房屋/森林的隐蔽加成（暴露在外）
                            e.kind.concealment()
                        } else if e.kind == UnitKind::SpecialForces
                            && (self.map.forests.contains(h)
                                || self.map.buildings.contains(h))
                        {
                            4
                        } else {
                            e.kind.concealment()
                        };
                        // 烟雾：其中所有单位隐蔽 ×2（发现需更近）
                        if self.smoke.contains_key(h) {
                            conceal *= 2;
                        }
                        // 空中单位隐蔽度 0.5：发现距离 = 视野 ×2
                        //（平原上视野 4 的单位可发现 8 格远的空中单位；中间有森林/
                        //  楼房时 BFS 路程相应增加或被阻挡，发现距离随之受影响）
                        let need = if e.kind.is_air() { v * 2 } else { v / conceal };
                        if *d <= need {
                            enemy_units.insert(*h);
                        }
                    }
                }
            }
        }
        // 合并"进入烟雾遭遇"接触发现的敌方单位（该单位立即进入视野）
        if let Some(contact) = self.revealed_by_contact.get(&team) {
            for h in contact {
                if let Some(e) = self.unit_at(*h) {
                    if e.team != team {
                        enemy_units.insert(*h);
                    }
                }
            }
        }
        VisionResult {
            terrain,
            enemy_units,
            dist: dist_map,
        }
    }

    /// 地形可见格（BFS 最短路程 ≤ 视野）——用于迷雾。
    pub fn revealed_hexes(&self, team: Team) -> BTreeSet<Hex> {
        self.vision(team).terrain
    }

    /// h 格是否处于 team 方地形视野内。
    pub fn is_revealed(&self, team: Team, h: Hex) -> bool {
        self.revealed_hexes(team).contains(&h)
    }

    /// h 格上的单位是否被 team 方侦察到（含隐蔽判定）。
    pub fn is_unit_visible(&self, team: Team, h: Hex) -> bool {
        // AI 回合内命中视野缓存（O(1)）；跨回合（回合号变化）自动失效
        if let Some((t, v)) = self.vis_cache.get(&team) {
            if *t == self.turn {
                return v.contains(&h);
            }
        }
        self.vision(team).enemy_units.contains(&h)
    }

    /// 清理迷雾开火警告标记：① 该位置单位已被警告方看到 → 失效；
    /// ② 该位置单位已阵亡 → 失效；③ 超过 2 回合 → 失效（警告时效）。
    pub fn prune_fog_fire_marks(&mut self) {
        let turn = self.turn;
        let killed: HashSet<Hex> = self.killed_hexes.iter().copied().collect();
        let mut visible: BTreeMap<Team, BTreeSet<Hex>> = BTreeMap::new();
        for team in self.fog_fire_marks.keys() {
            visible.insert(*team, self.vision(*team).enemy_units);
        }
        for (team, marks) in self.fog_fire_marks.iter_mut() {
            let vis = &visible[team];
            marks.retain(|h, t| !vis.contains(h) && !killed.contains(h) && turn - *t < 2);
        }
    }

    pub fn team_alive(&self, team: Team) -> bool {
        self.units
            .values()
            .chain(self.air_units.values())
            .any(|u| u.team == team)
    }

    pub fn game_over(&self) -> bool {
        // 部署阶段双方尚未布阵，不算对局结束
        if self.deploying {
            return false;
        }
        // 试验模式是自由沙盘：不因某一方无单位而自动结束，只遵循显式胜利标记。
        if self.test_mode {
            return self.winner.is_some();
        }
        if self.winner.is_some() {
            return true;
        }
        // 战役地图：到达游戏结束回合即结束（胜者已在 check_turn_victory 结算，
        // 无人满足则为平局，由 is_draw 判定）。
        if self.campaign_ended() {
            return true;
        }
        if !self.sustain {
            return !self.team_alive(Team::Player) || !self.team_alive(Team::Ai);
        }
        // 可持续部署模式：胜利条件由关键据点/大本营与地图胜利条件决定
        // （全灭不算结束——下回合还可增援复活）。
        self.winner.is_some()
    }

    /// 大本营区域（deploy_zone）某格是否被敌军"占领"：距敌军任意单位 ≤5 格。
    /// 该格是否被敌军压制而不可部署（距任一敌方**地面**单位 ≤5 格）。
    ///
    /// 只统计地面单位：空中单位不"占领"地面，否则一架敌侦察无人机在指挥部
    /// 附近悬停就能永久封锁本方全部增援格（地面单位还打不到它）。
    pub fn zone_occupied(&self, team: Team, h: Hex) -> bool {
        self.enemies_of(team)
            .iter()
            .filter(|e| !e.kind.is_air())
            .any(|e| Hex::distance(e.pos, h) <= 5)
    }

    /// 大本营区域是否被敌军完全占领（区域内所有格都距敌军 ≤5）。
    /// 战役地图按逐格部署区判定（列区域退化为列内全部格）。
    pub fn zone_fully_occupied(&self, team: Team) -> bool {
        let cells = self.deploy_cells(team);
        if cells.is_empty() {
            return false;
        }
        cells.iter().all(|h| self.zone_occupied(team, *h))
    }

    /// 补给范围格集合：本方地面上每个补给单位，其周围半径 2 格（含自身格）。
    /// 被搭载的补给单位不在 units 中，因此不能提供补给。
    pub fn supply_zone_hexes(&self, team: Team) -> BTreeSet<Hex> {
        let mut out: BTreeSet<Hex> = BTreeSet::new();
        for cargo in self
            .units
            .values()
            .filter(|u| u.team == team && u.kind == UnitKind::Supply)
        {
            out.insert(cargo.pos);
            for n1 in cargo.pos.neighbors() {
                out.insert(n1);
                for n2 in n1.neighbors() {
                    out.insert(n2);
                }
            }
        }
        out.retain(|h| self.map.contains(*h));
        out
    }

    /// h 是否处于 team 的补给范围（距本方任一地面补给单位 ≤ 2 格）。
    pub fn in_supply_zone(&self, team: Team, h: Hex) -> bool {
        self.units.values().any(|u| {
            u.team == team
                && u.kind == UnitKind::Supply
                && Hex::distance(u.pos, h) <= 2
        })
    }

    /// 某补给单位的补给范围（含自身格，半径 2 格内）。
    pub fn supply_range_of(&self, supplier_h: Hex) -> BTreeSet<Hex> {
        let mut out: BTreeSet<Hex> = BTreeSet::new();
        let Some(s) = self.unit_at(supplier_h) else {
            return out;
        };
        if s.kind != UnitKind::Supply {
            return out;
        }
        out.insert(supplier_h);
        for n1 in supplier_h.neighbors() {
            out.insert(n1);
            for n2 in n1.neighbors() {
                out.insert(n2);
            }
        }
        out.retain(|h| self.map.contains(*h));
        out
    }

    /// 补给：由补给单位 supplier_h 消耗 1 次行动与 1 点弹药，为半径 2 格内的友军
    /// target_h 提供补给；**被补给的友军也必须拥有行动次数并消耗 1 次行动**。
    /// 恢复目标全部弹药（主武器/副武器/第三武器）。
    /// 补给单位共携带 5 点弹药（max_ammo），耗尽后不能再补给。
    pub fn resupply_from(&mut self, supplier_h: Hex, target_h: Hex) -> Result<String, String> {
        let (s_team, s_kind, s_actions, s_ammo) = {
            let s = self.unit_at(supplier_h).ok_or("补给单位不存在")?;
            (s.team, s.kind, s.actions_left, s.ammo)
        };
        if s_kind != UnitKind::Supply {
            return Err("只有补给单位可以提供补给".into());
        }
        if s_ammo < 1 {
            return Err("补给单位弹药耗尽（共携带 5 点）".into());
        }
        if s_actions < 1 {
            return Err("补给单位行动次数不足".into());
        }
        if Hex::distance(supplier_h, target_h) > 2 {
            return Err("目标不在补给范围内（半径 2 格）".into());
        }
        let (t_team, t_kind, t_actions, t_label) = {
            let t = self.unit_at(target_h).ok_or("目标格没有单位")?;
            (t.team, t.kind, t.actions_left, t.label)
        };
        if t_team != s_team {
            return Err("只能补给友军单位".into());
        }
        if t_kind == UnitKind::Supply {
            return Err("补给单位自身无需补给".into());
        }
        if t_actions < 1 {
            return Err(format!("{} {} 行动次数不足，无法接受补给", t_label, t_kind.name()));
        }
        {
            let s = self.unit_at_mut(supplier_h).unwrap();
            s.actions_left -= 1;
            s.ammo -= 1;
        }
        let left = self.unit_at(supplier_h).map(|s| s.ammo).unwrap_or(0);
        {
            let t = self.unit_at_mut(target_h).unwrap();
            t.actions_left -= 1;
            t.ammo = t.kind.max_ammo();
            t.missile_ammo = t.kind.max_missile_ammo();
            t.aa_ammo = t.kind.max_aa_ammo();
        }
        let msg = format!(
            "补给单位消耗 1 行动/1 弹药，为 {} {} 补满全部弹药（其消耗 1 行动；剩余补给弹药 {}）",
            t_label,
            t_kind.name(),
            left
        );
        self.elog(format!("📦 {}", msg));
        Ok(msg)
    }

    /// AI/自动补给：反复寻找有行动、有弹药的补给单位与半径 2 格内主武器弹药耗尽、
    /// 且同样有行动的友军，执行补给；补给单位与被补给单位各消耗 1 行动。
    /// 返回产生的日志（供 AI 回合调用；在规划行动之前执行）。
    pub fn auto_resupply(&mut self, team: Team) -> Vec<String> {
        let mut out = Vec::new();
        loop {
            let mut chosen: Option<(Hex, Hex)> = None;
            let suppliers: Vec<Hex> = self
                .units
                .values()
                .filter(|u| {
                    u.team == team
                        && u.kind == UnitKind::Supply
                        && u.actions_left >= 1
                        && u.ammo >= 1
                })
                .map(|u| u.pos)
                .collect();
            'search: for s in suppliers {
                for t in self.units.values() {
                    if t.team == team
                        && t.kind != UnitKind::Supply
                        && t.kind.max_ammo() > 0
                        && t.ammo == 0
                        && t.actions_left >= 1
                        && Hex::distance(s, t.pos) <= 2
                    {
                        chosen = Some((s, t.pos));
                        break 'search;
                    }
                }
            }
            match chosen {
                Some((s, t)) => match self.resupply_from(s, t) {
                    Ok(m) => out.push(format!("[补给] {}", m)),
                    Err(_) => break,
                },
                None => break,
            }
        }
        // 大本营补给：本方大本营据点半径 2 格内、弹药耗尽的棋子自行消耗 1 行动补满。
        loop {
            let target = self
                .units
                .values()
                .find(|u| {
                    u.team == team
                        && u.kind.max_ammo() > 0
                        && u.ammo == 0
                        && u.actions_left >= 1
                        && self.in_hq_supply_area(team, u.pos)
                })
                .map(|u| u.pos);
            match target {
                Some(h) => match self.resupply_at_hq(team, h) {
                    Ok(m) => out.push(format!("[大本营] {}", m)),
                    Err(_) => break,
                },
                None => break,
            }
        }
        out
    }

    /// unit_h 是否处于本方大本营据点（关键据点中心）半径 2 格内。
    pub fn in_hq_supply_area(&self, team: Team, unit_h: Hex) -> bool {
        self.hq_pos(team)
            .map(|hq| Hex::distance(hq, unit_h) <= 2)
            .unwrap_or(false)
    }

    /// 大本营补给：任意己方棋子处于本方大本营据点（关键据点中心）半径 2 格内时，
    /// 可消耗 1 行动次数补充全部弹药（无需补给单位；补给单位则补充其补给弹药）。
    pub fn resupply_at_hq(&mut self, team: Team, unit_h: Hex) -> Result<String, String> {
        let (kind, label, actions) = {
            let u = self.unit_at(unit_h).ok_or("该格没有单位")?;
            if u.team != team {
                return Err("只能补给己方棋子".into());
            }
            (u.kind, u.label, u.actions_left)
        };
        if !self.in_hq_supply_area(team, unit_h) {
            return Err("目标不在本方大本营据点半径 2 格内".into());
        }
        if actions < 1 {
            return Err("行动次数不足".into());
        }
        let u = self.unit_at_mut(unit_h).unwrap();
        u.actions_left -= 1;
        u.ammo = u.kind.max_ammo();
        u.missile_ammo = u.kind.max_missile_ammo();
        u.aa_ammo = u.kind.max_aa_ammo();
        let msg = format!("{} {} 在大本营据点补满全部弹药（消耗 1 行动）", label, kind.name());
        self.elog(format!("🏛 {}", msg));
        Ok(msg)
    }

    /// 开启可持续部署模式：设定双方每回合获得的部署点数。
    /// 开始后每回合在初始部署盈余的基础上累计。
    pub fn enable_sustain(&mut self, player_per_turn: i32, ai_per_turn: i32) {
        self.sustain = true;
        self.sustain_per_turn.insert(Team::Player, player_per_turn.max(0));
        self.sustain_per_turn.insert(Team::Ai, ai_per_turn.max(0));
    }

    /// 多人对局（无部署阶段）直接进入可持续部署模式：设定每回合点数与初始点数，
    /// 并立即生成双方关键据点——多人开局是预置部队，`finish_deploy` 不会被调用，
    /// 不生成据点就没有大本营，追加部署会因「本方指挥部不存在」而失败。
    /// 首个蓝方回合开始时 `begin_turn` 再发放一次每回合点数。
    pub fn start_sustain_multiplayer(
        &mut self,
        player_per_turn: i32,
        ai_per_turn: i32,
        player_points: i32,
        ai_points: i32,
    ) {
        self.enable_sustain(player_per_turn, ai_per_turn);
        let pp = player_points.max(0);
        let ap = ai_points.max(0);
        self.recruit_points.insert(Team::Player, pp);
        self.recruit_points.insert(Team::Ai, ap);
        self.initial_points.insert(Team::Player, pp);
        self.initial_points.insert(Team::Ai, ap);
        if self.keypoints.is_empty() {
            self.spawn_keypoints(Team::Player);
            self.spawn_keypoints(Team::Ai);
        }
        self.elog(format!(
            "♾ 可持续部署：每回合 +{}（蓝）/ +{}（红）点 · 初始点数 {} / {} · 大本营已设立",
            player_per_turn.max(0),
            ai_per_turn.max(0),
            pp,
            ap
        ));
    }

    /// 可持续部署模式下，敌军是否已接近全歼：**已歼灭点数 ≥ 敌军初始部署点数 P - N**，
    /// N = 本队 AI 配置的总攻阈值（默认 10）。AI 据此发动总攻（搜索并摧毁敌军指挥部）。
    pub fn sustain_assault_ready(&self, team: Team) -> bool {
        if !self.sustain {
            return false;
        }
        let gap = self
            .ai_configs
            .get(&team)
            .map(|c| c.assault_gap)
            .unwrap_or(10);
        let opp = team.opponent();
        let init = self.initial_points.get(&opp).copied().unwrap_or(0);
        let lost = self.killed_value.get(&opp).copied().unwrap_or(0);
        lost >= (init - gap).max(0)
    }

    /// 本方的一处大本营（多座时取第一座；只用于增援部署，不参与胜负）。
    pub fn hq_pos(&self, team: Team) -> Option<Hex> {
        self.hq_positions(team).first().copied()
    }

    /// 本方全部大本营格（战役地图可有多座，甚至没有）。
    pub fn hq_positions(&self, team: Team) -> Vec<Hex> {
        self.keypoints
            .iter()
            .filter(|(_, kp)| kp.owner == team && kp.center)
            .map(|(h, _)| *h)
            .collect()
    }

    /// 当前控制方为 team 的所有据点格（含大本营，供 UI/文本显示）。
    pub fn keypoints_of(&self, team: Team) -> Vec<Hex> {
        self.keypoints
            .iter()
            .filter(|(_, kp)| kp.controller == team)
            .map(|(h, _)| *h)
            .collect()
    }

    /// 当前控制方为 team 的**关键据点**（`center == false`，胜负目标）。
    pub fn objectives_controlled_by(&self, team: Team) -> Vec<Hex> {
        self.keypoints
            .iter()
            .filter(|(_, kp)| !kp.center && kp.controller == team)
            .map(|(h, _)| *h)
            .collect()
    }

    /// 某方是否控制全部**关键据点**（不含大本营；无关键据点时恒为 false）。
    pub fn controls_all_keypoints(&self, team: Team) -> bool {
        let objectives: Vec<&Keypoint> =
            self.keypoints.values().filter(|kp| !kp.center).collect();
        !objectives.is_empty() && objectives.iter().all(|kp| kp.controller == team)
    }

    /// 本方在战役地图中的胜利条件（非战役地图 = 旧的「占领全部即胜」）。
    pub fn victory_rule(&self, team: Team) -> VictoryRule {
        self.custom
            .as_ref()
            .map(|c| match team {
                Team::Player => c.player_victory,
                Team::Ai => c.ai_victory,
            })
            .unwrap_or(VictoryRule::CaptureAllImmediate)
    }

    /// 战役地图的游戏结束回合（0 = 不限）。
    pub fn turn_limit(&self) -> i32 {
        self.custom.as_ref().map(|c| c.turn_limit).unwrap_or(0)
    }

    /// 是否已越过游戏结束回合（战役地图；用于结算 C 与平局）。
    pub fn campaign_ended(&self) -> bool {
        if self.test_mode || self.deploying {
            return false;
        }
        let l = self.turn_limit();
        l > 0 && self.turn > l
    }

    /// 记录胜者并写入日志/战报（幂等）。
    fn declare_winner(&mut self, team: Team, reason: String) {
        if self.winner.is_some() {
            return;
        }
        self.winner = Some(team);
        self.elog(format!("🏆 {} {}，游戏胜利！", team.cn(), reason));
        self.push_battle_event(BattleEventKind::Victory { winner: team, reason });
    }

    /// 回合推进后的胜利检查：B（到指定回合仍控制全部关键据点）与
    /// 游戏结束结算（C：结束时仍控制任意关键据点；无人满足则平局）。
    fn check_turn_victory(&mut self) {
        if self.winner.is_some() {
            return;
        }
        let t = self.turn;
        for team in [Team::Player, Team::Ai] {
            match self.victory_rule(team) {
                VictoryRule::HoldAllAtTurn { turn }
                    if turn > 0 && t == turn && self.controls_all_keypoints(team) =>
                {
                    self.declare_winner(team, format!("第 {} 回合仍控制全部关键据点", turn));
                    return;
                }
                VictoryRule::CaptureAllBeforeTurn { turn }
                    if turn > 0 && t == turn + 1 && !self.controls_all_keypoints(team) =>
                {
                    self.elog(format!(
                        "⌛ {} 的「第 {} 回合前占领全部关键据点」已超时（未占全）",
                        team.cn(),
                        turn
                    ));
                }
                _ => {}
            }
        }
        let limit = self.turn_limit();
        if limit > 0 && t > limit {
            let mut winners: Vec<Team> = Vec::new();
            for team in [Team::Player, Team::Ai] {
                if let VictoryRule::HoldAnyAtEnd = self.victory_rule(team) {
                    if !self.objectives_controlled_by(team).is_empty() {
                        winners.push(team);
                    }
                }
            }
            match winners.as_slice() {
                [w] => self.declare_winner(
                    *w,
                    format!("游戏结束（第 {} 回合）仍控制关键据点", limit),
                ),
                _ => {
                    self.elog(format!(
                        "⚖ 第 {} 回合游戏结束：双方均未达成胜利条件，判平局",
                        limit
                    ));
                }
            }
        }
    }

    /// 检查并执行据点占领：陆军棋子（非空中）落入敌方控制的据点/大本营格 → 占领。
    /// 夺取大本营只影响增援部署区域，不判胜负；夺取关键据点按胜利条件判胜。
    fn capture_keypoint(&mut self, u: &Unit, to: Hex) {
        if u.kind.is_air() {
            return; // 空中棋子不能占领据点/大本营
        }
        let Some(kp) = self.keypoints.get_mut(&to) else {
            return;
        };
        if kp.controller == u.team {
            return;
        }
        let old = kp.controller;
        kp.controller = u.team;
        let center = kp.center;
        let what = if center { "大本营" } else { "关键据点" };
        self.elog(format!(
            "⚑ {} 的{} 占领了{}的{} {}",
            u.team.cn(),
            u.name_with_label(),
            old.cn(),
            what,
            hex::hex_label(to)
        ));
        self.push_battle_event(BattleEventKind::Keypoint {
            hex: to,
            center,
            from: old,
            to: u.team,
            by_label: u.label,
            by_kind: u.kind,
        });
        if center || !self.controls_all_keypoints(u.team) {
            return;
        }
        // 关键据点已全控：仅「占领即胜」类条件立即判胜；
        // B（到指定回合控制全部）与 C（结束时控制任意）留待回合检查。
        match self.victory_rule(u.team) {
            VictoryRule::CaptureAllImmediate => {
                let total = self.keypoints.values().filter(|kp| !kp.center).count();
                self.declare_winner(u.team, format!("同时控制全部 {} 个关键据点", total));
            }
            VictoryRule::CaptureAllBeforeTurn { turn } => {
                if turn <= 0 || self.turn <= turn {
                    self.declare_winner(
                        u.team,
                        format!("第 {} 回合前占领全部关键据点", turn.max(self.turn)),
                    );
                }
            }
            VictoryRule::HoldAllAtTurn { .. } | VictoryRule::HoldAnyAtEnd => {}
        }
    }

    /// AI 全面防御：己方指挥部周围 `defend_radius` 格（配置参数，默认 8）内
    /// 是否存在**可见**的敌军单位。
    pub fn defense_triggered(&self, team: Team) -> bool {
        if !self.sustain {
            return false;
        }
        let radius = self
            .ai_configs
            .get(&team)
            .map(|c| c.defend_radius)
            .unwrap_or(8);
        let Some(hq) = self.hq_pos(team) else {
            return false;
        };
        self.enemies_of(team).iter().any(|e| {
            self.is_unit_visible(team, e.pos) && Hex::distance(e.pos, hq) <= radius
        })
    }

    /// 僵局：超过 20 个回合没有击杀（例如双方只剩互相打不穿的坦克）。
    /// 战役地图到达游戏结束回合且无人满足胜利条件时，同样判平局。
    pub fn is_draw(&self) -> bool {
        if self.test_mode {
            return false;
        }
        if self.campaign_ended() && self.winner.is_none() {
            return true;
        }
        self.turn >= 20 && self.turn - self.last_kill_turn >= 20
    }

    /// 保存当前完整游戏状态到 JSON 文件（含 RNG 内部状态，可从该位置继续）。
    pub fn save_to_file(&self, path: &std::path::Path) -> Result<(), String> {
        let json = serde_json::to_string_pretty(self).map_err(|e| e.to_string())?;
        std::fs::write(path, json).map_err(|e| e.to_string())
    }

    /// 从 JSON 文件加载游戏状态。
    pub fn load_from_file(path: &std::path::Path) -> Result<Self, String> {
        let txt = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
        let mut gs: Self =
            serde_json::from_str(&txt).map_err(|e| format!("{}: {}", path.display(), e))?;
        // 兼容旧存档：旧版只有 bool suppressed，没有压制层数；如有压制则补 1 层。
        for u in gs.units.values_mut().chain(gs.air_units.values_mut()) {
            if u.suppressed && u.suppression_stacks <= 0 {
                u.suppression_stacks = 1;
            }
            if u.suppression_stacks > 0 {
                u.suppressed = true;
            }
            for p in u.passengers.iter_mut() {
                if p.suppressed && p.suppression_stacks <= 0 {
                    p.suppression_stacks = 1;
                }
                if p.suppression_stacks > 0 {
                    p.suppressed = true;
                }
            }
        }
        Ok(gs)
    }

    /// 追加一条对局事件日志。
    fn elog(&mut self, msg: impl Into<String>) {
        self.event_log.push(msg.into());
    }

    /// 开始 team 的行动阶段并刷新其行动次数（含载具内步兵）。
    pub fn begin_turn(&mut self, team: Team) {
        // 已有事件时打回合标记（首帧/测试初始化时事件为空则跳过）
        if !self.event_log.is_empty() {
            let t = if team == Team::Player { self.turn + 1 } else { self.turn };
            self.elog(format!("== 第 {} 回合 · {} 行动 ==", t, team.cn()));
        }
        // 每回合（玩家阶段）烟雾衰减 1 回合、清除"接触发现"
        if team == Team::Player {
            self.smoke.retain(|_, r| {
                *r -= 1;
                *r > 0
            });
            self.revealed_by_contact.clear();
        }
        self.phase = team;
        if team == Team::Player {
            self.turn += 1;
            // 可持续部署：每回合（玩家阶段开始时）双方在初始部署盈余基础上获得部署点数
            if self.sustain {
                for t in [Team::Player, Team::Ai] {
                    let per = self.sustain_per_turn.get(&t).copied().unwrap_or(0);
                    let cur = self.recruit_points.get(&t).copied().unwrap_or(0);
                    self.recruit_points.insert(t, cur + per);
                    self.elog(format!(
                        "🛠 {} 获得 {} 部署点数（当前累计 {}）",
                        t.cn(),
                        per,
                        cur + per
                    ));
                }
            }
            // 战役地图：回合推进后检查 B（指定回合控制全部）与游戏结束结算（C/平局）
            self.check_turn_victory();
        }
        // 本回合提示只对本方可见，回合开始时先清空（随后由本回合事件填充）
        self.notices.remove(&team);
        // 压制生效：被压制单位新回合行动次数 -压制层数（可叠加，最低 0；持续 1 回合后清除）
        let mut suppressed_note: Vec<String> = Vec::new();
        for u in self.units.values_mut().chain(self.air_units.values_mut()) {
            if u.team == team {
                u.actions_left = u.kind.action_count();
                let stacks = u.suppression_stacks.max(0);
                if stacks > 0 {
                    u.actions_left = (u.actions_left - stacks).max(0);
                    u.suppression_stacks = 0;
                    u.suppressed = false;
                    suppressed_note.push(format!("{}（-{}）", u.name_with_label(), stacks));
                }
                for p in u.passengers.iter_mut() {
                    p.actions_left = p.kind.action_count();
                    let stacks = p.suppression_stacks.max(0);
                    if stacks > 0 {
                        p.actions_left = (p.actions_left - stacks).max(0);
                        p.suppression_stacks = 0;
                        p.suppressed = false;
                        suppressed_note.push(format!("{}（-{}）", p.name_with_label(), stacks));
                    }
                }
            }
        }
        if !suppressed_note.is_empty() {
            let line = format!("💥 压制生效：{} 本回合行动次数减少", suppressed_note.join("、"));
            self.elog(line.clone());
            self.notices.entry(team).or_default().push(line);
        }
        // 该方回合开始时刷新"最后已知敌方位置"（文本快照的 `?` 只显示这些记录）
        self.refresh_ghosts(team);
    }

    /// 移动单位：from 为当前所在格，path 为规划路径（含起点）。
    /// `air` 指定移动空中层还是地面层，确保同格空/地单位完全解耦。
    /// 成功返回新位置，消耗 1 次行动；载具移动时搭载步兵随行。
    pub fn move_unit(&mut self, from: Hex, path: &[Hex], air: bool) -> Result<Hex, String> {
        let mut u = if air {
            self.air_units.remove(&from).ok_or("空中单位不存在")?
        } else {
            self.units.remove(&from).ok_or("地面单位不存在")?
        };
        let to = *path.last().ok_or("路径为空")?;
        if path[0] != from {
            self.put_unit(u);
            return Err("路径起点与单位位置不符".into());
        }
        if to == from {
            self.put_unit(u);
            return Err("该方向无路可走".into());
        }
        if u.actions_left < 1 {
            self.put_unit(u);
            return Err("行动次数不足".into());
        }
        // 逐格执行移动：地形/行动力校验，支持"烟雾遭遇"（停在敌方前并发现敌人）
        // 行动力以半点为内部单位（2 半 = 1 点），以支持道路对车辆的 0.5 成本。
        let air = u.kind.is_air();
        let vehicle = u.kind.is_vehicle();
        let mut rem = u.kind.movement().saturating_mul(2);
        let mut reached: Option<Hex> = None; // 遭遇时部分移动的终点
        let mut contact_enemy: Option<Hex> = None;
        for i in 1..path.len() {
            let w = path[i];
            let prev = path[i - 1];
            if !self.map.contains(w) {
                self.put_unit(u);
                return Err("路径超出地图".into());
            }
            if Hex::distance(prev, w) != 1 {
                self.put_unit(u);
                return Err("非法路径".into());
            }
            if !air {
                if self.map.obstacles.contains(&w) {
                    self.put_unit(u);
                    return Err(format!("路径被岩石阻挡（{}）", hex::hex_label(w)));
                }
                if self.map.water.contains(&w) {
                    self.put_unit(u);
                    return Err(format!("路径被水域阻挡（{}）", hex::hex_label(w)));
                }
                if self.map.buildings.contains(&w) && !u.kind.is_foot() {
                    let name = u.name_with_label();
                    self.put_unit(u);
                    return Err(format!("{} 不能进入楼房（只有步兵可以进入）", name));
                }
                let cost = self.map.move_cost_half(w, vehicle);
                if rem >= cost {
                    rem -= cost;
                } else if rem >= 1 {
                    rem = 0; // 向上取整：进入最后一格
                } else {
                    self.put_unit(u);
                    return Err("行动力不足（森林每格 2 点；车辆沿道路每格 0.5 点）".into());
                }
            }
            // 空中单位不能飞入/飞越另一个空中单位所在格：同层不重叠，
            // 否则 put_unit(air_units.insert) 会覆盖掉原有的直升机/无人机。
            if air && self.air_units.contains_key(&w) {
                self.put_unit(u);
                return Err(format!("路径被空中单位阻挡（{}）", hex::hex_label(w)));
            }
            if let Some(occ) = self.units.get(&w) {
                if occ.team == u.team {
                    if air {
                        continue; // 直升机飞越己方地面单位
                    }
                    self.put_unit(u);
                    return Err("路径被己方单位阻挡".into());
                }
                // 敌方单位挡路：烟雾中遭遇 → 停在敌人前方并发现敌人；否则正常阻挡
                if self.smoke.contains_key(&w) {
                    contact_enemy = Some(w);
                    self.revealed_by_contact
                        .entry(u.team)
                        .or_default()
                        .insert(w);
                    reached = Some(prev);
                    break;
                }
                self.put_unit(u);
                return Err(format!("路径被敌方单位阻挡（{}）", hex::hex_label(w)));
            }
            reached = Some(w);
        }
        if let Some(hex_contact) = contact_enemy {
            // 遭遇：部分移动（可能原地），消耗 1 次行动，发现敌人
            let dest = reached.unwrap_or(from);
            u.pos = dest;
            // 需要架设的单位一旦移动到新位置，架设状态失效（需重新架设）
            if u.kind.needs_deploy() && dest != from {
                u.deployed = false;
            }
            u.actions_left -= 1;
            for p in u.passengers.iter_mut() {
                p.pos = dest;
            }
            let e = self
                .units
                .get(&hex_contact)
                .map(|e| e.name_with_label())
                .unwrap_or_default();
            self.elog(format!(
                "{} 在烟雾中遭遇 {}（被挡在 {}，已发现敌人）",
                u.name_with_label(),
                e,
                hex::hex_label(dest)
            ));
            self.capture_keypoint(&u, dest);
            // GUI 动画：只播放实际走过的前段路径
            let walked: Vec<Hex> = path.iter().copied().take_while(|&w| w != hex_contact).collect();
            self.record_move(&u, &walked, air);
            self.put_unit(u);
            return Ok(dest);
        }
        let to = *path.last().ok_or("路径为空")?;
        u.pos = to;
        // 需要架设的单位移动到新位置后，架设状态失效（需重新架设）
        if u.kind.needs_deploy() {
            u.deployed = false;
        }
        u.actions_left -= 1;
        for p in u.passengers.iter_mut() {
            p.pos = to;
        }
        self.elog(format!(
            "{} 移动 {} → {}",
            u.name_with_label(),
            hex::hex_label(from),
            hex::hex_label(to)
        ));
        // 关键据点占领：陆军踏入敌方据点即占领（空中单位不能）
        self.capture_keypoint(&u, to);
        self.record_move(&u, path, air);
        let mover_team = u.team;
        self.put_unit(u);
        // 移动后刷新该方的"最后已知敌方位置"（新看到的敌人进入幽灵记录）
        self.refresh_ghosts(mover_team);
        Ok(to)
    }

    /// 记录一次移动事件供 GUI 回放动画（路径至少含起点+终点才有效）。
    fn record_move(&mut self, u: &Unit, path: &[Hex], air: bool) {
        if path.len() >= 2 {
            self.ui_events.push(UiEvent::Move {
                team: u.team,
                label: u.label,
                kind: u.kind,
                path: path.to_vec(),
                air,
            });
        }
    }

    /// 按单位类型放入对应图层。
    fn put_unit(&mut self, u: Unit) {
        if u.kind.is_air() {
            self.air_units.insert(u.pos, u);
        } else {
            self.units.insert(u.pos, u);
        }
    }

    // ---------- 搭载 / 放下 ----------

    /// 让紧邻载具的单位上车（消耗载具 1 次行动）。按重量计算载重。
    pub fn board(&mut self, vehicle_h: Hex, cargo_h: Hex) -> Result<(), String> {
        let mut vehicle = self.unit_at(vehicle_h).ok_or("载具不存在")?.clone();
        let mut cargo = self.units.get(&cargo_h).ok_or("该格没有可搭载的单位")?.clone();
        if vehicle.kind.capacity() == 0 {
            return Err("该单位不能搭载".into());
        }
        if !vehicle.can_carry(cargo.kind) {
            return Err(format!("{} 不能搭载 {}", vehicle.kind.name(), cargo.kind.name()));
        }
        if vehicle.used_weight() + cargo.occupies_weight() > vehicle.kind.capacity() {
            return Err(format!(
                "载重不足（{} + {} > {}）",
                vehicle.used_weight(),
                cargo.occupies_weight(),
                vehicle.kind.capacity()
            ));
        }
        if Hex::distance(vehicle_h, cargo_h) != 1 {
            return Err("单位必须紧邻载具才能上车".into());
        }
        if vehicle.team != cargo.team {
            return Err("不能搭载敌方单位".into());
        }
        if !vehicle.has_space() {
            return Err(format!("{} 已满载", vehicle.name_with_label()));
        }
        if vehicle.kind.is_air() && self.map.obstacles.contains(&vehicle_h) {
            return Err("运输直升机在岩石上方无法搭载单位".into());
        }
        if vehicle.actions_left < 1 {
            return Err("载具行动次数不足".into());
        }
        vehicle.actions_left -= 1;
        cargo.pos = vehicle_h; // 位置随载具
        cargo.deployed = false; // 装车后需重新架设
        let cargo_name = cargo.name_with_label();
        let veh_name = vehicle.name_with_label();
        vehicle.passengers.push(cargo);
        self.units.remove(&cargo_h);
        self.elog(format!("{} 搭载 {}", veh_name, cargo_name));
        self.put_unit(vehicle);
        Ok(())
    }

    // ---------- 运输直升机专用：从正下方载入 / 放到正下方 ----------

    /// 运输直升机把**正下方**（自身所在格）的己方单位载入机舱（按重量计算载重）。
    /// 条件：直升机有剩余载重、下方有己方可载单位、双方均有剩余行动次数。
    /// 消耗直升机 1 次行动，登机单位当回合不再行动。
    pub fn heli_board(&mut self, heli_h: Hex) -> Result<(), String> {
        let mut heli = self
            .air_units
            .get(&heli_h)
            .ok_or("直升机不存在")?
            .clone();
        if !matches!(
            heli.kind,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
        ) {
            return Err("只有运输直升机可以从正下方载入单位".into());
        }
        let mut cargo = self
            .units
            .get(&heli_h)
            .ok_or("直升机正下方没有可载入的单位（运输直升机只能载入同一格的单位，不是紧邻）")?
            .clone();
        if cargo.team != heli.team {
            return Err("不能搭载敌方单位".into());
        }
        if !heli.kind.can_load_cargo(cargo.kind) {
            if cargo.kind == UnitKind::Supply {
                return Err("补给只能由重型运输直升机载运".into());
            }
            return Err(format!(
                "{} 不能搭载 {}",
                heli.kind.name(),
                cargo.kind.name()
            ));
        }
        if heli.used_weight() + cargo.occupies_weight() > heli.kind.capacity() {
            return Err(format!(
                "直升机载重不足（{} + {} > {}）",
                heli.used_weight(),
                cargo.occupies_weight(),
                heli.kind.capacity()
            ));
        }
        if heli.actions_left < 1 {
            return Err("直升机行动次数不足".into());
        }
        // 重型运输直升机载运补给时，不要求补给有剩余行动（常规载运规则例外）。
        let cargo_exception =
            cargo.kind == UnitKind::Supply && heli.kind == UnitKind::HeavyTransportHeli;
        if cargo.actions_left < 1 && !cargo_exception {
            return Err(format!("{} 行动次数不足，无法登机", cargo.name_with_label()));
        }
        heli.actions_left -= 1;
        cargo.actions_left = 0; // 登机消耗本次行动
        cargo.deployed = false; // 登机后需重新架设
        cargo.pos = heli_h;
        let heli_name = heli.name_with_label();
        let cargo_name = cargo.name_with_label();
        heli.passengers.push(cargo);
        self.units.remove(&heli_h);
        self.elog(format!("{} 载入下方 {}", heli_name, cargo_name));
        self.air_units.insert(heli_h, heli);
        Ok(())
    }

    /// 运输直升机把搭载的步兵放到**正下方**（自身所在格）。
    /// 条件：下方无单位、不是岩石、直升机有剩余行动次数。
    /// 消耗直升机 1 次行动；放下的单位当回合不能再行动。
    /// 未指定标签时放下机舱中的第一件货物（重型运输直升机可载多件）。
    pub fn heli_unload(&mut self, heli_h: Hex) -> Result<(), String> {
        let label = self
            .air_units
            .get(&heli_h)
            .and_then(|h| h.passengers.first().map(|p| p.label))
            .ok_or("直升机没有搭载单位")?;
        self.heli_unload_label(heli_h, label)
    }

    /// 同上，但明确指定要放下的单位标签（供 GUI 逐名选择；
    /// 重型运输直升机载多件时不会张冠李戴）。
    pub fn heli_unload_label(&mut self, heli_h: Hex, label: char) -> Result<(), String> {
        let mut heli = self
            .air_units
            .get(&heli_h)
            .ok_or("直升机不存在")?
            .clone();
        if !matches!(
            heli.kind,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
        ) {
            return Err("只有运输直升机可以放下单位".into());
        }
        if heli.passengers.is_empty() {
            return Err("直升机没有搭载单位".into());
        }
        if self.map.obstacles.contains(&heli_h) {
            return Err("直升机在岩石上方无法放下单位".into());
        }
        if self.map.water.contains(&heli_h) {
            return Err("直升机在水域上方无法放下单位".into());
        }
        if self.units.contains_key(&heli_h) {
            return Err("直升机下方有单位，无法放下单位".into());
        }
        if heli.actions_left < 1 {
            return Err("直升机行动次数不足".into());
        }
        let idx = heli
            .passengers
            .iter()
            .position(|p| p.label == label)
            .ok_or("直升机没有搭载该单位")?;
        // 车辆类货物不能卸到楼房内
        if self.map.buildings.contains(&heli_h) && !heli.passengers[idx].kind.is_foot() {
            return Err("车辆不能卸到楼房内".into());
        }
        let mut p = heli.passengers.remove(idx);
        heli.actions_left -= 1;
        p.pos = heli_h;
        p.actions_left = 0; // 卸下后当回合不能行动
        self.elog(format!(
            "{} 放下 {} 到正下方 {}",
            heli.name_with_label(),
            p.name_with_label(),
            hex::hex_label(heli_h)
        ));
        self.units.insert(heli_h, p);
        self.air_units.insert(heli_h, heli);
        Ok(())
    }

    /// 让车上的单位下到紧邻的非岩石空格（卸下不消耗载具行动）。
    pub fn disembark(&mut self, vehicle_h: Hex, label: char, dest: Hex) -> Result<(), String> {
        let mut vehicle = self.unit_at(vehicle_h).ok_or("载具不存在")?.clone();
        if vehicle.kind.capacity() == 0 {
            return Err("该单位不能搭载".into());
        }
        if vehicle.kind.is_air() {
            // 运输直升机：只能把货物放到正下方的格子（即自身所在格）
            if dest != vehicle_h {
                return Err("运输直升机只能把单位放到正下方的格子".into());
            }
            if self.map.obstacles.contains(&vehicle_h) {
                return Err("运输直升机在岩石上方无法放下单位".into());
            }
            if self.map.water.contains(&vehicle_h) {
                return Err("运输直升机在水域上方无法放下单位".into());
            }
        } else if Hex::distance(vehicle_h, dest) != 1 {
            return Err("只能下到紧邻载具的格子".into());
        }
        // 目标格被岩石或单位占据（运输直升机下到自身格时排除自身）
        let occupied = self.map.obstacles.contains(&dest)
            || (self.units.contains_key(&dest) && dest != vehicle_h);
        if occupied {
            return Err("目标格被岩石或单位占据".into());
        }
        // 水域：陆军载具不能卸下单位到水域格
        if self.map.water.contains(&dest) && !vehicle.kind.is_air() {
            return Err("不能把单位卸到水域上".into());
        }
        let idx = vehicle
            .passengers
            .iter()
            .position(|p| p.label == label)
            .ok_or("车上没有该单位")?;
        // 车辆类货物不能卸到楼房内
        if self.map.buildings.contains(&dest) && !vehicle.passengers[idx].kind.is_foot() {
            return Err("车辆不能卸到楼房内".into());
        }
        let mut p = vehicle.passengers.remove(idx);
        // 卸下不消耗载具行动（装车才耗行动；直升机放下单位除外）
        p.pos = dest;
        // 货物下到地面层（运输直升机则落到自身所在格下方）
        let veh_name = vehicle.name_with_label();
        let p_name = p.name_with_label();
        self.elog(format!(
            "{} 放下 {} 到 {}",
            veh_name,
            p_name,
            hex::hex_label(dest)
        ));
        self.units.insert(dest, p);
        self.put_unit(vehicle);
        Ok(())
    }

    // ---------- 攻击 ----------

    /// 按 M 切换副武器模式（免费）：M-SHORAD 导弹 / 精锐&特战 M3E1 / 步枪手 XM1176 / 榴弹炮 M864。
    pub fn toggle_missile_mode(&mut self, h: Hex) -> Result<(), String> {
        let u = self.unit_at_mut(h).ok_or("单位不存在")?;
        if !u.is_dual_weapon() {
            return Err("该单位没有副武器".into());
        }
        u.missile_mode = !u.missile_mode;
        u.aa_mode = false;
        Ok(())
    }

    /// 按 A 切换第三武器模式（特战 Stinger 防空导弹）。
    pub fn toggle_aa_mode(&mut self, h: Hex) -> Result<(), String> {
        let u = self.unit_at_mut(h).ok_or("单位不存在")?;
        if !u.has_tertiary() {
            return Err("该单位没有防空导弹模式".into());
        }
        u.aa_mode = !u.aa_mode;
        u.missile_mode = false;
        Ok(())
    }

    /// 架设：消耗 1 次行动进入架设状态。
    /// - 榴弹炮：架设后才能炮击/发射烟雾弹，架设状态跨回合保留、可持续射击；
    /// - 重机枪手：架设后才能开火，移动/装车后需重新架设（每回合 2 次行动，架设后仍可开火）。
    pub fn deploy(&mut self, attacker_h: Hex) -> Result<(), String> {
        let mut u = self.units.get(&attacker_h).ok_or("单位不存在")?.clone();
        if !u.kind.needs_deploy() {
            return Err("只有榴弹炮/重机枪手需要架设".into());
        }
        if u.deployed {
            return Ok(()); // 已架设：幂等，不再消耗行动
        }
        if u.actions_left < 1 {
            return Err("行动次数不足".into());
        }
        u.actions_left -= 1;
        u.deployed = true;
        let name = u.name_with_label();
        self.elog(format!("{} 完成架设", name));
        self.units.insert(attacker_h, u);
        Ok(())
    }

    /// 榴弹炮发射烟雾弹：以 center 为中心、半径 2（共 1+6+12 格）产生烟雾，
    /// 持续 2 回合。烟雾在视野上完全遮挡（侦察 BFS 不可穿透），但不阻挡移动。
    /// 需要已架设，消耗 1 次行动与 1 发炮弹。
    pub fn smoke_shot(&mut self, attacker_h: Hex, center: Hex) -> Result<Vec<Hex>, String> {
        let mut attacker = self.units.get(&attacker_h).ok_or("攻击方不存在")?.clone();
        if attacker.kind != UnitKind::Howitzer && attacker.kind != UnitKind::Mortar {
            return Err("只有榴弹炮/自行迫击炮能发射烟雾弹".into());
        }
        // 榴弹炮需先架设；自行迫击炮无需架设
        if attacker.kind == UnitKind::Howitzer && !attacker.deployed {
            return Err(format!(
                "{} 尚未架设，无法发射烟雾弹（先架设消耗 1 次行动）",
                attacker.name_with_label()
            ));
        }
        if attacker.actions_left < 1 {
            return Err("行动次数不足".into());
        }
        if attacker.ammo < 1 {
            return Err("弹药耗尽，无法发射烟雾弹".into());
        }
        if Hex::distance(attacker_h, center) > attacker.kind.range() {
            return Err("超出射程".into());
        }
        attacker.actions_left -= 1;
        attacker.ammo -= 1;
        let name = attacker.name_with_label();
        let ev_team = attacker.team;
        let ev_label = attacker.label;
        let ev_kind = attacker.kind;
        let radius = if attacker.kind == UnitKind::Mortar { 1 } else { 2 };
        // 中心 + 各环格（限地图内）：榴弹炮半径 2（19 格）、迫击炮半径 1（7 格）
        let mut cells = vec![center];
        for n in center.neighbors() {
            if self.map.contains(n) {
                cells.push(n);
            }
        }
        if radius >= 2 {
            for n in center.neighbors() {
                for m in n.neighbors() {
                    if m != center && self.map.contains(m) && !cells.contains(&m) {
                        cells.push(m);
                    }
                }
            }
        }
        for h in &cells {
            self.smoke.insert(*h, 2); // 持续 2 回合
        }
        self.units.insert(attacker_h, attacker);
        self.elog(format!(
            "{} 发射烟雾弹 @{}（半径{}，持续2回合）",
            name,
            hex::hex_label(center),
            radius
        ));
        // GUI 动画回放：烟雾弹（白色爆烟覆盖 cells）
        self.ui_events.push(UiEvent::Fire(UiFireEvent {
            team: ev_team,
            label: ev_label,
            kind: ev_kind,
            from: attacker_h,
            target: center,
            target_team: ev_team.opponent(),
            target_label: '?',
            target_kind: UnitKind::Rifleman,
            aa_mode: false,
            missile_mode: false,
            area: true,
            smoke_shell: true,
            blast: cells.clone(),
            hit: true,
            blocked: false,
            killed: false,
            target_hp_before: 0,
            dmg: 0,
            killed_units: Vec::new(),
        }));
        Ok(cells)
    }

    /// 攻击结算。榴弹炮为范围攻击（以 target_h 为中心），其余为单目标攻击。
    pub fn attack(&mut self, attacker_h: Hex, target_h: Hex) -> Result<AttackOutcome, String> {
        self.attack_inner(attacker_h, target_h, false)
    }

    /// 攻击：显式以**空中层**单位为攻击者（直升机与己方地面单位同格时，
    /// `unit_at` 会优先返回地面单位，需用本方法强制以直升机为攻击者）。
    pub fn attack_air(&mut self, attacker_h: Hex, target_h: Hex) -> Result<AttackOutcome, String> {
        self.attack_inner(attacker_h, target_h, true)
    }

    /// 解析攻击方与目标，并完成攻击前的全部合法性校验（不消耗行动/弹药）。
    /// 供单次攻击与同时攻击共用，保证两套入口的规则一致。
    fn resolve_attacker_target(
        &self,
        attacker_h: Hex,
        target_h: Hex,
        air_first: bool,
        mode_override: Option<(bool, bool)>,
    ) -> Result<(Unit, Unit), String> {
        let mut attacker = if air_first {
            self.air_units
                .get(&attacker_h)
                .or_else(|| self.units.get(&attacker_h))
                .cloned()
        } else {
            self.unit_at(attacker_h).cloned()
        }
        .ok_or("攻击方不存在")?;
        // 同时攻击命令使用下达时的武器模式快照，而不是确认时的当前模式
        if let Some((aa_mode, missile_mode)) = mode_override {
            attacker.aa_mode = aa_mode;
            attacker.missile_mode = missile_mode;
        }
        if !attacker.kind.can_attack() {
            return Err(format!("{} 不能发动攻击", attacker.name_with_label()));
        }
        // 目标解析：优先敌方（先地面后空中），支持敌方直升机与我方地面单位同格
        let target = if let Some(u) = self.units.get(&target_h) {
            if u.team != attacker.team {
                u.clone()
            } else if let Some(a) = self.air_units.get(&target_h) {
                if a.team != attacker.team {
                    a.clone()
                } else {
                    u.clone()
                }
            } else {
                u.clone()
            }
        } else if let Some(a) = self.air_units.get(&target_h) {
            a.clone()
        } else {
            return Err("目标不存在".into());
        };
        if attacker.team == target.team {
            return Err("不能攻击友军".into());
        }
        // 空中单位停在岩石上方时无法开火
        if attacker.kind.is_air() && self.map.obstacles.contains(&attacker_h) {
            return Err(format!("{} 在岩石上方无法开火", attacker.name_with_label()));
        }
        // 空/地目标类型限制（按当前武器模式）
        if !attacker.can_target_unit(target.kind) {
            let why = if attacker.is_stinger_mode() {
                "Stinger 防空导弹只能攻击直升机"
            } else if (attacker.kind == UnitKind::Atgm
                || attacker.kind == UnitKind::Javelin
                || (attacker.missile_mode && attacker.kind.has_tow()))
                && !target.kind.is_air()
            {
                "反坦克导弹只能攻击车辆单位"
            } else if target.kind.is_air() {
                "无法攻击空中单位（只有武装直升机与防空单位能打直升机）"
            } else {
                "该单位只能攻击直升机"
            };
            return Err(format!("{} 无法攻击目标：{}", attacker.name_with_label(), why));
        }
        // 重机枪对空的额外限制：隐蔽在楼房内（未登屋顶）的重机枪不能对空，
        // 只有登上屋顶的重机枪才能对空。
        if target.kind.is_air()
            && attacker.is_heavy_mg_mode()
            && self.map.buildings.contains(&attacker_h)
            && !attacker.rooftop
        {
            return Err(format!(
                "{} 在楼房内无法对空（重机枪需登上屋顶才能对空）",
                attacker.name_with_label()
            ));
        }
        // 需架设的单位（重机枪手）：必须先架设才能开火
        if attacker.kind.needs_deploy() && !attacker.deployed {
            return Err(format!(
                "{} 尚未架设，无法开火（先架设消耗 1 次行动）",
                attacker.name_with_label()
            ));
        }
        let cost = attacker.kind.attack_cost();
        if attacker.actions_left < cost {
            return Err(format!(
                "{} 行动次数不足（攻击需{}次，当前剩余{}）",
                attacker.name_with_label(),
                cost,
                attacker.actions_left
            ));
        }
        let sec_ammo = if attacker.aa_mode {
            attacker.aa_ammo
        } else if attacker.missile_mode {
            attacker.missile_ammo
        } else {
            attacker.ammo
        };
        if sec_ammo < 1 {
            let name = if attacker.aa_mode {
                "Stinger 防空导弹"
            } else if attacker.missile_mode {
                match attacker.kind {
                    UnitKind::AaMgv => "Stinger 防空导弹",
                    UnitKind::EliteInfantry | UnitKind::SpecialForces => "M3E1 火箭弹",
                    UnitKind::Rifleman => "M3E1-XM1176 弹",
                    UnitKind::Howitzer => "M864 子母弹",
                    _ => "副武器弹",
                }
            } else {
                "弹药"
            };
            return Err(format!(
                "{} {}耗尽，无法发起攻击",
                attacker.name_with_label(),
                name
            ));
        }
        let d = Hex::distance(attacker_h, target_h);
        if d > attacker.eff_range() {
            return Err(format!(
                "{} 射程 {} 格，目标在 {} 格外，超出射程",
                attacker.name_with_label(),
                attacker.eff_range(),
                d
            ));
        }
        // 视野规则：目标单位必须被我方侦察到（任一己方单位 BFS 路程 ≤ 视野/隐蔽值
        // 内可见即可，视野共享；步兵隐蔽 2 → 视野/2，其它单位隐蔽 1 → 视野）。
        if !self.is_unit_visible(attacker.team, target_h) {
            return Err(format!(
                "{} 的目标 {} 未被侦察到（可能因隐蔽需要更近）",
                attacker.name_with_label(),
                target.name_with_label()
            ));
        }
        // 直射视线：直射武器要求攻击者到目标之间不被岩石/楼房/烟雾**内部**阻断
        //（共享视野可绕过视野遮挡，但不能绕过直射视线；端点格——攻击者/目标所在
        // 格——不阻挡，如攻击者或目标在楼房内/烟雾中仍可互相直射）。
        // 例外：**空中单位互相攻击**（空对空导弹，高抛弹道）不受地形 LOS 限制；
        // 地面防空打空中、空对地、地对地仍受 LOS 限制。
        // 间瞄火力（榴弹炮/迫击炮）已在上方转入 area_attack，无此要求。
        let air_to_air = attacker.kind.is_air() && target.kind.is_air();
        // 屋顶步兵：攻击不受任何 LOS 因素遮挡（视野/射击无视森林与楼房）
        let rooftop_shooter = attacker.rooftop && attacker.kind.is_foot();
        if !air_to_air && !rooftop_shooter && !self.map.has_los_ex(attacker_h, target_h, &self.smoke) {
            return Err(format!(
                "{} 的直射视线被岩石/楼房/烟雾阻隔，无法开火",
                attacker.name_with_label()
            ));
        }
        Ok((attacker, target))
    }

    /// 计算直射攻击命中率（含地形/闪避/诱饵弹/机动规避等所有乘区）。
    /// `use_flares` 表示本次攻击是否应消耗并应用目标诱饵弹；
    /// `maneuver_evasion` 表示目标直升机的“机动规避”是否生效（同时攻击 2 个及以上单位时失效）。
    pub fn direct_hit_rate(
        &self,
        attacker: &Unit,
        target: &Unit,
        target_h: Hex,
        use_flares: bool,
        maneuver_evasion: bool,
    ) -> (u32, String) {
        let mut hit_rate = attacker.eff_hit_rate();
        let mut terrain_note = String::new();
        let m3e1_mode = attacker.missile_mode
            && (attacker.kind == UnitKind::EliteInfantry || attacker.kind == UnitKind::SpecialForces);
        if !target.kind.is_air() {
            if m3e1_mode {
                // M3E1-HE 火箭筒：楼房内命中率 ×5/3（抵消×0.6 → 100%）；装甲单位 100%；其余 80%；森林惩罚仍生效
                if self.map.buildings.contains(&target_h) {
                    hit_rate = 100;
                    terrain_note = "（M3E1 楼房抵消×0.6→100%）".to_string();
                } else if target.kind.armor() >= 2 {
                    hit_rate = 100;
                    terrain_note = "（M3E1 对装甲×100%）".to_string();
                } else {
                    hit_rate = 80;
                }
                if self.map.forests.contains(&target_h) {
                    hit_rate = hit_rate * 4 / 5;
                    terrain_note.push_str("（森林×0.8）");
                }
            } else {
                if self.map.forests.contains(&target_h) {
                    hit_rate = hit_rate * 4 / 5;
                    terrain_note = "（森林隐蔽×0.8）".to_string();
                } else if self.map.buildings.contains(&target_h) && !target.rooftop {
                    // 屋顶步兵放弃楼房闪避（命中率不 ×0.6）
                    hit_rate = hit_rate * 3 / 5;
                    terrain_note = "（楼房隐蔽×0.6）".to_string();
                }
            }
            // 特战小队闪避：被命中率 ×0.8（森林中叠加 = 敌方命中率×0.64）
            if target.kind == UnitKind::SpecialForces {
                hit_rate = hit_rate * 4 / 5;
                terrain_note.push_str("（特战闪避×0.8）");
            }
            // 烟雾：目标在烟雾中 → 被命中率 ×0.6（与森林/楼房/闪避减益叠加）
            if self.smoke.contains_key(&target_h) {
                hit_rate = hit_rate * 3 / 5;
                terrain_note.push_str("（烟雾×0.6）");
            }
        }
        // 普通运输直升机：自带闪避——被命中率 ×0.8（与诱饵弹/其他减益叠加）
        if target.kind == UnitKind::TransportHeli {
            hit_rate = hit_rate * 4 / 5;
            terrain_note.push_str("（运直闪避×0.8）");
        }
        // 诱饵弹：武装/运输/重型运输直升机携带，被命中率 ×0.6（每次被攻击消耗 1 发）
        if use_flares
            && target.kind.is_air()
            && matches!(
                target.kind,
                UnitKind::AttackHeli | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
            )
            && target.flares > 0
        {
            hit_rate = hit_rate * 3 / 5;
            terrain_note.push_str("（诱饵弹×0.6）");
        }
        // 机动规避：武装直升机与轻型运输直升机被命中率 ×0.6；
        // 被 2 个及以上单位同时攻击时失效（由 simultaneous_attack 在成组时关闭）
        if maneuver_evasion
            && matches!(target.kind, UnitKind::AttackHeli | UnitKind::TransportHeli)
        {
            hit_rate = hit_rate * 3 / 5;
            terrain_note.push_str("（机动规避×0.6）");
        }
        (hit_rate, terrain_note)
    }

    /// 护甲抵挡：当攻击力**恰好等于**目标护甲值时，命中后掷 50% 概率被抵挡
    /// （虽然命中但不损失 HP）。只在攻防值相等时消耗随机数，避免影响其它随机序列。
    /// 结算顺序：先判主动防御，再判护甲抵挡。
    pub fn armor_deflects(&mut self, atk: i32, arm: i32) -> bool {
        atk == arm && self.rng.gen_range(0..100) < 50
    }

    /// 计算重机枪/机关炮对步兵的压制概率。
    /// 与命中率一样受地形隐蔽（森林/楼房）、特战闪避、烟雾等乘区影响。
    pub fn suppression_rate(
        &self,
        target: &Unit,
        target_h: Hex,
        base: u32,
    ) -> u32 {
        let mut rate = base;
        if !target.kind.is_air() {
            if self.map.forests.contains(&target_h) {
                rate = rate * 4 / 5;
            } else if self.map.buildings.contains(&target_h) && !target.rooftop {
                rate = rate * 3 / 5;
            }
            if target.kind == UnitKind::SpecialForces {
                rate = rate * 4 / 5;
            }
            if self.smoke.contains_key(&target_h) {
                rate = rate * 3 / 5;
            }
        }
        rate
    }

    /// 攻击核心：air_first=true 时攻击者优先取空中层（直升机），否则地面优先。
    fn attack_inner(
        &mut self,
        attacker_h: Hex,
        target_h: Hex,
        air_first: bool,
    ) -> Result<AttackOutcome, String> {
        // 榴弹炮/自行迫击炮仍走范围攻击结算（不进入单目标直射流程）
        if self
            .unit_at(attacker_h)
            .map(|u| u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
            .unwrap_or(false)
        {
            return self.area_attack(attacker_h, target_h);
        }
        let (attacker, mut target) =
            self.resolve_attacker_target(attacker_h, target_h, air_first, None)?;
        // 动画回放数据：受击前血量与目标标识（命中结算会修改 target）
        let target_hp_before = target.hp;
        let target_team = target.team;
        let target_label = target.label;
        let target_kind = target.kind;

        // 迷雾开火警告：开火者若不在对方视野内，给对方留下开火位置标记
        //（无论命中与否；对玩家与 AI 一视同仁）
        let foe = if attacker.team == Team::Player { Team::Ai } else { Team::Player };
        if !self.is_unit_visible(foe, attacker_h) {
            self.fog_fire_marks
                .entry(foe)
                .or_default()
                .insert(attacker_h, self.turn);
            self.elog(format!(
                "⚠ {} 从迷雾中开火，开火位置被对方标记",
                attacker.name_with_label()
            ));
        }

        let mut attacker = attacker;
        attacker.actions_left -= attacker.kind.attack_cost();
        if attacker.aa_mode {
            attacker.aa_ammo -= 1;
        } else if attacker.missile_mode {
            attacker.missile_ammo -= 1;
        } else {
            attacker.ammo -= 1; // 开火消耗 1 发弹药（无论是否命中）
        }
        self.put_unit(attacker.clone());

        // 地形/闪避/诱饵弹/机动规避等命中率乘区统一由 helper 计算。
        let use_flares = target.flares > 0;
        let (hit_rate, terrain_note) = self.direct_hit_rate(
            &attacker,
            &target,
            target_h,
            use_flares,
            true, // 单次攻击不存在“同时攻击”，机动规避始终生效
        );
        if use_flares && target.flares > 0 {
            target.flares -= 1;
        }
        let rate_txt = format!("{}{}", hit_rate, terrain_note);

        let roll = self.rng.gen_range(0..100);
        let hit = (roll as u32) < hit_rate;
        let atk = attacker.eff_attack();
        let arm = target.kind.armor();

        // 重机枪/机关炮/重机枪手对步兵的压制：与命中检定共用同一个随机数。
        // 命中一定压制；未命中但随机数仍低于压制率时也会造成压制。
        let suppress = if target.kind.is_direct_suppressible() && attacker.is_suppressing_weapon() {
            let sr = self.suppression_rate(&target, target_h, attacker.suppression_base());
            (roll as u32) < sr
        } else {
            false
        };

        // 步枪手 M3E1-XM1176：命中楼房中的敌人强制击杀
        let xm1176_building = attacker.kind == UnitKind::Rifleman
            && attacker.missile_mode
            && !target.kind.is_air()
            && self.map.buildings.contains(&target_h)
            && !target.rooftop; // 屋顶步兵不在楼内，不吃 XM1176 强制击杀

        let mut ev_dmg: i32 = 0; // 动画回放：本次实际伤害（强制击杀记为全部血量）
        // 结构化战报用：本发子弹的击毁成因（强制击杀/致命伤分支各自覆盖）
        let mut kill_cause = KillCause::DirectFire;
        let (message, hit_flag, blocked, killed) = if !hit {
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} —— 未命中!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt
                ),
                false,
                false,
                false,
            )
        } else if xm1176_building {
            // M3E1-XM1176：楼内目标强制击杀（无视护甲/血量）
            target.hp = 0;
            ev_dmg = target_hp_before;
            kill_cause = KillCause::DirectFire;
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! M3E1-XM1176 对楼房内目标强制击杀!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt
                ),
                true,
                false,
                true,
            )
        } else if target.ad_uses > 0 && atk >= arm && !attacker.is_tank_gun_mode() {
            // 主动防御（主战坦克/装甲骑兵战车）：单次攻击被“实际命中”（能造成伤害）即消耗 1 次充能抵消，
            // 不再限制“回合首次命中”；同回合多次遇袭可多次触发（只要有剩余次数）。
            // 坦克炮例外：不会触发主动防御，也不会被主动防御抵消。
            target.ad_uses -= 1;
            self.notices.entry(target.team).or_default().push(format!(
                "🛡 {} 启动主动防御，抵消 {} 的一次攻击（剩余 {} 次）",
                target.name_with_label(),
                attacker.name_with_label(),
                target.ad_uses
            ));
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! 但 {} 启动主动防御，免疫本次伤害（剩余 {} 次）",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    target.name_with_label(),
                    target.ad_uses
                ),
                true,
                true,
                false,
            )
        } else if self.armor_deflects(atk, arm) {
            // 护甲抵挡：攻击力恰好等于目标护甲，命中但 50% 被抵挡（不掉血）。
            // 顺序在主动防御之后：即使逃过主动防御，仍可能被护甲抵挡。
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! 但攻击力 {} = 护甲 {}，被护甲抵挡，未造成伤害!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    atk,
                    arm
                ),
                true,
                true,
                false,
            )
        } else if hit
            && matches!(
                target.kind,
                UnitKind::AttackHeli | UnitKind::HeavyTransportHeli
            )
            && self.rng.gen_range(0..100) < 50
        {
            // 致命伤：武装直升机/重型运输直升机被命中要害，50% 概率直接坠毁
            //（无视此前血量与护甲）
            target.hp = 0;
            ev_dmg = target_hp_before;
            kill_cause = KillCause::FatalHit;
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! 💥 致命伤——{} 被命中要害，直接坠毁!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    target.name_with_label()
                ),
                true,
                false,
                true,
            )
        } else if hit && {
            // 悍马系列：被机炮（40%）命中时直接击毁；坦克炮不再直接击毁，改走殉爆 80%
            let p = attacker.humvee_instant_kill_chance(target.kind);
            p > 0 && self.rng.gen_range(0..100) < p as i32
        } {
            target.hp = 0;
            ev_dmg = target_hp_before;
            kill_cause = KillCause::DirectFire;
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! 💥 {}被{}直接击毁!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    target.name_with_label(),
                    "机炮"
                ),
                true,
                false,
                true,
            )
        } else if atk < arm {
            (
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中，但攻击力 {} < 护甲 {}，攻击无效!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    atk,
                    arm
                ),
                true,
                true,
                false,
            )
        } else {
            // 重机枪手 / 车载重机枪：攻击步兵时 50% 概率造成 2 点伤害（重弹命中要害）
            // 坦克炮：攻击车辆时按目标「殉爆」概率造成 2 点伤害
            //（主战坦克 30%、一般坦克 60%、步战/骑兵战车 60%、其它护甲2 70%、护甲1 80%）。
            let mut dmg = 1;
            let mut cook_off = false;
            if (attacker.kind == UnitKind::HmgGunner || attacker.is_heavy_mg_mode())
                && target.kind.is_foot()
                && self.rng.gen_range(0..100) < 50
            {
                dmg = 2;
            }
            let cook_off_p = target.kind.cook_off_chance();
            if attacker.is_tank_gun_mode()
                && cook_off_p > 0
                && self.rng.gen_range(0..100) < cook_off_p as i32
            {
                dmg = 2;
                cook_off = true;
            }
            let dmg_note = if dmg == 2 {
                if cook_off { "（殉爆！）" } else { "（重弹！）" }
            } else {
                ""
            };
            ev_dmg = dmg;
            target.hp -= dmg;
            let killed = !target.is_alive();
            let passenger_txt = if killed && !target.passengers.is_empty() {
                let names: Vec<String> = target.passengers.iter().map(|p| p.name_with_label()).collect();
                format!("，搭载的{}也随之阵亡", names.join("、"))
            } else {
                String::new()
            };
            let msg = if killed {
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! 攻击力 {} ≥ 护甲 {}，造成{}点伤害{}，{} 被摧毁{}!",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    atk,
                    arm,
                    dmg,
                    dmg_note,
                    target.name_with_label(),
                    passenger_txt
                )
            } else {
                format!(
                    "{} 攻击 {}: 命中检定 {}/{} 命中! 造成{}点伤害{}（{} 剩余血量 {}）",
                    attacker.name_with_label(),
                    target.name_with_label(),
                    roll,
                    rate_txt,
                    dmg,
                    dmg_note,
                    target.name_with_label(),
                    target.hp
                )
            };
            (msg, true, false, killed)
        };

        let mut kills = Vec::new();
        if killed {
            kills.push(target_h);
            self.note_kill(
                &target,
                Some((attacker.team, attacker.label, attacker.kind, attacker_h)),
                kill_cause,
            );
            self.remove_unit(target_h);
        } else {
            if suppress {
                target.suppression_stacks += 1;
                target.suppressed = true;
            }
            self.put_unit(target);
        }
        // GUI 动画回放：记录本次直射开火
        self.ui_events.push(UiEvent::Fire(UiFireEvent {
            team: attacker.team,
            label: attacker.label,
            kind: attacker.kind,
            from: attacker_h,
            target: target_h,
            target_team,
            target_label,
            target_kind,
            aa_mode: attacker.aa_mode,
            missile_mode: attacker.missile_mode,
            area: false,
            smoke_shell: false,
            blast: Vec::new(),
            hit: hit_flag,
            blocked,
            killed,
            target_hp_before,
            dmg: ev_dmg,
            killed_units: if killed {
                vec![KilledUnit {
                    hex: target_h,
                    team: target_team,
                    kind: target_kind,
                    label: target_label,
                    hp_before: target_hp_before,
                }]
            } else {
                Vec::new()
            },
        }));
        // 弹药提示：耗尽或所剩无几时在消息中注明
        let mut message = message;
        if suppress && !killed {
            message.push_str("（压制！）");
        }
        let shown = attacker.ammo_shown();
        let ammo_name = attacker.mode_name();
        if shown == 0 {
            message.push_str(&format!("（{}耗尽！）", ammo_name));
        } else if shown <= 2 {
            message.push_str(&format!("（{}剩 {}）", ammo_name, shown));
        }
        self.elog(message.clone());
        Ok(AttackOutcome {
            message,
            hit: hit_flag,
            blocked,
            killed: !kills.is_empty(),
            kills,
        })
    }

    /// 校验范围攻击（榴弹炮/迫击炮）命令，返回应用了武器模式快照的攻击者和是否使用 M864。
    fn resolve_area_attacker(
        &self,
        attacker_h: Hex,
        center: Hex,
        mode_override: Option<(bool, bool)>,
    ) -> Result<(Unit, bool), String> {
        let mut attacker = self
            .units
            .get(&attacker_h)
            .ok_or("攻击方不存在")?
            .clone(); // 榴弹炮/迫击炮是地面单位
        if let Some((aa_mode, missile_mode)) = mode_override {
            attacker.aa_mode = aa_mode;
            attacker.missile_mode = missile_mode;
        }
        if attacker.kind != UnitKind::Howitzer && attacker.kind != UnitKind::Mortar {
            return Err(format!("{} 不是范围攻击单位", attacker.name_with_label()));
        }
        if attacker.kind == UnitKind::Howitzer && !attacker.deployed {
            return Err(format!(
                "{} 尚未架设，无法开火（先架设消耗 1 次行动）",
                attacker.name_with_label()
            ));
        }
        let cost = attacker.kind.attack_cost();
        if attacker.actions_left < cost {
            return Err(format!(
                "{} 行动次数不足（当前剩余 {}）",
                attacker.name_with_label(),
                attacker.actions_left
            ));
        }
        let m864 = attacker.kind == UnitKind::Howitzer && attacker.missile_mode;
        if m864 && attacker.missile_ammo < 1 {
            return Err(format!(
                "{} M864 子母弹耗尽（仅剩 {} 发常规弹，可切回常规模式）",
                attacker.name_with_label(),
                attacker.ammo
            ));
        }
        if !m864 && attacker.ammo < 1 {
            return Err(format!(
                "{} 弹药耗尽，无法炮击",
                attacker.name_with_label()
            ));
        }
        if !self.map.contains(center) {
            return Err("炮击目标不在地图内".into());
        }
        let d = Hex::distance(attacker_h, center);
        if d > attacker.kind.range() {
            return Err(format!(
                "{} 射程 {} 格，目标在 {} 格外，超出射程",
                attacker.name_with_label(),
                attacker.kind.range(),
                d
            ));
        }
        Ok((attacker, m864))
    }

    /// 校验一条同时攻击命令（不消耗行动/弹药、不修改状态）。
    pub fn validate_simul_order(&self, order: SimulOrder) -> Result<(), String> {
        if order.attacker == order.target {
            return Err("不能攻击自己所在格".into());
        }
        let is_area = self
            .units
            .get(&order.attacker)
            .map(|u| u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
            .unwrap_or(false);
        if is_area {
            self.resolve_area_attacker(
                order.attacker,
                order.target,
                Some((order.aa_mode, order.missile_mode)),
            )?;
        } else {
            self.resolve_attacker_target(
                order.attacker,
                order.target,
                order.air_first,
                Some((order.aa_mode, order.missile_mode)),
            )?;
        }
        Ok(())
    }

    /// 同时攻击：将多条攻击命令作为一个“齐射”结算。
    ///
    /// 规则：
    /// - 先分别对每条攻击做命中检定；
    /// - 同一目标的伤害加和后一次性结算；
    /// - 主动防御不再按“回合首次命中”触发，而是每次单次攻击/每次同时攻击结果触发一次：
    ///   单发命中抵消该发伤害；同时攻击中若命中 1 发抵消该发，若命中 ≥2 发则随机抵消其中 1 发；
    /// - 武装/轻型运输直升机“机动规避”在同时攻击中被 2 个及以上单位集火时失效。
    pub fn simultaneous_attack(&mut self, orders: &[SimulOrder]) -> Result<Vec<AttackOutcome>, String> {
        if orders.is_empty() {
            return Err("没有同时攻击命令".into());
        }

        enum Prepared {
            Direct {
                attacker: Unit,
                target: Unit,
                order: SimulOrder,
            },
            Area {
                attacker: Unit,
                order: SimulOrder,
            },
        }

        let mut validated: Vec<Prepared> = Vec::with_capacity(orders.len());
        let mut seen_attackers: HashSet<(Hex, bool)> = HashSet::new();
        for order in orders {
            let is_area = self
                .units
                .get(&order.attacker)
                .map(|u| u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
                .unwrap_or(false);
            if is_area {
                let (attacker, _) = self.resolve_area_attacker(
                    order.attacker,
                    order.target,
                    Some((order.aa_mode, order.missile_mode)),
                )?;
                if !seen_attackers.insert((order.attacker, false)) {
                    return Err(format!(
                        "{} 重复下达同时攻击命令",
                        attacker.name_with_label()
                    ));
                }
                validated.push(Prepared::Area {
                    attacker,
                    order: *order,
                });
            } else {
                let (attacker, target) = self.resolve_attacker_target(
                    order.attacker,
                    order.target,
                    order.air_first,
                    Some((order.aa_mode, order.missile_mode)),
                )?;
                if !seen_attackers.insert((order.attacker, order.air_first)) {
                    return Err(format!(
                        "{} 重复下达同时攻击命令",
                        attacker.name_with_label()
                    ));
                }
                validated.push(Prepared::Direct {
                    attacker,
                    target,
                    order: *order,
                });
            }
        }

        // 迷雾开火警告 + 消耗各攻击者的行动/弹药（全部校验通过后才开始消耗）
        for prep in &validated {
            let (attacker, order) = match prep {
                Prepared::Direct { attacker, order, .. } => (attacker, order),
                Prepared::Area { attacker, order } => (attacker, order),
            };
            let foe = if attacker.team == Team::Player { Team::Ai } else { Team::Player };
            if !self.is_unit_visible(foe, order.attacker) {
                self.fog_fire_marks
                    .entry(foe)
                    .or_default()
                    .insert(order.attacker, self.turn);
                self.elog(format!(
                    "⚠ {} 从迷雾中开火，开火位置被对方标记",
                    attacker.name_with_label()
                ));
            }
            let mut att = attacker.clone();
            att.actions_left -= att.kind.attack_cost();
            if att.aa_mode {
                att.aa_ammo -= 1;
            } else if att.missile_mode {
                att.missile_ammo -= 1;
            } else {
                att.ammo -= 1;
            }
            self.put_unit(att);
        }

        // 统计每个目标被同时攻击的次数（只统计直射攻击，范围攻击不打空中单位，
        // 不参与直升机“机动规避”失效判定）
        let mut target_counts: HashMap<Hex, usize> = HashMap::new();
        for prep in &validated {
            if let Prepared::Direct { order, .. } = prep {
                *target_counts.entry(order.target).or_insert(0) += 1;
            }
        }

        // 每个直射目标的当前状态副本：用于按攻击顺序递减诱饵弹
        let mut target_state: HashMap<Hex, Unit> = HashMap::new();
        for prep in &validated {
            if let Prepared::Direct { target, .. } = prep {
                target_state.entry(target.pos).or_insert_with(|| target.clone());
            }
        }

        struct Shot {
            target_h: Hex,
            attacker_team: Team,
            attacker_label: char,
            attacker_kind: UnitKind,
            attacker_from: Hex,
            attacker_aa_mode: bool,
            attacker_missile_mode: bool,
            attacker_name: String,
            target_team: Team,
            target_label: char,
            target_kind: UnitKind,
            target_name: String,
            roll: i32,
            rate_txt: String,
            hit: bool,
            blocked: bool,
            /// 护甲抵挡：攻击力恰好等于护甲，命中后 50% 概率被抵挡（不掉血）
            armor_block: bool,
            atk: i32,
            arm: i32,
            dmg: i32,
            /// 本次 2 点伤害是否为坦克炮殉爆（否则为重机枪重弹）
            cook_off: bool,
            xm1176: bool,
            fatal: bool,
            /// 悍马系列被机炮命中直接击毁
            humvee_kill: bool,
            area: bool,
            ad_blocked: bool,
            suppress: bool,
            tank_gun: bool,
        }

        let mut shots: Vec<Shot> = Vec::new();
        let mut area_suppress: Vec<(Team, UnitKind, Vec<Hex>)> = Vec::new();
        let mut empty_area_outcomes: Vec<AttackOutcome> = Vec::new();

        for prep in &validated {
            match prep {
                Prepared::Direct {
                    attacker,
                    order,
                    ..
                } => {
                    let t = target_state.get_mut(&order.target).unwrap();
                    let use_flares = t.flares > 0;
                    let maneuver_evasion = !(target_counts[&order.target] >= 2
                        && matches!(t.kind, UnitKind::AttackHeli | UnitKind::TransportHeli));
                    let (rate, note) = self.direct_hit_rate(
                        attacker,
                        t,
                        order.target,
                        use_flares,
                        maneuver_evasion,
                    );
                    let roll = self.rng.gen_range(0..100);
                    let hit = (roll as u32) < rate;
                    if use_flares && t.flares > 0 {
                        t.flares -= 1;
                    }
                    let atk = attacker.eff_attack();
                    let arm = t.kind.armor();
                    let xm1176 = attacker.kind == UnitKind::Rifleman
                        && attacker.missile_mode
                        && !t.kind.is_air()
                        && self.map.buildings.contains(&order.target)
                        && !t.rooftop;
                    let fatal = hit
                        && matches!(t.kind, UnitKind::AttackHeli | UnitKind::HeavyTransportHeli)
                        && self.rng.gen_range(0..100) < 50;
                    let humvee_kill = hit && {
                        let p = attacker.humvee_instant_kill_chance(t.kind);
                        p > 0 && self.rng.gen_range(0..100) < p as i32
                    };
                    let suppress = if t.kind.is_direct_suppressible() && attacker.is_suppressing_weapon() {
                        let sr = self.suppression_rate(t, order.target, attacker.suppression_base());
                        (roll as u32) < sr
                    } else {
                        false
                    };
                    let tank_gun = attacker.is_tank_gun_mode();
                    let mut dmg = 1;
                    let mut cook_off = false;
                    if (attacker.kind == UnitKind::HmgGunner || attacker.is_heavy_mg_mode())
                        && t.kind.is_foot()
                        && self.rng.gen_range(0..100) < 50
                    {
                        dmg = 2;
                    }
                    let cook_off_p = t.kind.cook_off_chance();
                    if attacker.is_tank_gun_mode()
                        && cook_off_p > 0
                        && self.rng.gen_range(0..100) < cook_off_p as i32
                    {
                        dmg = 2;
                        cook_off = true;
                    }
                    shots.push(Shot {
                        target_h: order.target,
                        attacker_team: attacker.team,
                        attacker_label: attacker.label,
                        attacker_kind: attacker.kind,
                        attacker_from: order.attacker,
                        attacker_aa_mode: attacker.aa_mode,
                        attacker_missile_mode: attacker.missile_mode,
                        attacker_name: attacker.name_with_label(),
                        target_team: t.team,
                        target_label: t.label,
                        target_kind: t.kind,
                        target_name: t.name_with_label(),
                        roll,
                        rate_txt: format!("{}{}", rate, note),
                        hit,
                        blocked: hit && atk < arm,
                        armor_block: false, // 先判定主动防御，再判定护甲抵挡（见结算处）
                        atk,
                        arm,
                        dmg,
                        cook_off,
                        xm1176,
                        fatal,
                        humvee_kill,
                        area: false,
                        ad_blocked: false,
                        suppress,
                        tank_gun,
                    });
                }
                Prepared::Area { attacker, order } => {
                    let center = order.target;
                    let mut blast = vec![center];
                    for n in center.neighbors() {
                        if self.map.contains(n) {
                            blast.push(n);
                        }
                    }
                    area_suppress.push((attacker.team, attacker.kind, blast.clone()));
                    let before = shots.len();
                    // 与单发范围攻击一致：中心/周围命中率、地形隐蔽、特战闪避
                    let (center_rate, ring_rate) = match (attacker.kind, attacker.missile_mode) {
                        (UnitKind::Mortar, _) => (60, 30),
                        (UnitKind::Howitzer, true) => (100, 100),
                        _ => (80, 50),
                    };
                    for h in &blast {
                        if let Some(u) = self.units.get(h) {
                            if u.kind.is_air() {
                                continue;
                            }
                            let u = u.clone();
                            let mut rate = if *h == center { center_rate } else { ring_rate };
                            if self.map.forests.contains(h) {
                                rate = rate * 4 / 5;
                            } else if self.map.buildings.contains(h) {
                                rate = rate * 3 / 5;
                            }
                            if u.kind == UnitKind::SpecialForces {
                                rate = rate * 4 / 5;
                            }
                            let roll = self.rng.gen_range(0..100);
                            let hit = (roll as u32) < rate;
                            let atk = attacker.eff_attack();
                            let arm = u.kind.armor();
                            shots.push(Shot {
                                target_h: *h,
                                attacker_team: attacker.team,
                                attacker_label: attacker.label,
                                attacker_kind: attacker.kind,
                                attacker_from: order.attacker,
                                attacker_aa_mode: attacker.aa_mode,
                                attacker_missile_mode: attacker.missile_mode,
                                attacker_name: attacker.name_with_label(),
                                target_team: u.team,
                                target_label: u.label,
                                target_kind: u.kind,
                                target_name: u.name_with_label(),
                                roll,
                                rate_txt: rate.to_string(),
                                hit,
                                blocked: hit && atk < arm,
                                armor_block: false, // 结算处统一判定
                                atk,
                                arm,
                                dmg: 1,
                                cook_off: false,
                                xm1176: false,
                                fatal: false,
                                humvee_kill: false,
                                area: true,
                                ad_blocked: false,
                                suppress: false,
                                tank_gun: false,
                            });
                        }
                    }
                    if shots.len() == before {
                        empty_area_outcomes.push(AttackOutcome {
                            message: format!(
                                "⚔ {} 炮击 {}：范围内无目标",
                                attacker.name_with_label(),
                                hex::hex_label(center)
                            ),
                            hit: false,
                            blocked: false,
                            killed: false,
                            kills: Vec::new(),
                        });
                    }
                }
            }
        }

        // 把诱饵弹消耗写回地图
        for (_, t) in target_state {
            self.put_unit(t);
        }

        // 按目标分组，每组分别结算主动防御、伤害加和与击杀
        let mut groups: BTreeMap<Hex, Vec<Shot>> = BTreeMap::new();
        for shot in shots {
            groups.entry(shot.target_h).or_default().push(shot);
        }

        let mut outcomes: Vec<AttackOutcome> = Vec::new();
        for (target_h, mut target_shots) in groups {
            let mut target = match self.unit_at(target_h).cloned() {
                Some(u) => u,
                None => continue,
            };
            // 动画回放：目标受击前血量
            let target_hp_before = target.hp;
            // 主动防御：每次同时攻击结果触发一次；范围攻击延续原规则，不触发主动防御
            if target.ad_uses > 0 {
                let actual: Vec<usize> = target_shots
                    .iter()
                    .enumerate()
                    .filter(|(_, s)| s.hit && !s.blocked && !s.area && !s.tank_gun)
                    .map(|(i, _)| i)
                    .collect();
                if !actual.is_empty() {
                    target.ad_uses -= 1;
                    self.notices.entry(target.team).or_default().push(format!(
                        "🛡 {} 启动主动防御，抵消一次同时攻击（剩余 {} 次）",
                        target.name_with_label(),
                        target.ad_uses
                    ));
                    let chosen = if actual.len() == 1 {
                        actual[0]
                    } else {
                        actual[self.rng.gen_range(0..actual.len())]
                    };
                    target_shots[chosen].ad_blocked = true;
                }
            }

            // 护甲抵挡：主动防御判定之后，对仍会命中掉血、且攻击力恰好等于护甲的射击
            // 单独掷 50% 抵挡（命中但不掉血）。
            for s in target_shots.iter_mut() {
                if s.hit && !s.ad_blocked && s.atk == s.arm {
                    s.armor_block = self.rng.gen_range(0..100) < 50;
                }
            }

            let mut total_dmg = 0;
            let mut special_kill = false;
            let mut any_hit = false;
            let mut any_blocked = false;
            let mut parts: Vec<String> = Vec::new();
            for shot in &target_shots {
                let rate_txt = &shot.rate_txt;
                if !shot.hit {
                    parts.push(format!(
                        "{} 未命中 {}/{}",
                        shot.attacker_name, shot.roll, rate_txt
                    ));
                } else if shot.ad_blocked {
                    any_hit = true;
                    any_blocked = true;
                    parts.push(format!(
                        "{} 命中 {}/{}，但被 {} 主动防御抵消",
                        shot.attacker_name, shot.roll, rate_txt, shot.target_name
                    ));
                } else if shot.blocked {
                    any_hit = true;
                    any_blocked = true;
                    parts.push(format!(
                        "{} 命中 {}/{}，但攻击力 {} < 护甲 {}，未造成伤害",
                        shot.attacker_name,
                        shot.roll,
                        rate_txt,
                        shot.atk,
                        shot.arm
                    ));
                } else if shot.armor_block {
                    any_hit = true;
                    any_blocked = true;
                    parts.push(format!(
                        "{} 命中 {}/{}，但攻击力 {} = 护甲 {}，被护甲抵挡，未造成伤害",
                        shot.attacker_name,
                        shot.roll,
                        rate_txt,
                        shot.atk,
                        shot.arm
                    ));
                } else if shot.xm1176 {
                    any_hit = true;
                    special_kill = true;
                    parts.push(format!(
                        "{} 命中 {}/{}，M3E1-XM1176 对楼房内目标强制击杀!",
                        shot.attacker_name, shot.roll, rate_txt
                    ));
                } else if shot.fatal {
                    any_hit = true;
                    special_kill = true;
                    parts.push(format!(
                        "{} 命中 {}/{}，💥 致命伤——{} 直接坠毁!",
                        shot.attacker_name, shot.roll, rate_txt, shot.target_name
                    ));
                } else if shot.humvee_kill {
                    any_hit = true;
                    special_kill = true;
                    parts.push(format!(
                        "{} 命中 {}/{}，💥 机炮直击——{} 被直接击毁!",
                        shot.attacker_name, shot.roll, rate_txt, shot.target_name
                    ));
                } else {
                    any_hit = true;
                    total_dmg += shot.dmg;
                    parts.push(format!(
                        "{} 命中 {}/{}，造成 {} 点伤害{}",
                        shot.attacker_name,
                        shot.roll,
                        rate_txt,
                        shot.dmg,
                        if shot.dmg == 2 {
                            if shot.cook_off { "（殉爆！）" } else { "（重弹！）" }
                        } else {
                            ""
                        }
                    ));
                }
            }

            if special_kill {
                target.hp = 0;
            } else if total_dmg > 0 {
                target.hp -= total_dmg;
            }

            let killed = !target.is_alive();
            let target_name = target.name_with_label();
            let mut kills: Vec<Hex> = Vec::new();
            let passenger_txt = if killed && !target.passengers.is_empty() {
                let names: Vec<String> = target.passengers.iter().map(|p| p.name_with_label()).collect();
                format!("，搭载的{}也随之阵亡", names.join("、"))
            } else {
                String::new()
            };
            if killed {
                kills.push(target_h);
                // 齐射里可能有多发命中：以第一发命中者作为战报归属，
                // 致命伤/强制击杀优先记录其成因。
                let primary = target_shots
                    .iter()
                    .find(|s| s.fatal || s.xm1176 || s.humvee_kill)
                    .or_else(|| target_shots.iter().find(|s| s.hit));
                match primary {
                    Some(s) => {
                        let cause = if s.fatal {
                            KillCause::FatalHit
                        } else if s.area {
                            KillCause::Artillery
                        } else {
                            KillCause::DirectFire
                        };
                        self.note_kill(
                            &target,
                            Some((s.attacker_team, s.attacker_label, s.attacker_kind, s.attacker_from)),
                            cause,
                        );
                    }
                    None => self.note_kill(&target, None, KillCause::DirectFire),
                }
                self.remove_unit(target_h);
                parts.push(format!(
                    "{} 被摧毁{}！",
                    target_name,
                    passenger_txt
                ));
            } else {
                if total_dmg > 0 || special_kill {
                    parts.push(format!(
                        "{} 合计受到 {} 点伤害，剩余血量 {}",
                        target_name,
                        if special_kill { "致命".to_string() } else { total_dmg.to_string() },
                        target.hp
                    ));
                }
                let suppress_stacks = target_shots.iter().filter(|s| s.suppress).count();
                if suppress_stacks > 0 {
                    target.suppression_stacks += suppress_stacks as i32;
                    target.suppressed = true;
                    parts.push(format!(
                        "受到 {} 层压制",
                        suppress_stacks
                    ));
                }
                self.put_unit(target);
            }
            // GUI 动画回放：每发攻击记录一条事件（击杀标记给第一发有效命中）
            let mut kill_assigned = false;
            for s in &target_shots {
                let shot_kill = killed && !kill_assigned && s.hit && !s.blocked && !s.ad_blocked && !s.armor_block;
                if shot_kill {
                    kill_assigned = true;
                }
                let no_damage = !s.hit || s.blocked || s.ad_blocked || s.armor_block;
                self.ui_events.push(UiEvent::Fire(UiFireEvent {
                    team: s.attacker_team,
                    label: s.attacker_label,
                    kind: s.attacker_kind,
                    from: s.attacker_from,
                    target: target_h,
                    target_team: s.target_team,
                    target_label: s.target_label,
                    target_kind: s.target_kind,
                    aa_mode: s.attacker_aa_mode,
                    missile_mode: s.attacker_missile_mode,
                    area: s.area,
                    smoke_shell: false,
                    blast: Vec::new(),
                    hit: s.hit,
                    blocked: s.blocked || s.ad_blocked || s.armor_block,
                    killed: shot_kill,
                    target_hp_before,
                    dmg: if shot_kill {
                        target_hp_before
                    } else if no_damage {
                        0
                    } else {
                        s.dmg
                    },
                    killed_units: if shot_kill {
                        vec![KilledUnit {
                            hex: target_h,
                            team: s.target_team,
                            kind: s.target_kind,
                            label: s.target_label,
                            hp_before: target_hp_before,
                        }]
                    } else {
                        Vec::new()
                    },
                }));
            }
            let message = format!("⚔ 同时攻击 {}：{}", target_name, parts.join("；"));
            self.elog(message.clone());
            outcomes.push(AttackOutcome {
                message,
                hit: any_hit,
                blocked: any_blocked,
                killed: !kills.is_empty(),
                kills,
            });
        }

        // 范围攻击的压制：范围内所有敌军（无论命中与否）获得 1 回合压制，可叠加。
        // 例外：榴弹炮/迫击炮无法压制护甲 ≥ 2 的单位（炮弹破片对其无效）。
        let mut suppressed_names: Vec<String> = Vec::new();
        for (team, attacker_kind, cells) in area_suppress {
            for h in cells {
                if let Some(u) = self.units.get(&h).cloned() {
                    if u.team != team
                        && !u.kind.is_air()
                        && attacker_kind.artillery_suppresses(u.kind)
                    {
                        let mut su = u.clone();
                        su.suppression_stacks += 1;
                        su.suppressed = true;
                        self.units.insert(h, su);
                        suppressed_names.push(u.name_with_label());
                    }
                }
            }
        }
        if !suppressed_names.is_empty() {
            let msg = format!(
                "💥 同时攻击炮击压制：{} 新回合行动减少",
                suppressed_names.join("、")
            );
            self.elog(msg.clone());
            outcomes.push(AttackOutcome {
                message: msg,
                hit: false,
                blocked: false,
                killed: false,
                kills: Vec::new(),
            });
        }

        outcomes.extend(empty_area_outcomes);
        if outcomes.is_empty() {
            return Err("同时攻击结算失败：所有目标均已消失".into());
        }
        Ok(outcomes)
    }

    /// 榴弹炮范围攻击：以 center 为中心辐射 1 格（共 7 格），
    /// 每格独立计算命中（中心 70%，周围 40%）。范围内敌我双方都会被波及。
    fn area_attack(&mut self, attacker_h: Hex, center: Hex) -> Result<AttackOutcome, String> {
        let mut attacker = self.units.get(&attacker_h).ok_or("攻击方不存在")?.clone(); // 榴弹炮/迫击炮是地面单位
        // 榴弹炮需先架设；自行迫击炮无需架设即可开火
        if attacker.kind == UnitKind::Howitzer && !attacker.deployed {
            return Err(format!(
                "{} 尚未架设，无法开火（先架设消耗 1 次行动）",
                attacker.name_with_label()
            ));
        }
        let cost = attacker.kind.attack_cost();
        if attacker.actions_left < cost {
            return Err(format!(
                "{} 行动次数不足（当前剩余 {}）",
                attacker.name_with_label(),
                attacker.actions_left
            ));
        }
        let m864 = attacker.kind == UnitKind::Howitzer && attacker.missile_mode;
        if m864 && attacker.missile_ammo < 1 {
            return Err(format!(
                "{} M864 子母弹耗尽（仅剩 {} 发常规弹，可切回常规模式）",
                attacker.name_with_label(),
                attacker.ammo
            ));
        }
        if !m864 && attacker.ammo < 1 {
            return Err(format!(
                "{} 弹药耗尽，无法炮击",
                attacker.name_with_label()
            ));
        }
        let d = Hex::distance(attacker_h, center);
        if d > attacker.kind.range() {
            return Err(format!(
                "{} 射程 {} 格，目标在 {} 格外，超出射程",
                attacker.name_with_label(),
                attacker.kind.range(),
                d
            ));
        }
        // 榴弹炮是间瞄火力（抛物线弹道）：不需要直线视线，岩石/楼房/森林均不阻挡，
        // 射程内任意格子皆可炮击（无需视野已在攻击入口处保证）。
        // 迷雾开火警告（榴弹炮盲射同样暴露炮位，双方公平）
        let foe = if attacker.team == Team::Player { Team::Ai } else { Team::Player };
        if !self.is_unit_visible(foe, attacker_h) {
            self.fog_fire_marks
                .entry(foe)
                .or_default()
                .insert(attacker_h, self.turn);
            self.elog(format!(
                "⚠ {} 从迷雾中开火，开火位置被对方标记",
                attacker.name_with_label()
            ));
        }

        attacker.actions_left -= cost;
        if m864 {
            attacker.missile_ammo -= 1; // M864 子母弹
        } else {
            attacker.ammo -= 1; // 炮击消耗 1 发炮弹
        }
        self.units.insert(attacker_h, attacker.clone());
        let atk = attacker.eff_attack(); // 常规 2 / M864 3
        // 注：空中单位（直升机）不在 ground 层，不会被榴弹炮波及

        // 7 格：中心 + 6 邻格（限地图内）
        let mut blast = vec![center];
        for n in center.neighbors() {
            if self.map.contains(n) {
                blast.push(n);
            }
        }

        struct BlastHit {
            hex: Hex,
            name: String,
            roll: i32,
            rate: u32,
            hit: bool,
            damages: bool,
            /// 护甲抵挡（攻击力 == 护甲，命中但 50% 被挡）
            armor_block: bool,
        }
        let mut hits: Vec<BlastHit> = Vec::new();
        for h in &blast {
            if let Some(u) = self.units.get(h) {
                if u.kind.is_air() {
                    continue; // 榴弹炮打不到空中单位
                }
                let u = u.clone();
                // 地形隐蔽同样作用于炮击命中率；中心/周围命中率按兵种：
                // 榴弹炮常规 80%/50%、M864 子母弹 100%/100%、自行迫击炮 60%/30%
                let (center_rate, ring_rate) = match (attacker.kind, attacker.missile_mode) {
                    (UnitKind::Mortar, _) => (60, 30),
                    (UnitKind::Howitzer, true) => (100, 100),
                    _ => (80, 50),
                };
                let mut rate = if *h == center { center_rate } else { ring_rate };
                if self.map.forests.contains(h) {
                    rate = rate * 4 / 5;
                } else if self.map.buildings.contains(h) {
                    rate = rate * 3 / 5;
                }
                if u.kind == UnitKind::SpecialForces {
                    rate = rate * 4 / 5; // 特战闪避 ×0.8
                }
                let roll = self.rng.gen_range(0..100);
                let hit = (roll as u32) < rate;
                let arm = u.kind.armor();
                let armor_block = hit && self.armor_deflects(atk, arm);
                hits.push(BlastHit {
                    hex: *h,
                    name: u.name_with_label(),
                    roll,
                    rate,
                    hit,
                    damages: hit && atk >= arm && !armor_block,
                    armor_block,
                });
            }
        }

        // 压制：范围内所有敌军（无论命中与否）获得 1 回合压制（可叠加）。
        // 例外：榴弹炮/迫击炮无法压制护甲 ≥ 2 的单位（炮弹破片对其无效）。
        let mut suppressed_names: Vec<String> = Vec::new();
        for h in &blast {
            if let Some(u) = self.units.get(h).cloned() {
                if u.team != attacker.team
                    && !u.kind.is_air()
                    && attacker.kind.artillery_suppresses(u.kind)
                {
                    let mut su = u.clone();
                    su.suppression_stacks += 1;
                    su.suppressed = true;
                    self.units.insert(*h, su);
                    suppressed_names.push(u.name_with_label());
                }
            }
        }

        let mut parts: Vec<String> = Vec::new();
        let mut kills: Vec<Hex> = Vec::new();
        let mut killed_units: Vec<KilledUnit> = Vec::new();
        for bh in &hits {
            if bh.damages {
                if let Some(mut u) = self.units.get(&bh.hex).cloned() {
                    let hp_before = u.hp;
                    u.hp -= 1;
                    if u.is_alive() {
                        let hp = u.hp;
                        self.units.insert(bh.hex, u);
                        parts.push(format!("{}: 命中{}/{} 受创(剩{})", bh.name, bh.roll, bh.rate, hp));
                    } else {
                        killed_units.push(KilledUnit {
                            hex: bh.hex,
                            team: u.team,
                            kind: u.kind,
                            label: u.label,
                            hp_before,
                        });
                        // 战报：范围火力击毁（含车上步兵），并点名随毁的搭载单位
                        let passenger_names: Vec<String> = u
                            .passengers
                            .iter()
                            .map(|p| p.name_with_label())
                            .collect();
                        self.note_kill(
                            &u,
                            Some((attacker.team, attacker.label, attacker.kind, attacker_h)),
                            KillCause::Artillery,
                        );
                        let extra = self.remove_unit(bh.hex);
                        kills.push(bh.hex);
                        let extra_txt = if extra > 0 {
                            format!("，搭载的{}也随之阵亡", passenger_names.join("、"))
                        } else {
                            String::new()
                        };
                        parts.push(format!("{}: 命中{}/{} 被摧毁{}", bh.name, bh.roll, bh.rate, extra_txt));
                    }
                }
            } else if bh.armor_block {
                parts.push(format!("{}: 命中{}/{} 但被护甲抵挡", bh.name, bh.roll, bh.rate));
            } else if bh.hit {
                parts.push(format!("{}: 命中{}/{} 但被护甲挡下", bh.name, bh.roll, bh.rate));
            } else {
                parts.push(format!("{}: 未命中{}/{}", bh.name, bh.roll, bh.rate));
            }
        }

        // 范围内只有空中单位时，明确说明间瞄火力打不到——否则玩家会
        // 看到敌情里明明有目标却收到"范围内无目标"。
        let air_only: Vec<String> = blast
            .iter()
            .filter_map(|h| self.air_units.get(h))
            .filter(|u| u.team != attacker.team)
            .map(|u| u.name_with_label())
            .collect();
        let mut message = if parts.is_empty() {
            if air_only.is_empty() {
                format!(
                    "{} 炮击 {}：范围内无目标",
                    attacker.name_with_label(),
                    hex::hex_label(center)
                )
            } else {
                format!(
                    "{} 炮击 {}：范围内只有空中单位（{}），间瞄火力打不到空中目标",
                    attacker.name_with_label(),
                    hex::hex_label(center),
                    air_only.join("、")
                )
            }
        } else {
            format!(
                "{} 炮击 {}（中心{}%/周围{}%）：{}",
                attacker.name_with_label(),
                hex::hex_label(center),
                if attacker.kind == UnitKind::Mortar { 60 } else if m864 { 100 } else { 80 },
                if attacker.kind == UnitKind::Mortar { 30 } else if m864 { 100 } else { 50 },
                parts.join("；")
            )
        };
        let ammo_left = if m864 { attacker.missile_ammo } else { attacker.ammo };
        if ammo_left == 0 {
            message.push_str(if m864 { "（M864 耗尽！）" } else { "（弹药耗尽！）" });
        } else if ammo_left <= 2 {
            message.push_str(&format!("（{}剩 {}）", if m864 { "M864" } else { "弹药" }, ammo_left));
        }
        if !suppressed_names.is_empty() {
            message.push_str(&format!("（压制：{} 新回合行动-1）", suppressed_names.join("、")));
        }
        // GUI 动画回放：范围炮击（爆炸覆盖 blast 全部格子）
        let any_hit = hits.iter().any(|h| h.hit);
        let any_blocked = hits.iter().any(|h| h.hit && !h.damages);
        self.ui_events.push(UiEvent::Fire(UiFireEvent {
            team: attacker.team,
            label: attacker.label,
            kind: attacker.kind,
            from: attacker_h,
            target: center,
            target_team: attacker.team.opponent(),
            target_label: '?',
            target_kind: UnitKind::Rifleman, // 爆炸样式与目标兵种无关
            aa_mode: false,
            missile_mode: m864,
            area: true,
            smoke_shell: false,
            blast,
            hit: any_hit,
            blocked: any_blocked,
            killed: !kills.is_empty(),
            target_hp_before: 0,
            dmg: 1,
            killed_units,
        }));
        Ok(AttackOutcome {
            message,
            hit: any_hit,
            blocked: false,
            killed: !kills.is_empty(),
            kills,
        })
    }

    /// 追加一条结构化战报事件（自动分配单调递增的 seq）。
    fn push_battle_event(&mut self, kind: BattleEventKind) {
        self.battle_seq = self.battle_seq.wrapping_add(1);
        self.battle_events.push(BattleEvent {
            seq: self.battle_seq,
            turn: self.turn,
            kind,
        });
    }

    /// 记录一次击毁：主体单位 + 随载具阵亡的搭载步兵各记一条。
    /// `attacker` 为 (阵营, 标签, 兵种, 位置)；范围火力/无归属时传 None。
    /// 调用方在 `remove_unit` 之前调用，因此此时 victim 仍在场上。
    fn note_kill(
        &mut self,
        victim: &Unit,
        attacker: Option<(Team, char, UnitKind, Hex)>,
        cause: KillCause,
    ) {
        let base = KillEvent {
            turn: self.turn,
            victim_team: victim.team,
            victim_label: victim.label,
            victim_kind: victim.kind,
            victim_pos: victim.pos,
            passenger: false,
            attacker_team: attacker.map(|a| a.0),
            attacker_label: attacker.map(|a| a.1),
            attacker_kind: attacker.map(|a| a.2),
            attacker_pos: attacker.map(|a| a.3),
            cause,
        };
        self.push_battle_event(BattleEventKind::Kill(base.clone()));
        for p in &victim.passengers {
            let ev = KillEvent {
                victim_team: p.team,
                victim_label: p.label,
                victim_kind: p.kind,
                victim_pos: victim.pos,
                passenger: true,
                cause: KillCause::AboardCarrier,
                ..base.clone()
            };
            self.push_battle_event(BattleEventKind::Kill(ev));
        }
    }

    /// 用当前视野刷新某方的"最后已知敌方位置"：可见敌军刷新记录，
    /// 超过 2 回合的记录过期。被击毁的格由 `remove_unit` 立即清除。
    pub fn refresh_ghosts(&mut self, team: Team) {
        let visible: Vec<(Hex, UnitKind)> = self
            .vision(team)
            .enemy_units
            .iter()
            .filter_map(|h| {
                self.units
                    .get(h)
                    .or_else(|| self.air_units.get(h))
                    .map(|u| (*h, u.kind))
            })
            .collect();
        let turn = self.turn;
        let entry = self.ghosts.entry(team).or_default();
        for (h, kind) in visible {
            entry.insert(h, (kind, turn));
        }
        entry.retain(|_, (_, t)| turn - *t < 2);
    }

    /// 移除 h 格单位（含其搭载步兵），更新击杀与胜负状态。返回被连带歼灭的步兵数。
    fn remove_unit(&mut self, h: Hex) -> usize {
        self.remove_unit_inner(h, true)
    }

    /// 移除 h 格单位（含其搭载步兵）的内部实现。
    /// killed = true：按"被击毁"结算（计入歼灭点数、触发全灭判负）；
    /// killed = false：主动撤退/撤离——单位同样立即消失（含搭载单位），
    /// 但不计入被歼灭点数，也不触发"全灭"胜负判定。
    fn remove_unit_inner(&mut self, h: Hex, killed: bool) -> usize {
        let u = if let Some(u) = self.units.remove(&h) {
            u
        } else if let Some(u) = self.air_units.remove(&h) {
            u
        } else {
            return 0;
        };
        let passengers = u.passengers.len();
        if killed {
            self.last_kill_turn = self.turn;
        }
        // 记录移除位置（界面据此清除"最后已知位置"幽灵标记）
        self.killed_hexes.push(h);
        // 离开战场的单位不保留任何一方的幽灵标记
        for (_, g) in self.ghosts.iter_mut() {
            g.remove(&h);
        }
        // 统计被歼灭点数（sustain 模式 AI 判定"接近全歼"用；部署撤销与主动撤退不算）
        if killed && !self.deploying {
            let v = self.killed_value.entry(u.team).or_insert(0);
            *v += u.kind.recruit_cost();
        }
        // 该格的迷雾开火警告标记一并失效（单位已离场）
        for (_, marks) in self.fog_fire_marks.iter_mut() {
            marks.remove(&h);
        }
        // 部署阶段的撤销只是"收回棋子"，对方尚未部署时不能据此判胜；
        // 可持续部署模式下全灭不代表结束（还可增援），由 game_over 统一判定
        // （全灭 + 大本营完全被占领才结束）。主动撤退不算被歼灭，不触发判负。
        if killed && !self.deploying && !self.sustain {
            let before = self.winner;
            if !self.team_alive(Team::Player) {
                self.winner = Some(Team::Ai);
            } else if !self.team_alive(Team::Ai) {
                self.winner = Some(Team::Player);
            }
            if before.is_none() {
                if let Some(w) = self.winner {
                    let reason = format!("{}全灭", w.opponent().cn());
                    self.push_battle_event(BattleEventKind::Victory { winner: w, reason });
                }
            }
        }
        passengers
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ai;

    /// 连排指挥官部署：按排编组（战斗排/榴弹炮排），成员全部实际部署，
    /// 榴弹炮排 = 榴弹炮×2 + 卡车×2。
    #[test]
    fn company_deploy_builds_platoons() {
        let mut g = GameState::new_custom_deploy(
            42,
            CustomMap::load(std::path::Path::new("maps/小镇巷战.json")).unwrap(),
        );
        g.enable_sustain(30, 30);
        g.recruit_points.insert(Team::Player, 240);
        g.ai_configs.insert(Team::Player, company_champion());
        ai::ai_deploy(&mut g, Team::Player);
        let plan = g.company.get(&Team::Player).expect("应有连指挥部计划");
        assert!(!plan.platoons.is_empty(), "应至少有一个排");
        assert!(
            plan.platoons.iter().any(|p| p.role == PlatoonRole::Combat),
            "应有战斗排"
        );
        // 排型应是模板之一
        for p in &plan.platoons {
            assert!(
                matches!(
                    p.ptype,
                    PlatoonType::Tank
                        | PlatoonType::Cavalry
                        | PlatoonType::Motorized
                        | PlatoonType::Mechanized
                        | PlatoonType::AirDefense
                        | PlatoonType::Heli
                        | PlatoonType::Artillery
                ),
                "未知排型"
            );
        }
        // 排成员必须真实存在：要么在场，要么已上车（搭载中的步兵不占格，
        // 但仍是该排成员——旧断言依赖"标签被复用"才碰巧成立）。
        for p in &plan.platoons {
            for l in &p.members {
                let on_field = g
                    .units_of(Team::Player)
                    .iter()
                    .any(|u| u.label == *l || u.passengers.iter().any(|ps| ps.label == *l));
                assert!(on_field, "排成员 {} 应已部署（场上或车上）", l);
            }
        }
        // 若建了榴弹炮排（预算富余时），应为 2 榴弹炮 + 2 卡车
        if let Some(arty) = plan
            .platoons
            .iter()
            .find(|p| p.role == PlatoonRole::Artillery)
        {
            let hows = arty
                .members
                .iter()
                .filter(|l| {
                    g.units_of(Team::Player)
                        .iter()
                        .any(|u| u.label == **l && u.kind == UnitKind::Howitzer)
                })
                .count();
            assert_eq!(hows, 2, "榴弹炮排应有 2 门榴弹炮");
            let trucks = arty
                .members
                .iter()
                .filter(|l| {
                    g.units_of(Team::Player)
                        .iter()
                        .any(|u| u.label == **l && u.kind == UnitKind::Truck)
                })
                .count();
            assert_eq!(trucks, 2, "榴弹炮排应有 2 辆卡车");
        }
    }

    /// 武装/运输直升机诱饵弹：各 2 发，前 2 次被攻击时被命中率 ×0.6（消耗 1 发），
    /// 第 3 次起恢复正常命中率（武装直升机仍有机动规避 ×0.6）。
    #[test]
    fn test_heli_flares() {
        let mut g = GameState::new_seeded(21);
        g.begin_turn(Team::Ai);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        // AI 防空导弹发射车（Stinger 打空中）攻击玩家武装直升机
        let aa = hex::axial_from_offset(2, 5);
        g.units
            .insert(aa, Unit::new(UnitKind::AaLauncher, Team::Ai, aa));
        let heli = hex::axial_from_offset(5, 5);
        g.air_units
            .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Player, heli));
        assert_eq!(g.unit_at(heli).unwrap().flares, 2, "武直初始 2 发诱饵弹");
        // 三次被攻击（武直可能被 50% 致命伤击落——存活时验证诱饵弹递减与消息）
        for i in 0..3usize {
            if g.unit_at(heli).is_none() {
                break; // 已被致命伤击落，后续诱饵弹验证终止
            }
            g.unit_at_mut(aa).unwrap().actions_left = 2;
            let o = match g.attack(aa, heli) {
                Ok(o) => o,
                Err(_) => break,
            };
            if i < 2 {
                assert!(
                    o.message.contains("诱饵弹×0.6"),
                    "第 {} 次被攻击应有诱饵弹减益: {}",
                    i + 1,
                    o.message
                );
            } else {
                assert!(
                    !o.message.contains("诱饵弹×0.6"),
                    "第三次起无诱饵弹减益: {}",
                    o.message
                );
            }
            if let Some(u) = g.unit_at(heli) {
                assert_eq!(u.flares, 2 - (i + 1) as i32, "诱饵弹递减 2->1->0");
            }
        }
        // 运输直升机同样携带 2 发
        let mut g2 = GameState::new_seeded(22);
        let th = hex::axial_from_offset(4, 4);
        g2.air_units
            .insert(th, Unit::new(UnitKind::TransportHeli, Team::Player, th));
        assert_eq!(
            g2.unit_at(th).unwrap().flares,
            2,
            "运输直升机初始 2 发诱饵弹"
        );
        // 地面单位（坦克）无诱饵弹
        let mut g3 = GameState::new_seeded(23);
        let tk = hex::axial_from_offset(4, 4);
        g3.units
            .insert(tk, Unit::new(UnitKind::Tank, Team::Player, tk));
        assert_eq!(g3.unit_at(tk).unwrap().flares, 0, "坦克无诱饵弹");
    }

    /// 水域地形规则：陆军不可进入、空中可进入、卡车不可卸下到水域、
    /// 运输直升机不可在水域上方卸下、水域不阻挡射击视野、地面单位不可部署到水域。
    #[test]
    fn test_water_terrain_rules() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.map.water.clear();
        // ① 陆军单位不能进入水域
        g.map.add_water(5, 5);
        let tank = hex::axial_from_offset(4, 5);
        g.units.insert(tank, Unit::new(UnitKind::Tank, Team::Player, tank));
        let water_h = hex::axial_from_offset(5, 5);
        assert!(
            g.move_unit(tank, &[tank, water_h], false).is_err(),
            "坦克不能进入水域"
        );
        // ② 空中单位可以移动到水域上方
        let heli = hex::axial_from_offset(4, 7);
        g.air_units
            .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Player, heli));
        let wh = hex::axial_from_offset(5, 7);
        g.map.add_water(5, 7);
        assert!(
            g.move_unit(heli, &[heli, wh], true).is_ok(),
            "直升机可进入水域上方"
        );
        // ③ 卡车不能卸下单位到水域
        let truck = hex::axial_from_offset(3, 9);
        g.units.insert(truck, Unit::new(UnitKind::Truck, Team::Player, truck));
        let rifle = hex::axial_from_offset(2, 9);
        g.units
            .insert(rifle, Unit::new(UnitKind::Rifleman, Team::Player, rifle));
        g.board(truck, rifle).unwrap();
        let pass = g.unit_at(truck).unwrap().passengers[0].label;
        g.map.add_water(4, 9);
        let dest_w = hex::axial_from_offset(4, 9);
        assert!(g.disembark(truck, pass, dest_w).is_err(), "不能卸下到水域");
        let dest_l = hex::axial_from_offset(4, 10);
        assert!(g.disembark(truck, pass, dest_l).is_ok(), "可卸到陆地");
        // ④ 运输直升机不能在水域上方卸下步兵
        let th = hex::axial_from_offset(8, 3);
        g.map.add_water(8, 3);
        g.air_units
            .insert(th, Unit::new(UnitKind::TransportHeli, Team::Player, th));
        let mut hu = g.air_units.get(&th).unwrap().clone();
        hu.passengers
            .push(Unit::new(UnitKind::Rifleman, Team::Player, th));
        g.air_units.insert(th, hu);
        assert!(
            g.heli_unload(th).is_err(),
            "运输直升机不能在水域上方卸下步兵"
        );
        // ⑤ 水域不阻挡射击视野（放在与水域无关的干净地图上测 LOS）
        let mut g2 = GameState::new_seeded(4);
        g2.map.obstacles.clear();
        g2.map.forests.clear();
        g2.map.buildings.clear();
        g2.map.water.clear();
        let a = hex::axial_from_offset(2, 5);
        let b = hex::axial_from_offset(8, 5);
        for c in 3..8 {
            g2.map.add_water(c, 5);
        }
        assert!(
            g2.map.has_los_ex(a, b, &BTreeMap::new()),
            "水域不阻挡视线"
        );
        // ⑥ 地面单位不可部署到水域
        let mut g3 = GameState::new_deploy(9);
        g3.map.water.clear();
        g3.map.add_water(1, 1);
        assert!(
            g3.deploy_unit(Team::Player, UnitKind::Tank, hex::axial_from_offset(1, 1)).is_err(),
            "坦克不能部署到水域"
        );
        assert!(
            g3.deploy_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(1, 1))
                .is_err(),
            "步兵也不能部署到水域"
        );
        assert!(
            g3.deploy_unit(Team::Player, UnitKind::AttackHeli, hex::axial_from_offset(1, 1))
                .is_ok(),
            "直升机可部署到水域上方"
        );
    }

    /// 直升机特性：① 普通运输直升机自带被命中率 ×0.8 闪避；
    /// ② 武装直升机/重型运输直升机被命中时 30% 概率致命伤（直接坠毁，无视血量/护甲）。
    #[test]
    fn test_heli_dodge_and_critical() {
        // —— 普通运输直升机闪避 ×0.8 ——
        let mut g = GameState::new_seeded(41);
        g.begin_turn(Team::Ai);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let aa = hex::axial_from_offset(2, 5);
        g.units
            .insert(aa, Unit::new(UnitKind::AaLauncher, Team::Ai, aa));
        let th = hex::axial_from_offset(4, 5);
        g.air_units
            .insert(th, Unit::new(UnitKind::TransportHeli, Team::Player, th));
        let o = g.attack(aa, th).unwrap();
        assert!(
            o.message.contains("运直闪避×0.8"),
            "普通运直被命中率 ×0.8: {}",
            o.message
        );
        // —— 致命伤：武装直升机被命中 30% 直接坠毁 ——
        let mut g2 = GameState::new_seeded(52);
        g2.begin_turn(Team::Ai);
        g2.units.clear();
        g2.air_units.clear();
        g2.map.obstacles.clear();
        g2.map.forests.clear();
        g2.map.buildings.clear();
        let heli = hex::axial_from_offset(4, 5);
        g2.air_units
            .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Player, heli));
        // 清诱饵弹（避免干扰命中率），武直 HP 拉高便于统计致命
        {
            let mut hu = g2.air_units.get(&heli).unwrap().clone();
            hu.flares = 0;
            hu.hp = 99;
            g2.air_units.insert(heli, hu);
        }
        let aah = hex::axial_from_offset(2, 5);
        g2.units
            .insert(aah, Unit::new(UnitKind::AaLauncher, Team::Ai, aah));
        // 40 次攻击统计致命触发（命中率 70%，命中约 28 次，致命期望 ~8.4）
        let mut crits = 0;
        let mut hits = 0;
        for _ in 0..40 {
            // 若武直已坠毁则重建
            if g2.air_units.get(&heli).is_none() {
                g2.air_units
                    .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Player, heli));
                let mut hu = g2.air_units.get(&heli).unwrap().clone();
                hu.flares = 0;
                hu.hp = 99;
                g2.air_units.insert(heli, hu);
            }
            g2.unit_at_mut(aah).unwrap().actions_left = 2;
            g2.unit_at_mut(aah).unwrap().ammo = 8; // 重置弹药（防空导弹 8 发）
            let o = g2.attack(aah, heli).unwrap();
            if o.hit {
                hits += 1;
            }
            if o.message.contains("致命伤") {
                crits += 1;
                assert!(
                    g2.air_units.get(&heli).is_none(),
                    "致命伤应直接坠毁（移除单位）"
                );
            }
        }
        assert!(hits >= 10, "应有一定命中数（实测 {}）", hits);
        assert!(
            (5..=20).contains(&crits),
            "致命率应约 30%（实测致命 {} / 命中 {}）",
            crits,
            hits
        );
    }

    /// 重机枪手属性（费用 8/攻 2/射程 4/弹药 8/命中 80%/攻击耗 1 行动，
    /// 但需先架设；攻击步兵 50% 造成 2 点伤害）；步枪手/精锐步兵主武器射程 2（M3E1 副武器 3 保留）。
    #[test]
    fn test_hmg_gunner_and_rifle_range() {
        assert_eq!(UnitKind::HmgGunner.recruit_cost(), 8, "费用 8");
        assert_eq!(UnitKind::HmgGunner.max_hp(), 1);
        assert_eq!(UnitKind::HmgGunner.armor(), 0, "重机枪手（步兵）护甲 0");
        assert_eq!(UnitKind::HmgGunner.attack(), 2);
        assert_eq!(UnitKind::HmgGunner.range(), 4);
        assert_eq!(UnitKind::HmgGunner.max_ammo(), 8);
        assert_eq!(UnitKind::HmgGunner.hit_rate(), 80);
        assert_eq!(UnitKind::HmgGunner.attack_cost(), 1, "重机枪手攻击耗 1 行动");
        assert_eq!(UnitKind::HumveeHmg.attack_cost(), 1, "悍马-重机枪攻击耗 1 行动");
        assert!(UnitKind::HmgGunner.needs_deploy(), "重机枪手需先架设");
        assert!(!UnitKind::HumveeHmg.needs_deploy(), "悍马-重机枪无需架设");
        assert_eq!(UnitKind::HmgGunner.action_count(), 2);
        assert!(UnitKind::HmgGunner.is_foot());
        // 步枪手/精锐步兵主武器射程 2
        assert_eq!(UnitKind::Rifleman.range(), 2, "步枪手主武器射程 2");
        assert_eq!(UnitKind::EliteInfantry.range(), 2, "精锐步兵主武器射程 2");
        // M3E1 副武器射程 3 保留
        let mut r = Unit::new(UnitKind::Rifleman, Team::Player, Hex::ZERO);
        r.missile_mode = true;
        assert_eq!(r.eff_range(), 3, "M3E1-XM1176 射程 3 保留");
        // 重机枪攻击步兵 50% 造成 2 点伤害（重弹）——20 次攻击统计
        let mut g = GameState::new_seeded(101);
        g.begin_turn(Team::Ai);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let hmg = hex::axial_from_offset(2, 5);
        g.units
            .insert(hmg, Unit::new(UnitKind::HmgGunner, Team::Ai, hmg));
        let tgt = hex::axial_from_offset(4, 5);
        g.units
            .insert(tgt, Unit::new(UnitKind::EliteInfantry, Team::Player, tgt));
        let mut two = 0;
        let mut hits = 0;
        for _ in 0..20 {
            if g.unit_at(hmg).is_none() || g.unit_at(tgt).is_none() {
                break;
            }
            let mut hu = g.unit_at(hmg).unwrap().clone();
            hu.actions_left = 2;
            hu.ammo = 8;
            hu.deployed = true; // 重机枪手需先架设才能开火
            g.units.insert(hmg, hu);
            g.unit_at_mut(tgt).unwrap().hp = 3;
            let o = g.attack(hmg, tgt).unwrap();
            if o.message.contains("重弹") {
                two += 1;
            }
            if o.message.contains("命中!") {
                hits += 1;
            }
        }
        assert!(hits >= 8, "应有一定命中数（实测 {}）", hits);
        assert!(
            (2..=18).contains(&two),
            "重弹率应约 50%（实测 {}/{}）",
            two,
            hits
        );
    }

    /// 空中单位隐蔽度 0.5：发现距离 = 视野 ×2。
    /// 平原上视野 4 的步兵可发现 8 格远的空中单位；中间有森林/楼房时发现距离受影响。
    #[test]
    fn test_air_unit_concealment_half() {
        let mut g = GameState::new_seeded(91);
        g.begin_turn(Team::Ai);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let inf = hex::axial_from_offset(4, 5); // 步枪手视野 4
        g.units
            .insert(inf, Unit::new(UnitKind::Rifleman, Team::Player, inf));
        // 8 格远的武直（平原）→ 可见（4 × 2 = 8）
        let heli = hex::axial_from_offset(12, 5);
        g.air_units
            .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Ai, heli));
        assert!(
            g.is_unit_visible(Team::Player, heli),
            "视野 4 应发现 8 格远的空中单位（隐蔽 0.5）"
        );
        // 9 格远 → 不可见
        let heli2 = hex::axial_from_offset(13, 5);
        g.air_units
            .insert(heli2, Unit::new(UnitKind::AttackHeli, Team::Ai, heli2));
        assert!(
            !g.is_unit_visible(Team::Player, heli2),
            "9 格远超出视野×2 → 不可见"
        );
        // 中间有森林（步耗 2）→ 发现距离缩短：8 格处有森林垫步后 BFS 路程 > 8
        let heli3 = hex::axial_from_offset(12, 5);
        g.map.forests.insert(hex::axial_from_offset(8, 5));
        assert!(
            !g.is_unit_visible(Team::Player, heli3),
            "中间有森林 → BFS 路程增大，8 格处的空中单位不再可见"
        );
        // 中间有楼房 → 阻挡（地面单位视野被楼房阻断）
        g.map.forests.clear();
        g.map.buildings.insert(hex::axial_from_offset(8, 5));
        assert!(
            !g.is_unit_visible(Team::Player, heli3),
            "中间有楼房 → 阻挡地面单位视野，空中单位不可见"
        );
        // 楼房清除后恢复可见
        g.map.buildings.clear();
        assert!(
            g.is_unit_visible(Team::Player, heli3),
            "平原恢复 → 8 格内空中单位可见"
        );
    }

    /// AI 步兵登屋顶：防空导弹手/Javelin/TOW 在建筑内且场上存在可见敌军时，
    /// 自动登上屋顶（更好射击角度：视野/攻击无视遮挡）；无可见敌军时不上。
    #[test]
    fn test_ai_infantry_climbs_rooftop() {
        // —— 有可见敌军 → AI 的 TOW 上屋顶 ——
        let mut g = GameState::new_seeded(81);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let bld = hex::axial_from_offset(4, 5);
        g.map.buildings.insert(bld);
        g.units
            .insert(bld, Unit::new(UnitKind::Atgm, Team::Ai, bld));
        // 玩家单位在 2 格内（TOW 视野 4，步兵隐蔽 2 → 发现需 ≤2 格；无遮挡 → AI 可见）
        let foe = hex::axial_from_offset(5, 5);
        g.units
            .insert(foe, Unit::new(UnitKind::Rifleman, Team::Player, foe));
        let mut log = Vec::new();
        ai::run_ai_turn(&mut g, Team::Ai, &mut log);
        let u = g.unit_at(bld).cloned().unwrap();
        assert!(
            u.rooftop,
            "建筑内 AI 的 TOW + 可见敌军 → 应自动上屋顶（日志 {:?}）",
            log.iter().take(4).collect::<Vec<_>>()
        );
        // —— 无可见敌军 → 不上屋顶（保持屋中闪避） ——
        let mut g2 = GameState::new_seeded(82);
        g2.begin_turn(Team::Player);
        g2.map.obstacles.clear();
        g2.map.forests.clear();
        g2.map.buildings.clear();
        g2.units.clear();
        g2.air_units.clear();
        g2.map.buildings.insert(bld);
        g2.units
            .insert(bld, Unit::new(UnitKind::Atgm, Team::Ai, bld));
        // 玩家单位放在 20 格外（TOW 视野外 → AI 不可见）
        let far = hex::axial_from_offset(24, 20);
        g2.units
            .insert(far, Unit::new(UnitKind::Rifleman, Team::Player, far));
        let mut log2 = Vec::new();
        ai::run_ai_turn(&mut g2, Team::Ai, &mut log2);
        let u2 = g2.unit_at(bld).cloned().unwrap();
        assert!(
            !u2.rooftop,
            "无可见敌军 → AI 的 TOW 不应上屋顶（保持屋中闪避）"
        );
    }

    /// 武装直升机费用 24；AI 防空倾向：
    /// 场上存在未被击落的敌方空中单位 / 己方防空单位被击毁 → AI 更倾向出防空单位
    ///（防空排/防空步兵排前置；防空计数随回合更新）。
    #[test]
    fn test_aa_trigger_and_airdefense_infantry_platoon() {
        assert_eq!(UnitKind::AttackHeli.recruit_cost(), 24, "武直费用 24");
        // —— 敌方有未被击落的空中单位 → AI 出防空排 ——
        let mut g = GameState::new_seeded(71);
        g.begin_turn(Team::Player);
        g.enable_sustain(400, 400);
        let mut cfg = AiConfig::default();
        cfg.style = AiStyle::Company;
        cfg.platoon_pattern = 0;
        cfg.platoon_count = 3;
        g.ai_configs.insert(Team::Ai, cfg);
        g.units.clear();
        g.air_units.clear();
        g.air_units.insert(
            hex::axial_from_offset(2, 5),
            Unit::new(UnitKind::AttackHeli, Team::Player, hex::axial_from_offset(2, 5)),
        );
        g.recruit_points.insert(Team::Ai, 400);
        g.recruit_points.insert(Team::Player, 400);
        g.deploying = true;
        let log = ai::ai_deploy(&mut g, Team::Ai);
        assert!(
            log.iter().any(|m| m.contains("防空")),
            "场上存在玩家空中单位 → AI 应建防空排: {:?}",
            log.iter().take(8).collect::<Vec<_>>()
        );
        // —— 防空计数更新（用于检测"己方防空被击毁"） ——
        let mut g2 = GameState::new_seeded(72);
        g2.begin_turn(Team::Player);
        g2.enable_sustain(20, 20);
        g2.units.clear();
        g2.air_units.clear();
        g2.units.insert(
            hex::axial_from_offset(10, 5),
            Unit::new(UnitKind::AaLauncher, Team::Ai, hex::axial_from_offset(10, 5)),
        );
        g2.aa_count_last.insert(Team::Ai, 2); // 上回合有 2 个防空单位
        let mut log2 = Vec::new();
        ai::run_ai_turn(&mut g2, Team::Ai, &mut log2);
        assert_eq!(
            g2.aa_count_last.get(&Team::Ai).copied().unwrap_or(-1),
            1,
            "防空计数应更新为本回合实际数量（1 个 < 上回合 2 个 → 触发防空倾向）"
        );
    }

    /// 步兵登屋顶：建筑内步兵切换【屋中/屋顶】。
    /// 屋顶：被命中率不享受楼房 ×0.6、不吃 XM1176 楼内击杀、攻击无视 LOS、
    /// 视野无视森林/楼房遮挡、隐蔽不享受楼房加成；屋中恢复原有状态。
    #[test]
    fn test_rooftop_infantry() {
        // —— 构造：楼房 + 森林遮挡场景 ——
        let mut g = GameState::new_seeded(61);
        g.begin_turn(Team::Ai);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        // 楼房 (4,5) 内放玩家步枪手；楼房 (6,5) 内放 AI 步枪手（楼房间隔 1 格）
        g.map.buildings.insert(hex::axial_from_offset(4, 5));
        g.map.buildings.insert(hex::axial_from_offset(6, 5));
        let inf = hex::axial_from_offset(4, 5);
        let foe = hex::axial_from_offset(6, 5);
        g.units
            .insert(inf, Unit::new(UnitKind::Rifleman, Team::Player, inf));
        g.units.insert(foe, Unit::new(UnitKind::Rifleman, Team::Ai, foe));
        // 1) 屋中：AI 打玩家步兵 → 命中率 ×0.6（消息含"楼房隐蔽×0.6"）
        g.unit_at_mut(foe).unwrap().actions_left = 2;
        let o = g.attack(foe, inf).unwrap();
        assert!(
            o.message.contains("楼房隐蔽×0.6"),
            "屋中应享受楼房闪避: {}",
            o.message
        );
        // 2) 屋顶：登上屋顶后 AI 打他 → 不 ×0.6
        g.unit_at_mut(inf).unwrap().rooftop = true;
        g.unit_at_mut(foe).unwrap().actions_left = 2;
        let o2 = g.attack(foe, inf).unwrap();
        assert!(
            !o2.message.contains("楼房隐蔽×0.6"),
            "屋顶不应享受楼房闪避: {}",
            o2.message
        );
        // 3) 屋顶攻击无视 LOS：楼房 (5,5) 夹在两步兵中间挡住直射——
        //    屋中时无法开火，屋顶时能开火
        g.unit_at_mut(inf).unwrap().rooftop = false; // 先回屋中
        g.map.buildings.insert(hex::axial_from_offset(5, 5));
        g.unit_at_mut(inf).unwrap().actions_left = 2;
        let err = g.attack(inf, foe).unwrap_err();
        assert!(
            err.contains("未被侦察到") || err.contains("视线"),
            "屋中应被楼房挡视野/视线: {}",
            err
        );
        g.unit_at_mut(inf).unwrap().rooftop = true;
        g.unit_at_mut(inf).unwrap().actions_left = 2;
        assert!(
            g.attack(inf, foe).is_ok(),
            "屋顶攻击应无视 LOS"
        );
        // 4) 屋顶视野无视森林/楼房：在玩家步兵旁放森林 + 远处 AI 单位，
        //    屋中看不到（楼房挡），屋顶能看到
        g.map.forests.clear();
        let far = hex::axial_from_offset(8, 5);
        g.units
            .insert(far, Unit::new(UnitKind::Tank, Team::Ai, far));
        // 楼房 (5,5) 与 (6,5)(7,5) 排成一排挡住 4→8 的视野（地面单位）
        g.map.buildings.insert(hex::axial_from_offset(7, 5));
        g.units.remove(&foe);
        // 屋中（4,5 视野 6）：8 号坦克在楼房 (5,5)(6,5)(7,5) 之后 → 不可见
        g.unit_at_mut(inf).unwrap().rooftop = false; // 先回屋中
        assert!(
            !g.is_unit_visible(Team::Player, far),
            "屋中：楼房应挡住远处坦克的视野"
        );
        g.unit_at_mut(inf).unwrap().rooftop = true;
        assert!(
            g.is_unit_visible(Team::Player, far),
            "屋顶：视野应无视楼房遮挡"
        );
        // 5) XM1176 楼内击杀：屋顶步兵不在楼内 → 不强制击杀
        let sf = hex::axial_from_offset(2, 5);
        g.units.insert(sf, Unit::new(UnitKind::Rifleman, Team::Ai, sf));
        g.toggle_missile_mode(sf).ok();
        let mut hu = g.unit_at(inf).unwrap().clone();
        hu.hp = 3;
        hu.rooftop = true;
        g.units.insert(inf, hu);
        g.unit_at_mut(sf).unwrap().actions_left = 2;
        let o3 = g.attack(sf, inf).unwrap();
        assert!(
            !o3.message.contains("XM1176"),
            "屋顶步兵不吃 XM1176 强制击杀: {}",
            o3.message
        );
        // 6) 切换回屋中 → 恢复（被命中又带楼房 ×0.6）
        g.unit_at_mut(inf).unwrap().rooftop = false;
        g.unit_at_mut(sf).unwrap().actions_left = 2;
        let o4 = g.attack(sf, inf).unwrap();
        assert!(
            o4.message.contains("楼房隐蔽×0.6"),
            "回到屋中应恢复楼房闪避: {}",
            o4.message
        );
    }

    /// 重型运输直升机：血量 2、载重 8、3 发诱饵弹、费用 20，
    /// 其余属性与普通运输直升机一致（射程 0/护甲 1/移动 10/视野 9/行动 2）。
    #[test]
    fn test_heavy_transport_heli() {
        assert_eq!(UnitKind::HeavyTransportHeli.recruit_cost(), 20, "费用 20");
        assert_eq!(UnitKind::HeavyTransportHeli.max_hp(), 2, "血量 2");
        assert_eq!(UnitKind::HeavyTransportHeli.capacity(), 8, "载重 8");
        assert_eq!(UnitKind::HeavyTransportHeli.range(), 0, "不能攻击");
        assert_eq!(UnitKind::HeavyTransportHeli.armor(), 1);
        assert_eq!(UnitKind::HeavyTransportHeli.movement(), 10);
        assert_eq!(UnitKind::HeavyTransportHeli.vision(), 9);
        assert_eq!(UnitKind::HeavyTransportHeli.action_count(), 2);
        assert!(UnitKind::HeavyTransportHeli.is_air());
        let mut g = GameState::new_seeded(31);
        let pos = hex::axial_from_offset(4, 4);
        g.air_units.insert(
            pos,
            Unit::new(UnitKind::HeavyTransportHeli, Team::Player, pos),
        );
        assert_eq!(g.unit_at(pos).unwrap().flares, 3, "3 发诱饵弹");
        // 真实装载流程：正下方载入步枪手（3 重量）+ 榴弹炮（5 重量）= 8 满载
        g.units.insert(
            hex::axial_from_offset(4, 4),
            Unit::new(UnitKind::Rifleman, Team::Player, pos),
        );
        g.heli_board(pos).unwrap(); // 载入步兵
        assert_eq!(g.unit_at(pos).unwrap().used_weight(), 3);
        g.units.insert(
            pos,
            Unit::new(UnitKind::Howitzer, Team::Player, pos),
        );
        g.heli_board(pos)
            .expect("重型运直可载运榴弹炮（新规则）"); // 3 + 5 = 8
        let heli = g.unit_at(pos).unwrap();
        assert_eq!(heli.passengers.len(), 2);
        assert_eq!(heli.used_weight(), 8, "载重恰好 8");
        assert!(!heli.has_space(), "载重已满");
        // 再装一件 1 重量的步兵 → 9 > 8 拒绝
        g.units.insert(
            pos,
            Unit::new(UnitKind::Atgm, Team::Player, pos),
        );
        assert!(g.heli_board(pos).is_err(), "满载后不能继续搭载（载重 8）");
    }

    /// 重型运输直升机逐个放下：heli_unload 默认放机舱第一名，
    /// heli_unload_label 可指定第二名（GUI 逐名按钮），避免张冠李戴。
    #[test]
    fn heavy_transport_heli_unload_by_label() {
        let mut g = GameState::new_seeded(31);
        let pos = hex::axial_from_offset(4, 4);
        g.air_units.insert(
            pos,
            Unit::new(UnitKind::HeavyTransportHeli, Team::Player, pos),
        );
        let mut a = Unit::new(UnitKind::Rifleman, Team::Player, pos);
        a.label = 'A';
        let mut b = Unit::new(UnitKind::SpecialForces, Team::Player, pos);
        b.label = 'B';
        g.units.insert(pos, a);
        g.heli_board(pos).unwrap();
        g.units.insert(pos, b);
        g.heli_board(pos).unwrap();
        assert_eq!(g.unit_at(pos).unwrap().passengers.len(), 2);
        // 载入 2 名已耗尽 2 次行动：补足行动次数以便测试放下
        g.air_units.get_mut(&pos).unwrap().actions_left = 5;
        // 指定放下第二名（B），机舱应剩 A
        g.heli_unload_label(pos, 'B').unwrap();
        let heli = g.air_units.get(&pos).unwrap();
        assert_eq!(heli.passengers.len(), 1);
        assert_eq!(heli.passengers[0].label, 'A', "应剩下 A");
        assert_eq!(g.units.get(&pos).unwrap().label, 'B', "放下的应是 B");
        // 移走地上的 B，再让 heli_unload 无标签时默认放第一名（A）
        g.units.remove(&pos);
        g.heli_unload(pos).unwrap();
        assert!(g.air_units.get(&pos).unwrap().passengers.is_empty());
        assert_eq!(g.units.get(&pos).unwrap().label, 'A', "默认放下的应是 A");
    }

    /// 桥头堡之战地图：AI 自动使用优化后的连排指挥官（机械化强攻 5 排 400 点冠军）；
    /// 其他地图不预设 AI 配置（保持默认行为）。
    #[test]
    fn bridgehead_map_uses_company_ai() {
        let cm = CustomMap::load(std::path::Path::new("maps/桥头堡之战.json")).unwrap();
        let g = GameState::new_custom_deploy(1, cm);
        let ai_cfg = g.ai_configs.get(&Team::Ai).copied();
        assert!(ai_cfg.is_some(), "桥头堡应预设 AI 连排配置");
        if let Some(c) = ai_cfg {
            assert_eq!(c.style, AiStyle::Company, "桥头堡 AI 应为连排指挥官");
            assert_eq!(c.platoon_pattern, 4, "机械化强攻模式");
            assert_eq!(c.platoon_count, 5, "5 排");
        }
        let cm2 = CustomMap::load(std::path::Path::new("maps/小镇巷战.json")).unwrap();
        let g2 = GameState::new_custom_deploy(2, cm2);
        assert!(
            g2.ai_configs.get(&Team::Ai).is_none(),
            "小镇巷战不预设 AI 配置"
        );
    }

#[test]
fn test_cavalry_ifv() {
        assert_eq!(UnitKind::CavalryIfv.recruit_cost(), 20, "费用 20");
        assert_eq!(UnitKind::CavalryIfv.range(), 4, "主武器射程 4（同步兵战车）");
        assert_eq!(UnitKind::CavalryIfv.armor(), 2);
        assert_eq!(UnitKind::CavalryIfv.attack(), 2);
        assert_eq!(UnitKind::CavalryIfv.max_ammo(), 30);
        assert_eq!(UnitKind::CavalryIfv.capacity(), 1);
        let mut g = GameState::new_seeded(7);
        let pos = hex::axial_from_offset(10, 5);
        g.units.insert(
            pos,
            Unit::new(UnitKind::CavalryIfv, Team::Player, pos),
        );
        let u = g.unit_at(pos).unwrap().clone();
        assert_eq!(u.missile_ammo, 8, "TOW 弹 8");
        assert_eq!(u.ad_uses, 8, "主动防御 8 次（与主战坦克一致）");
        assert!(u.is_dual_weapon(), "双武器（机炮 + TOW）");
        assert!(!u.missile_mode, "默认机炮模式");
        // 按 M 切换 TOW 模式
        g.toggle_missile_mode(pos).unwrap();
        let u = g.unit_at(pos).unwrap().clone();
        assert!(u.missile_mode);
        assert_eq!(u.eff_range(), 9, "TOW 射程 9（参照 TOW 射手）");
        assert_eq!(u.eff_attack(), 4, "TOW 攻击 4");
        assert_eq!(u.eff_hit_rate(), 90, "TOW 命中率 90");
        assert!(u.can_target_unit(UnitKind::Tank), "TOW 打车辆");
        assert!(!u.can_target_unit(UnitKind::Rifleman), "TOW 不打步兵");
        assert!(!u.can_target_unit(UnitKind::AttackHeli), "TOW 不打空中");
        // 切回机炮：打地面
        g.toggle_missile_mode(pos).unwrap();
        let u = g.unit_at(pos).unwrap().clone();
        assert!(!u.missile_mode);
        assert!(u.can_target_unit(UnitKind::Rifleman), "机炮打步兵");
        // 只能搭载血量 1 的步兵（can_carry 是 Unit 实例方法）
        let cv = Unit::new(UnitKind::CavalryIfv, Team::Player, hex::axial_from_offset(0, 0));
        assert!(cv.can_carry(UnitKind::Javelin));
        assert!(cv.can_carry(UnitKind::Atgm));
        assert!(cv.can_carry(UnitKind::AaInfantry));
        assert!(!cv.can_carry(UnitKind::Rifleman), "不能载步枪手（HP3）");
        assert!(!cv.can_carry(UnitKind::SpecialForces), "不能载特战（HP2）");
        assert!(!cv.can_carry(UnitKind::EliteInfantry), "不能载精锐（HP3）");
        // 主动防御：第一发命中被免疫（8 -> 7）
        g.toggle_missile_mode(pos).unwrap();
        g.toggle_missile_mode(pos).unwrap();
        let tpos = hex::axial_from_offset(10, 4);
        g.units.insert(
            tpos,
            Unit::new(UnitKind::Tank, Team::Ai, tpos),
        );
        let out = g.attack(pos, tpos).unwrap();
        if out.message.contains("启动主动防御") {
            assert!(out.blocked, "命中被主动防御免疫");
            assert_eq!(g.unit_at(pos).unwrap().ad_uses, 7, "主动防御 8->7");
        }
    }

    /// 一般步兵战车（IFV）自带 2 枚 TOW：按 M 切换 TOW 模式，打车辆、不打步兵，开火消耗弹药。
    #[test]
    fn test_regular_ifv_has_two_tow_missiles() {
        assert_eq!(UnitKind::Ifv.max_missile_ammo(), 2, "步战车 TOW 弹 2");
        let mut g = GameState::new_seeded(7);
        g.units.clear();
        g.air_units.clear();
        let pos = hex::axial_from_offset(10, 5);
        g.units
            .insert(pos, Unit::new(UnitKind::Ifv, Team::Player, pos));
        assert_eq!(g.unit_at(pos).unwrap().missile_ammo, 2, "初始 TOW 弹 2");
        assert!(g.unit_at(pos).unwrap().is_dual_weapon(), "双武器（机关炮 + TOW）");
        assert_eq!(g.unit_at(pos).unwrap().mode_name(), "主武器", "默认机关炮");
        g.toggle_missile_mode(pos).unwrap();
        let u = g.unit_at(pos).unwrap().clone();
        assert!(u.missile_mode);
        assert_eq!(u.mode_name(), "TOW导弹");
        assert_eq!(u.eff_range(), 9, "TOW 射程 9");
        assert_eq!(u.eff_attack(), 4, "TOW 攻击 4");
        assert_eq!(u.eff_hit_rate(), 90, "TOW 命中率 90");
        assert!(!u.is_direct_fire_vehicle_gun(), "TOW 模式不算机关炮");
        assert!(u.can_target_unit(UnitKind::Tank), "TOW 打车辆");
        assert!(!u.can_target_unit(UnitKind::Rifleman), "TOW 不打步兵");
        assert!(!u.can_target_unit(UnitKind::AttackHeli), "TOW 不打空中");
        // 实测开火消耗 TOW 弹（无论是否命中）
        let tpos = hex::axial_from_offset(10, 4);
        let mut tank = Unit::new(UnitKind::Tank, Team::Ai, tpos);
        tank.hp = 9; // 避免被一击摧毁影响后续断言
        g.units.insert(tpos, tank);
        let _ = g.attack(pos, tpos);
        assert_eq!(g.unit_at(pos).unwrap().missile_ammo, 1, "开火消耗 1 枚 TOW");
    }

    #[test]
    fn test_save_load_roundtrip_preserves_state_and_rng() {
        let mut g = GameState::new_seeded(20240818);
        g.begin_turn(Team::Player);
        // 写入一些非空集合/配置，验证存档 JSON 能覆盖完整状态
        g.ai_configs.insert(Team::Ai, AiConfig::default());
        g.company.insert(Team::Ai, CompanyPlan::default());
        g.ai_recruit_plan.insert(Team::Ai, Some(UnitKind::Tank));
        g.vis_cache.insert(Team::Ai, (g.turn, BTreeSet::from([hex::axial_from_offset(1, 1)])));
        let path = std::env::temp_dir().join("hex_wargame_save_roundtrip.json");
        g.save_to_file(&path).unwrap();
        // 保存后继续消耗一次随机数；加载后应能接续同一随机流
        let next_after_save = g.rng.gen_range(0..100000u32);
        let loaded = GameState::load_from_file(&path).unwrap();
        assert_eq!(loaded.turn, g.turn);
        assert_eq!(loaded.phase, g.phase);
        assert_eq!(loaded.units.len(), g.units.len());
        assert_eq!(loaded.air_units.len(), g.air_units.len());
        let mut loaded = loaded;
        assert_eq!(
            loaded.rng.gen_range(0..100000u32),
            next_after_save,
            "存档应保留 RNG 内部状态，使读档后随机流与保存时一致"
        );
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn test_hex_distance() {
        assert_eq!(Hex::distance(Hex::new(0, 0), Hex::new(3, 0)), 3);
        assert_eq!(Hex::distance(Hex::new(0, 0), Hex::new(1, 1)), 2);
        assert_eq!(Hex::distance(Hex::new(2, -1), Hex::new(-1, 2)), 3);
    }

    #[test]
    fn test_hex_conversion_roundtrip() {
        for col in 0..15 {
            for row in 0..9 {
                let ax = hex::axial_from_offset(col, row);
                assert_eq!(hex::offset_from_axial(ax), (col, row));
            }
        }
    }

    #[test]
    fn test_armor_rule_rifleman_cannot_hurt_tank() {
        // 步枪手（攻击1）永远打不动坦克（护甲3）：命中也会被护甲挡下
        for seed in 0..30 {
            let mut g = GameState::new_seeded(seed);
            g.begin_turn(Team::Player);
            let b_pos = hex::axial_from_offset(0, 3);
            let mut tank = g
                .unit_at(*g.units.iter().find(|(_, u)| u.label == '1').unwrap().0)
                .unwrap()
                .clone();
            g.units.remove(&tank.pos);
            tank.pos = hex::axial_from_offset(1, 3);
            let t_pos = tank.pos;
            g.units.insert(t_pos, tank);

            let out = g.attack(b_pos, t_pos).unwrap();
            assert!(!out.killed);
            if out.hit {
                assert!(out.blocked, "步枪手命中坦克必须被护甲挡下: {}", out.message);
            }
        }
    }

    #[test]
    fn test_atgm_can_kill_tank_and_costs_two_actions() {
        let mut any_kill = false;
        for seed in 0..30 {
            let mut g = GameState::new_seeded(seed);
            g.begin_turn(Team::Player);
            let c_pos = hex::axial_from_offset(0, 4);
            let mut tank = g
                .unit_at(*g.units.iter().find(|(_, u)| u.label == '1').unwrap().0)
                .unwrap()
                .clone();
            g.units.remove(&tank.pos);
            tank.pos = hex::axial_from_offset(2, 4);
            let t_pos = tank.pos;
            g.units.insert(t_pos, tank);

            assert!(Hex::distance(c_pos, t_pos) <= 6);
            let out1 = g.attack(c_pos, t_pos).unwrap();
            assert!(!out1.blocked, "ATGM 攻击力4 >= 坦克护甲3");
            // TOW射手攻击消耗 2 次行动（一回合 1 发）
            assert_eq!(g.unit_at(c_pos).unwrap().actions_left, 0);
            if out1.hit {
                // 坦克 2 血：第一发命中后仍在场
                assert!(g.unit_at(t_pos).is_some(), "坦克 2 血，第一发不击杀");
                g.begin_turn(Team::Player); // 下一回合第二发
                let out2 = g.attack(c_pos, t_pos).unwrap();
                if out2.hit {
                    assert!(out2.killed, "两发命中应击杀 2 血坦克");
                    any_kill = true;
                }
            }
        }
        assert!(any_kill, "90% 命中率下 30 次至少应有一次两发全中");
    }

    #[test]
    fn test_move_blocked_by_rock() {
        let mut g = GameState::new_seeded(7);
        g.begin_turn(Team::Player);
        // 玩家坦克 A 在 (1,4)，把它挪到岩石 (4,2) 旁边测试阻挡
        let a_pos = hex::axial_from_offset(1, 4);
        let mut tank = g.unit_at(a_pos).unwrap().clone();
        g.units.remove(&a_pos);
        tank.pos = hex::axial_from_offset(3, 2);
        let tp = tank.pos;
        g.units.insert(tp, tank);
        // (4,2) 是岩石，尝试移动到 (4,2) 应失败（plan_move 不会穿过）
        let path = g
            .map
            .plan_move(&g.units, &g.air_units, tp, hex::axial_from_offset(5, 2), 3, None, false);
        for w in path.iter().skip(1) {
            assert!(!g.map.obstacles.contains(w), "路径不应穿过岩石");
        }
    }

    #[test]
    fn test_board_and_disembark() {
        let mut g = GameState::new_deploy_level(3, Level::OpenField);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.water.clear();
        g.map.buildings.clear();
        // 步兵战车 D 载 TOW 射手（1 重量，紧邻上车）
        let d_h = hex::axial_from_offset(5, 5);
        let n_h = hex::axial_from_offset(6, 5);
        g.spawn(UnitKind::Ifv, Team::Player, d_h, 'D');
        g.spawn(UnitKind::Atgm, Team::Player, n_h, 'N');
        g.begin_turn(Team::Player);
        assert!(g.board(d_h, n_h).is_ok(), "紧邻应可上车");
        let d = g.unit_at(d_h).unwrap();
        assert_eq!(d.passengers.len(), 1, "D 应搭载 N");
        assert_eq!(d.used_weight(), 1, "TOW 射手 1 重量");
        assert_eq!(d.actions_left, 1, "上车消耗 D 1 次行动");
        assert!(g.unit_at(n_h).is_none(), "N 已不在地图上");

        // 卡车 E 载重 9：3 名步枪手（每人 3 重量）恰好满载
        let e_h = hex::axial_from_offset(0, 2);
        let b_h = hex::axial_from_offset(0, 3);
        let c_h = hex::axial_from_offset(1, 2);
        let m_h = hex::axial_from_offset(0, 1);
        g.spawn(UnitKind::Truck, Team::Player, e_h, 'E');
        g.spawn(UnitKind::Rifleman, Team::Player, b_h, 'B');
        g.spawn(UnitKind::Rifleman, Team::Player, c_h, 'C');
        g.spawn(UnitKind::Rifleman, Team::Player, m_h, 'M');
        g.begin_turn(Team::Player);
        assert!(g.board(e_h, b_h).is_ok());
        assert_eq!(g.unit_at(e_h).unwrap().used_weight(), 3);
        // 卡车每回合 2 次行动；补足行动后继续装
        g.unit_at_mut(e_h).unwrap().actions_left = 2;
        assert!(g.board(e_h, c_h).is_ok());
        g.unit_at_mut(e_h).unwrap().actions_left = 1;
        assert!(g.board(e_h, m_h).is_ok());
        let e = g.unit_at(e_h).unwrap();
        assert_eq!(e.passengers.len(), 3, "卡车应能装载 3 名步枪手（9 重量）");
        assert_eq!(e.used_weight(), 9, "满载 9 重量");
        assert!(!e.has_space(), "9 重量后应满载");
        // 满载后再装 1 重量单位 → 拒绝
        let x_h = hex::axial_from_offset(1, 1);
        g.spawn(UnitKind::Atgm, Team::Player, x_h, 'X');
        let err = g.board(e_h, x_h).unwrap_err();
        assert!(
            err.contains("载重") || err.contains("满载"),
            "满载后不能继续搭载: {}",
            err
        );
        // 卡车不可运载悍马系列（即便重量 6 在 9 之内也禁止）
        let hum_h = hex::axial_from_offset(1, 3);
        g.spawn(UnitKind::HumveeHmg, Team::Player, hum_h, 'Y');
        let err = g.board(e_h, hum_h).unwrap_err();
        assert!(err.contains("不能搭载"), "卡车不可运载悍马: {}", err);

        // 放下 N 到紧邻空位（下车不消耗行动）
        let dest = hex::axial_from_offset(6, 5);
        let before = g.unit_at(d_h).unwrap().actions_left;
        assert!(g.disembark(d_h, 'N', dest).is_ok());
        assert!(g.unit_at(dest).is_some(), "N 已下车");
        assert!(g.unit_at(d_h).unwrap().passengers.is_empty());
        assert_eq!(
            g.unit_at(d_h).unwrap().actions_left,
            before,
            "下车不消耗行动（装车才耗）"
        );
        // 下车到被占据的格子 → 失败
        assert!(g.disembark(e_h, 'B', dest).is_err());
    }

    /// 道路：车辆沿道路每格只消耗 0.5 行动力（一次移动仍只耗 1 次行动）。
    #[test]
    fn test_road_move_unit_half_cost() {
        let mut g = GameState::new_deploy_level(6, Level::OpenField);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.map.water.clear();
        for c in 0..=6 {
            g.map.add_road(c, 3);
        }
        let start = hex::axial_from_offset(0, 3);
        let mut t = Unit::new(UnitKind::Tank, Team::Player, start);
        t.label = 'A';
        g.units.insert(start, t);
        g.begin_turn(Team::Player);
        let path: Vec<Hex> = (0..=6).map(|c| hex::axial_from_offset(c, 3)).collect();
        let dest = g.move_unit(start, &path, false).unwrap();
        assert_eq!(dest, hex::axial_from_offset(6, 3), "3 行动力可走 6 格道路");
        assert_eq!(
            g.unit_at(dest).unwrap().actions_left,
            1,
            "一次移动只消耗 1 次行动"
        );
        // 对照：无道路时同样 3 行动力只能走 3 格
        let mut g2 = GameState::new_deploy_level(6, Level::OpenField);
        g2.units.clear();
        g2.air_units.clear();
        g2.map.obstacles.clear();
        g2.map.forests.clear();
        g2.map.buildings.clear();
        g2.map.water.clear();
        let s2 = hex::axial_from_offset(0, 3);
        let mut t2 = Unit::new(UnitKind::Tank, Team::Player, s2);
        t2.label = 'A';
        g2.units.insert(s2, t2);
        g2.begin_turn(Team::Player);
        let reach = g2.map.reachable_hexes(&g2.units, s2, 3, g2.unit_at(s2));
        assert!(reach.contains(&hex::axial_from_offset(3, 3)));
        assert!(
            !reach.contains(&hex::axial_from_offset(4, 3)),
            "无道路 3 行动力只走 3 格"
        );
    }

    /// 补给：15 费用、1HP/1甲、每回合 2 行动、行动力 0；仅卡车/重型运输直升机可载（3 重量）。
    #[test]
    fn test_supply_carry_rules() {
        assert_eq!(UnitKind::Supply.name(), "补给");
        assert_eq!(UnitKind::Supply.recruit_cost(), 15);
        assert_eq!(UnitKind::Supply.max_hp(), 1);
        assert_eq!(UnitKind::Supply.armor(), 1);
        assert_eq!(UnitKind::Supply.action_count(), 2);
        assert_eq!(UnitKind::Supply.movement(), 0);
        assert_eq!(UnitKind::Supply.max_ammo(), 5, "补给携带 5 点弹药");
        let carrier = |k: UnitKind| Unit::new(k, Team::Player, hex::axial_from_offset(0, 0));
        assert_eq!(carrier(UnitKind::Supply).occupies_weight(), 3);
        assert!(carrier(UnitKind::Truck).can_carry(UnitKind::Supply));
        assert!(carrier(UnitKind::HeavyTransportHeli).can_carry(UnitKind::Supply));
        assert!(!carrier(UnitKind::Ifv).can_carry(UnitKind::Supply));
        assert!(!carrier(UnitKind::TransportHeli).can_carry(UnitKind::Supply));
        assert!(!carrier(UnitKind::CavalryIfv).can_carry(UnitKind::Supply));
    }

    /// 重型运输直升机可装载补给；普通运输直升机不可。
    #[test]
    fn test_heavy_transport_heli_loads_supply() {
        let mut g = GameState::new_deploy_level(4, Level::OpenField);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.water.clear();
        let h = hex::axial_from_offset(5, 5);
        let mut supply = Unit::new(UnitKind::Supply, Team::Player, h);
        supply.label = 'C';
        g.units.insert(h, supply);
        let mut heli = Unit::new(UnitKind::HeavyTransportHeli, Team::Player, h);
        heli.label = 'H';
        g.air_units.insert(h, heli);
        g.begin_turn(Team::Player);
        g.heli_board(h).expect("重直可载运补给");
        assert_eq!(g.air_units.get(&h).unwrap().passengers.len(), 1);
        assert!(g.units.get(&h).is_none(), "补给已装入机舱");
        // 普通运输直升机不可载补给
        let mut g2 = GameState::new_deploy_level(4, Level::OpenField);
        g2.units.clear();
        g2.air_units.clear();
        g2.map.obstacles.clear();
        let h2 = hex::axial_from_offset(5, 5);
        let mut c2 = Unit::new(UnitKind::Supply, Team::Player, h2);
        c2.label = 'C';
        g2.units.insert(h2, c2);
        g2.air_units
            .insert(h2, Unit::new(UnitKind::TransportHeli, Team::Player, h2));
        g2.begin_turn(Team::Player);
        assert!(g2.heli_board(h2).is_err(), "普通运输直升机不可载补给");
    }

    /// 卡车装载补给（3 重量），剩余 6 载重仍可再载 1 名步兵（3 重量）。
    #[test]
    fn test_truck_carries_supply() {
        let mut g = GameState::new_deploy_level(4, Level::OpenField);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.water.clear();
        let t_h = hex::axial_from_offset(5, 5);
        let c_h = hex::axial_from_offset(6, 5);
        let i_h = hex::axial_from_offset(5, 6);
        let mut truck = Unit::new(UnitKind::Truck, Team::Player, t_h);
        truck.label = 'E';
        g.units.insert(t_h, truck);
        let mut supply = Unit::new(UnitKind::Supply, Team::Player, c_h);
        supply.label = 'C';
        g.units.insert(c_h, supply);
        let mut rifle = Unit::new(UnitKind::Rifleman, Team::Player, i_h);
        rifle.label = 'B';
        g.units.insert(i_h, rifle);
        g.begin_turn(Team::Player);
        g.board(t_h, c_h).expect("卡车装载补给");
        assert_eq!(g.unit_at(t_h).unwrap().used_weight(), 3, "补给 3 重量");
        g.board(t_h, i_h).expect("剩余载重再载 1 步兵");
        assert_eq!(g.unit_at(t_h).unwrap().used_weight(), 6, "补给 3 + 步兵 3");
    }

    /// 补给动作：补给单位消耗 1 行动为半径 2 格内友军补给；
    /// 被补给方也须有行动并消耗 1 行动。
    #[test]
    fn test_supply_action() {
        let mut g = GameState::new_deploy_level(3, Level::OpenField);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.map.water.clear();
        let supply_h = hex::axial_from_offset(5, 5);
        let near_h = hex::axial_from_offset(7, 5);
        let far_h = hex::axial_from_offset(9, 5);
        let noact_h = hex::axial_from_offset(5, 7);
        let mut supply = Unit::new(UnitKind::Supply, Team::Player, supply_h);
        supply.label = 'C';
        g.units.insert(supply_h, supply);
        let mut near = Unit::new(UnitKind::Tank, Team::Player, near_h);
        near.label = 'A';
        g.units.insert(near_h, near);
        let mut far = Unit::new(UnitKind::Tank, Team::Player, far_h);
        far.label = 'B';
        g.units.insert(far_h, far);
        let mut noact = Unit::new(UnitKind::Tank, Team::Player, noact_h);
        noact.label = 'D';
        g.units.insert(noact_h, noact);
        g.begin_turn(Team::Player);
        for h in [near_h, far_h, noact_h] {
            g.unit_at_mut(h).unwrap().ammo = 0;
            g.unit_at_mut(h).unwrap().missile_ammo = 0;
        }
        g.unit_at_mut(noact_h).unwrap().actions_left = 0;
        assert!(g.in_supply_zone(Team::Player, near_h), "距补给 2 格在范围内");
        assert!(!g.in_supply_zone(Team::Player, far_h), "距补给 4 格不在范围内");
        let s0 = g.unit_at(supply_h).unwrap().actions_left;
        let t0 = g.unit_at(near_h).unwrap().actions_left;
        let m = g.resupply_from(supply_h, near_h).unwrap();
        assert!(!m.is_empty());
        assert_eq!(g.unit_at(near_h).unwrap().ammo, UnitKind::Tank.max_ammo());
        assert_eq!(
            g.unit_at(near_h).unwrap().missile_ammo,
            UnitKind::Tank.max_missile_ammo()
        );
        assert_eq!(g.unit_at(near_h).unwrap().actions_left, t0 - 1, "被补给方消耗 1 行动");
        assert_eq!(g.unit_at(supply_h).unwrap().actions_left, s0 - 1, "补给单位消耗 1 行动");
        assert_eq!(g.unit_at(supply_h).unwrap().ammo, 4, "补给单位消耗 1 点弹药");
        assert!(g.resupply_from(supply_h, far_h).is_err(), "范围外不可补给");
        assert!(g.resupply_from(supply_h, supply_h).is_err(), "补给单位自身不可补给");
        let s1 = g.unit_at(supply_h).unwrap().actions_left;
        assert!(g.resupply_from(supply_h, noact_h).is_err(), "被补给方无行动应被拒绝");
        assert_eq!(
            g.unit_at(supply_h).unwrap().actions_left,
            s1,
            "被拒绝的补给不应消耗补给单位行动"
        );
        // 自动补给：补给单位用剩余行动补满范围内另一辆空弹坦克
        g.unit_at_mut(near_h).unwrap().ammo = 0;
        let logs = g.auto_resupply(Team::Player);
        assert!(!logs.is_empty(), "自动补给应生效");
        assert_eq!(g.unit_at(near_h).unwrap().ammo, UnitKind::Tank.max_ammo());

        // 弹药上限：5 点用完后不能再补给
        let mut g2 = GameState::new_deploy_level(3, Level::OpenField);
        g2.units.clear();
        g2.air_units.clear();
        g2.map.obstacles.clear();
        g2.map.forests.clear();
        g2.map.buildings.clear();
        g2.map.water.clear();
        let sh = hex::axial_from_offset(5, 5);
        let th = hex::axial_from_offset(6, 5);
        let mut s = Unit::new(UnitKind::Supply, Team::Player, sh);
        s.label = 'C';
        g2.units.insert(sh, s);
        let mut t = Unit::new(UnitKind::Tank, Team::Player, th);
        t.label = 'A';
        g2.units.insert(th, t);
        g2.begin_turn(Team::Player);
        g2.unit_at_mut(sh).unwrap().actions_left = 10;
        for _ in 0..5 {
            g2.unit_at_mut(th).unwrap().ammo = 0;
            g2.unit_at_mut(th).unwrap().actions_left = 2;
            g2.resupply_from(sh, th).expect("前 5 次补给应成功");
        }
        assert_eq!(g2.unit_at(sh).unwrap().ammo, 0, "5 点弹药应耗尽");
        g2.unit_at_mut(th).unwrap().ammo = 0;
        g2.unit_at_mut(th).unwrap().actions_left = 2;
        assert!(
            g2.resupply_from(sh, th).is_err(),
            "弹药耗尽后不可再补给"
        );
    }

    /// 大本营补给：本方大本营据点半径 2 格内任意己方棋子消耗 1 行动补满弹药。
    #[test]
    fn test_hq_resupply_area() {
        let mut g = GameState::new_deploy_level(3, Level::OpenField);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.map.water.clear();
        let hq = hex::axial_from_offset(5, 5);
        g.keypoints.insert(
            hq,
            Keypoint {
                owner: Team::Player,
                controller: Team::Player,
                center: true,
            },
        );
        let near_h = hex::axial_from_offset(7, 5);
        let far_h = hex::axial_from_offset(9, 5);
        let foe_h = hex::axial_from_offset(5, 7);
        let mut near = Unit::new(UnitKind::Tank, Team::Player, near_h);
        near.label = 'A';
        near.ammo = 0;
        g.units.insert(near_h, near);
        let mut far = Unit::new(UnitKind::Tank, Team::Player, far_h);
        far.label = 'B';
        far.ammo = 0;
        g.units.insert(far_h, far);
        let mut foe = Unit::new(UnitKind::Rifleman, Team::Ai, foe_h);
        foe.label = 'x';
        g.units.insert(foe_h, foe);
        g.begin_turn(Team::Player);
        assert!(g.in_hq_supply_area(Team::Player, near_h), "距大本营 2 格在范围内");
        assert!(!g.in_hq_supply_area(Team::Player, far_h), "距大本营 4 格不在范围内");
        let a0 = g.unit_at(near_h).unwrap().actions_left;
        g.resupply_at_hq(Team::Player, near_h).expect("大本营补给");
        assert_eq!(g.unit_at(near_h).unwrap().ammo, UnitKind::Tank.max_ammo());
        assert_eq!(g.unit_at(near_h).unwrap().actions_left, a0 - 1, "消耗 1 行动");
        assert!(g.resupply_at_hq(Team::Player, far_h).is_err(), "范围外不可大本营补给");
        assert!(
            g.resupply_at_hq(Team::Player, foe_h).is_err(),
            "不能补给敌方棋子"
        );
        assert!(
            g.resupply_at_hq(Team::Ai, foe_h).is_err(),
            "AI 没有大本营时不可补给"
        );
    }

    #[test]
    fn test_vehicle_destroyed_kills_passengers() {
        let mut g = GameState::new_seeded(9);
        g.begin_turn(Team::Player);
        let d_h = hex::axial_from_offset(1, 6);
        let n_h = hex::axial_from_offset(1, 5);
        g.board(d_h, n_h).unwrap();
        // 把 D 血量压到 1
        g.unit_at_mut(d_h).unwrap().hp = 1;
        // AI TOW射手 3（攻击力4 > 护甲3）攻击 D
        let mut atgm = g
            .unit_at(*g.units.iter().find(|(_, u)| u.label == '3').unwrap().0)
            .unwrap()
            .clone();
        g.units.remove(&atgm.pos);
        atgm.pos = hex::axial_from_offset(0, 7); // 与 D (1,6) 相邻
        let ap = atgm.pos;
        g.units.insert(ap, atgm);
        let out = g.attack(ap, d_h).unwrap();
        if out.hit {
            assert!(out.killed, "D 血量1被命中应摧毁");
            assert!(g.unit_at(d_h).is_none(), "D 已被移除");
            assert!(g.units.values().all(|u| u.label != 'N'), "搭载的 N 也阵亡");
        }
    }

    #[test]
    fn test_howitzer_area_attack() {
        let mut g = GameState::new_seeded(11);
        g.begin_turn(Team::Player);
        // 榴弹炮 F 在 (0,0)，把三个 AI 单位挪到 (3,2)/(3,3)/(4,3) 附近
        let f_h = hex::axial_from_offset(0, 0);
        // 挪 AI 单位到炮击范围内
        let moves = [
            ('1', (3, 2)),
            ('2', (3, 3)),
            ('3', (4, 3)),
        ];
        for (label, (c, r)) in moves {
            let h = *g.units.iter().find(|(_, u)| u.label == label).unwrap().0;
            let mut u = g.units.remove(&h).unwrap();
            u.pos = hex::axial_from_offset(c, r);
            g.units.insert(u.pos, u);
        }
        // 中心 (3,3) 在 F 射程内且无岩石遮挡？
        let center = hex::axial_from_offset(3, 3);
        assert!(Hex::distance(f_h, center) <= 10, "射程内");
        assert!(g.map.has_los(f_h, center), "应有视线");
        // 未架设不能开火
        let err = g.attack(f_h, center).unwrap_err();
        assert!(err.contains("架设"), "未架设应被拒: {}", err);
        // 架设消耗 1 次行动 → 本回合行动耗尽
        assert!(g.deploy(f_h).is_ok());
        assert_eq!(g.unit_at(f_h).unwrap().actions_left, 0);
        assert!(g.unit_at(f_h).unwrap().deployed);
        // 下一回合：架设状态保留，可直接射击
        g.begin_turn(Team::Player);
        let out = g.attack(f_h, center).unwrap();
        assert!(out.hit, "范围内有目标，应有命中判定");
        assert_eq!(g.unit_at(f_h).unwrap().actions_left, 0, "榴弹炮每回合 1 次行动");
        // 炮击空点也允许
        g.begin_turn(Team::Player); // 刷新行动（架设状态保留，连续射击）
        let empty = hex::axial_from_offset(5, 5);
        assert!(g.attack(f_h, empty).is_ok(), "炮击空格允许");
        // 超出射程被拒
        let far = hex::axial_from_offset(14, 8);
        assert!(g.attack(f_h, far).is_err());
    }

    #[test]
    fn test_ai_game_terminates() {
        let mut g = GameState::new_seeded(42);
        let mut turns = 0;
        while !g.game_over() && !g.is_draw() && turns < 400 {
            g.begin_turn(Team::Player);
            ai::run_ai_turn(&mut g, Team::Player, &mut Vec::new());
            if g.game_over() {
                break;
            }
            g.begin_turn(Team::Ai);
            ai::run_ai_turn(&mut g, Team::Ai, &mut Vec::new());
            turns += 1;
        }
        assert!(
            g.game_over() || g.is_draw(),
            "AI 对局应在有限回合内分出胜负或判定平局 (turn={})",
            g.turn
        );
    }
}

#[test]
fn test_attack_blocked_by_los() {
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    // 自包含地形（清空默认地形，避免楼房/森林遮挡干扰）
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    // 在 row 4 放一块岩石墙（BFS 侦察下绕不过去），把玩家坦克 A 放到 (3,4)，AI 步枪手放到 (7,4)
    g.map.add_obstacle(5, 3);
    g.map.add_obstacle(5, 4);
    g.map.add_obstacle(5, 5);
    let a_h = hex::axial_from_offset(3, 4);
    let mut a = g
        .unit_at(*g.units.iter().find(|(_, u)| u.label == 'A').unwrap().0)
        .unwrap()
        .clone();
    g.units.remove(&a.pos);
    a.pos = a_h;
    g.units.insert(a_h, a.clone());

    let t_h = hex::axial_from_offset(7, 4);
    let mut t = g
        .unit_at(*g.units.iter().find(|(_, u)| u.label == '2').unwrap().0)
        .unwrap()
        .clone();
    // 目标改为坦克（隐蔽 1）：新机制下 5 步内可见，避免被步兵隐蔽（视野/2）干扰测试
    t.kind = UnitKind::Tank;
    t.hp = UnitKind::Tank.max_hp();
    t.ammo = UnitKind::Tank.max_ammo();
    g.units.remove(&t.pos);
    t.pos = t_h;
    g.units.insert(t_h, t.clone());

    // 只保留 A 一个我方单位，确保视野仅来自 A 自己（避免共享视野意外侦察）
    g.units.retain(|_, u| u.team != Team::Player);
    g.air_units.retain(|_, u| u.team != Team::Player);
    g.units.insert(a_h, a.clone());

    // 中间隔岩石 → 岩石挡住 A 的视野 → 目标未侦察 → 攻击被拒
    let err = g.attack(a_h, t_h).unwrap_err();
    assert!(err.contains("侦察"), "应提示侦察: {}", err);
    assert_eq!(g.unit_at(a_h).unwrap().actions_left, 2, "被拒绝的攻击不应消耗行动");

    // 找一个"直射视线通畅且可见"的位置（避开岩石墙）→ 可正常攻击
    g.units.remove(&t_h);
    let mut t2 = t_h;
    for col in 6..12 {
        for row in 4..9 {
            let h = hex::axial_from_offset(col, row);
            if h == t_h {
                continue;
            }
            t.pos = h;
            g.units.insert(h, t.clone());
            let ok = g.map.has_los(a_h, h) && g.is_unit_visible(Team::Player, h);
            g.units.remove(&h);
            if ok {
                t2 = h;
                break;
            }
        }
        if t2 != t_h {
            break;
        }
    }
    assert!(t2 != t_h, "应能找到无遮挡且可见的目标位置");
    t.pos = t2;
    g.units.insert(t2, t);
    assert!(g.attack(a_h, t2).is_ok(), "无遮挡应可攻击");
}

#[test]
fn test_air_unit_moves_over_rocks() {
    let mut g = GameState::new_seeded(21);
    g.begin_turn(Team::Player);
    // 武装直升机 G 在 (0,1)。岩石 (4,2)：把 G 移到 (3,2)（紧邻岩石），
    // 然后尝试移动到岩石 (4,2)——空中单位可以，陆地单位不行。
    let g_h = hex::axial_from_offset(0, 1);
    let mut heli = g.air_units.remove(&g_h).unwrap();
    heli.pos = hex::axial_from_offset(3, 2);
    g.air_units.insert(heli.pos, heli.clone());

    let rock = hex::axial_from_offset(4, 2);
    assert!(g.map.obstacles.contains(&rock));
    // 直升机可达格包含岩石
    let reach = g.map.reachable_hexes(&g.units, heli.pos, heli.kind.movement(), Some(&heli));
    assert!(reach.contains(&rock), "直升机应能飞到岩石上方");
    // 陆战单位（步枪手 B）可达格不包含岩石
    let b_h = hex::axial_from_offset(0, 3);
    let b = g.unit_at(b_h).unwrap();
    let reach2 = g.map.reachable_hexes(&g.units, b.pos, b.kind.movement(), Some(b));
    assert!(!reach2.contains(&rock), "陆战单位不能上岩石");

    // 直升机实际移动到岩石上
    let path = g.map.plan_move(&g.units, &g.air_units, heli.pos, rock, heli.kind.movement(), Some(heli), false);
    assert_eq!(*path.last().unwrap(), rock, "直升机可停在岩石上方");
}

/// 空中单位的规划路径必须与 move_unit 的真实规则一致：
/// 遇到另一架空中单位挡在直线路径上时，只要行动力足够就应绕行抵达，
/// 而不是把行动判定为"被阻挡"。
#[test]
fn test_air_move_routes_around_air_blocker() {
    let mut g = GameState::new_seeded(1);
    g.begin_turn(Team::Player);
    g.units.clear();
    g.air_units.clear();
    g.map.obstacles.clear();
    g.map.water.clear();
    g.map.buildings.clear();
    g.map.forests.clear();

    let start = hex::axial_from_offset(0, 4);
    let heli = Unit::new(UnitKind::TransportHeli, Team::Player, start);
    g.air_units.insert(start, heli.clone());
    // 正东邻格被另一架己方直升机占用 → 直线路径需绕行
    let blocker = hex::axial_from_offset(1, 4);
    g.air_units
        .insert(blocker, Unit::new(UnitKind::AttackHeli, Team::Player, blocker));

    let target = hex::axial_from_offset(3, 4);
    let path = g.map.plan_move(
        &g.units,
        &g.air_units,
        start,
        target,
        heli.kind.movement(),
        Some(heli),
        false,
    );
    assert!(
        !path.contains(&blocker),
        "规划的空中路径不应穿过被占用的空中格：{:?}",
        path
    );
    match g.move_unit(start, &path, true) {
        Ok(dest) => assert_eq!(dest, target, "应绕过阻挡抵达目的地"),
        Err(e) => panic!("行动力足够时不应判定被阻挡：{}", e),
    }
}

#[test]
fn test_air_targeting_rules() {
    let mut g = GameState::new_seeded(23);
    g.begin_turn(Team::Player);
    // 把 AI 武装直升机 7 放到玩家单位附近（空中层）
    let ai_heli = hex::axial_from_offset(2, 3);
    let mut h7 = g
        .air_units
        .iter()
        .find(|(_, u)| u.label == '7')
        .map(|(h, _)| *h)
        .and_then(|h| g.air_units.remove(&h))
        .unwrap();
    h7.pos = ai_heli;
    g.air_units.insert(ai_heli, h7);

    // 玩家坦克 A(1,3) 打直升机 → 拒绝（陆战不能打空中）
    let a_h = hex::axial_from_offset(1, 3);
    let err = g.attack(a_h, ai_heli).unwrap_err();
    assert!(err.contains("空中"), "坦克不能打直升机: {}", err);

    // 玩家防空导弹手 I(1,1) 打直升机 → 允许；打地面 → 拒绝
    let i_h = hex::axial_from_offset(1, 1);
    assert!(g.attack(i_h, ai_heli).is_ok(), "防空导弹手应能打直升机");
    // 防空导弹手可能触发致命伤击落目标；后续还需要一个直升机目标，若被击落则补一个
    if !g.air_units.contains_key(&ai_heli) {
        let mut h7 = Unit::new(UnitKind::AttackHeli, Team::Ai, ai_heli);
        h7.label = '7';
        g.air_units.insert(ai_heli, h7);
    }
    // 防空导弹手打地面（把 AI 坦克 1 放到附近）→ 拒绝
    let ai_tank = hex::axial_from_offset(3, 1);
    let mut t1 = g
        .unit_at(*g.units.iter().find(|(_, u)| u.label == '1').unwrap().0)
        .unwrap()
        .clone();
    g.units.remove(&t1.pos);
    t1.pos = ai_tank;
    g.units.insert(ai_tank, t1);
    let err = g.attack(i_h, ai_tank).unwrap_err();
    assert!(err.contains("只能攻击直升机"), "防空导弹手不能打地面: {}", err);

    // 玩家 M-SHORAD J(1,2) 打地面 → 允许
    let j_h = hex::axial_from_offset(1, 2);
    assert!(g.attack(j_h, ai_tank).is_ok(), "M-SHORAD 机枪模式应能打地面");

    // 玩家武装直升机 G(0,1) 打直升机 → 允许；打地面坦克 → 允许
    let g_h = hex::axial_from_offset(0, 1);
    assert!(g.attack(g_h, ai_heli).is_ok(), "武装直升机应能打直升机");
    assert!(g.attack(g_h, ai_tank).is_ok(), "武装直升机应能打地面");
}

#[test]
fn test_heli_on_rock_firing_and_being_hit() {
    let mut g = GameState::new_seeded(25);
    g.begin_turn(Team::Player);
    // 清空默认地形，使用自包含布局：岩石 (2,4)（防空步兵 I 视野 3 恰好可及）
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.map.add_obstacle(2, 4);
    let rock = hex::axial_from_offset(2, 4);
    let mut heli = g
        .air_units
        .iter()
        .find(|(_, u)| u.label == '7')
        .map(|(h, _)| *h)
        .and_then(|h| g.air_units.remove(&h))
        .unwrap();
    heli.pos = rock;
    g.air_units.insert(rock, heli.clone());

    // 岩石上方的直升机不能开火（把玩家坦克 A 放到 (4,3) 作目标）
    let target = hex::axial_from_offset(4, 3);
    let mut a = g
        .units
        .iter()
        .find(|(_, u)| u.label == 'A')
        .map(|(h, _)| *h)
        .and_then(|h| g.units.remove(&h))
        .unwrap();
    a.pos = target;
    g.units.insert(target, a);
    let err = g.attack(rock, target).unwrap_err();
    assert!(err.contains("岩石上方"), "岩石上方无法开火: {}", err);

    // 防空单位可以命中岩石上方的直升机（端点岩石不阻挡视线，且在其视野内）
    let i_h = hex::axial_from_offset(1, 1);
    assert!(g.map.has_los(i_h, rock), "端点岩石不应阻挡视线");
    assert!(
        g.is_revealed(Team::Player, rock),
        "I (视野3) 应能看到岩石上的直升机"
    );
    assert!(g.attack(i_h, rock).is_ok(), "防空应能打停在岩石上的直升机");
}

#[test]
fn test_transport_heli_board_disembark() {
    let mut g = GameState::new_seeded(27);
    g.begin_turn(Team::Player);
    // 运输直升机 H 在 (0,6)，步枪手 M 在 (0,5)，紧邻
    let h_h = hex::axial_from_offset(0, 6);
    let m_h = hex::axial_from_offset(0, 5);
    assert!(g.board(h_h, m_h).is_ok(), "运输直升机应可搭载紧邻步兵");
    assert_eq!(g.unit_at(h_h).unwrap().passengers.len(), 1);
    assert!(g.unit_at(m_h).is_none(), "M 已上机");

    // 放下到正下方（自身所在格 (0,6)：M 落到地面层，H 仍在空中层）
    assert!(g.disembark(h_h, 'M', h_h).is_ok(), "可放到正下方");
    assert!(g.air_units.get(&h_h).map(|u| u.label) == Some('H'), "H 仍在空中");
    assert!(g.units.get(&h_h).map(|u| u.label) == Some('M'), "M 已下到正下方 (0,6)");

    // 运输直升机不能把步兵放到其他格子
    assert!(g.disembark(h_h, 'M', hex::axial_from_offset(0, 7)).is_err());

    // 运输直升机在岩石上方不能搭载/放下（把 M 移到岩石旁 (3,2)）
    let rock = hex::axial_from_offset(4, 2);
    let mut heli = g.air_units.remove(&h_h).unwrap();
    heli.pos = rock;
    g.air_units.insert(rock, heli);
    let mut m = g.units.remove(&h_h).unwrap(); // M 在地面层 (0,6)
    m.pos = hex::axial_from_offset(3, 2);
    let m_pos = m.pos;
    g.units.insert(m_pos, m);
    let err = g.board(rock, m_pos).unwrap_err();
    assert!(err.contains("岩石"), "岩石上方不能搭载: {}", err);
    let err = g.disembark(rock, 'M', rock).unwrap_err();
    assert!(err.contains("岩石"), "岩石上方不能放下: {}", err);
}

#[test]
fn test_forest_move_cost_ceil() {
    let mut g = GameState::new_seeded(3);
    for (c, r) in [(2, 3), (3, 3), (4, 3)] {
        g.map.add_forest(c, r);
    }
    let start = hex::axial_from_offset(1, 3);
    g.units.clear();
    g.air_units.clear();
    g.spawn(UnitKind::Tank, Team::Player, start, 'A'); // 行动力 3
    g.begin_turn(Team::Player);
    // 3 点行动力走 3 格森林（需 6 点）→ 失败
    let p3 = vec![
        start,
        hex::axial_from_offset(2, 3),
        hex::axial_from_offset(3, 3),
        hex::axial_from_offset(4, 3),
    ];
    assert!(g.move_unit(start, &p3, false).is_err());
    // 3 点行动力走 2 格森林（向上取整）→ 成功
    let p2 = vec![start, hex::axial_from_offset(2, 3), hex::axial_from_offset(3, 3)];
    assert!(g.move_unit(start, &p2, false).is_ok());
}

#[test]
fn test_building_restriction_move() {
    let mut g = GameState::new_seeded(3);
    g.map.forests.clear();
    g.map.buildings.clear();
    g.map.add_building(3, 3);
    let start = hex::axial_from_offset(2, 3); // 坦克，紧邻楼房
    let b_h = hex::axial_from_offset(4, 4); // 步枪兵，紧邻楼房
    g.units.clear();
    g.air_units.clear();
    g.spawn(UnitKind::Tank, Team::Player, start, 'A');
    g.spawn(UnitKind::Rifleman, Team::Player, b_h, 'B');
    g.begin_turn(Team::Player);
    // 坦克（车辆）不能进入楼房
    let p = vec![start, hex::axial_from_offset(3, 3)];
    let err = g.move_unit(start, &p, false).unwrap_err();
    assert!(err.contains("楼房"), "车辆进楼房应被拒绝: {}", err);
    // 步枪兵（步兵）可以进入楼房
    let p2 = vec![b_h, hex::axial_from_offset(3, 3)];
    assert!(g.move_unit(b_h, &p2, false).is_ok());
}

#[test]
fn test_terrain_hit_rate() {
    let mut g = GameState::new_seeded(7);
    // 自包含地形：森林 (3,4)、楼房 (4,4)
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.map.add_forest(3, 4);
    g.map.add_building(4, 4);
    let a_h = hex::axial_from_offset(2, 4);
    let f_h = hex::axial_from_offset(3, 4);
    let b_h = hex::axial_from_offset(4, 4);
    g.units.clear();
    g.air_units.clear();
    g.spawn(UnitKind::Tank, Team::Player, a_h, 'A'); // 命中率 90%
    g.spawn(UnitKind::Tank, Team::Ai, f_h, '2'); // 坦克（隐蔽 1）不被步兵隐蔽干扰
    g.spawn(UnitKind::Tank, Team::Ai, b_h, '3');
    g.begin_turn(Team::Player);
    // 森林目标：90×0.8 = 72（森林只减命中率，不挡视线）
    let o1 = g.attack(a_h, f_h).unwrap();
    assert!(
        o1.message.contains("72") && o1.message.contains("森林隐蔽"),
        "森林×0.8=72: {}",
        o1.message
    );
    // 楼房目标：90×0.6 = 54（目标所在楼房是端点，不挡视线）
    let o2 = g.attack(a_h, b_h).unwrap();
    assert!(
        o2.message.contains("54") && o2.message.contains("楼房隐蔽"),
        "楼房×0.6=54: {}",
        o2.message
    );
    // 开阔地目标：无修正（放到 (2,3)，不与楼房/森林共线）
    let o_h = hex::axial_from_offset(2, 3);
    g.spawn(UnitKind::Rifleman, Team::Ai, o_h, '4');
    g.unit_at_mut(a_h).unwrap().actions_left = 1; // 补 1 次行动
    let o3 = g.attack(a_h, o_h).unwrap();
    assert!(
        o3.message.contains("90") && !o3.message.contains("隐蔽"),
        "开阔地命中率 90: {}",
        o3.message
    );
}

#[test]
fn test_heli_board_unload() {
    let mut g = GameState::new_seeded(3);
    let h_h = hex::axial_from_offset(2, 3);
    g.units.clear();
    g.air_units.clear();
    g.spawn(UnitKind::TransportHeli, Team::Player, h_h, 'H');
    g.spawn(UnitKind::Rifleman, Team::Player, h_h, 'M');
    g.begin_turn(Team::Player);
    // 条件：步兵行动耗尽 → 不能载入
    g.unit_at_mut(h_h).unwrap().actions_left = 0;
    let err = g.heli_board(h_h).unwrap_err();
    assert!(err.contains("行动次数不足"), "{}", err);
    g.unit_at_mut(h_h).unwrap().actions_left = 3;
    // 载入成功：双方各消耗 1 次行动
    assert!(g.heli_board(h_h).is_ok());
    let heli = g.air_units.get(&h_h).unwrap();
    assert_eq!(heli.passengers.len(), 1);
    assert_eq!(heli.actions_left, 1, "直升机消耗 1 次行动");
    assert_eq!(heli.passengers[0].actions_left, 0, "步兵登机后当回合不能行动");
    assert!(g.units.get(&h_h).is_none(), "下方步兵已上机");
    // 已载人 → 不能再次载入
    assert!(g.heli_board(h_h).is_err());
    // 直升机行动耗尽 → 不能放下
    g.air_units.get_mut(&h_h).unwrap().actions_left = 0;
    assert!(g.heli_unload(h_h).is_err());
    // 飞到岩石上方 → 不能放下
    let rock = hex::axial_from_offset(4, 2);
    let mut heli = g.air_units.remove(&h_h).unwrap();
    heli.actions_left = 2;
    heli.pos = rock;
    g.air_units.insert(rock, heli);
    assert!(g.heli_unload(rock).is_err());
    // 飞到空地 → 放下成功，步兵当回合不能行动
    let dest = hex::axial_from_offset(5, 3);
    let mut heli = g.air_units.remove(&rock).unwrap();
    heli.pos = dest;
    g.air_units.insert(dest, heli);
    assert!(g.heli_unload(dest).is_ok());
    let inf = g.units.get(&dest).unwrap();
    assert_eq!(inf.label, 'M');
    assert_eq!(inf.actions_left, 0, "卸下后第一回合不能行动");
    let heli2 = g.air_units.get(&dest).unwrap();
    assert!(heli2.passengers.is_empty());
    assert_eq!(heli2.actions_left, 1);
}

#[test]
fn test_ammo_system() {
    let mut g = GameState::new_seeded(5);
    let a_h = hex::axial_from_offset(1, 3); // 玩家坦克 A
    let t_h = hex::axial_from_offset(13, 3); // AI 坦克 1（相邻一行）
    g.units.clear();
    g.air_units.clear();
    g.spawn(UnitKind::Tank, Team::Player, a_h, 'A');
    g.spawn(UnitKind::Tank, Team::Ai, t_h, '1');
    g.spawn(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(2, 3), '2');
    g.begin_turn(Team::Player);
    let a = g.unit_at(a_h).unwrap().clone();
    assert_eq!(a.ammo, 42, "坦克携弹 42 发");
    assert_eq!(UnitKind::Atgm.max_ammo(), 4, "TOW射手 4 枚导弹");
    assert_eq!(UnitKind::Rifleman.max_ammo(), 10, "步枪手 10 个弹匣");
    assert_eq!(UnitKind::Howitzer.max_ammo(), 24, "榴弹炮 1 个弹药基数");
    assert_eq!(UnitKind::Truck.max_ammo(), 0, "卡车无武器");
    // 攻击消耗 1 发弹药
    let _ = g.attack(a_h, hex::axial_from_offset(2, 3)).unwrap();
    let a = g.unit_at(a_h).unwrap();
    assert_eq!(a.ammo, 41, "开火后弹药 42->41");
    assert_eq!(a.actions_left, 1, "行动正常消耗");
    // 弹药不影响回合刷新（弹药不补给）
    g.begin_turn(Team::Player);
    assert_eq!(g.unit_at(a_h).unwrap().ammo, 41, "新回合弹药不补充");
    // 耗尽后无法攻击且不消耗行动（换一个新目标，避免上一个被击杀）
    g.spawn(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(3, 3), '3');
    g.unit_at_mut(a_h).unwrap().ammo = 0;
    let err = g.attack(a_h, hex::axial_from_offset(3, 3)).unwrap_err();
    assert!(err.contains("弹药"), "弹药耗尽应报错: {}", err);
    assert_eq!(g.unit_at(a_h).unwrap().actions_left, 2, "失败的攻击不消耗行动");
    // 榴弹炮炮击消耗弹药（先架设）
    let f_h = hex::axial_from_offset(0, 0);
    g.spawn(UnitKind::Howitzer, Team::Player, f_h, 'F');
    g.begin_turn(Team::Player);
    g.deploy(f_h).unwrap();
    g.begin_turn(Team::Player); // 架设后下一回合射击
    let err2 = g.attack(f_h, hex::axial_from_offset(2, 2));
    assert!(err2.is_ok());
    let f = g.unit_at(f_h).unwrap();
    assert_eq!(f.ammo, 23, "炮击后弹药 24->23");
    // 榴弹炮弹药耗尽无法炮击（先恢复 1 次行动）
    let f = g.unit_at_mut(f_h).unwrap();
    f.actions_left = 1;
    f.ammo = 0;
    let err3 = g.attack(f_h, hex::axial_from_offset(2, 2)).unwrap_err();
    assert!(err3.contains("弹药"), "榴弹炮弹药耗尽: {}", err3);
}

#[test]
fn test_vision_system() {
    // 视野距离：普通步兵 4、特战 6、车辆较强、直升机最远
    assert_eq!(UnitKind::Rifleman.vision(), 4);
    assert_eq!(UnitKind::Atgm.vision(), 4);
    assert_eq!(UnitKind::AaInfantry.vision(), 4);
    assert_eq!(UnitKind::SpecialForces.vision(), 6, "特战小队视野 6");
    assert_eq!(UnitKind::Tank.vision(), 5);
    assert_eq!(UnitKind::Ifv.vision(), 5);
    assert_eq!(UnitKind::AaMgv.vision(), 5);
    assert_eq!(UnitKind::Howitzer.vision(), 5);
    assert_eq!(UnitKind::AaLauncher.vision(), 6);
    assert_eq!(UnitKind::Truck.vision(), 4);
    assert_eq!(UnitKind::AttackHeli.vision(), 9);
    assert_eq!(UnitKind::TransportHeli.vision(), 9);

    // 自包含地图：岩石 (4,3) 挡在 (1,3) 与 (7,3) 之间
    let mut g = GameState::new_seeded(55);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.map.add_obstacle(4, 3);
    g.units.clear();
    g.air_units.clear();
    // 坦克 A（视野5）在 (1,3)，AI 坦克在 (7,3)：距离 6，被岩石遮挡
    let a_h = hex::axial_from_offset(1, 3);
    let t_h = hex::axial_from_offset(7, 3);
    g.spawn(UnitKind::Tank, Team::Player, a_h, 'A');
    g.spawn(UnitKind::Tank, Team::Ai, t_h, '1');
    g.begin_turn(Team::Player);

    // 1) 视野内判定：自己所在格永远可见；岩石挡住直线视野
    assert!(g.is_revealed(Team::Player, a_h), "自己所在格可见");
    assert!(!g.is_revealed(Team::Player, t_h), "被岩石挡住看不见 (7,3)");

    // 2) 攻击需要目标在视野内：被岩石遮挡 → 拒绝
    let err = g.attack(a_h, t_h).unwrap_err();
    assert!(err.contains("侦察"), "未侦察目标不可攻击: {}", err);

    // 3) 共享视野：武装直升机 G 从高处（无遮挡的 (5,1)）侦察到 (7,3)。
    //    共享视野让 A 获得目标视野，但**直射视线**仍被中间岩石阻断——
    //    直射武器不能隔岩开火（间瞄火力除外）。
    let g_h = hex::axial_from_offset(5, 1);
    g.spawn(UnitKind::AttackHeli, Team::Player, g_h, 'G');
    assert!(
        g.is_revealed(Team::Player, t_h),
        "直升机侦察后 (7,3) 应进入我方视野（共享）"
    );
    assert!(!g.map.has_los(a_h, t_h), "中间岩石应阻断直射视线");
    let err = g.attack(a_h, t_h).unwrap_err();
    assert!(
        err.contains("视线") || err.contains("阻隔"),
        "共享视野不能绕过直射视线: {}",
        err
    );

    // 4) 榴弹炮无需视野即可炮击（清除我方单位，使 (7,3) 重新不可见；先架设）
    g.units.clear();
    g.air_units.clear();
    let f_h = hex::axial_from_offset(0, 0);
    g.spawn(UnitKind::Howitzer, Team::Player, f_h, 'F');
    g.spawn(UnitKind::Tank, Team::Ai, hex::axial_from_offset(6, 3), '1');
    g.begin_turn(Team::Player);
    // 榴弹炮自身视野 5：目标在 (6,3)，距离 6，被岩石 (4,3) 遮挡 → 视野外
    let blind_target = hex::axial_from_offset(6, 3);
    assert!(!g.is_revealed(Team::Player, blind_target), "炮击目标在视野外");
    g.deploy(f_h).unwrap();
    g.begin_turn(Team::Player); // 架设后下一回合射击
    let o = g.attack(f_h, blind_target).unwrap();
    assert!(
        o.message.contains("炮击"),
        "榴弹炮应能对视野外的格子炮击: {}",
        o.message
    );

    // 5) 榴弹炮炮击仍有射程限制（超出射程拒绝）
    let far = hex::axial_from_offset(18, 8);
    assert!(g.attack(f_h, far).is_err(), "超出射程仍被拒绝");
}

#[test]
fn test_building_blocks_los_and_vision() {
    // 楼房与岩石一样遮挡视野和射击（端点所在楼房不阻挡）
    let mut g = GameState::new_seeded(61);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.map.add_building(4, 3);
    g.units.clear();
    g.air_units.clear();
    let a_h = hex::axial_from_offset(1, 3);
    let t_h = hex::axial_from_offset(7, 3);
    g.spawn(UnitKind::Tank, Team::Player, a_h, 'A'); // 视野 5
    g.spawn(UnitKind::Tank, Team::Ai, t_h, '1');
    g.begin_turn(Team::Player);
    // 楼房在中间 → 视线被挡 → 目标未侦察 → 攻击被拒
    assert!(!g.map.has_los(a_h, t_h), "楼房应遮挡视线");
    assert!(!g.is_revealed(Team::Player, t_h), "楼房后目标不可见");
    let err = g.attack(a_h, t_h).unwrap_err();
    assert!(err.contains("侦察"), "楼房后目标不可攻击: {}", err);
    // 直升机侦察（楼房旁无遮挡位置）后共享视野可见，但直射视线仍被楼房阻断
    let g_h = hex::axial_from_offset(5, 1);
    g.spawn(UnitKind::AttackHeli, Team::Player, g_h, 'G');
    assert!(g.is_revealed(Team::Player, t_h), "直升机共享视野");
    assert!(!g.map.has_los(a_h, t_h), "楼房应阻断直射视线");
    let err = g.attack(a_h, t_h).unwrap_err();
    assert!(
        err.contains("视线") || err.contains("阻隔"),
        "楼房后目标不可直射: {}",
        err
    );
    // 目标在楼房内（端点楼房不阻挡视线/射击）：步兵 B(3,3) 攻击楼内敌人 (4,3)
    g.units.clear();
    g.air_units.clear();
    let in_b = hex::axial_from_offset(4, 3);
    g.spawn(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(3, 3), 'B');
    g.spawn(UnitKind::Rifleman, Team::Ai, in_b, '2'); // 目标在楼房内
    g.begin_turn(Team::Player);
    assert!(
        g.attack(hex::axial_from_offset(3, 3), in_b).is_ok(),
        "目标所在楼房（端点）不阻挡攻击"
    );
}

#[test]
fn test_forest_reduces_vision() {
    // BFS 侦察：森林每格计 2 步（森林减弱视野）；岩石/楼房不可穿透；可绕行。
    let mut g = GameState::new_seeded(63);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let a_h = hex::axial_from_offset(1, 3);
    g.spawn(UnitKind::Truck, Team::Player, a_h, 'A'); // 视野 4
    g.begin_turn(Team::Player);
    // 开阔地：(5,3) 从 (1,3) 直线 4 步 → 可见（视野 4）
    assert!(
        g.is_revealed(Team::Player, hex::axial_from_offset(5, 3)),
        "开阔地 4 步应可见"
    );
    assert!(!g.is_revealed(Team::Player, hex::axial_from_offset(6, 3)), "5 步超出视野");
    // 在 (3,3) 放森林：穿过它到 (5,3) 多 1 步（3,3 计 2 步）→ 4+1=5 > 4 不可见
    g.map.add_forest(3, 3);
    assert!(
        !g.is_revealed(Team::Player, hex::axial_from_offset(5, 3)),
        "穿过森林后 5 步应超出视野（森林减弱视野）"
    );
    // 森林格自身仍可见（进入计 2 步）
    assert!(
        g.is_revealed(Team::Player, hex::axial_from_offset(3, 3)),
        "森林格 2+1=3 步应可见"
    );
    // 绕开森林：从 (2,4)(3,4)(4,4) 到 (5,4) 都是开阔地 → (5,4) 可见
    assert!(
        g.is_revealed(Team::Player, hex::axial_from_offset(5, 4)),
        "绕行开阔地 4 步应可见"
    );
    // 站在森林里视野更差：把 A 挪进森林 (2,3)（进入计 2 步），
    // 从 (2,3) 看 (6,3)（3 步开阔 + 自身森林格 = 4 步）→ 可见；看 (7,3)（5 步）→ 不可见
    let mut a = g.unit_at(a_h).unwrap().clone();
    g.units.remove(&a_h);
    a.pos = hex::axial_from_offset(2, 3);
    g.units.insert(a.pos, a);
    g.begin_turn(Team::Player);
    assert!(g.is_revealed(Team::Player, hex::axial_from_offset(5, 3)), "(3,3)森林2+(4,3)(5,3)开阔2=4 应可见");
    assert!(
        !g.is_revealed(Team::Player, hex::axial_from_offset(6, 3)),
        "5 步超出视野 4"
    );
}

#[test]
fn test_deploy_phase() {
    let mut g = GameState::new_deploy(71);
    assert!(g.deploying, "新对局处于部署阶段");
    assert_eq!(g.recruit_points[&Team::Player], 100);
    assert!(g.units_of(Team::Player).is_empty(), "部署阶段无单位");
    // 1) 放置：出发区域内
    let pos = hex::axial_from_offset(2, 4); // 玩家左侧 4 列内
    let label = g.deploy_unit(Team::Player, UnitKind::Tank, pos).unwrap();
    assert_eq!(label, '1', "第一个单位标签为数字 1（双方统一数字编号）");
    assert_eq!(g.recruit_points[&Team::Player], 100 - 24, "坦克费用 24");
    // 2) 放区域外 → 拒绝
    let err = g
        .deploy_unit(Team::Player, UnitKind::Tank, hex::axial_from_offset(6, 4))
        .unwrap_err();
    assert!(err.contains("出发区域"), "区域外部署被拒: {}", err);
    // 3) 已有单位格 → 拒绝
    let err2 = g
        .deploy_unit(Team::Player, UnitKind::Tank, pos)
        .unwrap_err();
    assert!(err2.contains("已有单位"), "{}", err2);
    // 4) 岩石上部署地面单位 → 拒绝；直升机可放
    let rock = hex::axial_from_offset(2, 6); // 默认地图岩石
    let err3 = g
        .deploy_unit(Team::Player, UnitKind::Tank, rock)
        .unwrap_err();
    assert!(err3.contains("岩石"), "{}", err3);
    assert!(
        g.deploy_unit(Team::Player, UnitKind::AttackHeli, rock).is_ok(),
        "直升机可部署在岩石上"
    );
    // 5) 车辆进楼房 → 拒绝；步兵可进
    let bld = hex::axial_from_offset(1, 2); // 找一栋在左侧出发区域的楼房
    if g.map.buildings.contains(&bld) {
        assert!(g.deploy_unit(Team::Player, UnitKind::Tank, bld).is_err());
        assert!(g.deploy_unit(Team::Player, UnitKind::Rifleman, bld).is_ok());
    }
    // 6) 点数不足 → 拒绝
    g.recruit_points.insert(Team::Player, 5);
    let err4 = g
        .deploy_unit(Team::Player, UnitKind::Tank, hex::axial_from_offset(3, 0))
        .unwrap_err();
    assert!(err4.contains("点数不足"), "{}", err4);
    g.recruit_points.insert(Team::Player, 100);
    // 7) 撤销返还点数（当前点数 100 + 已部署坦克费用 24 = 124）
    let back = g.undeploy_unit(Team::Player, pos).unwrap();
    assert_eq!(back, 24, "撤销返还费用");
    assert_eq!(g.recruit_points[&Team::Player], 124, "撤销后点数=当前+费用");
    // 8) finish_deploy：AI 自动部署，进入第 1 回合玩家行动
    let ai_log = g.finish_deploy().unwrap();
    assert!(!g.deploying, "部署结束");
    assert!(!ai_log.is_empty(), "AI 部署有日志");
    let ai_units = g.units_of(Team::Ai);
    assert!(
        (5..=12).contains(&ai_units.len()),
        "AI 单位数 5-12（武直费用 24 后下限放宽；实际 {}）",
        ai_units.len()
    );
    for u in &ai_units {
        let (col, _) = hex::offset_from_axial(u.pos);
        assert!(col >= g.map.cols - 4, "AI 单位在右侧出发区域: {}", col);
    }
    assert_eq!(g.phase, Team::Player, "部署后轮到玩家");
}

/// 招募设定：部署阶段可一次性购入「已装载」的运输单位，
/// 按「载具 + 货物」总费用扣点，撤销时全额返还；非法组合被拒绝。
#[test]
fn test_deploy_loaded_transport() {
    let mut g = GameState::new_deploy(88);
    let pos = hex::axial_from_offset(2, 4);
    let cargo = vec![UnitKind::Rifleman, UnitKind::Rifleman, UnitKind::Rifleman];
    let label = g
        .deploy_unit_with_cargo(Team::Player, UnitKind::Truck, pos, &cargo)
        .expect("可部署已装载卡车");
    assert_eq!(label, '1', "第一个单位标签为数字 1");
    let truck = g.unit_at(pos).unwrap();
    assert_eq!(truck.passengers.len(), 3, "3 名步枪手随车部署");
    assert_eq!(truck.used_weight(), 9);
    assert_eq!(
        g.recruit_points[&Team::Player],
        100 - 44,
        "总费用 = 卡车 8 + 3×12"
    );
    // 撤销返还总费用
    let refund = g.undeploy_unit(Team::Player, pos).unwrap();
    assert_eq!(refund, 44, "撤销含货物全额返还");
    assert_eq!(g.recruit_points[&Team::Player], 100);

    // 超载 → 拒绝
    let over = vec![
        UnitKind::Rifleman,
        UnitKind::Rifleman,
        UnitKind::Rifleman,
        UnitKind::Rifleman,
    ];
    assert!(
        g.deploy_unit_with_cargo(Team::Player, UnitKind::Truck, pos, &over)
            .is_err(),
        "超载应拒绝"
    );
    // 类型不允许（卡车载悍马）→ 拒绝
    assert!(
        g.deploy_unit_with_cargo(Team::Player, UnitKind::Truck, pos, &[UnitKind::HumveeHmg])
            .is_err(),
        "卡车不可载悍马"
    );
    // 非运输单位带货物 → 拒绝
    assert!(
        g.deploy_unit_with_cargo(Team::Player, UnitKind::Tank, pos, &[UnitKind::Rifleman])
            .is_err(),
        "坦克不能带货物"
    );
    // 重直可一次性载入悍马 + 特战（新规则）
    let heli_pos = hex::axial_from_offset(3, 4);
    g.deploy_unit_with_cargo(
        Team::Player,
        UnitKind::HeavyTransportHeli,
        heli_pos,
        &[UnitKind::HumveeHmg, UnitKind::SpecialForces],
    )
    .expect("重直可载悍马 + 特战");
    assert_eq!(g.unit_at(heli_pos).unwrap().used_weight(), 8);
}

/// 追加部署 / 首回合招募同样可一次性购入已装载的运输单位。
#[test]
fn test_recruit_loaded_transport_in_sustain() {
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.enable_sustain(20, 20);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    g.recruit_points.insert(Team::Player, 100);
    g.recruit_points.insert(Team::Ai, 100);
    g.keypoints.insert(
        hex::axial_from_offset(1, 2),
        Keypoint {
            owner: Team::Player,
            controller: Team::Player,
            center: true,
        },
    );
    g.sustain_deploying = true;
    let pos = hex::axial_from_offset(1, 3);
    // 重直 20 + 补给 15 + 步兵 12 = 47
    let label = g
        .reinforce_unit_with_cargo(
            Team::Player,
            UnitKind::HeavyTransportHeli,
            pos,
            &[UnitKind::Supply, UnitKind::Rifleman],
        )
        .expect("追加部署可携带初始搭载");
    assert_eq!(g.unit_at(pos).unwrap().label, label);
    assert_eq!(g.unit_at(pos).unwrap().passengers.len(), 2);
    assert_eq!(g.unit_at(pos).unwrap().actions_left, 0, "增援本回合不可行动");
    assert_eq!(
        g.recruit_points[&Team::Player],
        100 - 47,
        "重直 20 + 补给 15 + 步枪手 12"
    );
    // 点数不足整组 → 拒绝，且不扣点
    g.recruit_points.insert(Team::Player, 10);
    assert!(
        g.reinforce_unit_now_with_cargo(
            Team::Player,
            UnitKind::Truck,
            hex::axial_from_offset(2, 3),
            &[UnitKind::Rifleman]
        )
        .is_err(),
        "点数不足应拒绝"
    );
    assert_eq!(g.recruit_points[&Team::Player], 10, "失败不扣点");
}

#[test]
fn test_ai_deploy_randomness() {
    // 不同种子 AI 部署单位序列应不同（允许极小概率相同）
    let mut g1 = GameState::new_deploy(101);
    g1.finish_deploy().unwrap();
    let s1: Vec<String> = g1
        .units_of(Team::Ai)
        .iter()
        .map(|u| u.kind.name().to_string())
        .collect();
    let mut g2 = GameState::new_deploy(202);
    g2.finish_deploy().unwrap();
    let s2: Vec<String> = g2
        .units_of(Team::Ai)
        .iter()
        .map(|u| u.kind.name().to_string())
        .collect();
    assert_ne!(s1, s2, "不同种子 AI 阵容应有差异");
    // AI 与玩家相同规则：单位都在右侧出发区域、点数不超
    let spent: i32 = g1
        .units_of(Team::Ai)
        .iter()
        .map(|u| u.kind.recruit_cost())
        .sum();
    assert!(spent <= 100, "AI 招募不超预算: {}", spent);
}

#[test]
fn test_undeploy_during_deploy_does_not_win() {
    // 回归：部署阶段撤销单位不应触发胜负判定（对方尚未部署）
    let mut g = GameState::new_deploy(81);
    let pos = hex::axial_from_offset(2, 4);
    let _ = g.deploy_unit(Team::Player, UnitKind::Tank, pos).unwrap();
    // 撤销（模拟玩家调整部署位置）
    let _ = g.undeploy_unit(Team::Player, pos).unwrap();
    assert_eq!(g.winner, None, "部署阶段撤销不判胜");
    assert!(!g.game_over(), "部署阶段不结束对局");
    // 重新部署并开战 → 双方都有单位，无胜利
    let _ = g.deploy_unit(Team::Player, UnitKind::Tank, pos).unwrap();
    g.finish_deploy().unwrap();
    assert_eq!(g.winner, None, "开战后无胜利");
    assert!(g.team_alive(Team::Ai) && g.team_alive(Team::Player));
    // 玩家结束第一回合 → 不应弹出胜利
    g.begin_turn(Team::Ai);
    let _ = ai::take_turn(&mut g, Team::Ai);
    assert_eq!(g.winner, None, "第一回合结束不应立即胜利");
    assert!(g.team_alive(Team::Ai), "AI 单位仍在场");
}

/// 撤退：仅本方出发区域内可用；按「招募费用 × 当前HP/总HP」返还（含搭载单位）；
/// 不算被歼灭、不触发全灭判负。
#[test]
fn retreat_unit_refunds_by_hp_ratio() {
    let mut g = GameState::new_seeded(7);
    g.units.clear();
    g.air_units.clear();
    g.deploying = false;
    g.winner = None;
    g.recruit_points.insert(Team::Player, 0);
    // 出发区内满血单位 → 全额返还
    let h1 = hex::axial_from_offset(1, 6);
    g.map.obstacles.remove(&h1);
    g.units
        .insert(h1, Unit::new(UnitKind::Rifleman, Team::Player, h1));
    assert!(g.can_retreat(Team::Player, h1));
    let r1 = g.retreat_unit(Team::Player, h1).unwrap();
    assert_eq!(r1, UnitKind::Rifleman.recruit_cost(), "满血应全额返还");
    assert!(g.unit_at(h1).is_none(), "撤退后单位立即消失");
    assert_eq!(g.recruit_points[&Team::Player], r1);
    // 半血单位 → 按血量比例返还（四舍五入）
    let h2 = hex::axial_from_offset(2, 6);
    g.map.obstacles.remove(&h2);
    let mut tank = Unit::new(UnitKind::Tank, Team::Player, h2);
    tank.hp = (UnitKind::Tank.max_hp() + 1) / 2;
    let expect2 = (UnitKind::Tank.recruit_cost() * tank.hp + UnitKind::Tank.max_hp() / 2)
        / UnitKind::Tank.max_hp();
    g.units.insert(h2, tank);
    assert_eq!(g.retreat_unit(Team::Player, h2).unwrap(), expect2);
    // 搭载单位一并折算返还
    let h3 = hex::axial_from_offset(3, 6);
    g.map.obstacles.remove(&h3);
    let mut truck = Unit::new(UnitKind::Truck, Team::Player, h3);
    truck
        .passengers
        .push(Unit::new(UnitKind::Rifleman, Team::Player, h3));
    let expect3 = UnitKind::Truck.recruit_cost() + UnitKind::Rifleman.recruit_cost();
    g.units.insert(h3, truck);
    assert_eq!(g.retreat_unit(Team::Player, h3).unwrap(), expect3);
    // 出发区外：不可撤退
    let out = hex::axial_from_offset(12, 6);
    g.map.obstacles.remove(&out);
    g.units
        .insert(out, Unit::new(UnitKind::Rifleman, Team::Player, out));
    assert!(!g.can_retreat(Team::Player, out));
    assert!(g.retreat_unit(Team::Player, out).is_err());
    // 对方单位不可撤退
    let foe = hex::axial_from_offset(1, 7);
    g.map.obstacles.remove(&foe);
    g.units
        .insert(foe, Unit::new(UnitKind::Rifleman, Team::Ai, foe));
    assert!(!g.can_retreat(Team::Player, foe));
    assert!(g.retreat_unit(Team::Player, foe).is_err());
    // 撤退不计入被歼灭点数，也不触发全灭判负
    assert_eq!(g.killed_value.get(&Team::Player).copied().unwrap_or(0), 0);
    assert!(g.winner.is_none());
}

/// 撤退时，装载在运输载具（卡车 / 直升机等）内的单位必须一并消失，
/// 且每一件货物都按其**自身** HP 比例折算返还，而不是沿用载具的比例。
#[test]
fn retreat_refunds_loaded_passengers_by_their_own_hp() {
    let mut g = GameState::new_seeded(7);
    g.units.clear();
    g.air_units.clear();
    g.deploying = false;
    g.winner = None;
    g.recruit_points.insert(Team::Player, 0);

    fn refund_of(kind: UnitKind, hp: i32) -> i32 {
        let max_hp = kind.max_hp().max(1);
        (kind.recruit_cost() * hp.clamp(0, max_hp) + max_hp / 2) / max_hp
    }

    // 卡车血量上限只有 1（不存在“半血”），撤退即全额返还车体点数；
    // 但车内步兵仍按自身 HP 单独折算。
    let h0 = hex::axial_from_offset(0, 6);
    g.map.obstacles.remove(&h0);
    assert_eq!(UnitKind::Truck.max_hp(), 1, "卡车血量上限为 1");
    let mut truck = Unit::new(UnitKind::Truck, Team::Player, h0);
    let mut wounded_rider = Unit::new(UnitKind::Rifleman, Team::Player, h0);
    wounded_rider.hp = 2; // 步枪手满血 3 → 2/3 血
    truck.passengers.push(wounded_rider);
    g.units.insert(h0, truck);
    assert_eq!(
        g.retreat_unit(Team::Player, h0).unwrap(),
        UnitKind::Truck.recruit_cost() + refund_of(UnitKind::Rifleman, 2),
        "卡车全额 + 车内步兵按 2/3 血折算"
    );
    assert!(g.unit_at(h0).is_none(), "撤退后卡车连同车内步兵一起消失");

    // 血量上限 2 的步兵战车（IFV）才可能出现“半血”：载具与乘客各自按自身 HP 折算。
    let h1 = hex::axial_from_offset(1, 6);
    g.map.obstacles.remove(&h1);
    assert_eq!(UnitKind::Ifv.max_hp(), 2, "步兵战车血量上限为 2");
    let mut ifv = Unit::new(UnitKind::Ifv, Team::Player, h1);
    ifv.hp = 1; // 半血
    let mut rider = Unit::new(UnitKind::Rifleman, Team::Player, h1);
    rider.hp = 1; // 步枪手 1/3 血
    let expect_ifv = refund_of(UnitKind::Ifv, 1);
    let expect_rider = refund_of(UnitKind::Rifleman, 1);
    ifv.passengers.push(rider);
    g.units.insert(h1, ifv);
    let points_before_ifv = g.recruit_points[&Team::Player];
    assert_eq!(
        g.retreat_unit(Team::Player, h1).unwrap(),
        expect_ifv + expect_rider,
        "半血 IFV 与车内步兵应分别按各自 HP 折算"
    );
    assert!(g.unit_at(h1).is_none(), "撤退后 IFV 连同车内步兵一起消失");
    assert_eq!(
        g.recruit_points[&Team::Player] - points_before_ifv,
        expect_ifv + expect_rider,
        "本次撤退净增招募点应等于 IFV + 车内步兵的折算值"
    );

    // 运输直升机（空中层）+ 机舱内步兵：同样一并消失并折算。
    let h2 = hex::axial_from_offset(2, 6);
    g.map.obstacles.remove(&h2);
    let mut heli = Unit::new(UnitKind::TransportHeli, Team::Player, h2);
    heli.passengers
        .push(Unit::new(UnitKind::SpecialForces, Team::Player, h2));
    let expect_heli =
        UnitKind::TransportHeli.recruit_cost() + UnitKind::SpecialForces.recruit_cost();
    g.air_units.insert(h2, heli);
    assert_eq!(g.retreat_unit(Team::Player, h2).unwrap(), expect_heli);
    assert!(g.air_units.get(&h2).is_none(), "空中层的直升机应被移除");
    assert!(g.unit_at(h2).is_none(), "机舱内步兵应随直升机一起消失");
}

/// AI 火炮不应轰击直升机：间瞄火力打不到空中单位，向直升机开炮等于空放。
#[test]
fn ai_artillery_ignores_helicopters() {
    let mut g = GameState::new_seeded(31);
    g.units.clear();
    g.air_units.clear();
    g.deploying = false;
    g.winner = None;
    let hh = hex::axial_from_offset(10, 6);
    let dh = hex::axial_from_offset(11, 6);
    let ph = hex::axial_from_offset(16, 6);
    for h in [hh, dh, ph] {
        g.map.obstacles.remove(&h);
        g.map.buildings.remove(&h);
        g.map.forests.remove(&h);
        g.map.water.remove(&h);
    }
    let mut how = Unit::new(UnitKind::Howitzer, Team::Ai, hh);
    how.deployed = true;
    g.units.insert(hh, how);
    // 侦察无人机提供视野，确保直升机被 AI 看到（否则测试会退化为"看不见"）
    g.air_units
        .insert(dh, Unit::new(UnitKind::Drone, Team::Ai, dh));
    g.air_units
        .insert(ph, Unit::new(UnitKind::AttackHeli, Team::Player, ph));
    g.phase = Team::Ai;
    let log = ai::take_turn(&mut g, Team::Ai);
    assert!(
        !log.iter().any(|l| l.contains("炮击")),
        "间瞄火力不应轰击直升机（应保留炮弹）: {:?}",
        log
    );
}

#[test]
fn test_event_log_records_and_replays() {
    // 1) 事件记录：部署/移动/攻击都在日志中
    let mut g = GameState::new_deploy(91);
    let p1 = hex::axial_from_offset(2, 4);
    let p2 = hex::axial_from_offset(1, 5);
    g.deploy_unit(Team::Player, UnitKind::Tank, p1).unwrap();
    g.deploy_unit(Team::Player, UnitKind::Rifleman, p2).unwrap();
    g.finish_deploy().unwrap();
    // 移动坦克
    let path = vec![p1, hex::axial_from_offset(3, 4)];
    g.move_unit(p1, &path, false).unwrap();
    let log = g.event_log.clone();
    assert!(
        log.iter().any(|l| l.contains("部署") && l.contains("玩家") && l.contains(" 1 ")),
        "部署事件缺失: {:?}",
        log
    );
    assert!(
        log.iter().any(|l| l.contains("移动") && l.contains("→")),
        "移动事件缺失: {:?}",
        log
    );
    assert!(log.iter().any(|l| l.contains("部署完成")), "{:?}", log);
    assert!(log.iter().any(|l| l.contains("回合")), "回合标记缺失: {:?}", log);

    // 2) 可复现性：相同种子 + 相同操作 → 相同事件序列
    let replay = || {
        let mut g2 = GameState::new_deploy(91);
        g2.deploy_unit(Team::Player, UnitKind::Tank, p1).unwrap();
        g2.deploy_unit(Team::Player, UnitKind::Rifleman, p2).unwrap();
        g2.finish_deploy().unwrap();
        let path2 = vec![p1, hex::axial_from_offset(3, 4)];
        g2.move_unit(p1, &path2, false).unwrap();
        g2.event_log.clone()
    };
    assert_eq!(replay(), log, "相同种子+操作应产生相同事件序列");
}

#[test]
fn test_truck_loads_howitzer() {
    let mut g = GameState::new_seeded(70);
    g.units.clear();
    g.air_units.clear();
    let e_h = hex::axial_from_offset(2, 3);
    let f_h = hex::axial_from_offset(1, 3); // 紧邻 E
    let b_h = hex::axial_from_offset(3, 3); // 紧邻 E 另一侧
    g.spawn(UnitKind::Truck, Team::Player, e_h, 'E');
    g.spawn(UnitKind::Howitzer, Team::Player, f_h, 'F');
    g.spawn(UnitKind::Rifleman, Team::Player, b_h, 'B');
    g.begin_turn(Team::Player);
    // 榴弹炮装卡车：5 重量
    assert!(g.board(e_h, f_h).is_ok(), "卡车应能装载榴弹炮");
    assert_eq!(g.unit_at(e_h).unwrap().used_weight(), 5, "榴弹炮 5 重量");
    assert!(g.unit_at(f_h).is_none(), "榴弹炮已上车");
    // 卡车还剩 4 载重：可再装 1 名步兵（3 重量）
    assert!(g.board(e_h, b_h).is_ok(), "剩余载重可装步兵");
    assert_eq!(g.unit_at(e_h).unwrap().used_weight(), 8, "榴弹炮 5 + 步兵 3");
    // 再放一个榴弹炮尝试 → 5 + 8 > 9 超载拒绝
    let g2_h = hex::axial_from_offset(1, 2);
    g.spawn(UnitKind::Howitzer, Team::Player, g2_h, 'G');
    g.unit_at_mut(e_h).unwrap().actions_left = 1;
    let err = g.board(e_h, g2_h).unwrap_err();
    assert!(err.contains("载重"), "超载应拒绝: {}", err);
    // 放下榴弹炮
    assert!(g.disembark(e_h, 'F', hex::axial_from_offset(1, 3)).is_ok());
    assert!(g.unit_at(hex::axial_from_offset(1, 3)).is_some(), "榴弹炮已下车");
}

#[test]
fn test_howitzer_aim_and_fire() {
    let mut g = GameState::new_seeded(72);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let f_h = hex::axial_from_offset(0, 0);
    g.spawn(UnitKind::Howitzer, Team::Player, f_h, 'F');
    g.spawn(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(3, 3), '2');
    g.begin_turn(Team::Player);
    // 未架设不能开火
    let err = g.attack(f_h, hex::axial_from_offset(3, 3)).unwrap_err();
    assert!(err.contains("架设"), "未架设被拒: {}", err);
    // 架设消耗行动
    assert!(g.deploy(f_h).is_ok());
    assert_eq!(g.unit_at(f_h).unwrap().actions_left, 0);
    assert!(g.unit_at(f_h).unwrap().deployed);
    // 本回合无法再射；下一回合架设保留，可直接射击
    let err2 = g.attack(f_h, hex::axial_from_offset(3, 3)).unwrap_err();
    assert!(err2.contains("行动次数不足"), "架设后本回合行动耗尽: {}", err2);
    g.begin_turn(Team::Player);
    assert!(g.unit_at(f_h).unwrap().deployed, "架设状态跨回合保留");
    assert!(g.attack(f_h, hex::axial_from_offset(3, 3)).is_ok(), "架设后可连续射击");
    // 装车后需重新架设
    let e_h = hex::axial_from_offset(1, 0);
    g.spawn(UnitKind::Truck, Team::Player, e_h, 'E');
    g.begin_turn(Team::Player);
    g.deploy(f_h).unwrap();
    g.begin_turn(Team::Player);
    assert!(g.board(e_h, f_h).is_ok(), "榴弹炮装车");
    assert!(!g.unit_at(e_h).unwrap().passengers[0].deployed, "装车后重置架设");
}

#[test]
fn test_hmg_gunner_deploy_and_humvee_hmg_no_deploy() {
    // —— 重机枪手：攻击耗 1 行动，但每移动到一个位置后需先架设 ——
    let mut g = GameState::new_seeded(303);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    g.begin_turn(Team::Player);
    let hmg = hex::axial_from_offset(2, 5);
    let foe = hex::axial_from_offset(4, 5);
    g.spawn(UnitKind::HmgGunner, Team::Player, hmg, 'H');
    g.spawn(UnitKind::Rifleman, Team::Ai, foe, '1');
    // 未架设不能开火
    let err = g.attack(hmg, foe).unwrap_err();
    assert!(err.contains("架设"), "未架设应被拒: {}", err);
    // 架设消耗 1 次行动（重机枪手每回合 2 次）
    assert!(g.deploy(hmg).is_ok());
    assert!(g.unit_at(hmg).unwrap().deployed);
    assert_eq!(g.unit_at(hmg).unwrap().actions_left, 1, "架设消耗 1 行动");
    // 架设后同一回合即可开火；攻击只耗 1 行动
    assert!(g.attack(hmg, foe).is_ok(), "架设后同回合可开火");
    assert_eq!(g.unit_at(hmg).unwrap().actions_left, 0, "攻击耗 1 行动");
    // 已架设时重复架设幂等、不消耗行动
    g.unit_at_mut(hmg).unwrap().actions_left = 1;
    assert!(g.deploy(hmg).is_ok());
    assert_eq!(
        g.unit_at(hmg).unwrap().actions_left,
        1,
        "已架设重复架设不耗行动"
    );
    // 移动后架设状态失效，需重新架设
    g.unit_at_mut(hmg).unwrap().actions_left = 2;
    let dest = hex::axial_from_offset(2, 6);
    assert!(g.move_unit(hmg, &[hmg, dest], false).is_ok());
    assert!(!g.unit_at(dest).unwrap().deployed, "移动后架设状态失效");
    assert!(
        g.attack(dest, foe).unwrap_err().contains("架设"),
        "移动后未架设不能开火"
    );

    // —— 悍马-重机枪：攻击耗 1 行动，且无需架设 ——
    let mut g2 = GameState::new_seeded(304);
    g2.map.obstacles.clear();
    g2.map.forests.clear();
    g2.map.buildings.clear();
    g2.units.clear();
    g2.air_units.clear();
    g2.begin_turn(Team::Player);
    let hv = hex::axial_from_offset(2, 5);
    let foe2 = hex::axial_from_offset(4, 5);
    g2.spawn(UnitKind::HumveeHmg, Team::Player, hv, 'V');
    g2.spawn(UnitKind::Rifleman, Team::Ai, foe2, '1');
    assert!(!g2.unit_at(hv).unwrap().deployed, "悍马-重机枪初始未架设");
    assert!(g2.deploy(hv).is_err(), "悍马-重机枪不需要架设");
    assert!(g2.attack(hv, foe2).is_ok(), "悍马-重机枪无需架设即可开火");
    assert_eq!(
        g2.unit_at(hv).unwrap().actions_left,
        1,
        "悍马-重机枪攻击耗 1 行动"
    );
    assert!(g2.attack(hv, foe2).is_ok(), "悍马-重机枪每回合可攻击 2 次");
    assert_eq!(g2.unit_at(hv).unwrap().actions_left, 0, "两次攻击耗尽行动");
}

#[test]
fn test_armor_deflect_when_attack_equals_armor() {
    // 攻击力 == 目标护甲：命中后 50% 概率被护甲抵挡（命中但不掉血）
    let mut blocked = 0;
    let mut damaged = 0;
    for seed in 0..400u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let a = hex::axial_from_offset(0, 0);
        let d = hex::axial_from_offset(2, 0);
        // 侦察战车（攻 2）vs 自行迫击炮（护甲 2）
        let mut scout = Unit::new(UnitKind::Scout, Team::Player, a);
        scout.hp = 9; // 防止被反击
        g.units.insert(a, scout);
        let mut target = Unit::new(UnitKind::Mortar, Team::Ai, d);
        target.hp = 5; // 便于观察是否掉血
        target.ammo = 0; // 不反击
        g.units.insert(d, target);
        let out = g.attack(a, d).unwrap();
        if !out.hit {
            continue;
        }
        let hp1 = g.unit_at(d).map(|u| u.hp).unwrap_or(0);
        if out.message.contains("被护甲抵挡") {
            blocked += 1;
            assert_eq!(hp1, 5, "抵挡不应掉血: {}", out.message);
        } else if out.message.contains("造成") {
            damaged += 1;
            assert!(hp1 < 5, "造成伤害应掉血: {}", out.message);
        }
    }
    assert!(
        blocked > 0 && damaged > 0,
        "攻==护 应同时出现抵挡与伤害 (blocked={blocked}, damaged={damaged})"
    );

    // 攻 != 护 时永不触发护甲抵挡
    let mut g = GameState::new_seeded(1);
    assert!(!g.armor_deflects(4, 3), "攻 > 护 不抵挡");
    assert!(!g.armor_deflects(1, 0), "攻 > 护（护甲 0）不抵挡");
    assert!(!g.armor_deflects(2, 3), "攻 < 护 不涉及抵挡");
}

#[test]
fn test_active_defense_resolves_before_armor_deflect() {
    // 攻 == 护 且目标有主动防御：先判主动防御（消耗 1 次、不掉血），不进入护甲抵挡
    let mut g = GameState::new_seeded(55);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    g.begin_turn(Team::Player);
    let a = hex::axial_from_offset(0, 0);
    let d = hex::axial_from_offset(2, 0);
    let mut scout = Unit::new(UnitKind::Scout, Team::Player, a);
    scout.hp = 9;
    g.units.insert(a, scout);
    let mut cav = Unit::new(UnitKind::CavalryIfv, Team::Ai, d); // 护甲 2、主动防御
    cav.ad_uses = 1;
    cav.hp = 5;
    cav.ammo = 0;
    g.units.insert(d, cav);
    for _ in 0..80 {
        if let Some(u) = g.unit_at_mut(a) {
            u.actions_left = 2;
            u.ammo = 99;
        }
        let out = g.attack(a, d).unwrap();
        if out.message.contains("主动防御") {
            assert_eq!(g.unit_at(d).unwrap().ad_uses, 0, "主动防御被消耗");
            assert_eq!(g.unit_at(d).unwrap().hp, 5, "主动防御抵消，不掉血");
            assert!(
                !out.message.contains("被护甲抵挡"),
                "主动防御优先于护甲抵挡: {}",
                out.message
            );
            return;
        }
    }
    panic!("应出现主动防御触发");
}

#[test]
fn test_cook_off_probabilities() {
    // 殉爆概率按目标防护：主战坦克 30%、一般坦克 60%、步战/骑兵战车 60%、
    // 其它护甲2车辆 70%、护甲1车辆 80%；非车辆（步兵/空中）为 0。
    assert_eq!(UnitKind::HeavyTank.cook_off_chance(), 30, "主战坦克殉爆 30%");
    assert_eq!(UnitKind::Tank.cook_off_chance(), 60, "一般坦克殉爆 60%");
    assert_eq!(UnitKind::Ifv.cook_off_chance(), 60, "步战车殉爆 60%");
    assert_eq!(UnitKind::CavalryIfv.cook_off_chance(), 60, "装甲骑兵战车殉爆 60%");
    assert_eq!(UnitKind::Scout.cook_off_chance(), 70, "其它护甲2车辆 70%");
    assert_eq!(UnitKind::Mortar.cook_off_chance(), 70);
    assert_eq!(UnitKind::AaMgv.cook_off_chance(), 70);
    assert_eq!(UnitKind::HumveeHmg.cook_off_chance(), 80, "护甲1车辆 80%");
    assert_eq!(UnitKind::HumveeTow.cook_off_chance(), 80);
    assert_eq!(UnitKind::HumveeJavelin.cook_off_chance(), 80);
    assert_eq!(UnitKind::AaLauncher.cook_off_chance(), 80);
    assert_eq!(UnitKind::Truck.cook_off_chance(), 80);
    assert_eq!(UnitKind::Supply.cook_off_chance(), 80);
    // 非车辆不殉爆
    assert_eq!(UnitKind::Rifleman.cook_off_chance(), 0);
    assert_eq!(UnitKind::HmgGunner.cook_off_chance(), 0);
    assert_eq!(UnitKind::Howitzer.cook_off_chance(), 0, "榴弹炮护甲0不殉爆");
    assert_eq!(UnitKind::Headquarters.cook_off_chance(), 0, "指挥部按步兵判定");
    assert_eq!(UnitKind::AttackHeli.cook_off_chance(), 0, "空中单位不殉爆");
    assert_eq!(UnitKind::Drone.cook_off_chance(), 0);

    // 坦克炮打一般坦克：命中后约 60% 殉爆（2 点伤害，消息含「殉爆」）
    let mut cook = 0;
    let mut plain = 0;
    for seed in 0..300u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let a = hex::axial_from_offset(0, 0);
        let d = hex::axial_from_offset(2, 0);
        let mut atk = Unit::new(UnitKind::Tank, Team::Player, a);
        atk.hp = 9;
        g.units.insert(a, atk);
        let mut tgt = Unit::new(UnitKind::Tank, Team::Ai, d);
        tgt.hp = 99; // 防止击毁，便于统计
        tgt.ammo = 0;
        g.units.insert(d, tgt);
        let out = g.attack(a, d).unwrap();
        if out.message.contains("殉爆") {
            cook += 1;
        } else if out.message.contains("点伤害") {
            plain += 1;
        }
    }
    assert!(cook > 0 && plain > 0, "应同时出现殉爆与普通伤害");
    let ratio = cook as f64 / (cook + plain) as f64;
    assert!(
        (0.45..0.75).contains(&ratio),
        "一般坦克殉爆率应约 60%（实测 {:.2}，cook={cook} plain={plain}）",
        ratio
    );

    // 坦克炮打主战坦克：护甲抵挡之外，命中伤害中约 30% 殉爆
    let mut cook2 = 0;
    let mut dmg2 = 0;
    for seed in 0..600u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let a = hex::axial_from_offset(0, 0);
        let d = hex::axial_from_offset(2, 0);
        let mut atk = Unit::new(UnitKind::Tank, Team::Player, a);
        atk.hp = 9;
        g.units.insert(a, atk);
        let mut tgt = Unit::new(UnitKind::HeavyTank, Team::Ai, d);
        tgt.hp = 99;
        tgt.ammo = 0;
        tgt.ad_uses = 0; // 排除主动防御干扰
        g.units.insert(d, tgt);
        let out = g.attack(a, d).unwrap();
        if out.message.contains("殉爆") {
            cook2 += 1;
        }
        if out.message.contains("点伤害") {
            dmg2 += 1;
        }
    }
    assert!(dmg2 > 0, "主战坦克应至少有一次造成伤害");
    let ratio2 = cook2 as f64 / dmg2 as f64;
    assert!(
        (0.18..0.45).contains(&ratio2),
        "主战坦克殉爆率应约 30%（实测 {:.2}，cook={cook2} dmg={dmg2}）",
        ratio2
    );

    // 坦克炮打护甲1的悍马：护甲抵挡不发生，殉爆 80%（悍马 2 血，殉爆即击毁）
    let mut cook3 = 0;
    for seed in 0..200u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let a = hex::axial_from_offset(0, 0);
        let d = hex::axial_from_offset(2, 0);
        let mut atk = Unit::new(UnitKind::Tank, Team::Player, a);
        atk.hp = 9;
        g.units.insert(a, atk);
        let mut tgt = Unit::new(UnitKind::HumveeTow, Team::Ai, d); // 护甲 1、血量 2
        tgt.hp = 99; // 加厚血量，避免被直接击毁而看不到后续消息
        tgt.ammo = 0;
        g.units.insert(d, tgt);
        let out = g.attack(a, d).unwrap();
        if out.message.contains("殉爆") {
            cook3 += 1;
        }
    }
    assert!(cook3 > 0, "坦克炮对护甲1车辆应能触发殉爆");
}

#[test]
fn test_concealment_system() {
    // 新机制：发现条件 = BFS 路程 ≤ 视野/隐蔽值
    // 隐蔽值 1（装甲/车辆/直升机）→ 视野；隐蔽值 2（步兵）→ 视野/2（无条件，与地形无关）
    let mut g = GameState::new_seeded(74);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    // 坦克 T（视野 5）在 (2,3)
    let t_h = hex::axial_from_offset(2, 3);
    g.spawn(UnitKind::Tank, Team::Player, t_h, 'T');
    g.begin_turn(Team::Player);
    // 步兵（隐蔽 2）：距离 ≤ 5/2=2 可见
    let near = hex::axial_from_offset(3, 3); // BFS 1 ≤ 2
    let mid = hex::axial_from_offset(4, 3); // BFS 2 ≤ 2
    let far = hex::axial_from_offset(5, 3); // BFS 3 > 2
    g.spawn(UnitKind::Rifleman, Team::Ai, near, '1');
    g.spawn(UnitKind::Rifleman, Team::Ai, mid, '2');
    g.spawn(UnitKind::Rifleman, Team::Ai, far, '3');
    assert!(g.is_unit_visible(Team::Player, near), "步兵 1 步可见");
    assert!(g.is_unit_visible(Team::Player, mid), "步兵 2 步 = 5/2 恰好可见");
    assert!(!g.is_unit_visible(Team::Player, far), "步兵 3 步 > 5/2 → 不可见");
    // 坦克（隐蔽 1）：≤ 5 可见（距离 5 恰好可见）
    let tk = hex::axial_from_offset(7, 3);
    g.spawn(UnitKind::Tank, Team::Ai, tk, '4');
    assert!(g.is_unit_visible(Team::Player, tk), "坦克（隐蔽 1）5 步可见");
    // 森林只影响 BFS 路程：步兵进入森林后需要更近（路程翻倍）
    g.map.add_forest(4, 3);
    assert!(
        !g.is_unit_visible(Team::Player, mid),
        "森林中 BFS 1+2=3 步 > 2 → 步兵不可见"
    );
    // 地形始终可见（只是单位隐藏）
    assert!(g.is_revealed(Team::Player, far), "地形可见但单位隐藏");
    // 分层迷雾数据：每格有 (BFS 路程, 视野)
    let v = g.vision(Team::Player);
    assert!(v.dist.contains_key(&near), "分层迷雾应有 (路程,视野) 数据");
    let (d, vis) = v.dist[&far];
    assert!(d > vis / 2, "远格路程超过 视野/2（应盖浅灰雾）");
    let (d2, vis2) = v.dist[&near];
    assert!(d2 <= vis2 / 2, "近格路程 ≤ 视野/2（无雾）");
}

#[test]
fn test_smoke_system() {
    let mut g = GameState::new_seeded(80);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let f_h = hex::axial_from_offset(0, 0);
    g.spawn(UnitKind::Howitzer, Team::Player, f_h, 'F');
    let t_h = hex::axial_from_offset(5, 3); // 观察者坦克
    g.spawn(UnitKind::Tank, Team::Player, t_h, 'T');
    g.begin_turn(Team::Player);
    // 1) 未架设不能放烟
    let err = g.smoke_shot(f_h, hex::axial_from_offset(3, 3)).unwrap_err();
    assert!(err.contains("架设"), "{}", err);
    // 架设后放烟
    g.deploy(f_h).unwrap();
    g.begin_turn(Team::Player);
    let cells = g.smoke_shot(f_h, hex::axial_from_offset(3, 3)).unwrap();
    assert_eq!(cells.len(), 19, "半径2共19格: {}", cells.len());
    assert_eq!(g.smoke.len(), 19, "烟雾格数");
    assert_eq!(g.unit_at(f_h).unwrap().ammo, 23, "消耗1发炮弹");
    assert_eq!(g.unit_at(f_h).unwrap().actions_left, 0, "消耗1行动");

    // 2) 烟雾遮挡视野：T(5,3) 视野5 看 (7,3)——烟雾中心(3,3)不在这条线上，
    //    在 (5,3) 与 (8,3) 之间放烟雾 → (8,3) 不可见
    g.begin_turn(Team::Player);
    g.deploy(f_h).unwrap();
    g.begin_turn(Team::Player);
    g.smoke_shot(f_h, hex::axial_from_offset(6, 3)).unwrap(); // 烟雾覆盖 (6,3)
    let far = hex::axial_from_offset(8, 3);
    assert!(
        g.is_revealed(Team::Player, far) == false,
        "烟雾遮挡使 (8,3) 不可见（BFS 不可穿透烟雾）"
    );
    // 但烟雾格本身可见
    assert!(g.is_revealed(Team::Player, hex::axial_from_offset(6, 3)), "烟雾格可见");

    // 3) 烟雾不阻挡移动：把 T 移到 (8,3)（穿过 (6,3) 烟雾格）
    let path = vec![t_h, hex::axial_from_offset(6, 3), hex::axial_from_offset(7, 3), far];
    assert!(g.move_unit(t_h, &path, false).is_ok(), "可穿过烟雾移动");

    // 4) 遭遇：烟雾中放置敌方单位，移动单位穿过烟雾被挡在前方并发现敌人
    g.begin_turn(Team::Player);
    let t2 = g.unit_at(far).unwrap().clone();
    g.units.remove(&far);
    // 把 T 放回 (5,3)，在 (6,3) 烟雾中放敌方坦克 (6,4)
    let t_pos = hex::axial_from_offset(5, 3);
    g.units.insert(t_pos, t2);
    g.spawn(UnitKind::Tank, Team::Ai, hex::axial_from_offset(6, 3), '1'); // 敌人在烟雾中
    let path2 = vec![t_pos, hex::axial_from_offset(6, 3), hex::axial_from_offset(7, 3)];
    let r = g.move_unit(t_pos, &path2, false).unwrap();
    assert_eq!(r, t_pos, "被挡在敌人前方（原地）");
    assert!(
        g.is_unit_visible(Team::Player, hex::axial_from_offset(6, 3)),
        "遭遇后敌人进入视野"
    );
    assert!(g.unit_at(t_pos).unwrap().actions_left <= 1, "遭遇消耗1行动");

    // 5) 烟雾持续 2 回合后消散
    assert!(g.smoke.contains_key(&hex::axial_from_offset(6, 3)));
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // 第2回合末
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // 第3回合开始 → 烟雾应已消散（发射时2，衰减两次）
    assert!(!g.smoke.contains_key(&hex::axial_from_offset(6, 3)), "2回合后烟雾消散");
}

#[test]
fn test_village_defense_level() {
    let mut g = GameState::new_deploy_level(88, Level::VillageDefense);
    assert_eq!(g.level, Level::VillageDefense);
    assert_eq!(g.recruit_points[&Team::Player], 150, "玩家 150 点");
    assert_eq!(g.recruit_points[&Team::Ai], 300, "AI 300 点");
    // 地图结构：村庄有大量楼房、有道路、北面岩石、南/西森林、两条小道
    let buildings: Vec<Hex> = g.map.buildings.iter().copied().collect();
    assert!(buildings.len() >= 20, "村庄房屋众多: {}", buildings.len());
    // 纵向道路 col 21 / 24 无楼房
    assert!(!g.map.buildings.contains(&hex::axial_from_offset(21, 4)));
    assert!(!g.map.buildings.contains(&hex::axial_from_offset(24, 6)));
    // 横向道路 row 5 / 7 / 9 无楼房
    assert!(!g.map.buildings.contains(&hex::axial_from_offset(20, 5)));
    assert!(!g.map.buildings.contains(&hex::axial_from_offset(23, 7)));
    assert!(!g.map.buildings.contains(&hex::axial_from_offset(25, 9)));
    // 北面岩石（山）
    assert!(g.map.obstacles.contains(&hex::axial_from_offset(20, 0)));
    assert!(g.map.obstacles.contains(&hex::axial_from_offset(25, 1)));
    // 南面森林
    assert!(g.map.forests.contains(&hex::axial_from_offset(22, 10)));
    assert!(!g.map.forests.contains(&hex::axial_from_offset(22, 11)), "row11 小道");
    // 西面森林 + 两条林中小道（row 9 / row 11 无森林）
    assert!(g.map.forests.contains(&hex::axial_from_offset(10, 10)));
    assert!(!g.map.forests.contains(&hex::axial_from_offset(10, 9)), "小道 row9");
    assert!(!g.map.forests.contains(&hex::axial_from_offset(14, 11)), "小道 row11");
    // 玩家西边开阔地
    assert!(!g.map.obstacles.contains(&hex::axial_from_offset(3, 6)));
    assert!(!g.map.forests.contains(&hex::axial_from_offset(2, 5)));
    // 部署区域：玩家西边、AI 村庄
    assert!(g.deploy_zone(Team::Player).contains(&0));
    assert!(g.deploy_zone(Team::Ai).contains(&20));
    assert!(!g.deploy_zone(Team::Ai).contains(&10));
    // 车辆能通过村庄道路（纵向 col 21 无楼房/岩石）
    assert!(g.map.can_step_into(
        hex::axial_from_offset(21, 6),
        &g.units,
        Some(&Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(21, 5)))
    ));
    // AI 部署：都落在村庄区域
    g.finish_deploy().unwrap();
    let ai_units = g.units_of(Team::Ai);
    assert!(ai_units.len() >= 8, "AI 300 点防守兵力: {}", ai_units.len());
    for u in &ai_units {
        let (col, _) = hex::offset_from_axial(u.pos);
        assert!(col >= 19, "AI 部署在村庄区域: {}", col);
    }
}

#[test]
fn test_ai_defends_village() {
    // AI 在村庄关：不主动出击，步兵进楼房，单位留在村庄区域
    // （随机阵容，多 seed 中至少一个满足"步兵进楼"）
    let mut any_building = false;
    for seed in 0..6 {
        let mut g = GameState::new_deploy_level(seed, Level::VillageDefense);
        g.finish_deploy().unwrap();
        // 跑 3 个 AI 回合（玩家也跑，避免空转）
        for _ in 0..3 {
            g.begin_turn(Team::Player);
            ai::run_ai_turn(&mut g, Team::Player, &mut Vec::new());
            g.begin_turn(Team::Ai);
            ai::run_ai_turn(&mut g, Team::Ai, &mut Vec::new());
        }
        // AI 步兵应进入楼房
        let inf_in_building = g
            .units_of(Team::Ai)
            .iter()
            .filter(|u| u.kind.is_foot() && g.map.buildings.contains(&u.pos))
            .count();
        if inf_in_building >= 2 {
            any_building = true;
        }
        // 地面/防空等核心单位仍在村庄区域（空中/侦察战车前出侦察除外）
        for u in g.units_of(Team::Ai) {
            if u.kind.is_air() || u.kind == UnitKind::Scout {
                continue; // 侦察单位（直升机/无人机/侦察战车）前出为火炮开眼
            }
            let (col, _) = hex::offset_from_axial(u.pos);
            assert!(col >= 19, "AI 防守单位留守村庄: {} {} @{} seed={seed}", u.label, u.kind.name(), col);
        }
        // 车辆在村庄空地（非楼房）
        for u in g.units_of(Team::Ai) {
            if !u.kind.is_air() && !u.kind.is_foot() {
                assert!(!g.map.buildings.contains(&u.pos), "车辆不进楼房");
            }
        }
    }
    assert!(any_building, "6 个 seed 中应至少有一个 AI 有 ≥2 步兵进楼");
}

#[test]
fn test_killed_unit_no_ghost_persistence() {
    // 被击毁的单位位置必须进入 killed_hexes（界面据此清除幽灵标记），
    // 且其"迷雾开火标记"一并失效。
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    // 手动布阵：玩家坦克 (2,0) 打 AI 卡车 (3,0)（1 血，攻击力 4 > 护甲 1）
    g.units.insert(hex::axial_from_offset(2, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(2, 0)));
    g.units.insert(hex::axial_from_offset(3, 0), Unit::new(UnitKind::Truck, Team::Ai, hex::axial_from_offset(3, 0)));
    g.begin_turn(Team::Player);
    let target = hex::axial_from_offset(3, 0);
    let out = g.attack(hex::axial_from_offset(2, 0), target).unwrap();
    if !out.killed {
        // 90% 命中率下可能未命中：手动击毁以验证"击毁位置记录"逻辑
        g.remove_unit(target);
    }
    assert!(g.killed_hexes.contains(&target), "击毁位置应被记录: {:?}", g.killed_hexes);
    // 该单位若曾从迷雾开火留下标记，也应随阵亡被清除
    assert!(!g.fog_fire_marks.values().any(|m| m.contains_key(&target)));
}

#[test]
fn test_fog_fire_mark_recorded_and_pruned() {
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    // 侦察引导设置：玩家步兵 (6,0) 开眼看到 AI 步枪手 (7,0)；
    // 玩家坦克 (0,0) 射程 8 远距离开火（距离 7），AI 各单位都看不到它。
    g.units.insert(hex::axial_from_offset(6, 0), Unit::new(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(6, 0)));
    g.units.insert(hex::axial_from_offset(0, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(0, 0)));
    g.units.insert(hex::axial_from_offset(5, 0), Unit::new(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(5, 0)));
    g.units.insert(hex::axial_from_offset(24, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(24, 0)));
    g.begin_turn(Team::Player);
    let attacker = hex::axial_from_offset(0, 0);
    assert!(!g.is_unit_visible(Team::Ai, attacker), "AI 应看不到远距离开火的玩家坦克");
    g.attack(attacker, hex::axial_from_offset(5, 0)).unwrap();
    let marks = g.fog_fire_marks.get(&Team::Ai).expect("AI 应收到迷雾开火警告");
    assert!(marks.contains_key(&attacker), "开火位置被 AI 标记: {:?}", marks.keys().collect::<Vec<_>>());
    // AI 视野内没有开火者 → 标记保留
    g.prune_fog_fire_marks();
    assert!(g.fog_fire_marks.get(&Team::Ai).unwrap().contains_key(&attacker));
    // AI 坦克移到能看到玩家坦克的位置（距离 3 ≤ 视野 5）→ 标记失效
    g.units.remove(&hex::axial_from_offset(24, 0));
    g.units.insert(hex::axial_from_offset(3, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(3, 0)));
    g.prune_fog_fire_marks();
    assert!(
        !g.fog_fire_marks.get(&Team::Ai).unwrap().contains_key(&attacker),
        "AI 看到开火单位后标记应失效"
    );
}

#[test]
fn test_fog_fire_mark_expires() {
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    g.units.insert(hex::axial_from_offset(6, 0), Unit::new(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(6, 0)));
    g.units.insert(hex::axial_from_offset(0, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(0, 0)));
    g.units.insert(hex::axial_from_offset(5, 0), Unit::new(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(5, 0)));
    g.units.insert(hex::axial_from_offset(24, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(24, 0)));
    g.begin_turn(Team::Player);
    let attacker = hex::axial_from_offset(0, 0);
    g.attack(attacker, hex::axial_from_offset(5, 0)).unwrap();
    assert!(g.fog_fire_marks.get(&Team::Ai).unwrap().contains_key(&attacker));
    // 跑 1 个完整回合（标记记录回合 = 1，第 2 回合内仍在时效内）
    g.begin_turn(Team::Player);
    g.begin_turn(Team::Ai);
    g.prune_fog_fire_marks();
    assert!(
        g.fog_fire_marks.get(&Team::Ai).unwrap().contains_key(&attacker),
        "2 回合内迷雾开火标记应保留"
    );
    // 再跑 1 个回合（第 3 回合起过期）
    g.begin_turn(Team::Player);
    g.begin_turn(Team::Ai);
    g.prune_fog_fire_marks();
    assert!(
        !g.fog_fire_marks.get(&Team::Ai).unwrap().contains_key(&attacker),
        "2 回合后迷雾开火标记应过期"
    );
}

#[test]
fn test_ai_reacts_to_fog_fire() {
    // AI 收到迷雾开火警告后，会派单位朝警告点机动查探。
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    // row 0 无障碍带：玩家坦克 (4,0) 射程 6 打 AI 卡车 (9,0)（距离 5，
    // 玩家视野 5 看卡车（隐蔽 1）可见；AI 卡车视野 4 反看不到玩家坦克 → 迷雾开火标记）。
    // 开火后玩家坦克移动到 (1,0)（警告点留在 (4,0)）。
    let atk_pos = hex::axial_from_offset(4, 0);
    g.units.insert(atk_pos, Unit::new(UnitKind::Tank, Team::Player, atk_pos));
    let ai_truck = hex::axial_from_offset(9, 0);
    g.units.insert(ai_truck, Unit::new(UnitKind::Truck, Team::Ai, ai_truck));
    let ai_pos = hex::axial_from_offset(12, 0);
    g.units.insert(ai_pos, Unit::new(UnitKind::Tank, Team::Ai, ai_pos));
    g.begin_turn(Team::Player);
    assert!(!g.is_unit_visible(Team::Ai, atk_pos), "AI 应看不到玩家坦克");
    g.attack(atk_pos, ai_truck).unwrap();
    assert_eq!(*g.fog_fire_marks.get(&Team::Ai).unwrap().keys().next().unwrap(), atk_pos);
    // 玩家坦克移动离开（坦克行动 2：攻击后还能走 3 格）
    let tank = g.unit_at(atk_pos).unwrap().clone();
    let path = g
        .map
        .plan_move(&g.units, &g.air_units, atk_pos, hex::axial_from_offset(1, 0), 3, Some(tank), false);
    assert!(path.len() > 1, "应有移动路径: {:?}", path);
    g.move_unit(atk_pos, &path, false).unwrap();
    // 警告点在 (4,0)（原位置），玩家坦克现于 (1,0)——AI 两者都看不到
    let before = Hex::distance(ai_pos, atk_pos); // 8
    let mut log = Vec::new();
    g.begin_turn(Team::Ai);
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // AI 坦克应朝警告点 (4,0) 靠近（距离 < 8）
    let moved_tank = g
        .units_of(Team::Ai)
        .iter()
        .find(|u| u.kind == UnitKind::Tank && u.pos != ai_pos)
        .map(|u| u.pos)
        .unwrap_or(ai_pos);
    assert!(
        moved_tank != ai_pos,
        "AI 应移动查探迷雾开火点（日志: {:?}）",
        log
    );
    assert!(
        Hex::distance(moved_tank, atk_pos) < before,
        "AI 坦克应朝警告点靠近: 旧 {before} → 新 {}",
        Hex::distance(moved_tank, atk_pos)
    );
    assert!(
        log.iter().any(|l| l.contains("→") || l.contains("查探")),
        "AI 应有查探/移动日志: {:?}",
        log
    );
}

#[test]
fn test_ai_reacts_to_threat_direction() {
    // 村庄防守关：玩家从 (14,4) 方向在迷雾中开火（留下开火警告标记），
    // AI 应抽调机动单位前往村庄西缘威胁带（col 19-21, rows 1-7）阻击，
    // 同时保留核心防守力量（榴弹炮/防空/进楼步兵）不动。
    let mut g = GameState::new_deploy_level(7, Level::VillageDefense); // 空地图
    // AI 单位
    g.units.insert(hex::axial_from_offset(21, 6), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(21, 6)));
    g.units.insert(hex::axial_from_offset(24, 8), Unit::new(UnitKind::Ifv, Team::Ai, hex::axial_from_offset(24, 8)));
    g.units.insert(hex::axial_from_offset(25, 3), Unit::new(UnitKind::Howitzer, Team::Ai, hex::axial_from_offset(25, 3)));
    g.units.insert(hex::axial_from_offset(24, 6), Unit::new(UnitKind::AaLauncher, Team::Ai, hex::axial_from_offset(24, 6)));
    g.units.insert(hex::axial_from_offset(20, 4), Unit::new(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(20, 4))); // (20,4) 是楼房→进楼核心
    // 迷雾开火警告：玩家从 (14,4) 方向开火（威胁源不可击毁，威胁持续）
    g.fog_fire_marks
        .insert(Team::Ai, [(hex::axial_from_offset(14, 4), 1)].into_iter().collect());
    g.begin_turn(Team::Ai);
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // ① 有单位被调往村庄西缘威胁带（col 19-21, rows 1-7）阻击
    let in_zone = g
        .units_of(Team::Ai)
        .iter()
        .filter(|u| {
            let (c, r) = hex::offset_from_axial(u.pos);
            (19..=21).contains(&c) && (1..=7).contains(&r)
        })
        .count();
    assert!(in_zone >= 1, "AI 应调兵到威胁方向阻击: {:?}", log);
    // ② 核心单位（榴弹炮/防空/进楼步兵）留守村庄深处未出动
    assert!(g.units.contains_key(&hex::axial_from_offset(25, 3)), "榴弹炮留守");
    assert!(g.units.contains_key(&hex::axial_from_offset(24, 6)), "防空导弹车留守");
    assert!(g.units.contains_key(&hex::axial_from_offset(20, 4)), "进楼步兵留守");
    // ③ 阻击日志
    assert!(
        log.iter().any(|l| l.contains("阻击") || l.contains("调往")),
        "应有阻击日志: {:?}",
        log
    );
}

#[test]
fn test_ai_threat_direction_no_wholesale_sally() {
    // 只有部分兵力被调去阻击：核心（榴弹炮/防空/进楼步兵）不动，
    // 且调动名额受上限约束（最多 3 个）。
    let mut g = GameState::new_deploy_level(7, Level::VillageDefense);
    // 7 个可调动步兵（村庄空地）+ 3 个核心单位
    for row in [0, 1, 2, 3, 4, 5, 7] {
        let h = hex::axial_from_offset(24, row);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Ai, h));
    }
    g.units.insert(hex::axial_from_offset(25, 3), Unit::new(UnitKind::Howitzer, Team::Ai, hex::axial_from_offset(25, 3)));
    g.units.insert(hex::axial_from_offset(24, 6), Unit::new(UnitKind::AaLauncher, Team::Ai, hex::axial_from_offset(24, 6)));
    g.units.insert(hex::axial_from_offset(20, 4), Unit::new(UnitKind::Rifleman, Team::Ai, hex::axial_from_offset(20, 4))); // 楼内核心
    g.fog_fire_marks
        .insert(Team::Ai, [(hex::axial_from_offset(14, 4), 1)].into_iter().collect());
    g.begin_turn(Team::Ai);
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // 被调动的单位数 = "调往"日志条数，应 ≤ 3（预算上限）
    let sallied = log.iter().filter(|l| l.contains("调往")).count();
    assert!(sallied >= 1 && sallied <= 3, "抽调 1-3 个（实际 {}）: {:?}", sallied, log);
    // 核心单位全部未动
    assert!(g.units.contains_key(&hex::axial_from_offset(25, 3)));
    assert!(g.units.contains_key(&hex::axial_from_offset(24, 6)));
    assert!(g.units.contains_key(&hex::axial_from_offset(20, 4)));
}

#[test]
fn test_tank_and_howitzer_range_change() {
    assert_eq!(UnitKind::Tank.range(), 6, "坦克射程改为 6");
    assert_eq!(UnitKind::Howitzer.range(), 16, "榴弹炮射程改为 16");
    assert_eq!(UnitKind::Howitzer.hit_rate(), 80, "榴弹炮中心命中率 80%");
    assert_eq!(UnitKind::Howitzer.recruit_cost(), 16, "榴弹炮费用 16");
    assert_eq!(UnitKind::Howitzer.armor(), 0, "榴弹炮护甲改为 0");
    // 自行迫击炮
    assert_eq!(UnitKind::Mortar.name(), "自行迫击炮");
    assert_eq!(UnitKind::Mortar.armor(), 2);
    assert_eq!(UnitKind::Mortar.max_hp(), 1);
    assert_eq!(UnitKind::Mortar.attack(), 1);
    assert_eq!(UnitKind::Mortar.range(), 8);
    assert_eq!(UnitKind::Mortar.action_count(), 2);
    assert_eq!(UnitKind::Mortar.movement(), 3);
    assert_eq!(UnitKind::Mortar.hit_rate(), 60, "迫击炮中心命中率 60%");
    assert_eq!(UnitKind::Mortar.max_ammo(), 24);
    assert_eq!(UnitKind::Mortar.recruit_cost(), 10);
    assert!(!UnitKind::Mortar.is_air());
    assert!(UnitKind::Mortar.can_hit_ground());
    assert_eq!(UnitKind::HeavyTank.range(), 8, "主战坦克射程 8");
    assert_eq!(UnitKind::HeavyTank.hit_rate(), 100, "主战坦克命中率 100%");
    assert_eq!(UnitKind::HeavyTank.max_hp(), 2, "主战坦克血量 2");
    assert_eq!(UnitKind::HeavyTank.armor(), 4, "主战坦克护甲 4");
    assert_eq!(UnitKind::HeavyTank.attack(), 4, "主战坦克攻击 4");
    assert_eq!(UnitKind::HeavyTank.movement(), 3);
    assert_eq!(UnitKind::HeavyTank.vision(), 5);
    assert_eq!(UnitKind::HeavyTank.max_ammo(), 42);
    assert_eq!(UnitKind::HeavyTank.recruit_cost(), 32, "主战坦克费用 32");
}

#[test]
fn test_javelin_shooter() {
    // Javelin 射手：与 TOW 射手一致，但攻击只耗 1 行动、费用 12、射程 5
    assert_eq!(UnitKind::Javelin.name(), "Javelin射手");
    assert_eq!(UnitKind::Atgm.name(), "TOW射手");
    assert_eq!(UnitKind::Atgm.range(), 9, "TOW 射程 9");
    assert_eq!(UnitKind::Javelin.range(), 5, "Javelin 射程 5");
    assert_eq!(UnitKind::Javelin.armor(), UnitKind::Atgm.armor());
    assert_eq!(UnitKind::Atgm.attack(), 4, "TOW 攻击力 4");
    assert_eq!(UnitKind::Javelin.attack(), 5, "Javelin 攻击力 5（特别提升）");
    assert_eq!(UnitKind::Javelin.hit_rate(), UnitKind::Atgm.hit_rate());
    assert_eq!(UnitKind::Javelin.max_ammo(), UnitKind::Atgm.max_ammo());
    assert_eq!(UnitKind::Javelin.vision(), UnitKind::Atgm.vision());
    assert_eq!(UnitKind::Javelin.max_hp(), UnitKind::Atgm.max_hp());
    assert_eq!(UnitKind::Javelin.action_count(), UnitKind::Atgm.action_count());
    assert_eq!(UnitKind::Atgm.attack_cost(), 2, "TOW 攻击耗 2 行动");
    assert_eq!(UnitKind::Javelin.attack_cost(), 1, "Javelin 攻击耗 1 行动");
    assert_eq!(UnitKind::Javelin.recruit_cost(), 10, "Javelin 费用 10（调整后）");
    assert_eq!(UnitKind::Atgm.recruit_cost(), 8, "TOW 射手费用 8（调整后）");
    assert_eq!(UnitKind::Rifleman.recruit_cost(), 12, "步枪手费用 12（调整后）");
    assert!(UnitKind::Javelin.is_infantry(), "Javelin 是可搭载步兵");
    assert!(UnitKind::Javelin.is_foot(), "Javelin 可进楼房");
    // Javelin/TOW 只能打车辆：打步兵被拒
    assert!(UnitKind::Javelin.can_target(UnitKind::Tank), "Javelin 打坦克（车辆）");
    assert!(!UnitKind::Javelin.can_target(UnitKind::Rifleman), "Javelin 不能打步兵");
    assert!(!UnitKind::Atgm.can_target(UnitKind::Rifleman), "TOW 不能打步兵");
    assert!(UnitKind::Atgm.can_target(UnitKind::Truck), "TOW 打卡车（车辆）");
    // Javelin 一回合可开 2 枪（行动 2 ÷ 耗 1）
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    g.units.insert(hex::axial_from_offset(0, 0), Unit::new(UnitKind::Javelin, Team::Player, hex::axial_from_offset(0, 0)));
    g.units.insert(hex::axial_from_offset(2, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(2, 0)));
    g.begin_turn(Team::Player);
    let out1 = g.attack(hex::axial_from_offset(0, 0), hex::axial_from_offset(2, 0)).unwrap();
    assert!(out1.hit, "第一枪 90% 应命中");
    assert_eq!(g.unit_at(hex::axial_from_offset(0, 0)).unwrap().actions_left, 1, "Javelin 攻击耗 1 行动");
    let out2 = g.attack(hex::axial_from_offset(0, 0), hex::axial_from_offset(2, 0)).unwrap();
    assert_eq!(g.unit_at(hex::axial_from_offset(0, 0)).unwrap().actions_left, 0, "第二枪后行动耗尽");
    assert!(out2.hit && out2.killed, "两枪命中应击杀 2 血坦克: {:?}", out2.message);
}

#[test]
fn test_howitzer_no_los_into_village() {
    // 榴弹炮是间瞄火力：村庄防守战地图中，即使视线被村庄楼房挡住也能炮击
    let mut g = GameState::new_deploy_level(7, Level::VillageDefense); // 空村庄地图
    let how = hex::axial_from_offset(16, 7); // 村庄西缘（森林外）
    g.units.insert(how, Unit::new(UnitKind::Howitzer, Team::Player, how));
    g.begin_turn(Team::Player);
    g.deploy(how).unwrap();
    g.begin_turn(Team::Player);
    // 统计"射程内且视线被村庄楼房遮挡"的格子，逐一炮击
    let mut blocked_in_range = 0;
    let mut fired = 0;
    for col in 19..g.map.cols {
        for row in 0..g.map.rows {
            let center = hex::axial_from_offset(col, row);
            if center == how {
                continue;
            }
            if Hex::distance(how, center) > UnitKind::Howitzer.range() {
                continue;
            }
            if g.map.has_los(how, center) {
                continue; // 只看视线被挡的
            }
            blocked_in_range += 1;
            g.begin_turn(Team::Player); // 榴弹炮每回合 1 次行动：重置后再炮击（架设状态跨回合保留）
            let out = g.attack(how, center);
            assert!(
                out.is_ok(),
                "间瞄火力应无视楼房视线炮击 ({col},{row}): {:?}",
                out.err()
            );
            fired += 1;
            if fired >= 5 {
                break; // 验证 5 个格子即可（弹药 24 发足够）
            }
        }
    }
    assert!(
        blocked_in_range >= 3,
        "村庄内应存在多个视线被挡且射程内的格子: {}",
        blocked_in_range
    );
    assert!(fired >= 3, "应能炮击多个被楼房遮挡的格子: {}", fired);
    assert_eq!(UnitKind::Howitzer.range(), 16);
}

#[test]
fn test_heavy_tank_active_defense() {
    // 主战坦克主动防御：共 8 次；取消“回合首次命中”，同回合每次被命中都触发
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    let ht = hex::axial_from_offset(4, 0);
    let a1 = hex::axial_from_offset(0, 0);
    let a2 = hex::axial_from_offset(1, 1);
    g.units.insert(ht, Unit::new(UnitKind::HeavyTank, Team::Ai, ht));
    let mut c1 = Unit::new(UnitKind::CavalryIfv, Team::Player, a1);
    c1.missile_mode = true; // TOW 反坦克导弹：不属于坦克炮，仍会被主动防御抵消
    let mut c2 = Unit::new(UnitKind::CavalryIfv, Team::Player, a2);
    c2.missile_mode = true;
    g.units.insert(a1, c1);
    g.units.insert(a2, c2);
    g.begin_turn(Team::Player);
    // 玩家装甲骑兵战车用 TOW 攻击主战坦克（2 血）：第一发命中被主动防御免疫
    let out1 = g.attack(a1, ht).unwrap();
    let ht_unit = g.unit_at(ht).unwrap().clone();
    assert_eq!(ht_unit.hp, 2, "主战坦克 2 血");
    assert!(out1.hit, "90% 命中第一发应命中");
    assert!(!out1.killed, "第一发命中被主动防御免疫");
    assert_eq!(ht_unit.ad_uses, 7, "主动防御 8->7");
    // 第二发（同回合）：主动防御仍触发（不再是“回合首次”），继续免疫
    let out2 = g.attack(a2, ht).unwrap();
    assert!(out2.hit, "第二发应命中: {:?}", out2.message);
    assert!(!out2.killed, "第二发仍被主动防御免疫");
    assert_eq!(g.unit_at(ht).unwrap().hp, 2, "第二发未造成伤害");
    assert_eq!(g.unit_at(ht).unwrap().ad_uses, 6, "主动防御 7->6");
    // 新回合：仍然触发
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player);
    let out3 = g.attack(a1, ht).unwrap();
    assert!(out3.hit && !out3.killed, "第三发再次被主动防御免疫");
    assert_eq!(g.unit_at(ht).unwrap().ad_uses, 5, "主动防御 6->5");
}

#[test]
fn test_simultaneous_attack_sums_damage() {
    let mut g = GameState::new_deploy_level(10, Level::OpenField);
    g.begin_turn(Team::Player);
    let a1 = hex::axial_from_offset(0, 0);
    let a2 = hex::axial_from_offset(0, 1);
    let t = hex::axial_from_offset(2, 0); // 距离 2，满足步兵隐蔽（视野5/2=2）
    g.units.insert(a1, Unit::new(UnitKind::HeavyTank, Team::Player, a1));
    g.units.insert(a2, Unit::new(UnitKind::HeavyTank, Team::Player, a2));
    g.units.insert(t, Unit::new(UnitKind::Rifleman, Team::Ai, t));
    let orders = vec![
        SimulOrder { attacker: a1, target: t, air_first: false, aa_mode: false, missile_mode: false },
        SimulOrder { attacker: a2, target: t, air_first: false, aa_mode: false, missile_mode: false },
    ];
    let outs = g.simultaneous_attack(&orders).unwrap();
    let target = g.unit_at(t).unwrap();
    assert_eq!(target.hp, 1, "两发命中伤害应加和：3 血 -> 1 血");
    assert!(!outs[0].killed, "两发 1 点伤害不应击毁 3 血目标");
}

#[test]
fn test_simultaneous_active_defense_single_and_multi_hit() {
    // 同时攻击 1 发命中：主动防御消耗 1 次抵消该发
    let mut g = GameState::new_deploy_level(11, Level::OpenField);
    g.begin_turn(Team::Player);
    let a = hex::axial_from_offset(0, 0);
    let ht = hex::axial_from_offset(3, 0);
    let mut cv = Unit::new(UnitKind::CavalryIfv, Team::Player, a);
    cv.missile_mode = true; // TOW：不是坦克炮，主动防御仍可抵消
    g.units.insert(a, cv);
    g.units.insert(ht, Unit::new(UnitKind::HeavyTank, Team::Ai, ht));
    let one = vec![SimulOrder { attacker: a, target: ht, air_first: false, aa_mode: false, missile_mode: true }];
    let _outs = g.simultaneous_attack(&one).unwrap();
    assert_eq!(g.unit_at(ht).unwrap().hp, 2, "单发被主动防御抵消");
    assert_eq!(g.unit_at(ht).unwrap().ad_uses, 7, "8->7");

    // 同时攻击 2 发命中：主动防御消耗 1 次随机抵消其中 1 发，另一发造成 1 伤害
    let mut g2 = GameState::new_deploy_level(12, Level::OpenField);
    g2.begin_turn(Team::Player);
    let a1 = hex::axial_from_offset(0, 0);
    let a2 = hex::axial_from_offset(0, 1);
    let ht2 = hex::axial_from_offset(3, 0);
    let mut cv1 = Unit::new(UnitKind::CavalryIfv, Team::Player, a1);
    cv1.missile_mode = true;
    let mut cv2 = Unit::new(UnitKind::CavalryIfv, Team::Player, a2);
    cv2.missile_mode = true;
    g2.units.insert(a1, cv1);
    g2.units.insert(a2, cv2);
    g2.units.insert(ht2, Unit::new(UnitKind::HeavyTank, Team::Ai, ht2));
    let two = vec![
        SimulOrder { attacker: a1, target: ht2, air_first: false, aa_mode: false, missile_mode: true },
        SimulOrder { attacker: a2, target: ht2, air_first: false, aa_mode: false, missile_mode: true },
    ];
    let _outs = g2.simultaneous_attack(&two).unwrap();
    let u = g2.unit_at(ht2).unwrap().clone();
    assert_eq!(u.hp, 1, "两发命中时主动防御抵消 1 发，另 1 发造成 1 伤害");
    assert_eq!(u.ad_uses, 7, "同时攻击结果只消耗 1 次主动防御");
}

#[test]
fn test_simultaneous_order_uses_weapon_mode_snapshot() {
    let mut g = GameState::new_deploy_level(15, Level::OpenField);
    g.begin_turn(Team::Player);
    let shooter = hex::axial_from_offset(0, 0);
    let target = hex::axial_from_offset(2, 0);
    let mut ms = Unit::new(UnitKind::AaMgv, Team::Player, shooter);
    ms.missile_mode = true; // 当前为 Stinger 导弹模式，不能打地面
    g.units.insert(shooter, ms);
    g.units.insert(target, Unit::new(UnitKind::Tank, Team::Ai, target));

    // 快照为机枪模式：应能通过校验并成功攻击地面坦克
    let order_gun = SimulOrder {
        attacker: shooter,
        target,
        air_first: false,
        aa_mode: false,
        missile_mode: false,
    };
    assert!(g.validate_simul_order(order_gun).is_ok());
    assert!(g.simultaneous_attack(&[order_gun]).is_ok());

    // 如果确认时按当前导弹模式结算，则无法攻击地面目标（证明必须使用快照）
    let mut g2 = GameState::new_deploy_level(16, Level::OpenField);
    g2.begin_turn(Team::Player);
    let mut ms2 = Unit::new(UnitKind::AaMgv, Team::Player, shooter);
    ms2.missile_mode = true;
    g2.units.insert(shooter, ms2);
    g2.units.insert(target, Unit::new(UnitKind::Tank, Team::Ai, target));
    let order_missile = SimulOrder {
        attacker: shooter,
        target,
        air_first: false,
        aa_mode: false,
        missile_mode: true,
    };
    assert!(
        g2.validate_simul_order(order_missile).is_err(),
        "导弹模式快照不能攻击地面目标"
    );
}

#[test]
fn test_simultaneous_area_attack_joins_volley_and_suppresses() {
    let mut g = GameState::new_deploy_level(17, Level::OpenField);
    g.begin_turn(Team::Player);
    let how = hex::axial_from_offset(0, 0);
    let tank = hex::axial_from_offset(0, 1);
    let target = hex::axial_from_offset(2, 0); // 距离 2，满足步兵隐蔽（视野5/2=2）
    let mut h = Unit::new(UnitKind::Howitzer, Team::Player, how);
    h.deployed = true;
    h.missile_mode = true; // M864：中心/周围 100% 命中
    g.units.insert(how, h);
    g.units.insert(tank, Unit::new(UnitKind::HeavyTank, Team::Player, tank));
    g.units.insert(target, Unit::new(UnitKind::Rifleman, Team::Ai, target));

    let orders = vec![
        SimulOrder { attacker: how, target, air_first: false, aa_mode: false, missile_mode: true },
        SimulOrder { attacker: tank, target, air_first: false, aa_mode: false, missile_mode: false },
    ];
    let outs = g.simultaneous_attack(&orders).unwrap();
    let u = g.unit_at(target).unwrap().clone();
    assert_eq!(u.hp, 1, "炮击 1 点 + 直射 1 点应加和：3 血 -> 1 血");
    assert!(u.suppressed, "炮击应施加压制");
    assert!(outs.iter().any(|o| o.message.contains("同时攻击")), "应有齐射结算消息");

    // 单独范围攻击打空地与同时攻击一起也不应报错
    let mut g2 = GameState::new_deploy_level(18, Level::OpenField);
    g2.begin_turn(Team::Player);
    let h2 = Unit::new(UnitKind::Mortar, Team::Player, how);
    g2.units.insert(how, h2);
    let empty = hex::axial_from_offset(5, 5);
    let orders2 = vec![SimulOrder { attacker: how, target: empty, air_first: false, aa_mode: false, missile_mode: false }];
    assert!(g2.simultaneous_attack(&orders2).is_ok(), "空范围攻击也应正常结算");
}

#[test]
fn test_simultaneous_maneuver_evasion_disabled_by_focus_fire() {
    let mut g = GameState::new_deploy_level(13, Level::OpenField);
    g.begin_turn(Team::Player);
    let a1 = hex::axial_from_offset(0, 0);
    let a2 = hex::axial_from_offset(0, 1);
    let heli = hex::axial_from_offset(3, 0);
    g.units.insert(a1, Unit::new(UnitKind::AaLauncher, Team::Player, a1));
    g.units.insert(a2, Unit::new(UnitKind::AaLauncher, Team::Player, a2));
    g.air_units.insert(heli, Unit::new(UnitKind::TransportHeli, Team::Ai, heli));
    let orders = vec![
        SimulOrder { attacker: a1, target: heli, air_first: false, aa_mode: false, missile_mode: false },
        SimulOrder { attacker: a2, target: heli, air_first: false, aa_mode: false, missile_mode: false },
    ];
    let outs = g.simultaneous_attack(&orders).unwrap();
    assert!(
        !outs[0].message.contains("机动规避×0.6"),
        "被 2 个及以上单位同时攻击时机动规避应失效: {}",
        outs[0].message
    );

    // 单次同时攻击（只有 1 个单位打该直升机）时机动规避仍生效
    let mut g2 = GameState::new_deploy_level(14, Level::OpenField);
    g2.begin_turn(Team::Player);
    g2.units.insert(a1, Unit::new(UnitKind::AaLauncher, Team::Player, a1));
    g2.air_units.insert(heli, Unit::new(UnitKind::TransportHeli, Team::Ai, heli));
    let single = vec![SimulOrder { attacker: a1, target: heli, air_first: false, aa_mode: false, missile_mode: false }];
    let outs2 = g2.simultaneous_attack(&single).unwrap();
    assert!(
        outs2[0].message.contains("机动规避×0.6"),
        "单次攻击时机动规避应生效: {}",
        outs2[0].message
    );
}

#[test]
fn test_ai_focuses_heavy_tank_when_enough_firepower() {
    // AI 能对主战坦克发动 ≥2 次袭击 → 优先集火攻击它
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    // 玩家主战坦克（AI 可见：AI 坦克在附近）
    let ht = hex::axial_from_offset(8, 0);
    g.units.insert(ht, Unit::new(UnitKind::HeavyTank, Team::Player, ht));
    // AI 两辆坦克在射程内（能发动 2 次袭击）
    let a1 = hex::axial_from_offset(3, 0);
    let a2 = hex::axial_from_offset(12, 0);
    g.units.insert(a1, Unit::new(UnitKind::Tank, Team::Ai, a1));
    g.units.insert(a2, Unit::new(UnitKind::Tank, Team::Ai, a2));
    g.begin_turn(Team::Ai);
    assert!(g.is_unit_visible(Team::Ai, ht), "主战坦克应被 AI 看到");
    // 两个 AI 坦克都能打到 (8,0)：距离 5/4 ≤ 6
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // 集火：至少一辆坦克攻击了主战坦克；坦克炮无视主动防御，直接造成伤害/击毁
    let ht_hp = g.unit_at(ht).map(|u| u.hp).unwrap_or(0);
    assert!(
        ht_hp < 2 || log.iter().any(|l| l.contains("攻击")),
        "AI 应优先集火主战坦克: {:?}",
        log
    );
    assert!(
        !log.iter().any(|l| l.contains("主动防御")),
        "坦克炮不应触发主动防御: {:?}",
        log
    );
    let has_attack = log.iter().any(|l| l.contains("攻击"));
    assert!(has_attack, "AI 应优先集火主战坦克: {:?}", log);
}

#[test]
fn test_ai_evades_heavy_tank_when_outgunned() {
    // AI 无法发动 ≥2 次袭击 → 撤退或撤入隐蔽地形（远离主战坦克）
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    // 玩家主战坦克
    let ht = hex::axial_from_offset(8, 0);
    g.units.insert(ht, Unit::new(UnitKind::HeavyTank, Team::Player, ht));
    // 单个 AI 步兵（打不穿，且只 1 个单位 → 袭击次数不足）
    let inf = hex::axial_from_offset(12, 2);
    g.units.insert(inf, Unit::new(UnitKind::Rifleman, Team::Ai, inf));
    g.begin_turn(Team::Ai);
    // 步兵能看到主战坦克（距离 6？(12,2)-(8,0) 距离 6 > 视野 3 → 看不到！
    // 需要 AI 侦察：给步兵一个同伴？或用高视野单位。改用武装直升机？直升机不隐蔽。
    // 用防空导弹手（视野3）+ 让主战坦克更近
    let inf2 = hex::axial_from_offset(10, 0);
    g.units.remove(&inf);
    g.units.insert(inf2, Unit::new(UnitKind::Rifleman, Team::Ai, inf2)); // 距离 2 ≤ 3 视野
    // 森林隐蔽地形：在远离主战坦克的方向放森林
    // open_field 已有森林 (3,1),(3,2),(3,3) 等。Rifleman 移动 1，向森林跑。
    assert!(g.is_unit_visible(Team::Ai, ht), "步兵应看到主战坦克");
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // 步兵应远离主战坦克（移动到更远/隐蔽处），而不是靠近
    let new_pos = g.units_of(Team::Ai).iter().find(|u| u.kind == UnitKind::Rifleman).unwrap().pos;
    let d_before = Hex::distance(inf2, ht);
    let d_after = Hex::distance(new_pos, ht);
    assert!(
        d_after >= d_before,
        "袭击次数不足应撤退/隐蔽（远离主战坦克）: 旧 {d_before} → 新 {d_after}，日志: {:?}",
        log
    );
}

#[test]
fn test_mshorad_rename_and_missile_mode() {
    // M-SHORAD：改名、护甲 2、2 发防空导弹、导弹模式与防空导弹一致
    assert_eq!(UnitKind::AaMgv.name(), "M-SHORAD");
    assert_eq!(UnitKind::AaMgv.armor(), 2, "M-SHORAD 护甲 2");
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let m = hex::axial_from_offset(2, 0);
    let heli = hex::axial_from_offset(5, 0);
    g.units.insert(m, Unit::new(UnitKind::AaMgv, Team::Player, m));
    g.air_units.insert(heli, Unit::new(UnitKind::AttackHeli, Team::Ai, heli));
    g.begin_turn(Team::Player);
    assert_eq!(g.unit_at(m).unwrap().missile_ammo, 2, "初始 2 发防空导弹");
    assert!(!g.unit_at(m).unwrap().missile_mode, "默认机枪模式");
    // 机枪模式：射程 4 打不到 3 格外？(2,0)->(5,0) 距离 3 ≤ 4 ✓ 可打直升机（机枪也能打直升机）
    assert!(g.unit_at(m).unwrap().eff_range() == 4);
    // 切导弹模式
    g.toggle_missile_mode(m).unwrap();
    assert!(g.unit_at(m).unwrap().missile_mode);
    assert_eq!(g.unit_at(m).unwrap().eff_range(), 8, "Stinger 导弹射程 8");
    assert_eq!(g.unit_at(m).unwrap().eff_hit_rate(), 70, "Stinger 命中 70%");
    assert_eq!(g.unit_at(m).unwrap().eff_attack(), 2, "Stinger 攻击 2");
    // 导弹模式打直升机 → 成功并消耗导弹
    let out = g.attack(m, heli).unwrap();
    assert!(out.hit || !out.hit, "导弹攻击应执行");
    assert_eq!(g.unit_at(m).unwrap().missile_ammo, 1, "导弹 2->1");
    assert_eq!(g.unit_at(m).unwrap().ammo, 25, "机枪弹药不受影响");
    // 导弹模式打地面 → 拒绝（只能打直升机）
    g.units.insert(hex::axial_from_offset(3, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(3, 0)));
    let err = g.attack(m, hex::axial_from_offset(3, 0)).unwrap_err();
    assert!(err.contains("Stinger"), "导弹模式只能打直升机: {}", err);
    // 切回机枪模式打地面 → 允许
    g.toggle_missile_mode(m).unwrap();
    assert!(!g.unit_at(m).unwrap().missile_mode);
    let out2 = g.attack(m, hex::axial_from_offset(3, 0));
    assert!(out2.is_ok(), "机枪模式可打地面: {:?}", out2.err());
    assert_eq!(g.unit_at(m).unwrap().ammo, 24, "机枪弹药 25->24");
}

#[test]
fn test_mshorad_missile_ammo_exhausted() {
    // 导弹耗尽后导弹模式无法攻击（提示切回机枪模式），机枪模式不受影响
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let m = hex::axial_from_offset(2, 0);
    let heli = hex::axial_from_offset(5, 0);
    g.units.insert(m, Unit::new(UnitKind::AaMgv, Team::Player, m));
    g.air_units.insert(heli, Unit::new(UnitKind::AttackHeli, Team::Ai, heli));
    g.begin_turn(Team::Player);
    g.toggle_missile_mode(m).unwrap();
    g.unit_at_mut(m).unwrap().missile_ammo = 0;
    let err = g.attack(m, heli).unwrap_err();
    assert!(err.contains("Stinger 防空导弹耗尽"), "导弹耗尽应报错: {}", err);
    // 切回机枪模式仍可攻击直升机（射程 4，距离 3）
    g.toggle_missile_mode(m).unwrap();
    assert!(g.attack(m, heli).is_ok(), "机枪模式不受导弹耗尽影响");
}

#[test]
fn test_recon_drone() {
    // 侦察无人机：空中单位，视野 12，1 发反坦克导弹（攻 4），费用 12
    assert_eq!(UnitKind::Drone.name(), "侦察无人机");
    assert_eq!(UnitKind::Drone.max_hp(), 1);
    assert_eq!(UnitKind::Drone.armor(), 1);
    assert_eq!(UnitKind::Drone.vision(), 12, "视野 12 全单位最远");
    assert_eq!(UnitKind::Drone.action_count(), 2);
    assert_eq!(UnitKind::Drone.movement(), 10); // 无人机行动力 10
    assert_eq!(UnitKind::Drone.attack(), 4);
    assert_eq!(UnitKind::Drone.range(), 4);
    assert_eq!(UnitKind::Drone.hit_rate(), 90);
    assert_eq!(UnitKind::Drone.max_ammo(), 1, "仅 1 发反坦克导弹");
    assert_eq!(UnitKind::Drone.recruit_cost(), 12);
    assert!(UnitKind::Drone.is_air(), "空中单位");
    assert!(UnitKind::Drone.can_hit_ground(), "反坦克导弹打地面");
    assert!(!UnitKind::Drone.can_hit_air(), "无人机不空对空");
    assert_eq!(UnitKind::Drone.concealment(), 1);
    // 空中单位：普通陆战打不到，防空能打
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let d = hex::axial_from_offset(4, 0);
    g.air_units.insert(d, Unit::new(UnitKind::Drone, Team::Player, d));
    g.units.insert(hex::axial_from_offset(5, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(5, 0)));
    g.begin_turn(Team::Player);
    // 无人机攻击地面坦克（距离 1 ≤ 4）：攻 4 > 坦克护甲 3 → 命中即伤害
    let out = g.attack(d, hex::axial_from_offset(5, 0)).unwrap();
    assert_eq!(g.air_units.get(&d).unwrap().ammo, 0, "1 发导弹打空");
    assert_eq!(g.air_units.get(&d).unwrap().actions_left, 1, "攻击耗 1 行动");
    if out.hit {
        assert_eq!(g.units.get(&hex::axial_from_offset(5, 0)).map(|t| t.hp), Some(1), "坦克 2 血被击中剩 1");
    }
    // 导弹耗尽后无法攻击
    let err = g.attack(d, hex::axial_from_offset(5, 0)).unwrap_err();
    assert!(err.contains("弹药"), "导弹耗尽: {}", err);
    // 普通陆战单位打无人机 → 拒绝（防空单位才能打空中）
    g.air_units.remove(&d);
    g.air_units.insert(hex::axial_from_offset(6, 0), Unit::new(UnitKind::Drone, Team::Ai, hex::axial_from_offset(6, 0)));
    g.units.insert(hex::axial_from_offset(7, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(7, 0)));
    let err2 = g.attack(hex::axial_from_offset(7, 0), hex::axial_from_offset(6, 0)).unwrap_err();
    assert!(err2.contains("空中"), "坦克打不到无人机: {}", err2);
    // 防空单位（防空导弹手）能打无人机
    g.units.insert(hex::axial_from_offset(8, 0), Unit::new(UnitKind::AaInfantry, Team::Player, hex::axial_from_offset(8, 0)));
    assert!(g.attack(hex::axial_from_offset(8, 0), hex::axial_from_offset(6, 0)).is_ok(), "防空导弹手能打无人机");
}

#[test]
fn test_suppression_mechanic() {
    // 榴弹炮/迫击炮炮击后，范围内所有敌军（无论命中与否）获得 1 回合压制（新回合行动 -1）。
    // 护甲 ≥ 2 的单位免疫火炮压制。
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    let how = hex::axial_from_offset(2, 2);
    g.units.insert(how, Unit::new(UnitKind::Howitzer, Team::Player, how));
    // 目标区域：中心 (4,2) + 邻格 (5,2)——护甲 0 的步兵被压制；
    // 另一邻格的坦克（护甲 3）与范围外的目标不受压制。
    let c1 = hex::axial_from_offset(4, 2);
    let ring: Vec<hex::Hex> = c1
        .neighbors()
        .into_iter()
        .filter(|h| g.map.contains(*h))
        .collect();
    let c2 = ring[0];
    let tank_h = ring[1];
    let far = hex::axial_from_offset(10, 2);
    g.units.insert(c1, Unit::new(UnitKind::Rifleman, Team::Ai, c1));
    g.units.insert(c2, Unit::new(UnitKind::Rifleman, Team::Ai, c2));
    g.units.insert(tank_h, Unit::new(UnitKind::Tank, Team::Ai, tank_h));
    g.units.insert(far, Unit::new(UnitKind::Tank, Team::Ai, far));
    g.begin_turn(Team::Player);
    g.deploy(how).unwrap();
    g.begin_turn(Team::Player);
    let out = g.attack(how, c1).unwrap();
    // 两处护甲 0 的步兵被压制（无论命中），坦克免疫
    assert!(g.unit_at(c1).unwrap().suppressed, "中心目标被压制");
    assert!(g.unit_at(c2).unwrap().suppressed, "邻格目标被压制");
    assert!(!g.unit_at(tank_h).unwrap().suppressed, "护甲 3 的坦克免疫火炮压制");
    assert_eq!(g.unit_at(tank_h).unwrap().suppression_stacks, 0);
    assert!(!g.unit_at(far).unwrap().suppressed, "范围外不受压制");
    assert!(out.message.contains("压制"), "消息应提示压制: {}", out.message);
    // 压制在对方新回合生效：行动次数 -1，然后解除
    g.begin_turn(Team::Ai);
    assert_eq!(g.unit_at(c1).unwrap().actions_left, 2, "被压制步兵行动 3-1=2");
    assert_eq!(g.unit_at(c2).unwrap().actions_left, 2);
    assert_eq!(g.unit_at(tank_h).unwrap().actions_left, 2, "坦克未被压制，行动正常");
    assert_eq!(g.unit_at(far).unwrap().actions_left, 2, "范围外行动正常");
    assert!(!g.unit_at(c1).unwrap().suppressed, "压制生效后解除");
    // 下下回合恢复
    g.begin_turn(Team::Player);
    g.begin_turn(Team::Ai);
    assert_eq!(g.unit_at(c1).unwrap().actions_left, 3, "恢复 3 行动");
}

#[test]
fn test_mortar_fires_without_aim_and_suppresses() {
    // 自行迫击炮无需架设即可开火，且施加压制；命中率中心 60%/周围 30%
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    let m = hex::axial_from_offset(4, 2);
    g.units.insert(m, Unit::new(UnitKind::Mortar, Team::Player, m));
    let c = hex::axial_from_offset(8, 2);
    let n = hex::axial_from_offset(9, 2);
    g.units.insert(c, Unit::new(UnitKind::Rifleman, Team::Ai, c));
    g.units.insert(n, Unit::new(UnitKind::Rifleman, Team::Ai, n));
    g.begin_turn(Team::Player);
    // 无需架设直接开火（榴弹炮此距离需架设，迫击炮不需要）
    let out = g.attack(m, c).unwrap();
    assert!(out.message.contains("中心60%/周围30%"), "迫击炮命中率: {}", out.message);
    assert!(g.unit_at(c).unwrap().suppressed, "迫击炮也施加压制");
    assert!(g.unit_at(n).unwrap().suppressed, "邻格同样压制");
    assert_eq!(g.unit_at(m).unwrap().actions_left, 1, "迫击炮 2 行动：炮击后剩 1");
    // 迫击炮可移动（行动力 3）
    g.begin_turn(Team::Player);
    let path = g.map.plan_move(&g.units, &g.air_units, m, hex::axial_from_offset(5, 2), 3, Some(g.unit_at(m).unwrap().clone()), false);
    if path.len() > 1 {
        g.move_unit(m, &path, false).unwrap();
    }
    assert!(g.unit_at(hex::axial_from_offset(4, 2)).is_none() || true, "迫击炮可移动");
}

#[test]
fn test_mortar_smoke_shot_radius1() {
    // 自行迫击炮可发射烟雾弹：半径 1（7 格），无需架设
    let mut g = GameState::new_deploy_level(9, Level::OpenField); // 空地图
    let m = hex::axial_from_offset(4, 2);
    g.units.insert(m, Unit::new(UnitKind::Mortar, Team::Player, m));
    g.begin_turn(Team::Player);
    // 无需架设直接发射（榴弹炮需先 setup 架设）
    let center = hex::axial_from_offset(7, 2);
    let cells = g.smoke_shot(m, center).unwrap();
    assert_eq!(cells.len(), 7, "迫击炮烟雾弹半径 1 = 中心+6 邻 = 7 格: {}", cells.len());
    assert!(g.smoke.contains_key(&center));
    assert!(g.smoke.contains_key(&hex::axial_from_offset(8, 2)), "邻格有烟");
    assert!(!g.smoke.contains_key(&hex::axial_from_offset(9, 2)), "二环无烟（半径1）");
    assert_eq!(g.unit_at(m).unwrap().actions_left, 1, "发射耗 1 行动");
    assert_eq!(g.unit_at(m).unwrap().ammo, 23, "消耗 1 发炮弹");
    // 榴弹炮仍为半径 2（19 格）
    let h = hex::axial_from_offset(4, 6);
    g.units.insert(h, Unit::new(UnitKind::Howitzer, Team::Player, h));
    g.begin_turn(Team::Player);
    g.deploy(h).unwrap();
    g.begin_turn(Team::Player);
    let center2 = hex::axial_from_offset(7, 6);
    let cells2 = g.smoke_shot(h, center2).unwrap();
    assert_eq!(cells2.len(), 19, "榴弹炮烟雾弹半径 2 = 19 格: {}", cells2.len());
}

#[test]
fn test_special_forces() {
    // 特战小队：闪避 ×0.8（森林中 ×0.64）、森林/楼房隐蔽值 4
    assert_eq!(UnitKind::SpecialForces.name(), "特战小队");
    assert_eq!(UnitKind::SpecialForces.max_hp(), 2, "特战血量 2");
    assert_eq!(UnitKind::SpecialForces.armor(), 0, "特战（步兵）护甲 0");
    assert_eq!(UnitKind::SpecialForces.attack(), 1, "主武器步枪攻 1");
    assert_eq!(UnitKind::SpecialForces.range(), 3, "主武器步枪射程 3");
    assert_eq!(UnitKind::SpecialForces.hit_rate(), 80, "主武器步枪命中 80%");
    assert_eq!(UnitKind::SpecialForces.action_count(), 3);
    assert_eq!(UnitKind::SpecialForces.vision(), 6, "特战小队视野 6");
    assert_eq!(UnitKind::SpecialForces.movement(), 1, "特战小队行动力 1（步兵）");
    assert_eq!(UnitKind::SpecialForces.max_ammo(), 10, "步枪弹 10");
    assert_eq!(UnitKind::SpecialForces.recruit_cost(), 18, "特战小队费用 18");
    assert!(UnitKind::SpecialForces.is_foot() && UnitKind::SpecialForces.is_infantry());
    // 隐蔽值：开阔地 2、森林/楼房 4（视野 5 → 发现距离 5/2=2 或 5/4=1）
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    g.units.insert(hex::axial_from_offset(2, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(2, 0)));
    g.units.insert(hex::axial_from_offset(4, 0), Unit::new(UnitKind::SpecialForces, Team::Ai, hex::axial_from_offset(4, 0))); // 距离 2
    g.begin_turn(Team::Player);
    assert!(g.is_unit_visible(Team::Player, hex::axial_from_offset(4, 0)), "开阔地距离2 = 视野5/隐蔽2 可见");
    // 进入森林：隐蔽值 4 → 需要 5/4=1 → 距离 2 不可见
    g.map.add_forest(4, 0);
    assert!(
        !g.is_unit_visible(Team::Player, hex::axial_from_offset(4, 0)),
        "森林中隐蔽 4：距离 2 > 5/4 → 不可见"
    );
    // 闪避：被命中率 ×0.8（开阔地）；森林中 ×0.8×0.8=0.64
    let mut g2 = GameState::new_deploy_level(9, Level::OpenField);
    let sf = hex::axial_from_offset(3, 0);
    let tank = hex::axial_from_offset(1, 0); // 距离 2：开阔地特战隐蔽 2 → 5/2=2 可见
    g2.units.insert(tank, Unit::new(UnitKind::Tank, Team::Player, tank));
    g2.units.insert(sf, Unit::new(UnitKind::SpecialForces, Team::Ai, sf));
    g2.begin_turn(Team::Player);
    let out = g2.attack(tank, sf).unwrap();
    assert!(out.message.contains("72") && out.message.contains("特战闪避×0.8"), "开阔地 90×0.8=72: {}", out.message);
    // 森林中：90%×0.8(森林)×0.8(特战) = 57.6 → 消息含 57。
    // 特战在森林隐蔽 4：用视野 12 的无人机（无人机视野/4=3 ≥ BFS 3 可见）
    let mut g3 = GameState::new_deploy_level(9, Level::OpenField);
    let sf2 = hex::axial_from_offset(3, 0);
    let drone = hex::axial_from_offset(2, 1); // 偏移(2,1)：到森林(3,0) BFS 2 步 ≤ 12/4=3
    g3.map.add_forest(3, 0);
    g3.air_units.insert(drone, Unit::new(UnitKind::Drone, Team::Player, drone));
    g3.units.insert(sf2, Unit::new(UnitKind::SpecialForces, Team::Ai, sf2));
    g3.begin_turn(Team::Player);
    let out2 = g3.attack(drone, sf2).unwrap();
    assert!(out2.message.contains("57"), "森林闪避 90×0.8×0.8=57: {}", out2.message);
}

#[test]
fn test_elite_infantry_dual_weapon() {
    // 精锐步兵班组：血量 3、步枪/Javelin 双武器（J 切换），弹药独立
    assert_eq!(UnitKind::EliteInfantry.name(), "精锐步兵班组");
    assert_eq!(UnitKind::EliteInfantry.max_hp(), 3);
    assert_eq!(UnitKind::EliteInfantry.armor(), 0, "精锐步兵（步兵）护甲 0");
    assert_eq!(UnitKind::EliteInfantry.action_count(), 3);
    assert_eq!(UnitKind::EliteInfantry.movement(), 1, "精锐步兵班组行动力 1");
    assert_eq!(UnitKind::EliteInfantry.recruit_cost(), 15, "精锐步兵班组费用 15（手动调整）");
    assert!(UnitKind::EliteInfantry.is_foot() && UnitKind::EliteInfantry.is_infantry());
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let e = hex::axial_from_offset(0, 0);
    let t = hex::axial_from_offset(3, 0); // 距离 3：精锐视野 3 可见
    g.units.insert(e, Unit::new(UnitKind::EliteInfantry, Team::Player, e));
    g.units.insert(t, Unit::new(UnitKind::Tank, Team::Ai, t));
    g.begin_turn(Team::Player);
    // 默认步枪模式：射程 2（主武器射程 2）、命中 80、攻 1
    let u = g.unit_at(e).unwrap().clone();
    assert_eq!(u.eff_range(), 2);
    assert_eq!(u.eff_hit_rate(), 80);
    assert_eq!(u.eff_attack(), 1);
    assert_eq!(u.missile_ammo, 4, "M3E1 弹 4 发");
    // 切 M3E1 模式：射程 3、基准命中 80、攻 4
    g.toggle_missile_mode(e).unwrap();
    let u2 = g.unit_at(e).unwrap().clone();
    assert!(u2.missile_mode);
    assert_eq!(u2.eff_range(), 3, "M3E1 射程 3");
    assert_eq!(u2.eff_attack(), 4);
    // M3E1 攻击坦克（装甲单位 → 命中 100%；攻 4 ≥ 护甲 3）：消耗 M3E1 弹
    let out = g.attack(e, t).unwrap();
    assert!(out.message.contains("M3E1 对装甲×100%"), "装甲单位命中 100%: {}", out.message);
    let u3 = g.unit_at(e).unwrap().clone();
    assert_eq!(u3.missile_ammo, 3, "M3E1 弹 4->3");
    assert_eq!(u3.ammo, 10, "步枪弹不受影响");
    // 切回步枪模式：弹药显示步枪弹
    g.toggle_missile_mode(e).unwrap();
    assert_eq!(g.unit_at(e).unwrap().ammo_shown(), 10);
}

#[test]
fn test_rifleman_xm1176_building_kill() {
    // 步枪手副武器 M3E1-XM1176：射程3/攻3/命中100%/弹药4；攻击楼房内敌人强制击杀
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let r = hex::axial_from_offset(2, 0);
    let b = hex::axial_from_offset(4, 0);
    g.units.insert(r, Unit::new(UnitKind::Rifleman, Team::Player, r));
    g.units.insert(b, Unit::new(UnitKind::HeavyTank, Team::Ai, b)); // 楼内主战坦克（护甲4）
    g.map.add_building(4, 0);
    g.begin_turn(Team::Player);
    // 步枪手视野 3：楼内主战坦克可见？(2,0)->(4,0) BFS 距离 2 ≤ 3/2？主战坦克隐蔽 1 → 3 可见 ✓
    assert_eq!(g.unit_at(r).unwrap().missile_ammo, 4, "XM1176 弹 4 发");
    // 切 XM1176 模式
    g.toggle_missile_mode(r).unwrap();
    assert_eq!(g.unit_at(r).unwrap().eff_hit_rate(), 100, "XM1176 命中 100%");
    assert_eq!(g.unit_at(r).unwrap().eff_attack(), 3, "XM1176 火箭筒攻击力 3");
    // 攻击楼内主战坦克：强制击杀（无视护甲 4 与 2 血量）
    let out = g.attack(r, b).unwrap();
    assert!(out.killed, "楼内目标被强制击杀: {}", out.message);
    assert!(g.unit_at(b).is_none());
    assert_eq!(g.unit_at(r).unwrap().missile_ammo, 3);
}

#[test]
fn test_special_forces_weapons() {
    // 特战小队：步枪（主武器）+ M3E1 火箭筒（M 键）+ Stinger 防空导弹（A 键）
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let sf = hex::axial_from_offset(2, 0);
    g.units.insert(sf, Unit::new(UnitKind::SpecialForces, Team::Player, sf));
    g.begin_turn(Team::Player);
    let u = g.unit_at(sf).unwrap().clone();
    assert_eq!(u.ammo, 10, "步枪弹 10");
    assert_eq!(u.missile_ammo, 4, "M3E1 弹 4");
    assert_eq!(u.aa_ammo, 1, "Stinger 1 发");
    // M 键 → M3E1
    g.toggle_missile_mode(sf).unwrap();
    let u2 = g.unit_at(sf).unwrap().clone();
    assert!(u2.missile_mode && !u2.aa_mode);
    assert_eq!(u2.eff_range(), 3, "M3E1 射程 3");
    assert_eq!(u2.eff_attack(), 4);
    // A 键 → Stinger（互斥）
    g.toggle_aa_mode(sf).unwrap();
    let u3 = g.unit_at(sf).unwrap().clone();
    assert!(u3.aa_mode && !u3.missile_mode);
    assert_eq!(u3.eff_range(), 8, "Stinger 射程 8");
    assert_eq!(u3.eff_hit_rate(), 70);
    assert_eq!(u3.eff_attack(), 2);
    // Stinger 只打直升机：打地面被拒
    g.units.insert(hex::axial_from_offset(4, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(4, 0)));
    let err = g.attack(sf, hex::axial_from_offset(4, 0)).unwrap_err();
    assert!(err.contains("Stinger"), "Stinger 只能打直升机: {}", err);
    // Stinger 打直升机：消耗 1 发（只有 1 发，打完耗尽）
    g.air_units.insert(hex::axial_from_offset(4, 1), Unit::new(UnitKind::AttackHeli, Team::Ai, hex::axial_from_offset(4, 1)));
    assert!(g.attack(sf, hex::axial_from_offset(4, 1)).is_ok(), "Stinger 打直升机");
    assert_eq!(g.unit_at(sf).unwrap().aa_ammo, 0, "Stinger 1->0");
    // 再次攻击 → 耗尽报错
    g.begin_turn(Team::Player);
    let err2 = g.attack(sf, hex::axial_from_offset(4, 1)).unwrap_err();
    assert!(err2.contains("Stinger 防空导弹耗尽"), "Stinger 耗尽: {}", err2);
}

#[test]
fn test_howitzer_m864() {
    // 榴弹炮 M864 双用途子母弹：中心/周围 100% 命中、攻 4、4 发、有压制
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let h = hex::axial_from_offset(2, 2);
    g.units.insert(h, Unit::new(UnitKind::Howitzer, Team::Player, h));
    let c = hex::axial_from_offset(4, 2);
    let n = hex::axial_from_offset(5, 2);
    g.units.insert(c, Unit::new(UnitKind::Tank, Team::Ai, c));
    g.units.insert(n, Unit::new(UnitKind::Tank, Team::Ai, n));
    g.begin_turn(Team::Player);
    g.deploy(h).unwrap();
    g.begin_turn(Team::Player);
    assert_eq!(g.unit_at(h).unwrap().missile_ammo, 4, "M864 4 发");
    // 切 M864 模式
    g.toggle_missile_mode(h).unwrap();
    let out = g.attack(h, c).unwrap();
    assert!(out.message.contains("中心100%/周围100%"), "M864 全命中: {}", out.message);
    // 攻 4 > 坦克护甲 3 → 命中即伤害；100% 命中下两辆坦克都受创/击杀
    assert!(g.unit_at(c).is_none() || g.unit_at(c).map(|u| u.hp < 2).unwrap_or(false), "中心坦克受创");
    assert!(g.unit_at(n).is_none() || g.unit_at(n).map(|u| u.hp < 2).unwrap_or(false), "邻格坦克受创");
    assert_eq!(g.unit_at(h).unwrap().missile_ammo, 3, "M864 4->3");
    assert_eq!(g.unit_at(h).unwrap().ammo, 24, "常规弹不受影响");
}

#[test]
fn test_air_vision_through_building() {
    // 无人机/直升机视野不受楼房影响（可看穿）；地面单位被楼房阻挡
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    g.map.obstacles.clear(); // 自包含地形：清掉默认岩石/森林干扰
    g.map.forests.clear();
    // 楼房墙：(5,0),(5,1),(5,2)
    g.map.add_building(5, 0);
    g.map.add_building(5, 1);
    g.map.add_building(5, 2);
    let target = hex::axial_from_offset(7, 1); // 距离 5（坦克视野 5 恰好可见，若不被楼房挡）
    g.units.insert(target, Unit::new(UnitKind::Tank, Team::Ai, target)); // 隐蔽 1
    // 地面坦克 (2,1) 视野 5：被楼房墙挡住看不到目标
    g.units.insert(hex::axial_from_offset(2, 1), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(2, 1)));
    g.begin_turn(Team::Player);
    assert!(
        !g.is_unit_visible(Team::Player, target),
        "地面单位视野被楼房阻挡"
    );
    // 无人机 (2,1) 视野 12：看穿楼房
    g.units.remove(&hex::axial_from_offset(2, 1));
    g.air_units.insert(hex::axial_from_offset(2, 1), Unit::new(UnitKind::Drone, Team::Player, hex::axial_from_offset(2, 1)));
    assert!(
        g.is_unit_visible(Team::Player, target),
        "无人机视野不受楼房影响"
    );
    // 直升机同样
    g.air_units.remove(&hex::axial_from_offset(2, 1));
    g.air_units.insert(hex::axial_from_offset(2, 1), Unit::new(UnitKind::AttackHeli, Team::Player, hex::axial_from_offset(2, 1)));
    assert!(
        g.is_unit_visible(Team::Player, target),
        "直升机视野不受楼房影响"
    );
}

#[test]
fn test_ai_recon_unit_scouts_ahead() {
    // 进攻关：AI 无人机被识别为侦察单位，无敌人时朝敌方半场前出
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    g.units.insert(hex::axial_from_offset(20, 6), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(20, 6)));
    g.air_units.insert(hex::axial_from_offset(22, 6), Unit::new(UnitKind::Drone, Team::Ai, hex::axial_from_offset(22, 6)));
    g.units.insert(hex::axial_from_offset(2, 6), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(2, 6)));
    g.begin_turn(Team::Ai);
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    let drone = g
        .air_units
        .iter()
        .find(|(_, u)| u.kind == UnitKind::Drone)
        .map(|(h, _)| *h)
        .expect("无人机仍在");
    let (dc, _) = hex::offset_from_axial(drone);
    assert!(
        dc < 22,
        "无人机应前出（朝敌方西边）: 新列 {dc}（日志: {:?}）",
        log
    );
    assert!(
        log.iter().any(|l| l.contains("前出侦察")),
        "应有前出侦察日志: {:?}",
        log
    );
}

#[test]
fn test_ai_three_strategies() {
    // (1) 就地攻击：射程内可见可打目标 → 攻击
    let mut g1 = GameState::new_deploy_level(9, Level::OpenField);
    g1.units.insert(hex::axial_from_offset(8, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(8, 0)));
    g1.units.insert(hex::axial_from_offset(5, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(5, 0)));
    g1.begin_turn(Team::Ai);
    let mut log1 = Vec::new();
    ai::run_ai_turn(&mut g1, Team::Ai, &mut log1);
    assert!(
        log1.iter().any(|l| l.contains("攻击")),
        "(1) 就地攻击应开火: {:?}",
        log1
    );

    // (2) 撤退：防空导弹手（打不了地面）被玩家坦克威胁 → 远离
    // （retreat_threats=1：单个威胁即触发撤退，验证撤退策略本身）
    let mut g2 = GameState::new_deploy_level(9, Level::OpenField);
    g2.ai_configs.insert(
        Team::Ai,
        AiConfig {
            retreat_threats: 1,
            ..AiConfig::default()
        },
    );
    g2.units.insert(hex::axial_from_offset(0, 0), Unit::new(UnitKind::AaInfantry, Team::Ai, hex::axial_from_offset(0, 0)));
    g2.units.insert(hex::axial_from_offset(3, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(3, 0)));
    g2.begin_turn(Team::Ai);
    let mut log2 = Vec::new();
    ai::run_ai_turn(&mut g2, Team::Ai, &mut log2);
    let aa = g2.units_of(Team::Ai).iter().find(|u| u.kind == UnitKind::AaInfantry).map(|u| u.pos).unwrap();
    let d_after = Hex::distance(aa, hex::axial_from_offset(3, 0));
    assert!(
        d_after >= 3 && aa != hex::axial_from_offset(0, 0),
        "(2) 撤退应移动且不更靠近玩家坦克: 距离 {d_after}（{:?}）",
        log2
    );
    assert!(
        log2.iter().any(|l| l.contains("撤退")),
        "(2) 应有撤退日志: {:?}",
        log2
    );

    // (3) 呼叫援军：AI 卡车看到近处玩家步兵（隐蔽2 需 视野/2=2 格内；打不到、不危险）
    // → 呼叫；远处坦克（预知敌方方向）随后响应/推进
    let mut g3 = GameState::new_deploy_level(9, Level::OpenField);
    g3.units.insert(hex::axial_from_offset(10, 0), Unit::new(UnitKind::Truck, Team::Ai, hex::axial_from_offset(10, 0)));
    g3.units.insert(hex::axial_from_offset(20, 0), Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(20, 0)));
    g3.units.insert(hex::axial_from_offset(12, 0), Unit::new(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(12, 0)));
    g3.begin_turn(Team::Ai);
    let mut log3 = Vec::new();
    ai::run_ai_turn(&mut g3, Team::Ai, &mut log3);
    assert!(
        log3.iter().any(|l| l.contains("呼叫援军")),
        "(3) 应有呼叫援军日志: {:?}",
        log3
    );
    let tank = g3
        .units_of(Team::Ai)
        .iter()
        .find(|u| u.kind == UnitKind::Tank)
        .map(|u| u.pos)
        .unwrap();
    // 共享视野下所有能看到的 AI 单位都会标记求援点并保守（不冒险突进）
    assert!(
        tank == hex::axial_from_offset(20, 0)
            || log3.iter().any(|l| l.contains("呼叫援军") || l.contains("增援")),
        "(3) 坦克应保守或增援（日志: {:?}）",
        log3
    );
}

#[test]
fn test_ai_deploy_no_pure_transport() {
    // AI 招募：无榴弹炮 → 不买卡车/运输直升机；有榴弹炮 → 至多 1 辆卡车
    for seed in 0..6 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.finish_deploy().unwrap();
        let trucks = g
            .units_of(Team::Ai)
            .iter()
            .filter(|u| u.kind == UnitKind::Truck)
            .count();
        let transports = g
            .units_of(Team::Ai)
            .iter()
            .filter(|u| u.kind == UnitKind::TransportHeli)
            .count();
        let howitzers = g
            .units_of(Team::Ai)
            .iter()
            .filter(|u| u.kind == UnitKind::Howitzer)
            .count();
        assert_eq!(transports, 0, "seed {seed}: 不再招募纯运输直升机");
        if howitzers > 0 {
            assert!(trucks <= 1, "seed {seed}: 有榴弹炮时卡车至多 1 辆（实际 {trucks}）");
        } else {
            assert_eq!(trucks, 0, "seed {seed}: 无榴弹炮不买卡车（实际 {trucks}）");
        }
    }
}

#[test]
fn test_village_recon_guides_artillery() {
    // 村庄防守关：AI 侦察单位（武直）前出开眼 → 榴弹炮据此炮击远处玩家单位
    let mut g = GameState::new_deploy_level(7, Level::VillageDefense);
    let how = hex::axial_from_offset(24, 4);
    g.units.insert(how, Unit::new(UnitKind::Howitzer, Team::Ai, how));
    let heli = hex::axial_from_offset(22, 6);
    g.air_units.insert(heli, Unit::new(UnitKind::AttackHeli, Team::Ai, heli));
    // 玩家悍马（隐蔽1 护甲1）：武直 9 格内可见；榴弹炮炮击必然施加压制（护甲<2）
    let p_tank = hex::axial_from_offset(14, 4);
    g.units.insert(p_tank, Unit::new(UnitKind::HumveeHmg, Team::Player, p_tank));
    g.begin_turn(Team::Ai);
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // 武直被识别为侦察单位前出（朝西边玩家方向），榴弹炮架设
    let heli_now = g
        .air_units
        .iter()
        .find(|(_, u)| u.kind == UnitKind::AttackHeli)
        .map(|(h, _)| *h)
        .unwrap();
    let (hc, _) = hex::offset_from_axial(heli_now);
    assert!(hc < 22, "武直应前出侦察（朝西）: 新列 {hc}（{:?}）", log);
    assert!(
        log.iter().any(|l| l.contains("前出侦察")),
        "应有前出侦察日志: {:?}",
        log
    );
    // 榴弹炮架设（第一回合）
    assert!(
        g.unit_at(how).map(|u| u.deployed).unwrap_or(false) || log.iter().any(|l| l.contains("架设")),
        "榴弹炮应架设: {:?}",
        log
    );
    // 第二回合：武直视野（共享）引导榴弹炮炮击玩家坦克
    g.begin_turn(Team::Player);
    g.begin_turn(Team::Ai);
    let mut log2 = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log2);
    assert!(
        log2.iter().any(|l| l.contains("炮击") || l.contains("攻击")),
        "榴弹炮应炮击（侦察引导）: {:?}",
        log2
    );
    // 玩家悍马要么受创/被压制（护甲1 < 2，必被火炮压制）
    let tank_hp = g.units.get(&p_tank).map(|t| t.hp).unwrap_or(0);
    let suppressed = g.units.get(&p_tank).map(|t| t.suppressed).unwrap_or(false);
    assert!(
        tank_hp < 2 || suppressed,
        "玩家悍马应被炮击影响（hp={tank_hp}）: {:?}",
        log2
    );
}

#[test]
fn test_scout_vehicle() {
    // 侦察战车：属性与 AI 侦察识别
    assert_eq!(UnitKind::Scout.name(), "侦察战车");
    assert_eq!(UnitKind::Scout.recruit_cost(), 10, "侦察战车费用 10");
    assert_eq!(UnitKind::Scout.armor(), 2, "护甲 2");
    assert_eq!(UnitKind::Scout.max_hp(), 1, "血量 1");
    assert_eq!(UnitKind::Scout.attack(), 2, "攻击 2");
    assert_eq!(UnitKind::Scout.range(), 4, "射程 4");
    assert_eq!(UnitKind::Scout.max_ammo(), 6, "弹药 6");
    assert_eq!(UnitKind::Scout.hit_rate(), 80, "命中 80%");
    assert_eq!(UnitKind::Scout.action_count(), 3, "行动次数 3");
    assert_eq!(UnitKind::Scout.movement(), 3, "行动力 3");
    assert_eq!(UnitKind::Scout.vision(), 8, "视野 8");
    assert!(UnitKind::Scout.is_vehicle(), "侦察战车是车辆");
    assert!(UnitKind::Scout.can_hit_ground(), "侦察战车能打地面");
    assert!(!UnitKind::Scout.can_hit_air(), "侦察战车不能打空中");
    assert!(UnitKind::Scout.can_damage(UnitKind::Tank) == false, "攻 2 打不动装甲 3 的坦克");

    // AI 侦察识别：视野 8 非防空 → 入选前出侦察（村庄关也入选）
    let mut g = GameState::new_deploy_level(7, Level::VillageDefense);
    let sc = hex::axial_from_offset(24, 6);
    g.units.insert(sc, Unit::new(UnitKind::Scout, Team::Ai, sc));
    g.units.insert(hex::axial_from_offset(14, 6), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(14, 6)));
    g.begin_turn(Team::Ai);
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    let scout = g.units_of(Team::Ai).iter().find(|u| u.kind == UnitKind::Scout).map(|u| u.pos).unwrap();
    let (sc_col, _) = hex::offset_from_axial(scout);
    assert!(sc_col < 24, "村庄关侦察战车前出侦察: 新列 {sc_col}（{:?}）", log);
    assert!(
        log.iter().any(|l| l.contains("前出侦察")),
        "应有前出侦察日志: {:?}",
        log
    );
}

#[test]
fn test_truck_boarding_sequence() {
    // 复现：装 2 队步兵 → 下回合装第 3 队；卸下后重新装载
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let t = hex::axial_from_offset(4, 0);
    g.units.insert(t, Unit::new(UnitKind::Truck, Team::Player, t));
    let i1 = hex::axial_from_offset(3, 0);
    let i2 = hex::axial_from_offset(5, 0);
    let i3 = hex::axial_from_offset(4, 1);
    for (h, lb) in [(i1, '1'), (i2, '2'), (i3, '3')] {
        let mut u = Unit::new(UnitKind::Rifleman, Team::Player, h);
        u.label = lb;
        g.units.insert(h, u);
    }
    g.begin_turn(Team::Player);
    g.board(t, i1).expect("装 1");
    g.board(t, i2).expect("装 2");
    assert_eq!(g.unit_at(t).unwrap().used_weight(), 6);
    // 下回合
    g.begin_turn(Team::Player);
    let r = g.board(t, i3);
    if let Err(e) = &r {
        let u = g.unit_at(t).unwrap();
        eprintln!("装3失败: {e} | used_weight={} cap={} act={}", u.used_weight(), u.kind.capacity(), u.actions_left);
    }
    assert!(r.is_ok(), "下回合应能装第 3 队: {:?}", r);
    assert_eq!(g.unit_at(t).unwrap().used_weight(), 9);
    // 卸下第 3 队（到 (4,1) 原位置已空）
    let p = g.unit_at(t).unwrap().passengers.iter().find(|p| p.label == '3').unwrap().clone();
    let dest = hex::axial_from_offset(3, 1);
    g.disembark(t, '3', dest).expect("放下第 3 队");
    // 重新装载第 3 队
    let r2 = g.board(t, dest);
    if let Err(e) = &r2 {
        let u = g.unit_at(t).unwrap();
        eprintln!("重装失败: {e} | used_weight={} cap={} act={}", u.used_weight(), u.kind.capacity(), u.actions_left);
        let _ = p.pos;
    }
    assert!(r2.is_ok(), "卸下后应能重新装载: {:?}", r2);
}

#[test]
fn test_truck_full_sequence_cross_turn() {
    // 完整用户场景：卡车+3步兵+1榴弹炮
    // 回合1：装A、装B（行动用光）→ 回合2：卸A→装C；回合3：卸B→装榴弹炮
    // 轴向坐标：卡车 (4,0)；A(3,0) B(5,0) C(4,1) 榴弹炮 H(4,-1) 均紧邻
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let t = hex::Hex::new(4, 0);
    g.units.insert(t, Unit::new(UnitKind::Truck, Team::Player, t));
    let spots = [
        (hex::Hex::new(3, 0), 'A', UnitKind::Rifleman),
        (hex::Hex::new(5, 0), 'B', UnitKind::Rifleman),
        (hex::Hex::new(4, 1), 'C', UnitKind::Rifleman),
        (hex::Hex::new(4, -1), 'H', UnitKind::Howitzer), // 紧邻卡车 (4,0)
    ];
    for (h, lb, k) in spots {
        let mut u = Unit::new(k, Team::Player, h);
        u.label = lb;
        g.units.insert(h, u);
    }
    g.begin_turn(Team::Player);
    g.board(t, hex::Hex::new(3, 0)).expect("装A");
    g.board(t, hex::Hex::new(5, 0)).expect("装B");
    assert_eq!(g.unit_at(t).unwrap().used_weight(), 6);
    // 回合2：卸 A（到邻格 5,-1）→ 装 C
    g.begin_turn(Team::Player);
    let dest_a = hex::Hex::new(5, -1);
    g.disembark(t, 'A', dest_a).expect("卸A");
    let r = g.board(t, hex::Hex::new(4, 1));
    assert!(r.is_ok(), "回合2 卸A后应能装C: {:?}", r);
    // 回合3：卸 B（到邻格 5,0 已空）→ 装榴弹炮（5 重量）
    g.begin_turn(Team::Player);
    let dest_b = hex::Hex::new(5, 0);
    g.disembark(t, 'B', dest_b).expect("卸B");
    let hh = hex::Hex::new(4, -1);
    let r2 = g.board(t, hh);
    if let Err(e) = &r2 {
        let u = g.unit_at(t).unwrap();
        eprintln!("装榴弹炮失败: {e} | used_weight={} cap={} act={}", u.used_weight(), u.kind.capacity(), u.actions_left);
    }
    assert!(r2.is_ok(), "回合3 卸B后应能装榴弹炮: {:?}", r2);
}

#[test]
fn test_ai_special_weapon_switch() {
    // ① 特战：视野内见直升机 → 自动切 Stinger（aa_mode）
    let mut g1 = GameState::new_deploy_level(9, Level::OpenField);
    let sf = hex::axial_from_offset(5, 0);
    g1.units.insert(sf, Unit::new(UnitKind::SpecialForces, Team::Ai, sf));
    g1.air_units.insert(hex::axial_from_offset(8, 0), Unit::new(UnitKind::AttackHeli, Team::Player, hex::axial_from_offset(8, 0)));
    g1.begin_turn(Team::Ai);
    ai::run_ai_turn(&mut g1, Team::Ai, &mut Vec::new());
    let sf_now = g1
        .units_of(Team::Ai)
        .iter()
        .find(|u| u.kind == UnitKind::SpecialForces)
        .map(|u| (u.aa_mode, u.aa_ammo))
        .unwrap();
    assert!(
        sf_now.0 || sf_now.1 == 0,
        "特战见直升机应自动切 Stinger（并消耗 Stinger 弹药）"
    );

    // ② 精锐：视野内见坦克（装甲≥2）→ 自动切 M3E1 火箭筒
    let mut g2 = GameState::new_deploy_level(9, Level::OpenField);
    let ei = hex::axial_from_offset(5, 0);
    g2.units.insert(ei, Unit::new(UnitKind::EliteInfantry, Team::Ai, ei));
    g2.units.insert(hex::axial_from_offset(7, 0), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(7, 0)));
    g2.begin_turn(Team::Ai);
    ai::run_ai_turn(&mut g2, Team::Ai, &mut Vec::new());
    let ei_now = g2
        .units_of(Team::Ai)
        .iter()
        .find(|u| u.kind == UnitKind::EliteInfantry)
        .map(|u| (u.missile_mode, u.missile_ammo))
        .unwrap();
    assert!(
        ei_now.0 || ei_now.1 < 4,
        "精锐见坦克应自动切 M3E1（并消耗 M3E1 弹药）"
    );

    // ③ 榴弹炮：射程内可见主战坦克（装甲3）→ 自动切 M864 子母弹
    let mut g3 = GameState::new_deploy_level(9, Level::OpenField);
    let how = hex::axial_from_offset(24, 4);
    g3.units.insert(how, Unit::new(UnitKind::Howitzer, Team::Ai, how));
    g3.units.insert(hex::axial_from_offset(20, 4), Unit::new(UnitKind::HeavyTank, Team::Player, hex::axial_from_offset(20, 4)));
    g3.begin_turn(Team::Ai);
    ai::run_ai_turn(&mut g3, Team::Ai, &mut Vec::new());
    assert!(
        g3.unit_at(how).map(|u| u.missile_mode).unwrap_or(false),
        "榴弹炮见主战坦克应自动切 M864"
    );
}

#[test]
fn test_ai_rifleman_xm1176_in_building() {
    // 步枪手：射程内有楼内步兵 → 自动切 XM1176（楼内强制击杀）
    let mut g = GameState::new_deploy_level(9, Level::VillageDefense);
    let b1 = hex::axial_from_offset(19, 3); // 楼房
    let b2 = hex::axial_from_offset(20, 3); // 紧邻楼房
    g.units.insert(b1, Unit::new(UnitKind::Rifleman, Team::Ai, b1));
    g.units.insert(b2, Unit::new(UnitKind::Rifleman, Team::Player, b2));
    g.begin_turn(Team::Ai);
    ai::run_ai_turn(&mut g, Team::Ai, &mut Vec::new());
    assert!(
        g.unit_at(b1).map(|u| u.missile_mode).unwrap_or(false),
        "步枪手见楼内步兵应自动切 XM1176"
    );
}

#[test]
fn test_ai_infantry_uses_cover() {
    // 进攻关：AI 步兵有森林隐蔽格可去（且不背离敌人）→ 先进森林
    let mut g = GameState::new_deploy_level(9, Level::OpenField);
    let ai_pos = hex::axial_from_offset(4, 4);
    g.units.insert(ai_pos, Unit::new(UnitKind::Rifleman, Team::Ai, ai_pos));
    g.units.insert(hex::axial_from_offset(24, 4), Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(24, 4)));
    g.begin_turn(Team::Ai);
    g.unit_at_mut(ai_pos).unwrap().actions_left = 1; // 只剩 1 次行动：只进隐蔽不追击
    ai::run_ai_turn(&mut g, Team::Ai, &mut Vec::new());
    let p = g
        .units_of(Team::Ai)
        .iter()
        .find(|u| u.kind == UnitKind::Rifleman)
        .map(|u| u.pos)
        .unwrap();
    assert!(
        g.map.forests.contains(&p) || g.map.buildings.contains(&p),
        "AI 步兵应进入森林/楼房隐蔽: offset {:?}",
        hex::offset_from_axial(p)
    );
}

#[test]
fn test_aa_infantry_boards_transport() {
    // 防空导弹手应可搭载：卡车/步兵战车/运输直升机（此前 is_infantry 遗漏防空手）
    assert!(UnitKind::AaInfantry.is_infantry(), "防空导弹手是可搭载步兵");
    let mut g = GameState::new_seeded(3);
    g.begin_turn(Team::Player);
    let truck_h = hex::axial_from_offset(1, 6);
    g.units.insert(truck_h, Unit::new(UnitKind::Truck, Team::Player, truck_h));
    let aa_h = hex::axial_from_offset(1, 5);
    g.units.insert(aa_h, Unit::new(UnitKind::AaInfantry, Team::Player, aa_h));
    // 卡车装载防空导弹手
    assert!(g.board(truck_h, aa_h).is_ok(), "卡车应能搭载防空导弹手");
    let truck = g.unit_at(truck_h).unwrap();
    assert_eq!(truck.passengers.len(), 1, "卡车已搭载防空导弹手");
    // 放下后运输直升机（正下方）也可载入
    g.disembark(truck_h, '?', aa_h).ok(); // 标签为 '?'（默认）
    // 换用带标签的单位确保标签正确
    let mut u = g.unit_at(aa_h).unwrap().clone();
    u.label = 'Z';
    g.units.insert(aa_h, u);
    let heli_h = aa_h; // 直升机飞在防空手正上方同格
    g.air_units.insert(heli_h, Unit::new(UnitKind::TransportHeli, Team::Player, heli_h));
    assert!(g.heli_board(heli_h).is_ok(), "运输直升机应能载入防空导弹手");
    let heli = g.air_units.get(&heli_h).unwrap();
    assert_eq!(heli.passengers.len(), 1, "直升机已搭载防空导弹手");
}

#[test]
fn custom_map_deploy_and_zones() {
    use crate::mapdef::CustomMap;
    let mut cm = CustomMap::default();
    cm.name = "自定义测试图".into();
    cm.cols = 24;
    cm.rows = 10;
    cm.obstacles = vec![(12, 5), (13, 5)];
    cm.buildings = vec![(20, 4)];
    cm.forests = vec![(6, 8), (7, 8)];
    cm.player_cols = vec![0, 1, 2];
    cm.ai_cols = vec![21, 22, 23];
    cm.player_points = 150;
    cm.ai_points = 200;
    cm.validate().unwrap();
    let mut g = GameState::new_custom_deploy(7, cm);
    assert_eq!(g.level, Level::Custom);
    assert_eq!(g.map.cols, 24);
    assert_eq!(g.map.rows, 10);
    assert!(g.map.obstacles.contains(&hex::axial_from_offset(12, 5)));
    assert!(g.map.buildings.contains(&hex::axial_from_offset(20, 4)));
    assert!(g.map.forests.contains(&hex::axial_from_offset(6, 8)));
    assert!(g.deploying, "自定义地图进入部署模式");
    assert_eq!(g.recruit_points[&Team::Player], 150);
    assert_eq!(g.recruit_points[&Team::Ai], 200);
    let pz = g.deploy_zone(Team::Player);
    assert!(pz.contains(&2) && !pz.contains(&3), "玩家部署列按自定义");
    let az = g.deploy_zone(Team::Ai);
    assert!(az.contains(&22) && !az.contains(&20), "AI 部署列按自定义");
    // 在自定义部署区放置单位成功
    let pos = hex::axial_from_offset(1, 4);
    let label = g.deploy_unit(Team::Player, UnitKind::Tank, pos).unwrap();
    assert_eq!(label, '1');
    // 越出部署区放置被拒
    let err = g
        .deploy_unit(Team::Player, UnitKind::Tank, hex::axial_from_offset(10, 4))
        .unwrap_err();
    assert!(err.contains("出发区域"), "{}", err);
    // 完成部署后游戏可运行（AI 自动部署、玩家回合）
    g.finish_deploy().unwrap();
    assert!(!g.deploying);
    g.begin_turn(Team::Player);
    assert!(g.units_of(Team::Player).iter().any(|u| u.kind == UnitKind::Tank));
}

/// 战役地图：预置棋子与指定据点直接进入对局；逐格部署区用于首个招募回合，
/// 之后在大本营中心周围 2 格内追加部署。
#[test]
fn campaign_map_loads_units_keypoints_and_cells() {
    use crate::mapdef::{CustomMap, PlacedKeypoint, PlacedUnit};
    let mut cm = CustomMap::default();
    cm.name = "战役测试图".into();
    cm.cols = 20;
    cm.rows = 10;
    cm.campaign = true;
    cm.player_cells = vec![(0, 0), (0, 1), (1, 1)];
    cm.ai_cells = vec![(19, 0), (19, 1), (18, 1)];
    cm.units = vec![
        PlacedUnit { team: Team::Player, kind: UnitKind::Tank, col: 0, row: 0, passengers: Vec::new()},
        PlacedUnit { team: Team::Player, kind: UnitKind::Rifleman, col: 0, row: 1, passengers: Vec::new()},
        PlacedUnit { team: Team::Ai, kind: UnitKind::HeavyTank, col: 19, row: 0, passengers: Vec::new()},
    ];
    cm.keypoints = vec![
        PlacedKeypoint { team: Team::Player, col: 0, row: 0, center: true },
        PlacedKeypoint { team: Team::Player, col: 1, row: 1, center: false },
        PlacedKeypoint { team: Team::Ai, col: 19, row: 1, center: true },
        PlacedKeypoint { team: Team::Ai, col: 18, row: 1, center: false },
    ];
    cm.player_points = 50;
    cm.ai_points = 60;
    cm.player_income = 7;
    cm.ai_income = 9;
    cm.validate().unwrap();

    let mut g = GameState::new_custom_deploy(1, cm);
    assert!(!g.deploying, "战役地图直接开战（无部署阶段）");
    assert_eq!(g.turn, 1, "直接进入第 1 回合");
    assert_eq!(g.recruit_zone_turn, 1, "首回合可在绘制的部署格内招募");
    assert!(g.sustain, "战役地图默认开启持续部署");
    assert_eq!(g.sustain_per_turn[&Team::Player], 7);
    assert_eq!(g.sustain_per_turn[&Team::Ai], 9);
    // 第 1 回合开局发放一次收入
    assert_eq!(g.recruit_points[&Team::Player], 57);
    assert_eq!(g.recruit_points[&Team::Ai], 69);
    // 预置棋子已就位
    assert!(g.unit_at(hex::axial_from_offset(0, 0)).is_some());
    assert!(g.unit_at(hex::axial_from_offset(0, 1)).is_some());
    assert!(g.unit_at(hex::axial_from_offset(19, 0)).is_some());
    // 指定据点与双方大本营中心
    assert_eq!(g.keypoints.len(), 4);
    assert_eq!(g.hq_pos(Team::Player), Some(hex::axial_from_offset(0, 0)));
    assert_eq!(g.hq_pos(Team::Ai), Some(hex::axial_from_offset(19, 1)));
    // 逐格部署区生效：绘制格可招募，同列未绘制格不可
    assert!(g.in_deploy_zone(Team::Player, hex::axial_from_offset(0, 1)));
    assert!(
        !g.in_deploy_zone(Team::Player, hex::axial_from_offset(0, 5)),
        "同列未绘制格不可部署"
    );
    let cols = g.deploy_zone(Team::Player);
    assert!(cols.contains(&0) && cols.contains(&1) && !cols.contains(&2));
    assert!(
        g.recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(1, 1))
            .is_ok(),
        "首回合可在绘制的部署格招募"
    );
    assert!(
        g.recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(0, 5))
            .is_err(),
        "未绘制的格不可招募"
    );
}

/// 战役地图：运输单位（卡车/轻型/重型运输直升机）可初始搭载货物进入对局，
/// 货物标签独立分配且随载具保存。
#[test]
fn campaign_map_loads_preloaded_transports() {
    use crate::mapdef::{CustomMap, PlacedKeypoint, PlacedUnit};
    let mut cm = CustomMap::default();
    cm.name = "搭载测试图".into();
    cm.cols = 20;
    cm.rows = 10;
    cm.campaign = true;
    cm.player_cells = vec![(0, 0), (0, 1), (1, 1)];
    cm.ai_cells = vec![(19, 0), (19, 1), (18, 1)];
    cm.units = vec![
        PlacedUnit {
            team: Team::Player,
            kind: UnitKind::Truck,
            col: 0,
            row: 0,
            passengers: vec![UnitKind::Rifleman, UnitKind::Atgm],
        },
        PlacedUnit {
            team: Team::Player,
            kind: UnitKind::TransportHeli,
            col: 1,
            row: 1,
            passengers: vec![UnitKind::SpecialForces],
        },
        PlacedUnit {
            team: Team::Ai,
            kind: UnitKind::HeavyTransportHeli,
            col: 19,
            row: 0,
            passengers: vec![UnitKind::HumveeHmg, UnitKind::AaInfantry],
        },
    ];
    cm.keypoints = vec![
        PlacedKeypoint { team: Team::Player, col: 0, row: 0, center: true },
        PlacedKeypoint { team: Team::Ai, col: 19, row: 0, center: true },
    ];
    cm.validate().unwrap();

    let g = GameState::new_custom_deploy(3, cm);
    let truck = g.unit_at(hex::axial_from_offset(0, 0)).expect("卡车已就位");
    assert_eq!(truck.kind, UnitKind::Truck);
    let cargo: Vec<UnitKind> = truck.passengers.iter().map(|p| p.kind).collect();
    assert_eq!(cargo, vec![UnitKind::Rifleman, UnitKind::Atgm], "卡车携带 2 名步兵");

    let heli = g.unit_at(hex::axial_from_offset(1, 1)).expect("运输直升机已就位");
    assert_eq!(heli.kind, UnitKind::TransportHeli);
    assert_eq!(heli.passengers.len(), 1);
    assert_eq!(heli.passengers[0].kind, UnitKind::SpecialForces);

    let heavy = g.unit_at(hex::axial_from_offset(19, 0)).expect("重型运输直升机已就位");
    assert_eq!(heavy.kind, UnitKind::HeavyTransportHeli);
    assert_eq!(heavy.used_weight(), 7, "重型运输直升机载悍马 6 + 步兵 1");
}

/// 测试用战役地图：双方各 1 座大本营 + 2 个目标 + 1 个预置单位。
fn campaign_map_for_victory(
    player_rule: VictoryRule,
    ai_rule: VictoryRule,
    turn_limit: i32,
) -> CustomMap {
    let mut cm = CustomMap::default();
    cm.name = "胜利条件测试".into();
    cm.cols = 12;
    cm.rows = 6;
    cm.campaign = true;
    cm.player_cells = vec![(0, 0), (0, 1)];
    cm.ai_cells = vec![(11, 0), (11, 1)];
    cm.player_income = 0;
    cm.ai_income = 0;
    cm.units = vec![
        crate::mapdef::PlacedUnit {
            team: Team::Player,
            kind: UnitKind::Tank,
            col: 4,
            row: 2,
            passengers: Vec::new(),
        },
        crate::mapdef::PlacedUnit {
            team: Team::Ai,
            kind: UnitKind::Rifleman,
            col: 11,
            row: 1,
            passengers: Vec::new(),
        },
    ];
    cm.keypoints = vec![
        crate::mapdef::PlacedKeypoint {
            team: Team::Player,
            col: 0,
            row: 0,
            center: true,
        },
        crate::mapdef::PlacedKeypoint {
            team: Team::Ai,
            col: 11,
            row: 0,
            center: true,
        },
        crate::mapdef::PlacedKeypoint {
            team: Team::Ai,
            col: 5,
            row: 2,
            center: false,
        },
        crate::mapdef::PlacedKeypoint {
            team: Team::Ai,
            col: 6,
            row: 2,
            center: false,
        },
    ];
    cm.turn_limit = turn_limit;
    cm.player_victory = player_rule;
    cm.ai_victory = ai_rule;
    cm
}

/// A 进攻：在指定回合前占领全部关键据点即胜（大本营不计入目标）。
#[test]
fn campaign_victory_rule_a_capture_before_turn() {
    let cm = campaign_map_for_victory(
        VictoryRule::CaptureAllBeforeTurn { turn: 3 },
        VictoryRule::HoldAnyAtEnd,
        5,
    );
    let mut g = GameState::new_custom_deploy(1, cm);
    let p = hex::axial_from_offset(4, 2);
    let o1 = hex::axial_from_offset(5, 2);
    let o2 = hex::axial_from_offset(6, 2);
    assert!(!g.controls_all_keypoints(Team::Player));
    g.move_unit(p, &[p, o1], false).unwrap();
    assert_eq!(g.winner, None, "只占领 1 个目标不判胜");
    g.move_unit(o1, &[o1, o2], false).unwrap();
    assert_eq!(g.winner, Some(Team::Player), "A：占全目标立即获胜");
}

/// B 进攻并坚守：到指定回合时仍控制全部关键据点即胜。
#[test]
fn campaign_victory_rule_b_hold_at_turn() {
    let cm = campaign_map_for_victory(
        VictoryRule::HoldAllAtTurn { turn: 3 },
        VictoryRule::HoldAnyAtEnd,
        5,
    );
    let mut g = GameState::new_custom_deploy(2, cm);
    let o1 = hex::axial_from_offset(5, 2);
    let o2 = hex::axial_from_offset(6, 2);
    g.keypoints.get_mut(&o1).unwrap().controller = Team::Player;
    assert_eq!(g.winner, None, "占全但未到指定回合不判胜");
    g.keypoints.get_mut(&o2).unwrap().controller = Team::Player;
    assert_eq!(g.winner, None, "B 不立即判胜");
    // 推进到第 3 回合
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // turn 2
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // turn 3 → 检查
    assert_eq!(g.winner, Some(Team::Player), "B：第 3 回合仍控制全部");
}

/// C 坚守：到游戏结束回合时仍控制任意一个关键据点即胜；双方都满足则平局。
#[test]
fn campaign_victory_rule_c_hold_any_at_end() {
    let cm = campaign_map_for_victory(
        VictoryRule::CaptureAllBeforeTurn { turn: 1 },
        VictoryRule::HoldAnyAtEnd,
        3,
    );
    let mut g = GameState::new_custom_deploy(3, cm);
    let o1 = hex::axial_from_offset(5, 2);
    let o2 = hex::axial_from_offset(6, 2);
    g.keypoints.get_mut(&o1).unwrap().controller = Team::Ai;
    g.keypoints.get_mut(&o2).unwrap().controller = Team::Ai;
    // 推进到第 4 回合（> 结束回合 3）→ 结算
    for _ in 0..3 {
        g.begin_turn(Team::Ai);
        g.begin_turn(Team::Player);
    }
    assert_eq!(g.winner, Some(Team::Ai), "C：红方结束时仍控制据点");
    assert!(g.game_over());

    // 双方在结束回合各控制一个目标 → 平局
    let cm2 = campaign_map_for_victory(
        VictoryRule::HoldAnyAtEnd,
        VictoryRule::HoldAnyAtEnd,
        3,
    );
    let mut g2 = GameState::new_custom_deploy(4, cm2);
    g2.keypoints.get_mut(&o1).unwrap().controller = Team::Player;
    g2.keypoints.get_mut(&o2).unwrap().controller = Team::Ai;
    for _ in 0..3 {
        g2.begin_turn(Team::Ai);
        g2.begin_turn(Team::Player);
    }
    assert_eq!(g2.winner, None, "双方都满足 C → 平局");
    assert!(g2.is_draw() && g2.game_over());
}

/// A 超时未占全不立即结束；到达游戏结束回合仍无人满足 → 平局。
#[test]
fn campaign_victory_rule_a_timeout_draw() {
    let cm = campaign_map_for_victory(
        VictoryRule::CaptureAllBeforeTurn { turn: 2 },
        VictoryRule::CaptureAllBeforeTurn { turn: 2 },
        5,
    );
    let mut g = GameState::new_custom_deploy(5, cm);
    // 推进到第 3 回合（已超时）但未占全
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // turn 2
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // turn 3
    assert_eq!(g.winner, None, "A 超时不立即判负");
    assert!(!g.game_over(), "超时后对局继续");
    // 推进到第 6 回合（> 结束回合 5）
    for _ in 0..3 {
        g.begin_turn(Team::Ai);
        g.begin_turn(Team::Player);
    }
    assert_eq!(g.winner, None);
    assert!(g.is_draw() && g.game_over(), "无人满足 → 平局结束");
}

/// 大本营失守 → 其连通区停用；夺回后恢复；大本营不参与胜负判定。
#[test]
fn campaign_hq_region_disabled_when_lost() {
    let cm = campaign_map_for_victory(
        VictoryRule::CaptureAllImmediate,
        VictoryRule::CaptureAllImmediate,
        0,
    );
    let mut g = GameState::new_custom_deploy(6, cm);
    let hq = hex::axial_from_offset(0, 0);
    let c1 = hex::axial_from_offset(0, 0);
    let c2 = hex::axial_from_offset(0, 1);
    assert!(g.in_deploy_zone(Team::Player, c1));
    assert!(g.in_deploy_zone(Team::Player, c2));
    assert_eq!(g.deploy_cells(Team::Player).len(), 2);
    // 大本营被敌方夺取
    g.keypoints.get_mut(&hq).unwrap().controller = Team::Ai;
    assert!(!g.in_deploy_zone(Team::Player, c1), "大本营失守 → 连通区停用");
    assert!(!g.in_deploy_zone(Team::Player, c2));
    assert!(g.deploy_cells(Team::Player).is_empty());
    // 夺取大本营本身不判胜
    assert_eq!(g.winner, None, "大本营易手不判胜负");
    // 夺回
    g.keypoints.get_mut(&hq).unwrap().controller = Team::Player;
    assert!(g.in_deploy_zone(Team::Player, c1), "夺回后恢复可用");
}

/// maps/战役示例.json：编辑器战役模式的示例地图可直接加载开战。
#[test]
fn campaign_sample_map_loads() {
    let path = std::path::Path::new("maps/战役示例.json");
    if !path.exists() {
        return;
    }
    let cm = crate::mapdef::CustomMap::load(path).expect("加载战役示例");
    assert!(cm.campaign, "示例应为战役模式");
    assert!(cm.validate().is_ok(), "示例应通过校验: {:?}", cm.validate());
    assert!(cm.warnings().is_empty(), "示例战役数据应完整: {:?}", cm.warnings());
    let g = GameState::new_custom_deploy(5, cm);
    assert!(!g.deploying, "战役示例直接开战");
    assert_eq!(g.turn, 1);
    assert!(g.hq_pos(Team::Player).is_some(), "玩家大本营中心");
    assert!(g.hq_pos(Team::Ai).is_some(), "AI 大本营中心");
    assert!(g.unit_at(hex::axial_from_offset(1, 4)).is_some());
    assert!(g.unit_at(hex::axial_from_offset(18, 4)).is_some());
    // 示例中的运输单位带初始搭载
    let truck = g.unit_at(hex::axial_from_offset(0, 3)).expect("示例卡车已就位");
    assert_eq!(truck.passengers.len(), 2, "示例卡车载 2 名步枪手");
    let heli = g.unit_at(hex::axial_from_offset(2, 3)).expect("示例运输直升机已就位");
    assert_eq!(heli.passengers.len(), 1, "示例运输直升机载特战小队");
    assert!(
        g.map.roads.contains(&hex::axial_from_offset(2, 6)),
        "战役示例含道路地形"
    );
    assert!(g.in_deploy_zone(Team::Player, hex::axial_from_offset(0, 3)));
    assert!(!g.in_deploy_zone(Team::Player, hex::axial_from_offset(0, 0)));
}

#[test]
fn scan_maps_dir_finds_sample() {
    // maps/ 目录里的示例地图可被扫描与加载（若存在；避免 CI 依赖跳过）
    let maps = crate::mapdef::CustomMap::scan_all();
    if let Some((name, path)) = maps.iter().find(|(n, _)| n.contains("渡口")) {
        let cm = crate::mapdef::CustomMap::load(path).unwrap();
        assert!(cm.validate().is_ok());
        let g = GameState::new_custom_deploy(3, cm);
        assert_eq!(g.level, Level::Custom);
        assert_eq!(g.map.cols, 27);
        assert_eq!(g.map.rows, 13);
        assert!(!g.map.obstacles.is_empty());
        assert!(!g.map.buildings.is_empty());
        assert!(g.deploy_zone(Team::Ai).contains(&24));
        assert_eq!(name, "渡口攻防");
    }
}

#[test]
fn test_smoke_concealment_and_hit() {
    // 烟雾新规则：隐蔽×2、被命中率×0.6
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    // 只留坦克 A（隐蔽1）与敌方步枪手（隐蔽2）
    let a_h = {
        let u = g.units_of(Team::Player).iter().find(|u| u.kind == UnitKind::Tank).unwrap().pos;
        u
    };
    let t_h = hex::axial_from_offset(9, 4);
    let mut t = Unit::new(UnitKind::Rifleman, Team::Ai, t_h);
    t.label = 'x';
    g.units.insert(t_h, t);
    g.units.retain(|_, u| u.team != Team::Player || u.pos == a_h);
    g.units.retain(|_, u| u.team != Team::Ai || u.pos == t_h);
    g.air_units.clear();
    // 坦克放 (3,4)，与目标距离 6（坦克视野 5 → 无烟雾时不可见）
    let mut a = g.units.remove(&a_h).unwrap();
    a.pos = hex::axial_from_offset(3, 4);
    g.units.insert(a.pos, a.clone());
    assert!(!g.is_unit_visible(Team::Player, t_h), "距离 6 > 视野 5 不可见");
    // 放烟雾到目标格 → 隐蔽×2 让发现更难（不改变可见性逻辑本身，但被命中率应×0.6）
    g.smoke.insert(t_h, 2);
    // 近距离可见：把坦克放到 (5,4)（距离 4 ≤ 视野5，但烟雾隐蔽×2 → 步枪手隐蔽2×2=4 → 需 5/4=1 格！）
    // 验证隐蔽×2：距离 4 时应不可见
    let mut a2 = g.units.remove(&a.pos).unwrap();
    a2.pos = hex::axial_from_offset(5, 4);
    g.units.insert(a2.pos, a2.clone());
    assert!(
        !g.is_unit_visible(Team::Player, t_h),
        "烟雾中步兵隐蔽 2×2=4，距离 4 > 视野5/4=1 → 不可见"
    );
    // 贴脸距离 1（同行相邻格 offset 8,4 → 9,4）→ 可见且命中率 ×0.6
    let mut a3 = g.units.remove(&a2.pos).unwrap();
    a3.pos = hex::axial_from_offset(8, 4);
    g.units.insert(a3.pos, a3.clone());
    assert!(g.is_unit_visible(Team::Player, t_h), "距离1 应可见");
    let out = g.attack(a3.pos, t_h).expect("可攻击");
    assert!(out.message.contains("烟雾×0.6") || out.message.contains("×0.6"), "{}", out.message);
}

#[test]
fn test_smoke_blocks_los_like_building() {
    // 烟雾与楼房一样阻断直射视线（has_los_ex），端点格不阻挡
    let mut g = GameState::new_seeded(5);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    let from = hex::axial_from_offset(3, 4);
    let to = hex::axial_from_offset(9, 4);
    assert!(g.map.has_los_ex(from, to, &g.smoke), "开阔地直射通畅");
    // 中间放烟雾（(6,4)）→ 阻断（与楼房一致）
    g.smoke.insert(hex::axial_from_offset(6, 4), 2);
    assert!(
        !g.map.has_los_ex(from, to, &g.smoke),
        "穿越烟雾内部应阻断直射"
    );
    // 端点在烟雾中不阻挡（目标在烟雾里仍可被直射）
    let to2 = hex::axial_from_offset(6, 4);
    assert!(
        g.map.has_los_ex(from, to2, &g.smoke),
        "目标格为烟雾格（端点豁免）不阻挡"
    );
    // 楼房对照：同样行为
    g.smoke.clear();
    g.map.add_building(6, 4);
    assert!(!g.map.has_los(from, to), "楼房同样阻断");
    assert!(g.map.has_los(from, to2), "端点楼房不阻挡");
}

#[test]
fn test_tank_blocked_by_building_despite_shared_vision() {
    // 坦克 A 在 (3,4)，敌方坦克在 (9,4)（距离 6，射程内）；
    // 中间 (6,4) 是楼房；我方步枪手在敌方坦克旁 (8,4)（共享视野能看到敌方坦克）。
    // 直射视线被楼房阻断 → 坦克 A 不能开火（即使有共享视野）。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.map.add_building(6, 4); // 中间的楼房

    let a_h = hex::axial_from_offset(3, 4);
    let r_h = hex::axial_from_offset(8, 4); // 我方步枪手（在敌方坦克旁 1 格）
    let e_h = hex::axial_from_offset(9, 4); // 敌方坦克

    g.units.retain(|_, u| u.team != Team::Player);
    g.units.retain(|_, u| u.team != Team::Ai);
    g.air_units.clear();
    g.units.insert(a_h, Unit::new(UnitKind::Tank, Team::Player, a_h));
    g.units.insert(r_h, Unit::new(UnitKind::Rifleman, Team::Player, r_h));
    g.units.insert(e_h, Unit::new(UnitKind::Tank, Team::Ai, e_h));

    // 前置：共享视野确认（步枪手能看到敌方坦克 → 全队可见）
    assert!(g.is_unit_visible(Team::Player, e_h), "共享视野应能看到敌方坦克");
    // 距离 6 在坦克射程内
    assert_eq!(Hex::distance(a_h, e_h), 6);
    // 视线被楼房阻断
    assert!(!g.map.has_los(a_h, e_h), "楼房应阻断直射视线");

    // 开火应被禁止（楼房阻隔，即使有共享视野）
    let err = g.attack(a_h, e_h).unwrap_err();
    assert!(
        err.contains("视线") || err.contains("阻隔") || err.contains("直射"),
        "应提示视线被阻隔: {}",
        err
    );
    // 被拒绝的攻击不消耗行动与弹药
    let t = g.unit_at(a_h).unwrap();
    assert_eq!(t.actions_left, 2, "被拒攻击不应消耗行动");
    assert_eq!(t.ammo, 42, "被拒攻击不应消耗弹药");
}

#[test]
fn test_heli_above_own_infantry_attacks_as_heli() {
    // 己方武装直升机飞在己方步兵上方（同格），攻击 6 格外的敌方坦克：
    // 攻击者应是直升机（射程 6/攻 4），而非同格步兵（射程 3）。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.retain(|_, u| u.team != Team::Player);
    g.units.retain(|_, u| u.team != Team::Ai);
    g.air_units.clear();
    let h_h = hex::axial_from_offset(3, 4);
    let e_h = hex::axial_from_offset(9, 4); // 距离 6：直升机射程内，步兵射程外
    g.units.insert(h_h, Unit::new(UnitKind::Rifleman, Team::Player, h_h));
    g.air_units.insert(h_h, Unit::new(UnitKind::AttackHeli, Team::Player, h_h));
    g.units.insert(e_h, Unit::new(UnitKind::Tank, Team::Ai, e_h));
    assert!(g.is_unit_visible(Team::Player, e_h), "直升机视野 9 应看到距离 6 的坦克");
    assert_eq!(Hex::distance(h_h, e_h), 6, "距离 6");
    // 用空中层攻击：应成功（直升机攻 4 > 坦克护甲 3）
    match g.attack_air(h_h, e_h) {
        Ok(out) => assert!(out.hit || !out.hit, "直升机攻击成功: {}", out.message),
        Err(e) => panic!("直升机攻击被误拒: {}", e),
    }
    // 对照：默认攻击（地面优先）会错误地把步兵当攻击者（射程 3 超距）
    let err = g.attack(h_h, e_h).unwrap_err();
    assert!(
        err.contains("射程") || err.contains("攻击"),
        "默认 attack 会误用步兵: {}",
        err
    );
}

#[test]
fn test_air_to_air_los_exemption() {
    // 规则：地面防空打空中受 LOS 限制；空中单位互相攻击不受 LOS 限制；
    // 空对地仍受 LOS 限制。全部用中间楼房 (6,4) 阻断直射。
    let mk = || {
        let mut g = GameState::new_seeded(5);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.map.add_building(6, 4);
        g.units.retain(|_, u| u.team != Team::Player);
        g.units.retain(|_, u| u.team != Team::Ai);
        g.air_units.clear();
        g
    };
    let aa_h = hex::axial_from_offset(3, 4);
    let h_h = hex::axial_from_offset(3, 4); // 己方武直位置
    let e_heli = hex::axial_from_offset(9, 4);

    // ① 地面防空（防空导弹发射车）打空中：受 LOS → 被拒
    // （无人机视野 12 可看穿楼房，提供共享视野，确保目标是"看得到但打不到"）
    let mut g1 = mk();
    g1.units.insert(aa_h, Unit::new(UnitKind::AaLauncher, Team::Player, aa_h));
    g1.air_units.insert(hex::axial_from_offset(5, 1), Unit::new(UnitKind::Drone, Team::Player, hex::axial_from_offset(5, 1)));
    g1.air_units.insert(e_heli, Unit::new(UnitKind::AttackHeli, Team::Ai, e_heli));
    assert!(g1.is_unit_visible(Team::Player, e_heli), "共享视野应看到敌方直升机（无人机看穿楼房）");
    assert!(!g1.map.has_los(aa_h, e_heli), "楼房应阻断直射");
    let err = g1.attack(aa_h, e_heli).unwrap_err();
    assert!(
        err.contains("视线") || err.contains("阻隔"),
        "地面防空打空中应受 LOS 限制: {}",
        err
    );

    // ② 空中互打：不受 LOS → 成功
    let mut g2 = mk();
    g2.air_units.insert(h_h, Unit::new(UnitKind::AttackHeli, Team::Player, h_h));
    g2.air_units.insert(e_heli, Unit::new(UnitKind::AttackHeli, Team::Ai, e_heli));
    assert!(!g2.map.has_los(h_h, e_heli), "楼房应阻断直射");
    assert!(
        g2.attack_air(h_h, e_heli).is_ok(),
        "空中单位互相攻击不受 LOS 限制"
    );

    // ③ 空对地（武直打坦克）：仍受 LOS → 被拒
    let mut g3 = mk();
    g3.air_units.insert(h_h, Unit::new(UnitKind::AttackHeli, Team::Player, h_h));
    g3.units.insert(e_heli, Unit::new(UnitKind::Tank, Team::Ai, e_heli));
    let err3 = g3.attack_air(h_h, e_heli).unwrap_err();
    assert!(
        err3.contains("视线") || err3.contains("阻隔"),
        "空对地仍受 LOS 限制: {}",
        err3
    );
}

#[test]
fn test_adjacent_building_to_building_fire() {
    // 步兵从楼房 A 攻击紧邻楼房 B 内的步兵：
    // 距离 1（射程内）、视野内（隐蔽2 → 需 视野/2=1 格，紧邻恰好满足）、
    // LOS 端点豁免（攻击者/目标所在楼房不阻挡）→ 应可开火（楼内命中 ×0.6）。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.retain(|_, u| u.team != Team::Player);
    g.units.retain(|_, u| u.team != Team::Ai);
    g.air_units.clear();
    let a_h = hex::axial_from_offset(3, 3);
    let t_h = hex::axial_from_offset(4, 3);
    g.map.add_building(3, 3);
    g.map.add_building(4, 3);
    g.units.insert(a_h, Unit::new(UnitKind::Rifleman, Team::Player, a_h));
    g.units.insert(t_h, Unit::new(UnitKind::Rifleman, Team::Ai, t_h));
    // 前置条件
    assert_eq!(Hex::distance(a_h, t_h), 1, "紧邻");
    assert!(g.is_unit_visible(Team::Player, t_h), "紧邻楼内步兵应在视野内（隐蔽2需1格路程）");
    assert!(g.map.has_los(a_h, t_h), "端点楼房不阻挡 LOS（紧邻互射）");
    // 开火应成功，且命中率受楼房 ×0.6 减益
    let out = g.attack(a_h, t_h).expect("紧邻楼房间步兵应可开火");
    assert!(
        out.message.contains("楼房×0.6") || out.message.contains("×0.6"),
        "楼内目标应有 ×0.6 减益: {}",
        out.message
    );
}

#[test]
fn test_aa_from_building_to_aircraft() {
    // 步兵在楼房内（或楼旁）对无其它遮挡的飞行器发射防空导弹：
    // 攻击者所在楼房是 LOS 端点（豁免），中间无遮挡 → 可发射。
    let mk = || {
        let mut g = GameState::new_seeded(5);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.retain(|_, u| u.team != Team::Player);
        g.units.retain(|_, u| u.team != Team::Ai);
        g.air_units.clear();
        g
    };
    let aa_h = hex::axial_from_offset(3, 3);
    let heli_h = hex::axial_from_offset(7, 3); // 距离 4：防空手视野 4 内、射程 8 内

    // ① 防空导弹手在楼房内 → 对 4 格外直升机发射成功
    let mut g1 = mk();
    g1.map.add_building(3, 3);
    g1.units.insert(aa_h, Unit::new(UnitKind::AaInfantry, Team::Player, aa_h));
    g1.air_units.insert(heli_h, Unit::new(UnitKind::AttackHeli, Team::Ai, heli_h));
    assert_eq!(Hex::distance(aa_h, heli_h), 4);
    assert!(g1.is_unit_visible(Team::Player, heli_h), "楼内防空手视野 4 应看到距离 4 的直升机");
    assert!(g1.map.has_los(aa_h, heli_h), "攻击者所在楼房（端点）不阻挡 LOS");
    assert!(
        g1.attack(aa_h, heli_h).is_ok(),
        "楼内步兵应对无遮挡飞行器发射防空导弹"
    );

    // ② 特战小队（Stinger 模式）在楼房旁（非楼内）→ 同样可发射
    let mut g2 = mk();
    g2.units.insert(aa_h, Unit::new(UnitKind::SpecialForces, Team::Player, aa_h));
    g2.air_units.insert(heli_h, Unit::new(UnitKind::AttackHeli, Team::Ai, heli_h));
    let _sf = g2.unit_at(aa_h).unwrap().clone();
    // 切换 Stinger 模式（A 键）
    g2.toggle_aa_mode(aa_h).ok();
    let sf2 = g2.unit_at(aa_h).unwrap();
    assert!(sf2.is_stinger_mode(), "特战应处于 Stinger 模式");
    assert!(
        g2.attack(aa_h, heli_h).is_ok(),
        "楼旁步兵对无遮挡飞行器发射防空导弹"
    );

    // ③ 对照：中间隔着另一栋楼房 → LOS 被挡 → 不可发射
    let mut g3 = mk();
    g3.map.add_building(3, 3);
    g3.map.add_building(5, 3); // 中间的楼房（from/to 之外）
    g3.units.insert(aa_h, Unit::new(UnitKind::AaInfantry, Team::Player, aa_h));
    g3.air_units.insert(heli_h, Unit::new(UnitKind::AttackHeli, Team::Ai, heli_h));
    // 己方武装直升机（视野 9 看穿楼房）提供共享视野，确保"看得到但打不到"
    g3.air_units.insert(hex::axial_from_offset(1, 1), Unit::new(UnitKind::AttackHeli, Team::Player, hex::axial_from_offset(1, 1)));
    assert!(g3.is_unit_visible(Team::Player, heli_h), "共享视野应可见");
    assert!(!g3.map.has_los(aa_h, heli_h), "中间楼房应阻断直射");
    let err = g3.attack(aa_h, heli_h).unwrap_err();
    assert!(
        err.contains("视线") || err.contains("阻隔"),
        "中间楼房阻隔时不可发射: {}",
        err
    );
}

#[test]
fn test_aa_hits_heli_above_building() {
    // 直升机停在楼房上方（楼顶），防空手在 4 格外、中间无其它遮挡：
    // 目标所在楼房是 LOS 端点（豁免）→ 防空导弹应能命中楼顶直升机。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.retain(|_, u| u.team != Team::Player);
    g.units.retain(|_, u| u.team != Team::Ai);
    g.air_units.clear();
    let aa_h = hex::axial_from_offset(3, 3);
    let roof = hex::axial_from_offset(7, 3); // 楼房
    g.map.add_building(7, 3);
    g.units.insert(aa_h, Unit::new(UnitKind::AaInfantry, Team::Player, aa_h));
    g.air_units.insert(roof, Unit::new(UnitKind::AttackHeli, Team::Ai, roof));
    // 前置：距离 4 在防空手视野 4 内；LOS 端点豁免（目标所在楼房不阻挡）
    assert_eq!(Hex::distance(aa_h, roof), 4);
    assert!(
        g.is_unit_visible(Team::Player, roof),
        "防空手视野 4 应看到楼顶直升机（BFS 到楼格距离 4）"
    );
    assert!(g.map.has_los(aa_h, roof), "目标所在楼房（端点）不阻挡 LOS");
    assert!(
        g.attack(aa_h, roof).is_ok(),
        "楼顶直升机应能被防空导弹命中"
    );
}

#[test]
fn test_sustain_points_granted_each_turn() {
    let mut g = GameState::new_seeded(5);
    g.enable_sustain(20, 30);
    let p0 = g.recruit_points.get(&Team::Player).copied().unwrap();
    let a0 = g.recruit_points.get(&Team::Ai).copied().unwrap();
    g.begin_turn(Team::Player); // 回合开始 → 双方加点
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), p0 + 20);
    assert_eq!(g.recruit_points.get(&Team::Ai).copied().unwrap(), a0 + 30);
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // 第 2 回合 → 再点
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), p0 + 40);
}

#[test]
fn test_reinforce_unit_rules() {
    // 追加部署：只能放在本方大本营中心（关键据点中心）周围 2 格内
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.enable_sustain(20, 20);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    g.recruit_points.insert(Team::Player, 60);
    g.recruit_points.insert(Team::Ai, 60);
    // 设玩家大本营中心于 (1,2)（关键据点；大本营不再是棋子）
    g.keypoints.insert(
        hex::axial_from_offset(1, 2),
        Keypoint {
            owner: Team::Player,
            controller: Team::Player,
            center: true,
        },
    );
    // 未进入追加部署状态 → 拒绝
    assert!(g.reinforce_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(1, 3)).is_err());
    g.sustain_deploying = true;
    // 大本营中心周围 2 格内成功：本回合不可行动
    let pos = hex::axial_from_offset(1, 3); // 距中心 (1,2) 1 格
    let label = g.reinforce_unit(Team::Player, UnitKind::Rifleman, pos).unwrap();
    assert_eq!(g.unit_at(pos).unwrap().label, label);
    assert_eq!(g.unit_at(pos).unwrap().actions_left, 0, "增援单位本回合不可行动");
    // 点数扣减（步枪手费用 12）
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), 60 - 12);
    // 超出大本营中心 2 格（(5,2) 距中心 (1,2) 4 格）→ 拒绝
    assert!(
        g.reinforce_unit(Team::Player, UnitKind::Tank, hex::axial_from_offset(5, 2)).is_err(),
        "只能部署在大本营中心周围 2 格内"
    );
}

#[test]
fn test_reinforce_unit_now_ignores_gui_toggle() {
    // 命令式追加部署（终端 / agent）：不依赖 GUI 的 sustain_deploying 切换，
    // 但未开启 sustain 时仍然拒绝。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let pos = hex::axial_from_offset(1, 3);
    assert!(
        g.reinforce_unit_now(Team::Player, UnitKind::Rifleman, pos).is_err(),
        "未开启可持续部署时应拒绝"
    );
    g.enable_sustain(10, 20);
    g.recruit_points.insert(Team::Player, 50);
    g.keypoints.insert(
        hex::axial_from_offset(1, 2),
        Keypoint {
            owner: Team::Player,
            controller: Team::Player,
            center: true,
        },
    );
    assert!(!g.sustain_deploying, "命令式部署不依赖 GUI 切换状态");
    let label = g
        .reinforce_unit_now(Team::Player, UnitKind::Rifleman, pos)
        .expect("sustain 模式且轮到自己时应能直接部署");
    assert_eq!(g.unit_at(pos).unwrap().label, label);
    assert_eq!(g.unit_at(pos).unwrap().actions_left, 0);
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), 50 - 12);
    // 点数不足 → 拒绝
    g.recruit_points.insert(Team::Player, 5);
    let denied = g.reinforce_unit_now(Team::Player, UnitKind::HeavyTank, hex::axial_from_offset(2, 2));
    assert!(denied.is_err(), "点数不足应拒绝: {:?}", denied);
}

#[test]
fn test_start_sustain_multiplayer_spawns_keypoints() {
    // 多人开局（预置部队、无部署阶段）：直接进入可持续部署需要
    // ① 双方各 3 个关键据点（否则没有大本营，追加部署会失败）；
    // ② 初始点数与每回合收入。
    let mut g = GameState::new_seeded_level(7, Level::OpenField);
    assert!(g.keypoints.is_empty(), "预置对局默认没有关键据点");
    g.start_sustain_multiplayer(10, 20, 80, 60);
    assert!(g.sustain);
    assert_eq!(g.sustain_per_turn.get(&Team::Player).copied().unwrap(), 10);
    assert_eq!(g.sustain_per_turn.get(&Team::Ai).copied().unwrap(), 20);
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), 80);
    assert_eq!(g.recruit_points.get(&Team::Ai).copied().unwrap(), 60);
    let blue_kp = g.keypoints.values().filter(|k| k.owner == Team::Player).count();
    let red_kp = g.keypoints.values().filter(|k| k.owner == Team::Ai).count();
    assert_eq!(blue_kp, 3, "蓝方应有 3 个关键据点");
    assert_eq!(red_kp, 3, "红方应有 3 个关键据点");
    assert!(g.hq_pos(Team::Player).is_some());
    assert!(g.hq_pos(Team::Ai).is_some());
    // 第 1 回合开始：双方再获得每回合点数
    g.begin_turn(Team::Player);
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), 90);
    assert_eq!(g.recruit_points.get(&Team::Ai).copied().unwrap(), 80);
    // 全灭不再立即判负：sustain 模式的胜负只看关键据点/胜负标记
    g.units.retain(|_, u| u.team != Team::Ai);
    g.air_units.retain(|_, u| u.team != Team::Ai);
    assert!(!g.game_over(), "sustain 模式下一方全灭不算结束（仍可增援）");
}

#[test]
fn test_recruit_unit_two_phase_area() {
    // 多人开局不预置棋子：第 1 回合可在本方出发区域招募（本回合即可行动），
    // 第 2 回合起只能在大本营中心周围 2 格内（当回合不可行动）。
    let mut g = GameState::new_sustain_multiplayer(21, Level::OpenField);
    assert!(g.units.is_empty() && g.air_units.is_empty(), "多人开局不应预置棋子");
    assert_eq!(g.recruit_zone_turn, 1);
    g.map.obstacles.clear();
    g.map.water.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.start_sustain_multiplayer(10, 10, 100, 100);
    g.begin_turn(Team::Player); // turn = 1
    let zone_hex = hex::axial_from_offset(1, 1);
    let label = g
        .recruit_unit(Team::Player, UnitKind::Rifleman, zone_hex)
        .expect("第 1 回合应在出发区域招募成功");
    assert_eq!(g.unit_at(zone_hex).unwrap().label, label);
    assert!(
        g.unit_at(zone_hex).unwrap().actions_left > 0,
        "第 1 回合招募的单位本回合即可行动"
    );
    assert_eq!(g.recruit_points.get(&Team::Player).copied().unwrap(), 110 - 12);
    // 第 1 回合也可一次性招募「已装载」的运输单位（载具 + 货物总费用）
    let truck_hex = hex::axial_from_offset(1, 2);
    let before = g.recruit_points[&Team::Player];
    g.recruit_unit_with_cargo(
        Team::Player,
        UnitKind::Truck,
        truck_hex,
        &[UnitKind::Rifleman, UnitKind::Rifleman],
    )
    .expect("首回合可招募已装载卡车");
    assert_eq!(
        g.unit_at(truck_hex).unwrap().passengers.len(),
        2,
        "卡车带 2 名步枪手入场"
    );
    assert_eq!(
        g.recruit_points[&Team::Player],
        before - 8 - 24,
        "总费用 = 卡车 8 + 2×12"
    );
    assert!(
        g.recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(13, 6)).is_err(),
        "出发区域之外不能招募"
    );
    // 第 2 回合：出发区域关闭，只能在大本营周围 2 格内
    g.begin_turn(Team::Ai);
    g.begin_turn(Team::Player); // turn = 2
    assert_eq!(g.turn, 2);
    let hq = g.hq_pos(Team::Player).expect("sustain 模式应设立大本营");
    // 出发区域内、但离大本营超过 2 格的空格：第 2 回合应被拒绝
    let far_zone = g
        .deploy_zone(Team::Player)
        .iter()
        .flat_map(|c| (0..g.map.rows).map(move |r| (*c, r)))
        .map(|(c, r)| hex::axial_from_offset(c, r))
        .find(|h| g.map.contains(*h) && Hex::distance(*h, hq) > 2 && g.unit_at(*h).is_none())
        .expect("出发区域内应有远离大本营的空格");
    let err = g
        .recruit_unit(Team::Player, UnitKind::Rifleman, far_zone)
        .unwrap_err();
    assert!(err.contains("2 格"), "{}", err);
    let spot = hq
        .neighbors()
        .into_iter()
        .find(|h| g.map.contains(*h) && g.unit_at(*h).is_none())
        .expect("大本营旁应有空格");
    let l2 = g
        .recruit_unit(Team::Player, UnitKind::Tank, spot)
        .expect("第 2 回合应能在大本营旁招募");
    assert_eq!(g.unit_at(spot).unwrap().label, l2);
    assert_eq!(
        g.unit_at(spot).unwrap().actions_left,
        0,
        "第 2 回合招募的单位当回合不可行动"
    );
    // 单机对局（出发区域走部署阶段）没有招募回合：recruit_unit 拒绝
    let mut solo = GameState::new_seeded(3);
    assert!(solo
        .recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(1, 1))
        .is_err());
}

#[test]
fn test_keypoint_capture_and_victory() {
    // 新胜利条件：同时控制双方全部 6 个关键据点 → 胜利（大本营不再是棋子）。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.enable_sustain(20, 20);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    // 玩家 3 个据点：中心 (1,2) + 2 个
    let pc = hex::axial_from_offset(1, 2);
    let p2 = hex::axial_from_offset(1, 3);
    let p3 = hex::axial_from_offset(2, 2);
    for (h, c) in [(pc, true), (p2, false), (p3, false)] {
        g.keypoints.insert(
            h,
            Keypoint {
                owner: Team::Player,
                controller: Team::Player,
                center: c,
            },
        );
    }
    // AI 3 个据点
    let ac = hex::axial_from_offset(20, 2);
    let a2 = hex::axial_from_offset(20, 3);
    let a3 = hex::axial_from_offset(21, 2);
    for (h, c) in [(ac, true), (a2, false), (a3, false)] {
        g.keypoints.insert(
            h,
            Keypoint {
                owner: Team::Ai,
                controller: Team::Ai,
                center: c,
            },
        );
    }
    assert!(!g.controls_all_keypoints(Team::Player), "初始未控制全部");
    assert_eq!(g.game_over(), false, "未控制全部不结束");
    // 空中棋子不能占领：武直飞入 AI 中心据点 → 控制权不变
    let heli_from = hex::axial_from_offset(19, 2);
    g.air_units
        .insert(heli_from, Unit::new(UnitKind::AttackHeli, Team::Player, heli_from));
    g.move_unit(heli_from, &[heli_from, ac], true).unwrap();
    assert_eq!(
        g.keypoints.get(&ac).unwrap().controller,
        Team::Ai,
        "空中棋子不能占领关键据点"
    );
    // 玩家步兵踏入 AI 据点 a2 → 占领（颜色翻转）
    let p_inf = hex::axial_from_offset(19, 3);
    g.units
        .insert(p_inf, Unit::new(UnitKind::Rifleman, Team::Player, p_inf));
    g.move_unit(p_inf, &[p_inf, a2], false).unwrap();
    assert_eq!(
        g.keypoints.get(&a2).unwrap().controller,
        Team::Player,
        "陆军踏入敌方据点即占领"
    );
    // 夺回：玩家驻守步兵撤离 a2 后，AI 步兵再踏入 → 翻转回 AI
    g.units.remove(&a2); // 玩家步兵撤出（占领持续，直到敌方踏入）
    let ai_inf = hex::axial_from_offset(19, 3);
    g.units
        .insert(ai_inf, Unit::new(UnitKind::Rifleman, Team::Ai, ai_inf));
    g.move_unit(ai_inf, &[ai_inf, a2], false).unwrap();
    assert_eq!(
        g.keypoints.get(&a2).unwrap().controller,
        Team::Ai,
        "被占领的据点可被反击夺回"
    );
    // 胜利：玩家已控制 pc/p2/p3/ac/a3（5 个），a2 为 AI 控制；
    // 玩家坦克踏入 a2（敌方控制的据点）→ 控制全部 6 个 → 判胜
    g.keypoints.get_mut(&pc).unwrap().controller = Team::Player;
    g.keypoints.get_mut(&p2).unwrap().controller = Team::Player;
    g.keypoints.get_mut(&p3).unwrap().controller = Team::Player;
    g.keypoints.get_mut(&ac).unwrap().controller = Team::Player;
    g.keypoints.get_mut(&a3).unwrap().controller = Team::Player;
    g.units.remove(&a2); // AI 驻守步兵撤出
    g.units
        .insert(
            hex::axial_from_offset(19, 3),
            Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(19, 3)),
        );
    g.move_unit(hex::axial_from_offset(19, 3), &[hex::axial_from_offset(19, 3), a2], false)
        .unwrap();
    assert_eq!(g.winner, Some(Team::Player), "同时控制全部 6 个关键据点 → 胜利");
    assert!(g.game_over(), "关键据点全控 → 游戏结束");
}

#[test]
fn test_ai_sustain_reinforce_and_assault() {
    // AI 每回合自动增援（待招兵种计划：攒点 → 买入 1 个 → 换下一个）
    let mut g = GameState::new_seeded(7);
    g.begin_turn(Team::Player);
    g.enable_sustain(50, 50);
    g.keypoints.insert(
        hex::axial_from_offset(24, 6),
        Keypoint {
            owner: Team::Ai,
            controller: Team::Ai,
            center: true,
        },
    );
    g.keypoints.insert(
        hex::axial_from_offset(24, 7),
        Keypoint {
            owner: Team::Ai,
            controller: Team::Ai,
            center: false,
        },
    );
    g.recruit_points.insert(Team::Ai, 50);
    let n0 = g.units_of(Team::Ai).len();
    // 增援前已有的标签集合：新单位必须带来新标签（双方统一数字编号后不能再按字母区间判断）
    let labels_before: BTreeSet<char> = g.units_of(Team::Ai).iter().map(|u| u.label).collect();
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    // 增援 1 个新单位（标签递增；装载/战斗可能使 units_of 变化，以新单位存在为准）
    assert!(
        log.iter().any(|m| m.contains("AI增援")),
        "AI 应增援: {:?}",
        log.iter().take(3).collect::<Vec<_>>()
    );
    assert!(
        g.units_of(Team::Ai)
            .iter()
            .any(|u| !labels_before.contains(&u.label)),
        "应出现增援的新单位: {n0} -> {} 日志={:?}",
        g.units_of(Team::Ai).len(),
        log.iter().take(10).collect::<Vec<_>>()
    );
    // 有下一个待招计划
    assert!(g.ai_recruit_plan.get(&Team::Ai).is_some(), "AI 应有待招计划");

    // 总攻标准：歼灭 ≥ P-10（P = 初始部署点数）
    let mut g2 = GameState::new_seeded(11);
    g2.begin_turn(Team::Player);
    g2.enable_sustain(10, 10);
    g2.initial_points.insert(Team::Player, 100); // P = 100
    g2.killed_value.insert(Team::Player, 89); // 89 < 90 → 未触发
    assert!(!g2.sustain_assault_ready(Team::Ai), "歼灭 89 分 < P-10=90 → 不总攻");
    g2.killed_value.insert(Team::Player, 90); // 90 ≥ 90 → 触发
    assert!(g2.sustain_assault_ready(Team::Ai), "歼灭 ≥ P-10 → 总攻");
    let mut log2 = Vec::new();
    ai::run_ai_turn(&mut g2, Team::Ai, &mut log2);
    assert!(
        log2.iter().any(|m| m.contains("总攻")),
        "总攻宣言应出现: {:?}",
        log2.iter().find(|m| m.contains("总攻"))
    );
}

#[test]
fn test_keypoints_spawned_in_zone() {
    // 可持续部署：双方大本营区域各生成 3 个关键据点（中心 + 半径 2 内 2 个随机格）；
    // 大本营中心不位于岩石/水域，且在本方部署区域内；不再生成指挥部棋子。
    let mut g = GameState::new_deploy(5);
    g.enable_sustain(20, 20);
    g.finish_deploy().unwrap();
    for team in [Team::Player, Team::Ai] {
        let mine: Vec<(&Hex, &Keypoint)> = g
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.owner == team)
            .collect();
        assert_eq!(mine.len(), 3, "{} 应有 3 个关键据点", team.cn());
        let center = mine.iter().find(|(_, kp)| kp.center).unwrap().0;
        assert!(!g.map.obstacles.contains(center), "大本营中心不位于岩石上");
        assert!(!g.map.water.contains(center), "大本营中心不位于水域上");
        let (col, _) = hex::offset_from_axial(*center);
        assert!(g.deploy_zone(team).contains(&col), "大本营中心在本方部署区域内");
        for (h, kp) in mine.iter().filter(|(_, kp)| !kp.center) {
            assert!(Hex::distance(*center, **h) <= 2, "据点在中心半径 2 内");
            assert!(
                !g.map.obstacles.contains(h) && !g.map.water.contains(h),
                "据点必须可站立（陆军要踏入占领）"
            );
            assert_eq!(kp.controller, team, "初始归本方控制");
        }
        assert!(
            !g.units_of(team).iter().any(|u| u.kind == UnitKind::Headquarters),
            "{} 大本营不再是棋子", team.cn()
        );
    }
}


#[test]
fn test_ai_records_enemy_center() {
    // AI 记录敌方大本营中心（关键据点中心，地图上始终可见）；总攻时朝敌方关键据点推进。
    let mut g = GameState::new_seeded(11);
    g.begin_turn(Team::Player);
    g.enable_sustain(10, 10);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    // 玩家大本营中心与一个普通据点（关键据点可见）
    let pc = hex::axial_from_offset(2, 3);
    g.keypoints.insert(
        pc,
        Keypoint {
            owner: Team::Player,
            controller: Team::Player,
            center: true,
        },
    );
    g.keypoints.insert(
        hex::axial_from_offset(1, 3),
        Keypoint {
            owner: Team::Player,
            controller: Team::Player,
            center: false,
        },
    );
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    assert_eq!(
        g.hq_seen.get(&Team::Ai).copied().flatten(),
        Some(pc),
        "AI 应记住敌方大本营中心"
    );
    // 总攻：歼灭 ≥ P-10 → 宣言总攻
    g.killed_value.insert(Team::Player, 90);
    assert!(g.sustain_assault_ready(Team::Ai), "歼灭 ≥ P-10 → 总攻");
    let mut log2 = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log2);
    assert!(
        log2.iter().any(|m| m.contains("总攻")),
        "总攻宣言应出现: {:?}",
        log2.iter().take(4).collect::<Vec<_>>()
    );
}

#[test]
fn test_ai_defense_mode() {
    // 全面防御：AI 指挥部 8 格内出现可见玩家单位 → AI 全力回防；
    // 8 格内无可见敌军 → 解除。
    let mut g = GameState::new_seeded(5);
    g.begin_turn(Team::Player);
    g.enable_sustain(20, 20);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    // AI 大本营中心与一个玩家单位（AI 可见、距中心 3 格）
    let hq = hex::axial_from_offset(25, 6);
    g.units.retain(|_, u| u.team != Team::Ai);
    g.air_units.retain(|_, u| u.team != Team::Ai);
    g.keypoints.insert(
        hq,
        Keypoint {
            owner: Team::Ai,
            controller: Team::Ai,
            center: true,
        },
    );
    let p_h = hex::axial_from_offset(22, 6); // 距 AI 大本营中心 3 格（武直视野覆盖）
    g.units.insert(p_h, Unit::new(UnitKind::Rifleman, Team::Player, p_h));
    g.air_units.insert(
        hex::axial_from_offset(21, 6),
        Unit::new(UnitKind::AttackHeli, Team::Ai, hex::axial_from_offset(21, 6)),
    );
    assert!(g.is_unit_visible(Team::Ai, p_h), "AI 应可见逼近的玩家单位");
    assert!(g.defense_triggered(Team::Ai), "指挥部 8 格内可见敌军 → 防御");
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    assert!(
        log.iter().any(|m| m.contains("防御") || m.contains("回防")),
        "AI 应转入防御: {:?}",
        log.iter().take(5).collect::<Vec<_>>()
    );
    // 玩家单位移出 8 格 → 解除
    g.units.remove(&p_h);
    g.units.insert(
        hex::axial_from_offset(15, 6),
        Unit::new(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(15, 6)),
    );
    assert!(!g.defense_triggered(Team::Ai), "8 格内无可见敌军 → 解除防御");
}

#[test]
fn test_test_mode_place_unit_and_ai_skip() {
    let mut g = GameState::new_seeded(1);
    g.test_mode = true;
    // 清空已有单位，便于在任意空位放置
    g.units.clear();
    g.air_units.clear();

    let h = hex::axial_from_offset(0, 0);
    assert!(g.test_place_unit(Team::Player, UnitKind::Tank, h).is_ok());
    assert!(g.unit_at(h).is_some(), "试验模式应能免费放置单位");

    // 地形限制仍然有效：地面单位不能上岩石
    let rock = g
        .map
        .obstacles
        .iter()
        .next()
        .copied()
        .unwrap_or_else(|| hex::axial_from_offset(4, 2));
    assert!(
        g.test_place_unit(Team::Ai, UnitKind::Rifleman, rock).is_err(),
        "试验模式也不能把地面单位放在岩石上"
    );

    // 试验模式下 AI 不行动
    let before = g.units_of(Team::Ai).len();
    let mut log = Vec::new();
    ai::run_ai_turn(&mut g, Team::Ai, &mut log);
    assert!(log.is_empty(), "试验模式 AI 不应产生行动日志: {:?}", log);
    assert_eq!(g.units_of(Team::Ai).len(), before, "试验模式 AI 不应部署/移动");
}

#[test]
fn test_enter_test_mode_clears_hq_keeps_units() {
    let mut g = GameState::new_deploy_level(1, Level::OpenField);
    g.enable_sustain(10, 20);
    let h = hex::axial_from_offset(0, 0);
    g.deploy_unit(Team::Player, UnitKind::Rifleman, h).unwrap();
    g.keypoints.insert(
        h,
        Keypoint {
            owner: Team::Player,
            controller: Team::Player,
            center: true,
        },
    );

    g.enter_test_mode();

    assert!(g.test_mode, "试验模式应开启");
    assert!(g.test_placing, "应自动进入放置棋子模式");
    assert!(!g.deploying, "应立即离开部署阶段");
    assert!(!g.sustain, "应关闭可持续部署/追加部署");
    assert!(g.keypoints.is_empty(), "双方大本营/关键据点应清空");
    assert!(g.unit_at(h).is_some(), "已部署棋子应保留在地图上");
}

#[test]
fn test_move_unit_air_ground_stack_decoupled() {
    let mut g = GameState::new_seeded(4);
    g.units.clear();
    g.air_units.clear();
    let h = hex::axial_from_offset(0, 0);
    let next = hex::axial_from_offset(1, 0);
    g.units.insert(h, Unit::new(UnitKind::Tank, Team::Player, h));
    g.air_units.insert(h, Unit::new(UnitKind::AttackHeli, Team::Player, h));
    g.begin_turn(Team::Player);

    // 移动空中层：只有直升机离开，地面坦克仍留在原格
    g.move_unit(h, &[h, next], true).unwrap();
    assert!(g.air_units.contains_key(&next), "直升机应移动到目标格");
    assert!(g.units.contains_key(&h), "地面坦克不应被移动");
    assert!(!g.air_units.contains_key(&h), "原格不应再有直升机");

    // 再移动地面层：地面坦克离开，空中层不受影响（当前空中层在 next）
    g.move_unit(h, &[h, next], false).unwrap();
    assert!(g.units.contains_key(&next), "地面坦克应移动到目标格");
    assert!(!g.units.contains_key(&h), "原格不应再有地面坦克");
    assert!(g.air_units.contains_key(&next), "直升机仍应在目标格，不受地面移动影响");
}


#[test]
fn test_tank_dual_weapon_mg_mode() {
    // 坦克/主战坦克：M 切换车载重机枪，弹药量与主炮弹药相同（42）
    let mut t = Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(0, 0));
    assert!(t.is_dual_weapon(), "坦克应有副武器（重机枪）");
    assert_eq!(t.missile_ammo, 42, "坦克机枪弹药量与主炮弹药相同");
    t.missile_mode = true;
    assert!(t.is_heavy_mg_mode(), "机枪模式应归类为重机枪");
    assert_eq!(t.eff_attack(), 1, "重机枪攻击力 1");
    assert_eq!(t.eff_hit_rate(), 60, "重机枪基础命中率 60%");
    assert_eq!(t.eff_range(), 4, "车载重机枪射程 4");
    assert_eq!(t.mode_name(), "重机枪");

    let mut ht = Unit::new(UnitKind::HeavyTank, Team::Player, hex::axial_from_offset(0, 0));
    assert!(ht.is_dual_weapon(), "主战坦克也应有重机枪副武器");
    assert_eq!(ht.missile_ammo, 42);
    ht.missile_mode = true;
    assert!(ht.is_heavy_mg_mode());
    assert_eq!(ht.eff_attack(), 1);
    assert_eq!(ht.eff_hit_rate(), 60);

    // 武器分类不再按攻击力数值判定：高攻的 ATGM/无人机等不属于坦克炮
    let z = hex::axial_from_offset(0, 0);
    assert!(Unit::new(UnitKind::Tank, Team::Player, z).is_tank_gun_mode());
    assert!(Unit::new(UnitKind::HeavyTank, Team::Player, z).is_tank_gun_mode());
    assert!(!Unit::new(UnitKind::HumveeTow, Team::Player, z).is_tank_gun_mode());
    assert!(!Unit::new(UnitKind::HumveeJavelin, Team::Player, z).is_tank_gun_mode());
    assert!(!Unit::new(UnitKind::Atgm, Team::Player, z).is_tank_gun_mode());
    assert!(!Unit::new(UnitKind::Drone, Team::Player, z).is_tank_gun_mode());
    assert!(!Unit::new(UnitKind::CavalryIfv, Team::Player, z).is_tank_gun_mode());
}

#[test]
fn test_vehicle_mg_same_roll_miss_still_suppresses() {
    // 重机枪：命中和压制由同一次随机数决定；未命中但随机数低于 90% 压制率时仍压制。
    for seed in 0..300u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let tank = hex::axial_from_offset(0, 0);
        let inf = hex::axial_from_offset(2, 0); // 距离 2，步兵可被坦克视野发现
        let mut t = Unit::new(UnitKind::Tank, Team::Player, tank);
        t.missile_mode = true;
        g.units.insert(tank, t);
        g.units.insert(inf, Unit::new(UnitKind::Rifleman, Team::Ai, inf));
        let out = g.attack(tank, inf).unwrap();
        let u = g.unit_at(inf).unwrap();
        if out.message.contains("未命中") && u.suppressed {
            assert_eq!(u.suppression_stacks, 1, "未命中也应获得 1 层压制");
            assert!(out.message.contains("压制"), "消息应提示压制: {}", out.message);
            return;
        }
    }
    panic!("未找到“未命中但仍压制”的随机种子");
}

#[test]
fn test_vehicle_autocannon_suppresses_infantry() {
    // 机关炮（侦察战车/步战车等攻击力 2 的装甲车辆直射武器）：攻击步兵基础 100% 压制。
    for seed in 0..300u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let scout = hex::axial_from_offset(0, 0);
        let inf = hex::axial_from_offset(2, 0);
        g.units.insert(scout, Unit::new(UnitKind::Scout, Team::Player, scout));
        g.units.insert(inf, Unit::new(UnitKind::Rifleman, Team::Ai, inf));
        let out = g.attack(scout, inf).unwrap();
        let u = g.unit_at(inf).unwrap();
        if out.message.contains("未命中") {
            assert!(u.suppressed, "机关炮未命中也有基础 100% 压制（受地形/闪避降低后仍可能未命中但压制）: seed={} msg={}", seed, out.message);
            return;
        }
    }
    panic!("未找到机关炮未命中但仍压制的随机种子");
}

#[test]
fn test_hmg_gunner_suppresses_infantry() {
    // 重机枪手（步兵）攻击步兵同样造成压制（基础 90%），与车载重机枪一致。
    let hmg_unit = Unit::new(
        UnitKind::HmgGunner,
        Team::Player,
        hex::axial_from_offset(0, 0),
    );
    assert!(
        hmg_unit.is_suppressing_weapon(),
        "重机枪手应可直射压制步兵"
    );
    assert_eq!(hmg_unit.suppression_base(), 90);
    for seed in 0..300u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let hmg = hex::axial_from_offset(0, 0);
        let inf = hex::axial_from_offset(2, 0); // 距离 2 ≤ 重机枪射程 4
        let mut hmg_unit = Unit::new(UnitKind::HmgGunner, Team::Player, hmg);
        hmg_unit.deployed = true; // 需先架设才能开火
        g.units.insert(hmg, hmg_unit);
        g.units.insert(inf, Unit::new(UnitKind::Rifleman, Team::Ai, inf));
        let out = g.attack(hmg, inf).unwrap();
        let u = g.unit_at(inf).unwrap();
        if out.message.contains("未命中") {
            assert!(
                u.suppressed,
                "重机枪手未命中也有基础 90% 压制: seed={} msg={}",
                seed, out.message
            );
            return;
        }
    }
    panic!("未找到重机枪手未命中但仍压制的随机种子");
}

#[test]
fn test_humvee_series_standard_stats() {
    // 悍马系列统一：血量 2 / 护甲 1 / 行动次数 2 / 行动力 4
    for k in [
        UnitKind::HumveeHmg,
        UnitKind::HumveeTow,
        UnitKind::HumveeJavelin,
        UnitKind::AaLauncher,
    ] {
        assert_eq!(k.max_hp(), 2, "{:?} 血量 2", k);
        assert_eq!(k.armor(), 1, "{:?} 护甲 1", k);
        assert_eq!(k.action_count(), 2, "{:?} 行动次数 2", k);
        assert_eq!(k.movement(), 4, "{:?} 行动力 4", k);
        assert!(k.is_humvee(), "{:?} 属于悍马系列", k);
        assert!(k.is_vehicle() && !k.is_foot() && !k.is_air(), "{:?} 地面车辆", k);
    }
    // 重命名
    assert_eq!(UnitKind::AaLauncher.name(), "悍马-Stinger");
    assert_eq!(UnitKind::AaInfantry.name(), "Stinger射手");
    // 费用
    assert_eq!(UnitKind::HumveeHmg.recruit_cost(), 12);
    assert_eq!(UnitKind::HumveeTow.recruit_cost(), 14);
    assert_eq!(UnitKind::HumveeJavelin.recruit_cost(), 20);
}

#[test]
fn test_humvee_weapons_follow_infantry() {
    // 悍马-重机枪：攻击属性参照重机枪手
    assert_eq!(UnitKind::HumveeHmg.range(), UnitKind::HmgGunner.range());
    assert_eq!(UnitKind::HumveeHmg.attack(), UnitKind::HmgGunner.attack());
    assert_eq!(UnitKind::HumveeHmg.hit_rate(), UnitKind::HmgGunner.hit_rate());
    assert_eq!(UnitKind::HumveeHmg.max_ammo(), 12, "悍马-重机枪弹药 12（步兵重机枪手仍为 8）");
    assert_eq!(UnitKind::HumveeHmg.attack_cost(), UnitKind::HmgGunner.attack_cost());
    let hv = Unit::new(UnitKind::HumveeHmg, Team::Player, hex::axial_from_offset(0, 0));
    assert!(hv.is_heavy_mg_mode(), "悍马-重机枪按重机枪判定而非机关炮");
    assert!(!hv.is_autocannon_mode());
    assert_eq!(hv.suppression_base(), 90);
    // 悍马-TOW：参照 TOW 射手
    assert_eq!(UnitKind::HumveeTow.range(), UnitKind::Atgm.range());
    assert_eq!(UnitKind::HumveeTow.attack(), UnitKind::Atgm.attack());
    assert_eq!(UnitKind::HumveeTow.hit_rate(), UnitKind::Atgm.hit_rate());
    assert_eq!(UnitKind::HumveeTow.max_ammo(), 8, "悍马-TOW 导弹增至 8（步兵 TOW 射手仍为 4）");
    assert_eq!(UnitKind::HumveeTow.attack_cost(), UnitKind::Atgm.attack_cost());
    // 悍马-Javelin：参照 Javelin 射手
    assert_eq!(UnitKind::HumveeJavelin.range(), UnitKind::Javelin.range());
    assert_eq!(UnitKind::HumveeJavelin.attack(), UnitKind::Javelin.attack());
    assert_eq!(UnitKind::HumveeJavelin.hit_rate(), UnitKind::Javelin.hit_rate());
    assert_eq!(UnitKind::HumveeJavelin.max_ammo(), 8, "悍马-Javelin 导弹增至 8（步兵 Javelin 射手仍为 4）");
    assert_eq!(UnitKind::HumveeJavelin.attack_cost(), UnitKind::Javelin.attack_cost());
    // TOW/Javelin 只能打车辆（与步兵版一致）
    assert!(UnitKind::HumveeTow.can_target(UnitKind::Tank));
    assert!(!UnitKind::HumveeTow.can_target(UnitKind::Rifleman));
    assert!(!UnitKind::HumveeJavelin.can_target(UnitKind::Rifleman));
    assert!(!UnitKind::HumveeTow.can_target(UnitKind::AttackHeli));
}

#[test]
fn test_humvee_instant_kill_by_tank_gun_and_autocannon() {
    // 概率函数：坦克炮 0%（改为殉爆 80%）/ 机炮 40% / 其余 0
    let tank = Unit::new(UnitKind::Tank, Team::Player, hex::axial_from_offset(0, 0));
    let scout = Unit::new(UnitKind::Scout, Team::Player, hex::axial_from_offset(0, 0));
    let hmg = Unit::new(UnitKind::HumveeHmg, Team::Player, hex::axial_from_offset(0, 0));
    for tgt in [
        UnitKind::HumveeHmg,
        UnitKind::HumveeTow,
        UnitKind::HumveeJavelin,
        UnitKind::AaLauncher,
    ] {
        assert_eq!(tank.humvee_instant_kill_chance(tgt), 0, "坦克炮不再直接击毁悍马");
        assert_eq!(scout.humvee_instant_kill_chance(tgt), 40, "机炮 vs 悍马");
        assert_eq!(hmg.humvee_instant_kill_chance(tgt), 0, "重机枪不直接击毁悍马");
    }
    assert_eq!(tank.humvee_instant_kill_chance(UnitKind::Rifleman), 0);

    // 实战：坦克炮命中悍马时，要么殉爆（2 点伤害、消息含「殉爆」），要么只扣 1 血；
    // 不再出现「直接击毁」。
    let mut cook = 0;
    let mut normal = 0;
    for seed in 0..200u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let a = hex::axial_from_offset(0, 0);
        let t = hex::axial_from_offset(2, 0);
        g.units.insert(a, Unit::new(UnitKind::Tank, Team::Player, a));
        g.units.insert(t, Unit::new(UnitKind::HumveeTow, Team::Ai, t));
        let out = g.attack(a, t).unwrap();
        assert!(
            !out.message.contains("直接击毁"),
            "坦克炮不应再直接击毁悍马: {}",
            out.message
        );
        if out.killed {
            assert!(out.message.contains("殉爆"), "{}", out.message);
            cook += 1;
        } else if out.hit {
            assert_eq!(g.unit_at(t).unwrap().hp, 1, "未击毁则只扣 1 血");
            normal += 1;
        }
    }
    assert!(cook > 0, "坦克炮应能殉爆悍马");
    assert!(normal > 0, "应出现未触发殉爆的普通命中");

    // 机炮（侦察战车，40%）可直接击毁悍马
    let mut ac_direct = 0;
    for seed in 0..200u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let a = hex::axial_from_offset(0, 0);
        let t = hex::axial_from_offset(2, 0);
        g.units.insert(a, Unit::new(UnitKind::Scout, Team::Player, a));
        g.units.insert(t, Unit::new(UnitKind::HumveeJavelin, Team::Ai, t));
        let out = g.attack(a, t).unwrap();
        if out.killed {
            assert!(out.message.contains("直接击毁"), "{}", out.message);
            ac_direct += 1;
        }
    }
    assert!(ac_direct > 0, "应出现机炮直接击毁悍马");
}

#[test]
fn test_humvee_direct_suppression() {
    // 对步兵生效的直射压制规则对悍马也生效
    assert!(UnitKind::HumveeTow.is_direct_suppressible());
    let mut miss_suppressed = 0;
    let mut hits = 0;
    for seed in 0..200u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let m = hex::axial_from_offset(0, 0);
        let t = hex::axial_from_offset(2, 0);
        let mut hmg_unit = Unit::new(UnitKind::HmgGunner, Team::Player, m);
        hmg_unit.deployed = true; // 需先架设才能开火
        g.units.insert(m, hmg_unit);
        g.units
            .insert(t, Unit::new(UnitKind::HumveeTow, Team::Ai, t));
        let out = g.attack(m, t).unwrap();
        let u = g.unit_at(t).unwrap();
        if out.message.contains("未命中") {
            if u.suppressed {
                miss_suppressed += 1;
            }
        } else {
            hits += 1;
            assert!(u.suppressed, "命中必压制悍马: seed={}", seed);
        }
    }
    assert!(miss_suppressed > 0, "重机枪未命中时也应能压制悍马");
    assert!(hits > 0, "应有命中样本");
}

#[test]
fn test_hmg_can_attack_air_with_building_restriction() {
    // 重机枪手可对空；步枪手不能
    let hmg = Unit::new(UnitKind::HmgGunner, Team::Player, hex::axial_from_offset(0, 0));
    assert!(hmg.can_target_unit(UnitKind::AttackHeli), "重机枪手可对空");
    let hv = Unit::new(UnitKind::HumveeHmg, Team::Player, hex::axial_from_offset(0, 0));
    assert!(hv.can_target_unit(UnitKind::AttackHeli), "悍马-重机枪可对空");
    let rifle = Unit::new(UnitKind::Rifleman, Team::Player, hex::axial_from_offset(0, 0));
    assert!(!rifle.can_target_unit(UnitKind::AttackHeli), "步枪手不能对空");

    // 楼内重机枪不能对空；登上屋顶后可对空
    let mut g = GameState::new_deploy_level(5, Level::OpenField);
    g.begin_turn(Team::Player);
    g.units.clear();
    g.air_units.clear();
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    let h = hex::axial_from_offset(2, 2);
    g.map.buildings.insert(h);
    let mut hmg_unit = Unit::new(UnitKind::HmgGunner, Team::Player, h);
    hmg_unit.deployed = true; // 需先架设才能开火
    g.units.insert(h, hmg_unit);
    let heli = hex::axial_from_offset(4, 2);
    g.air_units
        .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Ai, heli));
    let err = g.attack(h, heli).unwrap_err();
    assert!(err.contains("屋顶"), "楼内不能对空: {}", err);
    // 登屋顶（免费，不耗行动），随后可对空
    g.unit_at_mut(h).unwrap().rooftop = true;
    assert!(
        g.attack(h, heli).is_ok(),
        "登上屋顶后重机枪可对空"
    );

    // 开阔地重机枪不受楼内限制
    let mut g2 = GameState::new_deploy_level(6, Level::OpenField);
    g2.begin_turn(Team::Player);
    g2.units.clear();
    g2.air_units.clear();
    g2.map.obstacles.clear();
    g2.map.forests.clear();
    g2.map.buildings.clear();
    let a = hex::axial_from_offset(2, 2);
    let heli2 = hex::axial_from_offset(4, 2);
    g2.units
        .insert(a, Unit::new(UnitKind::HumveeHmg, Team::Player, a));
    g2.air_units
        .insert(heli2, Unit::new(UnitKind::AttackHeli, Team::Ai, heli2));
    assert!(g2.attack(a, heli2).is_ok(), "开阔地悍马-重机枪可对空");
}

#[test]
fn test_tank_gun_bypasses_active_defense() {
    // 坦克炮：单次和同时攻击都不会触发/参与主动防御抽签
    let mut g = GameState::new_deploy_level(20, Level::OpenField);
    g.begin_turn(Team::Player);
    g.units.clear();
    g.air_units.clear();
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    let a = hex::axial_from_offset(0, 0);
    let ht = hex::axial_from_offset(2, 0);
    let attacker = Unit::new(UnitKind::HeavyTank, Team::Player, a); // 命中率 100%，保证命中
    g.units.insert(a, attacker);
    let mut defender = Unit::new(UnitKind::HeavyTank, Team::Ai, ht);
    defender.ad_uses = 8;
    defender.hp = 10; // 防止被 2 点殉爆直接击毁，便于检查主动防御未被消耗
    g.units.insert(ht, defender);
    let out = g.attack(a, ht).unwrap();
    assert!(out.hit, "主战坦克 100% 命中");
    assert_eq!(g.unit_at(ht).unwrap().ad_uses, 8, "坦克炮不应消耗主动防御");
    assert!(g.unit_at(ht).unwrap().hp < 10, "坦克炮应直接造成伤害: {}", out.message);

    // 同时攻击：两门坦克炮齐射，主动防御完全不参与
    let mut g2 = GameState::new_deploy_level(21, Level::OpenField);
    g2.begin_turn(Team::Player);
    g2.units.clear();
    g2.air_units.clear();
    g2.map.obstacles.clear();
    g2.map.forests.clear();
    g2.map.buildings.clear();
    let a1 = hex::axial_from_offset(0, 0);
    let a2 = hex::axial_from_offset(0, 1);
    let ht2 = hex::axial_from_offset(3, 0);
    g2.units.insert(a1, Unit::new(UnitKind::HeavyTank, Team::Player, a1));
    g2.units.insert(a2, Unit::new(UnitKind::HeavyTank, Team::Player, a2));
    let mut def2 = Unit::new(UnitKind::HeavyTank, Team::Ai, ht2);
    def2.ad_uses = 8;
    def2.hp = 10; // 保证齐射后仍存活，便于检查主动防御未被消耗
    g2.units.insert(ht2, def2);
    let orders = vec![
        SimulOrder { attacker: a1, target: ht2, air_first: false, aa_mode: false, missile_mode: false },
        SimulOrder { attacker: a2, target: ht2, air_first: false, aa_mode: false, missile_mode: false },
    ];
    let _ = g2.simultaneous_attack(&orders).unwrap();
    let u = g2.unit_at(ht2).unwrap().clone();
    assert_eq!(u.ad_uses, 8, "同时攻击中坦克炮不参与主动防御抽签");
    assert!(u.hp < 10, "两门坦克炮应造成伤害: 实际 {}", u.hp);
}

#[test]
fn test_suppression_stacks_from_multiple_area_attacks() {
    // 压制可叠加：同一目标受到多次压制后，新回合行动次数减少多层，最低为 0。
    // 目标选护甲 1 的单位（护甲 ≥ 2 免疫火炮压制，见 test_artillery_cannot_suppress_armor).
    let mut g = GameState::new_deploy_level(30, Level::OpenField);
    g.begin_turn(Team::Player);
    g.units.clear();
    g.air_units.clear();
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    let m1 = hex::axial_from_offset(0, 0);
    let m2 = hex::axial_from_offset(0, 1);
    let target = hex::axial_from_offset(3, 0);
    g.units.insert(m1, Unit::new(UnitKind::Mortar, Team::Player, m1));
    g.units.insert(m2, Unit::new(UnitKind::Mortar, Team::Player, m2));
    let mut t = Unit::new(UnitKind::HmgGunner, Team::Ai, target); // 护甲 1、2 次行动
    t.hp = 5; // 避免两发炮弹直接击毁，专注验证压制叠加
    g.units.insert(target, t);
    // 两门迫击炮都覆盖 target（距离 3/3，射程 8）
    let _ = g.attack(m1, target).unwrap();
    let _ = g.attack(m2, target).unwrap();
    let u = g.unit_at(target).unwrap();
    assert!(u.suppressed, "目标应处于压制状态");
    assert_eq!(u.suppression_stacks, 2, "两次范围攻击应叠加 2 层压制");
    // 敌方新回合：行动次数 2 - 2 = 0
    g.begin_turn(Team::Ai);
    let u = g.unit_at(target).unwrap();
    assert_eq!(u.actions_left, 0, "两次压制应把目标行动次数降到 0");
    assert!(!u.suppressed, "压制生效后清除");
}

/// 迫击炮/榴弹炮不能压制护甲 ≥ 2 的单位；护甲 < 2 的目标仍会被压制。
#[test]
fn test_artillery_cannot_suppress_armor() {
    for seed in 0..40u64 {
        let mut g = GameState::new_deploy_level(seed, Level::OpenField);
        g.begin_turn(Team::Player);
        g.units.clear();
        g.air_units.clear();
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        let m = hex::axial_from_offset(0, 0);
        let tank = hex::axial_from_offset(3, 0); // 护甲 3：免疫火炮压制
        let inf = tank.neighbors()[0]; // 护甲 0：与坦克同处爆炸范围，可被火炮压制
        g.units.insert(m, Unit::new(UnitKind::Mortar, Team::Player, m));
        g.units.insert(tank, Unit::new(UnitKind::Tank, Team::Ai, tank));
        g.units.insert(inf, Unit::new(UnitKind::Rifleman, Team::Ai, inf));
        let _ = g.attack(m, tank).unwrap();
        let t = g.unit_at(tank).unwrap();
        assert!(
            !t.suppressed && t.suppression_stacks == 0,
            "护甲 3 的坦克不应被迫击炮压制（seed={}）",
            seed
        );
        let i = g.unit_at(inf).unwrap();
        assert!(
            i.suppressed && i.suppression_stacks >= 1,
            "护甲 0 的步兵应被迫击炮压制（seed={}）",
            seed
        );
    }

    // 榴弹炮（含 M864 子母弹）同样不能压制护甲 ≥ 2 的单位，但 M864 仍可击伤坦克
    let mut g = GameState::new_deploy_level(7, Level::OpenField);
    g.begin_turn(Team::Player);
    g.units.clear();
    g.air_units.clear();
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    let h = hex::axial_from_offset(0, 0);
    let tank = hex::axial_from_offset(4, 0);
    let mut how = Unit::new(UnitKind::Howitzer, Team::Player, h);
    how.deployed = true;
    how.missile_mode = true;
    how.missile_ammo = 4;
    how.actions_left = 1;
    how.hp = 5;
    g.units.insert(h, how);
    let mut t = Unit::new(UnitKind::Tank, Team::Ai, tank);
    t.hp = 5;
    g.units.insert(tank, t);
    let _ = g.attack(h, tank).unwrap();
    let t = g.unit_at(tank).unwrap();
    assert!(
        !t.suppressed && t.suppression_stacks == 0,
        "护甲 3 的坦克不应被榴弹炮 M864 压制"
    );
    assert!(t.hp < 5, "M864 攻 4 > 护甲 3，仍应击伤坦克");
}

/// 战报：直射击毁记录攻击者、被击毁者与成因。
#[test]
fn test_battle_events_record_direct_fire_kill() {
    let mut g = GameState::new_deploy_level(7, Level::OpenField);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let atk_h = hex::axial_from_offset(2, 2);
    let tgt_h = hex::axial_from_offset(3, 2);
    let mut a = Unit::new(UnitKind::Tank, Team::Player, atk_h);
    a.label = 'A';
    let mut t = Unit::new(UnitKind::Rifleman, Team::Ai, tgt_h);
    t.label = 'x';
    g.units.insert(atk_h, a);
    g.units.insert(tgt_h, t);
    g.begin_turn(Team::Player);
    for _ in 0..40 {
        if g.unit_at(tgt_h).is_none() {
            break;
        }
        if let Some(mut u) = g.unit_at(atk_h).cloned() {
            u.actions_left = 3;
            u.ammo = 42;
            g.units.insert(atk_h, u);
        }
        let _ = g.attack(atk_h, tgt_h);
    }
    assert!(g.unit_at(tgt_h).is_none(), "目标应被击毁");
    let kill = g
        .battle_events
        .iter()
        .find_map(|e| match &e.kind {
            BattleEventKind::Kill(k) if k.victim_label == 'x' => Some(k.clone()),
            _ => None,
        })
        .expect("应记录击毁事件");
    assert_eq!(kill.victim_team, Team::Ai);
    assert_eq!(kill.victim_kind, UnitKind::Rifleman);
    assert_eq!(kill.attacker_label, Some('A'));
    assert_eq!(kill.attacker_kind, Some(UnitKind::Tank));
    assert_eq!(kill.attacker_pos, Some(atk_h));
    assert_eq!(kill.cause, KillCause::DirectFire);
    assert!(!kill.passenger);
}

/// 战报：载具被范围火力击毁时，车上步兵各记一条"随载具阵亡"。
#[test]
fn test_battle_events_record_passengers_of_destroyed_carrier() {
    let mut g = GameState::new_deploy_level(7, Level::OpenField);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let h = hex::axial_from_offset(2, 2);
    let mut how = Unit::new(UnitKind::Howitzer, Team::Player, h);
    how.label = 'F';
    g.units.insert(h, how);
    let c = hex::axial_from_offset(4, 2);
    let mut truck = Unit::new(UnitKind::Truck, Team::Ai, c);
    truck.label = '5';
    let mut rider = Unit::new(UnitKind::Rifleman, Team::Ai, c);
    rider.label = '2';
    truck.passengers.push(rider);
    g.units.insert(c, truck);
    g.begin_turn(Team::Player);
    g.deploy(h).unwrap();
    g.begin_turn(Team::Player);
    g.toggle_missile_mode(h).unwrap(); // M864：中心 100% 命中
    let out = g.attack(h, c).unwrap();
    assert!(out.killed, "M864 100% 命中应击毁卡车: {}", out.message);
    let kills: Vec<KillEvent> = g
        .battle_events
        .iter()
        .filter_map(|e| match &e.kind {
            BattleEventKind::Kill(k) => Some(k.clone()),
            _ => None,
        })
        .collect();
    assert_eq!(kills.len(), 2, "卡车 + 车上步兵各一条战报: {:?}", kills);
    assert!(kills
        .iter()
        .any(|k| k.victim_label == '5' && k.cause == KillCause::Artillery));
    assert!(kills.iter().any(|k| k.victim_label == '2'
        && k.passenger
        && k.cause == KillCause::AboardCarrier
        && k.attacker_label == Some('F')));
    // 战报文本也应点名随毁的搭载单位
    assert!(out.message.contains("搭载的2(步枪手)也随之阵亡"), "{}", out.message);
}

/// 幽灵（最后已知位置）：只在真正看到过敌人后记录，离开视野仍保留，被击毁立即清除。
#[test]
fn test_ghosts_track_last_known_positions() {
    let mut g = GameState::new_deploy_level(7, Level::OpenField);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    let mine = hex::axial_from_offset(1, 1);
    g.units.insert(mine, Unit::new(UnitKind::Tank, Team::Player, mine));
    let far = hex::axial_from_offset(20, 10);
    g.units.insert(far, Unit::new(UnitKind::Tank, Team::Ai, far));
    g.begin_turn(Team::Player);
    assert!(
        g.ghosts
            .get(&Team::Player)
            .map(|m| m.is_empty())
            .unwrap_or(true),
        "从未见过的敌人不应留下幽灵"
    );
    // 走近后可见：记录幽灵
    let near = hex::axial_from_offset(18, 10);
    if let Some(mut u) = g.units.remove(&mine) {
        u.pos = near;
        g.units.insert(near, u);
    }
    g.refresh_ghosts(Team::Player);
    assert!(g.ghosts[&Team::Player].contains_key(&far), "可见时应记录幽灵");
    // 敌人退出视野：最后已知位置仍保留
    let gone = hex::axial_from_offset(25, 10);
    if let Some(mut u) = g.units.remove(&far) {
        u.pos = gone;
        g.units.insert(gone, u);
    }
    g.refresh_ghosts(Team::Player);
    assert!(
        g.ghosts[&Team::Player].contains_key(&far),
        "离开视野后应保留最后已知位置"
    );
    // 让敌人重新进入视野，再在幽灵格上被击毁 → 幽灵立即清除
    if let Some(mut u) = g.units.remove(&gone) {
        u.pos = far;
        g.units.insert(far, u);
    }
    g.refresh_ghosts(Team::Player);
    assert!(g.ghosts[&Team::Player].contains_key(&far), "重新可见");
    g.remove_unit(far);
    assert!(
        !g.ghosts[&Team::Player].contains_key(&far),
        "已阵亡的单位不应保留幽灵"
    );
}

/// 关键据点易手会产生结构化事件（供双方客户端播报）。
#[test]
fn test_keypoint_capture_emits_battle_event() {
    let mut g = GameState::new_deploy_level(11, Level::OpenField);
    g.map.obstacles.clear();
    g.map.forests.clear();
    g.map.buildings.clear();
    g.units.clear();
    g.air_units.clear();
    g.keypoints.clear();
    let kp = hex::axial_from_offset(5, 5);
    g.keypoints.insert(
        kp,
        Keypoint {
            owner: Team::Ai,
            controller: Team::Ai,
            center: true,
        },
    );
    let start = hex::axial_from_offset(4, 5);
    let mut u = Unit::new(UnitKind::Rifleman, Team::Player, start);
    u.label = 'B';
    g.units.insert(start, u);
    g.begin_turn(Team::Player);
    let path = vec![start, kp];
    g.move_unit(start, &path, false).unwrap();
    let ev = g
        .battle_events
        .iter()
        .find_map(|e| match &e.kind {
            BattleEventKind::Keypoint { to, .. } => Some(*to),
            _ => None,
        })
        .expect("应记录据点易手事件");
    assert_eq!(ev, Team::Player);
    assert_eq!(g.keypoints[&kp].controller, Team::Player);

}

    /// 单位标签整局不复用：阵亡后新单位不能拿到仍被占用的标签
    /// （旧实现用存活数量发标签，两个同标签单位只有一个能被 `s` 选中）。
    #[test]
    fn unit_labels_are_never_reused_after_death() {
        let mut g = GameState::new_sustain_multiplayer(7, Level::OpenField);
        g.begin_turn(Team::Player);
        let l1 = g
            .recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(1, 1))
            .expect("招募 1");
        let l2 = g
            .recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(2, 1))
            .expect("招募 2");
        assert_ne!(l1, l2, "两个新单位不应同标签");
        // 阵亡第一个单位后，再招一个：新单位不得复用 l1
        let dead = g
            .units_of(Team::Player)
            .into_iter()
            .find(|u| u.label == l1)
            .map(|u| u.pos)
            .expect("找到第一个单位");
        g.remove_unit(dead);
        let l3 = g
            .recruit_unit(Team::Player, UnitKind::Rifleman, hex::axial_from_offset(3, 1))
            .expect("招募 3");
        assert_ne!(l3, l1, "阵亡单位的标签不应被复用");
        assert_ne!(l3, l2);
        let labels: Vec<char> = g.units_of(Team::Player).iter().map(|u| u.label).collect();
        let unique: std::collections::BTreeSet<char> = labels.iter().copied().collect();
        assert_eq!(labels.len(), unique.len(), "存活单位标签必须互不相同: {:?}", labels);
    }

    /// 敌方**空中**单位不"占领"地面：否则一架无人机在指挥部旁悬停
    /// 就能永久封锁本方全部增援格。地面单位仍然封锁。
    #[test]
    fn enemy_air_unit_does_not_block_deployment() {
        let mut g = GameState::new_sustain_multiplayer(7, Level::OpenField);
        // 直接设一个蓝方大本营中心（关键据点），不必跑完整的开局流程
        let hq = hex::axial_from_offset(1, 1);
        g.keypoints.insert(
            hq,
            Keypoint {
                owner: Team::Player,
                controller: Team::Player,
                center: true,
            },
        );
        let near = hq.neighbors()[0];
        let mut drone = Unit::new(UnitKind::Drone, Team::Ai, near);
        drone.label = '6';
        g.air_units.insert(near, drone);
        assert!(!g.zone_occupied(Team::Player, hq), "敌方空中单位不应封锁部署");
        let mut tank = Unit::new(UnitKind::Tank, Team::Ai, near);
        tank.label = '7';
        g.units.insert(near, tank);
        assert!(g.zone_occupied(Team::Player, hq), "敌方地面单位应封锁部署");
    }
