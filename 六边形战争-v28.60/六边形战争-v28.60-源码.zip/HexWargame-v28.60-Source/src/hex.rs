//! 六边形坐标：内部统一使用轴向坐标 (q, r)，仅在渲染/输入时转换为奇数列偏移坐标 (col, row)。

/// 轴向六边形坐标。
#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Debug)]
pub struct Hex {
    pub q: i32,
    pub r: i32,
}

impl serde::Serialize for Hex {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(&format!("{},{}", self.q, self.r))
    }
}

impl<'de> serde::Deserialize<'de> for Hex {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let s = <String as serde::Deserialize>::deserialize(deserializer)?;
        let mut it = s.split(',');
        let q: i32 = it
            .next()
            .and_then(|x| x.trim().parse().ok())
            .ok_or_else(|| serde::de::Error::custom("invalid hex q"))?;
        let r: i32 = it
            .next()
            .and_then(|x| x.trim().parse().ok())
            .ok_or_else(|| serde::de::Error::custom("invalid hex r"))?;
        Ok(Hex { q, r })
    }
}

impl Hex {
    pub fn new(q: i32, r: i32) -> Self {
        Hex { q, r }
    }

    /// 原点（(0,0) 格），占位用。
    pub const ZERO: Hex = Hex { q: 0, r: 0 };

    /// 立方坐标下的六边形距离。
    pub fn distance(self, other: Hex) -> i32 {
        let dq = (self.q - other.q).abs();
        let dr = (self.r - other.r).abs();
        let ds = (self.q + self.r - other.q - other.r).abs();
        (dq + dr + ds) / 2
    }

    /// 六个相邻格子（轴向方向）。
    pub fn neighbors(self) -> [Hex; 6] {
        const DIRS: [(i32, i32); 6] = [(1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1)];
        DIRS.map(|(dq, dr)| Hex::new(self.q + dq, self.r + dr))
    }
}

/// 轴向坐标 → 奇数列偏移坐标 (col, row)。
pub fn offset_from_axial(h: Hex) -> (i32, i32) {
    let col = h.q + (h.r - (h.r & 1)) / 2;
    (col, h.r)
}

/// 奇数列偏移坐标 → 轴向坐标。
pub fn axial_from_offset(col: i32, row: i32) -> Hex {
    let q = col - (row - (row & 1)) / 2;
    Hex::new(q, row)
}

/// 格子的显示标签：**列,行** 两个数字（均从 1 起），如 "12,5"。
///
/// 早期版本用「列字母 + 行号」（如 "b4"），但 27 列的地图在第 27 列上
/// 无法用 a-z 表示（`'a' + 26 == '{'`，而显示侧曾 clamp 到 'z'，导致
/// 第 26/27 列同标签、输入与显示不一致）。改成双数字后不再有这类歧义。
pub fn hex_label(h: Hex) -> String {
    let (c, r) = offset_from_axial(h);
    format!("{},{}", c + 1, r + 1)
}

/// 解析 `hex_label` 输出的坐标（"列,行"，1 起）。不做地图范围校验。
pub fn parse_label(text: &str) -> Option<Hex> {
    let (col, row) = text.trim().split_once(',')?;
    let col: i32 = col.trim().parse().ok()?;
    let row: i32 = row.trim().parse().ok()?;
    if col < 1 || row < 1 {
        return None;
    }
    Some(axial_from_offset(col - 1, row - 1))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 标签与解析必须互为逆运算（含最右列：27 列地图的列号是两位数）。
    #[test]
    fn label_parse_round_trip() {
        for col in 0..27 {
            for row in 0..13 {
                let h = axial_from_offset(col, row);
                let label = hex_label(h);
                assert_eq!(parse_label(&label), Some(h), "标签 {} 往返失败", label);
                assert_eq!(label, format!("{},{}", col + 1, row + 1));
            }
        }
        // 非法输入
        for bad in ["", "a4", "1", "1,", ",2", "0,3", "3,0", "1,2,3", "x,y"] {
            assert_eq!(parse_label(bad), None, "{:?} 不应被解析", bad);
        }
    }
}
