//! 自定义地图定义与文件读写：地图编辑器输出、主游戏加载共用。
//!
//! 地图文件存放于 maps/ 目录，JSON 格式。地图编辑器（hex_wargame_editor）
//! 创建/编辑，主游戏（GUI/TUI）在开局时扫描 maps/*.json 供玩家选择。
//!
//! 地图分两种模式：
//! - 常规模式（campaign = false，默认）：只指定成列的部署区域（player_cols/ai_cols）。
//! - 战役模式（campaign = true）：以单个格子的精度绘制双方部署区域，
//!   手动预置双方棋子，并逐格指定双方全部大本营/关键据点。主游戏加载战役地图时
//!   直接以预置部队开战（等同持续部署模式：第 1 回合在绘制的部署格内招募，
//!   之后在大本营中心周围 2 格内追加部署；同时控制全部关键据点者获胜）。

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

use crate::hex::{self, Hex};
use crate::unit::{Team, UnitKind};

/// 战役模式胜利条件（按阵营分别设定）。
///
/// 关键据点（`PlacedKeypoint.center == false`）才是胜负目标；大本营
/// （`center == true`）只决定增援部署区域，不参与胜负。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "mode", rename_all = "snake_case")]
pub enum VictoryRule {
    /// 占领全部关键据点即胜（不限回合；旧地图缺省行为，等同于「进攻」但无时限）。
    CaptureAllImmediate,
    /// A 进攻：在指定回合（含）前占领全部关键据点即胜；到点未占全则该方条件作废。
    CaptureAllBeforeTurn { turn: i32 },
    /// B 进攻并坚守 / 坚守：到指定回合时仍控制全部关键据点即胜。
    HoldAllAtTurn { turn: i32 },
    /// C 坚守：到游戏结束回合时仍控制任意一个关键据点即胜。
    HoldAnyAtEnd,
}

impl Default for VictoryRule {
    fn default() -> Self {
        VictoryRule::CaptureAllImmediate
    }
}

impl VictoryRule {
    /// 中文名（供编辑器/日志显示）。
    pub fn label(self) -> String {
        match self {
            VictoryRule::CaptureAllImmediate => "占领全部即胜".into(),
            VictoryRule::CaptureAllBeforeTurn { turn } => {
                format!("A 进攻（第 {} 回合前占领全部）", turn)
            }
            VictoryRule::HoldAllAtTurn { turn } => {
                format!("B 进攻并坚守（第 {} 回合时控制全部）", turn)
            }
            VictoryRule::HoldAnyAtEnd => "C 坚守（游戏结束时控制任意据点）".into(),
        }
    }

    /// A/B 的指定回合（C 与旧行为无指定回合）。
    pub fn target_turn(self) -> Option<i32> {
        match self {
            VictoryRule::CaptureAllBeforeTurn { turn } | VictoryRule::HoldAllAtTurn { turn } => {
                Some(turn)
            }
            _ => None,
        }
    }

    /// 指定回合是否必填。
    pub fn needs_turn(self) -> bool {
        matches!(
            self,
            VictoryRule::CaptureAllBeforeTurn { .. } | VictoryRule::HoldAllAtTurn { .. }
        )
    }
}

/// 战役模式下预置的一枚棋子（偏移坐标）。
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct PlacedUnit {
    /// 所属方
    pub team: Team,
    /// 兵种
    pub kind: UnitKind,
    pub col: i32,
    pub row: i32,
    /// 初始搭载的货物（步兵/榴弹炮/补给/悍马系列/侦察战车/自行迫击炮）。
    /// 只有具备载重的运输单位（卡车 9 / 重型运输直升机 8 / 步兵战车 3 /
    /// 运输直升机 3 / 装甲骑兵战车 1）可以携带，且需满足 `UnitKind::can_load_cargo`
    /// 与载重（`capacity` / `cargo_weight`）限制；旧地图缺省为空。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub passengers: Vec<UnitKind>,
}

/// 战役模式下预置的一个大本营/关键据点（偏移坐标）。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct PlacedKeypoint {
    /// 据点原始归属方
    pub team: Team,
    pub col: i32,
    pub row: i32,
    /// 是否为大本营中心（用于对局中的追加部署判定）
    #[serde(default)]
    pub center: bool,
}

fn default_income() -> i32 {
    10
}

/// 一张自定义地图：大小、地形、双方部署区域与招募点数。
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CustomMap {
    /// 地图显示名（文件名由此生成：maps/<name>.json）
    pub name: String,
    pub cols: i32,
    pub rows: i32,
    /// 岩石（偏移坐标 (col,row)）
    pub obstacles: Vec<(i32, i32)>,
    /// 森林（偏移坐标）
    pub forests: Vec<(i32, i32)>,
    /// 楼房（偏移坐标）
    pub buildings: Vec<(i32, i32)>,
    /// 水域（偏移坐标）：陆军不可进入、卡车不可卸下到水域、
    /// 空中可进入但运输直升机不可在水域上方卸下步兵；不阻挡视野。
    #[serde(default)]
    pub water: Vec<(i32, i32)>,
    /// 道路（偏移坐标）：车辆进入只消耗 0.5 行动力；不阻挡移动/视线。
    #[serde(default)]
    pub roads: Vec<(i32, i32)>,
    /// 玩家部署列（常规模式：只在这些列可放置己方单位）
    pub player_cols: Vec<i32>,
    /// AI 部署列
    pub ai_cols: Vec<i32>,
    /// 双方招募点数
    pub player_points: i32,
    pub ai_points: i32,

    // ---- 战役模式（campaign = true）专用字段；旧地图缺省即常规模式 ----
    /// 是否战役模式：逐格部署区 + 预置双方棋子 + 指定大本营据点。
    #[serde(default)]
    pub campaign: bool,
    /// 战役模式玩家部署格（逐格精度）
    #[serde(default)]
    pub player_cells: Vec<(i32, i32)>,
    /// 战役模式 AI 部署格（逐格精度）
    #[serde(default)]
    pub ai_cells: Vec<(i32, i32)>,
    /// 战役模式预置棋子（双方任意棋子）
    #[serde(default)]
    pub units: Vec<PlacedUnit>,
    /// 战役模式大本营/关键据点（双方全部据点）
    #[serde(default)]
    pub keypoints: Vec<PlacedKeypoint>,
    /// 战役模式玩家每回合部署点数（持续部署收入）
    #[serde(default = "default_income")]
    pub player_income: i32,
    /// 战役模式 AI 每回合部署点数
    #[serde(default = "default_income")]
    pub ai_income: i32,
    /// 战役模式：游戏结束回合（>0 时，超过该回合结算 C 与超时；0 表示不限）。
    #[serde(default)]
    pub turn_limit: i32,
    /// 战役模式：玩家胜利条件（缺省为旧行为「占领全部即胜」）。
    #[serde(default)]
    pub player_victory: VictoryRule,
    /// 战役模式：AI 胜利条件（缺省为旧行为「占领全部即胜」）。
    #[serde(default)]
    pub ai_victory: VictoryRule,
}

impl Default for CustomMap {
    fn default() -> Self {
        CustomMap {
            name: "新地图".into(),
            cols: 27,
            rows: 13,
            obstacles: Vec::new(),
            forests: Vec::new(),
            buildings: Vec::new(),
            water: Vec::new(),
            roads: Vec::new(),
            player_cols: (0..4).collect(),
            ai_cols: (23..27).collect(),
            player_points: 100,
            ai_points: 100,
            campaign: false,
            player_cells: Vec::new(),
            ai_cells: Vec::new(),
            units: Vec::new(),
            keypoints: Vec::new(),
            player_income: default_income(),
            ai_income: default_income(),
            turn_limit: 0,
            player_victory: VictoryRule::CaptureAllImmediate,
            ai_victory: VictoryRule::CaptureAllImmediate,
        }
    }
}

impl CustomMap {
    /// 地图文件所在目录（工作目录下的 maps/，不存在则创建）。
    pub fn maps_dir() -> PathBuf {
        let p = PathBuf::from("maps");
        std::fs::create_dir_all(&p).ok();
        p
    }

    /// 由显示名生成文件名（去除非安全字符）。
    pub fn file_name(&self) -> String {
        let mut s = self
            .name
            .trim()
            .chars()
            .map(|c| {
                if c.is_alphanumeric() || c == '_' || c == '-' {
                    c
                } else {
                    '_'
                }
            })
            .collect::<String>();
        if s.is_empty() {
            s = "地图".into();
        }
        format!("{}.json", s)
    }

    pub fn path(&self) -> PathBuf {
        Self::maps_dir().join(self.file_name())
    }

    /// 保存到 maps/ 目录（JSON 美化格式）。
    pub fn save(&self) -> Result<PathBuf, String> {
        let p = self.path();
        let json = serde_json::to_string_pretty(self).map_err(|e| e.to_string())?;
        std::fs::write(&p, json).map_err(|e| e.to_string())?;
        Ok(p)
    }

    /// 从文件加载。
    pub fn load(path: &Path) -> Result<Self, String> {
        let txt = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
        serde_json::from_str(&txt).map_err(|e| format!("{}: {}", path.display(), e))
    }

    /// 扫描 maps/ 目录下的所有自定义地图（按文件名排序）。
    pub fn scan_all() -> Vec<(String, PathBuf)> {
        let mut out = Vec::new();
        if let Ok(rd) = std::fs::read_dir(Self::maps_dir()) {
            let mut files: Vec<PathBuf> = rd
                .filter_map(|e| e.ok().map(|e| e.path()))
                .filter(|p| p.extension().map(|x| x == "json").unwrap_or(false))
                .collect();
            files.sort();
            for f in files {
                if let Ok(cm) = Self::load(&f) {
                    out.push((cm.name, f));
                }
            }
        }
        out
    }

    fn check_bounds(&self, c: i32, r: i32, what: &str) -> Result<(), String> {
        if c < 0 || r < 0 || c >= self.cols || r >= self.rows {
            return Err(format!("{} 越界: ({},{})", what, c, r));
        }
        Ok(())
    }

    /// 校验地图合法性（供保存与加载时检查）。致命错误返回 Err。
    pub fn validate(&self) -> Result<(), String> {
        if self.cols < 8 || self.rows < 4 || self.cols > 64 || self.rows > 40 {
            return Err(format!(
                "地图大小需在 8×4 到 64×40 之间（当前 {}×{}）",
                self.cols, self.rows
            ));
        }
        if self.campaign {
            return self.validate_campaign();
        }
        if self.player_cols.is_empty() {
            return Err("玩家部署区为空".into());
        }
        if self.ai_cols.is_empty() {
            return Err("AI 部署区为空".into());
        }
        for c in self.player_cols.iter().chain(self.ai_cols.iter()) {
            if *c < 0 || *c >= self.cols {
                return Err(format!("部署列越界: {}", c));
            }
        }
        for (list, what) in [
            (&self.obstacles, "岩石"),
            (&self.forests, "森林"),
            (&self.buildings, "楼房"),
            (&self.water, "水域"),
            (&self.roads, "道路"),
        ] {
            for (c, r) in list {
                self.check_bounds(*c, *r, what)?;
            }
        }
        Ok(())
    }

    /// 战役模式校验：逐格部署区、预置棋子、大本营据点的越界与合法性。
    /// 部署区可以为空（该方没有大本营 → 没有增援部署区，只靠预置部队）。
    fn validate_campaign(&self) -> Result<(), String> {
        for (list, what) in [
            (&self.obstacles, "岩石"),
            (&self.forests, "森林"),
            (&self.buildings, "楼房"),
            (&self.water, "水域"),
            (&self.roads, "道路"),
        ] {
            for (c, r) in list {
                self.check_bounds(*c, *r, what)?;
            }
        }
        for (list, what) in [
            (&self.player_cells, "玩家部署格"),
            (&self.ai_cells, "AI 部署格"),
        ] {
            for (c, r) in list {
                self.check_bounds(*c, *r, what)?;
            }
        }
        // 预置棋子：同一层（地面/空中）一格一枚；地面棋子地形合法；运输单位初始搭载合法。
        let mut ground: Vec<(i32, i32)> = Vec::new();
        let mut air: Vec<(i32, i32)> = Vec::new();
        for u in &self.units {
            self.check_bounds(u.col, u.row, "预置棋子")?;
            self.check_cargo(u.kind, &u.passengers, u.col, u.row)?;
            let pos = (u.col, u.row);
            if u.kind.is_air() {
                if air.contains(&pos) {
                    return Err(format!("战役模式：同一格有多个空中棋子 ({},{})", u.col, u.row));
                }
                air.push(pos);
            } else {
                if ground.contains(&pos) {
                    return Err(format!("战役模式：同一格有多个地面棋子 ({},{})", u.col, u.row));
                }
                if self.obstacles.contains(&pos) {
                    return Err(format!("战役模式：地面棋子在岩石上 ({},{})", u.col, u.row));
                }
                if self.water.contains(&pos) {
                    return Err(format!("战役模式：地面棋子在水域上 ({},{})", u.col, u.row));
                }
                if self.buildings.contains(&pos) && !u.kind.is_foot() {
                    return Err(format!("战役模式：车辆棋子不能放在楼房内 ({},{})", u.col, u.row));
                }
                ground.push(pos);
            }
        }
        // 大本营据点：一格一个。
        for kp in &self.keypoints {
            self.check_bounds(kp.col, kp.row, "大本营据点")?;
        }
        for i in 0..self.keypoints.len() {
            for j in (i + 1)..self.keypoints.len() {
                if (self.keypoints[i].col, self.keypoints[i].row)
                    == (self.keypoints[j].col, self.keypoints[j].row)
                {
                    return Err(format!(
                        "战役模式：同一格有多个大本营据点 ({},{})",
                        self.keypoints[i].col, self.keypoints[i].row
                    ));
                }
            }
        }
        // 胜利条件与可部署区域规则
        self.check_victory_rule(Team::Player, self.player_victory)?;
        self.check_victory_rule(Team::Ai, self.ai_victory)?;
        self.check_deploy_regions(Team::Player)?;
        self.check_deploy_regions(Team::Ai)?;
        Ok(())
    }

    /// 某方的可部署格（战役模式）。
    pub fn deploy_cells_of(&self, team: Team) -> &Vec<(i32, i32)> {
        match team {
            Team::Player => &self.player_cells,
            Team::Ai => &self.ai_cells,
        }
    }

    /// 某方的关键据点（胜负目标；`center == false`）。
    pub fn objectives_of(&self, team: Team) -> Vec<(i32, i32)> {
        self.keypoints
            .iter()
            .filter(|k| k.team == team && !k.center)
            .map(|k| (k.col, k.row))
            .collect()
    }

    /// 某方的大本营（`center == true`；只决定增援部署，不参与胜负）。
    pub fn headquarters_of(&self, team: Team) -> Vec<(i32, i32)> {
        self.keypoints
            .iter()
            .filter(|k| k.team == team && k.center)
            .map(|k| (k.col, k.row))
            .collect()
    }

    /// 胜利条件校验：A/B 需指定回合，C 需游戏结束回合。
    fn check_victory_rule(&self, team: Team, rule: VictoryRule) -> Result<(), String> {
        match rule {
            VictoryRule::CaptureAllBeforeTurn { turn } | VictoryRule::HoldAllAtTurn { turn } => {
                if turn <= 0 {
                    return Err(format!(
                        "战役模式：{} 的胜利条件需要指定回合（≥1）",
                        team.cn()
                    ));
                }
            }
            VictoryRule::HoldAnyAtEnd => {
                if self.turn_limit <= 0 {
                    return Err(format!(
                        "战役模式：{} 选择 C 坚守，必须设置游戏结束回合（turn_limit > 0）",
                        team.cn()
                    ));
                }
            }
            VictoryRule::CaptureAllImmediate => {}
        }
        Ok(())
    }

    /// 战役模式可部署区域规则：每片连通区必须（且只能）连接一个大本营；
    /// 同方两个大本营的连通区不可交汇。
    fn check_deploy_regions(&self, team: Team) -> Result<(), String> {
        use std::collections::{BTreeSet, VecDeque};
        let cells = self.deploy_cells_of(team);
        if cells.is_empty() {
            return Ok(());
        }
        let hqs = self.headquarters_of(team);
        let cell_set: BTreeSet<(i32, i32)> = cells.iter().copied().collect();
        let mut visited: BTreeSet<(i32, i32)> = BTreeSet::new();
        for start in &cell_set {
            if visited.contains(start) {
                continue;
            }
            let mut comp: Vec<(i32, i32)> = Vec::new();
            let mut q = VecDeque::new();
            q.push_back(*start);
            visited.insert(*start);
            while let Some(c) = q.pop_front() {
                comp.push(c);
                for n in hex::axial_from_offset(c.0, c.1).neighbors() {
                    let (nc, nr) = hex::offset_from_axial(n);
                    if cell_set.contains(&(nc, nr)) && visited.insert((nc, nr)) {
                        q.push_back((nc, nr));
                    }
                }
            }
            let anchors: Vec<(i32, i32)> = hqs
                .iter()
                .copied()
                .filter(|hq| {
                    comp.contains(hq)
                        || comp.iter().any(|c| {
                            Hex::distance(
                                hex::axial_from_offset(c.0, c.1),
                                hex::axial_from_offset(hq.0, hq.1),
                            ) == 1
                        })
                })
                .collect();
            match anchors.len() {
                0 => {
                    return Err(format!(
                        "战役模式：{} 的可部署区域有一片（如 {}）未连接任何大本营",
                        team.cn(),
                        hex::hex_label(hex::axial_from_offset(start.0, start.1))
                    ))
                }
                1 => {}
                n => {
                    return Err(format!(
                        "战役模式：{} 的可部署区域有一片连接了 {} 个大本营（大本营连通区不可交汇）",
                        team.cn(),
                        n
                    ))
                }
            }
        }
        Ok(())
    }

    /// 校验一个预置运输单位的初始搭载是否合法（兵种允许 + 运力足够）。
    fn check_cargo(
        &self,
        carrier: UnitKind,
        passengers: &[UnitKind],
        col: i32,
        row: i32,
    ) -> Result<(), String> {
        if passengers.is_empty() {
            return Ok(());
        }
        if carrier.capacity() == 0 {
            return Err(format!(
                "战役模式：{} 不是运输单位，不能预置搭载 ({},{})",
                carrier.name(),
                col,
                row
            ));
        }
        let mut used = 0i32;
        for p in passengers {
            if !carrier.can_load_cargo(*p) {
                return Err(format!(
                    "战役模式：{} 不能搭载 {} ({},{})",
                    carrier.name(),
                    p.name(),
                    col,
                    row
                ));
            }
            used += p.cargo_weight();
        }
        if used > carrier.capacity() {
            return Err(format!(
                "战役模式：{} 初始搭载超出载重（{} > {}）({},{})",
                carrier.name(),
                used,
                carrier.capacity(),
                col,
                row
            ));
        }
        Ok(())
    }

    /// 非致命提示：保存前提示作者补全（不阻止保存）。
    pub fn warnings(&self) -> Vec<String> {
        let mut w = Vec::new();
        if !self.campaign {
            return w;
        }
        for team in [Team::Player, Team::Ai] {
            let hqs = self.headquarters_of(team).len();
            let objectives = self.objectives_of(team).len();
            if hqs == 0 {
                w.push(format!(
                    "{} 没有大本营：没有增援部署区（只能依靠预置部队）",
                    team.cn()
                ));
            }
            if self.deploy_cells_of(team).is_empty() {
                w.push(format!("{} 没有可部署区域（无法招募/增援）", team.cn()));
            }
            if objectives == 0 {
                w.push(format!("{} 没有关键据点（该方无据点胜负目标）", team.cn()));
            }
            let n = self.units.iter().filter(|u| u.team == team).count();
            if n == 0 {
                w.push(format!("{} 尚未预置任何棋子", team.cn()));
            }
            let rule = match team {
                Team::Player => self.player_victory,
                Team::Ai => self.ai_victory,
            };
            if rule.needs_turn() && self.turn_limit <= 0 {
                w.push(format!(
                    "{} 的胜利条件 {} 没有游戏结束回合（无法结算超时）",
                    team.cn(),
                    rule.label()
                ));
            }
            if let Some(t) = rule.target_turn() {
                if self.turn_limit > 0 && t > self.turn_limit {
                    w.push(format!(
                        "{} 的胜利条件指定回合 {} 超过游戏结束回合 {}",
                        team.cn(),
                        t,
                        self.turn_limit
                    ));
                }
            }
        }
        w
    }

    /// 常规模式的部署列 → 战役模式的逐格部署区（整列迁移，供编辑器切换模式用）。
    pub fn cols_to_cells(cols: &[i32], rows: i32) -> Vec<(i32, i32)> {
        let mut out = Vec::new();
        for c in cols {
            for r in 0..rows {
                out.push((*c, r));
            }
        }
        out.sort_unstable();
        out.dedup();
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn save_load_roundtrip() {
        let mut m = CustomMap::default();
        m.name = "测试峡谷".into();
        m.cols = 20;
        m.rows = 10;
        m.obstacles = vec![(3, 3), (4, 3)];
        m.forests = vec![(5, 5)];
        m.buildings = vec![(6, 2)];
        m.water = vec![(7, 4), (8, 4)];
        m.roads = vec![(2, 5), (3, 5)];
        m.player_cols = vec![0, 1];
        m.ai_cols = vec![18, 19];
        m.validate().expect("校验通过");
        let p = m.save().expect("保存");
        let loaded = CustomMap::load(&p).expect("加载");
        assert_eq!(loaded.name, "测试峡谷");
        assert_eq!(loaded.cols, 20);
        assert_eq!(loaded.obstacles, vec![(3, 3), (4, 3)]);
        assert_eq!(loaded.forests, vec![(5, 5)]);
        assert_eq!(loaded.buildings, vec![(6, 2)]);
        assert_eq!(loaded.water, vec![(7, 4), (8, 4)], "水域应随地图保存/加载");
        assert_eq!(loaded.roads, vec![(2, 5), (3, 5)], "道路应随地图保存/加载");
        assert_eq!(loaded.player_cols, vec![0, 1]);
        assert_eq!(loaded.ai_cols, vec![18, 19]);
        assert!(!loaded.campaign, "普通地图缺省非战役模式");
        std::fs::remove_file(&p).ok();
    }

    /// 旧版地图 JSON（无 water 字段）应兼容加载（water 默认空）。
    #[test]
    fn old_map_without_water_loads() {
        let old = r#"{"name":"旧地图","cols":10,"rows":10,"obstacles":[[1,1]],"forests":[],"buildings":[],"player_cols":[0],"ai_cols":[9],"player_points":100,"ai_points":100}"#;
        let m: CustomMap = serde_json::from_str(old).unwrap();
        assert_eq!(m.water, Vec::<(i32, i32)>::new(), "旧地图 water 默认空");
        assert_eq!(m.roads, Vec::<(i32, i32)>::new(), "旧地图 roads 默认空");
        assert_eq!(m.obstacles, vec![(1, 1)]);
        assert!(!m.campaign, "旧地图默认常规模式");
        assert!(m.units.is_empty() && m.keypoints.is_empty(), "旧地图无战役字段");
    }

    #[test]
    fn validate_rejects_bad() {
        let mut m = CustomMap::default();
        m.player_cols.clear();
        assert!(m.validate().is_err(), "空部署区应报错");
        m.player_cols = vec![0];
        m.obstacles = vec![(999, 0)];
        assert!(m.validate().is_err(), "越界岩石应报错");
        m.obstacles.clear();
        m.cols = 3;
        assert!(m.validate().is_err(), "过小地图应报错");
    }

    #[test]
    fn campaign_roundtrip_and_validation() {
        let mut m = CustomMap::default();
        m.name = "战役测试".into();
        m.campaign = true;
        m.player_cells = vec![(0, 0), (0, 1)];
        m.ai_cells = vec![(9, 0), (9, 1)];
        m.units = vec![
            PlacedUnit { team: Team::Player, kind: UnitKind::Tank, col: 0, row: 0, passengers: Vec::new()},
            PlacedUnit { team: Team::Ai, kind: UnitKind::AttackHeli, col: 9, row: 0, passengers: Vec::new()},
        ];
        m.keypoints = vec![
            PlacedKeypoint { team: Team::Player, col: 0, row: 0, center: true },
            PlacedKeypoint { team: Team::Player, col: 1, row: 0, center: false },
            PlacedKeypoint { team: Team::Ai, col: 9, row: 1, center: true },
            PlacedKeypoint { team: Team::Ai, col: 8, row: 1, center: false },
        ];
        m.validate().expect("战役地图应通过校验");
        assert!(m.warnings().is_empty(), "完整战役地图无提示: {:?}", m.warnings());
        let p = m.save().expect("保存");
        let loaded = CustomMap::load(&p).expect("加载");
        assert!(loaded.campaign, "战役标记应保存");
        assert_eq!(loaded.player_cells, vec![(0, 0), (0, 1)]);
        assert_eq!(loaded.units.len(), 2);
        assert_eq!(loaded.keypoints.len(), 4);
        assert_eq!(loaded.player_income, 10, "收入缺省 10");
        std::fs::remove_file(&p).ok();
    }

    #[test]
    fn campaign_rejects_overlaps_and_bad_terrain() {
        let mut m = CustomMap::default();
        m.campaign = true;
        m.player_cells = vec![(0, 0)];
        m.ai_cells = vec![(9, 0)];
        // 两个地面棋子同格
        m.units = vec![
            PlacedUnit { team: Team::Player, kind: UnitKind::Tank, col: 0, row: 0, passengers: Vec::new()},
            PlacedUnit { team: Team::Ai, kind: UnitKind::Rifleman, col: 0, row: 0, passengers: Vec::new()},
        ];
        assert!(m.validate().is_err(), "同格两个地面棋子应报错");
        // 地面棋子在岩石上
        m.units = vec![PlacedUnit { team: Team::Player, kind: UnitKind::Tank, col: 0, row: 0, passengers: Vec::new()}];
        m.obstacles = vec![(0, 0)];
        assert!(m.validate().is_err(), "地面棋子在岩石上应报错");
        // 车辆在楼房内
        m.obstacles.clear();
        m.buildings = vec![(0, 0)];
        assert!(m.validate().is_err(), "车辆在楼房内应报错");
        m.buildings.clear();
        m.units.clear();
        // 同格两个据点
        m.keypoints = vec![
            PlacedKeypoint { team: Team::Player, col: 1, row: 1, center: true },
            PlacedKeypoint { team: Team::Ai, col: 1, row: 1, center: false },
        ];
        assert!(m.validate().is_err(), "同格两个据点应报错");
    }

    #[test]
    fn campaign_warns_missing_center() {
        let mut m = CustomMap::default();
        m.campaign = true;
        m.player_cells = vec![(0, 0)];
        m.ai_cells = vec![(9, 0)];
        m.units = vec![PlacedUnit { team: Team::Player, kind: UnitKind::Tank, col: 0, row: 0, passengers: Vec::new()}];
        let w = m.warnings();
        assert!(w.iter().any(|s| s.contains("玩家") && s.contains("大本营")), "{:?}", w);
        assert!(w.iter().any(|s| s.contains("AI") && s.contains("大本营")), "{:?}", w);
    }

    /// 运输单位初始搭载：按重量校验，合法组合通过并随地图保存/加载；超载/非法货物被拒绝。
    #[test]
    fn campaign_cargo_validation_and_roundtrip() {
        let mut m = CustomMap::default();
        m.campaign = true;
        m.player_cells = vec![(0, 0)];
        m.ai_cells = vec![(9, 0)];
        m.keypoints = vec![
            PlacedKeypoint { team: Team::Player, col: 0, row: 0, center: true },
            PlacedKeypoint { team: Team::Ai, col: 9, row: 0, center: true },
        ];
        m.units = vec![PlacedUnit {
            team: Team::Player,
            kind: UnitKind::Truck,
            col: 0,
            row: 0,
            passengers: vec![UnitKind::Rifleman, UnitKind::Rifleman, UnitKind::Howitzer],
        }];
        // 3 + 3 + 5 = 11 > 卡车 9 载重
        assert!(m.validate().is_err(), "卡车初始搭载超出载重应报错");

        // 卡车不可运载悍马系列（重量 6 在载重内也禁止）
        m.units[0].passengers = vec![UnitKind::HumveeHmg];
        assert!(m.validate().is_err(), "卡车不能载悍马");
        // 卡车不可运载侦察战车/迫击炮
        m.units[0].passengers = vec![UnitKind::Scout];
        assert!(m.validate().is_err(), "卡车不能载侦察战车");
        m.units[0].passengers = vec![UnitKind::Mortar];
        assert!(m.validate().is_err(), "卡车不能载迫击炮");

        // 卡车载 1 步兵 + 补给 = 3 + 3 = 6 载重，合法且可保存/加载
        m.units[0].passengers = vec![UnitKind::Rifleman, UnitKind::Supply];
        m.validate().expect("卡车载 1 步兵 + 补给应合法");
        let p = m.save().expect("保存");
        let loaded = CustomMap::load(&p).expect("加载");
        assert_eq!(
            loaded.units[0].passengers,
            vec![UnitKind::Rifleman, UnitKind::Supply],
            "初始搭载应随地图保存/加载"
        );
        std::fs::remove_file(&p).ok();

        // 运输直升机（载重 3）：榴弹炮 5 超重、补给不可载
        m.units[0].kind = UnitKind::TransportHeli;
        m.units[0].passengers = vec![UnitKind::Howitzer];
        assert!(m.validate().is_err(), "运输直升机不能载榴弹炮（超重）");
        m.units[0].passengers = vec![UnitKind::Supply];
        assert!(m.validate().is_err(), "运输直升机不能载补给");
        m.units[0].passengers = vec![UnitKind::Rifleman];
        m.validate().expect("运输直升机可载步枪手（3 重量）");

        // 重型运输直升机（载重 8）：可载榴弹炮+步兵（5+3）、悍马+步兵（6+2）
        m.units[0].kind = UnitKind::HeavyTransportHeli;
        m.units[0].passengers = vec![UnitKind::Howitzer, UnitKind::Rifleman];
        m.validate().expect("重直可载榴弹炮 5 + 步兵 3");
        m.units[0].passengers = vec![UnitKind::HumveeHmg, UnitKind::SpecialForces];
        m.validate().expect("重直可载悍马 6 + 特战 2（新规则）");
        m.units[0].passengers = vec![UnitKind::Scout];
        m.validate().expect("重直可载侦察战车 7（新规则）");
        m.units[0].passengers = vec![UnitKind::Mortar];
        m.validate().expect("重直可载迫击炮 8（新规则）");
        m.units[0].passengers = vec![UnitKind::HumveeHmg, UnitKind::Howitzer];
        assert!(m.validate().is_err(), "重直 6 + 5 = 11 > 8 应报错");

        // 非运输单位不能预置搭载
        m.units[0].kind = UnitKind::Tank;
        m.units[0].passengers = vec![UnitKind::Rifleman];
        assert!(m.validate().is_err(), "坦克不能预置搭载");

        // 装甲骑兵战车载重 1：只能载 1 重量步兵
        m.units[0].kind = UnitKind::CavalryIfv;
        m.units[0].passengers = vec![UnitKind::Rifleman];
        assert!(m.validate().is_err(), "装甲骑兵战车不能载步枪手（3 重量）");
        m.units[0].passengers = vec![UnitKind::Javelin];
        m.validate().expect("装甲骑兵战车可载 Javelin（1 重量）");
    }

    /// 可部署区域规则：必须与大本营连通；同方两个大本营的连通区不可交汇。
    #[test]
    fn campaign_deploy_region_rules() {
        let base = |cells: Vec<(i32, i32)>, hqs: Vec<(i32, i32)>| {
            let mut m = CustomMap::default();
            m.campaign = true;
            m.cols = 12;
            m.rows = 6;
            m.player_cells = cells;
            m.ai_cells = vec![(11, 0)];
            let mut kps = vec![PlacedKeypoint {
                team: Team::Ai,
                col: 11,
                row: 0,
                center: true,
            }];
            for (c, r) in hqs {
                kps.push(PlacedKeypoint {
                    team: Team::Player,
                    col: c,
                    row: r,
                    center: true,
                });
            }
            m.keypoints = kps;
            m
        };
        // 单大本营（在区域外、与区域相邻）→ 合法
        base(vec![(0, 0), (1, 0)], vec![(0, 1)])
            .validate()
            .expect("与大本营相邻的连通区应合法");
        // 两个分离的连通区，各连一个大本营 → 合法
        base(vec![(0, 0), (0, 1), (2, 0), (2, 1)], vec![(0, 0), (2, 0)])
            .validate()
            .expect("两个独立连通区各连一座大本营应合法");
        // 同一片连通区连两个大本营 → 报错
        assert!(
            base(vec![(0, 0), (1, 0), (2, 0)], vec![(0, 0), (2, 0)])
                .validate()
                .is_err(),
            "同片两个大本营应报错"
        );
        // 有部署格但没有大本营 → 报错
        assert!(
            base(vec![(0, 0), (1, 0)], vec![]).validate().is_err(),
            "无大本营的部署区应报错"
        );
        // 一方没有大本营、也没有部署区 → 允许（只靠预置部队）
        base(vec![], vec![])
            .validate()
            .expect("无大本营且无部署区应允许");
    }

    /// 胜利条件校验：A/B 需指定回合，C 需游戏结束回合。
    #[test]
    fn campaign_victory_rule_validation() {
        let mut m = CustomMap::default();
        m.campaign = true;
        m.cols = 12;
        m.rows = 6;
        m.player_cells = vec![(0, 0)];
        m.ai_cells = vec![(11, 0)];
        m.keypoints = vec![
            PlacedKeypoint { team: Team::Player, col: 0, row: 0, center: true },
            PlacedKeypoint { team: Team::Ai, col: 11, row: 0, center: true },
            PlacedKeypoint { team: Team::Ai, col: 5, row: 5, center: false },
        ];
        m.player_victory = VictoryRule::CaptureAllBeforeTurn { turn: 0 };
        assert!(m.validate().is_err(), "A 未指定回合应报错");
        m.player_victory = VictoryRule::HoldAllAtTurn { turn: 5 };
        m.turn_limit = 0;
        m.ai_victory = VictoryRule::HoldAnyAtEnd;
        assert!(m.validate().is_err(), "C 无游戏结束回合应报错");
        m.turn_limit = 10;
        m.player_victory = VictoryRule::CaptureAllBeforeTurn { turn: 8 };
        m.ai_victory = VictoryRule::HoldAnyAtEnd;
        m.validate().expect("合法胜利条件应通过");
    }
}
