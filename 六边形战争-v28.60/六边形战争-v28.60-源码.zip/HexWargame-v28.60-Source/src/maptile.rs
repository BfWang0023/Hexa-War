//! 静态地图层：把地形/装饰/迷雾的**原矢量绘制**一次性锯齿化并缓存为 Mesh。
//!
//! 纯 CPU（软渲染）环境下，每帧对数百个六边形及其装饰重新做形状锯齿化
//! 是主要卡顿来源。此模块复用与逐帧绘制完全相同的矢量图形（含抗锯齿
//! 羽化描边），通过 `Context::tessellate` 只锯齿化一次缓存为 Mesh；
//! 每帧仅平移顶点并提交 1 个 Mesh——观感与逐帧矢量绘制完全一致。
//! 仅在地形缩放或视野（迷雾）变化时重建。

use eframe::egui::{self, Color32, Mesh, Pos2, Rect, Shape, Stroke, StrokeKind};
use hex_wargame::game::GameState;
use hex_wargame::hex::{self, Hex};
use std::collections::HashMap;
use std::hash::{Hash, Hasher};

use super::theme;

/// 烘焙好的静态地图层（已锯齿化的抗锯齿网格，本地坐标）。
pub struct MapLayer {
    pub mesh: Mesh,
    pub hs: f32,
    pub dist_hash: u64,
    pub deploying: bool,
}

impl MapLayer {
    /// 网格平移副本（每帧一次，仅顶点加法，开销可忽略）。
    pub fn mesh_at(&self, origin: Pos2) -> Mesh {
        let mut m = self.mesh.clone();
        for v in &mut m.vertices {
            v.pos.x += origin.x;
            v.pos.y += origin.y;
        }
        m
    }
}

/// 视野缓存签名：BFS 距离表内容变化 → 网格重建（雾层变化）。
pub fn dist_signature(dist: &HashMap<Hex, (i32, i32)>) -> u64 {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    let mut keys: Vec<Hex> = dist.keys().copied().collect();
    keys.sort();
    for k in keys {
        k.hash(&mut h);
        let v = &dist[&k];
        v.0.hash(&mut h);
        v.1.hash(&mut h);
    }
    h.finish()
}

/// 每格确定性明暗微差（-3..=3），给地图增加质感而不闪烁。
fn shade_delta(col: i32, row: i32) -> i32 {
    let h = (col.wrapping_mul(73_856_093) ^ row.wrapping_mul(19_349_663)) as u32;
    ((h >> 3) % 7) as i32 - 3
}

fn shade(c: Color32, d: i32) -> Color32 {
    let f = |v: u8| (v as i32 + d).clamp(0, 255) as u8;
    Color32::from_rgb(f(c.r()), f(c.g()), f(c.b()))
}

/// 本地坐标下的正六边形顶点（pointy-top，与全局布局一致）。
fn hex_verts(c: Pos2, hs: f32) -> Vec<Pos2> {
    (0..6)
        .map(|i| {
            let ang = std::f32::consts::PI / 6.0 + i as f32 * std::f32::consts::PI / 3.0;
            Pos2::new(c.x + hs * ang.cos(), c.y + hs * ang.sin())
        })
        .collect()
}

/// 烘焙静态地图层：生成与旧逐帧绘制**完全相同**的矢量形状并一次性锯齿化。
pub fn build(
    game: &GameState,
    hs: f32,
    dist: &HashMap<Hex, (i32, i32)>,
    deploying: bool,
    ctx: &egui::Context,
) -> MapLayer {
    let s = hs / 26.0; // 装饰细节以 s=1 时的单位长度书写
    let mut shapes: Vec<Shape> = Vec::with_capacity(2048);

    for row in 0..game.map.rows {
        for col in 0..game.map.cols {
            let h = hex::axial_from_offset(col, row);
            let c = Pos2::new(
                1.732_050_8 * hs * (col as f32 + 0.5 * (row % 2) as f32),
                1.5 * hs * row as f32,
            );
            let verts = hex_verts(c, hs);

            // 底色：岩石 / 楼房 / 森林 / 普通（带每格明暗微差）
            let (fill, stroke) = if game.map.obstacles.contains(&h) {
                (theme::ROCK, Stroke::new(1.4 * s, theme::ROCK_EDGE))
            } else if game.map.water.contains(&h) {
                (theme::WATER, Stroke::new(1.2 * s, theme::WATER_EDGE))
            } else if game.map.buildings.contains(&h) {
                (theme::BUILDING, Stroke::new(1.2 * s, theme::BUILDING_EDGE))
            } else if game.map.forests.contains(&h) {
                (theme::FOREST, Stroke::new(1.2 * s, theme::FOREST_EDGE))
            } else if game.map.roads.contains(&h) {
                (theme::ROAD, Stroke::new(1.1 * s, theme::ROAD_EDGE))
            } else {
                (theme::PLAIN, Stroke::new(1.1 * s, theme::PLAIN_EDGE))
            };
            shapes.push(Shape::convex_polygon(
                verts.clone(),
                shade(fill, shade_delta(col, row)),
                stroke,
            ));

            // 地形装饰（岩石/森林/楼房）
            if game.map.obstacles.contains(&h) {
                // 岩石：带受光面的多边形石块
                for (dx, dy, rs) in [(-7.0, -2.0, 5.4), (5.5, -5.0, 4.4), (1.0, 6.0, 4.8)] {
                    let t = Pos2::new(c.x + dx * s, c.y + dy * s);
                    let r = rs * s;
                    let rock = vec![
                        Pos2::new(t.x - r, t.y + r * 0.55),
                        Pos2::new(t.x - r * 0.55, t.y - r * 0.7),
                        Pos2::new(t.x + r * 0.25, t.y - r * 0.9),
                        Pos2::new(t.x + r, t.y + r * 0.1),
                        Pos2::new(t.x + r * 0.5, t.y + r * 0.6),
                    ];
                    shapes.push(Shape::convex_polygon(
                        rock.clone(),
                        Color32::from_rgb(118, 116, 110),
                        Stroke::new(1.0, Color32::from_rgb(70, 68, 62)),
                    ));
                    let lit = vec![
                        rock[1],
                        rock[2],
                        Pos2::new(t.x + r * 0.15, t.y - r * 0.1),
                        Pos2::new(t.x - r * 0.3, t.y - r * 0.05),
                    ];
                    shapes.push(Shape::convex_polygon(
                        lit,
                        Color32::from_rgb(146, 144, 138),
                        Stroke::NONE,
                    ));
                }
            } else if game.map.forests.contains(&h) {
                // 森林：三棵双层树冠的松树
                for (dx, dy, ts) in [(-6.0, 2.0, 1.0), (5.0, 4.0, 0.9), (0.5, -5.0, 1.15)] {
                    let t = Pos2::new(c.x + dx * s, c.y + dy * s);
                    let k = ts * s;
                    shapes.push(Shape::rect_filled(
                        Rect::from_center_size(
                            Pos2::new(t.x, t.y + 4.6 * k),
                            egui::vec2(1.8 * k, 3.0 * k),
                        ),
                        0.0,
                        Color32::from_rgb(74, 54, 34),
                    ));
                    let back = vec![
                        Pos2::new(t.x - 4.4 * k, t.y + 3.6 * k),
                        Pos2::new(t.x + 4.4 * k, t.y + 3.6 * k),
                        Pos2::new(t.x, t.y - 5.0 * k),
                    ];
                    shapes.push(Shape::convex_polygon(
                        back,
                        Color32::from_rgb(34, 84, 42),
                        Stroke::NONE,
                    ));
                    let front = vec![
                        Pos2::new(t.x - 3.1 * k, t.y + 1.6 * k),
                        Pos2::new(t.x + 3.1 * k, t.y + 1.6 * k),
                        Pos2::new(t.x, t.y - 6.2 * k),
                    ];
                    shapes.push(Shape::convex_polygon(
                        front.clone(),
                        Color32::from_rgb(56, 122, 60),
                        Stroke::NONE,
                    ));
                    shapes.push(Shape::closed_line(
                        front,
                        Stroke::new(0.8, Color32::from_rgb(84, 152, 84)),
                    ));
                }
            } else if game.map.buildings.contains(&h) {
                // 楼房：阴影 + 墙体 + 屋顶 + 门 + 窗
                let shadow = Rect::from_center_size(
                    Pos2::new(c.x + 1.5 * s, c.y + 2.5 * s),
                    egui::vec2(22.0 * s, 16.0 * s),
                );
                shapes.push(Shape::rect_filled(shadow, 2.0, Color32::from_black_alpha(60)));
                let body = Rect::from_center_size(
                    Pos2::new(c.x, c.y + 1.0 * s),
                    egui::vec2(20.0 * s, 11.0 * s),
                );
                shapes.push(Shape::rect_filled(body, 1.0, Color32::from_rgb(172, 150, 116)));
                shapes.push(Shape::rect_stroke(
                    body,
                    1.0,
                    Stroke::new(1.0, Color32::from_rgb(100, 84, 64)),
                    StrokeKind::Middle,
                ));
                let roof = vec![
                    Pos2::new(c.x - 12.0 * s, c.y + 1.0 * s),
                    Pos2::new(c.x + 12.0 * s, c.y + 1.0 * s),
                    Pos2::new(c.x, c.y - 8.0 * s),
                ];
                shapes.push(Shape::convex_polygon(
                    roof.clone(),
                    Color32::from_rgb(122, 62, 46),
                    Stroke::NONE,
                ));
                shapes.push(Shape::closed_line(
                    roof,
                    Stroke::new(1.0, Color32::from_rgb(78, 42, 30)),
                ));
                shapes.push(Shape::rect_filled(
                    Rect::from_center_size(
                        Pos2::new(c.x, c.y + 5.0 * s),
                        egui::vec2(4.0 * s, 5.0 * s),
                    ),
                    0.5,
                    Color32::from_rgb(74, 60, 46),
                ));
                for wx in [-6.0, 6.0] {
                    shapes.push(Shape::rect_filled(
                        Rect::from_center_size(
                            Pos2::new(c.x + wx * s, c.y + 2.8 * s),
                            egui::vec2(2.6 * s, 2.6 * s),
                        ),
                        0.5,
                        Color32::from_rgb(226, 206, 156),
                    ));
                }
            } else if game.map.roads.contains(&h) {
                // 道路：深色路面 + 中央虚线（同排相邻格可连成车道）
                let band = vec![
                    Pos2::new(c.x - hs * 0.86, c.y - 4.0 * s),
                    Pos2::new(c.x + hs * 0.86, c.y - 4.0 * s),
                    Pos2::new(c.x + hs * 0.86, c.y + 4.0 * s),
                    Pos2::new(c.x - hs * 0.86, c.y + 4.0 * s),
                ];
                shapes.push(Shape::convex_polygon(
                    band,
                    Color32::from_rgb(74, 72, 69),
                    Stroke::NONE,
                ));
                for k in [-0.5f32, 0.5] {
                    let x = c.x + k * hs;
                    shapes.push(Shape::line_segment(
                        [Pos2::new(x, c.y), Pos2::new(x + hs * 0.22, c.y)],
                        Stroke::new(1.4 * s, theme::ROAD_MARK),
                    ));
                }
            }

            // 战争迷雾（两层半透明灰蒙层，观感与旧版一致）
            if !deploying {
                let d = dist.get(&h).copied();
                let (depth, v) = d.unwrap_or((i32::MAX, 0));
                if depth > v {
                    shapes.push(Shape::convex_polygon(
                        verts.clone(),
                        Color32::from_rgba_unmultiplied(70, 74, 72, 165),
                        Stroke::new(
                            1.1 * s,
                            Color32::from_rgba_unmultiplied(95, 100, 97, 110),
                        ),
                    ));
                } else if depth > v / 2 {
                    shapes.push(Shape::convex_polygon(
                        verts.clone(),
                        Color32::from_rgba_unmultiplied(112, 116, 112, 78),
                        Stroke::new(
                            1.0 * s,
                            Color32::from_rgba_unmultiplied(128, 132, 128, 55),
                        ),
                    ));
                }
            }
        }
    }

    // 一次性锯齿化（含抗锯齿羽化，观感与逐帧绘制一致），合并为单个 Mesh
    let clip = Rect::from_min_max(Pos2::new(-1.0e5, -1.0e5), Pos2::new(1.0e5, 1.0e5));
    let tessellated = ctx.tessellate(
        vec![egui::epaint::ClippedShape {
            clip_rect: clip,
            shape: Shape::Vec(shapes),
        }],
        ctx.pixels_per_point(),
    );
    let mut mesh = Mesh::default();
    for cm in tessellated {
        if let egui::epaint::Primitive::Mesh(m) = cm.primitive {
            let base = mesh.vertices.len() as u32;
            mesh.vertices.extend(m.vertices.iter().copied());
            mesh.indices.extend(m.indices.iter().map(|i| i + base));
        }
    }
    MapLayer {
        mesh,
        hs,
        dist_hash: dist_signature(dist),
        deploying,
    }
}
