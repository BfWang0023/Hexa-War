//! 期望伤害 / 击杀 / 压制 / 主动防御模型（新版 AI）。
//!
//! 严格镜像 game.rs 的结算规则，使 AI 决策与真实结算一致：
//! - 命中乘区由 GameState::direct_hit_rate 统一给出；
//! - 护甲门槛、坦克炮对装甲 50% 打 2、重机枪对步兵 50% 打 2；
//! - 主动防御（非坦克炮命中被抵消）、致命伤（直升机 50% 坠毁）；
//! - M3E1-XM1176 楼内强制击杀、重机枪/机关炮对步兵压制。

use std::collections::BTreeSet;

use crate::game::{AiDifficulty, GameState};

use super::belief::Belief;
use crate::hex::Hex;
use crate::unit::{Team, Unit, UnitKind};

#[derive(Clone, Copy, Debug, Default)]
pub struct Expected {
    pub p_hit: f64,
    pub p_kill: f64,
    pub e_hp: f64,
    pub p_suppress: f64,
    pub e_ad: f64,
}

pub fn kind_value(k: UnitKind) -> f64 {
    k.value() as f64
}

/// 直射期望：命中率、击杀概率、期望扣血、压制概率、对主动防御的期望消耗。
pub fn expected_direct(game: &GameState, attacker: &Unit, target: &Unit) -> Expected {
    let target_h = target.pos;
    let (hit, _note) = game.direct_hit_rate(attacker, target, target_h, true, true);
    let p_hit = (hit as f64 / 100.0).clamp(0.0, 1.0);
    let mut e = Expected { p_hit, ..Default::default() };
    let atk = attacker.eff_attack();
    let arm = target.kind.armor();
    let hp = target.hp.max(1) as f64;
    // 护甲抵挡：攻击力恰好等于护甲时，命中后 50% 概率被抵挡（不掉血）。
    // 压制不受影响（命中即可能压制）。
    let keep = if atk == arm { 0.5 } else { 1.0 };

    // M3E1-XM1176：楼内目标（非屋顶）强制击杀
    let xm = attacker.kind == UnitKind::Rifleman
        && attacker.missile_mode
        && !target.kind.is_air()
        && game.map.buildings.contains(&target_h)
        && !target.rooftop;
    if xm {
        e.p_kill = p_hit;
        e.e_hp = p_hit * hp;
        return e;
    }

    // 压制（重机枪/机关炮/重机枪手对步兵；与命中共用一次 roll，概率与命中无关）
    if target.kind.is_direct_suppressible() && attacker.is_suppressing_weapon() {
        e.p_suppress = (game.suppression_rate(target, target_h, attacker.suppression_base()) as f64
            / 100.0)
            .clamp(0.0, 1.0);
    }

    if atk < arm {
        return e;
    }

    let cook_off = target.kind.cook_off_chance();
    let p2: f64 = if attacker.is_tank_gun_mode() && cook_off > 0 {
        // 殉爆：主战坦克 30%、一般坦克 60%、步战/骑兵战车 60%、其它护甲2 70%、护甲1 80%
        cook_off as f64 / 100.0
    } else if (attacker.kind == UnitKind::HmgGunner || attacker.is_heavy_mg_mode())
        && target.kind.is_foot()
    {
        0.5 // 重机枪重弹
    } else {
        0.0
    };
    let dmg_given_hit = (1.0 + p2).min(hp);
    let kill_given_hit = if hp <= 1.0 {
        1.0
    } else if hp <= 2.0 {
        p2
    } else {
        0.0
    };

    if target.ad_uses > 0 && !attacker.is_tank_gun_mode() {
        // 主动防御抵消本次伤害，但消耗 1 次
        e.p_kill = 0.0;
        e.e_hp = 0.0;
        e.e_ad = p_hit;
        return e;
    }

    // 悍马系列：被机炮（40%）命中时直接击毁（无视血量）；
    // 坦克炮不再直接击毁，改由上面的 p2（殉爆 80%）计入。
    let ik = attacker.humvee_instant_kill_chance(target.kind) as f64 / 100.0;
    if ik > 0.0 {
        e.p_kill = p_hit * (ik + (1.0 - ik) * kill_given_hit) * keep;
        e.e_hp = p_hit * (ik * hp + (1.0 - ik) * dmg_given_hit) * keep;
        return e;
    }

    e.p_kill = p_hit * kill_given_hit * keep;
    e.e_hp = p_hit * dmg_given_hit * keep;
    if matches!(target.kind, UnitKind::AttackHeli | UnitKind::HeavyTransportHeli) {
        e.p_kill += p_hit * 0.5 * keep;
        e.e_hp += p_hit * 0.5 * hp * keep;
    }
    e
}

/// 范围攻击每格命中率（中心/周围）。
pub fn area_hit_rate(attacker: &Unit, center: Hex, cell: Hex) -> f64 {
    let m864 = attacker.kind == UnitKind::Howitzer && attacker.missile_mode;
    if m864 {
        return 1.0;
    }
    match attacker.kind {
        UnitKind::Howitzer => {
            if cell == center {
                0.8
            } else {
                0.5
            }
        }
        UnitKind::Mortar => {
            if cell == center {
                0.6
            } else {
                0.3
            }
        }
        _ => 0.0,
    }
}

/// 范围攻击对一个中心的期望得分：敌方期望扣血/击杀为正，友军误伤为负，
/// 范围压制（命中与否都施加）单独计入。只统计已侦察到的敌军。
pub fn blast_score(
    game: &GameState,
    team: Team,
    attacker: &Unit,
    center: Hex,
    visible: &BTreeSet<Hex>,
    ghosts: &[(Hex, UnitKind, i32)],
    belief: &Belief,
) -> f64 {
    let mut cells = vec![center];
    for n in center.neighbors() {
        if game.map.contains(n) {
            cells.push(n);
        }
    }
    let mut score = 0.0f64;
    for cell in cells {
        let rate = area_hit_rate(attacker, center, cell);
        if let Some(occ) = game.unit_at(cell) {
            // 间瞄火力（榴弹炮/迫击炮）打不到空中单位：直升机/无人机既不会被
            // 炸伤也不会被压制（见 GameState::area_attack），因此完全不计入炮击
            // 收益，避免 AI 朝直升机浪费炮弹。空中单位可与地面单位同格，此处
            // unit_at 优先返回地面单位，故只有"该格仅有空中单位"时才会走到这里。
            if !occ.kind.is_air() {
                let tv = kind_value(occ.kind);
                let can_dmg = attacker.eff_attack() >= occ.kind.armor();
                if occ.team == team {
                    // 误伤扣分（按价值近似）
                    score -= rate * tv * 0.8;
                } else if visible.contains(&cell) {
                    if can_dmg {
                        // 攻击力 == 护甲时 50% 被抵挡
                        let deflect = if attacker.eff_attack() == occ.kind.armor() { 0.5 } else { 1.0 };
                        let hpv = tv / occ.kind.max_hp() as f64;
                        score += rate * hpv * 1.2 * deflect;
                        if occ.hp == 1 {
                            score += rate * (tv + 6.0) * 0.15 * deflect;
                        }
                    }
                    // 范围压制：命中与否都压制 1 层（护甲 ≥ 2 的单位免疫火炮压制）
                    if attacker.kind.artillery_suppresses(occ.kind) {
                        score += tv * 0.25;
                    }
                } else if let Some(gv) = ghost_value(ghosts, cell) {
                    // 未侦察到但最后已知在该格：折扣预打
                    score += rate * gv * 0.25;
                }
            }
        } else if let Some(gv) = ghost_value(ghosts, cell) {
            score += rate * gv * 0.25;
        }
        // 概率信念：未侦察格存在未确认敌军的期望价值（按名义价值折扣预打）
        if !visible.contains(&cell) {
            let bp = belief.prob(cell);
            if bp > 0.0 {
                score += rate * bp * 20.0;
            }
        }
    }
    score
}

/// 该格及其邻格中最近已知敌方幽灵的最高价值。
/// 空中单位（直升机/无人机）不计入：间瞄火力打不到它们，预打其最后已知位置
/// 只会浪费炮弹。
fn ghost_value(ghosts: &[(Hex, UnitKind, i32)], cell: Hex) -> Option<f64> {
    ghosts
        .iter()
        .filter(|(h, k, _)| Hex::distance(*h, cell) <= 1 && !k.is_air())
        .map(|(_, k, _)| kind_value(*k))
        .fold(None, |acc: Option<f64>, v| {
            Some(acc.map_or(v, |a| a.max(v)))
        })
}

/// 统一效用权重。风格/难度档位未来在此覆盖（见设计文档 Phase 5）。
#[derive(Clone, Copy, Debug)]
pub struct Weights {
    pub kill: f64,
    pub dmg: f64,
    pub suppress: f64,
    pub ad: f64,
    pub expose: f64,
    pub cover: f64,
    pub objective: f64,
    pub ammo: f64,
    /// 全队集火目标加成。
    pub focus: f64,
    /// 侦察信息增益权重。
    pub info: f64,
}

impl Default for Weights {
    fn default() -> Self {
        Self {
            kill: 1.0,
            dmg: 0.7,
            suppress: 0.5,
            ad: 0.5,
            expose: 1.0,
            cover: 1.0,
            objective: 1.5,
            ammo: 0.4,
            focus: 2.5,
            info: 0.8,
        }
    }
}

impl Weights {
    /// 难度档位 → 权重预设（新兵弱、精英强）。
    pub fn for_difficulty(d: AiDifficulty) -> Self {
        match d {
            AiDifficulty::Recruit => Self {
                kill: 0.6,
                dmg: 0.5,
                suppress: 0.3,
                ad: 0.3,
                expose: 0.5,
                cover: 0.6,
                objective: 1.0,
                ammo: 0.9,
                focus: 0.8,
                info: 0.3,
            },
            AiDifficulty::Regular => Self::default(),
            AiDifficulty::Veteran => Self {
                kill: 1.3,
                dmg: 0.8,
                suppress: 0.6,
                ad: 0.7,
                expose: 1.2,
                cover: 1.2,
                objective: 1.8,
                ammo: 0.3,
                focus: 3.5,
                info: 1.0,
            },
            AiDifficulty::Elite => Self {
                kill: 1.6,
                dmg: 0.9,
                suppress: 0.7,
                ad: 0.9,
                expose: 1.4,
                cover: 1.35,
                objective: 2.0,
                ammo: 0.2,
                focus: 4.5,
                info: 1.2,
            },
        }
    }
}

/// 单位"存量价值"：价值 × 血量比例（用于盘面评估）。
pub fn unit_strength(u: &Unit) -> f64 {
    let frac = u.hp.max(0) as f64 / u.kind.max_hp().max(1) as f64;
    kind_value(u.kind) * (0.5 + 0.5 * frac)
}

/// 盘面评估：己方存量 - 敌方存量（含搭载）+ 据点控制 + 目标推进 - 威胁暴露。
/// 用于 team-turn 束搜索比较"整队行动序列"的结果盘面。
pub fn score_state(game: &GameState, team: Team, objective: Option<Hex>) -> f64 {
    let opp = team.opponent();
    let mut s = 0.0f64;
    for u in game.units_of(team) {
        s += unit_strength(u);
        for p in &u.passengers {
            s += unit_strength(p);
        }
    }
    for u in game.units_of(opp) {
        s -= 0.95 * unit_strength(u);
        for p in &u.passengers {
            s -= 0.95 * unit_strength(p);
        }
    }
    // 关键据点：控制分 + 攻防态势（进攻/坚守/固守任务都以此为核心；
    // 大本营仅决定增援区域，不参与胜负）。
    let own_ground: Vec<Hex> = game
        .units_of(team)
        .into_iter()
        .filter(|u| !u.kind.is_air())
        .map(|u| u.pos)
        .collect();
    for (h, kp) in game.keypoints.iter().filter(|(_, kp)| !kp.center) {
        if kp.controller == team {
            s += 4.0;
            // 已控制的据点需有人驻守：无人驻守则易手风险高。
            let guarded = own_ground.iter().any(|p| Hex::distance(*p, *h) <= 2);
            s += if guarded { 2.2 } else { -2.2 };
        } else {
            s -= 4.0;
            // 未控制的据点：鼓励向其推进（最近陆军距离越近越好）。
            if !own_ground.is_empty() {
                let d = own_ground
                    .iter()
                    .map(|p| Hex::distance(*p, *h))
                    .min()
                    .unwrap_or(0) as f64;
                s -= 0.3 * d.min(20.0);
            }
        }
    }
    if let Some(obj) = objective {
        let mut d = 0.0;
        let mut n = 0.0;
        for u in game.units_of(team) {
            if !u.kind.is_air() {
                d += Hex::distance(u.pos, obj) as f64;
                n += 1.0;
            }
        }
        if n > 0.0 {
            s -= 0.6 * (d / n);
        }
    }
    // 廉价威胁：己方单位暴露在敌方"机动+射程"覆盖下的次数
    let foes = game.units_of(opp);
    for u in game.units_of(team) {
        for e in &foes {
            if e.kind.can_attack()
                && Hex::distance(u.pos, e.pos) <= e.kind.movement() + e.eff_range()
            {
                s -= 0.15;
            }
        }
    }
    s
}

pub fn attack_utility(e: &Expected, target: &Unit, w: &Weights) -> f64 {
    let tv = kind_value(target.kind);
    let hpv = tv / target.kind.max_hp() as f64;
    w.kill * e.p_kill * (tv + 6.0)
        + w.dmg * e.e_hp * hpv
        + w.suppress * e.p_suppress * (tv * 0.5)
        + w.ad * e.e_ad * (tv * 0.3)
        - w.ammo
}
