//! 新版 AI（v2）：期望伤害 + 统一效用 + 行动枚举 + 威胁图。
//! 与旧版 src/ai.rs 并存，由 GameState.ai_version 在运行时选择。
//! 设计文档见 docs/AI_REWRITE_DESIGN.md。
//!
//! 当前进度（Phase 1-2）：
//! - 精确期望伤害/击杀/压制/主动防御模型（eval.rs）
//! - 感知世界与量化威胁图（world.rs）
//! - 统一效用 + 宏行动枚举（移动后射击）（plan.rs）
//! - 火炮/迫击炮的期望爆炸评分
//! - 特殊武器自动切换
//! - 主动防御目标齐射
//! - 招募/部署暂委托旧版（Phase 4 再替换）

mod belief;
mod eval;
mod operational;
mod plan;
mod strategic;
mod threat;
mod world;

use crate::game::GameState;
use crate::unit::Team;

pub fn take_turn(game: &mut GameState, team: Team) -> Vec<String> {
    let mut log = Vec::new();
    run_ai_turn(game, team, &mut log);
    log
}

pub fn run_ai_turn(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    plan::run_turn(game, team, log);
}

pub fn ai_deploy(game: &mut GameState, team: Team) -> Vec<String> {
    // 战略层：反制组成优化（估计敌方组成 → 角色需求 → 预算内贪心选兵）。
    strategic::deploy_initial(game, team)
}

#[cfg(test)]
mod tests {
    use super::world::PerceivedWorld;
    use super::*;
    use crate::hex;
    use crate::hex::Hex;
    use crate::unit::{Unit, UnitKind};

    fn clear(g: &mut GameState, h: Hex) {
        g.map.obstacles.remove(&h);
        g.map.buildings.remove(&h);
        g.map.forests.remove(&h);
        g.map.water.remove(&h);
    }

    /// 期望命中率必须与规则一致（步枪 80%）。
    #[test]
    fn expected_direct_rifle_vs_rifle() {
        let mut g = GameState::new_seeded(42);
        let h1 = hex::axial_from_offset(3, 6);
        let h2 = hex::axial_from_offset(4, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        let a = Unit::new(UnitKind::Rifleman, Team::Ai, h1);
        let t = Unit::new(UnitKind::Rifleman, Team::Player, h2);
        g.units.insert(h1, a.clone());
        g.units.insert(h2, t.clone());
        let e = eval::expected_direct(&g, &a, &t);
        assert!((e.p_hit - 0.8).abs() < 1e-9, "p_hit={}", e.p_hit);
        assert!(e.e_hp > 0.0 && e.e_hp <= 2.0, "e_hp={}", e.e_hp);
        assert!(e.p_kill <= e.p_hit + 1e-9);
    }

    /// 新版 AI 完整跑一回合不 panic，并产生行动日志。
    #[test]
    fn v2_turn_runs() {
        let mut g = GameState::new_seeded(7);
        let h1 = hex::axial_from_offset(22, 6);
        let h2 = hex::axial_from_offset(5, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        g.units.insert(h1, Unit::new(UnitKind::Tank, Team::Ai, h1));
        g.units
            .insert(h2, Unit::new(UnitKind::Rifleman, Team::Player, h2));
        g.phase = Team::Ai;
        let log = take_turn(&mut g, Team::Ai);
        assert!(!log.is_empty(), "新版 AI 应产生行动日志");
    }

    /// 相邻可见的脆弱目标应触发攻击（期望击杀价值足够高）。
    #[test]
    fn v2_attacks_visible_enemy() {
        let mut g = GameState::new_seeded(11);
        let h1 = hex::axial_from_offset(10, 6);
        let h2 = hex::axial_from_offset(11, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        g.units
            .insert(h1, Unit::new(UnitKind::Rifleman, Team::Ai, h1));
        g.units.insert(h2, Unit::new(UnitKind::Atgm, Team::Player, h2));
        g.phase = Team::Ai;
        let log = take_turn(&mut g, Team::Ai);
        assert!(
            log.iter().any(|l| l.contains("攻击")),
            "相邻可见敌人应触发攻击: {:?}",
            log
        );
    }

    /// 路由按 ai_version 分发到新版，不 panic。
    #[test]
    fn router_dispatches_v2() {
        let mut g = GameState::new_seeded(5);
        g.ai_version = crate::game::AiVersion::V2;
        let h = hex::axial_from_offset(20, 6);
        clear(&mut g, h);
        g.units.insert(h, Unit::new(UnitKind::Scout, Team::Ai, h));
        g.phase = Team::Ai;
        let log = crate::ai_router::take_turn(&mut g, Team::Ai);
        assert!(!log.is_empty());
    }

    /// 端到端冒烟：新版（蓝）对旧版（红）跑多回合，不 panic、不卡死。
    #[test]
    fn v2_vs_legacy_playable() {
        use crate::ai;
        let mut g = GameState::new_seeded(2024);
        let blue = [UnitKind::Rifleman, UnitKind::Tank, UnitKind::Atgm];
        let red = [UnitKind::Rifleman, UnitKind::Tank, UnitKind::Atgm];
        for (i, k) in blue.iter().enumerate() {
            let h = hex::axial_from_offset(4 + i as i32, 6);
            clear(&mut g, h);
            g.units.insert(h, Unit::new(*k, Team::Player, h));
        }
        for (i, k) in red.iter().enumerate() {
            let h = hex::axial_from_offset(22 - i as i32, 6);
            clear(&mut g, h);
            g.units.insert(h, Unit::new(*k, Team::Ai, h));
        }
        for _ in 0..8 {
            if g.game_over() {
                break;
            }
            g.begin_turn(Team::Player);
            let mut lp = Vec::new();
            run_ai_turn(&mut g, Team::Player, &mut lp);
            if g.game_over() {
                break;
            }
            g.begin_turn(Team::Ai);
            let mut la = Vec::new();
            ai::run_ai_turn(&mut g, Team::Ai, &mut la);
        }
        assert!(g.game_over() || !g.units_of(Team::Player).is_empty());
    }

    /// 战役层：角色分配 + 集火目标（残血高价值目标优先）。
    #[test]
    fn operational_roles_and_focus() {
        let mut g = GameState::new_seeded(99);
        let hs = [
            (hex::axial_from_offset(22, 6), UnitKind::Tank),
            (hex::axial_from_offset(24, 6), UnitKind::Howitzer),
            (hex::axial_from_offset(21, 6), UnitKind::Drone),
            (hex::axial_from_offset(23, 4), UnitKind::AaInfantry),
        ];
        for (h, k) in hs {
            clear(&mut g, h);
            g.units.insert(h, Unit::new(k, Team::Ai, h));
        }
        let h_e = hex::axial_from_offset(18, 6);
        clear(&mut g, h_e);
        let mut e = Unit::new(UnitKind::Tank, Team::Player, h_e);
        e.hp = 1; // 残血 → 应成为集火目标
        g.units.insert(h_e, e);

        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        let label_of = |g: &GameState, k: UnitKind| {
            g.units_of(Team::Ai)
                .iter()
                .find(|u| u.kind == k)
                .unwrap()
                .label
        };
        assert_eq!(op.role_of(label_of(&g, UnitKind::Drone)), operational::Role::Recon);
        assert_eq!(
            op.role_of(label_of(&g, UnitKind::Howitzer)),
            operational::Role::FireSupport
        );
        assert_eq!(
            op.role_of(label_of(&g, UnitKind::AaInfantry)),
            operational::Role::AntiAir
        );
        assert_eq!(
            op.role_of(label_of(&g, UnitKind::Tank)),
            operational::Role::AntiArmor
        );
        assert_eq!(op.focus, Some(h_e));
    }

    /// 信息增益：远离己方视野处为正；视野为 0 时为 0。
    #[test]
    fn recon_info_gain() {
        let mut g = GameState::new_seeded(3);
        let h = hex::axial_from_offset(4, 6);
        clear(&mut g, h);
        g.units.insert(h, Unit::new(UnitKind::Scout, Team::Ai, h));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let far = hex::axial_from_offset(20, 6);
        assert!(world.info_gain(&g, far, 6) > 0, "远离视野处应有信息增益");
        assert_eq!(world.info_gain(&g, h, 0), 0);
    }

    /// 范围攻击会对"最后已知位置"（幽灵）按折扣计入。
    #[test]
    fn blast_scores_ghost() {
        use std::collections::BTreeSet;
        let mut g = GameState::new_seeded(21);
        let hh = hex::axial_from_offset(20, 6);
        clear(&mut g, hh);
        let how = Unit::new(UnitKind::Howitzer, Team::Ai, hh);
        g.units.insert(hh, how.clone());
        let ghost = hex::axial_from_offset(12, 6);
        let vis: BTreeSet<Hex> = BTreeSet::new();
        let ghosts = vec![(ghost, UnitKind::Tank, 1)];
        let s = eval::blast_score(
            &g,
            Team::Ai,
            &how,
            ghost,
            &vis,
            &ghosts,
            &crate::ai_v2::belief::Belief::default(),
        );
        assert!(s > 0.0, "对幽灵位置应有折扣炮击价值: {}", s);
    }

    /// 间瞄火力打不到直升机：只含直升机的炮击中心期望得分为 0（含幽灵也不计）。
    #[test]
    fn blast_ignores_helicopters() {
        use std::collections::BTreeSet;
        let mut g = GameState::new_seeded(23);
        let hh = hex::axial_from_offset(20, 6);
        clear(&mut g, hh);
        let how = Unit::new(UnitKind::Howitzer, Team::Ai, hh);
        g.units.insert(hh, how.clone());
        let heli_h = hex::axial_from_offset(12, 6);
        clear(&mut g, heli_h);
        g.air_units
            .insert(heli_h, Unit::new(UnitKind::AttackHeli, Team::Player, heli_h));
        let vis: BTreeSet<Hex> = [heli_h].into_iter().collect();
        let ghosts = vec![(heli_h, UnitKind::AttackHeli, 1)];
        let s = eval::blast_score(
            &g,
            Team::Ai,
            &how,
            heli_h,
            &vis,
            &ghosts,
            &crate::ai_v2::belief::Belief::default(),
        );
        assert_eq!(s, 0.0, "直升机不应计入炮击收益: {}", s);
        // 对照：同格换成地面目标时应有正收益
        g.air_units.clear();
        g.units
            .insert(heli_h, Unit::new(UnitKind::Rifleman, Team::Player, heli_h));
        let s2 = eval::blast_score(
            &g,
            Team::Ai,
            &how,
            heli_h,
            &vis,
            &[],
            &crate::ai_v2::belief::Belief::default(),
        );
        assert!(s2 > 0.0, "地面目标应有炮击收益: {}", s2);
    }

    /// 战役地图端到端：新版 AI 按本方胜利条件选择任务（战役示例 AI = C 固守），
    /// 并以已控制关键据点为核心组织防御；跑多个 AI 回合不 panic。
    #[test]
    fn v2_campaign_defend_mission_runs() {
        use crate::mapdef::CustomMap;
        let cm = CustomMap::load(std::path::Path::new("maps/战役示例.json"))
            .expect("加载战役示例地图");
        let mut g = GameState::new_custom_deploy(2025, cm);
        g.ai_version = crate::game::AiVersion::V2;
        assert!(!g.deploying, "战役地图直接开战");
        assert!(
            g.keypoints.values().any(|kp| !kp.center),
            "战役地图应有关键据点"
        );
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        assert_eq!(
            op.mission,
            operational::Mission::Defend,
            "战役示例 AI 胜利条件为 C 固守"
        );
        for _ in 0..3 {
            if g.game_over() {
                break;
            }
            g.begin_turn(Team::Ai);
            let log = take_turn(&mut g, Team::Ai);
            assert!(
                g.game_over() || !log.is_empty(),
                "固守任务应产生行动日志: {:?}",
                log
            );
            if g.game_over() {
                break;
            }
            g.begin_turn(Team::Player);
        }
    }

    /// 难度档位：权重单调变强，且各档位都能完整跑一回合。
    #[test]
    fn difficulty_profiles() {
        let easy = eval::Weights::for_difficulty(crate::game::AiDifficulty::Recruit);
        let elite = eval::Weights::for_difficulty(crate::game::AiDifficulty::Elite);
        assert!(easy.focus < elite.focus);
        assert!(easy.expose < elite.expose);
        for d in crate::game::AiDifficulty::all() {
            let mut g = GameState::new_seeded(13);
            let h1 = hex::axial_from_offset(10, 6);
            let h2 = hex::axial_from_offset(11, 6);
            clear(&mut g, h1);
            clear(&mut g, h2);
            g.units
                .insert(h1, Unit::new(UnitKind::Rifleman, Team::Ai, h1));
            g.units.insert(h2, Unit::new(UnitKind::Atgm, Team::Player, h2));
            g.phase = Team::Ai;
            g.ai_difficulty = d;
            let log = take_turn(&mut g, Team::Ai);
            assert!(!log.is_empty(), "难度 {:?} 应产生行动", d);
        }
    }
}
