//! 战役层（新版 AI，Phase 3）：任务组/角色分配 + 全队集火目标 + 作战目标。
//!
//! 借鉴 Civ 的 Operation / XCOM 的任务组：每回合把己方单位编成
//! 侦察 / 火力 / 反装甲 / 防空 / 突击 / 预备，并给出全队统一的
//! 作战目标、侦察方向与集火目标，供战术层统一效用使用。

use std::collections::{HashMap, HashSet};

use crate::game::{AiConfig, GameState};
use crate::hex::{self, Hex};
use crate::mapdef::VictoryRule;
use crate::unit::{Team, Unit, UnitKind};

use super::eval::{self, kind_value};
use super::threat::{self, EnemyTeam};
use super::world::PerceivedWorld;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Role {
    Recon,
    FireSupport,
    AntiArmor,
    AntiAir,
    Assault,
    Reserve,
}

impl Role {
    /// 行动顺序优先级（越大越先动）。
    pub fn priority(self) -> i32 {
        match self {
            Role::Recon => 6,
            Role::FireSupport => 5,
            Role::AntiArmor => 4,
            Role::AntiAir => 3,
            Role::Assault => 2,
            Role::Reserve => 1,
        }
    }

    #[allow(dead_code)]
    pub fn name(self) -> &'static str {
        match self {
            Role::Recon => "侦察",
            Role::FireSupport => "火力",
            Role::AntiArmor => "反装甲",
            Role::AntiAir => "防空",
            Role::Assault => "突击",
            Role::Reserve => "预备",
        }
    }
}

/// 新版 AI 的作战任务：由本方胜利条件（游戏目标）决定。
///
/// - Attack 进攻：胜利条件要求「占领全部关键据点」（含限时进攻）。
/// - Hold   坚守：先攻占全部关键据点，随后原地守住（B 类条件）。
/// - Defend 固守：只需守住已控制的关键据点，力量有余裕时才夺取其它据点（C 类条件）。
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub enum Mission {
    #[default]
    Attack,
    Hold,
    Defend,
}

impl Mission {
    /// 从本方胜利条件推导任务；非战役地图默认「占领全部即胜」= 进攻。
    pub fn of(game: &GameState, team: Team) -> Mission {
        match game.victory_rule(team) {
            VictoryRule::CaptureAllImmediate | VictoryRule::CaptureAllBeforeTurn { .. } => {
                Mission::Attack
            }
            VictoryRule::HoldAllAtTurn { .. } => Mission::Hold,
            VictoryRule::HoldAnyAtEnd => Mission::Defend,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Mission::Attack => "进攻",
            Mission::Hold => "坚守",
            Mission::Defend => "固守",
        }
    }
}

/// 本回合作战计划。
#[derive(Clone, Debug, Default)]
pub struct Operation {
    pub roles: HashMap<char, Role>,
    /// 全队优先击杀的可见敌人（按价值/可击杀性评分）。
    pub focus: Option<Hex>,
    /// 主攻/防守目标（关键据点、敌方大本营、回防点等）。
    pub objective: Option<Hex>,
    /// 侦察方向（前出开眼的目标点）。
    pub recon_target: Option<Hex>,
    /// 己方大本营中心。
    pub hq: Option<Hex>,
    /// 已知敌方队伍（按优先级降序）；每队中心是一个动态 objective。
    /// 保留字段供后续按队伍分配兵种/记录战况使用。
    #[allow(dead_code)]
    pub teams: Vec<EnemyTeam>,
    /// 每个己方单位被分配到的作战目标（据点/敌军队伍中心）。
    pub unit_objectives: HashMap<char, Hex>,
    /// 驻守据点的单位标签（固定驻地，交火后仍被拉回，不被抽调到前线）。
    pub base_guards: HashSet<char>,
    /// 本回合任务（由本方胜利条件决定；仅新版 AI 使用）。
    pub mission: Mission,
    /// 需要夺取的未控制关键据点（按离本方大本营由近到远）。
    pub targets: Vec<Hex>,
    /// 已控制、需要保护的关键据点（按受威胁程度由高到低）。
    pub held: Vec<Hex>,
    /// 据守/巡逻分配：单位标签 → 负责的据点格。
    pub garrisons: HashMap<char, Hex>,
}

impl Operation {
    pub fn role_of(&self, label: char) -> Role {
        self.roles.get(&label).copied().unwrap_or(Role::Assault)
    }

    /// 该单位的动态 objective（优先用队伍分配；否则用全队目标）。
    pub fn objective_for(&self, label: char) -> Option<Hex> {
        self.unit_objectives.get(&label).copied().or(self.objective)
    }
}

fn team_centroid(game: &GameState, team: Team) -> Option<Hex> {
    let us = game.units_of(team);
    if us.is_empty() {
        return None;
    }
    let (mut sc, mut sr) = (0i32, 0i32);
    for u in &us {
        let (c, r) = hex::offset_from_axial(u.pos);
        sc += c;
        sr += r;
    }
    Some(hex::axial_from_offset(
        sc / us.len() as i32,
        sr / us.len() as i32,
    ))
}

/// 作战目标：全面防御 → 回防大本营；总攻 → 敌方据点；
/// 否则优先夺回己方被占/占领敌方据点；再退化为最近可见敌人/幽灵；最后地图中心。
pub fn objective(game: &GameState, world: &PerceivedWorld, team: Team, from: Hex) -> Option<Hex> {
    if game.defense_triggered(team) {
        return game.hq_pos(team);
    }
    if game.sustain_assault_ready(team) {
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.controller == team.opponent())
            .min_by_key(|(h, _)| Hex::distance(from, **h))
        {
            return Some(*h);
        }
    }
    if game.sustain {
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.owner == team && kp.controller != team)
            .min_by_key(|(h, _)| Hex::distance(from, **h))
        {
            return Some(*h);
        }
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.controller == team.opponent())
            .min_by_key(|(h, _)| Hex::distance(from, **h))
        {
            return Some(*h);
        }
    }
    if let Some(e) = world
        .visible_enemies
        .iter()
        .min_by_key(|e| Hex::distance(from, e.pos))
    {
        return Some(e.pos);
    }
    if let Some(g) = game.ghosts.get(&team) {
        if let Some((h, _)) = g.iter().min_by_key(|(h, _)| Hex::distance(from, **h)) {
            return Some(*h);
        }
    }
    // 无任何敌情：以玩家大本营（敌方中心据点）为目标
    if let Some((h, _)) = game
        .keypoints
        .iter()
        .find(|(_, kp)| kp.owner == team.opponent() && kp.center)
    {
        return Some(*h);
    }
    if let Some(Some(h)) = game.hq_seen.get(&team) {
        return Some(*h);
    }
    Some(hex::axial_from_offset(game.map.cols / 2, game.map.rows / 2))
}

/// 集火目标：价值高、能被我方伤到、且残血（更易击杀）的可见敌人。
fn pick_focus(game: &GameState, world: &PerceivedWorld, team: Team) -> Option<Hex> {
    let mut best: Option<(f64, Hex)> = None;
    for e in &world.visible_enemies {
        let helpers = game
            .units_of(team)
            .iter()
            .filter(|u| u.can_target_unit(e.kind) && u.eff_attack() >= e.kind.armor())
            .count();
        if helpers == 0 {
            continue;
        }
        let tv = kind_value(e.kind);
        let score = tv * (1.0 + 0.3 * helpers as f64) / e.hp.max(1) as f64;
        if best.map_or(true, |(b, _)| score > b) {
            best = Some((score, e.pos));
        }
    }
    best.map(|(_, h)| h)
}

/// 角色分配：高视野单位优先当侦察（数量受配置限制），其余按兵种归类。
fn assign_roles(game: &GameState, team: Team, cfg: AiConfig) -> HashMap<char, Role> {
    let recon_max = cfg.recon_units.clamp(1, 3) as usize;
    let mut roles: HashMap<char, Role> = HashMap::new();
    let mut recon_cands: Vec<(i32, char)> = game
        .units_of(team)
        .iter()
        .filter(|u| matches!(u.kind, UnitKind::Drone | UnitKind::Scout | UnitKind::SpecialForces | UnitKind::AttackHeli))
        .map(|u| (u.kind.vision(), u.label))
        .collect();
    recon_cands.sort_by(|a, b| b.0.cmp(&a.0));
    for (i, (_, label)) in recon_cands.iter().enumerate() {
        if i < recon_max {
            roles.insert(*label, Role::Recon);
        }
    }
    for u in game.units_of(team) {
        if roles.contains_key(&u.label) {
            continue;
        }
        let role = match u.kind {
            UnitKind::Howitzer | UnitKind::Mortar => Role::FireSupport,
            UnitKind::AaInfantry | UnitKind::AaMgv | UnitKind::AaLauncher => Role::AntiAir,
            UnitKind::Atgm
            | UnitKind::Javelin
            | UnitKind::Tank
            | UnitKind::HeavyTank
            | UnitKind::CavalryIfv
            | UnitKind::Ifv
            | UnitKind::Scout => Role::AntiArmor,
            UnitKind::Truck | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => Role::Reserve,
            _ => Role::Assault,
        };
        roles.insert(u.label, role);
    }
    roles
}

/// 构建本回合作战计划。
pub fn build(game: &GameState, world: &PerceivedWorld, team: Team) -> Operation {
    let cfg = game.ai_configs.get(&team).copied().unwrap_or_default();
    let mission = Mission::of(game, team);
    let hq = game.hq_pos(team);
    let from = hq
        .or_else(|| team_centroid(game, team))
        .unwrap_or_else(|| hex::axial_from_offset(game.map.cols / 2, game.map.rows / 2));
    // 把已知敌军聚成"队伍"，每队中心作为动态 objective；
    // 按优先级 + 兵种匹配 + 距离给每个己方单位分配队伍。
    let teams = threat::teams_for(game, world, team);
    // 己方大本营被威胁时全队回防（不按队伍分配）。
    let defending = game.defense_triggered(team);

    // 关键据点：未控制的 = 需要夺取；已控制的 = 需要保护。
    let front = enemy_front(game, world, team);
    let (targets, held) = keypoint_lists(game, team, from, front);

    // 大本营防空优先占位（至少 2 队防空步兵），避免与据点驻军重复分配。
    let mut guard_objectives: HashMap<char, Hex> = HashMap::new();
    let base_guards = base_guard_assignment(game, team, &mut guard_objectives);

    let mut unit_objectives: HashMap<char, Hex> = HashMap::new();
    let mut garrisons: HashMap<char, Hex> = HashMap::new();
    if !defending {
        if game.keypoints.is_empty() {
            // 无关键据点：保持原有"按敌军队伍分配"的行为。
            if !teams.is_empty() {
                unit_objectives = threat::assign_units(game, team, &teams);
            }
        } else {
            // 有明确游戏目标：按任务把兵力组织到关键据点上。
            let (extra, g) =
                plan_mission_objectives(game, world, team, mission, &targets, &held, &base_guards);
            unit_objectives = extra;
            garrisons = g;
        }
    }
    // 大本营防空驻守优先级最高：覆盖据点/队伍分配。
    for (label, post) in guard_objectives {
        unit_objectives.insert(label, post);
    }

    let objective = if defending {
        game.hq_pos(team)
    } else if !game.keypoints.is_empty() {
        match mission {
            // 固守：以最受威胁的己方据点为全队重心；无据点时才去夺点。
            Mission::Defend => held
                .first()
                .copied()
                .or_else(|| targets.first().copied())
                .or_else(|| teams.first().map(|t| t.center))
                .or_else(|| objective(game, world, team, from)),
            // 进攻/坚守：以"达成胜利最需要的敌方据点"为全队主攻目标。
            _ => targets
                .first()
                .copied()
                .or_else(|| teams.first().map(|t| t.center))
                .or_else(|| objective(game, world, team, from)),
        }
    } else if let Some(top) = teams.first() {
        Some(top.center)
    } else {
        // 无已知敌军：以玩家大本营（敌方中心据点）为目标
        objective(game, world, team, from)
    };
    let recon_target = teams
        .first()
        .map(|t| t.center)
        .or_else(|| targets.first().copied())
        .or_else(|| {
            world
                .visible_enemies
                .iter()
                .min_by_key(|e| Hex::distance(from, e.pos))
                .map(|e| e.pos)
        })
        .or_else(|| {
            world
                .ghosts
                .iter()
                .min_by_key(|(h, _, _)| Hex::distance(from, *h))
                .map(|(h, _, _)| *h)
        })
        .or_else(|| {
            // 无可见敌人/幽灵时，朝信念热点（最可能藏敌的区域）侦察
            world
                .belief
                .hotspots(8)
                .into_iter()
                .min_by_key(|h| Hex::distance(from, *h))
        })
        .or(objective)
        .or(Some(hex::axial_from_offset(
            game.map.cols / 2,
            game.map.rows / 2,
        )));
    let focus = pick_focus(game, world, team);
    let roles = assign_roles(game, team, cfg);
    Operation {
        roles,
        focus,
        objective,
        recon_target,
        hq,
        teams,
        unit_objectives,
        base_guards,
        mission,
        targets,
        held,
        garrisons,
    }
}

/// 关键据点分类：targets = 尚未控制（需夺取）；held = 已控制（需保护）。
/// held 按受威胁程度排序（离敌方前沿越近越靠前），targets 按离本方大本营由近到远。
fn keypoint_lists(
    game: &GameState,
    team: Team,
    from: Hex,
    front: Option<Hex>,
) -> (Vec<Hex>, Vec<Hex>) {
    let mut targets: Vec<Hex> = game
        .keypoints
        .iter()
        .filter(|(_, kp)| !kp.center && kp.controller != team)
        .map(|(h, _)| *h)
        .collect();
    targets.sort_by_key(|h| Hex::distance(from, *h));
    let mut held: Vec<Hex> = game
        .keypoints
        .iter()
        .filter(|(_, kp)| !kp.center && kp.controller == team)
        .map(|(h, _)| *h)
        .collect();
    // 越靠近敌方前沿的据点越需要优先设防
    held.sort_by_key(|h| front.map(|f| Hex::distance(f, *h)).unwrap_or(0));
    (targets, held)
}

/// 敌方前沿参考点：可见敌军形心 → 敌方大本营 → 无。
fn enemy_front(game: &GameState, world: &PerceivedWorld, team: Team) -> Option<Hex> {
    if !world.visible_enemies.is_empty() {
        let n = world.visible_enemies.len() as i32;
        let (mut sc, mut sr) = (0i32, 0i32);
        for e in &world.visible_enemies {
            let (c, r) = hex::offset_from_axial(e.pos);
            sc += c;
            sr += r;
        }
        return Some(hex::axial_from_offset(sc / n, sr / n));
    }
    game.keypoints
        .iter()
        .find(|(_, kp)| kp.center && kp.owner == team.opponent())
        .map(|(h, _)| *h)
}

/// 不参与机动据守的单位：纯后勤 + 不能自主移动的榴弹炮（由摆渡逻辑单独处理）。
fn excluded_from_garrison(k: UnitKind) -> bool {
    matches!(
        k,
        UnitKind::Truck
            | UnitKind::TransportHeli
            | UnitKind::HeavyTransportHeli
            | UnitKind::Supply
            | UnitKind::Howitzer
    )
}

/// 每据点驻守名额：固守任务 2 个；进攻/坚守任务 1 个即可继续推进。
fn garrison_slots(mission: Mission) -> usize {
    match mission {
        Mission::Defend => 2,
        _ => 1,
    }
}

/// 敌军威胁构成（用于"多兵种克制"的驻防搭配）。
#[derive(Clone, Copy, Default)]
struct ThreatMix {
    air: f64,
    armor: f64,
    infantry: f64,
}

fn add_threat(t: &mut ThreatMix, k: UnitKind, w: f64) {
    if k.is_air() {
        t.air += w;
    } else if k.armor() >= 3 {
        t.armor += w;
    } else if k.is_foot() {
        t.infantry += w;
    }
}

fn threat_mix(world: &PerceivedWorld) -> ThreatMix {
    let mut t = ThreatMix::default();
    for e in &world.visible_enemies {
        add_threat(&mut t, e.kind, 1.0);
    }
    for (_, k, age) in &world.ghosts {
        add_threat(&mut t, *k, 1.0 / (1.0 + *age as f64));
    }
    t
}

/// 单位驻守某据点的适配度：兵种克制 + 就近 + 已在该据点者优先。
fn garrison_fit(u: &Unit, kp: Hex, mix: &ThreatMix) -> f64 {
    let mut s = eval::unit_strength(u);
    if mix.air > 0.0 && u.kind.is_aa() {
        s += 6.0 * mix.air.min(3.0);
    }
    if mix.armor > 0.0
        && matches!(
            u.kind,
            UnitKind::Atgm
                | UnitKind::Javelin
                | UnitKind::Tank
                | UnitKind::HeavyTank
                | UnitKind::CavalryIfv
        )
    {
        s += 4.0 * mix.armor.min(3.0);
    }
    if mix.infantry > 0.0
        && (u.kind.is_foot() || matches!(u.kind, UnitKind::HumveeHmg | UnitKind::AaMgv))
    {
        s += 3.0 * mix.infantry.min(3.0);
    }
    s -= 0.35 * Hex::distance(u.pos, kp) as f64;
    if u.pos == kp {
        s += 5.0;
    }
    s
}

/// 突击适配度：固守任务"力量有余裕时"派出的夺点部队优先机动装甲。
fn strike_fit(u: &Unit) -> f64 {
    let mut s = eval::unit_strength(u);
    if u.kind.is_air() {
        s -= 4.0; // 空中单位不能占领据点
    }
    match u.kind {
        UnitKind::Tank | UnitKind::HeavyTank | UnitKind::CavalryIfv | UnitKind::Ifv => s += 6.0,
        UnitKind::AaInfantry | UnitKind::AaLauncher => s -= 4.0,
        UnitKind::Howitzer | UnitKind::Mortar => s -= 6.0,
        _ => {}
    }
    s
}

fn own_strength(game: &GameState, team: Team) -> f64 {
    game.units_of(team)
        .iter()
        .map(|u| {
            eval::unit_strength(u) + u.passengers.iter().map(eval::unit_strength).sum::<f64>()
        })
        .sum()
}

/// 已知敌方存量（可见 + 幽灵折扣）：用于固守任务判断"力量是否余裕"。
fn known_enemy_strength(world: &PerceivedWorld) -> f64 {
    let mut s: f64 = world.visible_enemies.iter().map(eval::unit_strength).sum();
    for (_, k, age) in &world.ghosts {
        s += kind_value(*k) * 0.5 / (1.0 + *age as f64);
    }
    s
}

/// 按任务分配各单位目标，返回（单位 → 目标格，驻守单位 → 据点格）。
///
/// - 进攻/坚守：每个已控制据点留 1 个守备（至少留 2 个单位继续进攻），
///   其余单位统一扑向"最近的需要夺取的关键据点"。
/// - 固守：每个已控制据点驻 2 个（按敌军构成做兵种克制搭配），
///   力量有余裕（己方存量 > 已知敌方存量 × 1.2）时抽 2 个机动单位夺点，
///   其余单位就近在已控制据点之间巡逻。
fn plan_mission_objectives(
    game: &GameState,
    world: &PerceivedWorld,
    team: Team,
    mission: Mission,
    targets: &[Hex],
    held: &[Hex],
    base_guards: &HashSet<char>,
) -> (HashMap<char, Hex>, HashMap<char, Hex>) {
    let mut unit_objectives: HashMap<char, Hex> = HashMap::new();
    let mut garrisons: HashMap<char, Hex> = HashMap::new();
    let mut pool: Vec<Unit> = game
        .units_of(team)
        .into_iter()
        .filter(|u| !excluded_from_garrison(u.kind) && !base_guards.contains(&u.label))
        .cloned()
        .collect();
    if pool.is_empty() {
        return (unit_objectives, garrisons);
    }
    let mix = threat_mix(world);
    let slots = garrison_slots(mission);
    // 驻守名额上限：进攻/坚守至少留 2 个单位继续进攻；固守可全员据守。
    let raw_need = held.len() * slots;
    let need = if mission == Mission::Defend {
        raw_need.min(pool.len())
    } else {
        raw_need.min(pool.len().saturating_sub(2))
    };

    // 固守：确认力量有余裕才派出夺点部队（保证已有据点安全为前提）。
    if mission == Mission::Defend && !targets.is_empty() {
        let surplus = own_strength(game, team) > known_enemy_strength(world) * 1.2;
        let spare = pool.len().saturating_sub(need);
        if surplus && spare >= 2 {
            let n = 2.min(spare);
            pool.sort_by(|a, b| {
                strike_fit(b)
                    .partial_cmp(&strike_fit(a))
                    .unwrap_or(std::cmp::Ordering::Equal)
            });
            let picked: Vec<char> = pool.iter().take(n).map(|u| u.label).collect();
            for label in &picked {
                unit_objectives.insert(*label, targets[0]);
            }
            pool.retain(|u| !picked.contains(&u.label));
        }
    }

    // 逐据点填充驻军：优先设防受威胁最大的据点（held 已按前沿距离排序），
    // 总数不超过 need（进攻/坚守任务至少留 2 个单位继续进攻）。
    let mut remaining = need;
    for kp in held {
        if remaining == 0 {
            break;
        }
        let mut left = slots.min(remaining);
        while left > 0 && !pool.is_empty() {
            let best = pool
                .iter()
                .enumerate()
                .max_by(|(_, a), (_, b)| {
                    garrison_fit(a, *kp, &mix)
                        .partial_cmp(&garrison_fit(b, *kp, &mix))
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
                .map(|(i, _)| i);
            let Some(i) = best else { break };
            let u = pool.remove(i);
            garrisons.insert(u.label, *kp);
            unit_objectives.insert(u.label, *kp);
            left -= 1;
            remaining -= 1;
        }
    }

    // 其余单位：进攻/坚守扑向主攻据点；固守就近巡逻已控制据点。
    let rest: Vec<(char, Hex)> = pool.iter().map(|u| (u.label, u.pos)).collect();
    for (label, pos) in rest {
        let obj = match mission {
            Mission::Defend => held
                .iter()
                .copied()
                .min_by_key(|kp| Hex::distance(pos, *kp))
                .or_else(|| targets.first().copied()),
            _ => targets.first().copied(),
        };
        if let Some(o) = obj {
            unit_objectives.insert(label, o);
        }
    }
    (unit_objectives, garrisons)
}

/// 大本营防空驻点：大本营中心及其 2 格内可站立格，按离中心由近到远排序。
fn guard_posts(game: &GameState, team: Team) -> Vec<Hex> {
    let Some(hq) = game.hq_pos(team) else {
        return Vec::new();
    };
    let (hc, hr) = hex::offset_from_axial(hq);
    let mut cands: Vec<(i32, i32, Hex)> = Vec::new();
    for dc in -2..=2 {
        for dr in -2..=2 {
            let h = hex::axial_from_offset(hc + dc, hr + dr);
            if !game.map.contains(h) || game.map.obstacles.contains(&h) || game.map.water.contains(&h)
            {
                continue;
            }
            let d = Hex::distance(hq, h);
            if d > 2 {
                continue;
            }
            cands.push((d, dc.abs() + dr.abs(), h));
        }
    }
    cands.sort_by_key(|(d, m, _)| (*d, *m));
    cands.into_iter().map(|(_, _, h)| h).collect()
}

/// 选出至多 2 队防空步兵驻守大本营，并把它们的 objective 固定到驻地。
fn base_guard_assignment(
    game: &GameState,
    team: Team,
    unit_objectives: &mut HashMap<char, Hex>,
) -> HashSet<char> {
    let mut guards = HashSet::new();
    let mut aa: Vec<&Unit> = game
        .units_of(team)
        .into_iter()
        .filter(|u| u.kind == UnitKind::AaInfantry)
        .collect();
    if aa.is_empty() {
        return guards;
    }
    let Some(hq) = game.hq_pos(team) else {
        return guards;
    };
    // 离大本营最近的 2 队优先驻守
    aa.sort_by_key(|u| Hex::distance(u.pos, hq));
    let posts = guard_posts(game, team);
    for (i, u) in aa.iter().take(2).enumerate() {
        guards.insert(u.label);
        let post = posts.get(i).copied().unwrap_or(hq);
        unit_objectives.insert(u.label, post);
    }
    guards
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::unit::Unit;

    fn clear(g: &mut GameState, h: Hex) {
        g.map.obstacles.remove(&h);
        g.map.buildings.remove(&h);
        g.map.forests.remove(&h);
        g.map.water.remove(&h);
    }

    /// 无任何敌情时，目标应是玩家关键据点（含大本营中心）。
    #[test]
    fn no_enemy_targets_player_base() {
        let mut g = GameState::new_sustain_multiplayer(91, crate::game::Level::OpenField);
        g.start_sustain_multiplayer(10, 10, 100, 100);
        g.units.clear();
        g.air_units.clear();
        let ai_hq = g.hq_pos(Team::Ai).unwrap();
        g.units.insert(ai_hq, Unit::new(UnitKind::Rifleman, Team::Ai, ai_hq));
        let player_kps: Vec<Hex> = g
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.controller == Team::Player)
            .map(|(h, _)| *h)
            .collect();
        assert!(!player_kps.is_empty());
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = build(&g, &world, Team::Ai);
        assert!(
            player_kps.contains(&op.objective.unwrap()),
            "无敌人时应以玩家据点/大本营为目标: {:?}",
            op.objective
        );
    }

    /// 发现敌军后：应形成敌方队伍、给出动态 objective，并为己方单位分配队伍。
    #[test]
    fn enemies_create_team_objectives() {
        let mut g = GameState::new_sustain_multiplayer(93, crate::game::Level::OpenField);
        g.start_sustain_multiplayer(10, 10, 100, 100);
        g.units.clear();
        g.air_units.clear();
        let ai_hq = g.hq_pos(Team::Ai).unwrap();
        clear(&mut g, ai_hq);
        // 侦察无人机视野 12；把防守半径调小，避免触发"全面防御"（那样全队回防、不分配队伍）
        let mut cfg = AiConfig::default();
        cfg.defend_radius = 3;
        g.ai_configs.insert(Team::Ai, cfg);
        let mut u = Unit::new(UnitKind::Drone, Team::Ai, ai_hq);
        u.label = 'A';
        g.units.insert(ai_hq, u);
        // 距大本营 4~5 格放一个可见玩家小队（在无人机视野内，且 > 防守半径）
        let (hc, hr) = hex::offset_from_axial(ai_hq);
        let p1 = hex::axial_from_offset(hc - 4, hr);
        let p2 = hex::axial_from_offset(hc - 5, hr);
        for h in [p1, p2] {
            clear(&mut g, h);
        }
        g.units.insert(p1, Unit::new(UnitKind::Rifleman, Team::Player, p1));
        g.units.insert(p2, Unit::new(UnitKind::Rifleman, Team::Player, p2));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = build(&g, &world, Team::Ai);
        assert!(!op.teams.is_empty(), "应识别出敌方队伍");
        assert!(!op.unit_objectives.is_empty(), "应为己方单位分配队伍 objective");
        assert!(op.objective.is_some());
    }

    /// 大本营防空：指定 2 队防空步兵驻守，objective 固定在大本营附近。
    #[test]
    fn base_guard_assigns_two_infantry() {
        let mut g = GameState::new_sustain_multiplayer(95, crate::game::Level::OpenField);
        g.start_sustain_multiplayer(10, 10, 100, 100);
        g.units.clear();
        g.air_units.clear();
        let hq = g.hq_pos(Team::Ai).unwrap();
        let (hc, hr) = hex::offset_from_axial(hq);
        let positions = [
            hex::axial_from_offset(hc, hr),
            hex::axial_from_offset(hc - 1, hr),
            hex::axial_from_offset(hc + 1, hr),
        ];
        for (i, lb) in ['A', 'B', 'C'].iter().enumerate() {
            let h = positions[i];
            clear(&mut g, h);
            let mut u = Unit::new(UnitKind::AaInfantry, Team::Ai, h);
            u.label = *lb;
            g.units.insert(h, u);
        }
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = build(&g, &world, Team::Ai);
        assert_eq!(op.base_guards.len(), 2, "应指定 2 队驻守: {:?}", op.base_guards);
        for lb in &op.base_guards {
            let post = op.objective_for(*lb).unwrap();
            assert!(
                Hex::distance(post, hq) <= 2,
                "驻守 objective 应在大本营附近: {:?}",
                post
            );
        }
    }

    /// 任务由本方胜利条件推导（占领即胜=进攻，B=坚守，C=固守）。
    #[test]
    fn mission_follows_victory_rule() {
        let mut g = GameState::new_seeded(101);
        assert_eq!(Mission::of(&g, Team::Ai), Mission::Attack, "非战役默认占领即胜");
        let mut cm = crate::mapdef::CustomMap::load(std::path::Path::new("maps/战役示例.json"))
            .expect("加载战役示例地图");
        cm.ai_victory = crate::mapdef::VictoryRule::HoldAllAtTurn { turn: 5 };
        g.custom = Some(cm.clone());
        assert_eq!(Mission::of(&g, Team::Ai), Mission::Hold);
        cm.ai_victory = crate::mapdef::VictoryRule::HoldAnyAtEnd;
        g.custom = Some(cm);
        assert_eq!(Mission::of(&g, Team::Ai), Mission::Defend);
    }

    /// 进攻任务：全队主攻目标应是"需要夺取的敌方关键据点"，
    /// 非驻守单位被组织到该据点。
    #[test]
    fn attack_mission_organizes_toward_enemy_keypoint() {
        let mut g = GameState::new_sustain_multiplayer(105, crate::game::Level::OpenField);
        g.start_sustain_multiplayer(10, 10, 100, 100);
        g.units.clear();
        g.air_units.clear();
        let enemy_kps: Vec<Hex> = g
            .keypoints
            .iter()
            .filter(|(_, kp)| !kp.center && kp.controller == Team::Player)
            .map(|(h, _)| *h)
            .collect();
        assert!(!enemy_kps.is_empty(), "应有玩家关键据点");
        // 收紧防守半径，避免因零星接触触发"全面防御"（那会全队回防大本营）
        let mut cfg = AiConfig::default();
        cfg.defend_radius = 2;
        g.ai_configs.insert(Team::Ai, cfg);
        let hq = g.hq_pos(Team::Ai).unwrap();
        let (hc, hr) = hex::offset_from_axial(hq);
        let h = hex::axial_from_offset(hc + 1, hr);
        clear(&mut g, h);
        let mut u = Unit::new(UnitKind::Rifleman, Team::Ai, h);
        u.label = 'A';
        g.units.insert(h, u);
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = build(&g, &world, Team::Ai);
        assert_eq!(op.mission, Mission::Attack);
        let obj = op.objective.expect("进攻任务应有主攻目标");
        assert!(
            enemy_kps.contains(&obj),
            "主攻目标应为需要夺取的敌方据点: {:?}",
            obj
        );
        assert_eq!(
            op.objective_for('A'),
            Some(obj),
            "非驻守单位应被组织到主攻据点"
        );
    }

    /// 固守任务：为已控制据点分配多兵种驻军，并把驻军目标锁定在据点上。
    #[test]
    fn defend_mission_garrisons_held_keypoints() {
        let mut g = GameState::new_sustain_multiplayer(107, crate::game::Level::OpenField);
        g.start_sustain_multiplayer(10, 10, 100, 100);
        g.units.clear();
        g.air_units.clear();
        let mut cm = crate::mapdef::CustomMap::load(std::path::Path::new("maps/战役示例.json"))
            .expect("加载战役示例地图");
        cm.ai_victory = crate::mapdef::VictoryRule::HoldAnyAtEnd;
        g.custom = Some(cm);
        let held: Vec<Hex> = g
            .keypoints
            .iter()
            .filter(|(_, kp)| !kp.center && kp.controller == Team::Ai)
            .map(|(h, _)| *h)
            .collect();
        assert!(!held.is_empty(), "应有 AI 关键据点");
        let kinds = [
            UnitKind::Rifleman,
            UnitKind::Tank,
            UnitKind::Javelin,
            UnitKind::AaInfantry,
        ];
        let mut placed: Vec<Hex> = Vec::new();
        'outer: for kp in &held {
            for h in std::iter::once(*kp).chain(kp.neighbors()) {
                if placed.len() >= kinds.len() {
                    break 'outer;
                }
                if placed.contains(&h) || !g.map.contains(h) {
                    continue;
                }
                clear(&mut g, h);
                if g.unit_at(h).is_some() {
                    continue;
                }
                let mut u = Unit::new(kinds[placed.len()], Team::Ai, h);
                u.label = (b'A' + placed.len() as u8) as char;
                g.units.insert(h, u);
                placed.push(h);
            }
        }
        assert_eq!(placed.len(), kinds.len(), "应放置 4 个单位");
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = build(&g, &world, Team::Ai);
        assert_eq!(op.mission, Mission::Defend);
        assert!(!op.garrisons.is_empty(), "固守任务应为据点分配驻军");
        for (label, kp) in &op.garrisons {
            assert!(
                held.contains(kp),
                "驻军目标应为已控制据点: {}",
                hex::hex_label(*kp)
            );
            assert_eq!(
                op.objective_for(*label),
                Some(*kp),
                "驻军目标应写入 unit_objectives"
            );
        }
    }
}

