//! 感知世界（新版 AI）：本队视角的可见敌人快照 + 量化威胁图。
//! 与旧版不同，这里把"危险区"量化为期望伤害，供统一效用评估使用。

use std::collections::{BTreeSet, HashSet};

use crate::game::GameState;
use crate::hex::{self, Hex};

use super::belief::Belief;
use crate::unit::{Team, Unit, UnitKind};

pub struct PerceivedWorld {
    #[allow(dead_code)]
    pub team: Team,
    pub visible_enemy_hexes: BTreeSet<Hex>,
    pub visible_enemies: Vec<Unit>,
    /// 预计算的视线遮挡物（岩石+楼房+烟雾），供 los() 复用。
    pub blockers: HashSet<Hex>,
    /// 回合开始时本队已侦察到的地形格（用于信息增益评估）。
    pub terrain: BTreeSet<Hex>,
    /// 最后已知敌方位置（幽灵）：(格, 兵种, 记录回合)。
    pub ghosts: Vec<(Hex, UnitKind, i32)>,
    /// 对未观测敌军位置的概率分布（Phase 4）。
    pub belief: Belief,
}

impl PerceivedWorld {
    pub fn build(game: &GameState, team: Team) -> Self {
        let vr = game.vision(team);
        let visible_enemies: Vec<Unit> = game
            .enemies_of(team)
            .into_iter()
            .filter(|e| vr.enemy_units.contains(&e.pos))
            .cloned()
            .collect();
        let blockers = game.map.blocker_set(&game.smoke);
        let ghosts: Vec<(Hex, UnitKind, i32)> = game
            .ghosts
            .get(&team)
            .map(|m| m.iter().map(|(h, (k, t))| (*h, *k, *t)).collect())
            .unwrap_or_default();
        let mut w = Self {
            team,
            visible_enemy_hexes: vr.enemy_units,
            visible_enemies,
            blockers,
            terrain: vr.terrain,
            ghosts,
            belief: Belief::default(),
        };
        w.belief = Belief::build(game, &w);
        w
    }

    /// 依据固定的视野格集合刷新"可见敌方单位"列表（不重做 BFS，开销很小）。
    /// 视野本身在回合开始时算一次即可（与旧版 AI 的回合内视野缓存一致）。
    pub fn refresh_enemies(&mut self, game: &GameState) {
        self.visible_enemies = game
            .enemies_of(self.team)
            .into_iter()
            .filter(|e| self.visible_enemy_hexes.contains(&e.pos))
            .cloned()
            .collect();
    }

    /// 从 from 处、视野 vision 内还能新侦察到多少格（信息增益的廉价近似：
    /// 用六边形距离近似 BFS 视野，森林惩罚忽略）。仅侦察单位使用，开销可控。
    pub fn info_gain(&self, game: &GameState, from: Hex, vision: i32) -> i32 {
        if vision <= 0 {
            return 0;
        }
        let (c0, r0) = hex::offset_from_axial(from);
        let mut count = 0;
        for dc in -vision..=vision {
            for dr in -vision..=vision {
                let cc = c0 + dc;
                let rr = r0 + dr;
                if cc < 0 || rr < 0 || cc >= game.map.cols || rr >= game.map.rows {
                    continue;
                }
                let h = hex::axial_from_offset(cc, rr);
                if Hex::distance(from, h) > vision {
                    continue;
                }
                if !self.terrain.contains(&h) {
                    count += 1;
                }
            }
        }
        count
    }

    /// 使用预计算遮挡物的视线检查（与 map.has_los_ex 语义一致）。
    pub fn los(&self, game: &GameState, from: Hex, to: Hex) -> bool {
        game.map.has_los_with_blockers(from, to, &self.blockers)
    }

    /// mover 站在 h 处时，预计下个敌方回合受到的期望伤害（威胁图的一格）。
    /// 敌人可先移动再射击：超出当前射程但机动后够得到的威胁按折扣计入。
    pub fn exposure(&self, game: &GameState, mover: &Unit, h: Hex) -> f64 {
        let mut sum = 0.0f64;
        for e in &self.visible_enemies {
            if !e.kind.can_attack() {
                continue;
            }
            let d = Hex::distance(e.pos, h);
            let reach = e.kind.movement() + e.eff_range();
            if d > reach {
                continue;
            }
            let mut t = mover.clone();
            t.pos = h;
            if !e.can_target_unit(t.kind) {
                continue;
            }
            let atk = e.eff_attack();
            if atk < t.kind.armor() {
                continue;
            }
            let can_now = d <= e.eff_range();
            if can_now {
                let air_air = e.kind.is_air() && t.kind.is_air();
                if !air_air && !self.los(game, e.pos, h) {
                    continue;
                }
            }
            let w = if can_now { 1.0 } else { 0.4 };
            let (hr, _) = game.direct_hit_rate(e, &t, h, true, true);
            let p = (hr as f64 / 100.0).clamp(0.0, 1.0);
            let cook_off = t.kind.cook_off_chance();
            let dmg = if e.is_tank_gun_mode() && cook_off > 0 {
                1.0 + cook_off as f64 / 100.0 // 殉爆
            } else if (e.kind == UnitKind::HmgGunner || e.is_heavy_mg_mode())
                && t.kind.is_foot()
            {
                1.5 // 重机枪重弹
            } else {
                1.0
            };
            sum += w * p * dmg;
        }
        sum
    }
}
