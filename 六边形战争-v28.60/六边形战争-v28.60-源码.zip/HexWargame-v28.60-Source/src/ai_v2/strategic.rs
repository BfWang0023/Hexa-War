//! 战略层（新版 AI）：反制组成优化。
//!
//! 流程：
//! 1. 从已侦察敌人 + 幽灵估计敌方兵种组成（重甲/轻甲/空中/步兵/间瞄/侦察）。
//! 2. 把威胁映射到角色需求（反装甲/防空/反步兵/侦察/火力/运输/战线），
//!    减去己方现有供给，得到 needs。
//! 3. 在点数预算下按「角色价值 / 费用」贪心选兵（带重复递减与数量上限），
//!    直到买不起、无收益或达到单回合上限。
//! 4. 放置：初始部署用出发区，对局增援用大本营周围 2 格。

use std::collections::HashMap;

use rand::Rng;

use crate::game::GameState;
use crate::hex::{self, Hex};
use crate::unit::{Team, UnitKind};

use super::operational::Mission;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum Role {
    AntiArmor,
    AntiAir,
    AntiInfantry,
    Recon,
    FireSupport,
    Transport,
    Line,
}

const ROLES: [Role; 7] = [
    Role::AntiArmor,
    Role::AntiAir,
    Role::AntiInfantry,
    Role::Recon,
    Role::FireSupport,
    Role::Transport,
    Role::Line,
];

/// 敌方组成估计（按已侦察确定性 + 幽灵折扣）。
#[derive(Clone, Copy, Debug, Default)]
pub struct EnemyComp {
    pub armor_heavy: f64,
    pub armor_light: f64,
    pub air: f64,
    pub infantry: f64,
    pub indirect: f64,
    pub recon: f64,
}

fn add_kind(c: &mut EnemyComp, k: UnitKind, w: f64) {
    if k.is_air() {
        c.air += w;
    } else if k.armor() >= 3 {
        c.armor_heavy += w;
    } else if k.is_vehicle() && k.armor() >= 2 {
        c.armor_light += w;
    } else if k.is_foot() {
        c.infantry += w;
    }
    if matches!(k, UnitKind::Howitzer | UnitKind::Mortar) {
        c.indirect += w;
    }
    if matches!(k, UnitKind::Scout | UnitKind::Drone) {
        c.recon += w;
    }
}

/// 估计敌方组成：可见敌人确定性计入，幽灵按时间衰减计入。
pub fn estimate_enemy(game: &GameState, team: Team) -> EnemyComp {
    let mut c = EnemyComp::default();
    let vis = game.vision(team).enemy_units;
    for e in game.enemies_of(team) {
        if vis.contains(&e.pos) {
            add_kind(&mut c, e.kind, 1.0);
        }
    }
    if let Some(g) = game.ghosts.get(&team) {
        for (h, (k, age)) in g {
            if vis.contains(h) {
                continue;
            }
            add_kind(&mut c, *k, 1.0 / (1.0 + *age as f64));
        }
    }
    c
}

/// 兵种对各角色的贡献权重。
fn role_weights(k: UnitKind) -> &'static [(Role, f64)] {
    use Role::*;
    match k {
        UnitKind::Tank => &[(AntiArmor, 0.6), (Line, 0.5)],
        UnitKind::HeavyTank => &[(AntiArmor, 1.0), (Line, 0.5)],
        UnitKind::Atgm => &[(AntiArmor, 1.0)],
        UnitKind::Javelin => &[(AntiArmor, 0.9)],
        UnitKind::CavalryIfv => &[(AntiArmor, 1.0)],
        UnitKind::HumveeTow => &[(AntiArmor, 0.9)],
        UnitKind::HumveeJavelin => &[(AntiArmor, 0.85)],
        UnitKind::Ifv => &[(AntiArmor, 0.35), (AntiInfantry, 0.6), (Line, 0.5)],
        UnitKind::Scout => &[(Recon, 1.0), (AntiArmor, 0.25)],
        UnitKind::Drone => &[(Recon, 1.0), (AntiArmor, 0.35)],
        UnitKind::AaLauncher => &[(AntiAir, 1.0)],
        UnitKind::AaMgv => &[(AntiAir, 0.9), (AntiInfantry, 0.4)],
        UnitKind::AaInfantry => &[(AntiAir, 0.8)],
        UnitKind::SpecialForces => &[(Recon, 0.6), (AntiInfantry, 0.9), (AntiAir, 0.3)],
        UnitKind::Rifleman => &[(AntiInfantry, 1.0), (Line, 0.7)],
        UnitKind::EliteInfantry => &[(AntiInfantry, 1.0), (Line, 0.5)],
        UnitKind::HmgGunner => &[(AntiInfantry, 0.9), (Line, 0.6)],
        UnitKind::HumveeHmg => &[(AntiInfantry, 0.9), (AntiAir, 0.3), (Line, 0.5)],
        UnitKind::Howitzer => &[(FireSupport, 1.0)],
        UnitKind::Mortar => &[(FireSupport, 0.9), (AntiInfantry, 0.3)],
        UnitKind::AttackHeli => &[(AntiArmor, 0.5), (AntiInfantry, 0.5), (Line, 0.3)],
        UnitKind::Truck => &[(Transport, 1.0)],
        UnitKind::TransportHeli => &[(Transport, 0.6)],
        UnitKind::HeavyTransportHeli => &[(Transport, 0.5)],
        UnitKind::Headquarters => &[],
        UnitKind::Supply => &[],
    }
}

fn kind_cap(k: UnitKind) -> i32 {
    match k {
        UnitKind::Tank
        | UnitKind::HeavyTank
        | UnitKind::AttackHeli
        | UnitKind::Howitzer
        | UnitKind::CavalryIfv => 4,
        UnitKind::Supply => 1,
        UnitKind::Headquarters => 5,
        _ => 5,
    }
}

fn own_kinds(game: &GameState, team: Team) -> Vec<UnitKind> {
    let mut v = Vec::new();
    for u in game.units_of(team) {
        v.push(u.kind);
        for p in &u.passengers {
            v.push(p.kind);
        }
    }
    v
}

fn current_supply(game: &GameState, team: Team) -> HashMap<Role, f64> {
    let mut s: HashMap<Role, f64> = HashMap::new();
    for k in own_kinds(game, team) {
        for (r, w) in role_weights(k) {
            *s.entry(*r).or_insert(0.0) += w;
        }
    }
    s
}

/// 角色期望数量：基础配额 + 按敌方组成缩放（反制）。
fn desired_roles(game: &GameState, team: Team, e: &EnemyComp) -> HashMap<Role, f64> {
    let own = own_kinds(game, team);
    let howitzers = own.iter().filter(|k| **k == UnitKind::Howitzer).count();
    let trucks = own.iter().filter(|k| **k == UnitKind::Truck).count();
    // 榴弹炮必须有卡车转运：给较高紧迫度
    let need_truck: f64 = if howitzers > trucks { 2.0 } else { 0.0 };
    let n = own.len() as f64;
    // 运输/步兵倾向：有已知敌情且步兵较多时，需要运输单位把步兵摆渡到前线
    let enemy_total = e.armor_heavy + e.armor_light + e.air + e.infantry + e.indirect;
    let infantry = own.iter().filter(|k| k.is_infantry()).count() as f64;
    let transports = own
        .iter()
        .filter(|k| {
            matches!(
                k,
                UnitKind::Truck | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
            )
        })
        .count() as f64;
    let ferry_desired = if enemy_total > 0.0 {
        if infantry >= 5.0 {
            2.0
        } else if infantry >= 2.0 {
            1.0
        } else {
            0.0
        }
    } else {
        0.0
    };
    let transport_need = need_truck.max((ferry_desired - transports).max(0.0));

    let mut d: HashMap<Role, f64> = HashMap::new();
    d.insert(Role::AntiArmor, 1.8 + 0.7 * e.armor_heavy + 0.35 * e.armor_light);
    d.insert(Role::AntiAir, 0.6 + 0.9 * e.air);
    // 步兵倾向上调：更多廉价步兵，既用于作战也用于搭载/占点
    d.insert(Role::AntiInfantry, 2.4 + 0.4 * e.infantry + 0.5 * e.indirect);
    d.insert(Role::Recon, 1.5 + 0.3 * e.recon);
    d.insert(Role::FireSupport, 0.5 + 0.5 * (e.infantry + e.indirect));
    d.insert(Role::Transport, transport_need);
    d.insert(Role::Line, 1.2 + 0.45 * n);

    if e.air >= 1.0 {
        *d.get_mut(&Role::AntiAir).unwrap() += 0.5 * e.air;
    }
    // —— 作战任务偏好（新版 AI）：由本方胜利条件决定 ——
    match Mission::of(game, team) {
        // 固守：构筑多兵种克制的防御体系——防空/反装甲/反步兵/火力都要齐全
        Mission::Defend => {
            *d.get_mut(&Role::AntiAir).unwrap() += 0.6;
            *d.get_mut(&Role::AntiArmor).unwrap() += 0.4;
            *d.get_mut(&Role::AntiInfantry).unwrap() += 0.4;
            *d.get_mut(&Role::FireSupport).unwrap() += 0.4;
            *d.get_mut(&Role::Transport).unwrap() = transport_need.min(1.0);
        }
        // 坚守：先夺点再守点，反装甲与火力并重
        Mission::Hold => {
            *d.get_mut(&Role::AntiArmor).unwrap() += 0.4;
            *d.get_mut(&Role::Line).unwrap() += 0.3;
            *d.get_mut(&Role::AntiAir).unwrap() += 0.2;
        }
        // 进攻：突击/反装甲优先，尽快达成占领
        Mission::Attack => {
            *d.get_mut(&Role::AntiArmor).unwrap() += 0.3;
            *d.get_mut(&Role::Line).unwrap() += 0.3;
        }
    }
    d
}

fn compute_needs(game: &GameState, team: Team, e: &EnemyComp) -> HashMap<Role, f64> {
    let desired = desired_roles(game, team, e);
    let supply = current_supply(game, team);
    let mut needs = HashMap::new();
    for r in ROLES {
        let d = desired.get(&r).copied().unwrap_or(0.0);
        let s = supply.get(&r).copied().unwrap_or(0.0);
        needs.insert(r, (d - s).max(0.0));
    }
    needs
}

fn kind_role_value(k: UnitKind, needs: &HashMap<Role, f64>) -> f64 {
    role_weights(k)
        .iter()
        .map(|(r, w)| w * needs.get(r).copied().unwrap_or(0.0).max(0.0))
        .sum()
}

/// 在预算内贪心选兵（返回要买的兵种列表，按购买顺序）。
/// max_buy 限制单回合购买数量；放置由调用方完成。
pub fn plan_recruits(game: &GameState, team: Team, max_buy: usize) -> Vec<UnitKind> {
    let e = estimate_enemy(game, team);
    let mut needs = compute_needs(game, team, &e);
    let mut counts: HashMap<UnitKind, i32> = HashMap::new();
    for k in own_kinds(game, team) {
        *counts.entry(k).or_insert(0) += 1;
    }
    let mut points = game.recruit_points.get(&team).copied().unwrap_or(0);
    let mut out = Vec::new();

    for _ in 0..max_buy.max(1) {
        let mut best: Option<(f64, UnitKind)> = None;
        for k in UnitKind::all_recruitable() {
            let k = *k;
            if counts.get(&k).copied().unwrap_or(0) >= kind_cap(k) {
                continue;
            }
            if k.recruit_cost() > points {
                continue;
            }
            let pure_transport = matches!(
                k,
                UnitKind::Truck | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
            );
            if pure_transport && needs.get(&Role::Transport).copied().unwrap_or(0.0) <= 0.0 {
                continue;
            }
            let value = kind_role_value(k, &needs);
            let dup = 1.0 / (1.0 + 0.35 * counts.get(&k).copied().unwrap_or(0) as f64);
            // 大本营至少 2 队防空步兵：不足时大幅提升其优先级
            let guard_bonus =
                if k == UnitKind::AaInfantry && counts.get(&k).copied().unwrap_or(0) < 2 {
                    3.0
                } else {
                    0.0
                };
            let eff = (value * dup + 0.6 + guard_bonus) / k.recruit_cost() as f64;
            if best.map_or(true, |(be, _)| eff > be) {
                best = Some((eff, k));
            }
        }
        let Some((_eff, k)) = best else {
            break;
        };
        if k.recruit_cost() > points {
            break;
        }
        points -= k.recruit_cost();
        *counts.entry(k).or_insert(0) += 1;
        for (r, w) in role_weights(k) {
            if let Some(n) = needs.get_mut(r) {
                *n = (*n - w).max(0.0);
            }
        }
        out.push(k);
    }
    out
}

fn free_spot(game: &mut GameState, kind: UnitKind, candidates: &[Hex]) -> Option<Hex> {
    let mut ok: Vec<Hex> = Vec::new();
    for &h in candidates {
        if game.unit_at(h).is_some() {
            continue;
        }
        if !kind.is_air() {
            if game.map.obstacles.contains(&h) || game.map.water.contains(&h) {
                continue;
            }
            if game.map.buildings.contains(&h) && !kind.is_foot() {
                continue;
            }
        }
        ok.push(h);
    }
    if ok.is_empty() {
        return None;
    }
    let idx = game.rng.gen_range(0..ok.len());
    Some(ok[idx])
}

fn hq_area(game: &GameState, team: Team) -> Vec<Hex> {
    let Some(hq) = game.hq_pos(team) else {
        return Vec::new();
    };
    let (hc, hr) = hex::offset_from_axial(hq);
    let mut v = Vec::new();
    for dc in -2..=2 {
        for dr in -2..=2 {
            let h = hex::axial_from_offset(hc + dc, hr + dr);
            if Hex::distance(hq, h) <= 2 && game.map.contains(h) && !game.zone_occupied(team, h) {
                v.push(h);
            }
        }
    }
    v
}

fn deploy_zone_hexes(game: &GameState, team: Team) -> Vec<Hex> {
    // 战役地图：逐格部署区；普通地图 = 部署列内全部格。
    game.deploy_cells(team)
}

/// 对局中增援：按反制组成选兵并放到大本营周围。
pub fn reinforce_turn(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    if !game.sustain {
        return;
    }
    let kinds = plan_recruits(game, team, 3);
    if kinds.is_empty() {
        return;
    }
    log.push(format!(
        "[AI] 🧠 反制招募：{}",
        kinds
            .iter()
            .map(|k| k.name())
            .collect::<Vec<_>>()
            .join("、")
    ));
    for k in kinds {
        let candidates = hq_area(game, team);
        let Some(pos) = free_spot(game, k, &candidates) else {
            log.push(format!("[AI] 大本营周围无空位，暂缓招募 {}", k.name()));
            break;
        };
        match game.reinforce_unit(team, k, pos) {
            Ok(label) => log.push(format!(
                "[AI增援] {} {} → {}（反制）",
                label,
                k.name(),
                hex::hex_label(pos)
            )),
            Err(e) => log.push(format!("[AI] 增援 {} 失败: {}", k.name(), e)),
        }
    }
}

/// 初始部署：按反制组成选兵并放到出发区。
pub fn deploy_initial(game: &mut GameState, team: Team) -> Vec<String> {
    let mut log = Vec::new();
    let kinds = plan_recruits(game, team, 14);
    let zone = deploy_zone_hexes(game, team);
    for k in kinds {
        let Some(pos) = free_spot(game, k, &zone) else {
            continue;
        };
        match game.deploy_unit(team, k, pos) {
            Ok(label) => log.push(format!(
                "[AI部署] {} {} → {}（反制）",
                label,
                k.name(),
                hex::hex_label(pos)
            )),
            Err(e) => log.push(format!("[AI] 部署 {} 失败: {}", k.name(), e)),
        }
    }
    log
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::unit::Unit;

    fn clear(g: &mut GameState, h: Hex) {
        g.map.obstacles.remove(&h);
        g.map.buildings.remove(&h);
        g.map.forests.remove(&h);
        g.map.water.remove(&h);
    }

    fn empty(seed: u64) -> GameState {
        let mut g = GameState::new_seeded(seed);
        g.units.clear();
        g.air_units.clear();
        g.deploying = false;
        g.winner = None;
        g
    }

    fn is_aa(k: UnitKind) -> bool {
        matches!(
            k,
            UnitKind::AaLauncher | UnitKind::AaMgv | UnitKind::AaInfantry
        )
    }

    fn is_antiarmor(k: UnitKind) -> bool {
        matches!(
            k,
            UnitKind::Atgm
                | UnitKind::Javelin
                | UnitKind::Tank
                | UnitKind::HeavyTank
                | UnitKind::CavalryIfv
        )
    }

    /// 敌方有空中单位时，招募应包含防空反制。
    #[test]
    fn counter_picks_aa_vs_air() {
        let mut g = empty(71);
        let h_ai = hex::axial_from_offset(10, 6);
        let h1 = hex::axial_from_offset(11, 6);
        let h2 = hex::axial_from_offset(11, 5);
        for h in [h_ai, h1, h2] {
            clear(&mut g, h);
        }
        g.units.insert(h_ai, Unit::new(UnitKind::Rifleman, Team::Ai, h_ai));
        g.units
            .insert(h1, Unit::new(UnitKind::AttackHeli, Team::Player, h1));
        g.units
            .insert(h2, Unit::new(UnitKind::AttackHeli, Team::Player, h2));
        g.recruit_points.insert(Team::Ai, 60);
        let out = plan_recruits(&g, Team::Ai, 4);
        assert!(out.iter().any(|k| is_aa(*k)), "应抗空: {:?}", out);
    }

    /// 敌方有重甲时，招募应包含反装甲反制。
    #[test]
    fn counter_picks_antiarmor_vs_heavy() {
        let mut g = empty(73);
        let h_ai = hex::axial_from_offset(10, 6);
        let h1 = hex::axial_from_offset(11, 6);
        let h2 = hex::axial_from_offset(12, 6);
        for h in [h_ai, h1, h2] {
            clear(&mut g, h);
        }
        g.units.insert(h_ai, Unit::new(UnitKind::Rifleman, Team::Ai, h_ai));
        g.units
            .insert(h1, Unit::new(UnitKind::HeavyTank, Team::Player, h1));
        g.units
            .insert(h2, Unit::new(UnitKind::HeavyTank, Team::Player, h2));
        g.recruit_points.insert(Team::Ai, 80);
        let out = plan_recruits(&g, Team::Ai, 4);
        assert!(out.iter().any(|k| is_antiarmor(*k)), "应反装甲: {:?}", out);
    }

    /// 没有榴弹炮时不买纯运输单位。
    #[test]
    fn no_pure_transport_without_howitzer() {
        let mut g = empty(75);
        let h = hex::axial_from_offset(10, 6);
        clear(&mut g, h);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Ai, h));
        g.recruit_points.insert(Team::Ai, 200);
        let out = plan_recruits(&g, Team::Ai, 10);
        assert!(
            !out.iter().any(|k| matches!(
                k,
                UnitKind::Truck | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
            )),
            "无火炮不应买运输: {:?}",
            out
        );
    }

    /// 有敌情且步兵较多时，应招募运输单位用于摆渡。
    #[test]
    fn buys_transport_for_ferry() {
        let mut g = empty(79);
        let a1 = hex::axial_from_offset(10, 6);
        let a2 = hex::axial_from_offset(10, 8);
        let e1 = hex::axial_from_offset(13, 6);
        for h in [a1, a2, e1] {
            clear(&mut g, h);
        }
        g.units.insert(a1, Unit::new(UnitKind::Rifleman, Team::Ai, a1));
        g.units.insert(a2, Unit::new(UnitKind::Rifleman, Team::Ai, a2));
        g.units
            .insert(e1, Unit::new(UnitKind::Tank, Team::Player, e1));
        g.recruit_points.insert(Team::Ai, 80);
        let out = plan_recruits(&g, Team::Ai, 10);
        assert!(
            out.iter().any(|k| matches!(
                k,
                UnitKind::Truck | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
            )),
            "有敌情且步兵多时应招募运输单位: {:?}",
            out
        );
    }

    /// 有榴弹炮时应补 1 辆卡车用于转运。
    #[test]
    fn buys_truck_for_howitzer() {
        let mut g = empty(77);
        let h = hex::axial_from_offset(10, 6);
        clear(&mut g, h);
        g.units.insert(h, Unit::new(UnitKind::Howitzer, Team::Ai, h));
        g.recruit_points.insert(Team::Ai, 80);
        let out = plan_recruits(&g, Team::Ai, 8);
        assert!(out.contains(&UnitKind::Truck), "有火炮应补卡车: {:?}", out);
    }

    /// 无论敌情如何，都优先补足 2 队防空步兵（大本营驻守）。
    #[test]
    fn prioritizes_two_aa_infantry() {
        let mut g = empty(97);
        let h = hex::axial_from_offset(10, 6);
        clear(&mut g, h);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Ai, h));
        g.recruit_points.insert(Team::Ai, 60);
        let out = plan_recruits(&g, Team::Ai, 4);
        let aa = out.iter().filter(|k| **k == UnitKind::AaInfantry).count();
        assert!(aa >= 2, "应优先补足 2 队防空步兵: {:?}", out);
    }

    /// 固守任务（C 类胜利条件）：即使没有敌情，也应构筑多兵种克制的防御体系
    /// （至少包含防空 + 反装甲，而不是只堆步兵）。
    #[test]
    fn defend_mission_builds_counter_defense() {
        let mut g = empty(109);
        let h = hex::axial_from_offset(10, 6);
        clear(&mut g, h);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Ai, h));
        g.recruit_points.insert(Team::Ai, 160);
        let mut cm = crate::mapdef::CustomMap::load(std::path::Path::new("maps/战役示例.json"))
            .expect("加载战役示例地图");
        cm.ai_victory = crate::mapdef::VictoryRule::HoldAnyAtEnd;
        g.custom = Some(cm);
        let out = plan_recruits(&g, Team::Ai, 10);
        assert!(out.iter().any(|k| is_aa(*k)), "固守应包含防空: {:?}", out);
        assert!(
            out.iter().any(|k| is_antiarmor(*k)),
            "固守应包含反装甲: {:?}",
            out
        );
        assert!(
            out.iter().any(|k| k.is_infantry()),
            "固守应保留反步兵/据守步兵: {:?}",
            out
        );
    }
}


