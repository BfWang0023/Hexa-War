//! 威胁集群（新版 AI）：把已知敌军按 4 格半径聚成"队伍"，
//! 每队中心作为动态 objective，并按队伍规模/兵种分配兵力与支援类型。
//!
//! 已知敌军 = 可见敌人 + 迷雾中的"?"幽灵（每个按 1 个棋子计入，按时间衰减）。
//! 集群采用单链接（两两距离 ≤ 4 即同队）。
//! 优先级 = 规模 + 兵种威胁 + 是否压在我方大本营/据点上 - 距离衰减。
//! 单位分配 = 优先级 + 兵种匹配 + 距离（近者优先）。

use std::collections::HashMap;

use crate::game::GameState;
use crate::hex::{self, Hex};
use crate::unit::{Team, UnitKind};

use super::world::PerceivedWorld;

/// 聚类半径：两两距离 ≤ 该值的已知敌军归为同一支队伍。
pub const CLUSTER_RADIUS: i32 = 4;

#[derive(Clone, Debug)]
pub struct Contact {
    pub hex: Hex,
    pub kind: UnitKind,
    pub visible: bool,
    /// 计入规模时的权重（可见=1；幽灵按时间衰减）。
    pub weight: f64,
}

/// 一支已知敌方队伍（集群）。
#[derive(Clone, Debug)]
pub struct EnemyTeam {
    pub center: Hex,
    pub size: f64,
    pub contacts: Vec<Contact>,
    pub armor_heavy: f64,
    pub armor_light: f64,
    pub air: f64,
    pub infantry: f64,
    pub indirect: f64,
    pub priority: f64,
}

impl EnemyTeam {
    fn new(center: Hex) -> Self {
        Self {
            center,
            size: 0.0,
            contacts: Vec::new(),
            armor_heavy: 0.0,
            armor_light: 0.0,
            air: 0.0,
            infantry: 0.0,
            indirect: 0.0,
            priority: 0.0,
        }
    }

    fn add(&mut self, kind: UnitKind, weight: f64) {
        self.size += weight;
        if kind.is_air() {
            self.air += weight;
        } else if kind.armor() >= 3 {
            self.armor_heavy += weight;
        } else if kind.is_vehicle() && kind.armor() >= 2 {
            self.armor_light += weight;
        } else if kind.is_foot() {
            self.infantry += weight;
        }
        if matches!(kind, UnitKind::Howitzer | UnitKind::Mortar) {
            self.indirect += weight;
        }
    }
}

/// 收集已知敌军：可见敌人 + 幽灵（未被当前视野覆盖的"?"）。
pub fn collect_contacts(world: &PerceivedWorld) -> Vec<Contact> {
    let mut v = Vec::new();
    for e in &world.visible_enemies {
        v.push(Contact {
            hex: e.pos,
            kind: e.kind,
            visible: true,
            weight: 1.0,
        });
    }
    for (h, kind, age) in &world.ghosts {
        if world.visible_enemy_hexes.contains(h) {
            continue;
        }
        v.push(Contact {
            hex: *h,
            kind: *kind,
            visible: false,
            weight: 1.0 / (1.0 + *age as f64),
        });
    }
    v
}

fn uf_find(parent: &mut [usize], x: usize) -> usize {
    let mut r = x;
    while parent[r] != r {
        r = parent[r];
    }
    let mut c = x;
    while parent[c] != c {
        let next = parent[c];
        parent[c] = r;
        c = next;
    }
    r
}

/// 单链接聚类：**仅用地面单位**识别队伍（两两距离 ≤ CLUSTER_RADIUS 归为一队）；
/// 空中单位不参与聚类，但按"最近队伍中心"并入该队的规模与组成统计。
/// 若没有任何地面单位，则不识别出队伍（纯空中编队不构成队伍）。
pub fn cluster(contacts: &[Contact]) -> Vec<EnemyTeam> {
    let ground: Vec<usize> = (0..contacts.len())
        .filter(|i| !contacts[*i].kind.is_air())
        .collect();
    let air: Vec<usize> = (0..contacts.len())
        .filter(|i| contacts[*i].kind.is_air())
        .collect();
    if ground.is_empty() {
        return Vec::new();
    }
    // 并查集只在 ground 内做
    let m = ground.len();
    let mut parent: Vec<usize> = (0..m).collect();
    for i in 0..m {
        for j in (i + 1)..m {
            if Hex::distance(contacts[ground[i]].hex, contacts[ground[j]].hex) <= CLUSTER_RADIUS {
                let (a, b) = (uf_find(&mut parent, i), uf_find(&mut parent, j));
                if a != b {
                    parent[a] = b;
                }
            }
        }
    }
    let mut groups: HashMap<usize, Vec<usize>> = HashMap::new();
    for i in 0..m {
        let r = uf_find(&mut parent, i);
        groups.entry(r).or_default().push(i);
    }
    let mut teams = Vec::new();
    for idxs in groups.values() {
        let members: Vec<Contact> = idxs
            .iter()
            .map(|i| contacts[ground[*i]].clone())
            .collect();
        let (mut sc, mut sr) = (0.0f64, 0.0f64);
        for m in &members {
            let (c, r) = hex::offset_from_axial(m.hex);
            sc += c as f64;
            sr += r as f64;
        }
        let centroid = hex::axial_from_offset(
            (sc / members.len() as f64).round() as i32,
            (sr / members.len() as f64).round() as i32,
        );
        let center = members
            .iter()
            .min_by_key(|m| Hex::distance(centroid, m.hex))
            .map(|m| m.hex)
            .unwrap_or(centroid);
        let mut t = EnemyTeam::new(center);
        for m in members {
            t.add(m.kind, m.weight);
            t.contacts.push(m);
        }
        teams.push(t);
    }
    // 空中单位并入最近的地面队伍（计入 size / air / 组成），使队伍规模与支援计算包含空中单位
    for &ai in &air {
        let c = &contacts[ai];
        let nearest = teams
            .iter_mut()
            .min_by_key(|t| Hex::distance(t.center, c.hex));
        if let Some(t) = nearest {
            t.add(c.kind, c.weight);
            t.contacts.push(c.clone());
        }
    }
    teams
}

fn compute_priority(game: &GameState, team: Team, t: &EnemyTeam) -> f64 {
    let visible_n = t.contacts.iter().filter(|c| c.visible).count() as f64;
    let mut p = t.size
        + 0.5 * visible_n // 确认可见的威胁更紧迫
        + 1.5 * t.armor_heavy
        + 1.0 * t.armor_light
        + 1.2 * t.air
        + 0.6 * t.infantry
        + 1.0 * t.indirect;
    if let Some(hq) = game.hq_pos(team) {
        let d = Hex::distance(t.center, hq);
        let radius = game
            .ai_configs
            .get(&team)
            .map(|c| c.defend_radius)
            .unwrap_or(8);
        if d <= radius {
            p += 8.0; // 兵临城下 → 最高优先
        }
        p -= 0.06 * d as f64; // 远处队伍略降权，避免全图追人
    }
    for (h, kp) in &game.keypoints {
        if kp.owner == team && Hex::distance(t.center, *h) <= 2 {
            p += 6.0; // 敌队压在我方据点上
        }
    }
    p.max(0.1)
}

/// 构建按优先级降序排列的敌方队伍。
pub fn teams_for(game: &GameState, world: &PerceivedWorld, team: Team) -> Vec<EnemyTeam> {
    let mut teams = cluster(&collect_contacts(world));
    for t in teams.iter_mut() {
        t.priority = compute_priority(game, team, t);
    }
    teams.sort_by(|a, b| {
        b.priority
            .partial_cmp(&a.priority)
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    teams
}

fn is_anti_armor(k: UnitKind) -> bool {
    matches!(
        k,
        UnitKind::Atgm
            | UnitKind::Javelin
            | UnitKind::Tank
            | UnitKind::HeavyTank
            | UnitKind::CavalryIfv
            | UnitKind::HumveeTow
            | UnitKind::HumveeJavelin
    )
}

fn is_anti_infantry(k: UnitKind) -> bool {
    matches!(
        k,
        UnitKind::Rifleman
            | UnitKind::EliteInfantry
            | UnitKind::SpecialForces
            | UnitKind::HmgGunner
            | UnitKind::HumveeHmg
    )
}

/// 单位类型与队伍组成的匹配度（用于按敌队兵种分配支援）。
pub fn type_match(k: UnitKind, t: &EnemyTeam) -> f64 {
    let mut m = 0.0;
    if k.is_aa() {
        m += t.air;
    }
    if is_anti_armor(k) {
        m += t.armor_heavy + 0.6 * t.armor_light;
    }
    if is_anti_infantry(k) {
        m += 0.5 * t.infantry;
    }
    if matches!(k, UnitKind::Howitzer | UnitKind::Mortar) {
        m += 0.6 * (t.infantry + t.indirect);
    }
    if matches!(k, UnitKind::Scout | UnitKind::Drone | UnitKind::AttackHeli) {
        m += 0.3; // 侦察/机动单位对任何队伍都有价值
    }
    m
}

/// 为每个己方单位分配一个敌方队伍中心作为动态 objective。
/// 评分 = 队伍优先级 + 兵种匹配×3 - 距离×0.4。
pub fn assign_units(
    game: &GameState,
    team: Team,
    teams: &[EnemyTeam],
) -> HashMap<char, Hex> {
    let mut map = HashMap::new();
    if teams.is_empty() {
        return map;
    }
    for u in game.units_of(team) {
        if u.kind == UnitKind::Headquarters {
            continue;
        }
        let mut best: Option<(f64, Hex)> = None;
        for t in teams {
            let d = Hex::distance(u.pos, t.center) as f64;
            let score = t.priority + type_match(u.kind, t) * 3.0 - 0.4 * d;
            if best.map_or(true, |(bs, _)| score > bs) {
                best = Some((score, t.center));
            }
        }
        if let Some((_, c)) = best {
            map.insert(u.label, c);
        }
    }
    map
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::unit::Unit;

    fn clear(g: &mut GameState, h: Hex) {
        g.map.obstacles.remove(&h);
        g.map.buildings.remove(&h);
        g.map.forests.remove(&h);
        g.map.water.remove(&h);
    }

    fn empty(seed: u64) -> GameState {
        let mut g = GameState::new_seeded(seed);
        g.units.clear();
        g.air_units.clear();
        g.deploying = false;
        g.winner = None;
        g
    }

    /// 半径 4 内应聚为一队，远的另成一队。
    #[test]
    fn clusters_by_radius() {
        let mut g = empty(81);
        let a = hex::axial_from_offset(10, 6);
        let b = hex::axial_from_offset(11, 6);
        let c = hex::axial_from_offset(10, 8);
        let far = hex::axial_from_offset(18, 6);
        let ai = hex::axial_from_offset(6, 6);
        for h in [a, b, c, far, ai] {
            clear(&mut g, h);
        }
        // 侦察无人机视野 12，可发现 6 格内的步兵与 12 格内的车辆
        g.units.insert(ai, Unit::new(UnitKind::Drone, Team::Ai, ai));
        for h in [a, b, c] {
            g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Player, h));
        }
        // 远处用一个"?"幽灵表示（必定计入，且与近处 3 人距离 >4 → 独立一队）
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(far, (UnitKind::Tank, g.turn));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let teams = teams_for(&g, &world, Team::Ai);
        assert_eq!(teams.len(), 2, "应聚成 2 队: {:?}", teams);
        assert!(teams.iter().any(|t| (t.size - 3.0).abs() < 1e-9));
        assert!(teams.iter().any(|t| (t.size - 1.0).abs() < 1e-9));
    }

    /// 幽灵"?"按 1 个棋子计入规模。
    #[test]
    fn ghost_counts_as_unit() {
        let mut g = empty(83);
        let ghost = hex::axial_from_offset(15, 6);
        clear(&mut g, ghost);
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(ghost, (UnitKind::Tank, g.turn));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let teams = teams_for(&g, &world, Team::Ai);
        assert_eq!(teams.len(), 1);
        assert!(teams[0].size > 0.0 && teams[0].size <= 1.0 + 1e-9);
    }

    /// 防空单位应被分配到空中威胁那队（兵种匹配压过距离）。
    #[test]
    fn assigns_aa_to_air_team() {
        let mut g = empty(85);
        let aa = hex::axial_from_offset(4, 6);
        let ground = hex::axial_from_offset(6, 6);
        let air1 = hex::axial_from_offset(20, 2);
        let air2 = hex::axial_from_offset(21, 2);
        let inf = hex::axial_from_offset(7, 6);
        for h in [aa, ground, air1, air2, inf] {
            clear(&mut g, h);
        }
        let mut aau = Unit::new(UnitKind::AaLauncher, Team::Ai, aa);
        aau.label = 'A';
        g.units.insert(aa, aau);
        g.units.insert(ground, Unit::new(UnitKind::Rifleman, Team::Ai, ground));
        g.units
            .insert(air1, Unit::new(UnitKind::AttackHeli, Team::Player, air1));
        g.units
            .insert(air2, Unit::new(UnitKind::AttackHeli, Team::Player, air2));
        g.units.insert(inf, Unit::new(UnitKind::Rifleman, Team::Player, inf));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let teams = teams_for(&g, &world, Team::Ai);
        let assign = assign_units(&g, Team::Ai, &teams);
        let air_center = teams
            .iter()
            .max_by(|x, y| x.air.partial_cmp(&y.air).unwrap())
            .unwrap()
            .center;
        assert_eq!(assign.get(&'A'), Some(&air_center), "防空应去空中队");
    }

    /// 空中单位不参与聚类，但并入最近队伍的规模/组成。
    #[test]
    fn clustering_ground_only_air_joins_nearest() {
        let mut g = empty(87);
        let ai = hex::axial_from_offset(4, 6);
        let g1 = hex::axial_from_offset(9, 6);
        let g2 = hex::axial_from_offset(10, 6);
        let far = hex::axial_from_offset(18, 6);
        let heli = hex::axial_from_offset(11, 6);
        for h in [ai, g1, g2, far, heli] {
            clear(&mut g, h);
        }
        g.units.insert(ai, Unit::new(UnitKind::Drone, Team::Ai, ai));
        g.units
            .insert(g1, Unit::new(UnitKind::Rifleman, Team::Player, g1));
        // g2 与 far 用幽灵表示，保证已知且不受视野影响
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(g2, (UnitKind::Rifleman, g.turn));
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(far, (UnitKind::Rifleman, g.turn));
        g.units
            .insert(heli, Unit::new(UnitKind::AttackHeli, Team::Player, heli));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let teams = teams_for(&g, &world, Team::Ai);
        assert_eq!(teams.len(), 2, "空中单位不应改变聚类数: {:?}", teams);
        assert!(teams.iter().any(|t| t.air > 0.0), "空中单位应并入某队: {:?}", teams);
        // 含空中的那队规模 = 2 地面 + 1 空中 = 3
        assert!(
            teams.iter().any(|t| (t.size - 3.0).abs() < 1e-9),
            "队伍规模应包含空中单位: {:?}",
            teams
        );
    }

    /// 纯空中编队不构成队伍（队伍识别仅统计地面单位）。
    #[test]
    fn only_air_no_team() {
        let mut g = empty(89);
        let ai = hex::axial_from_offset(4, 6);
        let h1 = hex::axial_from_offset(8, 6);
        for h in [ai, h1] {
            clear(&mut g, h);
        }
        g.units.insert(ai, Unit::new(UnitKind::Drone, Team::Ai, ai));
        g.units
            .insert(h1, Unit::new(UnitKind::AttackHeli, Team::Player, h1));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let teams = teams_for(&g, &world, Team::Ai);
        assert!(teams.is_empty(), "纯空中编队不构成队伍: {:?}", teams);
    }
}
