//! 概率信念（新版 AI，Phase 4）：对未观测敌军位置的概率分布。
//!
//! 由"可见敌人（概率 1）" + "最后已知位置（幽灵，按兵种机动范围扩散、按时间衰减）"
//! 构建，用于：侦察选点（高不确定区）、炮兵打击（高概率集结点）、
//! 以及 determinized 搜索（从信念采样一致的敌方布置）。

use std::collections::BTreeMap;

use crate::hex::{self, Hex};

use super::world::PerceivedWorld;
use crate::game::GameState;

#[derive(Clone, Debug, Default)]
pub struct Belief {
    /// 每格存在敌军（未确认）的概率。已归一化。
    pub p: BTreeMap<Hex, f64>,
}

impl Belief {
    /// 从当前感知世界构建信念分布。
    pub fn build(game: &GameState, world: &PerceivedWorld) -> Self {
        let mut p: BTreeMap<Hex, f64> = BTreeMap::new();
        // 可见敌人：确定性计入
        for e in &world.visible_enemies {
            *p.entry(e.pos).or_insert(0.0) += 1.0;
        }
        // 幽灵：按兵种机动范围扩散，越远/越旧概率越低
        for (gh, kind, age) in &world.ghosts {
            if world.visible_enemy_hexes.contains(gh) {
                continue; // 当前已可见，前面已计入
            }
            let reach = kind.movement().max(0);
            if reach <= 0 {
                *p.entry(*gh).or_insert(0.0) += 1.0;
                continue;
            }
            let decay = 1.0 / (1.0 + *age as f64);
            let (c0, r0) = hex::offset_from_axial(*gh);
            for dc in -reach..=reach {
                for dr in -reach..=reach {
                    let h = hex::axial_from_offset(c0 + dc, r0 + dr);
                    if !game.map.contains(h) || game.map.obstacles.contains(&h) {
                        continue;
                    }
                    let d = Hex::distance(*gh, h);
                    if d > reach {
                        continue;
                    }
                    let w = decay / (1.0 + d as f64);
                    *p.entry(h).or_insert(0.0) += w;
                }
            }
        }
        let sum: f64 = p.values().sum();
        if sum > 0.0 {
            for v in p.values_mut() {
                *v /= sum;
            }
        }
        Belief { p }
    }

    pub fn prob(&self, h: Hex) -> f64 {
        self.p.get(&h).copied().unwrap_or(0.0)
    }

    pub fn is_empty(&self) -> bool {
        self.p.is_empty()
    }

    /// 概率最高的若干格（不确定热点），用于侦察选点。
    pub fn hotspots(&self, n: usize) -> Vec<Hex> {
        let mut v: Vec<(f64, Hex)> = self.p.iter().map(|(h, p)| (*p, *h)).collect();
        v.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        v.into_iter().take(n).map(|(_, h)| h).collect()
    }

    /// 按概率采样一个位置（determinization 用）。
    pub fn sample(&self, rng: &mut impl rand::Rng) -> Option<Hex> {
        let total: f64 = self.p.values().sum();
        if total <= 0.0 {
            return None;
        }
        let mut r = rng.gen::<f64>() * total;
        for (h, p) in &self.p {
            r -= *p;
            if r <= 0.0 {
                return Some(*h);
            }
        }
        self.p.keys().next().copied()
    }
}
