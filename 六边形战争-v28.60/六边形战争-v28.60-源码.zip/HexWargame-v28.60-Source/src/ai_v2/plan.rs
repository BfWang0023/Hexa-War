//! 战术层（新版 AI）：统一效用 + 宏行动枚举（移动后射击）+ 火炮评分。
//! Phase 3：接入战役层（任务组角色 / 全队集火 / 作战目标 / 侦察信息增益）。
//! 单次激活只选一个宏行动并执行；循环直到行动次数耗尽。

use std::collections::{BTreeSet, HashSet};

use crate::game::{AiDifficulty, GameState, SimulOrder};
use crate::hex::{self, Hex};
use crate::unit::{Team, Unit, UnitKind};

use super::eval::{self, Weights};
use super::operational::{self, Operation, Role};
use super::strategic;
use super::world::PerceivedWorld;

/// 一个"宏行动"：移动到哪里、打谁、架设、卸载。
#[derive(Clone, Copy, Debug)]
enum PlanAction {
    Fire(Hex),
    Move(Hex),
    Deploy,
    Unload { label: char, dest: Option<Hex> },
    /// 搭载紧邻（卡车）或正下方（运输直升机）的己方步兵。
    Board { target: Hex },
    /// 原地待命（不消耗行动，结束该单位的本次激活）。
    Hold,
}

pub fn run_turn(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    if game.test_mode && team == Team::Ai {
        return;
    }
    game.prune_fog_fire_marks();
    // 补给：主武器弹药耗尽且在补给区内的单位先花 1 行动补满（规划前执行）。
    let supply_log = game.auto_resupply(team);
    log.extend(supply_log);

    if game.sustain {
        game.sustain_deploying = true;
        strategic::reinforce_turn(game, team, log);
        game.sustain_deploying = false;
    }
    if game.sustain {
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .find(|(_, kp)| kp.owner == team.opponent() && kp.center)
        {
            game.hq_seen.insert(team, Some(*h));
        }
    }

    let volleyed = try_volley(game, team, log);
    if game.game_over() {
        return;
    }

    // 先构建一次感知世界用于确定行动顺序。之后每支部队开始行动前：
    // - 若上一支是侦察单位（可能前出开眼）→ 重做完整视野；
    // - 否则只刷新可见敌人列表（廉价）。
    let mut world = PerceivedWorld::build(game, team);
    let op0 = operational::build(game, &world, team);
    // 新版 AI 的作战任务由本方胜利条件决定（进攻/坚守/固守）：有多方关键据点的
    // 对局里记一行任务摘要，便于复盘"为什么这样打"。
    if game.keypoints.values().any(|kp| !kp.center) {
        log.push(format!(
            "[AI] 🎯 任务：{}（待夺取据点 {} · 己方据点 {}）",
            op0.mission.name(),
            op0.targets.len(),
            op0.held.len()
        ));
    }

    // 行动顺序：侦察 → 火力 → 反装甲 → 防空 → 突击 → 预备（同级按兵种价值）。
    let mut order: Vec<(i32, i32, char, Hex)> = game
        .units_of(team)
        .into_iter()
        .map(|u| {
            let role = op0.role_of(u.label);
            // 运输单位提前行动，便于在步兵离开前接载
            let prio = if is_transport(u.kind) { 3 } else { role.priority() };
            (prio, u.kind.value(), u.label, u.pos)
        })
        .collect();
    order.sort_by(|a, b| {
        b.0.cmp(&a.0)
            .then(b.1.cmp(&a.1))
            .then(a.3.q.cmp(&b.3.q))
            .then(a.3.r.cmp(&b.3.r))
    });

    // —— team-turn 束搜索（高难度启用；超时或新兵则回退贪心）——
    let beam_order: Vec<char> = order
        .iter()
        .filter(|(_, _, l, _)| !volleyed.contains(l))
        .map(|(_, _, l, _)| *l)
        .collect();
    let plan = try_determinized(game, team, &world, &beam_order, op0.objective)
        .or_else(|| try_beam(game, team, &world, &beam_order, op0.objective));
    if let Some(plan) = plan {
        execute_plan(game, team, &plan, log);
        return;
    }

    let mut full_refresh = false;
    for (_, _, label0, start) in order {
        let mut pos = start;
        if volleyed.contains(&label0) {
            continue;
        }
        if full_refresh {
            world = PerceivedWorld::build(game, team);
        } else {
            world.refresh_enemies(game);
        }
        // 战役层每支部队行动前重建（廉价，不含 BFS）：焦点/目标随最新敌情更新。
        let op = operational::build(game, &world, team);
        full_refresh = op.role_of(label0) == Role::Recon;
        let mut guard = 0;
        loop {
            guard += 1;
            if guard > 16 {
                break;
            }
            let Some(u0) = game.unit_at(pos).cloned() else {
                break;
            };
            if u0.actions_left <= 0 {
                break;
            }
            world.refresh_enemies(game);
            if let Ok(true) = auto_switch_weapons(game, pos, &world) {
                continue;
            }
            let u = match game.unit_at(pos) {
                Some(x) => x.clone(),
                None => break,
            };
            match choose_action(game, team, &world, &op, &u) {
                None => {
                    if let Some(np) = approach(game, &op, &u, log) {
                        pos = np;
                        continue;
                    }
                    break;
                }
                Some(PlanAction::Hold) => break,
                Some(PlanAction::Deploy) => {
                    if game.deploy(pos).is_ok() {
                        log.push(format!("[AI] {} 完成架设", u.name_with_label()));
                    } else {
                        break;
                    }
                    continue; // 重机枪手架设后若仍有行动可继续开火
                }
                Some(PlanAction::Unload { label, dest }) => {
                    let ok = match (u.kind.is_air(), dest) {
                        (true, _) => game.heli_unload(pos).is_ok(),
                        (false, Some(d)) => game.disembark(pos, label, d).is_ok(),
                        (false, None) => false,
                    };
                    if ok {
                        log.push(format!("[AI] {} 放下搭载步兵", u.name_with_label()));
                    } else {
                        break;
                    }
                }
                Some(PlanAction::Board { target }) => {
                    let ok = if u.kind.is_air() {
                        game.heli_board(pos).is_ok()
                    } else {
                        game.board(pos, target).is_ok()
                    };
                    if ok {
                        log.push(format!("[AI] {} 搭载步兵", u.name_with_label()));
                    } else {
                        break;
                    }
                }
                Some(PlanAction::Fire(t)) => match game.attack(pos, t) {
                    Ok(out) => {
                        let killed = out.killed;
                        log.push(format!("[AI] {}", out.message));
                        if killed && game.game_over() {
                            return;
                        }
                    }
                    Err(e) => {
                        log.push(format!("[AI] {}", e));
                        break;
                    }
                },
                Some(PlanAction::Move(dest)) => {
                    let path = game.map.plan_move(
                        &game.units,
                        &game.air_units,
                        pos,
                        dest,
                        u.kind.movement(),
                        Some(u.clone()),
                        true,
                    );
                    if path.len() <= 1 {
                        break;
                    }
                    match game.move_unit(pos, &path, u.kind.is_air()) {
                        Ok(np) => {
                            log.push(format!(
                                "[AI] {} → {}",
                                u.name_with_label(),
                                hex::hex_label(np)
                            ));
                            pos = np;
                        }
                        Err(e) => {
                            log.push(format!("[AI] 移动失败: {}", e));
                            break;
                        }
                    }
                }
            }
            let left = game.unit_at(pos).map(|x| x.actions_left).unwrap_or(0);
            if left <= 0 {
                break;
            }
        }
    }
}

/// 难度档位 → 候选落点上限（搜索广度）。
fn candidate_cap(d: AiDifficulty) -> usize {
    match d {
        AiDifficulty::Recruit => 6,
        AiDifficulty::Regular => 12,
        AiDifficulty::Veteran => 16,
        AiDifficulty::Elite => 20,
    }
}

/// 选择一个宏行动。范围单位单独处理；其余单位在"原地开火"与
/// "移动到某格（并预期下一动作开火）"之间按统一效用取最优。
fn choose_action(
    game: &GameState,
    team: Team,
    world: &PerceivedWorld,
    op: &Operation,
    u: &Unit,
) -> Option<PlanAction> {
    rank_actions(game, team, world, op, u, 1)
        .into_iter()
        .next()
        .map(|(a, _)| a)
}

/// 对一个单位枚举并排序候选宏行动（含 Hold）。贪心取第 1 个；
/// team-turn 束搜索取前 max_n 个作为分支。
fn rank_actions(
    game: &GameState,
    team: Team,
    world: &PerceivedWorld,
    op: &Operation,
    u: &Unit,
    max_n: usize,
) -> Vec<(PlanAction, f64)> {
    let d = game.ai_difficulty;
    let w = Weights::for_difficulty(d);

    // 火炮/迫击炮：架设或单一最优炮击点（不做位置分支）
    if u.kind == UnitKind::Howitzer {
        if !u.deployed {
            return vec![(PlanAction::Deploy, 0.0)];
        }
        return best_blast(game, team, world, op, u)
            .map(|t| vec![(PlanAction::Fire(t), 1.0)])
            .unwrap_or_default();
    }
    if u.kind == UnitKind::Mortar {
        return best_blast(game, team, world, op, u)
            .map(|t| vec![(PlanAction::Fire(t), 1.0)])
            .unwrap_or_default();
    }
    // 运输单位（卡车/运输直升机）：往返大本营与前线之间的摆渡逻辑
    if is_transport(u.kind) {
        return transport_plan(game, world, op, u)
            .map(|a| vec![(a, 1.0)])
            .unwrap_or_default();
    }
    // 其他载具（步战/骑兵战车）：接近敌人时卸载步兵
    if let Some(a) = transport_action(game, world, u) {
        return vec![(a, 0.0)];
    }

    let mut out: Vec<(PlanAction, f64)> = Vec::new();
    let stay_pos = position_score(game, world, op, u, u.pos, u.pos, &w);
    // 原地待命（不消耗行动）
    out.push((PlanAction::Hold, stay_pos));

    // 需要架设的单位（重机枪手）未架设时不能开火，只能先架设或移动。
    let needs_setup = u.kind.needs_deploy() && !u.deployed;

    if !needs_setup
        && u.kind.can_attack()
        && u.actions_left >= u.kind.attack_cost()
        && u.ammo_shown() > 0
    {
        for t in &world.visible_enemies {
            if let Some(s) = attack_score_from(game, world, op, u, t, &w) {
                out.push((PlanAction::Fire(t.pos), s + stay_pos));
            }
        }
    }

    if u.kind.movement() > 0 {
        let can_move_and_fire = !needs_setup
            && d != AiDifficulty::Recruit
            && u.kind.can_attack()
            && u.actions_left >= 1 + u.kind.attack_cost()
            && u.ammo_shown() > 0;
        for dest in candidate_dests(game, world, op, u, candidate_cap(d)) {
            let mut mover = u.clone();
            mover.pos = dest;
            // 移动会取消架设：移动分支按"到达后未架设"状态评估。
            if mover.kind.needs_deploy() {
                mover.deployed = false;
            }
            let mut atk = 0.0f64;
            if can_move_and_fire {
                for t in &world.visible_enemies {
                    if let Some(s) = attack_score_from(game, world, op, &mover, t, &w) {
                        if s > atk {
                            atk = s;
                        }
                    }
                }
            }
            let ps = position_score(game, world, op, &mover, u.pos, dest, &w);
            out.push((PlanAction::Move(dest), atk + ps));
        }
    }

    // 架设：架设后若仍有行动余量，按"架设后开火"的最佳效用评分。
    if needs_setup && u.actions_left >= 1 {
        let mut deployed_u = u.clone();
        deployed_u.deployed = true;
        let mut s = stay_pos;
        if u.actions_left >= 1 + u.kind.attack_cost()
            && u.kind.can_attack()
            && u.ammo_shown() > 0
        {
            for t in &world.visible_enemies {
                if let Some(ts) = attack_score_from(game, world, op, &deployed_u, t, &w) {
                    s = s.max(ts + stay_pos);
                }
            }
        }
        out.push((PlanAction::Deploy, s));
    }

    out.sort_by(|a, b| {
        b.1.partial_cmp(&a.1)
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    out.truncate(max_n.max(1));
    out
}

// ===================== team-turn 束搜索（Phase 3） =====================

/// 束搜索节点：克隆的静默盘面 + 已执行动作序列 + 盘面评分。
struct BeamNode {
    state: GameState,
    plan: Vec<(char, PlanAction)>,
    score: f64,
    /// 本轮已"结束行动"的单位（选择 Hold，或行动次数耗尽）。
    done: HashSet<char>,
}

/// 清掉仿真克隆里的瞬态缓冲，避免克隆体积随搜索深度膨胀。
fn strip_transient(g: &mut GameState) {
    g.event_log.clear();
    g.ui_events.clear();
    g.battle_events.clear();
    g.notices.clear();
    g.killed_hexes.clear();
}

fn find_unit_pos(g: &GameState, label: char) -> Option<Hex> {
    g.units
        .iter()
        .find(|(_, u)| u.label == label)
        .map(|(h, _)| *h)
        .or_else(|| {
            g.air_units
                .iter()
                .find(|(_, u)| u.label == label)
                .map(|(h, _)| *h)
        })
}

fn next_unit(state: &GameState, order: &[char], done: &HashSet<char>) -> Option<char> {
    order.iter().copied().find(|lb| {
        !done.contains(lb)
            && find_unit_pos(state, *lb)
                .and_then(|h| state.unit_at(h))
                .map(|u| u.actions_left > 0)
                .unwrap_or(false)
    })
}

/// 用根回合的视野/遮挡物构造轻量感知世界（不做 BFS），只刷新可见敌人。
fn search_world(base: &PerceivedWorld, state: &GameState) -> PerceivedWorld {
    let mut w = PerceivedWorld {
        team: base.team,
        visible_enemy_hexes: base.visible_enemy_hexes.clone(),
        visible_enemies: Vec::new(),
        blockers: base.blockers.clone(),
        terrain: base.terrain.clone(),
        ghosts: base.ghosts.clone(),
        belief: base.belief.clone(),
    };
    w.refresh_enemies(state);
    w
}

/// 在盘面上执行一个宏行动（返回可打印日志；Hold 返回 None）。
fn apply_plan_action(
    game: &mut GameState,
    label: char,
    action: PlanAction,
) -> Result<Option<String>, String> {
    let Some(pos) = find_unit_pos(game, label) else {
        return Err("单位不存在".into());
    };
    match action {
        PlanAction::Hold => Ok(None),
        PlanAction::Deploy => {
            game.deploy(pos)?;
            let name = game
                .unit_at(pos)
                .map(|u| u.name_with_label())
                .unwrap_or_default();
            Ok(Some(format!("[AI] {} 完成架设", name)))
        }
        PlanAction::Fire(t) => {
            let out = game.attack(pos, t)?;
            Ok(Some(format!("[AI] {}", out.message)))
        }
        PlanAction::Move(dest) => {
            let u = game.unit_at(pos).cloned().ok_or("单位不存在")?;
            let path = game.map.plan_move(
                &game.units,
                &game.air_units,
                pos,
                dest,
                u.kind.movement(),
                Some(u.clone()),
                true,
            );
            if path.len() <= 1 {
                return Err("无路径".into());
            }
            let np = game.move_unit(pos, &path, u.kind.is_air())?;
            Ok(Some(format!(
                "[AI] {} → {}",
                u.name_with_label(),
                hex::hex_label(np)
            )))
        }
        PlanAction::Unload { label: pass, dest } => {
            let u = game.unit_at(pos).cloned().ok_or("单位不存在")?;
            if u.kind.is_air() {
                game.heli_unload(pos)?;
            } else if let Some(d) = dest {
                game.disembark(pos, pass, d)?;
            } else {
                return Err("无落点".into());
            }
            Ok(Some(format!(
                "[AI] {} 放下搭载步兵",
                u.name_with_label()
            )))
        }
        PlanAction::Board { target } => {
            let u = game.unit_at(pos).cloned().ok_or("单位不存在")?;
            if u.kind.is_air() {
                game.heli_board(pos)?;
            } else {
                game.board(pos, target)?;
            }
            Ok(Some(format!("[AI] {} 搭载步兵", u.name_with_label())))
        }
    }
}

/// 按难度取束搜索参数：(束宽 K, 分支数 B, 时间预算毫秒)。
fn beam_params(d: AiDifficulty) -> Option<(usize, usize, u64)> {
    match d {
        AiDifficulty::Recruit => None,
        AiDifficulty::Regular => Some((2, 4, 25)),
        AiDifficulty::Veteran => Some((4, 8, 80)),
        AiDifficulty::Elite => Some((8, 12, 150)),
    }
}

fn beam_search(
    game: &GameState,
    team: Team,
    base: &PerceivedWorld,
    order: &[char],
    objective: Option<Hex>,
    k: usize,
    b: usize,
    budget: std::time::Duration,
) -> Option<Vec<(char, PlanAction)>> {
    use std::time::Instant;
    let start = Instant::now();
    let mut root = game.clone();
    strip_transient(&mut root);
    let mut beam: Vec<BeamNode> = vec![BeamNode {
        state: root,
        plan: Vec::new(),
        score: f64::NEG_INFINITY,
        done: HashSet::new(),
    }];
    let max_steps = (order.len() * 4).max(8);

    for _ in 0..max_steps {
        if start.elapsed() > budget {
            return None; // 超时 → 放弃，回退贪心
        }
        if beam
            .iter()
            .all(|n| next_unit(&n.state, order, &n.done).is_none())
        {
            break;
        }
        let mut next: Vec<BeamNode> = Vec::new();
        for node in &beam {
            let Some(label) = next_unit(&node.state, order, &node.done) else {
                let mut s = node.state.clone();
                strip_transient(&mut s);
                next.push(BeamNode {
                    state: s,
                    plan: node.plan.clone(),
                    score: node.score,
                    done: node.done.clone(),
                });
                continue;
            };
            let w = search_world(base, &node.state);
            let op = operational::build(&node.state, &w, team);
            // 推演前先做一次特殊武器切换（不消耗行动），与真实执行保持一致。
            let mut pre = node.state.clone();
            if let Some(h) = find_unit_pos(&pre, label) {
                let _ = auto_switch_weapons(&mut pre, h, &w);
            }
            strip_transient(&mut pre);
            let Some(u) = find_unit_pos(&pre, label)
                .and_then(|h| pre.unit_at(h).cloned())
            else {
                continue;
            };
            for (action, ascore) in rank_actions(&pre, team, &w, &op, &u, b) {
                let mut child = pre.clone();
                if apply_plan_action(&mut child, label, action).is_err() {
                    continue;
                }
                strip_transient(&mut child);
                let board = eval::score_state(&child, team, objective);
                let mut plan = node.plan.clone();
                plan.push((label, action));
                let mut done = node.done.clone();
                let child_left = find_unit_pos(&child, label)
                    .and_then(|h| child.unit_at(h))
                    .map(|c| c.actions_left)
                    .unwrap_or(0);
                if matches!(action, PlanAction::Hold) || child_left <= 0 {
                    done.insert(label);
                }
                next.push(BeamNode {
                    state: child,
                    plan,
                    score: board + 0.25 * ascore,
                    done,
                });
            }
        }
        if next.is_empty() {
            break;
        }
        next.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
        next.truncate(k.max(1));
        beam = next;
    }

    beam.into_iter()
        .max_by(|a, b| a.score.partial_cmp(&b.score).unwrap_or(std::cmp::Ordering::Equal))
        .map(|n| n.plan)
}

/// 尝试整队束搜索；不适用（新兵/超时）返回 None，调用方回退贪心。
fn try_beam(
    game: &GameState,
    team: Team,
    world: &PerceivedWorld,
    order: &[char],
    objective: Option<Hex>,
) -> Option<Vec<(char, PlanAction)>> {
    let (k, b, ms) = beam_params(game.ai_difficulty)?;
    beam_search(
        game,
        team,
        world,
        order,
        objective,
        k,
        b,
        std::time::Duration::from_millis(ms),
    )
}

/// 把束搜索得到的动作序列执行到真实盘面（逐步校验，目标已死/落点被占则跳过）。
fn execute_plan(
    game: &mut GameState,
    team: Team,
    plan: &[(char, PlanAction)],
    log: &mut Vec<String>,
) {
    let world = PerceivedWorld::build(game, team);
    for (label, action) in plan {
        if game.game_over() {
            break;
        }
        let Some(pos) = find_unit_pos(game, *label) else {
            continue;
        };
        if game.unit_at(pos).map(|u| u.actions_left).unwrap_or(0) <= 0 {
            continue;
        }
        // 与推演一致：先切武器（不消耗行动），再执行动作。
        let _ = auto_switch_weapons(game, pos, &world);
        match apply_plan_action(game, *label, *action) {
            Ok(Some(msg)) => log.push(msg),
            Ok(None) => {}
            Err(_) => {}
        }
    }
}

/// 从 attacker 当前位置对 target 的攻击效用（含射程/类型/LOS/弹药校验 + 集火加成）。
fn attack_score_from(
    game: &GameState,
    world: &PerceivedWorld,
    op: &Operation,
    attacker: &Unit,
    target: &Unit,
    w: &Weights,
) -> Option<f64> {
    if attacker.ammo_shown() <= 0 || !attacker.kind.can_attack() {
        return None;
    }
    // 未架设的重机枪手不能开火（需先架设）。
    if attacker.kind.needs_deploy() && !attacker.deployed {
        return None;
    }
    if Hex::distance(attacker.pos, target.pos) > attacker.eff_range() {
        return None;
    }
    if !attacker.can_target_unit(target.kind) {
        return None;
    }
    let is_area = attacker.kind == UnitKind::Howitzer || attacker.kind == UnitKind::Mortar;
    if !is_area {
        let air_air = attacker.kind.is_air() && target.kind.is_air();
        if !air_air && !world.los(game, attacker.pos, target.pos) {
            return None;
        }
    }
    let e = eval::expected_direct(game, attacker, target);
    if e.p_hit <= 0.0 {
        return None;
    }
    if attacker.eff_attack() < target.kind.armor() && e.p_suppress <= 0.0 {
        return None;
    }
    let mut s = eval::attack_utility(&e, target, w);
    // 战役层：集火目标 + 防空优先
    if op.focus == Some(target.pos) {
        s += w.focus * eval::kind_value(target.kind);
    }
    if target.kind.is_air() && attacker.kind.is_aa() {
        s += w.focus * 1.5;
    }
    Some(s)
}

/// 单位从 h 处能否对 e 有效开火（射程/类型/可破甲/LOS；间瞄无需 LOS）。
fn can_shoot_from(game: &GameState, world: &PerceivedWorld, u: &Unit, h: Hex, e: &Unit) -> bool {
    if Hex::distance(h, e.pos) > u.eff_range() {
        return false;
    }
    if !u.can_target_unit(e.kind) {
        return false;
    }
    if u.eff_attack() < e.kind.armor() {
        return false;
    }
    let is_area = u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar;
    if is_area {
        return true;
    }
    let air_air = u.kind.is_air() && e.kind.is_air();
    air_air || world.los(game, h, e.pos)
}

/// 单位在 h 处是否已能打到某个可见敌人（判断"已进入交火"）。
fn engaged(game: &GameState, world: &PerceivedWorld, u: &Unit, h: Hex) -> bool {
    world
        .visible_enemies
        .iter()
        .any(|e| can_shoot_from(game, world, u, h, e))
}

/// 位置效用：掩体、威胁暴露（按角色缩放）、作战目标推进、侦察信息增益。
fn position_score(
    game: &GameState,
    world: &PerceivedWorld,
    op: &Operation,
    mover: &Unit,
    from: Hex,
    to: Hex,
    w: &Weights,
) -> f64 {
    let role = op.role_of(mover.label);
    let mut s = 0.0;
    if game.map.forests.contains(&to) {
        s += w.cover * 6.0;
    }
    if mover.kind.is_foot() && game.map.buildings.contains(&to) {
        s += w.cover * 10.0;
    }
    if game.smoke.contains_key(&to) {
        s += w.cover * 8.0;
    }
    let exp_w = match role {
        Role::Recon => 0.6,
        Role::FireSupport => 1.3,
        Role::Reserve => 1.1,
        _ => 1.0,
    };
    s -= w.expose * exp_w * world.exposure(game, mover, to);

    // 主目标：预备单位在无威胁时守大本营
    let unit_obj = op.objective_for(mover.label);
    let objective = if role == Role::Reserve && !game.defense_triggered(mover.team) {
        op.hq.or(unit_obj)
    } else {
        unit_obj
    };
    // 已能与敌人交火 → 不再朝队伍中心推进（"从适当位置开火"），
    // 位置微调交给掩体/暴露度决定。
    // 驻守单位（大本营防空 / 关键据点驻军）：始终被拉回驻地，
    // 不因交火而漂移到前线。
    let is_guard = op.base_guards.contains(&mover.label) || op.garrisons.contains_key(&mover.label);
    let engaged_now = engaged(game, world, mover, from);
    if let Some(obj) = objective {
        if is_guard || !engaged_now {
            let d0 = Hex::distance(from, obj) as f64;
            let d1 = Hex::distance(to, obj) as f64;
            s += w.objective * (d0 - d1);
        }
    }
    // 侦察：未交火时朝侦察方向前进；信息增益始终保留
    if role == Role::Recon {
        let v = mover.kind.vision();
        let gain = world.info_gain(game, to, v) - world.info_gain(game, from, v);
        s += w.info * gain as f64 * 0.15;
        if !engaged_now {
            if let Some(rt) = op.recon_target {
                let d0 = Hex::distance(from, rt) as f64;
                let d1 = Hex::distance(to, rt) as f64;
                s += w.info * (d0 - d1);
            }
        }
    }
    s
}

/// 候选落点：先按廉价启发式排序取前若干，避免对全部可达格做完整威胁评估。
fn candidate_dests(
    game: &GameState,
    world: &PerceivedWorld,
    op: &Operation,
    u: &Unit,
    cap: usize,
) -> Vec<Hex> {
    let reach = game.map.reachable_hexes_ex(&game.units, &game.air_units, u.pos, u.kind.movement(), Some(u));
    let role = op.role_of(u.label);
    let reference = if role == Role::Recon {
        op.recon_target.or_else(|| op.objective_for(u.label))
    } else if role == Role::Reserve && !game.defense_triggered(u.team) {
        op.hq.or_else(|| op.objective_for(u.label))
    } else {
        op.objective_for(u.label)
    };
    let is_guard = op.base_guards.contains(&u.label) || op.garrisons.contains_key(&u.label);
    let engaged_now = engaged(game, world, u, u.pos);
    let mut scored: Vec<(f64, Hex)> = reach
        .into_iter()
        .filter_map(|h| {
            if u.kind.is_air() {
                if let Some(other) = game.air_units.get(&h) {
                    if other.label != u.label {
                        return None;
                    }
                }
            }
            let mut s = 0.0f64;
            if let Some(o) = reference {
                // 已交火时只保留很弱的趋近倾向，让掩体/射界优先
                let pull = if engaged_now && !is_guard { 0.25 } else { 1.0 };
                s -= pull * Hex::distance(h, o) as f64;
            }
            if game.map.forests.contains(&h) {
                s += 1.5;
            }
            if u.kind.is_foot() && game.map.buildings.contains(&h) {
                s += 2.5;
            }
            if game.smoke.contains_key(&h) {
                s += 1.5;
            }
            if world
                .visible_enemies
                .iter()
                .any(|e| Hex::distance(h, e.pos) <= u.eff_range())
            {
                s += 1.0;
            }
            Some((s, h))
        })
        .collect();
    scored.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
    scored.into_iter().take(cap).map(|(_, h)| h).collect()
}

/// 无可用动作时朝作战目标推进一次。
fn approach(
    game: &mut GameState,
    op: &Operation,
    u: &Unit,
    log: &mut Vec<String>,
) -> Option<Hex> {
    if u.kind.movement() <= 0 {
        return None;
    }
    let obj = if op.role_of(u.label) == Role::Recon {
        op.recon_target.or_else(|| op.objective_for(u.label))
    } else {
        op.objective_for(u.label)
    }?;
    let path = game.map.plan_move(
        &game.units,
        &game.air_units,
        u.pos,
        obj,
        u.kind.movement(),
        Some(u.clone()),
        true,
    );
    if path.len() <= 1 {
        return None;
    }
    match game.move_unit(u.pos, &path, u.kind.is_air()) {
        Ok(np) => {
            log.push(format!(
                "[AI] {} 推进 → {}",
                u.name_with_label(),
                hex::hex_label(np)
            ));
            Some(np)
        }
        Err(_) => None,
    }
}

/// 最优炮击中心：射程内所有格中期望得分最高者（阈值以上才开火）；靠近集火目标加权。
fn best_blast(
    game: &GameState,
    team: Team,
    world: &PerceivedWorld,
    op: &Operation,
    u: &Unit,
) -> Option<Hex> {
    if u.ammo_shown() <= 0 || u.actions_left < u.kind.attack_cost() {
        return None;
    }
    let range = u.kind.range();
    let mut frontier = vec![u.pos];
    let mut seen: BTreeSet<Hex> = BTreeSet::new();
    seen.insert(u.pos);
    let mut best: Option<(f64, Hex)> = None;
    while let Some(h) = frontier.pop() {
        for n in h.neighbors() {
            if !game.map.contains(n) || seen.contains(&n) {
                continue;
            }
            seen.insert(n);
            if Hex::distance(u.pos, n) <= range {
                frontier.push(n);
                let mut s = eval::blast_score(
                    game,
                    team,
                    u,
                    n,
                    &world.visible_enemy_hexes,
                    &world.ghosts,
                    &world.belief,
                );
                // 集火加成只对"本就有炮击价值"的中心生效：集火目标可能是
                // 直升机（间瞄火力打不到），若仅凭集火加成就开火会空放炮弹。
                if s > 0.0 {
                    if let Some(f) = op.focus {
                        if Hex::distance(n, f) <= 1 {
                            s += 6.0;
                        }
                    }
                }
                if s > 4.0 && best.map_or(true, |(bs, _)| s > bs) {
                    best = Some((s, n));
                }
            }
        }
    }
    best.map(|(_, h)| h)
}

// ===================== 运输单位摆渡（卡车/运输直升机） =====================

/// 进入该距离即视为"已接近前线"（有乘客时准备卸载）。
const TRANSPORT_SAFE_ENEMY: i32 = 6;
/// 卸载点至少要与最近敌人保持的距离（避免把步兵丢在敌人面前）。
const TRANSPORT_UNLOAD_MIN: i32 = 5;
/// 后方步兵距焦点多远才值得摆渡（已在前线的不搬来搬去）。
const TRANSPORT_PICKUP_REAR: i32 = 6;
/// 搜索搭载目标的最大距离。
const TRANSPORT_PICKUP_RANGE: i32 = 16;

fn is_transport(k: UnitKind) -> bool {
    matches!(
        k,
        UnitKind::Truck | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli
    )
}

fn nearest_enemy_dist(world: &PerceivedWorld, h: Hex) -> i32 {
    world
        .visible_enemies
        .iter()
        .map(|e| Hex::distance(h, e.pos))
        .min()
        .unwrap_or(i32::MAX)
}

fn nearest_friend_dist(game: &GameState, team: Team, h: Hex, exclude: char) -> i32 {
    game.units_of(team)
        .iter()
        .filter(|x| x.label != exclude)
        .map(|x| Hex::distance(h, x.pos))
        .min()
        .unwrap_or(i32::MAX)
}

/// 生成"朝 target 移动一步"的动作。
fn move_toward(game: &GameState, u: &Unit, target: Hex) -> Option<PlanAction> {
    if u.pos == target {
        return None;
    }
    let path = game.map.plan_move(
        &game.units,
        &game.air_units,
        u.pos,
        target,
        u.kind.movement(),
        Some(u.clone()),
        true,
    );
    if path.len() <= 1 {
        return None;
    }
    Some(PlanAction::Move(*path.last().unwrap()))
}

/// 卸载动作：地面载具找紧邻空格（优先靠近己方），运直卸到正下方。
/// require_safe=true 时，落点必须与最近敌人保持 TRANSPORT_UNLOAD_MIN 距离。
fn transport_unload_action(
    game: &GameState,
    world: &PerceivedWorld,
    u: &Unit,
    require_safe: bool,
) -> Option<PlanAction> {
    if u.passengers.is_empty() {
        return None;
    }
    let label = u.passengers[0].label;
    if u.kind.is_air() {
        if game.map.obstacles.contains(&u.pos) || game.map.is_blocked(u.pos, &game.units) {
            return None;
        }
        if require_safe && nearest_enemy_dist(world, u.pos) < TRANSPORT_UNLOAD_MIN {
            return None;
        }
        return Some(PlanAction::Unload { label, dest: None });
    }
    let mut best: Option<(i32, Hex)> = None; // (离友军距离, 落点) 越小越靠己方
    for n in u.pos.neighbors() {
        if !game.map.contains(n) {
            continue;
        }
        if game.map.is_blocked(n, &game.units) || game.map.water.contains(&n) {
            continue;
        }
        if require_safe && nearest_enemy_dist(world, n) < TRANSPORT_UNLOAD_MIN {
            continue;
        }
        let fd = nearest_friend_dist(game, u.team, n, u.label);
        if best.map_or(true, |(bf, _)| fd < bf) {
            best = Some((fd, n));
        }
    }
    best.map(|(_, dest)| PlanAction::Unload { label, dest: Some(dest) })
}

/// 能否立刻搭载该格步兵（卡车需紧邻、运直需正下方同格）。
fn is_loadable_now(u: &Unit, inf_pos: Hex) -> bool {
    if u.kind.is_air() {
        u.pos == inf_pos
    } else {
        Hex::distance(u.pos, inf_pos) == 1
    }
}

/// 找一名"后方"己方步兵作为摆渡对象（已在前线作战的不搬）。
fn pickup_target(game: &GameState, u: &Unit, focus: Hex) -> Option<Hex> {
    let mut best: Option<(i32, Hex)> = None;
    for x in game.units_of(u.team) {
        if x.label == u.label || !x.kind.is_infantry() {
            continue;
        }
        if u.kind.is_air() && x.actions_left < 1 {
            continue; // 运直登机要求步兵有行动次数
        }
        if Hex::distance(x.pos, focus) <= TRANSPORT_PICKUP_REAR {
            continue; // 已在前线附近
        }
        let d = Hex::distance(u.pos, x.pos);
        if d > TRANSPORT_PICKUP_RANGE {
            continue;
        }
        if best.map_or(true, |(bd, _)| d < bd) {
            best = Some((d, x.pos));
        }
    }
    best.map(|(_, h)| h)
}

/// 运输单位的一步计划：
/// - 有乘客：朝"最前沿的己方单位"推进，接近前线且能安全卸下时卸载（不冲进敌阵）；
/// - 空载：在后方接载步兵，否则回大本营待命。
fn transport_plan(
    game: &GameState,
    world: &PerceivedWorld,
    op: &Operation,
    u: &Unit,
) -> Option<PlanAction> {
    let team = u.team;
    // ---- 有乘客：运送到前线附近的安全位置 ----
    if !u.passengers.is_empty() {
        let ed = nearest_enemy_dist(world, u.pos);
        if ed <= TRANSPORT_SAFE_ENEMY {
            if let Some(a) = transport_unload_action(game, world, u, true) {
                return Some(a);
            }
            return Some(PlanAction::Hold); // 太近，不冲，等机会
        }
        let focus = op.objective_for(u.label).or(op.objective);
        if let Some(focus) = focus {
            let front_friend = game
                .units_of(team)
                .iter()
                .filter(|x| x.label != u.label && !is_transport(x.kind))
                .min_by_key(|x| Hex::distance(x.pos, focus))
                .map(|x| x.pos);
            let target = front_friend.unwrap_or(focus);
            if let Some(a) = move_toward(game, u, target) {
                return Some(a);
            }
        }
        if let Some(a) = transport_unload_action(game, world, u, true) {
            return Some(a);
        }
        return Some(PlanAction::Hold);
    }

    // ---- 空载：接载后方步兵；否则回大本营待命 ----
    if !world.visible_enemies.is_empty() {
        if let Some(focus) = op.objective_for(u.label).or(op.objective) {
            if let Some(inf_pos) = pickup_target(game, u, focus) {
                if is_loadable_now(u, inf_pos) {
                    return Some(PlanAction::Board { target: inf_pos });
                }
                if let Some(a) = move_toward(game, u, inf_pos) {
                    return Some(a);
                }
            }
        }
    }
    if let Some(hq) = game.hq_pos(team) {
        if Hex::distance(u.pos, hq) <= 1 {
            return Some(PlanAction::Hold);
        }
        if let Some(a) = move_toward(game, u, hq) {
            return Some(a);
        }
    }
    Some(PlanAction::Hold)
}

/// 运输单位带兵且接近敌人时卸载（地面载具下到紧邻空格，运直下到正下方）。
fn transport_action(game: &GameState, world: &PerceivedWorld, u: &Unit) -> Option<PlanAction> {
    if u.passengers.is_empty() {
        return None;
    }
    let near = world
        .visible_enemies
        .iter()
        .any(|e| Hex::distance(e.pos, u.pos) <= 4);
    if !near {
        return None;
    }
    if u.kind.is_air() {
        if !game.map.obstacles.contains(&u.pos) && !game.map.is_blocked(u.pos, &game.units) {
            return Some(PlanAction::Unload {
                label: u.passengers[0].label,
                dest: None,
            });
        }
        return None;
    }
    let pass = u.passengers[0].label;
    for n in u.pos.neighbors() {
        if !game.map.contains(n) {
            continue;
        }
        if game.map.is_blocked(n, &game.units) || game.map.water.contains(&n) {
            continue;
        }
        return Some(PlanAction::Unload {
            label: pass,
            dest: Some(n),
        });
    }
    None
}

/// 特殊武器自动切换（移植自旧版，逻辑保持一致）。
/// 复用调用方已经算好的 PerceivedWorld，避免重复做视野 BFS。
fn auto_switch_weapons(
    game: &mut GameState,
    pos: Hex,
    world: &PerceivedWorld,
) -> Result<bool, String> {
    let u = game.unit_at(pos).ok_or("单位不存在")?.clone();
    if !u.is_dual_weapon() && !u.has_tertiary() {
        return Ok(false);
    }
    let es = &world.visible_enemies;
    let isvis = |_h: Hex| true;
    let heli_in = |r: i32| {
        es.iter()
            .any(|e| e.kind.is_air() && isvis(e.pos) && Hex::distance(u.pos, e.pos) <= r)
    };
    let veh_in = |r: i32| {
        es.iter().any(|e| {
            !e.kind.is_air()
                && e.kind.is_vehicle()
                && e.kind.armor() >= 2
                && isvis(e.pos)
                && Hex::distance(u.pos, e.pos) <= r
        })
    };
    let inf_in_building = |r: i32| {
        es.iter().any(|e| {
            e.kind.is_foot()
                && isvis(e.pos)
                && Hex::distance(u.pos, e.pos) <= r
                && game.map.buildings.contains(&e.pos)
        })
    };
    let heavy_in = |r: i32| {
        es.iter()
            .any(|e| isvis(e.pos) && Hex::distance(u.pos, e.pos) <= r && e.kind.armor() >= 3)
    };
    // 软目标：护甲 < 2 的非空中单位（机枪可有效打击并压制步兵）。
    // 悍马系列除外——坦克炮对其有 80% 殉爆（2 点伤害），保留主炮更优。
    let soft_in = |r: i32| {
        es.iter().any(|e| {
            !e.kind.is_air()
                && e.kind.armor() < 2
                && !e.kind.is_humvee()
                && isvis(e.pos)
                && Hex::distance(u.pos, e.pos) <= r
        })
    };
    let (want_aa, want_missile): (Option<bool>, Option<bool>) = match u.kind {
        UnitKind::SpecialForces => {
            if heli_in(8) && u.aa_ammo > 0 {
                (Some(true), None)
            } else if veh_in(3) && u.missile_ammo > 0 {
                (Some(false), Some(true))
            } else {
                (Some(false), Some(false))
            }
        }
        UnitKind::EliteInfantry => {
            if veh_in(3) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Rifleman => {
            if inf_in_building(3) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::AaMgv => {
            if heli_in(8) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Howitzer => {
            if heavy_in(16) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Ifv | UnitKind::CavalryIfv => {
            if veh_in(8) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Tank | UnitKind::HeavyTank => {
            // 车载重机枪（射程 4）压制软目标：机枪射程内有软目标、且主炮射程内
            // 没有装甲目标（护甲 ≥ 2）时切机枪；否则保留坦克炮优先反装甲。
            let mg_range = {
                let mut mg = u.clone();
                mg.missile_mode = true;
                mg.eff_range()
            };
            if u.missile_ammo > 0 && soft_in(mg_range) && !veh_in(u.kind.range()) {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        _ => (None, None),
    };
    let cur = game.unit_at(pos).ok_or("单位不存在")?.clone();
    let mut switched = false;
    if let Some(w) = want_aa {
        if cur.aa_mode != w {
            game.toggle_aa_mode(pos)?;
            switched = true;
        }
    }
    if let Some(w) = want_missile {
        if cur.missile_mode != w {
            game.toggle_missile_mode(pos)?;
            switched = true;
        }
    }
    Ok(switched)
}

/// 对仍带主动防御的高价值目标组织同时攻击齐射；返回已参与的单位标签。
fn try_volley(game: &mut GameState, team: Team, log: &mut Vec<String>) -> HashSet<char> {
    let mut done = HashSet::new();
    let vis = game.vision(team).enemy_units;
    let target = game
        .enemies_of(team)
        .into_iter()
        .find(|e| {
            matches!(e.kind, UnitKind::HeavyTank | UnitKind::CavalryIfv)
                && e.ad_uses > 0
                && vis.contains(&e.pos)
        })
        .cloned();
    let Some(target) = target else {
        return done;
    };
    let mut orders: Vec<SimulOrder> = Vec::new();
    for u in game.units_of(team) {
        if !u.kind.can_attack() || u.actions_left < u.kind.attack_cost() || u.ammo_shown() <= 0 {
            continue;
        }
        if !u.can_target_unit(target.kind) {
            continue;
        }
        let is_area = u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar;
        if !is_area && u.eff_attack() < target.kind.armor() {
            continue;
        }
        let order = SimulOrder {
            attacker: u.pos,
            target: target.pos,
            air_first: u.kind.is_air(),
            aa_mode: u.aa_mode,
            missile_mode: u.missile_mode,
        };
        if game.validate_simul_order(order).is_ok() {
            orders.push(order);
        }
    }
    if orders.len() < 2 {
        return done;
    }
    match game.simultaneous_attack(&orders) {
        Ok(outcomes) => {
            for o in outcomes {
                log.push(format!("[AI] {}", o.message));
            }
            for o in &orders {
                if let Some(u) = game.unit_at(o.attacker) {
                    done.insert(u.label);
                }
            }
        }
        Err(e) => log.push(format!("[AI] 同时攻击失败: {}", e)),
    }
    done
}


// ===================== Determinized 搜索（Phase 4） =====================

/// 把一个未观测敌军按信念采样重定位，得到一个"确定化"盘面。
/// 用于 root-sampling：在每个一致的敌方布置上分别规划，再取期望最优。
fn determinize(
    state: &mut GameState,
    team: Team,
    belief: &super::belief::Belief,
    visible: &BTreeSet<Hex>,
    rng: &mut impl rand::Rng,
) {
    let hidden: Vec<(Hex, Unit)> = state
        .enemies_of(team)
        .iter()
        .filter(|e| !visible.contains(&e.pos))
        .map(|e| (e.pos, (*e).clone()))
        .collect();
    for (old, mut u) in hidden {
        let mut new = None;
        for _ in 0..24 {
            let Some(h) = belief.sample(rng) else {
                break;
            };
            if h == old {
                continue;
            }
            if !state.map.contains(h) || state.map.obstacles.contains(&h) {
                continue;
            }
            if state.unit_at(h).is_some() {
                continue;
            }
            if !u.kind.is_air() && state.map.water.contains(&h) {
                continue;
            }
            if !u.kind.is_foot() && state.map.buildings.contains(&h) {
                continue;
            }
            new = Some(h);
            break;
        }
        let Some(new) = new else {
            continue;
        };
        if state.units.contains_key(&old) {
            state.units.remove(&old);
        } else {
            state.air_units.remove(&old);
        }
        u.pos = new;
        if u.kind.is_air() {
            state.air_units.insert(new, u);
        } else {
            state.units.insert(new, u);
        }
    }
}

/// Determinized 束搜索：从信念采样 S 个一致的敌方布置，各自束搜索，
/// 再用所有样本上的平均盘面分挑出最稳健的计划。仅老兵/精英启用。
fn try_determinized(
    game: &GameState,
    team: Team,
    base: &PerceivedWorld,
    order: &[char],
    objective: Option<Hex>,
) -> Option<Vec<(char, PlanAction)>> {
    use std::time::{Duration, Instant};
    let (samples, k, b, total_ms) = match game.ai_difficulty {
        AiDifficulty::Veteran => (2usize, 3usize, 6usize, 150u64),
        AiDifficulty::Elite => (3usize, 4usize, 8usize, 250u64),
        _ => return None,
    };
    if base.belief.is_empty() {
        return None; // 没有不确定敌人：普通束搜索即可
    }
    let start = Instant::now();
    let mut rng = game.rng.clone();
    let mut sample_states: Vec<GameState> = Vec::new();
    let mut plans: Vec<Vec<(char, PlanAction)>> = Vec::new();
    for _ in 0..samples {
        if start.elapsed() > Duration::from_millis(total_ms) {
            break;
        }
        let mut s = game.clone();
        strip_transient(&mut s);
        determinize(&mut s, team, &base.belief, &base.visible_enemy_hexes, &mut rng);
        // 在确定化假设下，视为已侦察到全部敌军，允许搜索并攻击它们
        let mut w = search_world(base, &s);
        for e in s.enemies_of(team) {
            w.visible_enemy_hexes.insert(e.pos);
        }
        w.refresh_enemies(&s);
        if let Some(plan) = beam_search(
            &s,
            team,
            &w,
            order,
            objective,
            k,
            b,
            Duration::from_millis(50),
        ) {
            sample_states.push(s);
            plans.push(plan);
        }
    }
    if plans.is_empty() {
        return None;
    }
    // 每个候选计划在所有样本上推演，取平均盘面分
    let mut best: Option<(f64, Vec<(char, PlanAction)>)> = None;
    for plan in &plans {
        let mut total = 0.0;
        let mut n = 0usize;
        for st in &sample_states {
            let mut c = st.clone();
            let mut sink = Vec::new();
            execute_plan(&mut c, team, plan, &mut sink);
            strip_transient(&mut c);
            total += eval::score_state(&c, team, objective);
            n += 1;
        }
        if n > 0 {
            let avg = total / n as f64;
            if best.as_ref().map_or(true, |(bs, _)| avg > *bs) {
                best = Some((avg, plan.clone()));
            }
        }
    }
    best.map(|(_, p)| p)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn clear(g: &mut GameState, h: Hex) {
        g.map.obstacles.remove(&h);
        g.map.buildings.remove(&h);
        g.map.forests.remove(&h);
        g.map.water.remove(&h);
    }

    /// 干净空盘（清掉 new_seeded 预置的部队，避免标签冲突）。
    fn empty(seed: u64) -> GameState {
        let mut g = GameState::new_seeded(seed);
        g.units.clear();
        g.air_units.clear();
        g.deploying = false;
        g.winner = None;
        g
    }

    /// 候选行动里应同时包含"打相邻敌人"和"原地待命"。
    #[test]
    fn rank_actions_includes_fire_and_hold() {
        let mut g = empty(31);
        let h1 = hex::axial_from_offset(10, 6);
        let h2 = hex::axial_from_offset(11, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        let a = Unit::new(UnitKind::Rifleman, Team::Ai, h1);
        g.units.insert(h1, a.clone());
        g.units
            .insert(h2, Unit::new(UnitKind::Atgm, Team::Player, h2));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        let ranked = rank_actions(&g, Team::Ai, &world, &op, &a, 8);
        assert!(ranked
            .iter()
            .any(|(act, _)| matches!(act, PlanAction::Fire(p) if *p == h2)));
        assert!(ranked.iter().any(|(act, _)| matches!(act, PlanAction::Hold)));
    }

    /// 坦克对机枪射程内的软目标（护甲 < 2）切换车载重机枪；主炮射程内有装甲目标时保留坦克炮。
    #[test]
    fn tank_switches_to_mg_for_soft_targets() {
        // 只有软目标（步兵，距离 3）→ 切机枪
        let mut g = empty(41);
        let tank_h = hex::axial_from_offset(10, 6);
        let inf_h = hex::axial_from_offset(13, 6);
        clear(&mut g, tank_h);
        clear(&mut g, inf_h);
        let mut tank = Unit::new(UnitKind::Tank, Team::Ai, tank_h);
        tank.label = 'A';
        g.units.insert(tank_h, tank);
        let mut world = PerceivedWorld::build(&g, Team::Ai);
        world.visible_enemies = vec![Unit::new(UnitKind::Rifleman, Team::Player, inf_h)];
        assert!(auto_switch_weapons(&mut g, tank_h, &world).unwrap());
        assert!(
            g.unit_at(tank_h).unwrap().missile_mode,
            "软目标在机枪射程内应切机枪"
        );

        // 软目标在机枪射程内，但主炮射程内另有装甲目标 → 保留坦克炮
        let mut g2 = empty(43);
        let tank2 = hex::axial_from_offset(10, 6);
        let inf2 = hex::axial_from_offset(13, 6);
        let foe_tank = hex::axial_from_offset(15, 6); // 距离 5：主炮射程 6 内
        for h in [tank2, inf2, foe_tank] {
            clear(&mut g2, h);
        }
        let mut tk2 = Unit::new(UnitKind::Tank, Team::Ai, tank2);
        tk2.label = 'A';
        g2.units.insert(tank2, tk2);
        let mut world2 = PerceivedWorld::build(&g2, Team::Ai);
        world2.visible_enemies = vec![
            Unit::new(UnitKind::Rifleman, Team::Player, inf2),
            Unit::new(UnitKind::Tank, Team::Player, foe_tank),
        ];
        assert!(!auto_switch_weapons(&mut g2, tank2, &world2).unwrap());
        assert!(
            !g2.unit_at(tank2).unwrap().missile_mode,
            "主炮射程内有装甲目标应保留坦克炮"
        );
    }

    /// 推演执行移动后单位应落到目标格。
    #[test]
    fn apply_move_changes_position() {
        let mut g = empty(33);
        let h1 = hex::axial_from_offset(10, 6);
        let h2 = hex::axial_from_offset(11, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        let mut tank = Unit::new(UnitKind::Tank, Team::Ai, h1);
        tank.label = 'A';
        g.units.insert(h1, tank);
        let out = apply_plan_action(&mut g, 'A', PlanAction::Move(h2));
        assert!(out.is_ok(), "{:?}", out);
        assert!(g.unit_at(h2).is_some());
        assert!(g.unit_at(h1).is_none());
    }

    /// 敌方残血应提高己方盘面评分。
    #[test]
    fn score_state_prefers_damaged_enemy() {
        let mut g = empty(35);
        let h1 = hex::axial_from_offset(10, 6);
        let h2 = hex::axial_from_offset(12, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        g.units.insert(h1, Unit::new(UnitKind::Tank, Team::Ai, h1));
        let mut enemy = Unit::new(UnitKind::Tank, Team::Player, h2);
        g.units.insert(h2, enemy.clone());
        let full = eval::score_state(&g, Team::Ai, None);
        enemy.hp = 1;
        g.units.insert(h2, enemy);
        let hurt = eval::score_state(&g, Team::Ai, None);
        assert!(hurt > full, "敌方残血应提高己方评分: {} vs {}", hurt, full);
    }

    /// 小场景束搜索应返回非空计划。
    #[test]
    fn beam_search_returns_plan() {
        let mut g = empty(37);
        let h1 = hex::axial_from_offset(10, 6);
        let h2 = hex::axial_from_offset(11, 6);
        clear(&mut g, h1);
        clear(&mut g, h2);
        let mut a = Unit::new(UnitKind::Rifleman, Team::Ai, h1);
        a.label = 'A';
        g.units.insert(h1, a);
        g.units
            .insert(h2, Unit::new(UnitKind::Atgm, Team::Player, h2));
        let base = PerceivedWorld::build(&g, Team::Ai);
        let plan = beam_search(
            &g,
            Team::Ai,
            &base,
            &['A'],
            None,
            4,
            6,
            std::time::Duration::from_secs(10),
        );
        assert!(plan.is_some(), "小场景束搜索应返回计划");
        assert!(!plan.unwrap().is_empty());
    }

    /// 束搜索应能推进到多个单位（验证 done-set 不会卡在第一个单位）。
    #[test]
    fn beam_plans_multiple_units() {
        let mut g = empty(41);
        let a = hex::axial_from_offset(10, 6);
        let e1 = hex::axial_from_offset(11, 6);
        let b = hex::axial_from_offset(10, 9);
        let e2 = hex::axial_from_offset(11, 9);
        for h in [a, e1, b, e2] {
            clear(&mut g, h);
        }
        let mut ua = Unit::new(UnitKind::Rifleman, Team::Ai, a);
        ua.label = 'A';
        let mut ub = Unit::new(UnitKind::Rifleman, Team::Ai, b);
        ub.label = 'B';
        g.units.insert(a, ua);
        g.units.insert(b, ub);
        g.units.insert(e1, Unit::new(UnitKind::Atgm, Team::Player, e1));
        g.units.insert(e2, Unit::new(UnitKind::Atgm, Team::Player, e2));
        let base = PerceivedWorld::build(&g, Team::Ai);
        let plan = beam_search(
            &g,
            Team::Ai,
            &base,
            &['A', 'B'],
            None,
            4,
            6,
            std::time::Duration::from_secs(10),
        )
        .expect("应返回计划");
        let labels: std::collections::HashSet<char> = plan.iter().map(|(l, _)| *l).collect();
        assert!(labels.contains(&'A') && labels.contains(&'B'), "计划应覆盖两个单位: {:?}", plan);
    }

    /// 幽灵应产生非空的概率信念，且热点可被侦察使用。
    #[test]
    fn belief_from_ghost() {
        let mut g = empty(51);
        let h = hex::axial_from_offset(15, 6);
        clear(&mut g, h);
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(h, (UnitKind::Tank, g.turn));
        let world = PerceivedWorld::build(&g, Team::Ai);
        assert!(!world.belief.is_empty(), "有幽灵时信念不应为空");
        assert!(world.belief.prob(h) > 0.0);
        assert!(!world.belief.hotspots(3).is_empty());
    }

    /// 确定化重定位不应改变敌军数量。
    #[test]
    fn determinize_preserves_enemy_count() {
        use rand::SeedableRng;
        let mut g = empty(53);
        let h_ai = hex::axial_from_offset(5, 6);
        let h_enemy = hex::axial_from_offset(20, 6);
        let ghost = hex::axial_from_offset(18, 4);
        for h in [h_ai, h_enemy, ghost] {
            clear(&mut g, h);
        }
        g.units.insert(h_ai, Unit::new(UnitKind::Scout, Team::Ai, h_ai));
        g.units
            .insert(h_enemy, Unit::new(UnitKind::Tank, Team::Player, h_enemy));
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(ghost, (UnitKind::Tank, g.turn));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let before = g.enemies_of(Team::Ai).len();
        let mut s = g.clone();
        strip_transient(&mut s);
        let mut rng = rand::rngs::StdRng::seed_from_u64(7);
        determinize(
            &mut s,
            Team::Ai,
            &world.belief,
            &world.visible_enemy_hexes,
            &mut rng,
        );
        assert_eq!(s.enemies_of(Team::Ai).len(), before);
    }

    /// 场景门禁：侦察单位在无敌人时应向作战目标推进（而不是原地待命）。
    #[test]
    fn scenario_recon_advances() {
        let mut g = empty(61);
        let h = hex::axial_from_offset(3, 6);
        clear(&mut g, h);
        let mut scout = Unit::new(UnitKind::Scout, Team::Ai, h);
        scout.label = 'A';
        g.units.insert(h, scout.clone());
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        let ranked = rank_actions(&g, Team::Ai, &world, &op, &scout, 8);
        assert!(
            matches!(ranked[0].0, PlanAction::Move(_)),
            "侦察无敌人时应向目标推进: {:?}",
            ranked
        );
    }

    /// 场景门禁：同等条件下森林掩体的位置分应高于空地。
    #[test]
    fn scenario_prefers_cover() {
        let mut g = empty(63);
        let h = hex::axial_from_offset(10, 6);
        let cov = hex::axial_from_offset(11, 6);
        let open = hex::axial_from_offset(10, 5);
        for x in [h, cov, open] {
            clear(&mut g, x);
        }
        g.map.forests.insert(cov);
        let u = Unit::new(UnitKind::Rifleman, Team::Ai, h);
        g.units.insert(h, u.clone());
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        let w = Weights::for_difficulty(AiDifficulty::Regular);
        let s_cov = position_score(&g, &world, &op, &u, h, cov, &w);
        let s_open = position_score(&g, &world, &op, &u, h, open, &w);
        assert!(
            s_cov > s_open,
            "森林掩体应优于空地: {} vs {}",
            s_cov,
            s_open
        );
    }

    /// 场景门禁：已进入射程后不应继续逼近队伍中心，且应优先开火。
    #[test]
    fn scenario_holds_fire_position_when_engaged() {
        let mut g = empty(101);
        let u_pos = hex::axial_from_offset(10, 6);
        let e_pos = hex::axial_from_offset(15, 6);
        let closer = hex::axial_from_offset(11, 6);
        for h in [u_pos, e_pos, closer] {
            clear(&mut g, h);
        }
        let mut tank = Unit::new(UnitKind::Tank, Team::Ai, u_pos);
        tank.label = 'A';
        g.units.insert(u_pos, tank.clone());
        // 目标用车辆（隐蔽 1），确保坦克视野 5 能发现 5 格外的它
        g.units
            .insert(e_pos, Unit::new(UnitKind::Tank, Team::Player, e_pos));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        let w = Weights::for_difficulty(AiDifficulty::Regular);
        assert!(engaged(&g, &world, &tank, u_pos), "坦克射程 6、距离 5 应已可交火");
        let hold = position_score(&g, &world, &op, &tank, u_pos, u_pos, &w);
        let closer_score = position_score(&g, &world, &op, &tank, u_pos, closer, &w);
        assert!(
            closer_score <= hold + 1e-6,
            "已进入射程不应继续逼近: hold={} closer={}",
            hold,
            closer_score
        );
        let ranked = rank_actions(&g, Team::Ai, &world, &op, &tank, 8);
        let enemy = world.visible_enemies.first().cloned().expect("应可见敌人");
        // 首选动作必须是"开火"或"移动到仍可开火的掩体位"，而不是空追中心
        let top_can_shoot = match ranked[0].0 {
            PlanAction::Fire(_) => true,
            PlanAction::Move(dest) => {
                let mut m = tank.clone();
                m.pos = dest;
                can_shoot_from(&g, &world, &m, dest, &enemy)
            }
            _ => false,
        };
        assert!(
            top_can_shoot,
            "应开火或移动到可开火位置，而非空追目标中心: {:?}",
            ranked
        );
    }

    /// 场景门禁：未进入射程时应朝目标推进。
    #[test]
    fn scenario_advances_when_out_of_range() {
        let mut g = empty(103);
        let u_pos = hex::axial_from_offset(8, 6);
        let e_pos = hex::axial_from_offset(20, 6);
        let closer = hex::axial_from_offset(10, 6);
        for h in [u_pos, e_pos, closer] {
            clear(&mut g, h);
        }
        let mut tank = Unit::new(UnitKind::Tank, Team::Ai, u_pos);
        tank.label = 'A';
        g.units.insert(u_pos, tank.clone());
        // 用幽灵表示远处目标（保证有 objective，但不处于交火）
        g.ghosts
            .entry(Team::Ai)
            .or_default()
            .insert(e_pos, (UnitKind::Rifleman, g.turn));
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        let w = Weights::for_difficulty(AiDifficulty::Regular);
        assert!(!engaged(&g, &world, &tank, u_pos));
        let hold = position_score(&g, &world, &op, &tank, u_pos, u_pos, &w);
        let closer_score = position_score(&g, &world, &op, &tank, u_pos, closer, &w);
        assert!(
            closer_score > hold,
            "未交火时应朝目标推进: hold={} closer={}",
            hold,
            closer_score
        );
    }

    fn base_game(seed: u64) -> GameState {
        let mut g = GameState::new_sustain_multiplayer(seed, crate::game::Level::OpenField);
        g.start_sustain_multiplayer(10, 10, 100, 100);
        g.units.clear();
        g.air_units.clear();
        g
    }

    /// 空载运输单位应返回大本营。
    #[test]
    fn transport_returns_to_base_when_empty() {
        let mut g = base_game(111);
        let hq = g.hq_pos(Team::Ai).unwrap();
        let (hc, hr) = hex::offset_from_axial(hq);
        let t = hex::axial_from_offset(hc - 5, hr);
        clear(&mut g, t);
        let mut truck = Unit::new(UnitKind::Truck, Team::Ai, t);
        truck.label = 'T';
        g.units.insert(t, truck.clone());
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        match transport_plan(&g, &world, &op, &truck) {
            Some(PlanAction::Move(dest)) => {
                assert!(
                    Hex::distance(dest, hq) < Hex::distance(t, hq),
                    "空载运输应朝大本营移动: {:?} -> {:?}",
                    t,
                    dest
                );
            }
            other => panic!("空载运输应返回大本营: {:?}", other),
        }
    }

    /// 载员接近前线时应在安全位置卸载（与敌人保持距离）。
    #[test]
    fn transport_unloads_at_safe_position() {
        let mut g = base_game(113);
        let t = hex::axial_from_offset(10, 6);
        let e = hex::axial_from_offset(15, 6); // 距卡车 5 格（<= 安全线 6）
        let observer = hex::axial_from_offset(10, 5);
        let friend = hex::axial_from_offset(11, 6);
        for h in [t, e, observer, friend] {
            clear(&mut g, h);
        }
        let mut truck = Unit::new(UnitKind::Truck, Team::Ai, t);
        truck.label = 'T';
        truck.passengers.push(Unit::new(UnitKind::Rifleman, Team::Ai, t));
        g.units.insert(t, truck.clone());
        g.units
            .insert(e, Unit::new(UnitKind::Tank, Team::Player, e));
        let mut obs = Unit::new(UnitKind::Drone, Team::Ai, observer);
        obs.label = 'D';
        g.units.insert(observer, obs);
        let mut fr = Unit::new(UnitKind::Rifleman, Team::Ai, friend);
        fr.label = 'F';
        g.units.insert(friend, fr);
        let world = PerceivedWorld::build(&g, Team::Ai);
        let op = operational::build(&g, &world, Team::Ai);
        match transport_plan(&g, &world, &op, &truck) {
            Some(PlanAction::Unload { dest, .. }) => {
                let d = dest.expect("地面载具应有落点");
                assert!(
                    nearest_enemy_dist(&world, d) >= TRANSPORT_UNLOAD_MIN,
                    "卸载点应与敌人保持安全距离: {:?} (dist={})",
                    d,
                    nearest_enemy_dist(&world, d)
                );
            }
            other => panic!("载员到前线应卸载: {:?}", other),
        }
    }
}
