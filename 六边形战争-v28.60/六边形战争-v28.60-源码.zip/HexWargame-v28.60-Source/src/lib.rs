//! 六边形战争：游戏核心逻辑库。
//!
//! 界面（GUI / 终端）与规则引擎分离，多个可执行文件共用此库：
//! - `hex_wargame`            ：GUI 版（egui/eframe）
//! - `hex_wargame_multiplayer`：多人热座 / GUI + 终端混合 / 终端观战
//! - `hex_wargame_tui`        ：终端版
//! - `hex_wargame_editor`     ：地图编辑器
//! - `hex_wargame_piece_drawer`：棋子笔画绘制工具
//! - `hex_wargame_piece_export`：棋子美术导出 / 参考图比对工具

pub mod ai;
pub mod ai_arena;
pub mod ai_router;
pub mod ai_v2;
pub mod game;
pub mod hex;
pub mod map;
pub mod mapdef;
/// 棋子美术：实现位于项目根 `assets/` 目录（见 pieces.rs 与 assets/README.md）。
pub mod pieces;
pub mod unit;
