//! 多人热座模式的命令行解析、TCP 同步、终端客户端与终端命令解释器。
//!
//! 本模块只在 `hex_wargame_multiplayer` 可执行文件里被真正使用；为了让
//! `hex_wargame` 仍保持原有行为，`main.rs` 里用运行期二进制名判断进入哪套流程。
//! GUI 进程始终是唯一的 `GameState` 所有者，终端客户端只通过 TCP 发送命令、
//! 接收各自阵营的文本快照；因此 GUI 可以实时显示终端玩家的操作，也可以在
//! 两名玩家都使用终端时变为纯观战窗口。

#![allow(dead_code)]

use hex_wargame::game::{BattleEventKind, GameState, Level};
use hex_wargame::hex::{self, Hex};
use hex_wargame::unit::{Team, Unit, UnitKind};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeSet, HashMap};
use std::io::{BufRead, BufReader, Write};
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::sync::mpsc::{self, Sender};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

/// GUI 本地控制哪些阵营。终端客户端连接后会从本地控制集合中“接管”对应阵营。
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum LocalControl {
    Both,
    Blue,
    Red,
    Spectator,
}

impl LocalControl {
    pub fn from_teams(teams: &BTreeSet<Team>) -> Self {
        let blue = teams.contains(&Team::Player);
        let red = teams.contains(&Team::Ai);
        match (blue, red) {
            (true, true) => LocalControl::Both,
            (true, false) => LocalControl::Blue,
            (false, true) => LocalControl::Red,
            (false, false) => LocalControl::Spectator,
        }
    }

    pub fn teams(self) -> BTreeSet<Team> {
        match self {
            LocalControl::Both => [Team::Player, Team::Ai].into_iter().collect(),
            LocalControl::Blue => [Team::Player].into_iter().collect(),
            LocalControl::Red => [Team::Ai].into_iter().collect(),
            LocalControl::Spectator => BTreeSet::new(),
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            LocalControl::Both => "本地双人",
            LocalControl::Blue => "本地蓝方",
            LocalControl::Red => "本地红方",
            LocalControl::Spectator => "观战",
        }
    }
}

/// 多人模式的可持续部署设置（`--sustain`）。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SustainConfig {
    /// 蓝方每回合获得的部署点数。
    pub player_per_turn: i32,
    /// 红方每回合获得的部署点数。
    pub ai_per_turn: i32,
    /// 双方初始部署点数；None 表示沿用关卡初始点数（开阔地 100/100）。
    pub player_points: Option<i32>,
    pub ai_points: Option<i32>,
}

impl Default for SustainConfig {
    fn default() -> Self {
        Self {
            player_per_turn: 10,
            // 多人是人对人/agent 对 agent：默认双方对称（单人模式的 10/20 可显式指定）
            ai_per_turn: 10,
            player_points: None,
            ai_points: None,
        }
    }
}

/// 图形界面主机渲染哪种视野。
///
/// `Spectator` 是历史行为：多人模式每帧全视野，方便人类在 GUI 里实时看到
/// 双方操作（也会把双方终端玩家的私有命令回显进共享日志）。
/// `Acting` 则让窗口只渲染**当前行动方**的迷雾视野——同一时刻只有一方行动，
/// 因此窗口内容始终等于该方自己的视角；这也是 agent 截图能安全抓取该窗口的
/// 前提（窗口标题会声明「X方视角」，截图工具据此判定能否抓取）。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ViewMode {
    Spectator,
    Acting,
}

#[derive(Clone, Debug)]
pub struct GuiConfig {
    pub seed: u64,
    pub level: Level,
    pub listen_addr: Option<String>,
    pub initial_control: LocalControl,
    /// 图形界面主机的视野模式（`--view`，默认观战全视野）。
    pub view: ViewMode,
    /// 观战状态文件路径（`--state-file` 或环境变量 `HEX_WARGAME_STATE_FILE`）。
    /// 每当局势变化就原子写出一次完整快照，供外部监督进程（如控制 pipeline）
    /// 在不开第二个终端连接的情况下读取权威状态。
    pub state_file: Option<String>,
    /// `Some` = 多人对局启用可持续部署（每回合获得点数、可在大本营追加部署）。
    pub sustain: Option<SustainConfig>,
}

#[derive(Clone, Debug)]
pub struct TuiConfig {
    pub connect_addr: String,
    pub requested_team: Option<Team>,
}

pub enum CliAction {
    RunGui(GuiConfig),
    RunTui(TuiConfig),
    Help(String),
    Error(String),
}

pub fn help_text() -> String {
    r#"六边形战争 · 多人热座模式

用法:
  hex_wargame_multiplayer [--gui] [选项]        启动图形界面主机
  hex_wargame_multiplayer --tui [--connect 地址] 启动终端客户端

图形界面主机选项:
  --listen <地址>       监听终端玩家（默认 127.0.0.1:45123）
  --no-listen           不启动终端监听
  --local-team <模式>   both | blue | red | spectator（默认 both）
  --view <模式>         spectator | acting（默认 spectator）
                        spectator：多人模式全视野观战窗口（历史行为）
                        acting：窗口只渲染当前行动方的迷雾视野，标题显示「X方视角」
  --seed <数字>         指定随机种子
  --level <关卡>        open | village（默认 open）
  --state-file <路径>   每当局势变化写出一份完整观战快照（JSON，含双方全视野）
  --sustain             持续部署（默认开启）：空地图开局，双方单位全部自行招募；
                        第 1 回合可在本方出发区域招募，第 2 回合起只能在大本营周围 2 格内；
                        每回合获得部署点数，同时控制全部 6 个关键据点者获胜
  --sustain-pp <数字>   蓝方每回合部署点数（默认 10；隐含 --sustain）
  --sustain-ap <数字>   红方每回合部署点数（默认 10；隐含 --sustain）
  --sustain-points <n>  双方初始部署点数（默认沿用关卡初始点数，开阔地 100/100）
  --no-sustain          关闭持续部署：预置部队经典快速开局（全歼获胜，无招募）
  --help                显示帮助

终端客户端选项:
  --connect <地址>      连接到图形界面主机（默认 127.0.0.1:45123）
  --team <阵营>         blue | red | auto（默认 auto，由主机分配）

说明:
  - 默认图形界面为主机，本地可同时操作蓝、红双方（热座）。
  - 终端客户端连接后，会从本地控制中接管一个阵营：一人 GUI + 一人 TUI，
    或两名玩家都用 TUI 时，GUI 自动变为观战窗口。
  - 图形界面主机在多人模式下使用完整视野，以便实时播放终端玩家的操作效果。
    `--view acting` 时改为只显示当前行动方的视野（供 agent 截屏使用：
    任何时刻窗口内容都等于行动方自己的视角），并隐藏对方玩家的私有命令回显。
"#
    .to_string()
}

pub fn parse_args<I: IntoIterator<Item = String>>(args: I) -> CliAction {
    let mut args = args.into_iter().peekable();
    let mut gui = false;
    let mut tui = false;
    let mut listen: Option<String> = Some("127.0.0.1:45123".to_string());
    let mut connect: Option<String> = None;
    let mut local_team = LocalControl::Both;
    let mut view = ViewMode::Spectator;
    let mut requested_team: Option<Team> = None;
    let mut seed: u64 = rand::random();
    let mut level = Level::OpenField;
    let mut state_file: Option<String> = std::env::var("HEX_WARGAME_STATE_FILE").ok();
    // 多人默认持续部署（空地图开局：双方全部单位自行招募 + 每回合点数 + 大本营），
    // `--no-sustain` 回退到旧的预置部队经典快速开局。
    let mut sustain: Option<SustainConfig> = Some(SustainConfig::default());

    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--gui" => gui = true,
            "--tui" => tui = true,
            "--listen" => {
                if let Some(v) = args.next() {
                    listen = Some(v);
                } else {
                    return CliAction::Error("--listen 需要一个地址".into());
                }
            }
            "--no-listen" => listen = None,
            "--connect" => {
                if let Some(v) = args.next() {
                    connect = Some(v);
                    tui = true;
                } else {
                    return CliAction::Error("--connect 需要一个地址".into());
                }
            }
            "--local-team" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--local-team 需要一个模式".into());
                };
                local_team = match v.as_str() {
                    "both" | "双人" => LocalControl::Both,
                    "blue" | "player" | "蓝" => LocalControl::Blue,
                    "red" | "ai" | "红" => LocalControl::Red,
                    "spectator" | "watch" | "观战" => LocalControl::Spectator,
                    _ => return CliAction::Error(format!("未知 --local-team 模式: {}", v)),
                };
            }
            "--view" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--view 需要一个模式".into());
                };
                view = match v.as_str() {
                    "spectator" | "watch" | "观战" => ViewMode::Spectator,
                    "acting" | "fog" | "player" | "行动方" | "单方" => ViewMode::Acting,
                    _ => return CliAction::Error(format!("未知 --view 模式: {}", v)),
                };
            }
            "--team" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--team 需要一个阵营".into());
                };
                requested_team = match v.as_str() {
                    "blue" | "player" | "蓝" => Some(Team::Player),
                    "red" | "ai" | "红" => Some(Team::Ai),
                    "auto" | "自动" => None,
                    _ => return CliAction::Error(format!("未知 --team 阵营: {}", v)),
                };
            }
            "--seed" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--seed 需要一个数字".into());
                };
                match v.parse::<u64>() {
                    Ok(n) => seed = n,
                    Err(_) => return CliAction::Error(format!("无效种子: {}", v)),
                }
            }
            "--level" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--level 需要一个关卡名".into());
                };
                level = match v.as_str() {
                    "open" | "openfield" | "开阔地" => Level::OpenField,
                    "village" | "village_defense" | "村庄" => Level::VillageDefense,
                    _ => return CliAction::Error(format!("未知关卡: {}", v)),
                };
            }
            "--state-file" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--state-file 需要一个路径".into());
                };
                state_file = Some(v);
            }
            "--sustain" => {
                sustain.get_or_insert_with(SustainConfig::default);
            }
            "--no-sustain" | "--classic" => {
                sustain = None;
            }
            "--sustain-pp" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--sustain-pp 需要一个数字".into());
                };
                match v.parse::<i32>() {
                    Ok(n) => sustain.get_or_insert_with(SustainConfig::default).player_per_turn = n.max(0),
                    Err(_) => return CliAction::Error(format!("无效点数: {}", v)),
                }
            }
            "--sustain-ap" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--sustain-ap 需要一个数字".into());
                };
                match v.parse::<i32>() {
                    Ok(n) => sustain.get_or_insert_with(SustainConfig::default).ai_per_turn = n.max(0),
                    Err(_) => return CliAction::Error(format!("无效点数: {}", v)),
                }
            }
            "--sustain-points" => {
                let Some(v) = args.next() else {
                    return CliAction::Error("--sustain-points 需要一个数字".into());
                };
                match v.parse::<i32>() {
                    Ok(n) => {
                        let cfg = sustain.get_or_insert_with(SustainConfig::default);
                        cfg.player_points = Some(n.max(0));
                        cfg.ai_points = Some(n.max(0));
                    }
                    Err(_) => return CliAction::Error(format!("无效点数: {}", v)),
                }
            }
            "-h" | "--help" => return CliAction::Help(help_text()),
            _ => return CliAction::Error(format!("未知参数: {}（使用 --help 查看帮助）", arg)),
        }
    }

    if tui {
        CliAction::RunTui(TuiConfig {
            connect_addr: connect.unwrap_or_else(|| "127.0.0.1:45123".to_string()),
            requested_team,
        })
    } else {
        let _ = gui; // --gui 是默认行为，保留给显式写法
        CliAction::RunGui(GuiConfig {
            seed,
            level,
            listen_addr: listen,
            initial_control: local_team,
            view,
            state_file,
            sustain,
        })
    }
}

// ---------------------------------------------------------------------------
// 网络协议
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum ClientMessage {
    Hello { team: Option<Team> },
    Command { line: String },
    Quit,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum ServerMessage {
    Welcome { team: Team, message: String },
    State(String),
    Message(String),
    Error(String),
    Bye(String),
}

#[derive(Clone, Debug)]
pub enum HubEvent {
    ControlChanged { gui_teams: BTreeSet<Team> },
    ClientJoined { id: u64, team: Team, addr: String },
    ClientLeft { id: u64, team: Team },
    ServerError(String),
}

struct ClientConn {
    id: u64,
    team: Team,
    tx: Sender<ServerMessage>,
    addr: SocketAddr,
    /// 该阵营是否从 GUI 本地控制中“接管”而来；断开时需归还给 GUI。
    from_gui: bool,
}

/// 由 GUI 主线程与网络线程共同访问的连接状态。
pub struct NetHub {
    clients: HashMap<u64, ClientConn>,
    /// 仍由 GUI 本地控制的阵营；客户端连接会逐个取走。
    pub gui_teams: BTreeSet<Team>,
    /// 初始模式是否为“本地双人”：为 true 时客户端可以接管 GUI 当前控制的阵营；
    /// 为 false 时 GUI 明确保留自己那一方（或完全观战），客户端只能拿空闲阵营。
    gui_willing_both: bool,
    incoming: Vec<(u64, String)>,
    events: Vec<HubEvent>,
    next_id: u64,
    repaint: Option<eframe::egui::Context>,
    pub addr: String,
}

impl NetHub {
    pub fn take_incoming(&mut self) -> Vec<(u64, String)> {
        std::mem::take(&mut self.incoming)
    }

    pub fn take_events(&mut self) -> Vec<HubEvent> {
        std::mem::take(&mut self.events)
    }

    pub fn client_ids(&self) -> Vec<(u64, Team)> {
        self.clients.values().map(|c| (c.id, c.team)).collect()
    }

    pub fn client_team(&self, id: u64) -> Option<Team> {
        self.clients.get(&id).map(|c| c.team)
    }

    pub fn send_to(&self, id: u64, msg: ServerMessage) {
        if let Some(c) = self.clients.get(&id) {
            let _ = c.tx.send(msg);
        }
    }

    pub fn broadcast(&self, msg: &ServerMessage) {
        for c in self.clients.values() {
            let _ = c.tx.send(msg.clone());
        }
    }

    pub fn remove_client(&mut self, id: u64, reason: &str) {
        if let Some(c) = self.clients.remove(&id) {
            let _ = c.tx.send(ServerMessage::Bye(reason.to_string()));
            if c.from_gui {
                if self.gui_teams.insert(c.team) {
                    self.events.push(HubEvent::ControlChanged {
                        gui_teams: self.gui_teams.clone(),
                    });
                }
            }
            self.events.push(HubEvent::ClientLeft {
                id,
                team: c.team,
            });
        }
    }

    fn notify_repaint(&self) {
        if let Some(ctx) = &self.repaint {
            ctx.request_repaint();
        }
    }

    fn team_assignable(&self, team: Team) -> bool {
        if self.clients.values().any(|c| c.team == team) {
            return false;
        }
        if self.gui_willing_both {
            true
        } else {
            !self.gui_teams.contains(&team)
        }
    }

    /// 分配阵营，返回 (阵营, 是否从 GUI 控制中接管)。
    fn assign_team(&mut self, requested: Option<Team>) -> Option<(Team, bool)> {
        let preferred = [Team::Ai, Team::Player];
        let chosen = match requested {
            Some(t) if self.team_assignable(t) => Some(t),
            Some(_) => None,
            None => preferred.into_iter().find(|&t| self.team_assignable(t)),
        }?;
        let from_gui = self.gui_teams.remove(&chosen);
        if from_gui {
            self.events.push(HubEvent::ControlChanged {
                gui_teams: self.gui_teams.clone(),
            });
        }
        Some((chosen, from_gui))
    }
}

pub fn start_server(
    addr: &str,
    initial_gui_teams: BTreeSet<Team>,
    repaint: Option<eframe::egui::Context>,
) -> Result<Arc<Mutex<NetHub>>, String> {
    let listener = TcpListener::bind(addr).map_err(|e| format!("监听 {} 失败: {}", addr, e))?;
    let actual = listener.local_addr().map_err(|e| e.to_string())?;
    let gui_willing_both = initial_gui_teams.len() >= 2;
    let hub = Arc::new(Mutex::new(NetHub {
        clients: HashMap::new(),
        gui_teams: initial_gui_teams,
        gui_willing_both,
        incoming: Vec::new(),
        events: Vec::new(),
        next_id: 1,
        repaint,
        addr: actual.to_string(),
    }));
    let hub2 = Arc::clone(&hub);
    thread::Builder::new()
        .name("hex-mp-listener".into())
        .spawn(move || accept_loop(listener, hub2))
        .map_err(|e| format!("无法启动监听线程: {}", e))?;
    Ok(hub)
}

fn accept_loop(listener: TcpListener, hub: Arc<Mutex<NetHub>>) {
    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                let hub = Arc::clone(&hub);
                thread::Builder::new()
                    .name("hex-mp-client".into())
                    .spawn(move || handle_client(stream, hub))
                    .ok();
            }
            Err(e) => {
                if let Ok(mut h) = hub.lock() {
                    h.events.push(HubEvent::ServerError(e.to_string()));
                    h.notify_repaint();
                }
            }
        }
    }
}

fn write_json_line<W: Write>(w: &mut W, msg: &ClientMessage) -> std::io::Result<()> {
    let s = serde_json::to_string(msg)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
    w.write_all(s.as_bytes())?;
    w.write_all(b"\n")?;
    w.flush()
}

fn send_json_line(w: &mut TcpStream, msg: &ServerMessage) -> std::io::Result<()> {
    let s = serde_json::to_string(msg)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
    w.write_all(s.as_bytes())?;
    w.write_all(b"\n")?;
    w.flush()
}

fn handle_client(stream: TcpStream, hub: Arc<Mutex<NetHub>>) {
    let _ = stream.set_nodelay(true);
    let peer = stream
        .peer_addr()
        .map(|a| a.to_string())
        .unwrap_or_else(|_| "未知地址".to_string());
    let write_stream = match stream.try_clone() {
        Ok(s) => s,
        Err(e) => {
            if let Ok(mut h) = hub.lock() {
                h.events.push(HubEvent::ServerError(e.to_string()));
                h.notify_repaint();
            }
            return;
        }
    };
    let mut reader = BufReader::new(stream);

    // 先读 Hello，再决定分配哪一方。
    let mut line = String::new();
    if reader.read_line(&mut line).unwrap_or(0) == 0 {
        return;
    }
    let hello: ClientMessage = match serde_json::from_str(line.trim()) {
        Ok(v) => v,
        Err(e) => {
            let mut w = write_stream;
            let _ = send_json_line(&mut w, &ServerMessage::Error(format!("协议错误: {}", e)));
            return;
        }
    };
    let requested = match hello {
        ClientMessage::Hello { team } => team,
        _ => None,
    };

    let (id, assigned) = {
        let Ok(mut h) = hub.lock() else {
            return;
        };
        let id = h.next_id;
        h.next_id += 1;
        let assigned = h.assign_team(requested);
        (id, assigned)
    };
    let Some((team, from_gui)) = assigned else {
        let mut w = write_stream;
        let _ = send_json_line(
            &mut w,
            &ServerMessage::Error("没有空闲阵营：蓝、红双方都已被占用。".into()),
        );
        return;
    };

    let (tx, rx) = mpsc::channel::<ServerMessage>();

    // 写线程。先启动写线程并发送 Welcome，再向 GUI 暴露该连接，
    // 保证客户端总是先看到握手，再收到 GUI 广播的战场快照。
    let writer = thread::Builder::new()
        .name("hex-mp-writer".into())
        .spawn(move || {
            let mut w = write_stream;
            for msg in rx {
                if send_json_line(&mut w, &msg).is_err() {
                    break;
                }
            }
        })
        .ok();

    let _ = tx.send(ServerMessage::Welcome {
        team,
        message: format!(
            "已连接。你执{}方。输入 h 查看命令，q 退出。",
            team_label(team)
        ),
    });

    {
        let Ok(mut h) = hub.lock() else {
            return;
        };
        h.clients.insert(
            id,
            ClientConn {
                id,
                team,
                tx,
                addr: peer.parse().unwrap_or_else(|_| {
                    // peer 通常是 ip:port；解析失败时退化为本地回环占位。
                    SocketAddr::from(([127, 0, 0, 1], 0))
                }),
                from_gui,
            },
        );
        h.events.push(HubEvent::ClientJoined {
            id,
            team,
            addr: peer.clone(),
        });
        h.notify_repaint();
    }

    // 命令循环。
    loop {
        line.clear();
        match reader.read_line(&mut line) {
            Ok(0) => break,
            Ok(_) => {}
            Err(_) => break,
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        let msg: ClientMessage = match serde_json::from_str(trimmed) {
            Ok(v) => v,
            Err(e) => {
                if let Ok(h) = hub.lock() {
                    h.send_to(id, ServerMessage::Error(format!("协议错误: {}", e)));
                }
                continue;
            }
        };
        match msg {
            ClientMessage::Command { line } => {
                if let Ok(mut h) = hub.lock() {
                    h.incoming.push((id, line));
                    h.notify_repaint();
                }
            }
            ClientMessage::Quit => {
                break;
            }
            ClientMessage::Hello { .. } => {
                if let Ok(h) = hub.lock() {
                    h.send_to(id, ServerMessage::Error("已经连接，无需重复 Hello".into()));
                }
            }
        }
    }

    if let Ok(mut h) = hub.lock() {
        h.remove_client(id, "连接已断开");
        h.notify_repaint();
    }
    if let Some(w) = writer {
        let _ = w.join();
    }
}

pub fn team_label(team: Team) -> &'static str {
    match team {
        Team::Player => "蓝",
        Team::Ai => "红",
    }
}

pub fn team_full_label(team: Team) -> &'static str {
    match team {
        Team::Player => "蓝方",
        Team::Ai => "红方",
    }
}

// ---------------------------------------------------------------------------
// 终端客户端
// ---------------------------------------------------------------------------

pub fn run_tui_client(cfg: TuiConfig) -> Result<(), String> {
    let stream = TcpStream::connect(&cfg.connect_addr)
        .map_err(|e| format!("连接 {} 失败: {}", cfg.connect_addr, e))?;
    let _ = stream.set_nodelay(true);
    let mut write_stream = stream.try_clone().map_err(|e| e.to_string())?;
    let reader_stream = stream;

    write_json_line(&mut write_stream, &ClientMessage::Hello { team: cfg.requested_team })
        .map_err(|e| format!("发送握手失败: {}", e))?;

    let out_lock = Arc::new(Mutex::new(()));
    let reader_lock = Arc::clone(&out_lock);
    thread::Builder::new()
        .name("hex-mp-tui-reader".into())
        .spawn(move || {
            let mut reader = BufReader::new(reader_stream);
            let mut line = String::new();
            loop {
                line.clear();
                match reader.read_line(&mut line) {
                    Ok(0) => {
                        let _g = reader_lock.lock();
                        println!("\n与主机的连接已关闭。");
                        std::process::exit(0);
                    }
                    Ok(_) => {}
                    Err(_) => {
                        let _g = reader_lock.lock();
                        println!("\n与主机的连接异常中断。");
                        std::process::exit(0);
                    }
                }
                let Ok(msg) = serde_json::from_str::<ServerMessage>(line.trim()) else {
                    continue;
                };
                match msg {
                    ServerMessage::Welcome { team: _, message } => {
                        let _g = reader_lock.lock();
                        println!("\n{}", message);
                        println!("命令 > ");
                        let _ = std::io::stdout().flush();
                    }
                    ServerMessage::State(text) => {
                        let _g = reader_lock.lock();
                        print!("\n──────── 战场快照 ────────\n{}", text);
                        print!("\n命令 > ");
                        let _ = std::io::stdout().flush();
                    }
                    ServerMessage::Message(text) => {
                        let _g = reader_lock.lock();
                        println!("{}", text);
                    }
                    ServerMessage::Error(text) => {
                        let _g = reader_lock.lock();
                        println!("⚠ {}", text);
                    }
                    ServerMessage::Bye(text) => {
                        let _g = reader_lock.lock();
                        println!("{}", text);
                        std::process::exit(0);
                    }
                }
            }
        })
        .map_err(|e| format!("无法启动终端接收线程: {}", e))?;

    println!("已连接 {}。输入 h 查看命令，q 退出。", cfg.connect_addr);
    let stdin = std::io::stdin();
    loop {
        let mut line = String::new();
        print!("命令 > ");
        let _ = std::io::stdout().flush();
        if stdin.read_line(&mut line).map_err(|e| e.to_string())? == 0 {
            break;
        }
        let line = line.trim().to_string();
        if line.is_empty() {
            continue;
        }
        if line == "q" || line == "quit" {
            let _ = write_json_line(&mut write_stream, &ClientMessage::Quit);
            break;
        }
        if let Err(e) = write_json_line(&mut write_stream, &ClientMessage::Command { line }) {
            return Err(format!("发送命令失败: {}", e));
        }
        thread::sleep(Duration::from_millis(5));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// 终端命令解释器
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, Default)]
pub struct PlayerSession {
    pub selected: Option<Hex>,
}

#[derive(Clone, Debug, Default)]
pub struct CommandOutcome {
    pub messages: Vec<String>,
    pub changed: bool,
    pub end_turn: bool,
    pub quit: bool,
    /// 本命令不触发「全员行动完毕自动结束回合」。追加部署属于回合内的额外动作
    /// （与 GUI 点击放置一致），单位行动次数全空时也不该把回合交出去。
    pub no_auto_end: bool,
}

/// 解析坐标参数：`列,行`（均从 1 起，如 `12,5`）。
fn parse_hex(game: &GameState, s: &str) -> Option<Hex> {
    let ax = hex::parse_label(s)?;
    if game.map.contains(ax) {
        Some(ax)
    } else {
        None
    }
}

fn find_unit(game: &GameState, team: Team, ch: char) -> Option<Hex> {
    game.units_of(team)
        .into_iter()
        .find(|u| u.label == ch)
        .map(|u| u.pos)
}

fn unit_at_layer(game: &GameState, h: Hex, air: bool) -> Option<Unit> {
    if air {
        game.air_units.get(&h).cloned()
    } else {
        game.units.get(&h).cloned()
    }
}

fn selected_unit(game: &GameState, session: &PlayerSession, team: Team) -> Option<Unit> {
    let h = session.selected?;
    game.unit_at(h)
        .filter(|u| u.team == team)
        .cloned()
        .or_else(|| game.air_units.get(&h).filter(|u| u.team == team).cloned())
}

fn out(out: &mut Vec<String>, s: impl Into<String>) {
    out.push(s.into());
}

pub fn execute_command(
    game: &mut GameState,
    team: Team,
    session: &mut PlayerSession,
    line: &str,
) -> CommandOutcome {
    let mut result = CommandOutcome::default();
    let tokens: Vec<&str> = line.split_whitespace().collect();
    if tokens.is_empty() {
        return result;
    }
    let raw_cmd = tokens[0];
    let cmd = raw_cmd.to_lowercase();

    // 裸标签：单个字符且不是小写命令字母时，直接当"选择单位"
    // （README：也可直接输入单位字母，如 A；红方标签是 1-9）。
    // 这样大写 `E` 不会再被当成 `e` 结束回合。
    let bare_label = {
        let mut it = raw_cmd.chars();
        match (it.next(), it.next()) {
            (Some(c), None) => !(c.is_ascii_lowercase() && "smpaerhdxbq".contains(c)) && c != '?',
            _ => false,
        }
    };
    if bare_label {
        let ch = raw_cmd.chars().next().unwrap();
        if let Some(h) = find_unit(game, team, ch) {
            session.selected = Some(h);
            let u = game.unit_at(h).unwrap();
            result.messages.push(format!("已选择 {}。", u.name_with_label()));
        } else {
            result.messages.push(format!(
                "找不到{}方单位 '{}'，输入 h 查看帮助。",
                team_label(team),
                ch
            ));
        }
        return result;
    }

    if matches!(cmd.as_str(), "h" | "help" | "?") {
        result.messages.push(command_help());
        return result;
    }
    if matches!(cmd.as_str(), "q" | "quit" | "exit") {
        result.quit = true;
        result.messages.push("再见。".into());
        return result;
    }
    if game.game_over() {
        result.messages.push("对局已经结束。".into());
        return result;
    }
    if game.phase != team {
        result.messages.push(format!(
            "⚠ 当前是{}方回合，不是你的回合。",
            team_label(game.phase)
        ));
        return result;
    }

    match cmd.as_str() {
        "s" | "select" => {
            // 标签是单个字符：多字符输入必须明确报错，
            // 否则 `s 10` 会被静默当成 `s 1`（选错单位）。
            let Some(arg) = tokens.get(1) else {
                result.messages.push("用法: s <标签>（如 s A、s 3）".into());
                return result;
            };
            let mut arg_chars = arg.chars();
            let ch = match (arg_chars.next(), arg_chars.next()) {
                (Some(c), None) => c,
                _ => {
                    result.messages.push(format!(
                        "标签只能是单个字符（如 s A、s 3）：'{}' 不是有效标签。",
                        arg
                    ));
                    return result;
                }
            };
            if let Some(h) = find_unit(game, team, ch) {
                session.selected = Some(h);
                let u = game.unit_at(h).unwrap();
                result.messages.push(format!("已选择 {}。", u.name_with_label()));
            } else {
                result
                    .messages
                    .push(format!("找不到{}方单位 '{}'。", team_label(team), ch));
            }
        }
        "m" | "move" => {
            let Some(target) = tokens.get(1).and_then(|t| parse_hex(game, t)) else {
                result.messages.push("用法: m <格子>（如 m 2,4）".into());
                return result;
            };
            let Some(sel) = session.selected else {
                result.messages.push("请先用 s <标签> 选择单位。".into());
                return result;
            };
            let Some(u) = selected_unit(game, session, team) else {
                session.selected = None;
                result.messages.push("选中单位已不存在。".into());
                return result;
            };
            if u.actions_left < 1 {
                result.messages.push("行动次数不足。".into());
                return result;
            }
            let path = game.map.plan_move(
                &game.units,
                &game.air_units,
                u.pos,
                target,
                u.kind.movement(),
                Some(u.clone()),
                false,
            );
            if path.len() <= 1 {
                result
                    .messages
                    .push("无法到达该格（目标不可达或行动次数不足）。".into());
                return result;
            }
            match game.move_unit(sel, &path, u.kind.is_air()) {
                Ok(new_pos) => {
                    result.changed = true;
                    session.selected = Some(new_pos);
                    // 移动是"朝目标走最多行动力步"：走不到目标格时必须说明，
                    // 否则看起来像"落点与指令不符"。
                    let tail = if new_pos == target {
                        String::new()
                    } else {
                        "（未到达目标格：行动力不足或路径被阻挡/被占据）".to_string()
                    };
                    result.messages.push(format!(
                        "{} 移动到 {}（行动剩余 {}）{}",
                        u.name_with_label(),
                        hex::hex_label(new_pos),
                        u.actions_left - 1,
                        tail
                    ));
                }
                Err(e) => result.messages.push(format!("移动失败: {}", e)),
            }
        }
        "a" | "attack" => {
            let Some(target) = tokens.get(1).and_then(|t| parse_hex(game, t)) else {
                result.messages.push("用法: a <格子>（如 a 15,4）".into());
                return result;
            };
            let Some(sel) = session.selected else {
                result.messages.push("请先用 s <标签> 选择单位。".into());
                return result;
            };
            let Some(u) = selected_unit(game, session, team) else {
                session.selected = None;
                result.messages.push("选中单位已不存在。".into());
                return result;
            };
            let use_air = u.kind.is_air() && game.units.get(&sel).is_none();
            let res = if use_air {
                game.attack_air(sel, target)
            } else {
                game.attack(sel, target)
            };
            match res {
                Ok(o) => {
                    result.changed = true;
                    result.messages.push(o.message);
                }
                Err(e) => result.messages.push(e),
            }
        }
        "p" | "pass" => {
            let Some(sel) = session.selected else {
                result.messages.push("未选择单位。".into());
                return result;
            };
            let Some(u) = selected_unit(game, session, team) else {
                session.selected = None;
                result.messages.push("选中单位已不存在。".into());
                return result;
            };
            let left = u.actions_left;
            let name = u.name_with_label();
            if let Some(mu) = game.unit_at_mut(sel) {
                mu.actions_left = 0;
                result.changed = true;
            }
            session.selected = None;
            result
                .messages
                .push(format!("{} 结束本回合行动（剩余 {} 次行动作废）。", name, left));
        }
        "e" | "end" => {
            result.end_turn = true;
            result.messages.push("结束回合。".into());
        }
        "r" | "range" => {
            let a = tokens.get(1).and_then(|t| parse_hex(game, t));
            let b = tokens.get(2).and_then(|t| parse_hex(game, t));
            match (a, b) {
                (Some(f), Some(t)) => {
                    let d = Hex::distance(f, t);
                    let los = game.map.has_los_ex(f, t, &game.smoke);
                    // 本命令测量的是"任意两格"，与选中单位无关——明确提示，
                    // 避免把测距结果当成"我选中的单位能打"。
                    let mut note = String::new();
                    if let Some(sel) = session.selected {
                        if sel != f {
                            note = format!("（注意：这是任意两格的测距，与选中单位无关；选中单位在 {}）",
                                hex::hex_label(sel));
                        }
                    }
                    result.messages.push(format!(
                        "📏 {} → {}：距离 {} 格，直射{}。{}",
                        hex::hex_label(f),
                        hex::hex_label(t),
                        d,
                        if los { "✅ 通畅" } else { "❌ 被阻挡" },
                        note
                    ));
                }
                _ => result.messages.push("用法: r <格1> <格2>".into()),
            }
        }
        "smoke" => {
            let Some(target) = tokens.get(1).and_then(|t| parse_hex(game, t)) else {
                result.messages.push("用法: smoke <格子>".into());
                return result;
            };
            let Some(sel) = session.selected else {
                result.messages.push("请先选择榴弹炮/迫击炮。".into());
                return result;
            };
            match game.smoke_shot(sel, target) {
                Ok(cells) => {
                    result.changed = true;
                    result.messages.push(format!(
                        "发射烟雾弹 @{}（共 {} 格，持续 2 回合）。",
                        hex::hex_label(target),
                        cells.len()
                    ));
                }
                Err(e) => result.messages.push(format!("⚠ {}", e)),
            }
        }
        "setup" | "aim" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择需要架设的单位（榴弹炮/重机枪手）。".into());
                return result;
            };
            let name = game.unit_at(sel).map(|u| u.name_with_label()).unwrap_or_default();
            match game.deploy(sel) {
                Ok(()) => {
                    result.changed = true;
                    result.messages.push(format!("{} 完成架设。", name));
                }
                Err(e) => result.messages.push(format!("⚠ {}", e)),
            }
        }
        "aa" | "stinger" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择单位。".into());
                return result;
            };
            match game.toggle_aa_mode(sel) {
                Ok(()) => {
                    result.changed = true;
                    if let Some(u) = game.unit_at(sel) {
                        result.messages.push(format!(
                            "{} 切换到 {}（射程 {} 攻 {} 命中 {}%）。",
                            u.name_with_label(),
                            u.mode_name(),
                            u.eff_range(),
                            u.eff_attack(),
                            u.eff_hit_rate()
                        ));
                    }
                }
                Err(e) => result.messages.push(format!("⚠ {}", e)),
            }
        }
        "missile" | "ms" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择单位。".into());
                return result;
            };
            match game.toggle_missile_mode(sel) {
                Ok(()) => {
                    result.changed = true;
                    if let Some(u) = game.unit_at(sel) {
                        result.messages.push(format!(
                            "{} 切换到 {}（射程 {} 攻 {} 命中 {}%）。",
                            u.name_with_label(),
                            u.mode_name(),
                            u.eff_range(),
                            u.eff_attack(),
                            u.eff_hit_rate()
                        ));
                    }
                }
                Err(e) => result.messages.push(format!("⚠ {}", e)),
            }
        }
        "roof" | "rf" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择建筑内的步兵。".into());
                return result;
            };
            let can = game
                .unit_at(sel)
                .map(|u| {
                    u.team == team && u.kind.is_foot() && game.map.buildings.contains(&sel)
                })
                .unwrap_or(false);
            if !can {
                result
                    .messages
                    .push("只有建筑内的己方步兵可以切换屋顶状态。".into());
                return result;
            }
            if let Some(u) = game.unit_at_mut(sel) {
                if u.actions_left < 1 {
                    result.messages.push("行动次数不足。".into());
                    return result;
                }
                u.rooftop = !u.rooftop;
                u.actions_left -= 1;
                result.changed = true;
                result.messages.push(format!(
                    "{} 现在处于{}。",
                    u.name_with_label(),
                    if u.rooftop { "屋顶" } else { "屋中" }
                ));
            }
        }
        "wd" | "retreat" | "撤退" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择要撤退的单位。".into());
                return result;
            };
            match game.retreat_unit(team, sel) {
                Ok(pts) => {
                    result.changed = true;
                    session.selected = None;
                    result.messages.push(format!(
                        "🏳 单位已从出发区域撤退，按血量返还 {} 点招募点。",
                        pts
                    ));
                }
                Err(e) => result.messages.push(format!("⚠ {}", e)),
            }
        }
        "b" | "board" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择载具。".into());
                return result;
            };
            let label = tokens.get(1).and_then(|t| t.chars().next());
            let Some(su) = game.unit_at(sel).cloned() else {
                result.messages.push("载具已不存在。".into());
                return result;
            };
            if su.kind.capacity() == 0 {
                result.messages.push(format!("{} 不能搭载单位。", su.name_with_label()));
                return result;
            }
            if su.kind.is_air() {
                match game.heli_board(su.pos) {
                    Ok(()) => {
                        result.changed = true;
                        result.messages.push(format!("{} 载入下方单位。", su.name_with_label()));
                    }
                    Err(e) => result.messages.push(format!("载入失败: {}", e)),
                }
                return result;
            }
            let candidates: Vec<Unit> = su
                .pos
                .neighbors()
                .iter()
                .filter_map(|n| game.unit_at(*n).cloned())
                .filter(|inf| inf.team == team && su.can_carry(inf.kind))
                .collect();
            let target = candidates
                .iter()
                .find(|inf| label.map_or(true, |l| inf.label == l));
            match target {
                Some(inf) => match game.board(su.pos, inf.pos) {
                    Ok(()) => {
                        result.changed = true;
                        result
                            .messages
                            .push(format!("{} 搭载 {}。", su.name_with_label(), inf.name_with_label()));
                    }
                    Err(e) => result.messages.push(format!("上车失败: {}", e)),
                },
                None => result.messages.push("没有可搭载的紧邻己方步兵。".into()),
            }
        }
        "d" | "x" | "disembark" => {
            let Some(sel) = session.selected else {
                result.messages.push("请先选择载具。".into());
                return result;
            };
            let is_air = game.unit_at(sel).map(|u| u.kind.is_air()).unwrap_or(false);
            if is_air {
                match game.heli_unload(sel) {
                    Ok(()) => {
                        result.changed = true;
                        result.messages.push("步兵已下到正下方（本回合不能行动）。".into());
                    }
                    Err(e) => result.messages.push(format!("放下失败: {}", e)),
                }
                return result;
            }
            let Some(lbl) = tokens.get(1).and_then(|t| t.chars().next()) else {
                result
                    .messages
                    .push("用法: d <步兵标签> <落点格>（如 d B 3,4）".into());
                return result;
            };
            let Some(dest) = tokens.get(2).and_then(|t| parse_hex(game, t)) else {
                result
                    .messages
                    .push("用法: d <步兵标签> <落点格>（如 d B 3,4）".into());
                return result;
            };
            match game.disembark(sel, lbl, dest) {
                Ok(()) => {
                    result.changed = true;
                    result
                        .messages
                        .push(format!("{} 下车到 {}。", lbl, hex::hex_label(dest)));
                }
                Err(e) => result.messages.push(format!("下车失败: {}", e)),
            }
        }
        "dp" | "deploy" | "points" | "pts" => {
            // 追加部署命令族（可持续部署模式）：
            //   dp                  → 点数/大本营/用法摘要
            //   dp list             → 可部署兵种清单（编号可用作 dp 的第一个参数）
            //   dp <兵种|编号> <格>  → 在本方大本营中心周围 2 格内追加部署
            // 部署是回合内的额外动作，任何 dp 命令都不触发「行动完毕自动结束回合」。
            result.no_auto_end = true;
            if game.recruit_zone_turn <= 0 {
                result.messages.push(
                    "当前对局未启用招募（本局是预置部队经典快速开局；用持续部署模式启动主机可自行招募）。"
                        .into(),
                );
                return result;
            }
            let sub = tokens.get(1).copied().unwrap_or("");
            let sub_lower = sub.to_ascii_lowercase();
            if sub.is_empty() {
                result.messages.push(reinforce_status_text(game, team));
                return result;
            }
            if matches!(sub_lower.as_str(), "list" | "ls" | "help") {
                result.messages.push(reinforce_kind_list(game, team));
                return result;
            }
            let Some(kind) = parse_kind_token(sub) else {
                result.messages.push(format!(
                    "未知兵种 '{}'。用 dp list 查看可部署兵种（也接受编号）。",
                    sub
                ));
                return result;
            };
            let Some(pos) = tokens.get(2).and_then(|t| parse_hex(game, t)) else {
                result.messages.push(format!(
                    "用法: dp <兵种|编号> <格> [货物…]（如 dp {} 3,5；运输单位可跟货物，如 dp truck 3,5 rifleman rifleman）；dp list 查看兵种与费用。",
                    kind.token()
                ));
                return result;
            };
            let cargo = match parse_cargo_tokens(&tokens, 3) {
                Ok(c) => c,
                Err(e) => {
                    result.messages.push(format!("⚠ {}", e));
                    return result;
                }
            };
            match game.recruit_unit_with_cargo(team, kind, pos, &cargo) {
                Ok(label) => {
                    result.changed = true;
                    let left = game.recruit_points.get(&team).copied().unwrap_or(0);
                    let first_round = game.turn <= game.recruit_zone_turn;
                    result.messages.push(format!(
                        "🛠 {} {} {} @{}{}（剩余 {} 点；{}）",
                        if first_round { "招募" } else { "增援部署" },
                        label,
                        kind.name(),
                        hex::hex_label(pos),
                        if cargo.is_empty() {
                            String::new()
                        } else {
                            format!("（载 {}）", cargo.len())
                        },
                        left,
                        if first_round { "本回合即可行动" } else { "本回合不可行动" }
                    ));
                }
                Err(e) => result.messages.push(format!("⚠ {}", e)),
            }
        }
        "units" | "u" => {
            result.messages.push(render_units_panel(game, team));
        }
        _ => {
            result.messages.push(format!(
                "未知命令 '{}'，输入 h 查看帮助。",
                tokens[0]
            ));
        }
    }

    result
}

/// `dp` 的兵种参数：支持中文名（坦克）、ASCII 代号（tank）或清单编号（dp list 的序号）。
fn parse_kind_token(text: &str) -> Option<UnitKind> {
    let raw = text.trim();
    if let Ok(n) = raw.parse::<usize>() {
        let all = UnitKind::all_recruitable();
        if n >= 1 && n <= all.len() {
            return Some(all[n - 1]);
        }
        return None;
    }
    UnitKind::from_token(raw)
}

/// `dp` 命令尾随的「初始搭载」货物：每项接受兵种中文名/代号/编号。
fn parse_cargo_tokens(tokens: &[&str], from: usize) -> Result<Vec<UnitKind>, String> {
    let mut cargo = Vec::new();
    for t in tokens.iter().skip(from) {
        match parse_kind_token(t) {
            Some(k) => cargo.push(k),
            None => return Err(format!("未知货物兵种 '{}'", t)),
        }
    }
    Ok(cargo)
}

/// 出发区域列的文字标签（连续列写作 a-d，否则逐个列出）。
pub fn deploy_zone_label(game: &GameState, team: Team) -> String {
    let zone = game.deploy_zone(team);
    if zone.is_empty() {
        return "无".to_string();
    }
    let letter = |c: i32| (c + 1).to_string();
    let first = *zone.iter().min().unwrap();
    let last = *zone.iter().max().unwrap();
    if (last - first + 1) as usize == zone.len() {
        format!("{}-{}", letter(first), letter(last))
    } else {
        zone.iter().map(|c| letter(*c)).collect::<Vec<_>>().join(",")
    }
}

/// `dp` 无参数：按当前阶段说明招募区域、点数与每回合收入。
fn reinforce_status_text(game: &GameState, team: Team) -> String {
    let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
    let per = game.sustain_per_turn.get(&team).copied().unwrap_or(0);
    let turn = game.turn.max(1);
    let mut out = String::new();
    if game.turn <= game.recruit_zone_turn {
        out.push_str(&format!(
            "🛠 招募（第 {} 回合）· 剩余 {} 点（每回合 +{}）\n",
            turn, pts, per
        ));
        out.push_str(&format!(
            "本回合可在本方出发区域（{} 列）任意空格招募；第 {} 回合起改为大本营周围 2 格内。\n",
            deploy_zone_label(game, team),
            game.recruit_zone_turn + 1
        ));
        out.push_str("本回合招募的单位本回合即可行动。\n");
    } else {
        let hq = game
            .hq_pos(team)
            .map(hex::hex_label)
            .unwrap_or_else(|| "未设立".to_string());
        out.push_str(&format!(
            "🛠 追加部署（第 {} 回合）· 剩余 {} 点（每回合 +{}）· 大本营中心 {}\n",
            turn, pts, per, hq
        ));
        out.push_str("部署范围: 大本营中心周围 2 格内、空格、且距敌军 >5 格（被敌军占领的格子不可用）\n");
        out.push_str("本回合部署的单位下回合才能行动。\n");
    }
    out.push_str("用法: dp <兵种|编号> <格> [货物…]（如 dp 坦克 3,5；运输单位可跟货物，如 dp truck 3,5 rifleman rifleman）；dp list 查看兵种与费用");
    out
}

/// `dp list`：可部署兵种清单（编号可直接用作 `dp <编号> <格>` 的第一个参数）。
fn reinforce_kind_list(game: &GameState, team: Team) -> String {
    let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
    let mut out = format!("🛠 可部署兵种（剩余 {} 点）:\n", pts);
    for (i, kind) in UnitKind::all_recruitable().iter().enumerate() {
        let cost = kind.recruit_cost();
        let mark = if cost <= pts { "✅" } else { "❌" };
        out.push_str(&format!(
            "  {:>2}. {} {} · {} 点（{}）\n",
            i + 1,
            mark,
            kind.name(),
            cost,
            kind.token()
        ));
    }
    out.push_str("用法: dp <兵种|编号> <格> [货物…]（运输单位可在后面列货物）");
    out
}

fn command_help() -> String {
    r#"可用命令:
  h / help           显示本帮助
  s <标签>           选择己方单位（如 s A、s 3）
  m <格子>           移动选中单位（坐标 列,行，如 m 2,4）
  a <格子>           攻击目标（如 a 15,4）
  p / pass           结束选中单位的行动
  e / end            结束本回合
  r <格1> <格2>      测距/检查直射视线
  smoke <格子>       榴弹炮/迫击炮发射烟雾弹
  setup              架设（榴弹炮/重机枪手，消耗 1 次行动后才能开火）
  aa / stinger       切换防空导弹模式
  missile / ms       切换副武器/导弹模式
  roof / rf          步兵在屋中/屋顶间切换
  wd / retreat       撤退：位于本方出发区域内的单位立即撤离，按血量比例返还招募点
  b [标签]           搭载紧邻步兵（直升机从正下方载入）
  d <标签> <格子>    地面载具放下步兵；x 为直升机放下
  units              查看战场态势
  dp                 招募：查看当前招募区域/剩余点数/每回合收入/大本营
  dp list            招募：可招募兵种清单（编号、名称、费用）
  dp <兵种|编号> <格> [货物…]  招募一个单位（第 1 回合可在出发区域；之后只能在大本营周围 2 格内；运输单位可跟货物一次性购入）
  q / quit           退出

自动播报（无需命令，随战场快照一起推送）:
  [战损] 你方某单位被击毁（含被谁、用什么方式击毁、是否随载具阵亡）
  [战果] 你方击毁敌方某单位
  [据点] 关键据点易手
  [胜负] 对局结束（胜负或僵局平局）
"#
    .to_string()
}

// ---------------------------------------------------------------------------
// 文本快照
// ---------------------------------------------------------------------------

pub fn render_state(game: &GameState, team: Team, selected: Option<Hex>) -> String {
    let mut s = String::new();
    s.push_str(&format!(
        "六边形战争 · 多人热座 · 你是{}方 · 第 {} 回合 · {}方行动\n",
        team_label(team),
        game.turn.max(1),
        team_label(game.phase)
    ));
    s.push_str(&render_situation(game, team));
    s.push_str(&render_map(game, team, selected));
    s.push_str("图例: 青色=我方 红色=敌方 反色=当前选中 ?=最后已知位置 !=迷雾开火警告 ");
    s.push_str("▲岩石 ♣森林(行动力×2/隐蔽) ▣楼房(仅步兵) ≈水域 ▒烟雾 ★=关键据点中心 ⚑=关键据点\n");
    s.push('\n');
    s.push_str(&render_units_panel(game, team));
    s.push('\n');
    if let Some(h) = selected {
        s.push_str(&render_selected_panel(game, h, team));
    }
    if game.sustain {
        s.push_str("\n命令: s 选择 | m 移动 | a 攻击 | dp 招募 | p 结束单位 | e 结束回合 | h 帮助\n");
    } else {
        s.push_str("\n命令: s 选择 | m 移动 | a 攻击 | p 结束单位 | e 结束回合 | h 帮助\n");
    }
    s
}

/// 结构化战报的文本投影：把 `seq > from_seq` 的事件渲染成该方视角的行。
/// 击毁（含随载具阵亡的步兵）、关键据点易手、胜负判定各一类前缀，
/// 便于人或 Agent 稳定解析。
pub fn render_battle_events(game: &GameState, team: Team, from_seq: u32) -> Vec<String> {
    let mut out = Vec::new();
    for ev in game.battle_events.iter().filter(|e| e.seq > from_seq) {
        match &ev.kind {
            BattleEventKind::Kill(k) => {
                let attacker_short = match (k.attacker_label, k.attacker_kind) {
                    (Some(label), Some(kind)) => format!("{}({})", label, kind.name()),
                    _ => "未知来源".to_string(),
                };
                let attacker = match (k.attacker_label, k.attacker_kind) {
                    (Some(_), Some(_)) => format!(
                        "{} {}",
                        k.attacker_team.map(team_full_label).unwrap_or("未知方"),
                        attacker_short
                    ),
                    _ => "未知来源".to_string(),
                };
                if k.victim_team == team {
                    out.push(format!(
                        "[战损] 第{}回合 你方 {}({}) @{} 被 {} 击毁（{}）{}",
                        ev.turn,
                        k.victim_label,
                        k.victim_kind.name(),
                        hex::hex_label(k.victim_pos),
                        attacker,
                        k.cause.cn(),
                        if k.passenger { "，随载具一同阵亡" } else { "" }
                    ));
                } else {
                    out.push(format!(
                        "[战果] 第{}回合 你方 {} 击毁敌方 {}({}) @{}（{}）{}",
                        ev.turn,
                        attacker_short,
                        k.victim_label,
                        k.victim_kind.name(),
                        hex::hex_label(k.victim_pos),
                        k.cause.cn(),
                        if k.passenger { "，车上步兵随载具阵亡" } else { "" }
                    ));
                }
            }
            BattleEventKind::Keypoint {
                hex,
                center,
                from,
                to,
                by_label,
                by_kind,
            } => {
                let center_txt = if *center { "（大本营中心）" } else { "" };
                if *to == team {
                    out.push(format!(
                        "[据点] 第{}回合 你方 {}({}) 占领了{}的关键据点 {} {}",
                        ev.turn,
                        by_label,
                        by_kind.name(),
                        team_full_label(*from),
                        hex::hex_label(*hex),
                        center_txt
                    ));
                } else {
                    out.push(format!(
                        "[据点] 第{}回合 敌方 {}({}) 夺占了{}的关键据点 {} {}",
                        ev.turn,
                        by_label,
                        by_kind.name(),
                        team_full_label(*from),
                        hex::hex_label(*hex),
                        center_txt
                    ));
                }
            }
            BattleEventKind::Victory { winner, reason } => {
                if *winner == team {
                    out.push(format!("[胜负] 第{}回合 你方获胜：{}", ev.turn, reason));
                } else {
                    out.push(format!("[胜负] 第{}回合 你方失败：{}", ev.turn, reason));
                }
            }
        }
    }
    out
}

/// 上帝视角的一条战报文本（观战快照用，不属于任何一方）。
fn spectator_event_text(ev: &hex_wargame::game::BattleEvent) -> String {
    match &ev.kind {
        BattleEventKind::Kill(k) => {
            let attacker = match (k.attacker_team, k.attacker_label, k.attacker_kind) {
                (Some(t), Some(label), Some(kind)) => {
                    format!("{}{}({})", team_full_label(t), label, kind.name())
                }
                _ => "未知来源".to_string(),
            };
            format!(
                "{} {}({}) @{} 被 {} 击毁（{}）{}",
                team_full_label(k.victim_team),
                k.victim_label,
                k.victim_kind.name(),
                hex::hex_label(k.victim_pos),
                attacker,
                k.cause.cn(),
                if k.passenger { "，随载具阵亡" } else { "" }
            )
        }
        BattleEventKind::Keypoint {
            hex,
            center,
            from,
            to,
            by_label,
            by_kind,
        } => format!(
            "{} {}({}) 占领了{}的关键据点 {}{}",
            team_full_label(*to),
            by_label,
            by_kind.name(),
            team_full_label(*from),
            hex::hex_label(*hex),
            if *center { "（大本营中心）" } else { "" }
        ),
        BattleEventKind::Victory { winner, reason } => {
            format!("{}获胜：{}", team_full_label(*winner), reason)
        }
    }
}

/// 观战快照（`--state-file`）：一份自包含的权威状态。
///
/// 任何单个参战方都看不到的信息（双方全部单位、完整地形、结构化战报）都在这里，
/// 供外部监督进程（控制 pipeline）在**不占用第二个终端连接**的情况下：
/// 判断当前行动方与回合、核对回合是否真正交接、统计双方损失、渲染观战画面。
/// 快照是纯数据（JSON），不含任何运行期对象。
pub fn spectator_snapshot(game: &GameState, game_over: Option<&str>) -> serde_json::Value {
    let team_code = |t: Team| if t == Team::Player { "blue" } else { "red" };
    let now_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    let unit_json = |u: &Unit, air: bool| {
        serde_json::json!({
            "team": team_code(u.team),
            "label": u.label.to_string(),
            "kind": u.kind.name(),
            "hex": hex::hex_label(u.pos),
            "hp": u.hp,
            "max_hp": u.kind.max_hp(),
            "actions_left": u.actions_left,
            "ammo": u.ammo,
            "missile_ammo": u.missile_ammo,
            "aa_ammo": u.aa_ammo,
            "suppression": u.suppression_stacks,
            "air": air,
            "rooftop": u.rooftop,
            "passengers": u
                .passengers
                .iter()
                .map(|p| serde_json::json!({
                    "label": p.label.to_string(),
                    "kind": p.kind.name(),
                    "hp": p.hp,
                    "max_hp": p.kind.max_hp(),
                }))
                .collect::<Vec<_>>(),
        })
    };

    let mut units: Vec<serde_json::Value> = Vec::new();
    for u in game.units.values() {
        units.push(unit_json(u, false));
    }
    for u in game.air_units.values() {
        units.push(unit_json(u, true));
    }

    // 双方损失：直接由结构化战报统计（含随载具阵亡的步兵）。
    let mut lost_count = [0usize, 0usize];
    let mut lost_points = [0i32, 0i32];
    for ev in game.battle_events.iter() {
        if let BattleEventKind::Kill(k) = &ev.kind {
            let idx = if k.victim_team == Team::Player { 0 } else { 1 };
            lost_count[idx] += 1;
            if !k.passenger {
                lost_points[idx] += k.victim_kind.recruit_cost();
            }
        }
    }
    let alive = |t: Team| -> usize { game.alive_unit_count(t) };
    let side_json = |t: Team, idx: usize| {
        serde_json::json!({
            "alive": alive(t),
            "lost": lost_count[idx],
            "lost_points": lost_points[idx],
            "kills": lost_count[1 - idx],
            // 可持续部署：当前累计部署点数与每回合收入（非 sustain 模式为 0）。
            "points": game.recruit_points.get(&t).copied().unwrap_or(0),
            "points_per_turn": game.sustain_per_turn.get(&t).copied().unwrap_or(0),
            "hq": game.hq_pos(t).map(hex::hex_label),
        })
    };

    let keypoints: Vec<serde_json::Value> = game
        .keypoints
        .iter()
        .map(|(h, kp)| {
            serde_json::json!({
                "hex": hex::hex_label(*h),
                "owner": team_code(kp.owner),
                "controller": team_code(kp.controller),
                "center": kp.center,
            })
        })
        .collect();

    let events: Vec<serde_json::Value> = game
        .battle_events
        .iter()
        .rev()
        .take(60)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .map(|ev| {
            serde_json::json!({
                "seq": ev.seq,
                "turn": ev.turn,
                "kind": match &ev.kind {
                    BattleEventKind::Kill(_) => "kill",
                    BattleEventKind::Keypoint { .. } => "keypoint",
                    BattleEventKind::Victory { .. } => "victory",
                },
                "text": spectator_event_text(ev),
            })
        })
        .collect();

    let winner = game.winner.map(team_code);
    let draw = game.winner.is_none() && game.is_draw();
    let result = match (game_over, game.winner, draw) {
        (Some(msg), _, _) => msg.to_string(),
        (None, Some(w), _) => format!("{}方获胜", team_full_label(w)),
        (None, None, true) => "平局（连续 20 回合无击毁的僵局）".to_string(),
        (None, None, false) => String::new(),
    };

    serde_json::json!({
        "schema": "hex_wargame.spectator.v1",
        "updated_ms": now_ms,
        "seed": game.seed,
        "level": game.level.name(),
        "turn": game.turn.max(1),
        "active_team": team_code(game.phase),
        "deploying": game.deploying,
        "sustain": game.sustain,
        // 空地图招募模式：双方全部单位自行招募；recruit_zone_turn 回合内可在出发区域招募。
        "recruit_mode": game.recruit_zone_turn > 0,
        "recruit_zone_turn": game.recruit_zone_turn,
        "sustain_per_turn": {
            "blue": game.sustain_per_turn.get(&Team::Player).copied().unwrap_or(0),
            "red": game.sustain_per_turn.get(&Team::Ai).copied().unwrap_or(0),
        },
        "over": game.winner.is_some() || draw || game_over.is_some(),
        "winner": winner,
        "draw": draw,
        "result": result,
        "battle_seq": game.battle_seq,
        "event_log_len": game.event_log.len(),
        "teams": {
            "blue": side_json(Team::Player, 0),
            "red": side_json(Team::Ai, 1),
        },
        "units": units,
        "keypoints": keypoints,
        "events": events,
        "map": render_spectator_map(game),
    })
}

/// 一行的局势摘要：胜负条件、双方兵力、关键据点归属、迷雾警告、最后已知敌情、结果。
/// 与地图/部队面板一起，构成"任意时刻都能重建本方视角状态"的完备快照。
fn render_situation(game: &GameState, team: Team) -> String {
    let mut out = String::new();
    out.push_str("── 局势 ──\n");
    let objectives = game.keypoints.values().filter(|k| !k.center).count();
    let cond = if game.sustain || !game.keypoints.is_empty() {
        format!(
            "据点胜负（蓝：{} / 红：{}；游戏结束回合 {}）",
            game.victory_rule(Team::Player).label(),
            game.victory_rule(Team::Ai).label(),
            if game.turn_limit() > 0 {
                game.turn_limit().to_string()
            } else {
                "不限".to_string()
            }
        )
    } else {
        "全歼敌军（任一方单位全部阵亡即结束）".to_string()
    };
    out.push_str(&format!("胜负条件: {}\n", cond));
    let phase_note = if game.phase == team {
        "轮到你行动"
    } else {
        "等待对手行动"
    };
    out.push_str(&format!(
        "当前阶段: {}方行动（{}）\n",
        team_label(game.phase),
        phase_note
    ));

    let losses_of = |t: Team| -> usize {
        game.battle_events
            .iter()
            .filter(|e| matches!(&e.kind, BattleEventKind::Kill(k) if k.victim_team == t))
            .count()
    };
    let mine_alive = game.alive_unit_count(team);
    let mine_lost = losses_of(team);
    out.push_str(&format!(
        "我方: 存活 {} 个 · 已损失 {} 个（阵亡单位不会出现在部队面板里，也不能再被指挥）\n",
        mine_alive, mine_lost
    ));
    let vision = game.vision(team);
    let enemy = team.opponent();
    // 可见的载具连同其搭载步兵一起计入"视野内"，与 alive_unit_count 的口径一致。
    let mut seen = 0usize;
    for u in game.units_of(enemy) {
        if vision.enemy_units.contains(&u.pos) || game.test_mode {
            seen += 1 + u.passengers.len();
        }
    }
    let hidden = game.alive_unit_count(enemy).saturating_sub(seen);
    out.push_str(&format!(
        "敌方: 视野内 {} 个 · 未发现 {} 个 · 已确认击毁 {} 个\n",
        seen,
        hidden,
        losses_of(enemy)
    ));

    if !game.keypoints.is_empty() {
        let mut mine_obj: Vec<String> = Vec::new();
        let mut foe_obj: Vec<String> = Vec::new();
        let mut mine_hq: Vec<String> = Vec::new();
        let mut foe_hq: Vec<String> = Vec::new();
        for (h, kp) in game.keypoints.iter() {
            let item = if kp.center {
                hex::hex_label(*h)
            } else {
                format!("{}{}", hex::hex_label(*h), "⚑")
            };
            match (kp.center, kp.controller == team) {
                (false, true) => mine_obj.push(item),
                (false, false) => foe_obj.push(item),
                (true, true) => mine_hq.push(item),
                (true, false) => foe_hq.push(item),
            }
        }
        out.push_str(&format!(
            "关键据点: 我方控制 {}/{} [{}] · 敌方控制 {}/{} [{}]\n",
            mine_obj.len(),
            objectives,
            mine_obj.join(","),
            foe_obj.len(),
            objectives,
            foe_obj.join(",")
        ));
        out.push_str(&format!(
            "大本营(仅增援): 我方 [{}] · 敌方 [{}]\n",
            mine_hq.join(","),
            foe_hq.join(",")
        ));
    }

    // 持续部署：招募区域（第 1 回合=出发区域，之后=大本营周围 2 格）+ 点数。
    if game.sustain {
        let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
        let per = game.sustain_per_turn.get(&team).copied().unwrap_or(0);
        if game.recruit_zone_turn > 0 && game.turn <= game.recruit_zone_turn {
            out.push_str(&format!(
                "招募: 第 {} 回合可在本方出发区域（{} 列）任意空格招募 · 剩余 {} 点（每回合 +{}）· dp <兵种> <格>（本回合即可行动）\n",
                game.turn.max(1),
                deploy_zone_label(game, team),
                pts,
                per
            ));
        } else {
            let hq = game
                .hq_pos(team)
                .map(hex::hex_label)
                .unwrap_or_else(|| "未设立".to_string());
            out.push_str(&format!(
                "招募: 大本营中心 {} 周围 2 格内 · 剩余 {} 点（每回合 +{}）· dp <兵种> <格>（本回合不可行动）\n",
                hq, pts, per
            ));
        }
    }

    if let Some(marks) = game.fog_fire_marks.get(&team) {
        if !marks.is_empty() {
            let list: Vec<String> = marks
                .iter()
                .map(|(h, t)| format!("{}(第{}回合)", hex::hex_label(*h), t))
                .collect();
            out.push_str(&format!("迷雾开火警告: {}\n", list.join(" ")));
        }
    }

    if let Some(ghosts) = game.ghosts.get(&team) {
        let list: Vec<String> = ghosts
            .iter()
            .map(|(h, (kind, t))| {
                format!("{}({},{})", hex::hex_label(*h), kind.name(), t)
            })
            .collect();
        if !list.is_empty() {
            out.push_str(&format!("最后已知敌情: {}\n", list.join(" ")));
        }
    }

    out.push_str(&format!(
        "对局结果: {}\n",
        match game.winner {
            Some(w) if w == team => "你方已获胜".to_string(),
            Some(w) => format!("{}方获胜", team_label(w)),
            None => "对局进行中".to_string(),
        }
    ));
    // 只对该方可见的回合内提示（压制生效、主动防御抵消等）
    if let Some(notes) = game.notices.get(&team) {
        if !notes.is_empty() {
            out.push_str("本回合提示:\n");
            for n in notes {
                out.push_str(&format!("- {}\n", n));
            }
        }
    }
    out
}

fn render_map(game: &GameState, team: Team, selected: Option<Hex>) -> String {
    render_map_inner(game, Some(team), selected)
}

/// 全视野观战地图（无迷雾、无 ANSI 颜色）：双方单位、地形、据点、烟雾全部可见。
/// 用于观战快照（`--state-file`），这是任何单个参战方都看不到的完整画面。
pub fn render_spectator_map(game: &GameState) -> String {
    strip_ansi(&render_map_inner(game, None, None))
}

/// 去掉 ANSI 颜色码（观战快照是 JSON，不能带终端转义序列）。
fn strip_ansi(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut chars = text.chars();
    while let Some(ch) = chars.next() {
        if ch == '\u{1b}' {
            for next in chars.by_ref() {
                if next.is_ascii_alphabetic() {
                    break;
                }
            }
        } else {
            out.push(ch);
        }
    }
    out
}

/// `team == None` 表示全视野观战：地形全部可见、双方单位全部可见、无迷雾标记。
fn render_map_inner(game: &GameState, team: Option<Team>, selected: Option<Hex>) -> String {
    let w = game.map.cols;
    let h = game.map.rows;
    let gutter = 3;
    let text_w = (4 * w + 2) as usize;
    let text_h = (3 * h) as usize;
    let mut grid = vec![vec![' '; text_w]; text_h];

    for r in 0..h {
        for c in 0..w {
            let x = (4 * c + 2 * (r % 2)) as usize;
            let y = (3 * r) as usize;
            grid[y][x + 1] = '_';
            grid[y][x + 2] = '_';
            grid[y + 1][x] = '/';
            grid[y + 1][x + 3] = '\\';
            grid[y + 2][x] = '\\';
            grid[y + 2][x + 1] = '_';
            grid[y + 2][x + 2] = '_';
            grid[y + 2][x + 3] = '\\';
        }
    }

    let mut spans: Vec<(usize, usize, String)> = Vec::new();
    let vision = team.map(|t| game.vision(t));
    let all_hexes: BTreeSet<Hex> = BTreeSet::new();
    let revealed = vision
        .as_ref()
        .map(|v| &v.terrain)
        .unwrap_or(&all_hexes);
    let visible_enemies = vision
        .as_ref()
        .map(|v| &v.enemy_units)
        .unwrap_or(&all_hexes);
    for r in 0..h {
        for c in 0..w {
            let x = (4 * c + 2 * (r % 2)) as usize + 1;
            let y = (3 * r + 1) as usize;
            let ax = hex::axial_from_offset(c, r);
            let fog_warn = team
                .and_then(|t| game.fog_fire_marks.get(&t))
                .map(|m| m.contains_key(&ax))
                .unwrap_or(false);
            let ghost = team
                .and_then(|t| game.ghosts.get(&t))
                .and_then(|g| g.get(&ax))
                .copied();
            // 地形/标记（无单位时显示的内容）
            let terrain_cell = |revealed: bool| -> (char, String) {
                if !revealed {
                    if game.map.obstacles.contains(&ax) {
                        ('▲', "\x1b[2m".to_string())
                    } else if game.map.forests.contains(&ax) {
                        ('♣', "\x1b[2m".to_string())
                    } else if game.map.buildings.contains(&ax) {
                        ('▣', "\x1b[2m".to_string())
                    } else if game.map.water.contains(&ax) {
                        ('≈', "\x1b[2m".to_string())
                    } else {
                        ('·', "\x1b[2m".to_string())
                    }
                } else if game.smoke.contains_key(&ax) {
                    ('▒', "\x1b[97m".to_string())
                } else if game.map.obstacles.contains(&ax) {
                    ('▲', "\x1b[33m".to_string())
                } else if game.map.forests.contains(&ax) {
                    ('♣', "\x1b[32m".to_string())
                } else if game.map.buildings.contains(&ax) {
                    ('▣', "\x1b[37m".to_string())
                } else if game.map.water.contains(&ax) {
                    ('≈', "\x1b[36m".to_string())
                } else {
                    ('·', "\x1b[2m".to_string())
                }
            };
            let (ch, color) = if let Some(u) = game.unit_at(ax) {
                let viewer = team.unwrap_or(Team::Player);
                let seen = team.is_none()
                    || u.team == viewer
                    || visible_enemies.contains(&ax)
                    || game.test_mode;
                if seen {
                    if Some(ax) == selected {
                        (u.label, "\x1b[7m".to_string())
                    } else if u.team == viewer {
                        (u.label, "\x1b[96m".to_string())
                    } else if game.test_mode && !visible_enemies.contains(&ax) {
                        (u.label, "\x1b[2;91m".to_string())
                    } else {
                        (u.label, "\x1b[91m".to_string())
                    }
                } else if fog_warn {
                    ('!', "\x1b[91m".to_string())
                } else if ghost.is_some() {
                    // 该格有"最后已知位置"记录：显示 ?（隐藏敌人的真实位置不会被
                    // 单独泄露——只有曾经看到过的格子才有这个标记）
                    ('?', "\x1b[90m".to_string())
                } else {
                    // 未侦察到的敌方单位：只显示地形，不暴露其真实位置
                    terrain_cell(revealed.contains(&ax))
                }
            } else if fog_warn {
                ('!', "\x1b[91m".to_string())
            } else if ghost.is_some() {
                // 最后已知位置：只在当前确实没有单位时显示
                ('?', "\x1b[90m".to_string())
            } else if let Some(kp) = game.keypoints.get(&ax) {
                let ch = if kp.center { '★' } else { '⚑' };
                let color = match kp.controller {
                    Team::Player => "\x1b[94m".to_string(),
                    Team::Ai => "\x1b[91m".to_string(),
                };
                (ch, color)
            } else {
                terrain_cell(revealed.contains(&ax))
            };
            grid[y][x] = ch;
            spans.push((y, x, format!("{}{}\x1b[0m", color, ch)));
        }
    }

    let mut out = String::new();
    let mut header = " ".repeat(gutter);
    for c in 0..w {
        let x = (4 * c + 1) as usize;
        while header.chars().count() < gutter + x {
            header.push(' ');
        }
        // 列号从 1 起（两位数也放得下 4 字符的格宽）
        header.push_str(&(c + 1).to_string());
    }
    out.push_str(&header);
    out.push('\n');

    for r in 0..h {
        for dy in 0..3 {
            let y = (3 * r + dy) as usize;
            let mut line: String = grid[y].iter().collect();
            let mut row_spans: Vec<(usize, String)> = spans
                .iter()
                .filter(|(sy, _, _)| *sy == y)
                .map(|(_, sx, s)| (*sx, s.clone()))
                .collect();
            row_spans.sort_by_key(|(sx, _)| std::cmp::Reverse(*sx));
            for (sx, s) in row_spans {
                let prefix: String = line.chars().take(sx).collect();
                let suffix: String = line.chars().skip(sx + 1).collect();
                line = format!("{}{}{}", prefix, s, suffix);
            }
            let row_label = if dy == 1 {
                format!("{:>2} ", r + 1)
            } else {
                "   ".to_string()
            };
            out.push_str(&format!("{}{}\n", row_label, line));
        }
    }
    out
}

/// 单个我方单位的完整状态行（弹药/模式/压制/主动防御/诱饵弹/屋顶/搭载）。
fn own_unit_line(u: &Unit) -> String {
    let mut s = format!(
        "{}({}) @{} 血{}/{} 行动{}/{}",
        u.label,
        u.kind.name(),
        hex::hex_label(u.pos),
        u.hp,
        u.kind.max_hp(),
        u.actions_left,
        u.kind.action_count()
    );
    if u.kind.max_ammo() > 0 {
        s.push_str(&format!(" 弹{}/{}", u.ammo, u.kind.max_ammo()));
    }
    if u.kind.max_missile_ammo() > 0 {
        s.push_str(&format!(" 副弹{}/{}", u.missile_ammo, u.kind.max_missile_ammo()));
    }
    if u.kind.max_aa_ammo() > 0 {
        s.push_str(&format!(" 三弹{}/{}", u.aa_ammo, u.kind.max_aa_ammo()));
    }
    if u.kind.max_missile_ammo() > 0 || u.kind.max_aa_ammo() > 0 {
        s.push_str(&format!(" 模式{}", u.mode_name()));
    }
    if u.deployed {
        s.push_str(" 已架设");
    }
    if u.suppression_stacks > 0 {
        s.push_str(&format!(" 压制{}", u.suppression_stacks));
    }
    if u.ad_uses > 0 {
        s.push_str(&format!(" 主动防御{}", u.ad_uses));
    }
    if u.flares > 0 {
        s.push_str(&format!(" 诱饵弹{}", u.flares));
    }
    if u.rooftop {
        s.push_str(" 屋顶");
    }
    if !u.passengers.is_empty() {
        let ps: Vec<String> = u
            .passengers
            .iter()
            .map(|p| {
                let mut t = format!("{}({}) 血{}/{}", p.label, p.kind.name(), p.hp, p.kind.max_hp());
                if p.kind.max_ammo() > 0 {
                    t.push_str(&format!("弹{}/{}", p.ammo, p.kind.max_ammo()));
                }
                t
            })
            .collect();
        s.push_str(&format!(" 载[{}]", ps.join(";")));
    }
    s
}

fn render_units_panel(game: &GameState, team: Team) -> String {
    let mut out = String::new();
    out.push_str("── 战场态势 ──\n");
    let mine: Vec<String> = game.units_of(team).iter().map(|u| own_unit_line(u)).collect();
    out.push_str(&format!("我方: {}\n", mine.join("   ")));
    let vision = game.vision(team);
    let enemy = team.opponent();
    let seen: Vec<&Unit> = game
        .units_of(enemy)
        .into_iter()
        .filter(|u| vision.enemy_units.contains(&u.pos) || game.test_mode)
        .collect();
    let hidden = game
        .units_of(enemy)
        .iter()
        .filter(|u| !vision.enemy_units.contains(&u.pos))
        .count();
    if seen.is_empty() {
        out.push_str(&format!("敌方: （视野内暂无敌人，共 {} 个未发现）\n", hidden));
    } else {
        let e: Vec<String> = seen
            .iter()
            .map(|u| {
                format!(
                    "{}({}) @{} 血{}/{}",
                    u.label,
                    u.kind.name(),
                    hex::hex_label(u.pos),
                    u.hp,
                    u.kind.max_hp()
                )
            })
            .collect();
        out.push_str(&format!("敌方: {}", e.join("   ")));
        if hidden > 0 {
            out.push_str(&format!("（另有 {} 个在视野外）", hidden));
        }
        out.push('\n');
    }
    out
}

fn render_selected_panel(game: &GameState, h: Hex, team: Team) -> String {
    let Some(u) = game.unit_at(h) else {
        return String::new();
    };
    let mut out = String::new();
    out.push_str(&format!(
        "已选择 {} @{} 血{}/{} 行动{}/{} 行动力{} 视野{} 射程{} 攻击{} 命中{}%",
        u.name_with_label(),
        hex::hex_label(u.pos),
        u.hp,
        u.kind.max_hp(),
        u.actions_left,
        u.kind.action_count(),
        u.kind.movement(),
        u.kind.vision(),
        u.eff_range(),
        u.eff_attack(),
        u.eff_hit_rate()
    ));
    if u.kind.max_ammo() > 0 {
        out.push_str(&format!(" 弹{}/{}", u.ammo, u.kind.max_ammo()));
    }
    if u.kind.max_missile_ammo() > 0 {
        out.push_str(&format!(" 副弹{}/{}", u.missile_ammo, u.kind.max_missile_ammo()));
    }
    if u.kind.max_aa_ammo() > 0 {
        out.push_str(&format!(" 三弹{}/{}", u.aa_ammo, u.kind.max_aa_ammo()));
    }
    if u.kind.max_missile_ammo() > 0 || u.kind.max_aa_ammo() > 0 {
        out.push_str(&format!(" 模式{}", u.mode_name()));
    }
    if u.deployed {
        out.push_str(" 已架设");
    }
    if u.ad_uses > 0 {
        out.push_str(&format!(" 主动防御{}", u.ad_uses));
    }
    if u.suppression_stacks > 0 {
        out.push_str(&format!(" 压制{}", u.suppression_stacks));
    }
    out.push('\n');
    let enemies: Vec<String> = game
        .enemies_of(team)
        .iter()
        .filter(|e| {
            (game.is_unit_visible(team, e.pos) || game.test_mode)
                && Hex::distance(u.pos, e.pos) <= u.eff_range()
        })
        .map(|e| {
            format!(
                "{}({})血{}/{}",
                hex::hex_label(e.pos),
                e.kind.name(),
                e.hp,
                e.kind.max_hp()
            )
        })
        .collect();
    if !enemies.is_empty() {
        out.push_str(&format!("射程内可见敌人: {}\n", enemies.join("  ")));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use hex_wargame::game::{BattleEvent, KillCause, KillEvent};
    use hex_wargame::unit::UnitKind;

    /// 文本快照必须让消费者在任意时刻重建本方视角：局势、双方兵力、
    /// 图例、单位完整状态（弹药/压制/主动防御）都在。
    #[test]
    fn render_state_reports_complete_situation() {
        let mut game = GameState::new_seeded_level(3, Level::OpenField);
        game.begin_turn(Team::Player);
        let text = render_state(&game, Team::Player, None);
        for needle in [
            "── 局势 ──",
            "胜负条件:",
            "当前阶段:",
            "我方:",
            "敌方:",
            "对局结果:",
            "图例:",
            "── 战场态势 ──",
        ] {
            assert!(text.contains(needle), "快照缺少 {:?}:\n{}", needle, text);
        }
        // 我方单位行应包含血量上限与弹药
        assert!(text.contains("血2/2"), "应显示血量上限:\n{}", text);
        assert!(text.contains("弹42/42"), "坦克应显示主炮弹药:\n{}", text);
    }

    /// 坐标是「列,行」两个数字：第 27 列也必须能解析（旧实现用字母，
    /// 第 26/27 列会同标签，输入与显示不一致）。
    #[test]
    fn numeric_coordinates_round_trip_and_parse_last_column() {
        let game = GameState::new_seeded_level(3, Level::OpenField);
        for col in 0..game.map.cols {
            for row in 0..game.map.rows {
                let h = hex::axial_from_offset(col, row);
                let label = hex::hex_label(h);
                assert_eq!(
                    parse_hex(&game, &label),
                    Some(h),
                    "标签 {} 应能解析回原格",
                    label
                );
            }
        }
        // 第 27 列（最右列）标签必须是 "27,x"，而不是被截断/重复的字母
        let last_col = hex::axial_from_offset(game.map.cols - 1, 0);
        assert_eq!(hex::hex_label(last_col), format!("{},1", game.map.cols));
    }

    /// `s 10` 不能被静默当成 `s 1`（旧实现取首字符，会选错单位）。
    #[test]
    fn multi_char_label_is_rejected_instead_of_truncated() {
        let mut game = GameState::new_seeded_level(3, Level::OpenField);
        game.begin_turn(Team::Player);
        let mut session = PlayerSession::default();
        let out = execute_command(&mut game, Team::Player, &mut session, "s 10");
        let text = out.messages.join("\n");
        assert!(text.contains("单个字符"), "应明确报错而不是截断: {}", text);
        assert!(session.selected.is_none(), "不应选中任何单位: {:?}", session.selected);
    }

    /// 大写裸标签是"选择单位"，不能因为 to_lowercase 变成结束回合。
    #[test]
    fn uppercase_bare_letter_selects_unit_and_does_not_end_turn() {
        let mut game = GameState::new_seeded_level(3, Level::OpenField);
        game.begin_turn(Team::Player);
        let mut session = PlayerSession::default();
        // 找一个蓝方单位的标签
        let label = game.units_of(Team::Player)[0].label;
        let out = execute_command(&mut game, Team::Player, &mut session, &label.to_string());
        assert!(!out.end_turn, "大写标签不应结束回合");
        assert!(session.selected.is_some(), "应选中单位 {}", label);
        let text = out.messages.join("\n");
        assert!(text.contains("已选择"), "{}", text);
    }

    /// 压制生效时，本方视角必须看得到原因（否则只表现为"行动次数凭空消失"）。
    #[test]
    fn suppression_is_reported_to_the_affected_team() {
        let mut game = GameState::new_seeded_level(3, Level::OpenField);
        game.begin_turn(Team::Player);
        let pos = game.units_of(Team::Player)[0].pos;
        if let Some(u) = game.unit_at_mut(pos) {
            u.suppression_stacks = 1;
        }
        game.begin_turn(Team::Player);
        let text = render_state(&game, Team::Player, None);
        assert!(text.contains("本回合提示"), "应显示回合内提示:\n{}", text);
        assert!(text.contains("压制生效"), "应说明压制生效:\n{}", text);
    }

    /// 结构化战报按阵营视角渲染：受害方看到 [战损]，加害方看到 [战果]。
    #[test]
    fn battle_event_lines_are_side_aware() {
        let mut game = GameState::new_seeded_level(3, Level::OpenField);
        game.battle_events.push(BattleEvent {
            seq: 1,
            turn: 4,
            kind: BattleEventKind::Kill(KillEvent {
                turn: 4,
                victim_team: Team::Player,
                victim_label: 'K',
                victim_kind: UnitKind::AaLauncher,
                victim_pos: hex::axial_from_offset(10, 0),
                passenger: false,
                attacker_team: Some(Team::Ai),
                attacker_label: Some('6'),
                attacker_kind: Some(UnitKind::Howitzer),
                attacker_pos: Some(hex::axial_from_offset(25, 0)),
                cause: KillCause::Artillery,
            }),
        });
        let blue = render_battle_events(&game, Team::Player, 0);
        assert_eq!(blue.len(), 1);
        assert!(blue[0].starts_with("[战损]"), "{}", blue[0]);
        assert!(blue[0].contains("K(悍马-Stinger)"), "{}", blue[0]);
        assert!(blue[0].contains("红方 6(榴弹炮)"), "{}", blue[0]);
        let red = render_battle_events(&game, Team::Ai, 0);
        assert!(red[0].starts_with("[战果]"), "{}", red[0]);
        // 序号过滤：已发送的事件不再重复
        assert!(render_battle_events(&game, Team::Player, 1).is_empty());

        // 据点易手与胜负判定同样按视角渲染
        game.battle_events.push(BattleEvent {
            seq: 2,
            turn: 5,
            kind: BattleEventKind::Keypoint {
                hex: hex::axial_from_offset(10, 0),
                center: true,
                from: Team::Ai,
                to: Team::Player,
                by_label: 'B',
                by_kind: UnitKind::Rifleman,
            },
        });
        game.battle_events.push(BattleEvent {
            seq: 3,
            turn: 5,
            kind: BattleEventKind::Victory {
                winner: Team::Ai,
                reason: "蓝方全灭".to_string(),
            },
        });
        let blue = render_battle_events(&game, Team::Player, 1);
        assert!(blue.iter().any(|l| l.starts_with("[据点]") && l.contains("占领了红方")), "{:?}", blue);
        assert!(blue.iter().any(|l| l.starts_with("[胜负]") && l.contains("你方失败")), "{:?}", blue);
        let red = render_battle_events(&game, Team::Ai, 1);
        assert!(red.iter().any(|l| l.starts_with("[据点]") && l.contains("夺占了红方")), "{:?}", red);
        assert!(red.iter().any(|l| l.starts_with("[胜负]") && l.contains("你方获胜")), "{:?}", red);
    }

    /// 未侦察到的敌方单位不得在文本地图上泄露真实位置（只能靠幽灵标记）。
    #[test]
    fn render_map_does_not_leak_hidden_enemy_positions() {        let mut game = GameState::new_seeded_level(5, Level::OpenField);
        game.begin_turn(Team::Player);
        game.ghosts.clear();
        let far = hex::axial_from_offset(26, 12); // 地图右下角：远离蓝方视野
        let mut foe = Unit::new(UnitKind::Tank, Team::Ai, far);
        foe.label = '1';
        game.units.insert(far, foe);
        let map = render_map(&game, Team::Player, None);
        assert!(
            !map.contains('?'),
            "从未侦察过敌人时地图不应出现 ? 标记:\n{}",
            map
        );
        // 敌人确实存在：不应出现在敌方部队列表里
        let text = render_state(&game, Team::Player, None);
        assert!(
            !text.contains("1(坦克)"),
            "隐藏敌人不应出现在敌方列表:\n{}",
            text
        );
        // 一旦侦察到（记录幽灵），离开视野后才显示 ? 最后已知位置
        let near = hex::axial_from_offset(24, 12);
        let mut mine = Unit::new(UnitKind::Scout, Team::Player, near); // 视野 8
        mine.label = 'S';
        game.units.insert(near, mine);
        game.refresh_ghosts(Team::Player);
        assert!(
            game.ghosts[&Team::Player].contains_key(&far),
            "侦察兵进入视野后应记录幽灵"
        );
        game.units.remove(&near);
        game.refresh_ghosts(Team::Player);
        let map2 = render_map(&game, Team::Player, None);
        assert!(
            map2.contains('?'),
            "侦察过的敌人离开视野后应显示最后已知位置:\n{}",
            map2
        );
    }

    #[test]
    fn parse_args_defaults_to_gui() {
        match parse_args(Vec::<String>::new()) {
            CliAction::RunGui(cfg) => {
                assert_eq!(cfg.initial_control, LocalControl::Both);
                assert!(cfg.listen_addr.is_some());
            }
            _ => panic!("expected gui"),
        }
    }

    #[test]
    fn local_control_roundtrip() {
        for c in [
            LocalControl::Both,
            LocalControl::Blue,
            LocalControl::Red,
            LocalControl::Spectator,
        ] {
            assert_eq!(LocalControl::from_teams(&c.teams()), c);
        }
    }

    #[test]
    fn command_interpreter_moves_and_renders() {
        let mut game = GameState::new_seeded_level(7, Level::OpenField);
        game.begin_turn(Team::Player);
        let mut session = PlayerSession::default();
        let start = game.units_of(Team::Player)[0].pos;
        let label = game.units_of(Team::Player)[0].label;
        let select = execute_command(&mut game, Team::Player, &mut session, &format!("s {}", label));
        assert!(select.messages[0].contains("已选择"));
        assert_eq!(session.selected, Some(start));
        let text = render_state(&game, Team::Player, session.selected);
        assert!(text.contains("战场态势"));
        assert!(text.contains("命令"));
    }

    /// 终端 `dp` 命令族：第 1 回合在出发区域招募，第 2 回合起只能在大本营周围；
    /// 招募/部署都不触发自动结束回合。
#[test]
    fn deploy_command_uses_recruit_phases() {
        let mut game = GameState::new_sustain_multiplayer(11, Level::OpenField);
        assert!(game.units.is_empty(), "多人开局不预置棋子");
        game.map.obstacles.clear();
        game.map.water.clear();
        game.map.forests.clear();
        game.map.buildings.clear();
        game.start_sustain_multiplayer(10, 10, 100, 100);
        game.begin_turn(Team::Player);
        let mut session = PlayerSession::default();

        // dp（无参数）→ 第 1 回合的招募区域/点数/用法
        let info = execute_command(&mut game, Team::Player, &mut session, "dp");
        let text = info.messages.join("\n");
        assert!(text.contains("招募（第 1 回合）"), "{}", text);
        assert!(text.contains("出发区域"), "{}", text);
        assert!(text.contains("剩余 110 点"), "{}", text);
        assert!(text.contains("每回合 +10"), "{}", text);
        assert!(text.contains("dp <兵种|编号> <格>"), "{}", text);

        // dp list → 兵种清单（含编号与费用）
        let list = execute_command(&mut game, Team::Player, &mut session, "dp list");
        let text = list.messages.join("\n");
        assert!(text.contains("坦克"), "{}", text);
        assert!(text.contains("24 点"), "{}", text);

        // 第 1 回合：在出发区域招募（本回合即可行动）
        let zone_hex = hex::axial_from_offset(1, 1);
        let pts_before = game.recruit_points.get(&Team::Player).copied().unwrap();
        let cmd = format!("dp 坦克 {}", hex::hex_label(zone_hex));
        let deployed = execute_command(&mut game, Team::Player, &mut session, &cmd);
        let text = deployed.messages.join("\n");
        assert!(text.contains("招募"), "{}", text);
        assert!(text.contains("本回合即可行动"), "{}", text);
        assert!(deployed.changed, "招募应标记状态变化");
        assert!(deployed.no_auto_end, "招募不应触发自动结束回合");
        let u = game.unit_at(zone_hex).expect("招募后该格应有单位");
        assert_eq!(u.kind, UnitKind::Tank);
        assert!(u.actions_left > 0, "第 1 回合招募的单位可行动");
        assert_eq!(
            game.recruit_points.get(&Team::Player).copied().unwrap(),
            pts_before - UnitKind::Tank.recruit_cost()
        );
        // 出发区域之外（地图中部）不能招募
        let outside = format!("dp 1 {}", hex::hex_label(hex::axial_from_offset(13, 6)));
        let denied = execute_command(&mut game, Team::Player, &mut session, &outside);
        assert!(denied.messages.join("\n").contains("出发区域"), "{}", denied.messages.join("\n"));

        // 第 2 回合：出发区域关闭，只能在大本营周围 2 格内（当回合不可行动）
        game.begin_turn(Team::Ai);
        game.begin_turn(Team::Player);
        assert_eq!(game.turn, 2);
        let hq = game.hq_pos(Team::Player).expect("sustain 模式应设立大本营");
        // 出发区域内、离大本营超过 2 格的空格：第 2 回合应被拒绝
        let far_zone = game
            .deploy_zone(Team::Player)
            .iter()
            .flat_map(|c| (0..game.map.rows).map(move |r| (*c, r)))
            .map(|(c, r)| hex::axial_from_offset(c, r))
            .find(|h| {
                game.map.contains(*h) && Hex::distance(*h, hq) > 2 && game.unit_at(*h).is_none()
            })
            .expect("出发区域内应有远离大本营的空格");
        let zone_cmd = format!("dp 1 {}", hex::hex_label(far_zone));
        let closed = execute_command(&mut game, Team::Player, &mut session, &zone_cmd);
        assert!(closed.messages.join("\n").contains("2 格"), "{}", closed.messages.join("\n"));
        let spot = hq
            .neighbors()
            .into_iter()
            .find(|h| game.map.contains(*h) && game.unit_at(*h).is_none())
            .expect("大本营旁应有空格");
        let cmd2 = format!("dp 坦克 {}", hex::hex_label(spot));
        let second = execute_command(&mut game, Team::Player, &mut session, &cmd2);
        let text2 = second.messages.join("\n");
        assert!(text2.contains("增援部署"), "{}", text2);
        assert!(text2.contains("本回合不可行动"), "{}", text2);
        assert_eq!(game.unit_at(spot).expect("应已部署").actions_left, 0);

        // 编号同样可用；预置部队经典对局明确拒绝招募
        let by_index = execute_command(&mut game, Team::Player, &mut session, "dp 1");
        assert!(by_index.messages.join("\n").contains("用法"), "{}", by_index.messages.join("\n"));
        let mut classic = GameState::new_seeded_level(11, Level::OpenField);
        classic.begin_turn(Team::Player);
        let denied = execute_command(&mut classic, Team::Player, &mut session, "dp");
        assert!(denied.messages.join("\n").contains("未启用招募"), "{}", denied.messages.join("\n"));
    }

    /// 观战快照必须暴露 sustain 模式的部署点数、每回合收入与大本营，
    /// 供控制管线在提示词与观战视图里显示。
    #[test]
    fn spectator_snapshot_exposes_sustain_points() {
        let mut game = GameState::new_sustain_multiplayer(13, Level::OpenField);
        game.start_sustain_multiplayer(10, 20, 70, 55);
        game.begin_turn(Team::Player);
        let snap = spectator_snapshot(&game, None);
        assert_eq!(snap["sustain"], serde_json::json!(true));
        assert_eq!(snap["recruit_mode"], serde_json::json!(true));
        assert_eq!(snap["recruit_zone_turn"], serde_json::json!(1));
        assert_eq!(snap["units"].as_array().unwrap().len(), 0, "空地图开局");
        assert_eq!(snap["sustain_per_turn"]["blue"], serde_json::json!(10));
        assert_eq!(snap["sustain_per_turn"]["red"], serde_json::json!(20));
        assert_eq!(snap["teams"]["blue"]["points"], serde_json::json!(80));
        assert_eq!(snap["teams"]["red"]["points"], serde_json::json!(75));
        assert_eq!(snap["teams"]["blue"]["points_per_turn"], serde_json::json!(10));
        assert!(snap["teams"]["blue"]["hq"].is_string());
        assert!(snap["teams"]["red"]["hq"].is_string());
    }

    #[test]
    fn parse_args_reads_sustain_flags() {
        // 多人默认持续部署（空地图招募），双方点数对称 10/10
        match parse_args(Vec::<String>::new()) {
            CliAction::RunGui(cfg) => {
                let sc = cfg.sustain.expect("多人默认开启持续部署");
                assert_eq!(sc.player_per_turn, 10);
                assert_eq!(sc.ai_per_turn, 10);
            }
            _ => panic!("expected gui"),
        }
        // --no-sustain 回退到预置部队经典快速开局
        match parse_args(vec!["--no-sustain".to_string()]) {
            CliAction::RunGui(cfg) => assert!(cfg.sustain.is_none()),
            _ => panic!("expected gui"),
        }
        let args = vec![
            "--sustain".to_string(),
            "--sustain-pp".to_string(),
            "5".to_string(),
            "--sustain-ap".to_string(),
            "7".to_string(),
            "--sustain-points".to_string(),
            "30".to_string(),
        ];
        match parse_args(args) {
            CliAction::RunGui(cfg) => {
                let sc = cfg.sustain.expect("应解析出 sustain 配置");
                assert_eq!(sc.player_per_turn, 5);
                assert_eq!(sc.ai_per_turn, 7);
                assert_eq!(sc.player_points, Some(30));
                assert_eq!(sc.ai_points, Some(30));
            }
            _ => panic!("expected gui"),
        }
        // 只给 --sustain-pp 也视为开启，其余取默认值
        let args = vec!["--sustain-pp".to_string(), "3".to_string()];
        match parse_args(args) {
            CliAction::RunGui(cfg) => {
                let sc = cfg.sustain.expect("隐含 --sustain");
                assert_eq!(sc.player_per_turn, 3);
                assert_eq!(sc.ai_per_turn, 10);
                assert_eq!(sc.player_points, None);
            }
            _ => panic!("expected gui"),
        }
    }

    #[test]
    fn explicit_gui_team_is_not_taken_by_auto_client() {
        let gui_teams: BTreeSet<Team> = [Team::Ai].into_iter().collect();
        let hub = start_server("127.0.0.1:0", gui_teams, None).expect("server");
        let addr = hub.lock().unwrap().addr.clone();
        let stream = TcpStream::connect(&addr).expect("connect");
        stream
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        let mut write = stream.try_clone().unwrap();
        let mut read = BufReader::new(stream);
        write_json_line(&mut write, &ClientMessage::Hello { team: None }).unwrap();
        let mut line = String::new();
        read.read_line(&mut line).unwrap();
        let welcome: ServerMessage = serde_json::from_str(line.trim()).unwrap();
        match welcome {
            ServerMessage::Welcome { team, .. } => {
                assert_eq!(team, Team::Player, "GUI 保留红方时，终端应自动拿蓝方");
            }
            other => panic!("unexpected welcome: {:?}", other),
        }
        let after = hub.lock().unwrap().gui_teams.clone();
        assert!(after.contains(&Team::Ai), "GUI 红方不应被自动分配");
    }

    #[test]
    fn server_assigns_team_and_receives_commands() {
        let teams: BTreeSet<Team> = [Team::Player, Team::Ai].into_iter().collect();
        let hub = start_server("127.0.0.1:0", teams, None).expect("server");
        let addr = hub.lock().unwrap().addr.clone();
        let stream = TcpStream::connect(&addr).expect("connect");
        stream
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        let mut write = stream.try_clone().unwrap();
        let mut read = BufReader::new(stream);
        write_json_line(&mut write, &ClientMessage::Hello { team: None }).unwrap();
        let mut line = String::new();
        read.read_line(&mut line).unwrap();
        let welcome: ServerMessage = serde_json::from_str(line.trim()).unwrap();
        let assigned = match welcome {
            ServerMessage::Welcome { team, .. } => team,
            other => panic!("unexpected welcome: {:?}", other),
        };
        write_json_line(
            &mut write,
            &ClientMessage::Command {
                line: "h".to_string(),
            },
        )
        .unwrap();
        thread::sleep(Duration::from_millis(80));
        let incoming = hub.lock().unwrap().take_incoming();
        assert_eq!(incoming.len(), 1);
        assert_eq!(incoming[0].1, "h");
        assert!(hub.lock().unwrap().client_team(incoming[0].0).is_some());
        let gui_teams = hub.lock().unwrap().gui_teams.clone();
        assert!(!gui_teams.contains(&assigned));
    }

    /// 观战快照必须对监督进程"完备"：权威行动方/回合、双方全部单位、
    /// 全视野地图、结构化战报、损失统计、结果，都在同一份 JSON 里。
    #[test]
    fn spectator_snapshot_is_complete_for_supervisors() {
        let mut game = GameState::new_seeded_level(7, Level::OpenField);
        game.begin_turn(Team::Player);
        let snap = spectator_snapshot(&game, None);
        assert_eq!(snap["schema"], "hex_wargame.spectator.v1");
        assert_eq!(snap["turn"], 1);
        assert_eq!(snap["active_team"], "blue");
        assert_eq!(snap["over"], false);
        let units = snap["units"].as_array().expect("units array");
        let blue = units.iter().filter(|u| u["team"] == "blue").count();
        let red = units.iter().filter(|u| u["team"] == "red").count();
        assert!(blue > 0 && red > 0, "双方单位都应在快照里: {} / {}", blue, red);
        assert_eq!(snap["teams"]["blue"]["alive"], blue);
        assert_eq!(snap["teams"]["blue"]["lost"], 0);
        // 全视野地图：红方单位（蓝方视角看不到）也必须出现
        let map = snap["map"].as_str().expect("map text");
        assert!(!map.contains("\u{1b}"), "观战地图不应含 ANSI 颜色码");
        let red_label = units
            .iter()
            .find(|u| u["team"] == "red")
            .and_then(|u| u["label"].as_str())
            .unwrap()
            .chars()
            .next()
            .unwrap();
        assert!(map.contains(red_label), "全视野地图应显示红方单位 {}:\n{}", red_label, map);
        assert!(map.contains('▲') || map.contains('♣'), "应含地形符号");
        // 结束与战报字段
        assert_eq!(snap["events"].as_array().map(|a| a.len()), Some(0));
        assert_eq!(snap["result"], "");
    }

    /// 击毁事件会同时进入结构化战报、损失统计与终局结果。
    #[test]
    fn spectator_snapshot_reports_losses_and_result() {
        let mut game = GameState::new_seeded_level(7, Level::OpenField);
        game.begin_turn(Team::Player);
        game.battle_events.push(BattleEvent {
            seq: 1,
            turn: 3,
            kind: BattleEventKind::Kill(KillEvent {
                turn: 3,
                victim_team: Team::Ai,
                victim_label: '1',
                victim_kind: UnitKind::Tank,
                victim_pos: hex::axial_from_offset(20, 6),
                passenger: false,
                attacker_team: Some(Team::Player),
                attacker_label: Some('A'),
                attacker_kind: Some(UnitKind::Tank),
                attacker_pos: Some(hex::axial_from_offset(6, 6)),
                cause: KillCause::DirectFire,
            }),
        });
        game.battle_seq = 1;
        let snap = spectator_snapshot(&game, None);
        assert_eq!(snap["teams"]["red"]["lost"], 1);
        assert_eq!(snap["teams"]["blue"]["kills"], 1);
        let events = snap["events"].as_array().unwrap();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0]["kind"], "kill");
        let text = events[0]["text"].as_str().unwrap();
        assert!(text.contains("红方 1(坦克)") && text.contains("蓝方A(坦克)"), "{}", text);
        let over = spectator_snapshot(&game, Some("蓝方获胜（全歼红方）"));
        assert_eq!(over["over"], true);
        assert_eq!(over["result"], "蓝方获胜（全歼红方）");
    }

    /// 搭载中的步兵仍在编：存活统计必须把他算进去，否则"存活 13 · 已损失 0"
    /// 会自相矛盾（上车 ≠ 阵亡）。
    #[test]
    fn alive_count_includes_passengers() {
        let mut game = GameState::new_seeded_level(3, Level::OpenField);
        game.begin_turn(Team::Player);
        let before = game.alive_unit_count(Team::Player);
        let top_before = game.units_of(Team::Player).len();
        let mut pos = hex::axial_from_offset(0, 0);
        'outer: for r in 0..game.map.rows {
            for c in 0..game.map.cols {
                let h = hex::axial_from_offset(c, r);
                if game.unit_at(h).is_none() {
                    pos = h;
                    break 'outer;
                }
            }
        }
        let mut carrier = Unit::new(UnitKind::Ifv, Team::Player, pos);
        carrier.label = 'Z';
        let mut rider = Unit::new(UnitKind::Rifleman, Team::Player, pos);
        rider.label = 'Y';
        carrier.passengers.push(rider);
        game.units.insert(pos, carrier);
        assert_eq!(game.units_of(Team::Player).len(), top_before + 1);
        assert_eq!(game.alive_unit_count(Team::Player), before + 2, "车上步兵应计入存活");
        let text = render_state(&game, Team::Player, None);
        assert!(text.contains(&format!("我方: 存活 {} 个", before + 2)), "{}", text);
    }
}
