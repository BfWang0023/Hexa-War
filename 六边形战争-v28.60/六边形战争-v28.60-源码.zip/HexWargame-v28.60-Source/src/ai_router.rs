//! AI 版本路由：按 GameState.ai_version 在旧版（ai）与新版（ai_v2）之间分发。
//! 默认旧版；GUI/TUI 提供运行时切换，不破坏原有实现。

use crate::ai;
use crate::ai_v2;
use crate::game::{AiVersion, GameState};
use crate::unit::Team;

pub fn take_turn(game: &mut GameState, team: Team) -> Vec<String> {
    match game.ai_version {
        AiVersion::Legacy => ai::take_turn(game, team),
        AiVersion::V2 => ai_v2::take_turn(game, team),
    }
}

pub fn run_ai_turn(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    match game.ai_version {
        AiVersion::Legacy => ai::run_ai_turn(game, team, log),
        AiVersion::V2 => ai_v2::run_ai_turn(game, team, log),
    }
}

pub fn ai_deploy(game: &mut GameState, team: Team) -> Vec<String> {
    match game.ai_version {
        AiVersion::Legacy => ai::ai_deploy(game, team),
        AiVersion::V2 => ai_v2::ai_deploy(game, team),
    }
}
