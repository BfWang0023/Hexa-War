//! 六边形战争 · GUI 版（egui/eframe）。
//! 运行：cargo run （或 cargo run --bin hex_wargame）
//! 多人热座 / GUI+终端混合：cargo run --bin hex_wargame_multiplayer
//!
//! 操作方式：
//! - 左键点击己方单位：选中（显示属性与可行动范围）
//! - 选中后点击绿色格子：移动（消耗 1 次行动）
//! - 选中后点击红色高亮敌人：攻击（消耗攻击所需行动次数）
//! - 右键 / 点击空白：取消选择
//! - 按钮：结束该单位行动 / 结束回合 / 重新开始 / 帮助

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use eframe::egui;
use hex_wargame::ai_router;
use hex_wargame::game::{AiDifficulty, AiVersion, GameState, Level, SimulOrder, UiEvent};
use hex_wargame::hex::{self, Hex};
use hex_wargame::mapdef::CustomMap;
use hex_wargame::pieces;
use hex_wargame::unit::{Team, Unit, UnitKind};
use std::collections::{BTreeSet, HashMap};
use std::path::PathBuf;
use std::sync::Arc;

mod fx;
mod maptile;
#[allow(dead_code)]
mod mp;

/// 六边形外接半径（像素）。
const HEX_SIZE: f32 = 26.0;
/// 水平中心距：sqrt(3) * size
const HEX_W: f32 = 1.732_050_8 * HEX_SIZE;
/// 垂直中心距：1.5 * size
const HEX_H: f32 = 1.5 * HEX_SIZE;
/// 移动动画转弯宽度：以路径节点为中心、长度为 2*TURN_W 的路径参数窗口内
/// 完成上一段方向 → 下一段方向的平滑转向（单位：路径段数，需 < 0.5）。
const TURN_W: f32 = 0.35;

/// 视觉主题色板：统一的大地/植被/建筑/阵营/高亮配色。
mod theme {
    use eframe::egui::Color32;

    // 背景与棋盘底板
    pub const BG: Color32 = Color32::from_rgb(22, 26, 24);
    pub const BOARD_FILL: Color32 = Color32::from_rgb(31, 37, 32);
    pub const BOARD_STROKE: Color32 = Color32::from_rgb(62, 74, 62);

    // 地形
    pub const PLAIN: Color32 = Color32::from_rgb(60, 74, 52);
    pub const PLAIN_EDGE: Color32 = Color32::from_rgb(90, 106, 80);
    pub const FOREST: Color32 = Color32::from_rgb(45, 74, 44);
    pub const FOREST_EDGE: Color32 = Color32::from_rgb(78, 116, 70);
    pub const ROCK: Color32 = Color32::from_rgb(94, 92, 86);
    pub const WATER: Color32 = Color32::from_rgb(38, 82, 128);
    pub const WATER_EDGE: Color32 = Color32::from_rgb(92, 150, 200);
    pub const ROCK_EDGE: Color32 = Color32::from_rgb(128, 124, 114);
    pub const BUILDING: Color32 = Color32::from_rgb(110, 96, 74);
    pub const BUILDING_EDGE: Color32 = Color32::from_rgb(150, 132, 104);
    pub const ROAD: Color32 = Color32::from_rgb(86, 84, 80);
    pub const ROAD_EDGE: Color32 = Color32::from_rgb(122, 118, 110);
    pub const ROAD_MARK: Color32 = Color32::from_rgb(214, 196, 120);

    // 高亮
    pub const MOVE_FILL: Color32 = Color32::from_rgba_unmultiplied_const(90, 210, 120, 52);
    pub const MOVE_EDGE: Color32 = Color32::from_rgb(120, 235, 150);
    pub const ATTACK_FILL: Color32 = Color32::from_rgba_unmultiplied_const(235, 80, 70, 58);
    pub const ATTACK_EDGE: Color32 = Color32::from_rgb(255, 120, 105);
    pub const BOMB_FILL: Color32 = Color32::from_rgba_unmultiplied_const(240, 200, 80, 30);
    pub const BOMB_EDGE: Color32 = Color32::from_rgb(240, 205, 90);
    pub const BLAST_FILL: Color32 = Color32::from_rgba_unmultiplied_const(255, 150, 50, 52);
    pub const BLAST_EDGE: Color32 = Color32::from_rgb(255, 175, 80);
    pub const BLOCKED_EDGE: Color32 = Color32::from_rgba_unmultiplied_const(170, 170, 170, 140);

    // UI 点缀
    pub const ACCENT: Color32 = Color32::from_rgb(216, 196, 148);
    pub const ALLY_TEXT: Color32 = Color32::from_rgb(110, 190, 240);
    pub const ENEMY_TEXT: Color32 = Color32::from_rgb(240, 125, 110);
}

/// 日志按内容着色。
fn log_color(line: &str) -> egui::Color32 {
    if line.contains("——") {
        theme::ACCENT
    } else if line.starts_with('⚠') {
        egui::Color32::from_rgb(255, 190, 90)
    } else if line.contains("击毁") || line.contains("消灭") || line.contains("胜利") || line.contains("失败") {
        egui::Color32::from_rgb(255, 120, 100)
    } else if line.contains("命中") || line.contains("炮击") || line.contains("攻击") {
        egui::Color32::from_rgb(240, 160, 110)
    } else if line.contains("移动") || line.contains("搭载") || line.contains("下车") || line.contains("载入") || line.contains("放下") {
        egui::Color32::from_rgb(160, 210, 170)
    } else if line.contains("模式") {
        egui::Color32::from_rgb(240, 220, 140)
    } else {
        egui::Color32::from_rgb(198, 206, 198)
    }
}

fn main() -> eframe::Result {
    run_single_player_gui()
}

/// 多人热座可执行文件的入口（由 `src/bin/hex_wargame_multiplayer.rs` 调用）。
pub fn multiplayer_main() -> eframe::Result {
    main_multiplayer()
}

fn run_single_player_gui() -> eframe::Result {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1160.0, 840.0])
            .with_min_inner_size([960.0, 680.0])
            .with_title("六边形战争 · Hex Wargame"),
        ..Default::default()
    };
    eframe::run_native(
        "hex_wargame",
        options,
        Box::new(|cc| Ok(Box::new(GuiApp::new(cc)))),
    )
}

fn main_multiplayer() -> eframe::Result {
    match mp::parse_args(std::env::args().skip(1)) {
        mp::CliAction::RunGui(cfg) => run_multiplayer_gui(cfg),
        mp::CliAction::RunTui(cfg) => {
            if let Err(e) = mp::run_tui_client(cfg) {
                eprintln!("终端客户端错误: {}", e);
                std::process::exit(1);
            }
            std::process::exit(0);
        }
        mp::CliAction::Help(text) => {
            println!("{}", text);
            std::process::exit(0);
        }
        mp::CliAction::Error(e) => {
            eprintln!("参数错误: {}", e);
            eprintln!("{}", mp::help_text());
            std::process::exit(2);
        }
    }
}

fn run_multiplayer_gui(cfg: mp::GuiConfig) -> eframe::Result {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1160.0, 840.0])
            .with_min_inner_size([960.0, 680.0])
            .with_title("六边形战争 · 多人热座"),
        ..Default::default()
    };
    eframe::run_native(
        "hex_wargame_multiplayer",
        options,
        Box::new(move |cc| Ok(Box::new(GuiApp::new_multiplayer(cc, cfg.clone())))),
    )
}

struct GuiApp {
    game: GameState,
    selected: Option<Hex>,
    log: Vec<LogLine>,
    log_hover: Option<Hex>,
    game_over: Option<String>,
    show_help: bool,
    /// 待放下状态：记录要下车的步兵标签，等待点击落点
    pending_disembark: Option<char>,
    /// 地面载具装载模式（按 X 切换）：该模式下点击紧邻的己方可搭载单位上车，
    /// 且不能移动；未进入该模式时点击步兵不会装载。
    load_mode: bool,
    /// 补给模式（选中补给单位后按 S 进入）：点击半径 2 格内友军进行补给。
    supply_mode: bool,
    /// 榴弹炮模式：false=行动模式（点击移动），true=开火模式（点击炮击，按 T 切换）
    howitzer_fire_mode: bool,
    /// 二次确认（重新开始 / 结束回合）：记录点击时间，2 秒内再点一次才执行
    confirm_action: Option<(f64, ConfirmAction)>,
    /// 最近一条错误（顶栏展示 3 秒）
    last_error: Option<(f64, String)>,
    /// 0 行动单位点击提示去重：已提示过的选中格
    zero_hint: Option<Hex>,
    /// 同格双单位（地面+空中）时，点击是否要切到地面单位
    selected_is_air: bool,
    /// 当前帧时间（egui），用于错误提示计时
    time: f64,
    /// 我方视野内的格子（每帧重算，地形可见）
    revealed: BTreeSet<Hex>,
    /// 被我方侦察到的敌方单位格（含隐蔽判定）
    visible_enemies: BTreeSet<Hex>,
    /// 敌方单位最后已知位置（敌方离开视野后显示为淡色"?"标记）
    /// 敌方最后已知位置（灰雾图标）→ (兵种, 最后目击回合)；只保留 2 回合。
    /// **按阵营分开保存**：`--view acting` 下窗口在蓝/红视角之间切换，
    /// 若共用一份，就会把上一方的目击记录泄露给另一方。
    ghosts: HashMap<Team, HashMap<Hex, (UnitKind, i32)>>,
    /// 部署阶段：当前选中待放置的单位类型（点击出发区域放置）
    pending_recruit: Option<UnitKind>,
    /// 招募/部署阶段：当前运输单位要一并购入的初始搭载（按重量与兵种规则校验）
    pending_cargo: Vec<UnitKind>,
    /// 招募/部署阶段：搭载编辑区当前选择的货物兵种
    pending_cargo_kind: UnitKind,
    /// 榴弹炮烟雾弹待发射状态：true 时点击射程内格子发射烟雾弹
    smoke_shot_pending: bool,
    /// 当前关卡
    level: Level,
    /// 右侧面板是否展开（可折叠以便地图占满屏幕）
    panel_expanded: bool,
    /// 地图缩放系数（乘在自适应缩放上；滚轮调整）
    zoom: f32,
    /// 直射测距器模式（按 R 切换）：不可选棋，先后点两格查看距离/直射/命中率乘数
    ranger_mode: bool,
    /// 测距器已选起点格
    ranger_first: Option<Hex>,
    /// 测距器终点格（最近一次点击/悬停，用于画线）
    ranger_last: Option<Hex>,
    /// 同时攻击模式：进入后可点选多个己方单位并对敌人下达进攻命令，
    /// 按 C 或右侧按钮统一结算
    simul_mode: bool,
    /// 已下达的同时攻击命令（未结算前不消耗行动/弹药）
    simul_orders: Vec<SimulOrder>,
    /// 地图平移偏移（像素；按住右键拖动）
    pan: egui::Vec2,
    /// 每格到最近己方单位的 BFS 路程 + 视野（分层迷雾用）
    dist_map: HashMap<Hex, (i32, i32)>,
    /// 可持续部署模式开关（部署阶段设置；进入对局后不可改）
    sustain_mode: bool,
    /// 可持续部署：双方每回合获得的部署点数（部署阶段设置）
    sustain_pp: i32,
    sustain_ap: i32,
    /// 当前加载的自定义地图（Level::Custom 时用于重新开局/应用设置）
    custom_map: Option<CustomMap>,
    /// 单位朝向视图状态：(阵营, 标签) → 车身/炮塔朝向
    poses: HashMap<(Team, char), fx::Pose>,
    /// 进行中的移动滑行动画（终点真身由动画代画）
    move_anims: Vec<fx::MoveAnim>,
    /// 进行中的开火动画（瞄准/上肩 → 发射）
    fire_anims: Vec<FireAnim>,
    /// 本回合被击毁的单位：击毁弹落地前保持显示（避免棋子提前消失）
    pending_deaths: Vec<PendingDeath>,
    /// 飞行弹道/曳光/爆炸/烟团特效
    effects: Vec<fx::Effect>,
    /// 阵亡士兵尸体（变灰 2 秒后淡出）
    corpses: Vec<fx::Corpses>,
    /// 被毁载具残骸（爆炸 → 变灰 → 淡出）
    wrecks: Vec<fx::Wreck>,
    /// 被击中未击毁的载具冒烟
    smokers: Vec<fx::Smoker>,
    /// 动画调度时钟：批量事件错峰排队
    fx_clock: f64,
    /// 当前帧地图原点与格半径（供动画把格坐标换算为像素）
    map_origin: egui::Pos2,
    map_hs: f32,
    map_s: f32,
    /// 临时特效演示待触发（HEX_WARGAME_FX_DEMO 截图验证用）
    fx_demo_pending: bool,
    /// 烘焙好的静态地图层（地形+装饰+迷雾 → 1 个 Mesh/帧）
    map_layer: Option<maptile::MapLayer>,

    // ---------- 多人热座模式（hex_wargame_multiplayer） ----------
    /// 是否运行在多人热座模式。
    multiplayer: bool,
    /// GUI 本地控制哪些阵营（终端客户端连接后会动态接管）。
    local_control: mp::LocalControl,
    /// 终端连接中心；None 表示纯本地模式。
    net: Option<Arc<std::sync::Mutex<mp::NetHub>>>,
    /// 每个终端客户端的选择状态（按连接 id 保存）。
    net_sessions: HashMap<u64, mp::PlayerSession>,
    /// 本帧是否有需要推送给终端客户端的画面变化。
    net_dirty: bool,
    /// 已推送给终端客户端的结构化战报事件序号（击毁/据点/胜负）。
    /// 每帧检查新事件并逐条播报，保证被击毁方也能即时看到自己的战损。
    net_event_seq: u32,
    /// 对局结束后是否已自动导出日志（避免重复写文件）。
    auto_log_done: bool,
    /// 观战快照文件路径（`--state-file`）：每当局势变化原子写出一份完整快照。
    state_file: Option<String>,
    /// 上次写出快照时的状态签名，用于只在真正变化时写盘。
    state_sig: Option<(i32, Team, usize, u32, bool, u64)>,
    /// 图形界面主机的视野模式（`--view`）。`Acting` 时窗口只渲染当前行动方
    /// 的迷雾视野，并隐藏对方玩家的私有命令回显。
    view_mode: mp::ViewMode,
    /// 已设置的窗口标题，避免每帧重复发送 Title 指令。
    last_title: Option<String>,

    // ---------- AI 回合异步计算 / 状态标记 ----------
    /// 后台线程正在计算的 AI 回合：完成后返回（新局面, AI 行动日志）。
    /// 放到后台是为了让玩家最后一道指令的动画先播完、并显示"AI 思考中"，
    /// 而不是单击后整段卡住。
    ai_thread: Option<std::thread::JoinHandle<(GameState, Vec<String>)>>,
    /// AI 开始思考的时间（`self.time`）。
    ai_think_start: Option<f64>,
    /// AI 思考耗时（秒）：Some 表示已算完、正在播放其行动。
    ai_think_elapsed: Option<f64>,
    /// AI 行动播放阶段：期间屏蔽玩家输入、标记显示"AI 已思考"。
    ai_playback: bool,
}

/// 一行战斗日志。`team` 为 `Some` 表示这行只属于该阵营的私有信息
/// （终端玩家的命令回显），`--view acting` 下不显示给另一方。
struct LogLine {
    team: Option<Team>,
    text: String,
}

/// 一次开火动画：事件 + 时序（瞄准 → 离膛 → 飞行）。
struct FireAnim {
    ev: hex_wargame::game::UiFireEvent,
    start: f64,
    launch: f64,
    flight: f64,
    launched: bool,
}

/// 本回合被击毁的单位：游戏状态已将其移除，但画面上保持到击毁弹落地，
/// 由落地的尸体/残骸动画接管（保证「先看到被击毁，棋子才消失」）。
struct PendingDeath {
    hex: Hex,
    unit: Unit,
    is_air: bool,
    land_at: f64,
}

/// 二次确认的动作类型。
#[derive(Clone, Copy, PartialEq)]
enum ConfirmAction {
    Restart,
    EndTurn,
}

impl GuiApp {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        install_cjk_fonts(&cc.egui_ctx);
        apply_theme(&cc.egui_ctx);
        let mut app = GuiApp {
            game: GameState::new(),
            selected: None,
            log: Vec::new(),
            log_hover: None,
            game_over: None,
            show_help: false,
            pending_disembark: None,
            load_mode: false,
            supply_mode: false,
            howitzer_fire_mode: false,
            confirm_action: None,
            last_error: None,
            zero_hint: None,
            selected_is_air: true,
            time: 0.0,
            revealed: BTreeSet::new(),
            visible_enemies: BTreeSet::new(),
            ghosts: HashMap::new(),
            pending_recruit: None,
            pending_cargo: Vec::new(),
            pending_cargo_kind: UnitKind::Rifleman,
            smoke_shot_pending: false,
            level: Level::OpenField,
            panel_expanded: true,
            zoom: 1.0,
            pan: egui::Vec2::ZERO,
            ranger_mode: false,
            ranger_first: None,
            ranger_last: None,
            simul_mode: false,
            simul_orders: Vec::new(),
            dist_map: HashMap::new(),
            sustain_mode: true, // 默认勾选持续部署，开局即进入
            sustain_pp: 10,
            sustain_ap: 20,
            custom_map: None,
            poses: HashMap::new(),
            move_anims: Vec::new(),
            fire_anims: Vec::new(),
            pending_deaths: Vec::new(),
            effects: Vec::new(),
            corpses: Vec::new(),
            wrecks: Vec::new(),
            smokers: Vec::new(),
            fx_clock: 0.0,
            map_origin: egui::pos2(0.0, 0.0),
            map_hs: 26.0,
            map_s: 1.0,
            fx_demo_pending: false,
            map_layer: None,
            multiplayer: false,
            local_control: mp::LocalControl::Blue,
            net: None,
            net_sessions: HashMap::new(),
            net_dirty: false,
            net_event_seq: 0,
            auto_log_done: false,
            state_file: None,
            state_sig: None,
            view_mode: mp::ViewMode::Spectator,
            last_title: None,
            ai_thread: None,
            ai_think_start: None,
            ai_think_elapsed: None,
            ai_playback: false,
        };
        app.game = if std::env::var_os("HEX_WARGAME_BATTLE").is_some() {
            // 调试：直接进入战斗状态（跳过部署），便于检查棋子绘制
            GameState::new_seeded(rand::random())
        } else {
            GameState::new_deploy_level(rand::random(), app.level)
        };
        app.apply_sustain_settings();
        if std::env::var_os("HEX_WARGAME_BATTLE").is_some() {
            app.log.push(LogLine {
                team: None,
                text: "—— 战斗状态（HEX_WARGAME_BATTLE 调试模式）——".into(),
            });
            // 临时特效演示：1 秒后自动触发一组开火（截图验证用）
            if std::env::var_os("HEX_WARGAME_FX_DEMO").is_some() {
                app.fx_demo_pending = true;
            }
        } else {
            app.log.push(LogLine {
                team: None,
                text: "—— 第 0 回合 · 部署阶段 ——
用招募点数挑选单位，点击己方出发区域放置。"
                    .into(),
            });
        }
        app
    }

    /// 多人热座模式初始化：直接进入已部署战斗状态，双方均为人类。
    fn new_multiplayer(cc: &eframe::CreationContext<'_>, cfg: mp::GuiConfig) -> Self {
        let mut app = Self::new(cc);
        app.multiplayer = true;
        app.local_control = cfg.initial_control;
        app.view_mode = cfg.view;
        app.sustain_mode = false;
        app.sustain_pp = 0;
        app.sustain_ap = 0;
        app.level = cfg.level;
        // 多人默认持续部署：**空地图开局**（双方全部单位都要自行招募）+ 双方大本营
        // 关键据点 + 每回合部署点数；`--no-sustain` 才是旧的预置部队经典快速开局。
        app.game = match cfg.sustain {
            Some(sc) => {
                let mut g = GameState::new_sustain_multiplayer(cfg.seed, cfg.level);
                let pp = sc.player_points.unwrap_or_else(|| {
                    g.recruit_points.get(&Team::Player).copied().unwrap_or(100)
                });
                let ap = sc.ai_points.unwrap_or_else(|| {
                    g.recruit_points.get(&Team::Ai).copied().unwrap_or(100)
                });
                g.start_sustain_multiplayer(sc.player_per_turn, sc.ai_per_turn, pp, ap);
                app.sustain_mode = true;
                app.sustain_pp = sc.player_per_turn;
                app.sustain_ap = sc.ai_per_turn;
                g
            }
            None => {
                app.sustain_mode = false;
                app.sustain_pp = 0;
                app.sustain_ap = 0;
                GameState::new_seeded_level(cfg.seed, cfg.level)
            }
        };
        app.game.begin_turn(Team::Player);

        // 清掉单机初始化留下的部署提示与动画状态。
        app.log.clear();
        app.selected = None;
        app.selected_is_air = true;
        app.pending_recruit = None;
        app.smoke_shot_pending = false;
        app.howitzer_fire_mode = false;
        app.ranger_mode = false;
        app.ranger_first = None;
        app.ranger_last = None;
        app.simul_mode = false;
        app.simul_orders.clear();
        app.pending_disembark = None;
        app.load_mode = false;
        app.supply_mode = false;
        app.game_over = None;
        app.confirm_action = None;
        app.last_error = None;
        app.zero_hint = None;
        app.ghosts.clear();
        app.poses.clear();
        app.move_anims.clear();
        app.fire_anims.clear();
        app.pending_deaths.clear();
        app.effects.clear();
        app.corpses.clear();
        app.wrecks.clear();
        app.smokers.clear();
        app.fx_clock = 0.0;
        app.fx_demo_pending = false;
        app.map_layer = None;
        app.log(format!(
            "—— 多人热座 · 第 1 回合 · {}方行动 ——",
            mp::team_label(Team::Player)
        ));
        if app.sustain_mode {
            app.log(format!(
                "♾ 持续部署：空地图开局，双方所有单位都要自行招募；每回合 +{}（蓝）/ +{}（红）点",
                app.sustain_pp, app.sustain_ap
            ));
            app.log(
                "第 1 回合可在本方出发区域任意空格招募（招募的单位本回合即可行动）；第 2 回合起只能在大本营周围 2 格内（当回合不可行动）。终端用 dp 命令，GUI 按 D。"
                    .into(),
            );
        }
        app.log(
            "默认本地可同时操作蓝、红双方；终端玩家连接后会接管对应阵营，GUI 自动变为其余阵营或观战。"
                .into(),
        );

        if let Some(addr) = cfg.listen_addr {
            match mp::start_server(
                &addr,
                cfg.initial_control.teams(),
                Some(cc.egui_ctx.clone()),
            ) {
                Ok(hub) => {
                    let actual = hub.lock().map(|h| h.addr.clone()).unwrap_or(addr);
                    app.log(format!("🌐 终端玩家可连接: {}", actual));
                    app.net = Some(hub);
                }
                Err(e) => app.log(format!("⚠ 启动终端监听失败: {}", e)),
            }
        }
        if let Some(path) = cfg.state_file {
            app.state_file = Some(path.clone());
            app.write_spectator_state();
            app.log(format!("👁 观战快照: {}", path));
        }
        app
    }

    /// 临时特效演示（HEX_WARGAME_FX_DEMO=1）：在出生点旁放置几个目标并
    /// 依次开火，覆盖步枪曳光/坦克炮/Javelin 导弹/火箭筒上肩/榴弹炮覆盖。
    fn run_fx_demo(&mut self) {
        use hex_wargame::hex as hx;
        let place = |g: &mut GameState, col: i32, row: i32, kind: UnitKind, team: Team, label: char| {
            let h = hx::axial_from_offset(col, row);
            let mut u = Unit::new(kind, team, h);
            u.label = label;
            g.units.insert(h, u);
        };
        // 目标（敌方）
        place(&mut self.game, 3, 3, UnitKind::Rifleman, Team::Ai, 'x');
        place(&mut self.game, 2, 4, UnitKind::Rifleman, Team::Ai, 'y');
        place(&mut self.game, 4, 6, UnitKind::Tank, Team::Ai, 'z');
        place(&mut self.game, 2, 6, UnitKind::Rifleman, Team::Ai, 'w');
        // 我方特战小队（演示火箭筒上肩）
        place(&mut self.game, 0, 6, UnitKind::SpecialForces, Team::Player, 'Z');
        if let Some(sf) = self.game.units.get_mut(&hx::axial_from_offset(0, 6)) {
            sf.missile_mode = true;
        }
        let at = |_g: &GameState, col: i32, row: i32| hx::axial_from_offset(col, row);
        // 补足行动/弹药，循环攻击直至命中（保证演示出效果）
        let mut amp = self.game.units.get(&at(&self.game, 0, 4)).cloned();
        if let Some(u) = amp.as_mut() {
            u.actions_left = 12;
        }
        if let Some(u) = self.game.units.get_mut(&at(&self.game, 0, 4)) {
            *u = amp.unwrap();
        }
        // A 坦克 → z 坦克（击毁 → 爆炸 + 残骸）
        for _ in 0..6 {
            match self.game.attack(at(&self.game, 1, 3), at(&self.game, 4, 6)) {
                Ok(o) if o.hit && !o.blocked => break,
                Ok(_) => {
                    if let Some(u) = self.game.units.get_mut(&at(&self.game, 1, 3)) {
                        u.actions_left += 1;
                        u.ammo += 1;
                    }
                }
                Err(_) => break,
            }
        }
        // B 步枪 → y 步枪班（曳光 + 士兵变灰）
        for _ in 0..8 {
            match self.game.attack(at(&self.game, 0, 3), at(&self.game, 2, 4)) {
                Ok(o) if o.hit => break,
                Ok(_) => {
                    if let Some(u) = self.game.units.get_mut(&at(&self.game, 0, 3)) {
                        u.actions_left += 1;
                        u.ammo += 1;
                    }
                }
                Err(_) => break,
            }
        }
        // C Javelin → z 坦克（高抛弹道，命中 → 爆炸/冒烟）
        for _ in 0..6 {
            match self.game.attack(at(&self.game, 0, 4), at(&self.game, 4, 6)) {
                Ok(o) if o.hit && !o.blocked => break,
                Ok(_) => {
                    if let Some(u) = self.game.units.get_mut(&at(&self.game, 0, 4)) {
                        u.actions_left += 1;
                        u.ammo += 1;
                    }
                }
                Err(_) => break,
            }
        }
        // Z 特战火箭筒 → w 步枪班（上肩动画 + 火箭）
        for _ in 0..8 {
            match self.game.attack(at(&self.game, 0, 6), at(&self.game, 2, 6)) {
                Ok(o) if o.hit => break,
                Ok(_) => {
                    if let Some(u) = self.game.units.get_mut(&at(&self.game, 0, 6)) {
                        u.actions_left += 1;
                        u.missile_ammo += 1;
                    }
                }
                Err(_) => break,
            }
        }
        // F 榴弹炮覆盖炮击（7 格爆炸）
        let _ = self.game.deploy(at(&self.game, 0, 0));
        if let Some(u) = self.game.units.get_mut(&at(&self.game, 0, 0)) {
            u.actions_left += 1;
            u.ammo += 1;
        }
        let _ = self.game.attack(at(&self.game, 0, 0), at(&self.game, 5, 4));
        self.log("🎬 特效演示：坦克炮/步枪/Javelin/火箭筒/榴弹炮".into());
    }

    fn restart(&mut self) {
        // 自定义地图用保存的 CustomMap 重建（new_deploy_level 会把 Custom 变成空地图）
        let ai_version = self.game.ai_version;
        let ai_difficulty = self.game.ai_difficulty;
        self.game = if self.multiplayer {
            // 多人重开保持模式：持续部署仍是空地图开局（据点重新随机、点数回初始值）；
            // --no-sustain 的经典快速开局仍用预置部队。
            let mut g = if self.sustain_mode {
                GameState::new_sustain_multiplayer(rand::random(), self.level)
            } else {
                GameState::new_seeded_level(rand::random(), self.level)
            };
            if self.sustain_mode {
                let pp = self.game.initial_points.get(&Team::Player).copied().unwrap_or(100);
                let ap = self.game.initial_points.get(&Team::Ai).copied().unwrap_or(100);
                g.start_sustain_multiplayer(self.sustain_pp, self.sustain_ap, pp, ap);
            }
            g.begin_turn(Team::Player);
            g
        } else if self.level == Level::Custom {
            match self.custom_map.clone() {
                Some(cm) => GameState::new_custom_deploy(rand::random(), cm),
                None => GameState::new_deploy_level(rand::random(), self.level),
            }
        } else {
            GameState::new_deploy_level(rand::random(), self.level)
        };
        self.game.ai_version = ai_version;
        self.game.ai_difficulty = ai_difficulty;
        // 创建新对局**后**应用可持续部署设置（此前顺序颠倒导致设置丢失）
        if !self.multiplayer {
            self.apply_sustain_settings();
        }
        self.selected = None;
        self.log.clear();
        self.revealed = BTreeSet::new();
        self.visible_enemies = BTreeSet::new();
        self.ghosts = HashMap::new();
        self.pending_recruit = None;
        self.smoke_shot_pending = false;
        if !self.multiplayer {
            self.log("—— 第 0 回合 · 部署阶段 ——
用招募点数挑选单位，点击己方出发区域放置。"
                .into());
        }
        self.log_hover = None;
        self.game_over = None;
        self.pending_disembark = None;
        self.load_mode = false;
        self.supply_mode = false;
        self.show_help = false;
        self.howitzer_fire_mode = false;
        self.confirm_action = None;
        self.last_error = None;
        self.zero_hint = None;
        self.selected_is_air = true;
        self.zoom = 1.0;
        self.pan = egui::Vec2::ZERO;
        self.ranger_mode = false;
        self.ranger_first = None;
        self.ranger_last = None;
        self.simul_mode = false;
        self.simul_orders.clear();
        if self.multiplayer {
            self.net_sessions.clear();
        }
        self.time = 0.0;
        // 清空战斗动画视图状态
        self.poses.clear();
        self.move_anims.clear();
        self.fire_anims.clear();
        self.pending_deaths.clear();
        self.effects.clear();
        self.corpses.clear();
        self.wrecks.clear();
        self.smokers.clear();
        self.fx_clock = 0.0;
        // 取消/丢弃正在进行的 AI 后台回合，避免旧线程结果污染新对局。
        self.ai_thread = None;
        self.ai_think_start = None;
        self.ai_think_elapsed = None;
        self.ai_playback = false;
        self.map_layer = None;
        if self.game.deploying {
            self.log("—— 第 0 回合 · 部署阶段 ——\n用招募点数挑选单位，点击己方出发区域放置。".into());
        } else if self.multiplayer {
            self.log(format!(
                "—— 第 {} 回合 · {}方行动 ——",
                self.game.turn.max(1),
                mp::team_label(self.game.phase)
            ));
        } else {
            self.log(format!("—— 第 {} 回合 · 你的行动 ——", self.game.turn));
        }
    }

    fn log(&mut self, s: String) {
        self.push_log(None, s);
    }

    /// 只属于某一方私有信息的日志（终端玩家的命令回显）。
    /// `--view acting` 下只显示给该方视角，避免把对方的私有消息泄露出去。
    fn log_team(&mut self, team: Team, s: String) {
        self.push_log(Some(team), s);
    }

    fn push_log(&mut self, team: Option<Team>, s: String) {
        if s.starts_with('⚠') {
            self.last_error = Some((self.time, s.clone()));
        }
        self.log.push(LogLine { team, text: s });
        if self.log.len() > 400 {
            self.log.drain(0..100);
        }
        if self.multiplayer {
            self.net_dirty = true;
        }
    }

    /// 全部日志的纯文本（不含阵营归属），供测试与导出使用。
    fn log_text(&self) -> String {
        self.log
            .iter()
            .map(|l| l.text.clone())
            .collect::<Vec<_>>()
            .join("\n")
    }

    /// 某行日志在当前视角下是否可见。观战（全视野）模式显示全部；
    /// `--view acting` 下隐藏对方阵营的私有行。
    fn log_visible(&self, line: &LogLine) -> bool {
        if !self.multiplayer || self.view_mode == mp::ViewMode::Spectator {
            return true;
        }
        match line.team {
            None => true,
            Some(t) => t == self.view_team(),
        }
    }

    /// GUI 当前可操作的阵营。单人模式固定为蓝方；多人模式按热座/终端接管情况决定。
    fn gui_control_team(&self) -> Option<Team> {
        if !self.multiplayer {
            return Some(Team::Player);
        }
        match self.local_control {
            mp::LocalControl::Both => Some(self.game.phase),
            mp::LocalControl::Blue => {
                if self.game.phase == Team::Player {
                    Some(Team::Player)
                } else {
                    None
                }
            }
            mp::LocalControl::Red => {
                if self.game.phase == Team::Ai {
                    Some(Team::Ai)
                } else {
                    None
                }
            }
            mp::LocalControl::Spectator => None,
        }
    }

    /// 右侧面板显示哪一方的单位：本地控制方优先，否则显示当前行动方。
    fn side_team(&self) -> Team {
        if !self.multiplayer {
            return Team::Player;
        }
        self.gui_control_team().unwrap_or(self.game.phase)
    }

    /// 多人模式使用完整视野，便于 GUI 实时播放终端玩家的操作效果。
    fn set_full_vision(&mut self) {
        self.revealed.clear();
        self.dist_map.clear();
        for row in 0..self.game.map.rows {
            for col in 0..self.game.map.cols {
                let h = hex::axial_from_offset(col, row);
                self.revealed.insert(h);
                self.dist_map.insert(h, (0, 999));
            }
        }
        self.visible_enemies = self
            .game
            .enemies_of(Team::Player)
            .iter()
            .map(|u| u.pos)
            .collect();
        // 全视野下所有敌方单位都可见，鬼影永远不会被画出来；清掉避免
        // 切回单方视角时残留上一方的目击记录。
        self.ghosts.clear();
    }

    /// 当前渲染视角的「我方」阵营。单人固定蓝方；多人 `--view acting`
    /// 时是**当前行动方**——同一时刻只有一方行动，因此窗口内容始终
    /// 等于该方自己的视角。
    fn view_team(&self) -> Team {
        if !self.multiplayer || self.view_mode == mp::ViewMode::Spectator {
            return Team::Player;
        }
        self.game.phase
    }

    /// 记录某一方「看到过」的敌方单位最后已知位置（灰雾「?」标记）。
    /// 必须在该方视野刚算完时调用（`visible_enemies` 属于该方）。
    fn refresh_ghosts(&mut self, viewer: Team) {
        let turn = self.game.turn;
        let seen: Vec<(Hex, UnitKind)> = self
            .game
            .enemies_of(viewer)
            .iter()
            .filter(|u| self.visible_enemies.contains(&u.pos))
            .map(|u| (u.pos, u.kind))
            .collect();
        let slot = self.ghosts.entry(viewer).or_default();
        for (h, kind) in seen {
            slot.insert(h, (kind, turn));
        }
        slot.retain(|_, (_, t)| turn - *t < 2);
    }

    /// `--view acting` 下把当前渲染的阵营写进窗口标题。截图工具据此判断
    /// 这个窗口现在展示的是哪一方的视野，从而决定能否安全抓取。
    fn sync_view_title(&mut self, ctx: &egui::Context) {
        let want = format!(
            "六边形战争 · 多人热座 · {}方视角",
            mp::team_label(self.view_team())
        );
        if self.last_title.as_deref() != Some(want.as_str()) {
            ctx.send_viewport_cmd(egui::ViewportCommand::Title(want.clone()));
            self.last_title = Some(want);
        }
    }

    /// 处理网络线程送来的连接事件与终端命令。
    fn process_net(&mut self) {
        let Some(hub) = self.net.clone() else {
            return;
        };

        let events = hub.lock().map(|mut h| h.take_events()).unwrap_or_default();
        for ev in events {
            match ev {
                mp::HubEvent::ControlChanged { gui_teams } => {
                    self.local_control = mp::LocalControl::from_teams(&gui_teams);
                    self.log(format!(
                        "🖥 本地控制已更新：{}",
                        self.local_control.label()
                    ));
                }
                mp::HubEvent::ClientJoined { id, team, addr } => {
                    self.net_sessions.entry(id).or_default();
                    // 新连接（含重连/接管）：补发完整战报历史，
                    // 让客户端不依赖重放也能重建此前的战况。
                    let history = mp::render_battle_events(&self.game, team, 0);
                    if let Some(hub) = self.net.clone() {
                        if let Ok(h) = hub.lock() {
                            for line in history {
                                h.send_to(id, mp::ServerMessage::Message(line));
                            }
                        }
                    }
                    self.log(format!(
                        "🖥 终端玩家已连接：{}方（{}）",
                        mp::team_label(team),
                        addr
                    ));
                }
                mp::HubEvent::ClientLeft { id, team } => {
                    self.net_sessions.remove(&id);
                    self.log(format!("🖥 {}方终端玩家已断开。", mp::team_label(team)));
                }
                mp::HubEvent::ServerError(e) => {
                    self.log(format!("⚠ 网络错误: {}", e));
                }
            }
        }

        let commands = hub.lock().map(|mut h| h.take_incoming()).unwrap_or_default();
        for (id, line) in commands {
            let Some(team) = hub.lock().ok().and_then(|h| h.client_team(id)) else {
                continue;
            };
            let session = self.net_sessions.entry(id).or_default();
            let outcome = mp::execute_command(&mut self.game, team, session, &line);
            for msg in &outcome.messages {
                if let Ok(h) = hub.lock() {
                    h.send_to(id, mp::ServerMessage::Message(msg.clone()));
                }
                self.log_team(team, format!("[{}方] {}", mp::team_label(team), msg));
            }
            if outcome.changed {
                self.net_dirty = true;
            }
            if outcome.quit {
                if let Ok(mut h) = hub.lock() {
                    h.remove_client(id, "玩家已退出");
                }
                self.net_sessions.remove(&id);
                continue;
            }
            if let Some(w) = self.current_winner() {
                self.finish_game(w);
                continue;
            }
            // 僵局判定：连续 20 回合无击毁即平局收场（多人模式原本不判平局，
            // 会导致双方都不再造成杀伤时对局永远不结束）
            if self.game.is_draw() {
                self.finish_draw();
                continue;
            }
            if outcome.end_turn {
                self.end_turn_for(team);
            } else if !outcome.no_auto_end {
                self.after_action();
            }
        }
    }

    /// 把当前战场快照推送给所有终端客户端（按各自阵营过滤迷雾）。
    fn broadcast_net_states(&mut self) {
        let Some(hub) = self.net.clone() else {
            return;
        };
        // 先播报结构化战报（击毁/据点/胜负）：每个客户端按自己的视角收到
        // [战损]/[战果]/[据点]/[胜负] 行。这是"被击毁方能知道自己损失了什么"
        // 的唯一通道——游戏原本只把开火结果发给开火方。
        let events_blue = mp::render_battle_events(&self.game, Team::Player, self.net_event_seq);
        let events_red = mp::render_battle_events(&self.game, Team::Ai, self.net_event_seq);
        let clients = hub.lock().map(|h| h.client_ids()).unwrap_or_default();
        for (id, team) in clients {
            let selected = self.net_sessions.get(&id).and_then(|s| s.selected);
            let lines = if team == Team::Player {
                &events_blue
            } else {
                &events_red
            };
            if let Ok(h) = hub.lock() {
                for line in lines {
                    h.send_to(id, mp::ServerMessage::Message(line.clone()));
                }
                let text = mp::render_state(&self.game, team, selected);
                h.send_to(id, mp::ServerMessage::State(text));
            }
        }
        self.net_event_seq = self.game.battle_seq;
        self.net_dirty = false;
    }

    /// 对局结束时自动导出完整日志（无需点按钮），只写一次。
    /// 环境变量 HEX_WARGAME_AUTO_LOG=0 可关闭。
    fn auto_export_log(&mut self) {
        if self.auto_log_done || !self.multiplayer {
            return;
        }
        if self.game_over.is_none() && self.game.winner.is_none() {
            return;
        }
        if std::env::var("HEX_WARGAME_AUTO_LOG")
            .map(|v| v == "0")
            .unwrap_or(false)
        {
            self.auto_log_done = true;
            return;
        }
        self.auto_log_done = true;
        match self.export_log() {
            Ok(path) => self.log(format!("📜 对局结束，完整日志已自动导出: {}", path)),
            Err(e) => self.log(format!("⚠ 自动导出日志失败: {}", e)),
        }
    }

    /// 每帧检查局势是否变化，变化时写出观战快照（`--state-file`）。
    ///
    /// 签名除了「回合 + 行动方 + 事件日志长度 + 战报序号 + 是否结束」，
    /// 还**哈希全部单位的关键状态**：像 `p`（结束单位行动）、消耗弹药、
    /// 切换武器模式这类不写事件日志的操作，只靠日志长度会漏写，
    /// 外部消费者就会读到过期的 `actions_left`/弹药。
    fn sync_spectator_state(&mut self) {
        if self.state_file.is_none() {
            return;
        }
        let sig = (
            self.game.turn,
            self.game.phase,
            self.game.event_log.len(),
            self.game.battle_seq,
            self.game_over.is_some(),
            Self::units_digest(&self.game),
        );
        if self.state_sig == Some(sig) {
            return;
        }
        self.state_sig = Some(sig);
        self.write_spectator_state();
    }

    /// 全部单位关键状态的稳定哈希（BTreeMap 迭代顺序确定，故可复现）。
    fn units_digest(game: &GameState) -> u64 {
        use std::hash::{Hash, Hasher};
        let mut h = std::collections::hash_map::DefaultHasher::new();
        for u in game.units.values().chain(game.air_units.values()) {
            u.team.hash(&mut h);
            u.label.hash(&mut h);
            (u.kind as u8).hash(&mut h);
            u.pos.q.hash(&mut h);
            u.pos.r.hash(&mut h);
            u.hp.hash(&mut h);
            u.actions_left.hash(&mut h);
            u.ammo.hash(&mut h);
            u.missile_ammo.hash(&mut h);
            u.aa_ammo.hash(&mut h);
            u.ad_uses.hash(&mut h);
            u.suppression_stacks.hash(&mut h);
            u.flares.hash(&mut h);
            u.deployed.hash(&mut h);
            u.missile_mode.hash(&mut h);
            u.aa_mode.hash(&mut h);
            u.rooftop.hash(&mut h);
            u.passengers.len().hash(&mut h);
            for p in &u.passengers {
                p.label.hash(&mut h);
                p.hp.hash(&mut h);
                p.ammo.hash(&mut h);
            }
        }
        h.finish()
    }

    /// 原子写出观战快照：先写临时文件再 rename，读者永远看到完整 JSON。
    fn write_spectator_state(&mut self) {
        let Some(path) = self.state_file.clone() else {
            return;
        };
        let snapshot = mp::spectator_snapshot(&self.game, self.game_over.as_deref());
        let text = match serde_json::to_string_pretty(&snapshot) {
            Ok(t) => t,
            Err(e) => {
                eprintln!("⚠ 观战快照序列化失败: {}", e);
                return;
            }
        };
        let tmp = format!("{}.tmp", path);
        if let Err(e) = std::fs::write(&tmp, text.as_bytes()) {
            eprintln!("⚠ 写观战快照失败 {}: {}", tmp, e);
            return;
        }
        if let Err(e) = std::fs::rename(&tmp, &path) {
            eprintln!("⚠ 提交观战快照失败 {}: {}", path, e);
        }
    }

    /// 多人模式结束一方回合并切换到对手。
    fn end_turn_for(&mut self, team: Team) {
        if self.game_over.is_some() || team != self.game.phase {
            return;
        }
        let other = team.opponent();
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.confirm_action = None;
        self.pending_disembark = None;
        self.load_mode = false;
        self.smoke_shot_pending = false;
        self.howitzer_fire_mode = false;
        self.simul_mode = false;
        self.simul_orders.clear();
        self.ranger_mode = false;
        self.ranger_first = None;
        self.ranger_last = None;
        self.game.begin_turn(other);
        self.log(format!(
            "—— 第 {} 回合 · {}方行动 ——",
            self.game.turn.max(1),
            mp::team_label(other)
        ));
        self.net_dirty = true;
    }

    /// 选中格的单位：直升机与地面单位同格时，按当前选中层（selected_is_air）返回；
    /// 再次点击同格可切换选中地面单位。空中层无单位时回退到地面层。
    fn selected_unit(&self) -> Option<&hex_wargame::unit::Unit> {
        let sel = self.selected?;
        if self.selected_is_air {
            if let Some(a) = self.game.air_units.get(&sel) {
                return Some(a);
            }
        }
        self.game.unit_at(sel)
    }

    /// 左键点击某个格子后的交互逻辑。
    /// `click_upper`：点击是否落在格子上半部分。同格双单位（直升机画在上方）时，
    /// 点上半选直升机、点下半选地面单位。
    fn handle_click(&mut self, h: Hex, click_upper: bool) {
        // AI 回合（后台思考或播放其行动）期间屏蔽玩家操作。
        if self.ai_busy() {
            return;
        }
        let me = if self.multiplayer {
            match self.gui_control_team() {
                Some(t) if t == self.game.phase => t,
                _ => return,
            }
        } else {
            Team::Player
        };
        // 试验模式：放置棋子子模式优先于部署/增援/普通操作。
        if self.game.test_mode && self.game.test_placing {
            if let Some(kind) = self.pending_recruit {
                match self.game.test_place_unit(self.game.test_place_team, kind, h) {
                    Ok(label) => self.log(format!(
                        "🧪 试验放置 {} {} {} @{}",
                        self.game.test_place_team.cn(),
                        label,
                        kind.name(),
                        hex::hex_label(h)
                    )),
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
            }
            return;
        }

        // 部署阶段：放置待选单位 / 点击己方已部署单位撤销（返还点数）
        if self.game.deploying {
            if std::env::var_os("HEX_WARGAME_DEBUG").is_some() {
                eprintln!("[gui] deploy_click hex={} pending={:?}", hex::hex_label(h), self.pending_recruit);
            }
            if let Some(kind) = self.pending_recruit {
                if let Some(u) = self.game.unit_at(h).cloned() {
                    if u.team == me {
                        match self.game.undeploy_unit(me, h) {
                            Ok(cost) => self.log(format!(
                                "撤销部署 {}（返还 {} 点）",
                                u.name_with_label(),
                                cost
                            )),
                            Err(e) => self.log(format!("⚠ {}", e)),
                        }
                    } else {
                        self.log("⚠ 不能操作对方单位".into());
                    }
                    return;
                }
                let cargo = self.pending_cargo.clone();
                match self.game.deploy_unit_with_cargo(me, kind, h, &cargo) {
                    Ok(label) => self.log(format!(
                        "部署 {} {}{}",
                        label,
                        kind.name(),
                        if cargo.is_empty() {
                            String::new()
                        } else {
                            format!("（载 {}）", cargo.len())
                        }
                    )),
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
            } else if let Some(u) = self.game.unit_at(h).cloned() {
                if u.team == me {
                    match self.game.undeploy_unit(me, h) {
                        Ok(cost) => self.log(format!(
                            "撤销部署 {}（返还 {} 点）",
                            u.name_with_label(),
                            cost
                        )),
                        Err(e) => self.log(format!("⚠ {}", e)),
                    }
                }
            }
            return;
        }

        // 招募阶段（对局中按 D）：第 1 回合在出发区域招募，之后在大本营周围追加部署。
        if self.game.sustain_deploying {
            if let Some(kind) = self.pending_recruit {
                let cargo = self.pending_cargo.clone();
                let placed = if self.game.recruit_zone_turn > 0 {
                    self.game.recruit_unit_with_cargo(me, kind, h, &cargo)
                } else {
                    self.game.reinforce_unit_with_cargo(me, kind, h, &cargo)
                };
                match placed {
                    Ok(label) => {
                        let first = self.game.recruit_zone_turn > 0
                            && self.game.turn <= self.game.recruit_zone_turn;
                        self.log(format!(
                            "🛠 {} {} {}{}（{}）",
                            if first { "招募" } else { "增援部署" },
                            label,
                            kind.name(),
                            if cargo.is_empty() {
                                String::new()
                            } else {
                                format!("（载 {}）", cargo.len())
                            },
                            if first { "本回合即可行动" } else { "本回合不可行动" }
                        ));
                    }
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
            }
            return;
        }

        if self.game_over.is_some() {
            return;
        }
        let debug = std::env::var_os("HEX_WARGAME_DEBUG").is_some();
        if debug {
            eprintln!("[gui] click hex={}", hex::hex_label(h));
        }

        // 补给模式：点击半径 2 格内的友军单位进行补给（补给单位与被补给方各消耗 1 行动）。
        if self.supply_mode {
            let valid = self
                .selected
                .and_then(|s| self.game.unit_at(s))
                .map(|u| u.team == me && u.kind == UnitKind::Supply && u.actions_left >= 1)
                .unwrap_or(false);
            if !valid {
                self.supply_mode = false;
            } else if let Some(src) = self.selected {
                match self.game.resupply_from(src, h) {
                    Ok(m) => self.log(format!("📦 {}", m)),
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
                let still = self
                    .game
                    .unit_at(src)
                    .map(|u| u.actions_left >= 1)
                    .unwrap_or(false);
                self.supply_mode = still;
                self.after_action();
                return;
            }
        }

        // 0) 同时攻击模式：不立即结算，只选择己方单位并下达攻击命令
        if self.simul_mode {
            // 已选中己方单位 + 点击敌方目标 → 加入/替换命令
            if let Some(sel) = self.selected {
                if let Some(au) = self.selected_unit().cloned() {
                    if au.team == me {
                        let is_area = au.kind == UnitKind::Howitzer
                            || au.kind == UnitKind::Mortar;
                        let mine_here = self
                            .game
                            .units
                            .get(&h)
                            .map(|u| u.team == me)
                            .unwrap_or(false)
                            || self
                                .game
                                .air_units
                                .get(&h)
                                .map(|u| u.team == me)
                                .unwrap_or(false);
                        let enemy_here = self
                            .game
                            .units
                            .get(&h)
                            .map(|u| u.team != me)
                            .unwrap_or(false)
                            || self
                                .game
                                .air_units
                                .get(&h)
                                .map(|u| u.team != me)
                                .unwrap_or(false);
                        // 范围攻击：点击射程内任意非己方占用的格子作为炮击中心
                        if is_area && !mine_here {
                            self.queue_simul_attack(sel, h, self.selected_is_air);
                            return;
                        }
                        if enemy_here {
                            self.queue_simul_attack(sel, h, self.selected_is_air);
                            return;
                        }
                    }
                }
            }
            // 点击己方单位：切换当前“攻击者”
            let mine_ground = self
                .game
                .units
                .get(&h)
                .filter(|u| u.team == me)
                .cloned();
            let mine_air = self
                .game
                .air_units
                .get(&h)
                .filter(|u| u.team == me)
                .cloned();
            if mine_ground.is_some() || mine_air.is_some() {
                let has_ground = mine_ground.is_some();
                let has_air = mine_air.is_some();
                self.selected = Some(h);
                if has_air && has_ground {
                    self.selected_is_air = click_upper;
                } else if has_air {
                    self.selected_is_air = true;
                } else {
                    self.selected_is_air = false;
                }
                self.zero_hint = None;
                return;
            }
            // 点击空白：取消当前攻击者选择
            self.selected = None;
            self.selected_is_air = true;
            self.zero_hint = None;
            return;
        }

        // 0) 待放下状态：把步兵放到点击的格子（须紧邻载具）
        if let Some(label) = self.pending_disembark {
            if let Some(sel) = self.selected {
                match self.game.disembark(sel, label, h) {
                    Ok(()) => {
                        if debug {
                            eprintln!("[gui] disembark -> {} 到 {}", label, hex::hex_label(h));
                        }
                        self.log(format!("{} 下车到 {}", label, hex::hex_label(h)));
                        self.pending_disembark = None;
                    }
                    Err(e) => {
                        if debug {
                            eprintln!("[gui] disembark error -> {}", e);
                        }
                        // 失败时保留等待态，方便重试（Esc/再点一次取消）
                        self.log(format!("⚠ {}（等待中，可点合法空格或按 Esc 取消）", e));
                    }
                }
            } else {
                self.pending_disembark = None;
            }
            return;
        }

        // 0.5) 未选中时点击敌方单位：选中查看其信息（不可控制）。
        // 视野规则：只有我方视野内的敌人才能被选中查看（防止泄露视野外信息）；
        // 敌方空中/地面同格时同样按点击层选择。
        if self.selected.is_none() {
            let e_ground = self
                .game
                .units
                .get(&h)
                .filter(|e| {
                    e.team != me
                        && (self.multiplayer
                            || self.visible_enemies.contains(&h)
                            || self.game.test_mode)
                });
            let e_air = self
                .game
                .air_units
                .get(&h)
                .filter(|e| {
                    e.team != me
                        && (self.multiplayer
                            || self.visible_enemies.contains(&h)
                            || self.game.test_mode)
                });
            if e_ground.is_some() || e_air.is_some() {
                self.selected = Some(h);
                self.selected_is_air = match (e_ground.is_some(), e_air.is_some()) {
                    (true, true) => click_upper,
                    (true, false) => false,
                    (false, true) => true,
                    (false, false) => false,
                };
                self.zero_hint = None;
                return;
            }
        }

        // 0.6) 榴弹炮/迫击炮烟雾弹待发射：点击射程内格子发射烟雾弹
        if self.smoke_shot_pending {
            let can_smoke = self
                .selected
                .and_then(|sel| self.game.unit_at(sel))
                .map(|u| u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
                .unwrap_or(false);
            if can_smoke {
                if let Some(sel) = self.selected {
                    let range = self
                        .game
                        .unit_at(sel)
                        .map(|u| u.kind.range())
                        .unwrap_or(0);
                    self.smoke_shot_pending = false;
                    if Hex::distance(sel, h) <= range {
                        match self.game.smoke_shot(sel, h) {
                            Ok(cells) => {
                                if debug {
                                    eprintln!("[gui] smoke -> {} 格", cells.len());
                                }
                                let radius = if self
                                    .game
                                    .unit_at(sel)
                                    .map(|u| u.kind == UnitKind::Mortar)
                                    .unwrap_or(false)
                                {
                                    1
                                } else {
                                    2
                                };
                                self.log(format!(
                                    "发射烟雾弹 @{}（半径{}，持续2回合）",
                                    hex::hex_label(h),
                                    radius
                                ));
                            }
                            Err(e) => self.log(format!("⚠ {}", e)),
                        }
                        self.after_action();
                    } else {
                        self.log("⚠ 超出射程，无法发射烟雾弹".into());
                    }
                }
            }
            self.smoke_shot_pending = false;
            return;
        }
        // 0.7) 榴弹炮开火模式：优先炮击（点击任意格，含己方单位所在格）
        if self.howitzer_fire_mode {
            if let Some(sel) = self.selected {
                if self.try_howitzer_fire(sel, h) {
                    return;
                }
            }
        }

        // 1) 已选中单位：若该格有敌方单位（地面或空中，含敌方直升机与我方地面单位同格）→ 攻击
        if let Some(sel) = self.selected {
            if let Some(au) = self.selected_unit().cloned() {
                if au.team == me && au.kind != UnitKind::Howitzer {
                    let enemy_here = self
                        .game
                        .units
                        .get(&h)
                        .map(|u| u.team != me)
                        .unwrap_or(false)
                        || self
                            .game
                            .air_units
                            .get(&h)
                            .map(|u| u.team != me)
                            .unwrap_or(false);
                    if enemy_here {
                        // 同格双单位（直升机在己方单位上方）时按选中层决定攻击者
                        let result = if self.selected_is_air {
                            self.game.attack_air(sel, h)
                        } else {
                            self.game.attack(sel, h)
                        };
                        match result {
                            Ok(out) => {
                                if debug {
                                    eprintln!("[gui] attack -> {}", out.message);
                                }
                                self.log(out.message);
                                if let Some(w) = self.current_winner() {
                                    self.finish_game(w);
                                    return;
                                }
                            }
                            Err(e) => {
                                if debug {
                                    eprintln!("[gui] attack error -> {}", e);
                                }
                                self.log(format!("⚠ {}", e))
                            }
                        }
                        self.after_action();
                        return;
                    }
                }
            }
        }

        // 1.5) 装载模式（按 X 进入）：只允许点击紧邻的己方可搭载单位上车，
        //      此模式不能移动（要移动请先按 X/Esc 退出）。未进入该模式时，
        //      点击己方单位只会选中它，不会装载。
        if self.load_mode {
            self.handle_load_mode_click(h, me);
            return;
        }

        // 2) 点自己的单位（地面或空中；空中单位可能单独在格或飞在己方单位上方）：
        //    - 已选中单位 + 该格可达 → 直接移动（空中可停在地面单位上方；
        //      地面也可移动到己方空中单位所在格，同格双层）
        //    - 否则切换选择（同格双单位按点击层选择：点离空中兵牌近→直升机）
        let mine_ground = self
            .game
            .units
            .get(&h)
            .filter(|u| u.team == me)
            .cloned();
        let mine_air = self
            .game
            .air_units
            .get(&h)
            .filter(|u| u.team == me)
            .cloned();
        if mine_ground.is_some() || mine_air.is_some() {
            // 已选中己方单位 + 该格可达 → 直接移动（而非选中该格单位）。
            // 同一层不能重叠（地面×地面、空中×空中），否则会覆盖同层棋子；
            // 不同层（空中停在地面单位上方 / 地面移动到己方直升机同格）允许。
            let can_move_here = if let Some(sel) = self.selected {
                self.selected_unit()
                    .filter(|su| su.team == me && su.actions_left > 0 && sel != h)
                    .map(|su| {
                        let same_layer_occupied = if su.kind.is_air() {
                            self.game.air_units.contains_key(&h)
                        } else {
                            self.game.units.contains_key(&h)
                        };
                        !same_layer_occupied
                            && self
                                .game
                                .map
                                .reachable_hexes_ex(
                                    &self.game.units,
                                    &self.game.air_units,
                                    su.pos,
                                    su.kind.movement(),
                                    Some(su),
                                )
                                .contains(&h)
                    })
                    .unwrap_or(false)
            } else {
                false
            };
            if can_move_here {
                self.try_move_selected(h);
                return;
            }
            // 选中该格：同格双单位（直升机在上、地面在下）按点击层选择
            let has_ground = mine_ground.is_some();
            let has_air = mine_air.is_some();
            self.selected = Some(h);
            if has_air && has_ground {
                self.selected_is_air = click_upper;
            } else if has_air {
                self.selected_is_air = true;
            } else {
                self.selected_is_air = false;
            }
            self.zero_hint = None;
            return;
        }

        // 2) 已选中单位时的操作
        if let Some(sel) = self.selected {
            if let Some(au) = self.selected_unit().cloned() {
                // 敌方单位：只查看，不行动
                if au.team != me {
                    return;
                }
                // 榴弹炮：行动模式下不攻击（开火模式已在最前处理）；
                // 点击敌人时给出提示（避免静默取消）
                if au.kind == UnitKind::Howitzer {
                    let has_enemy = self
                        .game
                        .units
                        .get(&h)
                        .map(|u| u.team != me)
                        .unwrap_or(false)
                        || self
                            .game
                            .air_units
                            .get(&h)
                            .map(|u| u.team != me)
                            .unwrap_or(false);
                    if has_enemy && au.actions_left > 0 && au.ammo > 0 {
                        self.log("⚠ 榴弹炮当前是行动模式，不能炮击：按 T 切到开火模式后点击黄色格子".into());
                        return;
                    }
                } else if let Some(tu) = self.game.unit_at(h).cloned() {
                    // 普通攻击：目标是射程内敌人
                    if tu.team != me {
                        let result = if self.selected_is_air {
                            self.game.attack_air(sel, h)
                        } else {
                            self.game.attack(sel, h)
                        };
                        match result {
                            Ok(out) => {
                                if debug {
                                    eprintln!("[gui] attack -> {}", out.message);
                                }
                                self.log(out.message);
                                if let Some(w) = self.current_winner() {
                                    self.finish_game(w);
                                    return;
                                }
                            }
                            Err(e) => {
                                if debug {
                                    eprintln!("[gui] attack error -> {}", e);
                                }
                                self.log(format!("⚠ {}", e))
                            }
                        }
                        self.after_action();
                        return;
                    }
                }
                // 移动：目标是可达格
                if au.actions_left > 0 && self.try_move_selected(h) {
                    return;
                }
                // 0 行动单位：点击给出提示（只提示一次），再点一次才取消选择
                if au.actions_left <= 0 {
                    if self.zero_hint != Some(sel) {
                        self.zero_hint = Some(sel);
                        self.log(format!(
                            "⚠ {} 本回合行动已用完（按 S 结束或再点一次取消选择）",
                            au.name_with_label()
                        ));
                        return;
                    }
                }
            }
            // 点击不可达处：取消选择
            self.selected = None;
            self.selected_is_air = true;
            self.zero_hint = None;
        }
    }

    /// 装载模式下点击 h：只允许点击紧邻的己方可搭载单位上车，不执行移动。
    fn handle_load_mode_click(&mut self, h: Hex, me: Team) {
        let debug = std::env::var_os("HEX_WARGAME_DEBUG").is_some();
        let Some(sel) = self.selected else {
            self.load_mode = false;
            return;
        };
        let Some(su) = self.selected_unit().cloned() else {
            self.load_mode = false;
            return;
        };
        // 选中的载体已失效（换选/被毁/不是地面载具）→ 自动退出。
        if su.team != me || su.kind.capacity() == 0 || su.kind.is_air() {
            self.load_mode = false;
            return;
        }
        if !su.has_space() {
            self.load_mode = false;
            self.log(format!("{} 已满载，退出装载模式", su.name_with_label()));
            return;
        }
        // 点击紧邻的己方可搭载单位 → 上车。
        if h != sel {
            if let Some(g) = self.game.units.get(&h).cloned() {
                if g.team == me && Hex::distance(sel, h) == 1 {
                    if su.can_carry(g.kind) {
                        match self.game.board(sel, h) {
                            Ok(()) => {
                                if debug {
                                    eprintln!(
                                        "[gui] load-mode board -> {} 搭载 {}",
                                        su.name_with_label(),
                                        g.name_with_label()
                                    );
                                }
                                self.log(format!(
                                    "{} 搭载 {}",
                                    su.name_with_label(),
                                    g.name_with_label()
                                ));
                                // 还有空位就留在装载模式，方便连续装载；满载则退出。
                                self.load_mode = self
                                    .game
                                    .unit_at(sel)
                                    .map(|u| u.has_space())
                                    .unwrap_or(false);
                                self.after_action();
                            }
                            Err(e) => {
                                if debug {
                                    eprintln!("[gui] load-mode board error -> {}", e);
                                }
                                self.log(format!("⚠ {}", e));
                            }
                        }
                    } else {
                        self.log(format!(
                            "⚠ {} 不能搭载 {}",
                            su.name_with_label(),
                            g.name_with_label()
                        ));
                    }
                    return;
                }
            }
        }
        self.log(
            "⚠ 装载模式：请点击紧邻的己方可搭载单位上车（X/Esc 退出；此模式不能移动）".into(),
        );
    }

    /// 按 X 进入/退出地面载具的装载模式：进入后点击紧邻己方单位上车且不能移动。
    fn toggle_load_mode(&mut self) {
        if self.load_mode {
            self.load_mode = false;
            self.log("已退出装载模式".into());
            return;
        }
        if self.selected.is_none() {
            self.log("⚠ 请先选中一个可搭载的载具，再按 X 进入装载模式".into());
            return;
        }
        let Some(u) = self.selected_unit().cloned() else {
            return;
        };
        let me = if self.multiplayer {
            match self.gui_control_team() {
                Some(t) => t,
                None => {
                    self.log("⚠ 当前不可操作".into());
                    return;
                }
            }
        } else {
            Team::Player
        };
        if u.team != me {
            self.log("⚠ 只能对己方载具使用装载模式".into());
            return;
        }
        if u.kind.is_air() || u.kind.capacity() == 0 {
            self.log(format!(
                "⚠ {} 不能搭载地面部队，无法进入装载模式",
                u.name_with_label()
            ));
            return;
        }
        if !u.has_space() {
            self.log(format!("⚠ {} 已满载", u.name_with_label()));
            return;
        }
        if u.actions_left < 1 {
            self.log(format!("⚠ {} 本回合行动次数不足", u.name_with_label()));
            return;
        }
        self.load_mode = true;
        self.pending_disembark = None;
        self.zero_hint = None;
        self.log(format!(
            "🚚 {} 装载模式：点击紧邻高亮的己方单位上车（X/Esc 退出；此模式不能移动）",
            u.name_with_label()
        ));
    }

    /// 按 S（选中补给单位时）：进入/退出补给模式。
    /// 进入后点击半径 2 格内的友军单位，由补给单位消耗 1 行动为其补给，
    /// 被补给友军也消耗 1 行动。
    fn toggle_supply_mode(&mut self) {
        if self.supply_mode {
            self.supply_mode = false;
            self.log("已退出补给模式".into());
            return;
        }
        let Some(sel) = self.selected else {
            self.log("⚠ 请先选中一个己方补给单位".into());
            return;
        };
        let me = if self.multiplayer {
            match self.gui_control_team() {
                Some(t) => t,
                None => {
                    self.log("⚠ 当前不可操作".into());
                    return;
                }
            }
        } else {
            Team::Player
        };
        match self.game.unit_at(sel) {
            Some(u) if u.team == me && u.kind == UnitKind::Supply => {
                if u.actions_left < 1 {
                    self.log("⚠ 补给单位本回合行动次数不足".into());
                    return;
                }
                self.supply_mode = true;
                self.load_mode = false;
                self.pending_disembark = None;
                self.smoke_shot_pending = false;
                self.zero_hint = None;
                self.log(
                    "📦 补给模式：点击半径 2 格内的友军单位补给（补给单位与被补给方各消耗 1 行动；S/Esc 退出）"
                        .into(),
                );
            }
            _ => self.log("⚠ 请先选中一个己方补给单位，再按 S 进入补给模式".into()),
        }
    }

    /// 尝试把选中单位移动到 h（可达才移动）。成功返回 true。
    /// 直射测距器：输出两格间的距离、能否直射、命中率乘数等辅助信息。
    fn show_range_info(&mut self, from: Hex, to: Hex) {
        let d = Hex::distance(from, to);
        let los = self.game.map.has_los_ex(from, to, &self.game.smoke);
        self.log(format!(
            "📏 测距 {} → {}：距离 {} 格",
            hex::hex_label(from),
            hex::hex_label(to),
            d
        ));
        self.log(if los {
            "直射视线：✅ 通畅（未穿越岩石/楼房/烟雾内部）".to_string()
        } else {
            "直射视线：❌ 被阻挡（穿越岩石/楼房/烟雾内部）".to_string()
        });
        // 目标格地形
        let mut terrain: Vec<&str> = Vec::new();
        if self.game.map.obstacles.contains(&to) {
            terrain.push("岩石");
        }
        if self.game.map.buildings.contains(&to) {
            terrain.push("楼房");
        }
        if self.game.map.water.contains(&to) {
            terrain.push("水域");
        }
        if self.game.map.forests.contains(&to) {
            terrain.push("森林");
        }
        if self.game.map.roads.contains(&to) {
            terrain.push("道路");
        }
        if self.game.smoke.contains_key(&to) {
            terrain.push("烟雾");
        }
        self.log(format!(
            "目标格：{}",
            if terrain.is_empty() {
                "平原".to_string()
            } else {
                terrain.join("/")
            }
        ));
        // 起点为己方单位：按实际武器模拟命中率（结合直射视线新规则）
        if let Some(au) = self.game.unit_at(from).cloned() {
            if au.team == Team::Player {
                let indirect = au.kind == UnitKind::Howitzer || au.kind == UnitKind::Mortar;
                let air_to_air = au.kind.is_air()
                    && self
                        .game
                        .unit_at(to)
                        .map(|t| t.kind.is_air())
                        .unwrap_or(false);
                let cover = d <= au.eff_range();
                let can_fire = cover && (indirect || air_to_air || los);
                self.log(format!(
                    "{}：射程 {} 格{}，{}",
                    au.name_with_label(),
                    au.eff_range(),
                    if indirect { "（间瞄火力，无需直射视线）" } else { "" },
                    if !cover {
                        "❌ 射程不覆盖".to_string()
                    } else if !los && !indirect && !air_to_air {
                        "❌ 直射视线被阻隔，无法开火（共享视野不可绕过）".to_string()
                    } else {
                        "✅ 可开火".to_string()
                    }
                ));
                let rate = au.eff_hit_rate();
                let mut note: Vec<String> = Vec::new();
                let mut final_rate = rate;
                if let Some(tu) = self.game.unit_at(to).cloned() {
                    if !tu.kind.is_air() {
                        let m3e1 = (au.kind == UnitKind::EliteInfantry
                            || au.kind == UnitKind::SpecialForces)
                            && au.missile_mode;
                        if m3e1 {
                            if self.game.map.buildings.contains(&to) {
                                final_rate = 100;
                                note.push("M3E1 楼房抵消→100%".into());
                            } else if tu.kind.armor() >= 2 {
                                final_rate = 100;
                                note.push("M3E1 对装甲→100%".into());
                            } else {
                                final_rate = 80;
                            }
                            if self.game.map.forests.contains(&to) {
                                final_rate = final_rate * 4 / 5;
                                note.push("森林×0.8".into());
                            }
                        } else if self.game.map.forests.contains(&to) {
                            final_rate = final_rate * 4 / 5;
                            note.push("森林×0.8".into());
                        } else if self.game.map.buildings.contains(&to) {
                            final_rate = final_rate * 3 / 5;
                            note.push("楼房×0.6".into());
                        }
                        if self.game.smoke.contains_key(&to) {
                            final_rate = final_rate * 3 / 5;
                            note.push("烟雾×0.6".into());
                        }
                        if tu.kind == UnitKind::SpecialForces {
                            final_rate = final_rate * 4 / 5;
                            note.push("特战闪避×0.8".into());
                        }
                        let dmg = if au.eff_attack() >= tu.kind.armor() {
                            "✅ 能击穿护甲"
                        } else {
                            "❌ 打不穿护甲"
                        };
                        self.log(format!(
                            "对 {}：命中率 {}%（基准 {}%）{}，{}{}",
                            tu.name_with_label(),
                            final_rate,
                            rate,
                            if note.is_empty() {
                                "无地形减益".to_string()
                            } else {
                                format!("（{}）", note.join(" + "))
                            },
                            dmg,
                            if can_fire {
                                String::new()
                            } else {
                                " ⚠ 仅供参考（当前无法开火）".to_string()
                            }
                        ));
                    }
                } else {
                    // 目标格无单位：只显示地形命中乘数
                    let mut mult: Vec<String> = Vec::new();
                    if self.game.map.forests.contains(&to) {
                        mult.push("森林×0.8".into());
                    }
                    if self.game.map.buildings.contains(&to) {
                        mult.push("楼房×0.6".into());
                    }
                    if self.game.smoke.contains_key(&to) {
                        mult.push("烟雾×0.6".into());
                    }
                    self.log(if mult.is_empty() {
                        "目标格：无地形命中减益".to_string()
                    } else {
                        format!("目标格命中乘数：{}", mult.join(" + "))
                    });
                }
                return;
            }
        }
        // 起点无己方单位：只给地形乘数
        let mut mult: Vec<String> = Vec::new();
        if self.game.map.forests.contains(&to) {
            mult.push("森林×0.8".into());
        }
        if self.game.map.buildings.contains(&to) {
            mult.push("楼房×0.6".into());
        }
        if self.game.smoke.contains_key(&to) {
            mult.push("烟雾×0.6".into());
        }
        self.log(if mult.is_empty() {
            "目标格：无地形命中减益".to_string()
        } else {
            format!("目标格命中乘数：{}", mult.join(" + "))
        });
    }

    fn try_move_selected(&mut self, h: Hex) -> bool {
        if self.selected.is_none() {
            return false;
        }
        let Some(au) = self.selected_unit().cloned() else {
            return false;
        };
        if au.actions_left < 1 {
            return false;
        }
        let reach = self.game.map.reachable_hexes(
            &self.game.units,
            au.pos,
            au.kind.movement(),
            Some(&au),
        );
        if !reach.contains(&h) {
            return false;
        }
        let path = self.game.map.plan_move(
            &self.game.units,
            &self.game.air_units,
            au.pos,
            h,
            au.kind.movement(),
            Some(au.clone()), // 携带单位以识别空中移动
            false,
        );
        let debug = std::env::var_os("HEX_WARGAME_DEBUG").is_some();
        match self.game.move_unit(au.pos, &path, au.kind.is_air()) {
            Ok(new_pos) => {
                if debug {
                    eprintln!("[gui] move -> {} 到 {}", au.name_with_label(), hex::hex_label(new_pos));
                }
                self.log(format!(
                    "{} 移动到 {} (行动剩余 {})",
                    au.name_with_label(),
                    hex::hex_label(new_pos),
                    au.actions_left - 1
                ));
                self.selected = Some(new_pos);
                // 占领关键据点后立即结算（否则玩家还能继续操作）
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return true;
                }
            }
            Err(e) => {
                if debug {
                    eprintln!("[gui] move error -> {}", e);
                }
                self.log(format!("⚠ {}", e))
            }
        }
        self.after_action();
        true
    }

    /// 榴弹炮开火模式：对 h 格炮击（射程内+视线畅通才开炮）。
    /// 返回 true 表示已处理本次点击。
    fn try_howitzer_fire(&mut self, sel: Hex, h: Hex) -> bool {
        let Some(au) = self.selected_unit().cloned() else {
            return false;
        };
        let Some(me) = self.gui_control_team() else {
            return false;
        };
        if au.team != me {
            return false;
        }
        // 榴弹炮/自行迫击炮：射击模式下点击黄色格炮击
        if (au.kind != UnitKind::Howitzer && au.kind != UnitKind::Mortar) || h == sel {
            return false;
        }
        let debug = std::env::var_os("HEX_WARGAME_DEBUG").is_some();
        let in_range = Hex::distance(sel, h) <= au.kind.range();
        // 间瞄火力：无需直线视线（抛物线弹道，楼房/岩石不挡）
        if !in_range {
            self.log("⚠ 超出射程，无法炮击".to_string());
            return true;
        }
        match self.game.attack(sel, h) {
            Ok(out) => {
                if debug {
                    eprintln!("[gui] attack -> {}", out.message);
                }
                self.log(out.message);
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return true;
                }
            }
            Err(e) => {
                if debug {
                    eprintln!("[gui] attack error -> {}", e);
                }
                self.log(format!("⚠ {}", e))
            }
        }
        self.after_action();
        true
    }

    // ---------- 战斗动画（俯视棋子 / 弹道 / 爆炸） ----------

    /// 格中心像素（使用 draw_map 缓存的地图原点与格半径）。
    fn hex_center_pos(&self, h: Hex) -> egui::Pos2 {
        let (col, row) = hex::offset_from_axial(h);
        self.hex_center(self.map_origin, col, row, self.map_hs)
    }

    /// 按阵营+标签查找单位（含空中层）。
    fn find_unit(&self, team: Team, label: char) -> Option<&Unit> {
        self.game
            .units
            .values()
            .chain(self.game.air_units.values())
            .find(|u| u.team == team && u.label == label)
    }

    fn pose_of(&self, u: &Unit) -> fx::Pose {
        self.poses
            .get(&(u.team, u.label))
            .copied()
            .unwrap_or_else(|| fx::Pose::default_for(u.team))
    }

    /// 移动后更新朝向：车身 = 路径倒数第二格 → 终点方向；
    /// 移动后未开火则炮塔回正（与车身一致）。
    fn apply_move_pose(&mut self, team: Team, label: char, path: &[Hex]) {
        if path.len() < 2 {
            return;
        }
        let ang = pieces::angle_between(
            self.hex_center_pos(path[path.len() - 2]),
            self.hex_center_pos(path[path.len() - 1]),
        );
        let p = self
            .poses
            .entry((team, label))
            .or_insert_with(|| fx::Pose::default_for(team));
        p.hull = ang;
        if !p.fired {
            p.turret = ang;
        }
        p.fired = false;
    }

    /// 移动动画进行中的车头朝向：沿路径段实时前进，并在转弯节点附近平滑转向
    /// （以节点为中心、宽度 `TURN_W` 的窗口内从上一段方向插值到下一段方向），
    /// 避免"出发时先转好、之后一路平移"的僵硬表现。
    fn move_heading(&self, path: &[Hex], seg: usize, frac: f32) -> f32 {
        let n = path.len().saturating_sub(1); // 路径段数
        if n == 0 {
            return 0.0;
        }
        let dir = |i: usize| {
            pieces::angle_between(
                self.hex_center_pos(path[i.min(n - 1)]),
                self.hex_center_pos(path[(i + 1).min(n)]),
            )
        };
        let seg = seg.min(n - 1);
        let u = seg as f32 + frac.clamp(0.0, 1.0); // 连续路径参数 [0, n]
        let smooth = |t: f32| {
            let t = t.clamp(0.0, 1.0);
            t * t * (3.0 - 2.0 * t)
        };
        // 最短弧插值（避免 ±π 处绕远路）
        let blend = |a: f32, b: f32, t: f32| {
            let tau = std::f32::consts::TAU;
            let mut d = (b - a) % tau;
            if d > std::f32::consts::PI {
                d -= tau;
            } else if d < -std::f32::consts::PI {
                d += tau;
            }
            a + d * t
        };
        let mut ang = dir(seg);
        // 即将进入的节点（k = seg + 1）：后 TURN_W 段开始转向前一段→本段
        if seg + 1 < n {
            let k = (seg + 1) as f32;
            if u >= k - TURN_W {
                ang = blend(dir(seg), dir(seg + 1), smooth((u - (k - TURN_W)) / (2.0 * TURN_W)));
            }
        }
        // 刚刚经过的节点（k = seg）：前 TURN_W 段完成上一段→本段
        if seg > 0 {
            let k = seg as f32;
            if u <= k + TURN_W {
                ang = blend(dir(seg - 1), dir(seg), smooth((u - (k - TURN_W)) / (2.0 * TURN_W)));
            }
        }
        ang
    }

    /// 开火后更新朝向：车辆炮塔转向最后一次开火目标；步兵班组转向目标。
    fn apply_fire_pose(&mut self, ev: &hex_wargame::game::UiFireEvent) {
        let ang = pieces::angle_between(self.hex_center_pos(ev.from), self.hex_center_pos(ev.target));
        let p = self
            .poses
            .entry((ev.team, ev.label))
            .or_insert_with(|| fx::Pose::default_for(ev.team));
        if ev.kind.is_vehicle() {
            p.turret = ang;
        } else {
            p.hull = ang;
        }
        p.fired = true;
    }

    /// 步兵当前的开火视觉（转向/上肩动画状态）。
    fn fire_visual_of(&self, u: &Unit) -> Option<(f32, f32, Option<pieces::BackWeapon>)> {
        if !u.kind.is_foot() || u.kind == UnitKind::Headquarters {
            return None;
        }
        let f = self.fire_anims.iter().find(|f| {
            f.ev.team == u.team && f.ev.label == u.label && self.time >= f.start && self.time < f.launch + 0.25
        })?;
        let aim = pieces::angle_between(self.hex_center_pos(f.ev.from), self.hex_center_pos(f.ev.target));
        let progress = ((self.time - f.start) / (f.launch - f.start).max(1e-6)).clamp(0.0, 1.0) as f32;
        Some((aim, progress, fx::fire_back_weapon(&f.ev)))
    }

    /// GUI 日志：AI 回合中只记录玩家视野可见的移动；不可见的移动不提示。
    /// `end_seen`/`start_seen` 为玩家视野对移动终点/起点的可见性。
    fn log_ai_move(
        &mut self,
        kind: UnitKind,
        label: char,
        path: &[Hex],
        end_seen: bool,
        start_seen: bool,
    ) {
        if !end_seen || path.is_empty() {
            return;
        }
        let name = format!("{}{}", kind.name(), label);
        let end = *path.last().unwrap();
        if start_seen {
            self.log(format!(
                "🔴 敌军 {} 移动 {} → {}",
                name,
                hex::hex_label(path[0]),
                hex::hex_label(end)
            ));
        } else {
            self.log(format!("🔍 发现敌军 {} 于 {}", name, hex::hex_label(end)));
        }
    }

    /// GUI 日志：AI 开火。攻击方可见时正常记录；从迷雾中开火时只提示
    /// 敌方位置与攻击效果（玩家看不到棋子，但看得到弹道/爆炸）。
    fn log_ai_fire(&mut self, f: &hex_wargame::game::UiFireEvent, attacker_visible: bool) {
        let name = format!("{}{}", f.kind.name(), f.label);
        let effect = if f.killed {
            "击毁目标".to_string()
        } else if f.hit && f.blocked {
            "命中但被护甲挡下".to_string()
        } else if f.hit {
            format!("命中 -{}", f.dmg)
        } else {
            "未命中".to_string()
        };
        if attacker_visible {
            self.log(format!(
                "🔴 敌军 {} 攻击 {}：{}",
                name,
                hex::hex_label(f.target),
                effect
            ));
        } else {
            self.log(format!(
                "⚠ 迷雾中的敌军从 {} 向 {} 开火：{}",
                hex::hex_label(f.from),
                hex::hex_label(f.target),
                effect
            ));
        }
    }

    /// 取走游戏事件并排入动画队列：**严格串行**——上一个行动（含弹药飞行
    /// 与击毁动画的可见段）播完才播下一个。迷雾中敌方单位的移动完全不播放
    /// （终点不可见即跳过滑行，避免暗处棋子闪现）；迷雾中开火不显示敌棋子
    /// （由 reveal 规则隐藏），只保留弹道与红色迷雾开火标记。
    ///
    /// 单人模式下同时把 AI 行动按玩家视野过滤后写入 GUI 日志；导出日志与
    /// 存档仍通过 `event_log` 保留 AI 全部行动数据。
    fn drain_ui_events(&mut self) {
        if self.game.ui_events.is_empty() {
            return;
        }
        let events = std::mem::take(&mut self.game.ui_events);
        let vis = self.visible_enemies.clone();
        // 敌方移动是否播放：终点在视野内才播（迷雾中的移动完全不播放）。
        // 多人热座使用完整视野，所有移动/开火都完整播放。
        let full_view = self.multiplayer;
        let move_seen = |team: &Team, path: &[Hex]| {
            full_view || *team == Team::Player || path.last().is_some_and(|h| vis.contains(h))
        };
        // 预估总时长：批次过长时整体加速（仍严格串行，只是单步更快）
        let raw: f64 = events
            .iter()
            .map(|ev| match ev {
                UiEvent::Move { team, path, .. } => {
                    if move_seen(team, path) {
                        0.16 * (path.len() as f64 - 1.0).max(1.0) + 0.1
                    } else {
                        0.05
                    }
                }
                UiEvent::Fire(f) => {
                    let prof = fx::weapon_profile(f.kind, f.aa_mode, f.missile_mode, f.area);
                    prof.aim + prof.flight + if f.killed { 1.5 } else { 0.35 }
                }
            })
            .sum();
        let scale = (28.0 / raw).min(1.0).max(0.45);
        let mut t = self.fx_clock.max(self.time);
        for ev in events {
            let now = t.max(self.time);
            match ev {
                UiEvent::Move { team, label, kind, path, .. } => {
                    self.apply_move_pose(team, label, &path);
                    let end_seen = path.last().is_some_and(|h| vis.contains(h));
                    let start_seen = path.first().is_some_and(|h| vis.contains(h));
                    if move_seen(&team, &path) && path.len() >= 2 {
                        let dur = (0.16 * (path.len() as f64 - 1.0).max(1.0)).max(0.18) * scale;
                        self.move_anims.push(fx::MoveAnim {
                            team,
                            label,
                            path: path.clone(),
                            start: now,
                            end: now + dur,
                        });
                        t = now + dur + 0.06;
                    } else {
                        t = now + 0.02;
                    }
                    // 单人迷雾：只把玩家看得见的 AI 移动写进 GUI 日志。
                    if !full_view && team == Team::Ai {
                        self.log_ai_move(kind, label, &path, end_seen, start_seen);
                    }
                }
                UiEvent::Fire(f) => {
                    let prof = fx::weapon_profile(f.kind, f.aa_mode, f.missile_mode, f.area);
                    let aim = (prof.aim * scale).max(0.03);
                    let killed = f.killed;
                    // 单人迷雾：AI 开火按可见性写 GUI 日志（攻击方不可见时只提示位置与效果）。
                    if !full_view && f.team == Team::Ai {
                        let attacker_visible = vis.contains(&f.from);
                        self.log_ai_fire(&f, attacker_visible);
                    }
                    self.apply_fire_pose(&f);
                    // 被击毁的单位在击毁弹落地前保持显示（状态已移除，画面补画；
                    // 范围炮击的被波及击毁者同样处理）
                    for k in &f.killed_units {
                        let mut unit = Unit::new(k.kind, k.team, k.hex);
                        unit.hp = k.hp_before;
                        self.pending_deaths.push(PendingDeath {
                            hex: k.hex,
                            unit,
                            is_air: k.kind.is_air(),
                            land_at: now + aim + prof.flight,
                        });
                    }
                    self.fire_anims.push(FireAnim {
                        ev: f,
                        start: now,
                        launch: now + aim,
                        flight: prof.flight,
                        launched: false,
                    });
                    let wait = if killed { 1.5 } else { 0.35 } * scale;
                    t = now + aim + prof.flight + wait.max(0.05);
                }
            }
        }
        self.fx_clock = t;
    }

    /// 逐帧推进动画：发射离膛弹药、结算落地后果、冒烟、清理过期特效。
    fn update_fx(&mut self) {
        let now = self.time;
        let mut spawn: Vec<fx::Effect> = Vec::new();
        // 到达发射时刻：生成炮口火光与弹药
        let launches: Vec<usize> = self
            .fire_anims
            .iter()
            .enumerate()
            .filter(|(_, f)| !f.launched && now >= f.launch)
            .map(|(i, _)| i)
            .collect();
        for i in launches {
            self.fire_anims[i].launched = true;
            let f = &self.fire_anims[i];
            self.spawn_projectile(&mut spawn, f);
        }
        // 弹药落地 → 爆炸/火花/尸体/残骸/冒烟
        let mut landings = Vec::new();
        for e in self.effects.iter_mut() {
            if let Some(l) = e.take_landing(now) {
                landings.push(l);
            }
        }
        for l in landings {
            self.spawn_landing(&mut spawn, l);
        }
        // 被击中未击毁的载具持续冒烟
        for sm in &mut self.smokers {
            while now >= sm.next_puff && sm.next_puff <= sm.until {
                spawn.push(fx::Effect::Puff {
                    pos: sm.pos,
                    t0: sm.next_puff,
                    big: false,
                    white: false,
                    seed: (sm.next_puff * 7.31).fract() as f32,
                });
                sm.next_puff += 0.24;
            }
        }
        self.effects.extend(spawn);
        self.effects.retain(|e| !e.done(now));
        self.fire_anims.retain(|f| now < f.launch + 0.3);
        self.move_anims.retain(|m| !m.done(now));
        // 击毁弹已落地：待毁棋子消失，由刚生成的尸体/残骸动画接管
        self.pending_deaths.retain(|d| now < d.land_at);
        self.corpses.retain(|c| !c.done(now));
        self.wrecks.retain(|w| !w.done(now));
        self.smokers.retain(|s| now < s.until);
    }

    /// 生成开火弹药特效（曳光/炮弹/导弹/抛物线）。
    fn spawn_projectile(&self, out: &mut Vec<fx::Effect>, f: &FireAnim) {
        let ev = &f.ev;
        let hs = self.map_hs;
        let s = self.map_s;
        let from_c = self.hex_center_pos(ev.from);
        let to_c = self.hex_center_pos(ev.target);
        let prof = fx::weapon_profile(ev.kind, ev.aa_mode, ev.missile_mode, ev.area);
        let pose = self
            .poses
            .get(&(ev.team, ev.label))
            .copied()
            .unwrap_or_else(|| fx::Pose::default_for(ev.team));
        let aim = pieces::angle_between(from_c, to_c);
        // 出膛位置：车辆 = 炮口（沿炮塔方向）；步兵 = 射手前沿；炮兵 = 炮管口
        let from = if ev.area {
            egui::pos2(
                from_c.x + 17.0 * s * pose.hull.cos(),
                from_c.y + 17.0 * s * pose.hull.sin(),
            )
        } else if ev.kind.is_vehicle() {
            egui::pos2(
                from_c.x + 16.0 * s * pose.turret.cos(),
                from_c.y + 16.0 * s * pose.turret.sin(),
            )
        } else {
            egui::pos2(
                from_c.x + 7.0 * s * aim.cos(),
                from_c.y + 7.0 * s * aim.sin(),
            )
        };
        let impact = if ev.hit {
            Some(fx::Impact {
                killed: ev.killed,
                blocked: ev.blocked,
                target_kind: ev.target_kind,
                target_team: ev.target_team,
                target_label: ev.target_label,
                target_hex: ev.target,
                target_hp_before: ev.target_hp_before,
                dmg: ev.dmg,
            })
        } else {
            None // 未命中：飞过目标后淡出
        };
        // 炮口火光（曳光弹轻微，其余明显）
        out.push(fx::Effect::Flash {
            pos: from,
            ang: if ev.kind.is_vehicle() && !ev.area { pose.turret } else { aim },
            t0: f.launch,
            scale: if prof.kind == fx::ProjKind::Tracer { 0.7 } else { 1.2 },
        });
        if ev.area {
            // 榴弹炮/迫击炮：抛物线 + 落地爆炸覆盖全 blast（附带被波及击毁者）
            let blast = ev.blast.iter().map(|&h| self.hex_center_pos(h)).collect();
            let kills = ev
                .killed_units
                .iter()
                .map(|k| fx::Impact {
                    killed: true,
                    blocked: false,
                    target_kind: k.kind,
                    target_team: k.team,
                    target_label: k.label,
                    target_hex: k.hex,
                    target_hp_before: k.hp_before,
                    dmg: k.hp_before,
                })
                .collect();
            out.push(fx::Effect::Arc {
                from,
                to: to_c,
                t0: f.launch,
                dur: f.flight,
                height: prof.arc.unwrap_or(52.0),
                smoke_shell: ev.smoke_shell,
                blast,
                kills,
                consumed: false,
            });
            return;
        }
        match prof.kind {
            fx::ProjKind::Tracer | fx::ProjKind::Autocannon => {
                out.push(fx::Effect::Tracer {
                    from,
                    to: to_c,
                    t0: f.launch,
                    dur: f.flight,
                    kind: prof.kind,
                });
                // 重机枪/机关炮：连发展现（2-3 发快速曳光）
                if prof.kind == fx::ProjKind::Autocannon || ev.kind == UnitKind::HmgGunner {
                    for k in 1..3 {
                        out.push(fx::Effect::Tracer {
                            from,
                            to: to_c,
                            t0: f.launch + 0.05 * k as f64,
                            dur: f.flight,
                            kind: prof.kind,
                        });
                    }
                }
            }
            fx::ProjKind::Javelin => {
                let mid = egui::pos2((from.x + to_c.x) / 2.0, (from.y + to_c.y) / 2.0 - 34.0 * hs / 26.0 * s);
                out.push(fx::Effect::Missile {
                    from,
                    to: to_c,
                    ctrl: Some(mid),
                    t0: f.launch,
                    dur: f.flight,
                    kind: prof.kind,
                    impact,
                    consumed: false,
                });
            }
            _ => {
                out.push(fx::Effect::Missile {
                    from,
                    to: to_c,
                    ctrl: None,
                    t0: f.launch,
                    dur: f.flight,
                    kind: prof.kind,
                    impact,
                    consumed: false,
                });
            }
        }
    }

    /// 弹药落地后果：命中爆炸/火花、击毁爆炸+残骸（或全体士兵变灰）、冒烟。
    fn spawn_landing(&mut self, out: &mut Vec<fx::Effect>, l: fx::Landing) {
        let now = self.time;
        // 范围炮击：blast 全部格子依次起爆（中心更大）
        for (i, bp) in l.blast.iter().enumerate() {
            out.push(fx::Effect::Explosion {
                pos: *bp,
                t0: now + i as f64 * 0.045,
                big: *bp == l.pos,
            });
        }
        // 被炮击波及击毁的单位：弹落地即生成尸体/残骸
        for imp in &l.kills {
            self.spawn_death_fx(out, imp);
        }
        if l.smoke_shell {
            for i in 0..5 {
                out.push(fx::Effect::Puff {
                    pos: l.pos,
                    t0: now + i as f64 * 0.06,
                    big: true,
                    white: true,
                    seed: (i as f32 * 0.37 + 0.11).fract(),
                });
            }
            return;
        }
        let Some(imp) = l.impact else { return };
        if imp.blocked {
            // 命中但被护甲/主动防御挡下：弹开火花
            out.push(fx::Effect::Spark { pos: l.pos, t0: now });
            return;
        }
        if imp.killed {
            out.push(fx::Effect::Explosion { pos: l.pos, t0: now, big: true });
            for i in 0..3 {
                out.push(fx::Effect::Puff {
                    pos: l.pos,
                    t0: now + 0.25 + i as f64 * 0.14,
                    big: true,
                    white: false,
                    seed: (i as f32 * 0.53 + 0.2).fract(),
                });
            }
            self.spawn_death_fx(out, &imp);
            return;
        }
        // 命中未击毁：载具冒烟；步兵部分士兵变灰
        if imp.target_kind.is_vehicle() {
            self.smokers.push(fx::Smoker {
                pos: l.pos,
                until: now + 2.6,
                next_puff: now,
            });
            out.push(fx::Effect::Spark { pos: l.pos, t0: now });
        } else if imp.target_kind.is_foot() && imp.dmg > 0 {
            let before = pieces::soldiers_alive(imp.target_kind, imp.target_hp_before);
            let after = pieces::soldiers_alive(imp.target_kind, imp.target_hp_before - imp.dmg);
            if before > after {
                let pose = self
                    .poses
                    .get(&(imp.target_team, imp.target_label))
                    .copied()
                    .unwrap_or_else(|| fx::Pose::default_for(imp.target_team));
                let slots = pieces::soldier_slots(before);
                self.corpses.push(fx::Corpses {
                    hex: imp.target_hex,
                    t0: now,
                    facing: pose.hull,
                    slots: slots[after..before].to_vec(),
                });
            }
        }
    }

    /// 击毁单位的尸体/残骸特效（棋子由 pending_deaths 在同一时刻移除）。
    fn spawn_death_fx(&mut self, out: &mut Vec<fx::Effect>, imp: &fx::Impact) {
        let now = self.time;
        if imp.target_kind.is_vehicle() && !imp.target_kind.is_air() {
            // 载具残骸：变灰停留后再淡出
            let pose = self
                .poses
                .get(&(imp.target_team, imp.target_label))
                .copied()
                .unwrap_or_else(|| fx::Pose::default_for(imp.target_team));
            self.wrecks.push(fx::Wreck {
                hex: imp.target_hex,
                kind: imp.target_kind,
                team: imp.target_team,
                t0: now,
                hull: pose.hull,
                turret: pose.turret,
            });
        } else if imp.target_kind.is_foot() && imp.target_kind != UnitKind::Headquarters {
            // 步兵全灭：全体士兵变灰
            let pose = self
                .poses
                .get(&(imp.target_team, imp.target_label))
                .copied()
                .unwrap_or_else(|| fx::Pose::default_for(imp.target_team));
            let n = pieces::soldiers_alive(imp.target_kind, imp.target_hp_before);
            self.corpses.push(fx::Corpses {
                hex: imp.target_hex,
                t0: now,
                facing: pose.hull,
                slots: pieces::soldier_slots(n)[..n].to_vec(),
            });
        } else if imp.target_kind.is_air() {
            // 空中单位坠毁：额外的坠落烟团
            for i in 0..2 {
                out.push(fx::Effect::Puff {
                    pos: self.hex_center_pos(imp.target_hex),
                    t0: now + 0.5 + i as f64 * 0.2,
                    big: false,
                    white: false,
                    seed: (i as f32 * 0.71 + 0.3).fract(),
                });
            }
        }
    }

    // ---------- 临时自检：全兵种开火演示（HEX_WARGAME_FX_DEMO=1，验证后删除） ----------

    #[allow(clippy::too_many_arguments)]
    fn demo_fire(
        kind: UnitKind,
        from: (i32, i32),
        target: (i32, i32),
        missile_mode: bool,
        aa_mode: bool,
        area: bool,
        hit: bool,
        killed: bool,
        target_kind: UnitKind,
    ) -> hex_wargame::game::UiFireEvent {
        let tgt = hex::axial_from_offset(target.0, target.1);
        hex_wargame::game::UiFireEvent {
            team: Team::Player,
            label: 'Z',
            kind,
            from: hex::axial_from_offset(from.0, from.1),
            target: tgt,
            target_team: Team::Ai,
            target_label: 'x',
            target_kind,
            aa_mode,
            missile_mode,
            area,
            smoke_shell: false,
            blast: if area {
                let mut v = vec![tgt];
                v.extend(tgt.neighbors());
                v
            } else {
                Vec::new()
            },
            hit,
            blocked: false,
            killed,
            target_hp_before: if killed { 1 } else { 3 },
            dmg: 1,
            killed_units: Vec::new(),
        }
    }

    fn queue_fx_demo(&mut self) {
        let d = |kind, from, target, mm, aa, area, hit, killed, tk| {
            Self::demo_fire(kind, from, target, mm, aa, area, hit, killed, tk)
        };
        // 移动滑行
        self.game.ui_events.push(UiEvent::Move {
            team: Team::Player,
            label: 'Z',
            kind: UnitKind::Tank,
            path: vec![
                hex::axial_from_offset(3, 4),
                hex::axial_from_offset(4, 4),
                hex::axial_from_offset(5, 4),
            ],
            air: false,
        });
        // 步枪曳光（命中：部分士兵变灰）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::Rifleman, (7, 3), (13, 3), false, false, false, true, false, UnitKind::Rifleman,
        )));
        // 坦克炮（高速炮弹 + 炮口火光）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::Tank, (7, 4), (15, 4), false, false, false, true, false, UnitKind::Tank,
        )));
        // TOW 导弹（未命中：飞越目标淡出）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::Atgm, (7, 6), (18, 6), false, false, false, false, false, UnitKind::Tank,
        )));
        // Javelin 高抛顶攻（命中载具未毁：冒烟）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::Javelin, (7, 7), (14, 7), false, false, false, true, false, UnitKind::Tank,
        )));
        // Stinger 防空（对空中目标）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::AaInfantry, (7, 8), (20, 2), false, true, false, true, false, UnitKind::AttackHeli,
        )));
        // 榴弹炮范围炮击（抛物线 + 7 格连环爆炸）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::Howitzer, (7, 1), (17, 1), false, false, true, true, true, UnitKind::Rifleman,
        )));
        // XM1176 击毁步兵班组（全体士兵变灰）
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::Rifleman, (7, 9), (13, 9), true, false, false, true, true, UnitKind::Rifleman,
        )));
        // M3E1 火箭筒上肩发射
        self.game.ui_events.push(UiEvent::Fire(d(
            UnitKind::EliteInfantry, (7, 10), (12, 10), true, false, false, true, false, UnitKind::Tank,
        )));
    }

    fn current_winner(&self) -> Option<Team> {
        if self.game.winner.is_some() {
            return self.game.winner;
        }
        // 普通模式：一方全灭即结束。可持续部署模式：全灭还不够——
        // 必须 game_over()（全灭 + 大本营被完全占领）才判胜，否则还能增援。
        if !self.game.game_over() {
            return None;
        }
        if !self.game.team_alive(Team::Player) {
            Some(Team::Ai)
        } else if !self.game.team_alive(Team::Ai) {
            Some(Team::Player)
        } else {
            None
        }
    }

    fn finish_game(&mut self, winner: Team) {
        let msg = if self.multiplayer {
            match winner {
                Team::Player => "★ 蓝方获胜！".to_string(),
                Team::Ai => "★ 红方获胜！".to_string(),
            }
        } else if self.game.sustain || !self.game.keypoints.is_empty() {
            let total = self
                .game
                .keypoints
                .values()
                .filter(|k| !k.center)
                .count();
            match winner {
                Team::Player => format!("★ 胜利！达成胜利条件（关键据点 {} 个）", total),
                Team::Ai => "✗ 失败！敌方达成了胜利条件。".to_string(),
            }
        } else {
            match winner {
                Team::Player => "★ 胜利！你消灭了所有敌军！".to_string(),
                Team::Ai => "✗ 失败！你的部队全军覆没。".to_string(),
            }
        };
        if self.multiplayer {
            self.net_dirty = true;
            if let Some(hub) = self.net.clone() {
                if let Ok(h) = hub.lock() {
                    h.broadcast(&mp::ServerMessage::Message(format!("对局结束：{}", msg)));
                }
            }
        }
        self.game_over = Some(msg);
        self.selected = None;
        self.load_mode = false;
    }

    /// 僵局平局收场：与单机模式一致（连续 20 回合无击毁），
    /// 并像胜负判定一样向所有终端客户端播报，避免对局永不结束。
    fn finish_draw(&mut self) {
        let msg = if self.multiplayer {
            "▬ 平局：连续 20 回合无击毁（僵局）。"
        } else {
            "▬ 平局：双方都无法造成有效杀伤（僵局）。"
        };
        if self.multiplayer {
            self.net_dirty = true;
            if let Some(hub) = self.net.clone() {
                if let Ok(h) = hub.lock() {
                    h.broadcast(&mp::ServerMessage::Message(format!("对局结束：{}", msg)));
                }
            }
        }
        self.game_over = Some(msg.to_string());
        self.selected = None;
        self.load_mode = false;
    }

    /// 所有己方单位行动完毕则自动结束回合。
    fn after_action(&mut self) {
        if self.game_over.is_some() {
            return;
        }
        if self.multiplayer {
            if self.game.game_over() {
                return;
            }
            let team = self.game.phase;
            let units = self.game.units_of(team);
            // 空部队不自动结束：可持续部署模式下全军覆没的一方仍可追加部署增援。
            if !units.is_empty() && units.iter().all(|u| u.actions_left == 0) {
                self.log(format!(
                    "{}方所有单位行动完毕，自动结束回合。",
                    mp::team_label(team)
                ));
                self.end_turn_for(team);
            }
            return;
        }
        if self
            .game
            .units_of(Team::Player)
            .iter()
            .all(|u| u.actions_left == 0)
        {
            // 可持续部署：全灭但大本营未失守 → 提示按 D 部署增援（不自动结束回合）
            if self.game.sustain && !self.game.team_alive(Team::Player) {
                self.log("⚠ 你已全军覆没！按 D 追加部署增援（大本营未被占领前还可再战）".into());
                return;
            }
            self.log("所有单位行动完毕，自动结束回合。".into());
            self.end_player_turn();
        }
    }

    /// 是否正在 AI 回合（后台思考或播放其行动）：期间屏蔽玩家输入。
    fn ai_busy(&self) -> bool {
        self.ai_thread.is_some() || self.ai_playback || self.ai_think_elapsed.is_some()
    }

    /// AI 回合状态标记：思考中 / 已思考 xx 秒；玩家回合开始时消失。
    fn ai_status_marker(&self) -> Option<String> {
        if self.ai_thread.is_some() {
            Some("🤖 AI 思考中…".to_string())
        } else if self.ai_playback {
            self.ai_think_elapsed.map(|s| format!("🤖 AI 已思考 {:.1} 秒", s))
        } else {
            None
        }
    }

    /// 战斗动画/特效是否仍在排队播放（判断 AI 行动何时播完）。
    fn fx_active(&self) -> bool {
        // 注意：finalize_ai_turn 在 draw_map（drain_ui_events）之前调用，
        // 因此这里还要把"尚未入队的 AI 事件"算作未播完，避免 AI 事件还没
        // 播放就提前交还玩家回合。
        self.fx_clock > self.time
            || !self.move_anims.is_empty()
            || !self.fire_anims.is_empty()
            || !self.pending_deaths.is_empty()
            || !self.game.ui_events.is_empty()
    }

    /// 轮询后台 AI 线程；算完则接管新局面并进入「AI 行动播放」阶段。
    fn poll_ai_thread(&mut self) {
        let Some(handle) = self.ai_thread.take() else {
            return;
        };
        if !handle.is_finished() {
            self.ai_thread = Some(handle);
            return;
        }
        match handle.join() {
            Ok((state, msgs)) => {
                if std::env::var_os("HEX_WARGAME_DEBUG").is_some() {
                    for m in &msgs {
                        eprintln!("[gui] {}", m);
                    }
                }
                let elapsed = self
                    .ai_think_start
                    .take()
                    .map(|t0| (self.time - t0).max(0.0))
                    .unwrap_or(0.0);
                self.game = state;
                // 完整 AI 行动写入事件日志：导出日志 / 存档仍包含全部 AI 数据；
                // GUI 底部日志在 drain_ui_events 中按玩家视野过滤显示。
                self.game.event_log.extend(msgs);
                self.ai_think_elapsed = Some(elapsed);
                self.ai_playback = true;
            }
            Err(_) => {
                self.ai_think_start = None;
                self.ai_think_elapsed = None;
                self.ai_playback = false;
                self.log("⚠ AI 回合计算异常终止".into());
            }
        }
    }

    /// AI 行动播放完毕后交接：判定胜负/平局，进入玩家回合并清除标记。
    fn finalize_ai_turn(&mut self) {
        if !self.ai_playback || self.fx_active() {
            return;
        }
        self.ai_playback = false;
        self.ai_think_elapsed = None;
        if let Some(w) = self.current_winner() {
            self.finish_game(w);
            return;
        }
        if self.game.is_draw() {
            self.game_over = Some("▬ 平局：双方都无法造成有效杀伤（僵局）。".into());
            return;
        }
        self.game.begin_turn(Team::Player);
        self.log(format!("—— 第 {} 回合 · 你的行动 ——", self.game.turn));
    }

    /// 结束玩家回合：先立即播放玩家最后一道指令的动画，再在后台计算 AI 回合。
    /// AI 计算期间 UI 保持响应并显示「AI 思考中」，算完播放其行动时显示耗时。
    fn end_player_turn(&mut self) {
        // 已在 AI 回合（后台思考或播放行动）时忽略重复触发，避免并行起两个 AI 线程。
        if self.game_over.is_some() || self.ai_busy() {
            return;
        }
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.confirm_action = None;
        self.load_mode = false;
        self.game.begin_turn(Team::Ai);
        // 立即播放玩家最后一道指令的动画，不等 AI 计算（避免单击后卡 1-3 秒）。
        self.drain_ui_events();
        if self.game.test_mode {
            self.log("🧪 试验模式：敌方本回合不行动。".into());
            if let Some(w) = self.current_winner() {
                self.finish_game(w);
                return;
            }
            if self.game.is_draw() {
                self.game_over = Some("▬ 平局：双方都无法造成有效杀伤（僵局）。".into());
                return;
            }
            self.game.begin_turn(Team::Player);
            self.log(format!("—— 第 {} 回合 · 你的行动 ——", self.game.turn));
            return;
        }
        self.log(format!("—— 第 {} 回合 · AI 行动 ——", self.game.turn));
        // 在干净副本上后台计算：UI 线程继续播放动画并显示「AI 思考中」。
        let mut state = self.game.clone();
        state.ui_events.clear();
        self.ai_think_start = Some(self.time);
        self.ai_think_elapsed = None;
        self.ai_playback = false;
        self.ai_thread = Some(std::thread::spawn(move || {
            let msgs = ai_router::take_turn(&mut state, Team::Ai);
            (state, msgs)
        }));
    }

    /// 导出完整对局日志到 logs/ 目录（含初始种子与全部事件，可完全复原对局）。
    /// 内容包含：基础信息、逐条事件记录、结构化战报（击毁/据点/胜负）、
    /// 终局态势（双方存活/损失/据点）与双方视角的最终文本快照。
    fn export_log(&mut self) -> Result<String, String> {
        use std::time::{SystemTime, UNIX_EPOCH};
        std::fs::create_dir_all("logs").map_err(|e| e.to_string())?;
        let secs = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let fname = format!("wargame_seed{}_{}.log", self.game.seed, secs);
        let path = format!("logs/{}", fname);
        let mut text = String::new();
        text.push_str("════════ 六边形战争 对局日志 ════════\n");
        text.push_str("版本: 2\n");
        text.push_str(&format!(
            "初始种子: {}（用此种子 + 下列事件可完全复原本局）\n",
            self.game.seed
        ));
        text.push_str(&format!(
            "地图: {}x{}  模式: {}\n\n",
            self.game.map.cols,
            self.game.map.rows,
            if self.game.deploying {
                "部署阶段"
            } else if self.game.test_mode {
                "对局中 · 试验模式"
            } else {
                "对局中"
            }
        ));
        text.push_str("── 事件记录 ──\n");
        if self.game.event_log.is_empty() {
            text.push_str("（暂无事件）\n");
        } else {
            for line in &self.game.event_log {
                text.push_str(line);
                text.push('\n');
            }
        }

        // 结构化战报：不依赖中文措辞的稳定格式，供复盘工具直接解析
        text.push_str("\n── 结构化战报 ──\n");
        if self.game.battle_events.is_empty() {
            text.push_str("（暂无战报事件）\n");
        } else {
            for ev in &self.game.battle_events {
                match &ev.kind {
                    hex_wargame::game::BattleEventKind::Kill(k) => {
                        let attacker = match (k.attacker_label, k.attacker_kind) {
                            (Some(label), Some(kind)) => format!(
                                "{} {}({})",
                                k.attacker_team.map(mp::team_full_label).unwrap_or("未知方"),
                                label,
                                kind.name()
                            ),
                            _ => "未知来源".to_string(),
                        };
                        text.push_str(&format!(
                            "#{} 第{}回合 击毁 {} {}({}) @{} ← {}（{}）{}\n",
                            ev.seq,
                            ev.turn,
                            mp::team_full_label(k.victim_team),
                            k.victim_label,
                            k.victim_kind.name(),
                            hex::hex_label(k.victim_pos),
                            attacker,
                            k.cause.cn(),
                            if k.passenger { "，随载具阵亡" } else { "" }
                        ));
                    }
                    hex_wargame::game::BattleEventKind::Keypoint {
                        hex,
                        center,
                        from,
                        to,
                        by_label,
                        by_kind,
                    } => {
                        text.push_str(&format!(
                            "#{} 第{}回合 据点易手 {} → {}：{} 的 {}({}) 占领 {} {}\n",
                            ev.seq,
                            ev.turn,
                            mp::team_full_label(*from),
                            mp::team_full_label(*to),
                            mp::team_full_label(*to),
                            by_label,
                            by_kind.name(),
                            hex::hex_label(*hex),
                            if *center { "（大本营中心）" } else { "" }
                        ));
                    }
                    hex_wargame::game::BattleEventKind::Victory { winner, reason } => {
                        text.push_str(&format!(
                            "#{} 第{}回合 胜负判定: {}获胜（{}）\n",
                            ev.seq,
                            ev.turn,
                            mp::team_full_label(*winner),
                            reason
                        ));
                    }
                }
            }
        }

        // 终局态势：双方存活/损失/据点，便于快速复盘
        text.push_str("\n── 终局态势 ──\n");
        for team in [Team::Player, Team::Ai] {
            let alive = self.game.units_of(team);
            let lost = self
                .game
                .battle_events
                .iter()
                .filter(|e| {
                    matches!(&e.kind, hex_wargame::game::BattleEventKind::Kill(k) if k.victim_team == team)
                })
                .count();
            let units: Vec<String> = alive
                .iter()
                .map(|u| format!("{}({})@{}", u.label, u.kind.name(), hex::hex_label(u.pos)))
                .collect();
            text.push_str(&format!(
                "{}: 存活 {} 个 · 损失 {} 个 · 被歼灭点数 {} · 部队: {}\n",
                mp::team_full_label(team),
                alive.len(),
                lost,
                self.game.killed_value.get(&team).copied().unwrap_or(0),
                if units.is_empty() {
                    "（无）".to_string()
                } else {
                    units.join(" ")
                }
            ));
        }
        if !self.game.keypoints.is_empty() {
            let list: Vec<String> = self
                .game
                .keypoints
                .iter()
                .map(|(h, kp)| {
                    format!(
                        "{}{}={}",
                        hex::hex_label(*h),
                        if kp.center { "★" } else { "⚑" },
                        mp::team_full_label(kp.controller)
                    )
                })
                .collect();
            text.push_str(&format!("关键据点: {}\n", list.join(" ")));
        }

        text.push_str("\n── 对局结果 ──\n");
        text.push_str(match &self.game_over {
            Some(msg) => msg.as_str(),
            None => {
                if self.game.winner == Some(Team::Player) {
                    "玩家胜利"
                } else if self.game.winner == Some(Team::Ai) {
                    "AI 胜利"
                } else {
                    "对局进行中"
                }
            }
        });
        text.push('\n');

        // 双方视角的最终文本快照：与终端客户端收到的最后一帧一致
        text.push_str("\n── 最终快照 · 蓝方视角 ──\n");
        text.push_str(&mp::render_state(&self.game, Team::Player, None));
        text.push_str("\n── 最终快照 · 红方视角 ──\n");
        text.push_str(&mp::render_state(&self.game, Team::Ai, None));

        std::fs::write(&path, text).map_err(|e| e.to_string())?;
        Ok(path)
    }

    fn saves_dir() -> PathBuf {
        std::fs::create_dir_all("saves").ok();
        PathBuf::from("saves")
    }

    fn scan_saves() -> Vec<(String, PathBuf)> {
        let mut out = Vec::new();
        if let Ok(rd) = std::fs::read_dir(Self::saves_dir()) {
            let mut files: Vec<PathBuf> = rd
                .filter_map(|e| e.ok().map(|e| e.path()))
                .filter(|p| p.extension().map(|x| x == "json").unwrap_or(false))
                .collect();
            files.sort();
            for f in files {
                if let Some(name) = f.file_name().map(|s| s.to_string_lossy().into_owned()) {
                    out.push((name, f));
                }
            }
        }
        out
    }

    /// 保存当前完整游戏状态到 saves/ 目录（JSON）。
    fn save_game(&mut self) -> Result<String, String> {
        use std::time::{SystemTime, UNIX_EPOCH};
        std::fs::create_dir_all("saves").map_err(|e| e.to_string())?;
        let secs = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let fname = format!(
            "save_seed{}_t{}_{}.json",
            self.game.seed, self.game.turn, secs
        );
        let path = Self::saves_dir().join(fname);
        self.game.save_to_file(&path)?;
        Ok(path.display().to_string())
    }

    /// 从 JSON 存档加载游戏状态，并从该位置继续。
    fn load_game(&mut self, path: &std::path::Path) -> Result<(), String> {
        let g = GameState::load_from_file(path)?;
        self.game = g;
        self.level = self.game.level;
        self.custom_map = self.game.custom.clone();
        self.sustain_mode = self.game.sustain;
        self.sustain_pp = self
            .game
            .sustain_per_turn
            .get(&Team::Player)
            .copied()
            .unwrap_or(10);
        self.sustain_ap = self
            .game
            .sustain_per_turn
            .get(&Team::Ai)
            .copied()
            .unwrap_or(20);
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.pending_disembark = None;
        self.pending_recruit = None;
        self.smoke_shot_pending = false;
        self.howitzer_fire_mode = false;
        // 清空战斗动画视图状态（读档后单位布局完全不同）
        self.map_layer = None;
        self.poses.clear();
        self.move_anims.clear();
        self.fire_anims.clear();
        self.pending_deaths.clear();
        self.effects.clear();
        self.corpses.clear();
        self.wrecks.clear();
        self.smokers.clear();
        self.fx_clock = 0.0;
        // 读档时同样清除 AI 回合状态。
        self.ai_thread = None;
        self.ai_think_start = None;
        self.ai_think_elapsed = None;
        self.ai_playback = false;
        self.ranger_mode = false;
        self.ranger_first = None;
        self.ranger_last = None;
        self.simul_mode = false;
        self.simul_orders.clear();
        self.game_over = None;
        self.confirm_action = None;
        self.revealed.clear();
        self.visible_enemies.clear();
        self.ghosts.clear();
        self.dist_map.clear();
        self.log_hover = None;
        self.log.clear();
        if self.game.deploying {
            self.log("—— 第 0 回合 · 部署阶段（已从存档加载）——".into());
        } else {
            self.log(format!(
                "—— 第 {} 回合 · 你的行动（已从存档加载）——",
                self.game.turn
            ));
        }
        Ok(())
    }

    /// 结束当前选中单位的本回合行动（剩余行动作废）。
    fn pass_unit(&mut self) {
        if let Some(sel) = self.selected {
            // 仅对当前 GUI 可控的己方单位生效（敌方单位只可查看）
            let Some(me) = self.gui_control_team() else {
                return;
            };
            let mine = self
                .game
                .units
                .get(&sel)
                .map(|u| u.team == me)
                .unwrap_or(false)
                || self
                    .game
                    .air_units
                    .get(&sel)
                    .map(|u| u.team == me)
                    .unwrap_or(false);
            let info = if !mine {
                None
            } else if self.selected_is_air && self.game.air_units.contains_key(&sel) {
                if let Some(u) = self.game.air_units.get_mut(&sel) {
                    let name = u.name_with_label();
                    let left = u.actions_left;
                    u.actions_left = 0;
                    Some((name, left))
                } else {
                    None
                }
            } else if let Some(u) = self.game.unit_at_mut(sel) {
                let name = u.name_with_label();
                let left = u.actions_left;
                u.actions_left = 0;
                Some((name, left))
            } else {
                None
            };
            if let Some((name, left)) = info {
                self.log(format!(
                    "{} 结束本回合行动 (剩余 {} 次行动作废)",
                    name, left
                ));
            }
            self.selected = None;
            self.selected_is_air = true;
            self.load_mode = false;
            self.zero_hint = None;
            self.after_action();
        }
    }

    // ---------- 地图绘制 ----------

    fn hex_center(&self, origin: egui::Pos2, col: i32, row: i32, hs: f32) -> egui::Pos2 {
        egui::pos2(
            origin.x + 1.732_050_8 * hs * (col as f32 + 0.5 * (row % 2) as f32),
            origin.y + 1.5 * hs * row as f32,
        )
    }

    fn hex_vertices(&self, c: egui::Pos2, hs: f32) -> Vec<egui::Pos2> {
        (0..6)
            .map(|i| {
                let ang = std::f32::consts::PI / 6.0 + i as f32 * std::f32::consts::PI / 3.0;
                egui::pos2(c.x + hs * ang.cos(), c.y + hs * ang.sin())
            })
            .collect()
    }

    fn point_in_poly(&self, p: egui::Pos2, verts: &[egui::Pos2]) -> bool {
        let mut inside = false;
        let mut j = verts.len() - 1;
        for i in 0..verts.len() {
            let a = verts[i];
            let b = verts[j];
            if (a.y > p.y) != (b.y > p.y) {
                let xint = (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x;
                if p.x < xint {
                    inside = !inside;
                }
            }
            j = i;
        }
        inside
    }

    fn pixel_to_hex(&self, p: egui::Pos2, origin: egui::Pos2, hs: f32) -> Option<Hex> {
        for row in 0..self.game.map.rows {
            for col in 0..self.game.map.cols {
                let c = self.hex_center(origin, col, row, hs);
                if self.point_in_poly(p, &self.hex_vertices(c, hs)) {
                    return Some(hex::axial_from_offset(col, row));
                }
            }
        }
        None
    }

/// 滚轮缩放：围绕鼠标位置 p 缩放地图，保持鼠标下的地图点不动。
/// 返回 (新 zoom, 新 pan)。rect_center 为面板中心；map_w/map_h 为缩放前地图像素尺寸；
/// old_zoom 为缩放前系数；pan 为缩放前平移；scroll 为滚轮增量（向上为正）。
fn scroll_zoom(
    rect_center: egui::Pos2,
    map_w: f32,
    map_h: f32,
    old_zoom: f32,
    pan: egui::Vec2,
    p: egui::Pos2,
    scroll: f32,
) -> (f32, egui::Vec2) {
    let k = (scroll * 0.002).exp();
    let new_zoom = (old_zoom * k).clamp(0.15, 7.0);
    // 缩放前地图原点（不含平移）
    let origin0 = egui::pos2(rect_center.x - map_w / 2.0, rect_center.y - map_h / 2.0);
    // 鼠标相对地图原点的偏移（以缩放前像素计）
    let rel = p - origin0 - pan;
    // 缩放后新的原点 + 平移补偿：使该地图点仍在鼠标下
    let origin0_new = egui::pos2(
        rect_center.x - map_w / 2.0 * new_zoom / old_zoom,
        rect_center.y - map_h / 2.0 * new_zoom / old_zoom,
    );
    let k_real = new_zoom / old_zoom;
    let pan_new = p - origin0_new - rel * k_real;
    (new_zoom, pan_new)
}

    fn draw_map(&mut self, ui: &mut egui::Ui) {
        // 当前渲染视角方：单人 = 蓝方；多人 --view acting = 当前行动方。
        let viewer = self.view_team();
        let size = ui.available_size();
        let (response, painter) = ui.allocate_painter(size, egui::Sense::click_and_drag());
        let rect = response.rect;

        // 按可用区域自适应缩放，让棋盘充满中央面板；再乘以滚轮缩放系数 zoom
        let base_w = HEX_W * (self.game.map.cols as f32 - 1.0) + 2.0 * HEX_SIZE;
        let base_h = HEX_H * (self.game.map.rows as f32 - 1.0) + 2.0 * HEX_SIZE;
        // 自适应缩放：面板占宽时地图按比例缩小（下限 0.5），不再被面板遮挡
        let base_s = ((rect.width() - 56.0) / base_w)
            .min((rect.height() - 56.0) / base_h)
            .clamp(0.5, 1.5);
        let s = (base_s * self.zoom).clamp(0.15, 7.0);
        let hs = HEX_SIZE * s;
        let map_w = base_w * s;
        let map_h = base_h * s;
        let origin = egui::pos2(
            rect.center().x - map_w / 2.0,
            rect.center().y - map_h / 2.0,
        ) + self.pan;
        // 缓存坐标换算参数，供战斗动画把格坐标换算为像素
        self.map_origin = origin;
        self.map_hs = hs;
        self.map_s = s;
        // 取走战斗事件并推进动画（AI 回合事件错峰播放）
        self.drain_ui_events();
        self.update_fx();
        // 临时特效演示触发（无输入时 egui 不重绘，需主动请求）
        if self.fx_demo_pending {
            ui.ctx().request_repaint();
            if self.time > 1.0 {
                self.fx_demo_pending = false;
                self.run_fx_demo();
            }
        }
        // 临时自检：HEX_WARGAME_FX_DEMO=1 时在 8 秒后播放一轮全兵种开火演示
        if std::env::var_os("HEX_WARGAME_FX_DEMO").is_some()
            && self.fx_clock == 0.0
            && self.time > 8.0
        {
            self.queue_fx_demo();
        }
        // 动画/特效播放期间持续重绘（否则 egui 无输入时冻结画面）；
        // AI 后台思考期间也要持续重绘，才能刷新「AI 思考中」标记并轮询线程。
        if !self.effects.is_empty()
            || !self.move_anims.is_empty()
            || !self.fire_anims.is_empty()
            || !self.corpses.is_empty()
            || !self.wrecks.is_empty()
            || !self.smokers.is_empty()
            || self.fx_clock > self.time
            || self.ai_thread.is_some()
            || self.ai_playback
        {
            ui.ctx().request_repaint();
        }

        // —— 滚轮缩放（围绕鼠标位置，保持鼠标下的地图点不动）——
        let scroll = ui.input(|i| i.smooth_scroll_delta.y);
        if response.hovered() && scroll != 0.0 {
            if let Some(p) = response.hover_pos() {
                let (nz, np) = Self::scroll_zoom(rect.center(), map_w, map_h, self.zoom, self.pan, p, scroll);
                self.zoom = nz;
                self.pan = np;
            }
        }
        // —— 按住右键拖动平移地图 ——
        if response.dragged_by(egui::PointerButton::Secondary) {
            self.pan += response.drag_delta();
        }

        // 悬停提示
        if let Some(p) = response.hover_pos() {
            if let Some(h) = self.pixel_to_hex(p, origin, hs) {
                ui.ctx().set_cursor_icon(egui::CursorIcon::PointingHand);
                self.log_hover = Some(h);
            } else {
                self.log_hover = None;
            }
        } else {
            self.log_hover = None;
        }

        // 点击：同格双单位时按"点击位置离哪个兵牌中心更近"选层
        // （空中兵牌画在格中心上方 20s，地面兵牌在格中心）
        if self.ranger_mode {
            // 测距器模式：不点选棋子，先后点两格查看距离/直射/命中率乘数
            if response.clicked() {
                if let Some(p) = response.interact_pointer_pos() {
                    if let Some(h) = self.pixel_to_hex(p, origin, hs) {
                        match self.ranger_first {
                            None => {
                                self.ranger_first = Some(h);
                                self.ranger_last = None;
                                self.log(format!("测距：起点 {}，再点第二格", hex::hex_label(h)));
                            }
                            Some(f) => {
                                self.show_range_info(f, h);
                                self.ranger_last = Some(h);
                            }
                        }
                    }
                }
            }
            if response.secondary_clicked() {
                self.ranger_mode = false;
                self.ranger_first = None;
                self.ranger_last = None;
                self.log("测距器关闭".into());
            }
        } else if response.clicked() {
            if let Some(p) = response.interact_pointer_pos() {
                if let Some(h) = self.pixel_to_hex(p, origin, hs) {
                    let (col, row) = hex::offset_from_axial(h);
                    let c = self.hex_center(origin, col, row, hs);
                    let air_cy = c.y - 20.0 * s;
                    let click_upper = (p.y - air_cy).abs() <= (p.y - c.y).abs();
                    self.handle_click(h, click_upper);
                } else {
                    self.selected = None;
                    self.selected_is_air = true;
                    self.load_mode = false;
                }
            }
        }
        if !self.ranger_mode && response.secondary_clicked() {
            self.selected = None;
            self.selected_is_air = true;
            self.load_mode = false;
        }

        // 高亮集合
        let hl = self.highlight_sets();

        // 选中己方单位：用于绘制其自身视野范围（黄线）与攻击范围（红线）
        let sel_owner = if self.multiplayer {
            self.side_team()
        } else {
            Team::Player
        };
        let sel_u = if self.game.deploying || self.selected.is_none() {
            None
        } else if let Some(u) = self.selected_unit() {
            if u.team == sel_owner {
                Some(u.clone())
            } else {
                None
            }
        } else {
            None
        };

        // 榴弹炮悬停：仅开火模式下预览 7 格爆炸范围
        let mut blast_preview: Vec<Hex> = Vec::new();
        if self.selected.is_some() && self.howitzer_fire_mode {
            if let Some(u) = self.selected_unit() {
                if u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar {
                    if let Some(p) = response.hover_pos() {
                        if let Some(h) = self.pixel_to_hex(p, origin, hs) {
                            if hl.howitzer_targets.contains(&h) {
                                blast_preview.push(h);
                                for n in h.neighbors() {
                                    if self.game.map.contains(n) {
                                        blast_preview.push(n);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 背景 + 棋盘底板
        painter.rect_filled(rect, 0.0, theme::BG);
        let pad = hs + 12.0 * s;
        let board = egui::Rect::from_min_size(
            egui::pos2(origin.x - pad, origin.y - pad),
            egui::vec2(map_w + pad * 2.0, map_h + pad * 2.0),
        );
        painter.rect_filled(board, 14.0, theme::BOARD_FILL);
        painter.rect_stroke(
            board,
            14.0,
            egui::Stroke::new(1.5, theme::BOARD_STROKE),
            egui::StrokeKind::Middle,
        );

        // 静态地图层：地形+装饰+迷雾一次性锯齿化缓存为 1 个 Mesh（仅缩放/视野变化时重建）
        let dsig = maptile::dist_signature(&self.dist_map);
        let layer_stale = self.map_layer.as_ref().map_or(true, |l| {
            l.hs != hs || l.dist_hash != dsig || l.deploying != self.game.deploying
        });
        if layer_stale {
            self.map_layer =
                Some(maptile::build(&self.game, hs, &self.dist_map, self.game.deploying, ui.ctx()));
        }
        painter.add(egui::Shape::mesh(
            self.map_layer.as_ref().unwrap().mesh_at(origin),
        ));

        // 可视区域（棋子裁剪用）
        let view = egui::Rect::from_min_size(origin, egui::vec2(map_w, map_h)).expand(60.0);

        for row in 0..self.game.map.rows {
            for col in 0..self.game.map.cols {
                let hx = hex::axial_from_offset(col, row);
                let c = self.hex_center(origin, col, row, hs);
                let verts = self.hex_vertices(c, hs);

                // 关键据点层：半透明色块（本队控制=蓝色、敌方控制=红色），
                // 中心格画五角星、普通据点画小旗；绘制在单位之下
                if let Some(kp) = self.game.keypoints.get(&hx) {
                    let tint = if kp.controller == viewer {
                        egui::Color32::from_rgba_unmultiplied(56, 118, 240, 84)
                    } else {
                        egui::Color32::from_rgba_unmultiplied(236, 74, 74, 84)
                    };
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        tint,
                        egui::Stroke::NONE,
                    ));
                    let mark = egui::Color32::from_rgba_unmultiplied(255, 255, 255, 235);
                    if kp.center {
                        // 大本营中心：五角星
                        let r = 6.0 * s;
                        let mut star = Vec::new();
                        for i in 0..10 {
                            let ang = std::f32::consts::PI / 2.0
                                + i as f32 * std::f32::consts::PI / 5.0;
                            let rad = if i % 2 == 0 { r } else { r * 0.45 };
                            star.push(egui::pos2(
                                c.x + rad * ang.cos(),
                                c.y - rad * ang.sin(),
                            ));
                        }
                        painter.add(egui::Shape::convex_polygon(
                            star,
                            mark,
                            egui::Stroke::NONE,
                        ));
                    } else {
                        // 普通据点：旗杆 + 小三角旗
                        let px = c.x - 3.2 * s;
                        let top = egui::pos2(px, c.y - 4.5 * s);
                        let bot = egui::pos2(px, c.y + 3.5 * s);
                        painter.add(egui::Shape::line_segment(
                            [top, bot],
                            egui::Stroke::new(1.4 * s, mark),
                        ));
                        painter.add(egui::Shape::convex_polygon(
                            vec![
                                top,
                                egui::pos2(px + 5.5 * s, c.y - 2.2 * s),
                                egui::pos2(px, c.y - 0.2 * s),
                            ],
                            mark,
                            egui::Stroke::NONE,
                        ));
                    }
                }

                // ---- 选中单位的视野/攻击范围框线 ----
                // 红圈 = 攻击范围边界（射程边界的一圈格子）；黄圈 = 该棋子自身的
                // 视野范围边界（距离 = 视野 且 视线畅通）。两个同心环不重叠。
                if let Some(u) = &sel_u {
                    let d = Hex::distance(u.pos, hx);
                    if hx != u.pos {
                        if d == u.kind.range() {
                            painter.add(egui::Shape::convex_polygon(
                                verts.clone(),
                                egui::Color32::TRANSPARENT,
                                egui::Stroke::new(
                                    1.3 * s,
                                    egui::Color32::from_rgb(232, 92, 78),
                                ),
                            ));
                        } else if d == u.kind.vision()
                            && self.game.map.has_los(u.pos, hx)
                        {
                            painter.add(egui::Shape::convex_polygon(
                                verts.clone(),
                                egui::Color32::TRANSPARENT,
                                egui::Stroke::new(
                                    1.1 * s,
                                    egui::Color32::from_rgb(238, 202, 92),
                                ),
                            ));
                        }
                    }
                }

                // ---- 烟雾弹区域：白色半透明覆盖（视野遮挡，不阻挡移动）----
                if let Some(r) = self.game.smoke.get(&hx) {
                    let alpha = if *r >= 2 { 110 } else { 70 }; // 越接近消散越淡
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        egui::Color32::from_rgba_unmultiplied(225, 225, 218, alpha),
                        egui::Stroke::new(1.2 * s, egui::Color32::from_rgba_unmultiplied(245, 245, 240, 160)),
                    ));
                }

                // ---- 部署/招募阶段：可放置区域高亮 ----
                // 出发区域（部署阶段，或多人第 1 回合招募）：本方青色、对方红色淡描边；
                // 追加部署阶段则高亮本方大本营周围 2 格。
                let first_recruit = self.game.sustain_deploying
                    && self.game.recruit_zone_turn > 0
                    && self.game.turn <= self.game.recruit_zone_turn;
                if self.game.deploying || first_recruit {
                    if self.game.in_deploy_zone(viewer, hx) {
                        painter.add(egui::Shape::convex_polygon(
                            verts.clone(),
                            egui::Color32::from_rgba_unmultiplied(80, 200, 230, 26),
                            egui::Stroke::new(1.6 * s, egui::Color32::from_rgb(110, 220, 245)),
                        ));
                    } else if self.game.in_deploy_zone(viewer.opponent(), hx) {
                        painter.add(egui::Shape::convex_polygon(
                            verts.clone(),
                            egui::Color32::TRANSPARENT,
                            egui::Stroke::new(1.2 * s, egui::Color32::from_rgba_unmultiplied(216, 86, 74, 130)),
                        ));
                    }
                } else if self.game.sustain_deploying {
                    if let Some(hq) = self.game.hq_pos(self.side_team()) {
                        if Hex::distance(hq, hx) <= 2 {
                            painter.add(egui::Shape::convex_polygon(
                                verts.clone(),
                                egui::Color32::from_rgba_unmultiplied(80, 200, 230, 24),
                                egui::Stroke::new(1.4 * s, egui::Color32::from_rgba_unmultiplied(110, 220, 245, 200)),
                            ));
                        }
                    }
                }

                // ---- 烟雾弹待发射：射程内格子淡蓝色高亮 ----
                if self.smoke_shot_pending {
                    if let Some(sel) = self.selected {
                        if Hex::distance(sel, hx) <= self
                            .game
                            .unit_at(sel)
                            .map(|u| u.kind.range())
                            .unwrap_or(0)
                            && hx != sel
                        {
                            painter.add(egui::Shape::convex_polygon(
                                verts.clone(),
                                egui::Color32::from_rgba_unmultiplied(150, 190, 255, 26),
                                egui::Stroke::new(1.3 * s, egui::Color32::from_rgb(140, 185, 255)),
                            ));
                        }
                    }
                }

                // ---- 行动高亮（画在迷雾之上，保证可见）----
                // 移动高亮（绿）
                if hl.reachable.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        theme::MOVE_FILL,
                        egui::Stroke::new(1.8 * s, theme::MOVE_EDGE),
                    ));
                }
                // 榴弹炮可炮击点（黄：无需视野，迷雾中也能看到可炮击格）
                if hl.howitzer_targets.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        theme::BOMB_FILL,
                        egui::Stroke::new(1.6 * s, theme::BOMB_EDGE),
                    ));
                }
                // 爆炸范围预览（橙）
                if blast_preview.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        theme::BLAST_FILL,
                        egui::Stroke::new(1.8 * s, theme::BLAST_EDGE),
                    ));
                }
                // 攻击高亮（红：视野内 + 打得穿）
                if hl.attackable.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        theme::ATTACK_FILL,
                        egui::Stroke::new(1.8 * s, theme::ATTACK_EDGE),
                    ));
                }
                // 待放下：合法落点青色高亮
                if hl.disembark_targets.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        egui::Color32::from_rgba_unmultiplied(80, 200, 230, 45),
                        egui::Stroke::new(2.0, egui::Color32::from_rgb(110, 220, 245)),
                    ));
                }
                // 装载模式：可点击上车的紧邻己方单位（青绿）
                if hl.board_targets.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        egui::Color32::from_rgba_unmultiplied(120, 230, 170, 45),
                        egui::Stroke::new(2.0, egui::Color32::from_rgb(120, 230, 170)),
                    ));
                }
                // 视野内但打不穿/类型不符的敌人：灰色细描边提示
                if hl.blocked.contains(&hx) {
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        egui::Color32::TRANSPARENT,
                        egui::Stroke::new(1.4 * s, theme::BLOCKED_EDGE),
                    ));
                }
                // 补给范围：本方任一补给单位周围 2 格（绿色淡水纹）；补给模式下
                // 高亮所选补给单位的半径 2 格（更亮），提示可补给目标。
                let in_supply = self.game.in_supply_zone(viewer, hx);
                let supply_target = self.supply_mode
                    && self.selected.map(|src| Hex::distance(src, hx) <= 2).unwrap_or(false);
                if in_supply || supply_target {
                    let (fill, stroke) = if supply_target {
                        (
                            egui::Color32::from_rgba_unmultiplied(90, 240, 140, 42),
                            egui::Color32::from_rgb(150, 255, 180),
                        )
                    } else {
                        (
                            egui::Color32::from_rgba_unmultiplied(90, 220, 130, 16),
                            egui::Color32::from_rgba_unmultiplied(120, 230, 150, 110),
                        )
                    };
                    painter.add(egui::Shape::convex_polygon(
                        verts.clone(),
                        fill,
                        egui::Stroke::new(1.2 * s, stroke),
                    ));
                }

                // 内容：地面单位 + 同格空中单位（直升机画在上方，避免遮挡）。
                // 视野规则：敌方单位只有处于我方视野内才显示（敌我共享视野）；
                // 不在视野内的敌方单位隐藏（可能在远处留下"?"最后已知标记）。
                let reveal_ok = |u: &Unit| {
                    u.team == viewer
                        || self.visible_enemies.contains(&u.pos)
                        || self.game.test_mode
                };
                // 被毁载具残骸与阵亡士兵尸体（画在棋子之下）。
                // 只有本方看得见的格子才画：残骸位置同样属于视野信息。
                if self.revealed.contains(&hx) {
                    if let Some(w) = self.wrecks.iter().find(|w| w.hex == hx) {
                        w.draw(&painter, c, s, self.time);
                    }
                    for cp in self.corpses.iter().filter(|cp| cp.hex == hx) {
                        cp.draw(&painter, c, s, self.time);
                    }
                }
                // 移动动画进行中的单位隐藏真身（由动画在插值位置代画）
                let moving = |u: &Unit| {
                    self.move_anims
                        .iter()
                        .any(|m| m.active(self.time) && m.team == u.team && m.label == u.label)
                };
                let in_view = view.contains(c);
                let gv = self.game.units.get(&hx).filter(|u| reveal_ok(u) && !moving(u) && in_view);
                let av = self.game.air_units.get(&hx).filter(|u| reveal_ok(u) && !moving(u) && in_view);
                let has_live = gv.is_some() || av.is_some();
                // 选中高亮按层：同格双单位时只高亮当前选中层（空中或地面）
                let sel_any = self.selected == Some(hx);
                let sel_air = sel_any && self.selected_is_air;
                let sel_ground = sel_any && !self.selected_is_air;
                match (gv, av) {
                    (Some(g), Some(a)) => {
                        self.draw_unit(&painter, c, g, sel_ground, s);
                        self.draw_unit(
                            &painter,
                            egui::pos2(c.x, c.y - 20.0 * s),
                            a,
                            sel_air,
                            s,
                        );
                    }
                    (Some(g), None) => {
                        self.draw_unit(&painter, c, g, sel_any, s);
                    }
                    (None, Some(a)) => {
                        self.draw_unit(&painter, c, a, sel_any, s);
                    }
                    (None, None) => {}
                }
                // 本回合被击毁的单位：击毁弹落地前保持显示（棋子不提前消失；
                // 落地时由 pending_deaths 清理 + 尸体/残骸动画接管）
                if !has_live {
                    if let Some(d) = self.pending_deaths.iter().find(|d| d.hex == hx) {
                        let reveal = d.unit.team == viewer
                            || self.visible_enemies.contains(&hx)
                            || self.game.test_mode;
                        if reveal {
                            let u = d.unit.clone();
                            let pos = if d.is_air {
                                egui::pos2(c.x, c.y - 20.0 * s)
                            } else {
                                c
                            };
                            self.draw_unit(&painter, pos, &u, false, s);
                        }
                    }
                }
                // 敌方最后已知位置（鬼影）：该格现在无任何单位时才显示
                if let Some(&(k, _)) = self.ghosts.get(&viewer).and_then(|g| g.get(&hx)) {
                    let occupied = self.game.unit_at(hx).is_some();
                    if !occupied {
                        self.draw_ghost(&painter, c, k, s);
                    }
                }
                // 迷雾开火警报（红色 ! 幽灵）：从迷雾中向我军开火的敌方位置。
                // 该格若已有可见敌方单位则不再叠加（标记在单位被发现时已失效）。
                if !self.game.deploying {
                    if let Some(marks) = self.game.fog_fire_marks.get(&viewer) {
                        if marks.contains_key(&hx) && !self.visible_enemies.contains(&hx) {
                            self.draw_ghost_alarm(&painter, c, s);
                        }
                    }
                }
                // 部署阶段：悬停显示待放置单位预览
                if self.game.deploying {
                    if let Some(kind) = self.pending_recruit {
                        if self.log_hover == Some(hx) && self.game.unit_at(hx).is_none() {
                            self.draw_deploy_preview(&painter, c, kind, s);
                        }
                    }
                }
            }
        }
        // ---- 移动动画：单位沿路径滑行（插值位置代画） ----
        for m in &self.move_anims {
            if !m.active(self.time) || m.path.len() < 2 {
                continue;
            }
            if let Some(u) = self.find_unit(m.team, m.label) {
                // 迷雾：不属于本视角方、又不在可见敌人集合里的移动单位不画。
                if u.team != viewer && !self.visible_enemies.contains(&u.pos) {
                    continue;
                }
                let (seg, frac) = m.progress(self.time);
                let a = self.hex_center_pos(m.path[seg]);
                let b = self.hex_center_pos(m.path[(seg + 1).min(m.path.len() - 1)]);
                let mut pos = egui::pos2(a.x + (b.x - a.x) * frac, a.y + (b.y - a.y) * frac);
                if u.kind.is_air() {
                    pos.y -= 20.0 * s;
                }
                // 车头始终朝向前进方向：按当前路径段实时定向，转弯节点处平滑转向。
                // 未开火时炮塔随车身同向；开火后炮塔保持瞄准方向。
                let base = self.pose_of(u);
                let hull = self.move_heading(&m.path, seg, frac);
                let turret = if base.fired { base.turret } else { hull };
                self.draw_unit_posed(
                    &painter,
                    pos,
                    u,
                    false,
                    s,
                    255,
                    Some(fx::Pose { hull, turret, fired: base.fired }),
                );
            }
        }
        // ---- 战斗特效：曳光/弹道/爆炸/烟团（画在棋子之上） ----
        for e in &self.effects {
            e.draw(&painter, s, self.time);
        }
        // ---- 直射测距器：起点标记 + 到终点/悬停格的线段与距离 ----
        if self.ranger_mode {
            if let Some(f) = self.ranger_first {
                let (fc, fr) = hex::offset_from_axial(f);
                let cf = self.hex_center(origin, fc, fr, hs);
                painter.add(egui::Shape::circle_stroke(
                    cf,
                    hs * 0.85,
                    egui::Stroke::new(2.2, egui::Color32::from_rgb(120, 220, 255)),
                ));
                painter.text(
                    egui::pos2(cf.x, cf.y - hs * 1.05),
                    egui::Align2::CENTER_BOTTOM,
                    "起点",
                    egui::FontId::proportional(11.0 * s),
                    egui::Color32::from_rgb(140, 230, 255),
                );
                // 终点：最近点击的格，或悬停预览
                let end = self.ranger_last.or(self.log_hover);
                if let Some(t) = end {
                    let (tc, tr) = hex::offset_from_axial(t);
                    let ct = self.hex_center(origin, tc, tr, hs);
                    let (col_c, _) = if self.log_hover == Some(t) {
                        (egui::Color32::from_rgb(120, 220, 255), egui::Color32::from_rgb(160, 235, 255))
                    } else {
                        (egui::Color32::from_rgb(90, 170, 210), egui::Color32::from_rgb(120, 200, 235))
                    };
                    painter.add(egui::Shape::line_segment(
                        [cf, ct],
                        egui::Stroke::new(1.6, col_c),
                    ));
                    let mid = egui::pos2((cf.x + ct.x) / 2.0, (cf.y + ct.y) / 2.0);
                    let d = Hex::distance(f, t);
                    painter.text(
                        mid,
                        egui::Align2::CENTER_CENTER,
                        format!("{}格", d),
                        egui::FontId::proportional(12.0 * s),
                        egui::Color32::from_rgb(200, 235, 255),
                    );
                    // 悬停实时显示直射状态
                    if self.log_hover == Some(t) {
                        let los = self.game.map.has_los_ex(f, t, &self.game.smoke);
                        painter.text(
                            egui::pos2(mid.x, mid.y + 13.0 * s),
                            egui::Align2::CENTER_CENTER,
                            if los { "直射✓" } else { "阻挡✗" },
                            egui::FontId::proportional(11.0 * s),
                            if los {
                                egui::Color32::from_rgb(150, 230, 160)
                            } else {
                                egui::Color32::from_rgb(255, 150, 130)
                            },
                        );
                    }
                }
            }
        }
        // ---- AI 回合状态标记：思考中 / 已思考 xx 秒（玩家回合开始时消失）----
        if let Some(text) = self.ai_status_marker() {
            let galley = painter.layout_no_wrap(
                text,
                egui::FontId::proportional(15.0),
                egui::Color32::from_rgb(232, 245, 255),
            );
            let pad = egui::vec2(14.0, 7.0);
            let size = galley.size() + pad * 2.0;
            let center = egui::pos2(rect.center().x, rect.top() + 24.0);
            let bg = egui::Rect::from_center_size(center, size);
            painter.rect_filled(bg, 8.0, egui::Color32::from_rgba_unmultiplied(18, 22, 30, 220));
            painter.rect_stroke(
                bg,
                8.0,
                egui::Stroke::new(1.4, egui::Color32::from_rgb(120, 200, 255)),
                egui::StrokeKind::Inside,
            );
            painter.galley(bg.min + pad, galley, egui::Color32::WHITE);
        }
    }

    /// 部署阶段：在悬停格绘制待放置单位的半透明预览。
    fn draw_deploy_preview(
        &self,
        painter: &egui::Painter,
        c: egui::Pos2,
        kind: UnitKind,
        s: f32,
    ) {
        // 用俯视棋子绘制半透明预览
        let dummy = Unit::new(kind, Team::Player, hex::axial_from_offset(0, 0));
        self.draw_unit_alpha(painter, c, &dummy, false, s, 150);
        let px = pieces::Px { a: 200, ..pieces::Px::new(painter, s) };
        px.text(c, egui::Align2::CENTER_CENTER, "+", 14.0, egui::Color32::from_rgb(235, 250, 255));
    }

    /// 绘制敌方"最后已知位置"鬼影：淡色轮廓 + "?"，
    /// 提示该处曾侦察到敌人但当前不可见。
    fn draw_ghost(&self, painter: &egui::Painter, c: egui::Pos2, kind: UnitKind, s: f32) {
        let fill = egui::Color32::from_rgba_unmultiplied(40, 44, 46, 130);
        let stroke = egui::Color32::from_rgba_unmultiplied(150, 150, 150, 90);
        painter.circle_stroke(c, 13.0 * s, egui::Stroke::new(1.2 * s, stroke));
        painter.circle_filled(c, 13.0 * s, fill);
        painter.text(
            c,
            egui::Align2::CENTER_CENTER,
            "?",
            egui::FontId::proportional(16.0 * s),
            egui::Color32::from_rgba_unmultiplied(210, 210, 210, 150),
        );
        let _ = kind;
    }

    /// 绘制迷雾开火警报标记：红色半透明幽灵 + 感叹号，
    /// 表示"曾有敌方单位在此从迷雾中开火"（位置被标记，需查探确认）。
    fn draw_ghost_alarm(&self, painter: &egui::Painter, c: egui::Pos2, s: f32) {
        let pw = 34.0 * s;
        let ph = 24.0 * s;
        let rect = egui::Rect::from_center_size(c, egui::vec2(pw, ph));
        painter.add(egui::Shape::convex_polygon(
            vec![
                rect.min,
                egui::pos2(rect.max.x, rect.min.y),
                rect.max,
                egui::pos2(rect.min.x, rect.max.y),
            ],
            egui::Color32::from_rgba_unmultiplied(72, 26, 22, 160),
            egui::Stroke::new(1.4 * s, egui::Color32::from_rgba_unmultiplied(235, 96, 70, 210)),
        ));
        painter.text(
            c,
            egui::Align2::CENTER_CENTER,
            "!",
            egui::FontId::proportional(17.0 * s),
            egui::Color32::from_rgba_unmultiplied(255, 150, 130, 230),
        );
    }

    /// 绘制单位：北约风格矩形兵牌 + 下方血条（绿=我方，红=敌方，按比例减少）。
    /// 绘制单位：俯视风格棋子（士兵班组/装甲车辆/直升机/无人机）+ 下方血条。
    fn draw_unit(&self, painter: &egui::Painter, c: egui::Pos2, u: &hex_wargame::unit::Unit, selected: bool, s: f32) {
        self.draw_unit_alpha(painter, c, u, selected, s, 255);
    }

    /// `alpha`：整体透明度（部署预览半透明用）。
    fn draw_unit_alpha(
        &self,
        painter: &egui::Painter,
        c: egui::Pos2,
        u: &hex_wargame::unit::Unit,
        selected: bool,
        s: f32,
        alpha: u8,
    ) {
        self.draw_unit_posed(painter, c, u, selected, s, alpha, None);
    }

    /// 与 draw_unit_alpha 同义，但可覆盖朝向姿态（移动动画期间按路径段实时定向）。
    fn draw_unit_posed(
        &self,
        painter: &egui::Painter,
        c: egui::Pos2,
        u: &hex_wargame::unit::Unit,
        selected: bool,
        s: f32,
        alpha: u8,
        pose_override: Option<fx::Pose>,
    ) {
        let dimmed = self.game.test_mode
            && u.team == Team::Ai
            && !self.visible_enemies.contains(&u.pos);
        let mut px = pieces::Px::new(painter, s);
        px.a = alpha;
        let pose = pose_override.unwrap_or_else(|| self.pose_of(u));
        // 投影：让棋子浮于地图之上
        painter.circle_filled(
            egui::pos2(c.x, c.y + 2.0 * s),
            13.0 * s,
            egui::Color32::from_black_alpha(70),
        );
        // 步兵开火视觉（转向/上肩动画）
        let fire = self.fire_visual_of(u);
        pieces::draw_unit_body(&px, c, u, pose.hull, pose.turret, fire, self.time, dimmed);
        // 选中：白色双圈柔光
        if selected {
            painter.circle_stroke(
                c,
                17.5 * s,
                egui::Stroke::new(1.2 * s, egui::Color32::from_white_alpha(70)),
            );
            painter.circle_stroke(c, 15.8 * s, egui::Stroke::new(1.8 * s, egui::Color32::WHITE));
        }
        // 字母代号（左上角小字；指挥部用星徽即可）
        if alpha == 255 && u.kind != UnitKind::Headquarters {
            px.text(
                egui::pos2(c.x - 13.5 * s, c.y - 13.5 * s),
                egui::Align2::CENTER_CENTER,
                &u.label.to_string(),
                9.5,
                egui::Color32::from_rgb(246, 246, 240),
            );
        }
        // 压制标记：红色闪电角标 + 层数（左上外侧）
        if u.suppressed && alpha == 255 {
            let c2 = egui::pos2(c.x - 14.5 * s, c.y - 13.5 * s);
            let col = egui::Color32::from_rgb(240, 70, 60);
            painter.add(egui::Shape::convex_polygon(
                vec![
                    egui::pos2(c2.x, c2.y - 5.5 * s),
                    egui::pos2(c2.x + 4.5 * s, c2.y + 1.5 * s),
                    egui::pos2(c2.x + 0.5 * s, c2.y + 1.5 * s),
                    egui::pos2(c2.x - 1.5 * s, c2.y + 5.5 * s),
                    egui::pos2(c2.x - 3.5 * s, c2.y - 1.0 * s),
                    egui::pos2(c2.x + 0.5 * s, c2.y - 1.0 * s),
                ],
                col,
                egui::Stroke::NONE,
            ));
            painter.text(
                egui::pos2(c2.x + 7.0 * s, c2.y + 1.0 * s),
                egui::Align2::LEFT_CENTER,
                u.suppression_stacks.max(1).to_string(),
                egui::FontId::proportional(10.0 * s),
                egui::Color32::from_rgb(255, 220, 210),
            );
        }
        // 主战坦克 / 装甲骑兵战车：主动防御剩余次数角标（右上盾牌 + 次数）
        if matches!(u.kind, UnitKind::HeavyTank | UnitKind::CavalryIfv) && alpha == 255 {
            let shield_c = egui::pos2(c.x + 13.0 * s, c.y - 13.5 * s);
            let shield = egui::Rect::from_center_size(shield_c, egui::vec2(9.0 * s, 7.0 * s));
            let shield_col = if u.ad_uses > 0 {
                egui::Color32::from_rgb(90, 200, 255)
            } else {
                egui::Color32::from_rgb(150, 150, 140)
            };
            painter.rect_filled(shield, 1.5 * s, shield_col);
            painter.text(
                shield_c,
                egui::Align2::CENTER_CENTER,
                u.ad_uses.to_string(),
                egui::FontId::proportional(8.0 * s),
                egui::Color32::BLACK,
            );
        }
        // 搭载步兵角标（右侧一列小圆点）
        if alpha == 255 {
            for (i, p) in u.passengers.iter().enumerate() {
                let bx = c.x + 17.0 * s;
                let by = c.y - 4.5 * s + i as f32 * 8.0 * s;
                painter.circle_filled(egui::pos2(bx, by), 2.8 * s, egui::Color32::from_rgb(255, 220, 130));
                painter.circle_stroke(
                    egui::pos2(bx, by),
                    2.8 * s,
                    egui::Stroke::new(0.8, egui::Color32::from_rgb(120, 90, 40)),
                );
                painter.text(
                    egui::pos2(bx + 4.0 * s, by),
                    egui::Align2::LEFT_CENTER,
                    p.label.to_string(),
                    egui::FontId::proportional(8.0 * s),
                    egui::Color32::WHITE,
                );
            }
        }
        // 血条（棋子下方）：绿=我方，红=敌方，随伤害按比例减少
        let bar_w = 30.0 * s;
        let bar_h = 3.0 * s;
        let bar_cy = c.y + 19.5 * s;
        let bar_rect = egui::Rect::from_center_size(
            egui::pos2(c.x, bar_cy),
            egui::vec2(bar_w, bar_h),
        );
        painter.rect_filled(bar_rect, 1.2 * s, egui::Color32::from_rgb(16, 20, 18));
        let frac = (u.hp as f32 / u.kind.max_hp() as f32).clamp(0.0, 1.0);
        let bar_color = if u.team == self.view_team() {
            egui::Color32::from_rgb(74, 205, 112)
        } else if self.game.test_mode && !self.visible_enemies.contains(&u.pos) {
            egui::Color32::from_rgb(110, 46, 42)
        } else {
            egui::Color32::from_rgb(240, 92, 76)
        };
        if frac > 0.0 {
            let w = (bar_w * frac).max(bar_h * 0.6);
            let fill_rect = egui::Rect::from_min_size(bar_rect.min, egui::vec2(w, bar_h));
            painter.rect_filled(fill_rect, 1.2 * s, bar_color);
        }
        painter.rect_stroke(
            bar_rect,
            1.2 * s,
            egui::Stroke::new(0.8, egui::Color32::from_black_alpha(120)),
            egui::StrokeKind::Middle,
        );
        // 弹药条（血条下方细条）：琥珀色，随消耗变短
        if u.kind.max_ammo() > 0 {
            let ab_w = bar_w * 0.82;
            let ab_h = 1.6 * s;
            let ab_cy = bar_cy + bar_h * 0.5 + ab_h * 0.5 + 1.0 * s;
            let ab_rect =
                egui::Rect::from_center_size(egui::pos2(c.x, ab_cy), egui::vec2(ab_w, ab_h));
            painter.rect_filled(ab_rect, 0.8 * s, egui::Color32::from_rgb(16, 20, 18));
            let af = (u.ammo_shown() as f32
                / if u.kind == UnitKind::AaMgv && u.missile_mode { 2 } else { u.kind.max_ammo() } as f32)
                .clamp(0.0, 1.0);
            if af > 0.0 {
                let w = (ab_w * af).max(ab_h * 0.8);
                let ammo_color = if af > 0.4 {
                    egui::Color32::from_rgb(235, 200, 100) // 琥珀
                } else if af > 0.0 {
                    egui::Color32::from_rgb(240, 150, 70) // 橙=低弹药
                } else {
                    egui::Color32::from_rgb(220, 80, 70) // 红=耗尽
                };
                let fill_rect = egui::Rect::from_min_size(ab_rect.min, egui::vec2(w, ab_h));
                painter.rect_filled(fill_rect, 0.8 * s, ammo_color);
            }
            // 剩余行动点（弹药条下方黄色小点）
            if alpha == 255 {
                let n = u.actions_left;
                let dots_cy = ab_cy + ab_h * 0.5 + 3.0 * s;
                for i in 0..n {
                    painter.circle_filled(
                        egui::pos2(
                            c.x - (n as f32 - 1.0) * 3.5 * s + i as f32 * 7.0 * s,
                            dots_cy,
                        ),
                        1.7 * s,
                        egui::Color32::from_rgb(255, 226, 130),
                    );
                }
            }
        }
    }

    fn highlight_sets(&self) -> Highlights {
        let empty = Highlights {
            reachable: Vec::new(),
            attackable: Vec::new(),
            blocked: Vec::new(),
            howitzer_targets: Vec::new(),
            disembark_targets: Vec::new(),
            board_targets: Vec::new(),
        };
        if self.selected.is_none() {
            return empty;
        }
        let Some(u) = self.selected_unit() else {
            return empty;
        };
        let me = if self.multiplayer {
            match self.gui_control_team() {
                Some(t) => t,
                None => return empty,
            }
        } else {
            Team::Player
        };
        // 选中敌方单位：只查看信息，不显示行动高亮
        if u.team != me {
            return empty;
        }
        // 待放下状态：标出合法落点（紧邻载具、非岩石、无单位）
        let mut disembark_targets = Vec::new();
        if self.pending_disembark.is_some() && !u.kind.is_air() && u.kind.capacity() > 0 {
            for n in u.pos.neighbors() {
                if self.game.map.contains(n)
                    && !self.game.map.obstacles.contains(&n)
                    && !self.game.units.contains_key(&n)
                {
                    disembark_targets.push(n);
                }
            }
        }
        // 装载模式：标出可点击上车的紧邻己方单位（青绿高亮）
        let mut board_targets = Vec::new();
        if self.load_mode && !u.kind.is_air() && u.kind.capacity() > 0 && u.has_space() {
            for n in u.pos.neighbors() {
                if let Some(g) = self.game.units.get(&n) {
                    if g.team == me && u.can_carry(g.kind) {
                        board_targets.push(n);
                    }
                }
            }
        }
        let mut reach = if self.simul_mode || self.load_mode {
            Vec::new() // 同时攻击/装载模式下不显示移动高亮
        } else if u.actions_left > 0
            && !((u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
                && self.howitzer_fire_mode)
        {
            self.game
                .map
                .reachable_hexes_ex(&self.game.units, &self.game.air_units, u.pos, u.kind.movement(), Some(u))
        } else {
            Vec::new()
        };
        // 空中单位不能停到另一个空中单位所在格（同层不重叠），
        // 避免绿色高亮与实际移动规则不一致。
        if u.kind.is_air() {
            reach.retain(|h| !self.game.air_units.contains_key(h));
        }
        // 同时攻击模式下，榴弹炮/迫击炮显示可选的炮击目标（黄色）
        if self.simul_mode
            && (u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
        {
            let mut targets = Vec::new();
            for row in 0..self.game.map.rows {
                for col in 0..self.game.map.cols {
                    let hx = hex::axial_from_offset(col, row);
                    if hx == u.pos {
                        continue;
                    }
                    if Hex::distance(u.pos, hx) <= u.kind.range() {
                        targets.push(hx);
                    }
                }
            }
            return Highlights {
                reachable: Vec::new(),
                attackable: Vec::new(),
                blocked: Vec::new(),
                howitzer_targets: targets,
                disembark_targets,
                board_targets,
            };
        }
        // 榴弹炮/自行迫击炮：射击模式下显示黄色炮击目标
        if (u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar) && self.howitzer_fire_mode {
            let mut targets = Vec::new();
            for row in 0..self.game.map.rows {
                for col in 0..self.game.map.cols {
                    let hx = hex::axial_from_offset(col, row);
                    if hx == u.pos {
                        continue;
                    }
                    // 间瞄火力：射程内任意格子皆可炮击（无需直线视线）
                    if Hex::distance(u.pos, hx) <= u.kind.range() {
                        targets.push(hx);
                    }
                }
            }
            return Highlights {
                reachable: reach,
                attackable: Vec::new(),
                blocked: Vec::new(),
                howitzer_targets: targets,
                disembark_targets,
                board_targets,
            };
        }
        let can_act = u.actions_left >= u.kind.attack_cost();
        let mut attackable = Vec::new();
        let mut blocked = Vec::new();
        for e in self.game.enemies_of(me) {
            // 视野规则：只考虑我方侦察到的敌人（共享视野 + 隐蔽判定）。
            // 多人热座使用完整视野，因此不再按迷雾过滤。
            if !self.multiplayer
                && !self.visible_enemies.contains(&e.pos)
                && !self.game.test_mode
            {
                continue;
            }
            if Hex::distance(u.pos, e.pos) > u.eff_range() || !can_act {
                continue;
            }
            let air_to_air = u.kind.is_air() && e.kind.is_air();
            let los_ok = u.kind == UnitKind::Howitzer
                || u.kind == UnitKind::Mortar
                || air_to_air
                || self
                    .game
                    .map
                    .has_los_ex(u.pos, e.pos, &self.game.smoke);
            if !los_ok {
                blocked.push(e.pos);
                continue;
            }
            if u.can_target_unit(e.kind) && u.eff_attack() >= e.kind.armor() {
                attackable.push(e.pos);
            } else {
                blocked.push(e.pos);
            }
        }
        Highlights {
            disembark_targets,
            reachable: reach,
            attackable,
            blocked,
            howitzer_targets: Vec::new(),
            board_targets,
        }
    }

    // ---------- 面板 ----------

    fn top_panel(&mut self, ui: &mut egui::Ui) {
        egui::Panel::top("top").show(ui, |ui| {
            ui.horizontal(|ui| {
                ui.heading(
                    egui::RichText::new(if self.multiplayer {
                        format!(
                            "六边形战争 · 多人热座 · 第 {} 回合",
                            self.game.turn.max(1)
                        )
                    } else {
                        format!("六边形战争 · 第 {} 回合", self.game.turn)
                    })
                    .color(theme::ACCENT),
                );
                ui.separator();
                if self.game_over.is_some() {
                    ui.label(egui::RichText::new("对局结束").strong().color(egui::Color32::YELLOW));
                } else if self.game.deploying {
                    ui.label(
                        egui::RichText::new("● 部署阶段（第 0 回合）")
                            .color(egui::Color32::from_rgb(120, 200, 255)),
                    );
                } else {
                    if self.multiplayer {
                        let active = self.game.phase;
                        let text = match self.gui_control_team() {
                            Some(me) if me == active => format!(
                                "● {}方行动阶段（本地可操作）",
                                mp::team_label(active)
                            ),
                            Some(_) => format!(
                                "● {}方行动阶段（本地等待）",
                                mp::team_label(active)
                            ),
                            None => format!(
                                "● {}方行动阶段（观战）",
                                mp::team_label(active)
                            ),
                        };
                        ui.label(
                            egui::RichText::new(text)
                                .color(egui::Color32::from_rgb(140, 210, 150)),
                        );
                    } else {
                        ui.label(
                            egui::RichText::new("● 你的行动阶段")
                                .color(egui::Color32::from_rgb(140, 210, 150)),
                        );
                    }
                    if self.game.test_mode {
                        ui.label(
                            egui::RichText::new("🧪 试验模式")
                                .color(egui::Color32::from_rgb(220, 180, 255))
                                .strong(),
                        );
                    }
                    // 榴弹炮开火模式指示
                    if self.howitzer_fire_mode {
                        ui.label(
                            egui::RichText::new("炮击模式")
                                .color(egui::Color32::from_rgb(255, 200, 90))
                                .strong(),
                        );
                    }
                    // 烟雾弹待发射指示
                    if self.smoke_shot_pending {
                        ui.label(
                            egui::RichText::new("烟雾弹待发射（点击射程内格子 / Esc 取消）")
                                .color(egui::Color32::from_rgb(160, 200, 255)),
                        );
                    }
                    // 待放下状态指示
                    if self.pending_disembark.is_some() {
                        ui.label(
                            egui::RichText::new("等待选择放下地点 (Esc 取消)")
                                .color(egui::Color32::from_rgb(120, 200, 255)),
                        );
                    }
                    // 同时攻击模式指示
                    if self.simul_mode {
                        ui.label(
                            egui::RichText::new(format!(
                                "⚔ 同时攻击模式（已选 {} 条命令，按 C 结算）",
                                self.simul_orders.len()
                            ))
                            .color(egui::Color32::from_rgb(255, 200, 90))
                            .strong(),
                        );
                    }
                    // 未行动单位数
                    let count_team = if self.multiplayer {
                        self.game.phase
                    } else {
                        Team::Player
                    };
                    let remaining = self
                        .game
                        .units_of(count_team)
                        .iter()
                        .filter(|u| u.actions_left > 0)
                        .count();
                    let total = self.game.units_of(count_team).len();
                    ui.label(
                        egui::RichText::new(format!("未行动 {}/{}", remaining, total)).weak(),
                    );
                }
                // 最近错误（3 秒内显示在顶栏，方便看见）
                if let Some((t, msg)) = &self.last_error {
                    let now = ui.input(|i| i.time);
                    if now - *t < 3.0 {
                        ui.label(
                            egui::RichText::new(msg.as_str())
                                .color(egui::Color32::from_rgb(255, 160, 120)),
                        );
                    } else {
                        self.last_error = None;
                    }
                }
                if let Some(h) = self.log_hover {
                    ui.label(egui::RichText::new(format!("光标: {}", hex::hex_label(h))).weak());
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let ai_label = format!("🤖 AI：{}", self.game.ai_version.name());
                    if ui
                        .button(ai_label)
                        .on_hover_text("点击切换旧版/新版 AI（新版：期望伤害 + 统一效用 + 威胁图）")
                        .clicked()
                    {
                        self.game.ai_version = self.game.ai_version.toggled();
                        self.log(format!("🤖 已切换为{} AI", self.game.ai_version.name()));
                    }
                    let diff_label = format!("难度：{}", self.game.ai_difficulty.name());
                    if ui
                        .button(diff_label)
                        .on_hover_text("新版 AI 难度：新兵/常规/老兵/精英（点击循环）")
                        .clicked()
                    {
                        let all = AiDifficulty::all();
                        let idx = all
                            .iter()
                            .position(|d| *d == self.game.ai_difficulty)
                            .unwrap_or(1);
                        self.game.ai_difficulty = all[(idx + 1) % all.len()];
                        self.log(format!("🎯 AI 难度：{}", self.game.ai_difficulty.name()));
                    }
                    if ui.button("帮助 (F1)").clicked() {
                        self.show_help = true;
                    }
                    if ui
                        .button(if self.panel_expanded { "收起面板 ◀" } else { "展开面板 ▶" })
                        .clicked()
                    {
                        self.panel_expanded = !self.panel_expanded;
                    }
                    if ui.button("导出日志").clicked() {
                        match self.export_log() {
                            Ok(path) => self.log(format!("✅ 对局日志已导出: {}", path)),
                            Err(e) => self.log(format!("⚠ 导出日志失败: {}", e)),
                        }
                    }
                    if self.game_over.is_none() {
                        // 重新开始：二次确认防误触
                        let confirm = self
                            .confirm_action
                            .map(|(_, k)| k == ConfirmAction::Restart)
                            .unwrap_or(false);
                        let mut do_restart = false;
                        if ui
                            .button(if confirm {
                                "确认重新开始？"
                            } else {
                                "重新开始"
                            })
                            .clicked()
                        {
                            if confirm {
                                do_restart = true;
                            } else {
                                self.confirm_action =
                                    Some((ui.input(|i| i.time), ConfirmAction::Restart));
                            }
                        }
                        if do_restart {
                            self.restart();
                        }
                        // 结束回合：有未行动单位时二次确认
                        let end_team = if self.multiplayer {
                            self.game.phase
                        } else {
                            Team::Player
                        };
                        let can_end_here = self
                            .gui_control_team()
                            .map(|me| me == end_team)
                            .unwrap_or(false);
                        let remaining = self
                            .game
                            .units_of(end_team)
                            .iter()
                            .filter(|u| u.actions_left > 0)
                            .count();
                        let confirm = self
                            .confirm_action
                            .map(|(_, k)| k == ConfirmAction::EndTurn)
                            .unwrap_or(false);
                        let mut do_end = false;
                        let btn_txt = if confirm {
                            if remaining > 0 {
                                format!("确认结束？({}未行动)", remaining)
                            } else {
                                "确认结束？".to_string()
                            }
                        } else {
                            "结束回合".to_string()
                        };
                        if ui
                            .add_enabled(can_end_here, egui::Button::new(btn_txt))
                            .clicked()
                        {
                            if remaining > 0 && !confirm {
                                self.confirm_action =
                                    Some((ui.input(|i| i.time), ConfirmAction::EndTurn));
                            } else {
                                do_end = true;
                            }
                        }
                        if do_end {
                            if self.multiplayer {
                                self.end_turn_for(end_team);
                            } else {
                                self.end_player_turn();
                            }
                        }
                    }
                });
            });
            // 二次确认超时自动复位
            if let Some((t, _)) = self.confirm_action {
                if ui.input(|i| i.time) - t > 2.0 {
                    self.confirm_action = None;
                }
            }
        });
    }

    /// 部署阶段面板：选择招募单位、查看已部署单位、开始战斗。
    fn deploy_panel(&mut self, ui: &mut egui::Ui) {
        let pts = self
            .game
            .recruit_points
            .get(&Team::Player)
            .copied()
            .unwrap_or(0);
        // 关卡信息与切换
        let level_name = if self.level == Level::Custom {
            self.game
                .custom
                .as_ref()
                .map(|c| c.name.clone())
                .unwrap_or_else(|| self.level.name().to_string())
        } else {
            self.level.name().to_string()
        };
        ui.horizontal(|ui| {
            ui.heading(
                egui::RichText::new(format!("{} · 剩余 {} 点", level_name, pts))
                    .color(theme::ACCENT),
            );
            if ui
                .button(if self.level == Level::OpenField {
                    "切换：村庄防守战"
                } else {
                    "切换：开阔地遭遇战"
                })
                .clicked()
            {
                self.level = match self.level {
                    Level::OpenField => Level::VillageDefense,
                    Level::VillageDefense | Level::Custom => Level::OpenField,
                };
                self.custom_map = None;
                self.log(format!(
                    "已切换到关卡：{}（重新部署）",
                    self.level.name()
                ));
                let ai_version = self.game.ai_version;
                let ai_difficulty = self.game.ai_difficulty;
                self.game = GameState::new_deploy_level(rand::random(), self.level);
                self.game.ai_version = ai_version;
                self.game.ai_difficulty = ai_difficulty;
                self.apply_sustain_settings();
                self.pending_recruit = None;
                self.log("—— 第 0 回合 · 部署阶段 ——".into());
            }
            // 加载编辑器制作的自定义地图（maps/ 目录）
            let maps = CustomMap::scan_all();
            if !maps.is_empty() {
                ui.separator();
                let sel = if self.level == Level::Custom {
                    self.game
                        .custom
                        .as_ref()
                        .map(|c| c.name.clone())
                        .unwrap_or_else(|| "自定义地图".into())
                } else {
                    "自定义地图…".into()
                };
                egui::ComboBox::from_id_salt("custom_map")
                    .selected_text(sel)
                    .show_ui(ui, |ui| {
                        for (name, path) in &maps {
                            if ui.selectable_label(false, name).clicked() {
                                let p = path.clone();
                                let nm = name.clone();
                                match CustomMap::load(&p) {
                                    Ok(cm) => {
                                        self.level = Level::Custom;
                                        self.custom_map = Some(cm.clone());
                                        let ai_version = self.game.ai_version;
                                        let ai_difficulty = self.game.ai_difficulty;
                                        self.game =
                                            GameState::new_custom_deploy(rand::random(), cm);
                                        self.game.ai_version = ai_version;
                                        self.game.ai_difficulty = ai_difficulty;
                                        self.apply_sustain_settings();
                                        self.log(format!(
                                            "已加载自定义地图：{}（重新部署）",
                                            nm
                                        ));
                                        self.pending_recruit = None;
                                        self.log("—— 第 0 回合 · 部署阶段 ——".into());
                                    }
                                    Err(e) => self.log(format!("⚠ 加载地图失败: {}", e)),
                                }
                            }
                        }
                    });
            }
        });
        // AI 版本选择（开局即可选择新版/旧版；对局中也可在顶栏切换）
        ui.separator();
        ui.label(egui::RichText::new("🤖 AI 智能版本").strong());
        ui.horizontal(|ui| {
            if ui
                .selectable_label(self.game.ai_version == AiVersion::Legacy, "旧版（经典三策略）")
                .clicked()
            {
                self.game.ai_version = AiVersion::Legacy;
            }
            if ui
                .selectable_label(self.game.ai_version == AiVersion::V2, "新版（期望伤害+威胁图）")
                .clicked()
            {
                self.game.ai_version = AiVersion::V2;
            }
        });
        ui.horizontal(|ui| {
            ui.label("难度:");
            for d in AiDifficulty::all() {
                if ui
                    .selectable_label(self.game.ai_difficulty == d, d.name())
                    .clicked()
                {
                    self.game.ai_difficulty = d;
                }
            }
        });
        ui.label(
            egui::RichText::new("新版：期望伤害/统一效用/量化威胁图/移动后射击；可随时在顶栏切换。难度仅对旧版无影响。")
                .weak()
                .size(11.0),
        );
        // 可持续部署模式设置
        ui.separator();
        ui.label(egui::RichText::new("♾ 可持续部署").strong());
        ui.checkbox(&mut self.sustain_mode, "开启：每回合双方获得部署点数，可在本方大本营追加部署");
        ui.horizontal(|ui| {
            ui.label("玩家每回合点数:");
            ui.add(egui::DragValue::new(&mut self.sustain_pp).range(0..=200));
            ui.label("AI:");
            ui.add(egui::DragValue::new(&mut self.sustain_ap).range(0..=200));
        });
        if ui
            .add(egui::Button::new("应用设置（保留当前部署）").min_size(egui::vec2(ui.available_width(), 0.0)))
            .clicked()
        {
            self.apply_sustain_settings();
            self.log(if self.sustain_mode {
                format!(
                    "已开启可持续部署：每回合 +{}（玩家）/ +{}（AI）点数",
                    self.sustain_pp, self.sustain_ap
                )
            } else {
                "已关闭可持续部署（规则与普通对局完全一致）".into()
            });
        }
        if self.sustain_mode {
            ui.label(
                egui::RichText::new("开始后每回合在部署盈余上累计；对局中按 D 进入追加部署；
大本营中距敌军 ≤5 格的格子被占领不可部署；开局双方大本营内随机设指挥部（HP2），
摧毁敌方指挥部即获胜。")
                    .weak()
                    .size(11.0),
            );
        }
        // 试验模式：只允许在开局部署阶段通过此按钮进入。
        ui.separator();
        ui.label(egui::RichText::new("🧪 试验模式").strong());
        ui.label(
            egui::RichText::new("点击后立即进入试验模式：清空双方大本营，保留已部署棋子，关闭费用/追加部署。")
                .weak()
                .size(11.0),
        );
        if ui
            .add(
                egui::Button::new("✅ 确认进入试验模式（立即开始）")
                    .min_size(egui::vec2(ui.available_width(), 0.0)),
            )
            .clicked()
        {
            self.enter_test_mode();
            self.log("🧪 已进入试验模式：大本营已清空，可自由放置双方棋子并开始行动。".into());
            return;
        }
        ui.separator();
        let ai_pts = self
            .game
            .recruit_points
            .get(&Team::Ai)
            .copied()
            .unwrap_or(0);
        if ai_pts != pts {
            ui.label(
                egui::RichText::new(format!("AI 点数：{}", ai_pts)).weak(),
            );
        }
        ui.label(
            egui::RichText::new("点击单位招募（可重复），再点击左侧青色区域放置；
点击已放置单位可撤销返还点数。")
                .weak()
                .size(12.0),
        );
        ui.separator();

        // 已部署单位（点击撤销）
        let deployed: Vec<(char, String, String, i32, Hex)> = self
            .game
            .units_of(Team::Player)
            .iter()
            .map(|u| {
                (
                    u.label,
                    u.kind.name().to_string(),
                    hex::hex_label(u.pos),
                    u.kind.recruit_cost(),
                    u.pos,
                )
            })
            .collect();
        if deployed.is_empty() {
            ui.label(egui::RichText::new("尚未部署任何单位").weak());
        } else {
            ui.label(
                egui::RichText::new(format!("已部署 {} 个：", deployed.len()))
                    .strong()
                    .color(theme::ALLY_TEXT),
            );
            for (label, name, pos_txt, cost, pos) in deployed {
                let txt = format!("  {} {} @{}（{}点）", label, name, pos_txt, cost);
                if ui
                    .add(egui::Button::new(txt).min_size(egui::vec2(ui.available_width(), 0.0)))
                    .clicked()
                {
                    match self.game.undeploy_unit(Team::Player, pos) {
                        Ok(c) => self.log(format!("撤销部署 {} {}（返还 {} 点）", label, name, c)),
                        Err(e) => self.log(format!("⚠ {}", e)),
                    }
                }
            }
        }
        ui.separator();

        // 招募单位列表
        ui.label(egui::RichText::new("招募单位（可重复）：").strong());
        let all = [
            UnitKind::Rifleman,
            UnitKind::Scout,
            UnitKind::Atgm,
            UnitKind::Javelin,
            UnitKind::SpecialForces,
            UnitKind::EliteInfantry,
            UnitKind::Tank,
            UnitKind::HeavyTank,
            UnitKind::Ifv,
            UnitKind::CavalryIfv,
            UnitKind::HumveeHmg,
            UnitKind::HumveeTow,
            UnitKind::HumveeJavelin,
            UnitKind::Truck,
            UnitKind::Howitzer,
            UnitKind::Mortar,
            UnitKind::AttackHeli,
            UnitKind::TransportHeli,
            UnitKind::HeavyTransportHeli,
            UnitKind::Drone,
            UnitKind::AaInfantry,
            UnitKind::HmgGunner,
            UnitKind::AaMgv,
            UnitKind::AaLauncher,
            UnitKind::Supply,
        ];
        for (_, kind) in all.iter().enumerate() {
            let cost = kind.recruit_cost();
            let afford = cost <= pts;
            let selected = self.pending_recruit == Some(*kind);
            let txt = format!(
                "{} · {} 点",
                kind.name(),
                cost
            );
            let btn = ui.add_enabled(
                afford,
                egui::Button::new(if selected {
                    format!("▶ {}（放置中）", txt)
                } else {
                    format!("  {}", txt)
                })
                .min_size(egui::vec2(ui.available_width(), 0.0)),
            );
            if btn.clicked() {
                if std::env::var_os("HEX_WARGAME_DEBUG").is_some() {
                    eprintln!("[gui] deploy_pick kind={:?}", kind);
                }
                if self.pending_recruit != Some(*kind) {
                    self.pending_cargo.clear();
                }
                self.pending_recruit = Some(*kind);
            }
            btn.on_hover_text(if afford {
                format!(
                    "射程{} 攻击{} 命中{}% 行动力{} 视野{} 弹药{}",
                    kind.range(),
                    kind.attack(),
                    kind.hit_rate(),
                    kind.movement(),
                    kind.vision(),
                    kind.max_ammo()
                )
            } else {
                "招募点数不足".into()
            });
        }
        self.cargo_panel(ui, pts);
        ui.separator();

        // 随机部署（AI 式快速开局）
        if ui
            .add(egui::Button::new("🎲 随机部署（AI 式）").min_size(egui::vec2(ui.available_width(), 0.0)))
            .clicked()
        {
            for msg in ai_router::ai_deploy(&mut self.game, Team::Player) {
                self.log(msg);
            }
            self.pending_recruit = None;
        }
        // 开始战斗
        let have_any = !self.game.units_of(Team::Player).is_empty();
        let start_btn = ui.add_enabled(
            have_any,
            egui::Button::new("⚔ 开始战斗（AI 同步部署）")
                .min_size(egui::vec2(ui.available_width(), 0.0)),
        );
        if start_btn.clicked() {
            match self.game.finish_deploy() {
                Ok(ai_log) => {
                    self.log("—— 部署完成 · 战斗开始 ——".into());
                    self.log("【AI 部署】".into());
                    for m in ai_log {
                        self.log(m);
                    }
                    self.log(format!(
                        "—— 第 {} 回合 · 你的行动 ——",
                        self.game.turn + 1
                    ));
                    self.pending_recruit = None;
                }
                Err(e) => self.log(format!("⚠ {}", e)),
            }
        }
        start_btn.on_hover_text("完成部署，AI 随机部署后进入第 1 回合");
    }

    fn side_panel(&mut self, ui: &mut egui::Ui) {
        if !self.panel_expanded {
            // 折叠态：窄条，仅"展开"按钮（地图获得完整空间）
            egui::Panel::right("side")
                .resizable(false)
                .exact_size(46.0)
                .show(ui, |ui| {
                    ui.vertical_centered(|ui| {
                        ui.add_space(4.0);
                        if ui.button("◀\n面板").clicked() {
                            self.panel_expanded = true;
                        }
                    });
                });
            return;
        }
        egui::Panel::right("side")
            .resizable(true)
            .default_size(320.0)
            .min_size(150.0)
            .show(ui, |ui| {
                egui::ScrollArea::vertical().show(ui, |ui| {
                    // 收起按钮（顶行）
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new("◀ 收起面板").weak().size(11.0));
                        if ui.button("收起").clicked() {
                            self.panel_expanded = false;
                        }
                    });
                    if self.game.deploying && !(self.game.test_mode && self.game.test_placing) {
                        self.deploy_panel(ui);
                        return;
                    }
                    // 试验模式：只能在开局部署阶段通过按钮开启；对局中仅展示已开启的试验模式。
                    if self.game.test_mode {
                        ui.separator();
                        ui.horizontal(|ui| {
                            ui.label(egui::RichText::new("🧪 试验模式").strong());
                        });
                        ui.label(
                            egui::RichText::new(
                                "敌方不行动；视野外敌人以暗色显示；可自由放置双方棋子（不扣点数）",
                            )
                            .weak()
                            .size(11.0),
                        );
                        if ui
                            .add(
                                egui::Button::new(if self.game.test_placing {
                                    "✅ 退出放置模式（F3）"
                                } else {
                                    "📌 进入放置棋子模式（F3）"
                                })
                                .min_size(egui::vec2(ui.available_width(), 0.0)),
                            )
                            .clicked()
                        {
                            self.toggle_test_placing();
                        }
                        if self.game.test_placing {
                            ui.horizontal(|ui| {
                                ui.label("放置阵营：");
                                ui.radio_value(&mut self.game.test_place_team, Team::Player, "己方");
                                ui.radio_value(&mut self.game.test_place_team, Team::Ai, "敌方");
                            });
                            self.test_place_panel(ui);
                        }
                    }
                    // 部署阶段只展示试验放置面板，不进入对局中的其余面板
                    if self.game.deploying {
                        return;
                    }
                    // 持续部署状态（对局中）：招募/追加部署入口
                    if self.game.sustain {
                        ui.separator();
                        let team = self.side_team();
                        let pts = self
                            .game
                            .recruit_points
                            .get(&team)
                            .copied()
                            .unwrap_or(0);
                        let per = self
                            .game
                            .sustain_per_turn
                            .get(&team)
                            .copied()
                            .unwrap_or(0);
                        let first_round = self.game.recruit_zone_turn > 0
                            && self.game.turn <= self.game.recruit_zone_turn;
                        ui.label(
                            egui::RichText::new(format!(
                                "♾ 持续部署 · {} · 每回合 +{}",
                                mp::team_label(team),
                                per
                            ))
                            .strong(),
                        );
                        ui.label(format!("当前可用点数：{}", pts));
                        if self.game.sustain_deploying {
                            self.reinforce_panel(ui);
                        } else if ui
                            .add(
                                egui::Button::new(if first_round {
                                    "📦 招募（按 D）"
                                } else {
                                    "📦 追加部署（按 D）"
                                })
                                .min_size(egui::vec2(ui.available_width(), 0.0)),
                            )
                            .clicked()
                        {
                            self.toggle_sustain_deploy();
                        }
                    }
                    // 存档 / 读档
                    ui.separator();
                    egui::CollapsingHeader::new("💾 存档 / 读档")
                        .default_open(false)
                        .show(ui, |ui| {
                            if ui
                                .add(
                                    egui::Button::new("💾 保存当前对局")
                                        .min_size(egui::vec2(ui.available_width(), 0.0)),
                                )
                                .clicked()
                            {
                                match self.save_game() {
                                    Ok(p) => self.log(format!("已保存对局到 {}", p)),
                                    Err(e) => self.log(format!("⚠ 保存失败: {}", e)),
                                }
                            }
                            let saves = Self::scan_saves();
                            if saves.is_empty() {
                                ui.label(egui::RichText::new("暂无存档").weak());
                            } else {
                                ui.label(
                                    egui::RichText::new(format!("已保存存档（{} 个）：", saves.len()))
                                        .weak(),
                                );
                                for (name, path) in saves {
                                    if ui
                                        .add(
                                            egui::Button::new(format!("📂 {}", name))
                                                .min_size(egui::vec2(ui.available_width(), 0.0)),
                                        )
                                        .clicked()
                                    {
                                        match self.load_game(&path) {
                                            Ok(()) => {
                                                self.log(format!("已从 {} 加载对局并继续", path.display()));
                                            }
                                            Err(e) => self.log(format!("⚠ 读档失败: {}", e)),
                                        }
                                    }
                                }
                            }
                        });

                    // 同时攻击模式入口/确认（对局中可用）
                    if !self.game.deploying && self.game_over.is_none() {
                        ui.separator();
                        if self.simul_mode {
                            ui.label(
                                egui::RichText::new("⚔ 同时攻击模式：点击己方单位，再点击红色敌人下达命令")
                                    .color(egui::Color32::from_rgb(255, 200, 90)),
                            );
                            ui.label(format!("已下达命令：{} 条", self.simul_orders.len()));
                            for o in &self.simul_orders {
                                let at = self.game.unit_at(o.attacker).map(|u| u.name_with_label()).unwrap_or_else(|| "?".into());
                                ui.label(format!("  {} → {}", at, hex::hex_label(o.target)));
                            }
                            ui.horizontal(|ui| {
                                let can_confirm = !self.simul_orders.is_empty();
                                if ui
                                    .add_enabled(
                                        can_confirm,
                                        egui::Button::new(format!(
                                            "✅ 确认同时攻击{}（按 C）",
                                            if can_confirm {
                                                format!("（{} 条）", self.simul_orders.len())
                                            } else {
                                                String::new()
                                            }
                                        )),
                                    )
                                    .clicked()
                                {
                                    self.confirm_simul_attack();
                                }
                                if ui.button("❌ 退出（U/Esc）").clicked() {
                                    self.toggle_simul_mode();
                                }
                            });
                        } else if ui
                            .add(
                                egui::Button::new("⚔ 同时攻击（按 U）")
                                    .min_size(egui::vec2(ui.available_width(), 0.0)),
                            )
                            .clicked()
                        {
                            self.toggle_simul_mode();
                        }
                    }

                    ui.heading(egui::RichText::new("战场态势").color(theme::ACCENT));
                    ui.separator();

                    let side_team = self.side_team();
                    let side_label = if self.multiplayer {
                        format!("■ {}方单位", mp::team_label(side_team))
                    } else {
                        "■ 我方单位".to_string()
                    };
                    ui.label(
                        egui::RichText::new(side_label)
                            .strong()
                            .color(theme::ALLY_TEXT),
                    );
                    for u in self.game.units_of(side_team) {
                        let marker = if self.selected == Some(u.pos) && self.selected_is_air == u.kind.is_air() {
                            "▶ "
                        } else {
                            "  "
                        };
                        // 状态色块：绿=可行动 灰=已耗尽
                        let dot = if u.actions_left > 0 { "●" } else { "○" };
                        let spent_note = if u.actions_left > 0
                            && u.actions_left < u.kind.action_count()
                        {
                            " (剩)"
                        } else {
                            ""
                        };
                        let ammo_note = if u.kind.max_ammo() > 0 && u.ammo == 0 {
                            " ⚠无弹药".to_string()
                        } else if u.kind.max_ammo() > 0 && u.ammo <= 2 {
                            format!(" 弹{}", u.ammo)
                        } else {
                            String::new()
                        };
                        let mut txt = format!(
                            "{} {}{} {}{} @{}  行动 {}/{}{}",
                            marker,
                            dot,
                            u.label,
                            u.kind.name(),
                            spent_note,
                            hex::hex_label(u.pos),
                            u.actions_left,
                            u.kind.action_count(),
                            ammo_note
                        );
                        if !u.passengers.is_empty() {
                            let ps: Vec<String> = u.passengers.iter().map(|p| p.label.to_string()).collect();
                            txt.push_str(&format!("  载[{}]", ps.join(",")));
                        }
                        let btn = ui.add(
                            egui::Button::new(txt)
                                .min_size(egui::vec2(ui.available_width(), 0.0)),
                        );
                        if btn.clicked() {
                            self.selected = Some(u.pos);
                            self.selected_is_air = u.kind.is_air();
                            self.zero_hint = None;
                        }
                        btn.on_hover_text(format!(
                            "血量 {}  射程{} 护甲{} 攻击{} 命中{}% 行动力{} 视野{} 弹药{}/{}",
                            u.hp,
                            u.kind.range(),
                            u.kind.armor(),
                            u.kind.attack(),
                            u.kind.hit_rate(),
                            u.kind.movement(),
                            u.kind.vision(),
                            u.ammo,
                            u.kind.max_ammo()
                        ));
                    }

                    ui.add_space(6.0);
                    let enemy_team = side_team.opponent();
                    // 观战全视野模式才列出全部敌方单位；单方视角（含 --view acting）
                    // 只列视野内侦察到的。
                    let full_vision = self.multiplayer
                        && self.view_mode == mp::ViewMode::Spectator;
                    let seen: Vec<&Unit> = self
                        .game
                        .units_of(enemy_team)
                        .into_iter()
                        .filter(|u| {
                            full_vision
                                || self.visible_enemies.contains(&u.pos)
                                || self.game.test_mode
                        })
                        .collect();
                    ui.label(
                        egui::RichText::new(if full_vision {
                            if self.game.test_mode {
                                format!(
                                    "■ {}方单位（试验模式全显 {} 个，暗色=视野外）",
                                    mp::team_label(enemy_team),
                                    seen.len()
                                )
                            } else {
                                format!(
                                    "■ {}方单位（视野内 {} 个，点击查看）",
                                    mp::team_label(enemy_team),
                                    seen.len()
                                )
                            }
                        } else if self.game.test_mode {
                            format!(
                                "■ 敌方单位（试验模式全显 {} 个，暗色=视野外）",
                                seen.len()
                            )
                        } else {
                            format!(
                                "■ 敌方单位（视野内 {} 个，点击查看）",
                                seen.len()
                            )
                        })
                        .strong()
                        .color(theme::ENEMY_TEXT),
                    );
                    if seen.is_empty() {
                        ui.label(
                            egui::RichText::new(if self.game.test_mode {
                                "  暂无敌方单位"
                            } else {
                                "  视野内暂无敌人（用直升机等侦察单位探明敌情）"
                            })
                                .weak(),
                        );
                    }
                    for u in seen {
                        let mut txt = format!(
                            "  {} {} @{}  行动 {}/{}",
                            u.label,
                            u.kind.name(),
                            hex::hex_label(u.pos),
                            u.actions_left,
                            u.kind.action_count()
                        );
                        if self.game.test_mode && !self.visible_enemies.contains(&u.pos) {
                            txt = format!("[暗]{}", txt);
                        }
                        if !u.passengers.is_empty() {
                            let ps: Vec<String> = u.passengers.iter().map(|p| p.label.to_string()).collect();
                            txt.push_str(&format!("  载[{}]", ps.join(",")));
                        }
                        let btn = ui.add(
                            egui::Button::new(txt)
                                .min_size(egui::vec2(ui.available_width(), 0.0)),
                        );
                        if btn.clicked() {
                            self.selected = Some(u.pos);
                            self.selected_is_air = u.kind.is_air();
                            self.zero_hint = None;
                        }
                        btn.on_hover_text(format!(
                            "血量 {}  射程{} 护甲{} 攻击{} 命中{}% 行动力{} 视野{} 弹药{}/{}",
                            u.hp,
                            u.kind.range(),
                            u.kind.armor(),
                            u.kind.attack(),
                            u.kind.hit_rate(),
                            u.kind.movement(),
                            u.kind.vision(),
                            u.ammo,
                            u.kind.max_ammo()
                        ));
                    }

                    ui.add_space(10.0);
                    ui.separator();
                    self.selected_panel(ui);
                    ui.separator();

                    ui.label(
                        egui::RichText::new("操作：点击己方单位选中；点绿色格子移动；点红色高亮敌人攻击；地面载具按 X 进入装载模式后点紧邻货物上车（青绿高亮），运载直升机按 X 装载正下方单位；补给单位按 S 进入补给模式后点半径 2 格内友军补给；榴弹炮点黄色格子开炮；M-SHORAD 按 M 切换导弹模式；右键取消选择。")
                            .weak()
                            .size(12.0),
                    );
                });
            });
    }

    fn selected_panel(&mut self, ui: &mut egui::Ui) {
        if self.selected.is_none() {
            ui.label("未选择单位（点击地图上你的单位）");
            return;
        }
        let Some(u) = self.selected_unit().cloned() else {
            self.selected = None;
            return;
        };
        if std::env::var_os("HEX_WARGAME_DEBUG").is_some() {
            eprintln!(
                "[gui] selected_panel unit={} kind={:?} air={}",
                u.label,
                u.kind,
                u.kind.is_air()
            );
        }
        let me = if self.multiplayer {
            match self.gui_control_team() {
                Some(t) => t,
                None => {
                    ui.label(egui::RichText::new("（观战模式：只读）").weak());
                    return;
                }
            }
        } else {
            Team::Player
        };
        let (color, head) = if u.team == me {
            (
                theme::ALLY_TEXT,
                format!("{} · {}（我方）", u.label, u.kind.name()),
            )
        } else {
            (
                theme::ENEMY_TEXT,
                format!("{} · {}（敌方）", u.label, u.kind.name()),
            )
        };
        ui.heading(egui::RichText::new(head).color(color));
        ui.label(format!("位置 {}   血量 {}/{}", hex::hex_label(u.pos), u.hp, u.kind.max_hp()));
        if self.multiplayer && u.team != me {
            ui.label(egui::RichText::new("（对方单位：只读）").weak());
            return;
        }
        if u.is_dual_weapon() {
            // 双武器单位（坦克/主战坦克/步战/装甲骑兵/M-SHORAD/步兵/榴弹炮等）：显示当前模式
            ui.label(format!(
                "{}：射程{}  攻击力{}  命中率{}%",
                u.mode_name(),
                u.eff_range(),
                u.eff_attack(),
                u.eff_hit_rate()
            ));
        } else {
            ui.label(format!(
                "射程{}  护甲{}  攻击力{}  命中率{}%",
                u.kind.range(),
                u.kind.armor(),
                u.kind.attack(),
                u.kind.hit_rate()
            ));
        }
        ui.label(format!(
            "行动次数 {}/{}   行动力 {}",
            u.actions_left,
            u.kind.action_count(),
            u.kind.movement()
        ));
        // 弹药（双武器单位按当前模式显示）
        if u.kind.max_ammo() > 0 {
            let (shown, total, name) = if u.kind == UnitKind::Supply {
                (u.ammo, 5, "补给弹药")
            } else if u.aa_mode {
                (u.aa_ammo, 1, "Stinger")
            } else if u.kind == UnitKind::AaMgv && u.missile_mode {
                (u.missile_ammo, 2, "Stinger弹")
            } else if u.missile_mode {
                match u.kind {
                    UnitKind::EliteInfantry | UnitKind::SpecialForces => (u.missile_ammo, 4, "M3E1弹"),
                    UnitKind::Rifleman => (u.missile_ammo, 4, "XM1176弹"),
                    UnitKind::Howitzer => (u.missile_ammo, 4, "M864弹"),
                    UnitKind::Tank | UnitKind::HeavyTank => (u.missile_ammo, 42, "机枪弹"),
                    UnitKind::Ifv | UnitKind::CavalryIfv => (u.missile_ammo, u.kind.max_missile_ammo(), "TOW弹"),
                    _ => (u.missile_ammo, 0, "副武器弹"),
                }
            } else if u.kind == UnitKind::SpecialForces || u.kind == UnitKind::EliteInfantry {
                (u.ammo, 10, "步枪弹")
            } else {
                (u.ammo, u.kind.max_ammo(), "弹药")
            };
            let (txt, col) = if shown == 0 {
                (format!("{} 0/{} —— 已耗尽！", name, total), egui::Color32::from_rgb(255, 110, 95))
            } else if shown <= 2 {
                (
                    format!("{} {}/{}", name, shown, total),
                    egui::Color32::from_rgb(255, 180, 90),
                )
            } else {
                (
                    format!("{} {}/{}", name, shown, total),
                    egui::Color32::from_rgb(200, 210, 190),
                )
            };
            ui.colored_label(col, txt);
        } else {
            ui.label(egui::RichText::new("弹药：无（该单位无武器）").weak());
        }
        // 诱饵弹：被攻击时被命中率 ×0.6
        if u.flares > 0 {
            let max = if u.kind == UnitKind::HeavyTransportHeli { 3 } else { 2 };
            let col = if u.flares == 1 {
                egui::Color32::from_rgb(255, 180, 90)
            } else {
                egui::Color32::from_rgb(200, 210, 190)
            };
            ui.colored_label(
                col,
                format!("诱饵弹 {} / {}（被攻击命中率 ×0.6）", u.flares, max),
            );
        }
        // 所处地形与隐蔽效果
        let terrain_txt = if self.game.map.forests.contains(&u.pos) {
            Some("位于森林：被命中率 ×0.8；移动消耗 ×2".to_string())
        } else if self.game.map.buildings.contains(&u.pos) {
            Some("位于楼房：被命中率 ×0.6（仅步兵可进入）".to_string())
        } else if self.game.map.water.contains(&u.pos) {
            Some("位于水域上方（仅空中单位可停留；不能卸下步兵）".to_string())
        } else if self.game.map.roads.contains(&u.pos) {
            Some("位于道路：车辆移动每格仅消耗 0.5 行动力".to_string())
        } else if self.game.map.obstacles.contains(&u.pos) {
            Some("位于岩石上方（直升机无法开火）".to_string())
        } else {
            None
        };
        if let Some(t) = terrain_txt {
            ui.label(egui::RichText::new(t).weak().color(egui::Color32::from_rgb(150, 190, 130)));
        }
        // 补给：选中补给单位进入补给模式，点击半径 2 格内友军补给（双方各消耗 1 行动）。
        if u.kind == UnitKind::Supply {
            ui.separator();
            ui.label(
                egui::RichText::new(format!(
                    "📦 补给：行动力 0（不可移动/攻击）；每回合 2 行动，携带 5 点补给弹药（剩余 {}）。进入补给模式后点击半径 2 格内友军补给——补给单位消耗 1 行动与 1 点弹药，被补给方消耗 1 行动并恢复全部弹药。",
                    u.ammo
                ))
                .color(egui::Color32::from_rgb(150, 210, 150)),
            );
            if u.team == me {
                let can = u.actions_left >= 1 && u.ammo >= 1;
                let btn = ui.add_enabled(
                    can,
                    egui::Button::new(if self.supply_mode {
                        "退出补给模式 (S)"
                    } else {
                        "进入补给模式 (S)"
                    }),
                );
                if btn.clicked() {
                    self.toggle_supply_mode();
                }
                btn.on_hover_text(
                    "进入后点击半径 2 格（绿色高亮）内友军补给；补给单位与被补给方各消耗 1 行动",
                );
                if self.supply_mode {
                    ui.colored_label(
                        egui::Color32::from_rgb(150, 235, 170),
                        "补给模式：点击半径 2 格（绿色高亮）内的友军进行补给（S/Esc 退出）",
                    );
                } else if !can {
                    ui.label(egui::RichText::new("行动次数不足").weak());
                }
            }
        } else if u.team == me && self.game.in_supply_zone(me, u.pos) {
            ui.label(
                egui::RichText::new("📦 处于补给范围内：选中补给单位后按 S 可为其补满弹药")
                    .weak()
                    .color(egui::Color32::from_rgb(150, 210, 150)),
            );
        }
        // 大本营补给：本方大本营据点半径 2 格内，任意己方棋子消耗 1 行动补满弹药。
        if u.team == me && self.game.in_hq_supply_area(me, u.pos) {
            ui.separator();
            ui.label(
                egui::RichText::new("🏛 位于本方大本营据点半径 2 格内")
                    .color(egui::Color32::from_rgb(216, 196, 148)),
            );
            let can = u.actions_left >= 1;
            let btn = ui.add_enabled(
                can,
                egui::Button::new("大本营补给（消耗 1 行动，恢复全部弹药）(H)"),
            );
            if btn.clicked() {
                match self.game.resupply_at_hq(me, u.pos) {
                    Ok(m) => self.log(format!("🏛 {}", m)),
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
                self.after_action();
            }
            if !can {
                ui.label(egui::RichText::new("行动次数不足").weak());
            }
        }
        // 步兵登屋顶：建筑内的步兵可在【屋中/屋顶】间切换（免费，不耗行动）
        if u.kind.is_foot() && self.game.map.buildings.contains(&u.pos) && u.team == me {
            ui.separator();
            if u.rooftop {
                ui.label(
                    egui::RichText::new(
                        "🪜 屋顶：视野无视森林/楼房，攻击无视LOS；但失去楼房闪避（×0.6）与隐蔽加成",
                    )
                    .color(egui::Color32::from_rgb(255, 200, 90)),
                );
            } else {
                ui.label(
                    egui::RichText::new("🏠 屋中：享受楼房闪避（被命中率 ×0.6）与隐蔽加成")
                        .color(egui::Color32::from_rgb(150, 190, 130)),
                );
            }
            let can_toggle = u.actions_left >= 1;
            if ui
                .add_enabled(
                    can_toggle,
                    egui::Button::new(if u.rooftop {
                        "🏠 进入屋中（消耗 1 行动）"
                    } else {
                        "🪜 登上屋顶（消耗 1 行动）"
                    }),
                )
                .clicked()
            {
                if let Some(mu) = self.game.unit_at_mut(u.pos) {
                    mu.rooftop = !mu.rooftop;
                    mu.actions_left -= 1;
                }
                self.log(format!(
                    "{} {}（消耗 1 行动）",
                    u.name_with_label(),
                    if u.rooftop {
                        "登上屋顶（视野/攻击无视遮挡，失去楼房闪避）"
                    } else {
                        "进入屋中（恢复楼房闪避）"
                    }
                ));
                self.after_action();
            } else if !can_toggle {
                ui.label(egui::RichText::new("行动次数不足，无法切换").weak());
            }
        }
        if u.kind == UnitKind::Atgm {
            ui.label(egui::RichText::new("（TOW射手：攻击消耗 2 次行动；Javelin射手只耗 1 次）").weak());
        }
        if u.kind == UnitKind::Tank {
            ui.label(egui::RichText::new("（坦克：护甲 3，步枪手打不穿；按 M 可切车载重机枪压制步兵）").weak());
        }
        if u.kind.capacity() > 0 {
            let extra = if u.kind.is_air() {
                "；直升机从正下方（自身格）载入/放下，且不能在岩石/水域上方上下机"
            } else {
                ""
            };
            ui.label(egui::RichText::new(format!(
                "（{}：载重 {}/{}（步兵=HP、补给 3、榴弹炮 5、悍马 6、侦察战车 7、迫击炮 8）；上车耗载具 1 次行动、卸下免费{}）",
                u.kind.name(),
                u.used_weight(),
                u.kind.capacity(),
                extra
            ))
            .weak());
            // 地面载具：装载模式开关（按 X 同样可切换）。
            if !u.kind.is_air() && u.team == me {
                ui.horizontal(|ui| {
                    let btn = ui.add_enabled(
                        u.actions_left > 0 && u.has_space(),
                        egui::Button::new(if self.load_mode {
                            "退出装载模式 (X)"
                        } else {
                            "进入装载模式 (X)"
                        }),
                    );
                    if btn.clicked() {
                        self.toggle_load_mode();
                    }
                    btn.on_hover_text(
                        "装载模式下点击紧邻（青绿高亮）的己方单位上车；此模式不能移动",
                    );
                });
                if self.load_mode {
                    ui.colored_label(
                        egui::Color32::from_rgb(120, 230, 170),
                        "装载模式：点击紧邻高亮的己方单位上车（不能移动；X/Esc 退出）",
                    );
                }
            } else if u.kind.is_air() && u.team == me {
                // 直升机：按 X 装载正下方（自身格）的己方单位。
                let can = u.actions_left >= 1 && u.has_space();
                let btn = ui.add_enabled(can, egui::Button::new("装载正下方单位 (X)"));
                if btn.clicked() {
                    match self.game.heli_board(u.pos) {
                        Ok(()) => {
                            let heli = self
                                .game
                                .air_units
                                .get(&u.pos)
                                .map(|h| h.name_with_label())
                                .unwrap_or_default();
                            let p = self
                                .game
                                .air_units
                                .get(&u.pos)
                                .and_then(|h| h.passengers.last())
                                .map(|p| p.name_with_label())
                                .unwrap_or_default();
                            self.log(format!("{} 载入正下方 {}", heli, p));
                        }
                        Err(e) => self.log(format!("⚠ {}", e)),
                    }
                    self.after_action();
                }
                btn.on_hover_text("把正下方（同一格）的己方步兵/补给载入机舱；消耗直升机 1 行动");
            }
        }
        if u.kind.is_air() {
            ui.label(egui::RichText::new(
                "（空中单位：可越过岩石；一般陆战单位打不到它；在岩石上方时无法开火）",
            )
            .weak());
        }
        if u.kind == UnitKind::AaInfantry || u.kind == UnitKind::AaLauncher {
            ui.label(egui::RichText::new("（防空单位：只能攻击直升机）").weak());
        }
        if u.kind.is_humvee() {
            ui.label(egui::RichText::new("（悍马系列：血量2/护甲1/行动2/行动力4；被机炮命中40%概率直接击毁，被坦克炮命中按护甲1殉爆80%；适用对步兵的压制规则）").weak());
        }
        if u.kind == UnitKind::HmgGunner {
            ui.label(egui::RichText::new("（重机枪手：可对空；楼内未登屋顶不能对空；攻击步兵/悍马可压制；每次攻击耗 1 次行动，但每移动到一个位置后需先「架设」才能开火）").weak());
            ui.horizontal(|ui| {
                if u.deployed {
                    ui.label(
                        egui::RichText::new("◎ 已架设（可开火）")
                            .color(egui::Color32::from_rgb(255, 200, 90)),
                    );
                } else {
                    let can_deploy = u.actions_left > 0;
                    if ui
                        .add_enabled(can_deploy, egui::Button::new("🛠 架设（消耗 1 次行动）"))
                        .clicked()
                    {
                        match self.game.deploy(u.pos) {
                            Ok(()) => self.log(format!("{} 完成架设", u.name_with_label())),
                            Err(e) => self.log(format!("⚠ {}", e)),
                        }
                    }
                }
            });
        }
        if u.kind == UnitKind::HumveeHmg {
            ui.label(egui::RichText::new("（悍马-重机枪：可对空；楼内未登屋顶不能对空；攻击步兵/悍马可压制；每次攻击耗 1 次行动，无需架设）").weak());
        }
        if u.suppressed {
            let n = u.suppression_stacks.max(1);
            ui.label(
                egui::RichText::new(format!("⚠ 被压制：新回合行动次数 -{}", n))
                    .color(egui::Color32::from_rgb(240, 70, 60)),
            );
        }
        if matches!(u.kind, UnitKind::HeavyTank | UnitKind::CavalryIfv) {
            let ad_txt = format!(
                "主动防御可用（剩余 {} 次；每次被命中触发 1 次，同时攻击命中≥2发时随机抵消其中 1 发）",
                u.ad_uses
            );
            ui.label(
                egui::RichText::new(format!("🛡 {}", ad_txt))
                    .color(egui::Color32::from_rgb(90, 200, 255)),
            );
        }
        if u.kind == UnitKind::Howitzer {
            ui.label(egui::RichText::new("（榴弹炮：不能自主移动，需卡车装载；射击前需先「架设」，架设后可持续射击。开火模式点击黄色格子炮击，中心80%/周围50%命中，敌我皆伤，范围内敌军被压制（护甲≥2免疫）；M 键切 M864 子母弹 100%/100%）").weak());
            ui.horizontal(|ui| {
                // 架设状态
                if u.deployed {
                    ui.label(
                        egui::RichText::new("◎ 已架设（可直接射击）")
                            .color(egui::Color32::from_rgb(255, 200, 90)),
                    );
                } else {
                    let can_aim = u.actions_left > 0;
                    let aim_btn = ui.add_enabled(
                        can_aim,
                        egui::Button::new("🛠 架设（消耗 1 次行动）"),
                    );
                    if aim_btn.clicked() {
                        match self.game.deploy(u.pos) {
                            Ok(()) => self.log(format!("{} 完成架设（本回合不能射击）", u.name_with_label())),
                            Err(e) => self.log(format!("⚠ {}", e)),
                        }
                    }
                }
                let mode = if self.howitzer_fire_mode {
                    "射击模式"
                } else {
                    "行动模式"
                };
                ui.label(format!("模式：{}", mode));
                if ui
                    .button(if self.howitzer_fire_mode {
                        "切到行动模式"
                    } else {
                        "切到射击模式 (T)"
                    })
                    .clicked()
                {
                    self.toggle_howitzer_mode();
                }
                // 烟雾弹（需已架设）
                let smoke_btn = ui.add_enabled(
                    u.deployed,
                    egui::Button::new(if self.smoke_shot_pending {
                        "💨 烟雾弹待发射 (点击目标/ Esc取消)"
                    } else {
                        "💨 发射烟雾弹（半径2，持续2回合）"
                    }),
                );
                if smoke_btn.clicked() {
                    self.smoke_shot_pending = !self.smoke_shot_pending;
                    if self.smoke_shot_pending {
                        self.log("烟雾弹待发射：点击射程内格子施放（Esc 取消）".into());
                    }
                }
            });
        }
        // 自行迫击炮：行动/射击模式（按 T 或按钮切换，与榴弹炮相同）
        if u.kind == UnitKind::Mortar {
            ui.horizontal(|ui| {
                let mode = if self.howitzer_fire_mode {
                    "射击模式"
                } else {
                    "行动模式"
                };
                ui.label(format!("模式：{}", mode));
                if ui
                    .button(if self.howitzer_fire_mode {
                        "切到行动模式"
                    } else {
                        "切到射击模式 (T)"
                    })
                    .clicked()
                {
                    self.toggle_howitzer_mode();
                }
            });
            // 自行迫击炮：无需架设，直接发射烟雾弹（半径 1）
            ui.horizontal(|ui| {
                let smoke_btn = ui.add_enabled(
                    u.actions_left > 0 && u.ammo > 0,
                    egui::Button::new(if self.smoke_shot_pending {
                        "💨 烟雾弹待发射 (点击目标/ Esc取消)"
                    } else {
                        "💨 发射烟雾弹（半径1，持续2回合）"
                    }),
                );
                if smoke_btn.clicked() {
                    self.smoke_shot_pending = !self.smoke_shot_pending;
                    if self.smoke_shot_pending {
                        self.log("烟雾弹待发射：点击射程内格子施放（Esc 取消）".into());
                    }
                }
            });
        }
        if u.kind == UnitKind::Truck {
            ui.label(egui::RichText::new("（卡车：攻击力 0，不能攻击）").weak());
        }
        ui.add_space(4.0);

        if u.team == me {
            // 视野内敌人（按视野/护甲标注状态）：视野外的一律不显示（未知）
            let in_range: Vec<&hex_wargame::unit::Unit> = self
                .game
                .enemies_of(me)
                .into_iter()
                .filter(|e| {
                    (self.multiplayer
                        || self.visible_enemies.contains(&e.pos)
                        || self.game.test_mode)
                        && Hex::distance(u.pos, e.pos) <= u.eff_range()
                })
                .collect();
            if in_range.is_empty() {
                ui.label(egui::RichText::new("射程内可见敌人：无").weak());
            } else {
                ui.label(egui::RichText::new("射程内可见敌人（红色=可攻击）：").strong());
                for e in in_range {
                    let tgt = u.can_target_unit(e.kind);
                    let dmg = u.eff_attack() >= e.kind.armor();
                    let (status, col) = match (tgt, dmg) {
                        (true, true) => ("可攻击", egui::Color32::from_rgb(255, 120, 110)),
                        (true, false) => ("护甲免疫", egui::Color32::GRAY),
                        (false, _) => ("无法攻击此目标", egui::Color32::GRAY),
                    };
                    ui.colored_label(
                        col,
                        format!(
                            "{} {}（{}）· 距离{}",
                            hex::hex_label(e.pos),
                            e.kind.name(),
                            status,
                            Hex::distance(u.pos, e.pos)
                        ),
                    );
                }
            }
            // 载具：搭载/放下
            if u.kind.capacity() > 0 {
                ui.separator();
                if u.kind.is_air() {
                    // 运输直升机：从正下方载入 / 放到正下方（右侧面板按钮）
                    if std::env::var_os("HEX_WARGAME_DEBUG").is_some() {
                        eprintln!(
                            "[gui] heli panel: passengers={} below={:?}",
                            u.passengers.len(),
                            self.game.units.get(&u.pos).map(|i| i.label)
                        );
                    }
                    // 已搭载的步兵（可逐个放下）——先显示，再显示载入入口，
                    // 这样重型运输直升机载了 1 名后仍能继续载入第 2 名。
                    if !u.passengers.is_empty() {
                        ui.label(egui::RichText::new("机上货物：").strong());
                        for p in &u.passengers {
                            ui.horizontal(|ui| {
                                ui.label(format!("  {} {}", p.label, p.kind.name()));
                                let can_unload = u.actions_left > 0
                                    && !self.game.map.obstacles.contains(&u.pos)
                                    && !self.game.map.water.contains(&u.pos)
                                    && !self.game.units.contains_key(&u.pos);
                                let btn = ui.add_enabled(
                                    can_unload,
                                    egui::Button::new("放下到正下方"),
                                );
                                if btn.clicked() {
                                    match self.game.heli_unload_label(u.pos, p.label) {
                                        Ok(()) => {
                                            self.log(format!(
                                                "{} 放下 {} 到正下方 {}（步兵本回合不能行动）",
                                                u.name_with_label(),
                                                p.name_with_label(),
                                                hex::hex_label(u.pos)
                                            ));
                                        }
                                        Err(e) => self.log(format!("⚠ {}", e)),
                                    }
                                    self.after_action();
                                }
                                btn.on_hover_text(
                                    "消耗直升机 1 次行动；放下后步兵本回合不能再行动",
                                );
                            });
                        }
                    }
                    // 只要机舱还有载重且正下方有己方可载单位，就显示载入入口。
                    if u.has_space() {
                        let inf = self
                            .game
                            .units
                            .get(&u.pos)
                            .filter(|inf| {
                                inf.team == me
                                    && u.can_carry(inf.kind)
                                    && u.used_weight() + inf.kind.cargo_weight()
                                        <= u.kind.capacity()
                            })
                            .cloned();
                        if let Some(inf) = inf {
                            // 重型运输直升机载运补给时豁免补给的行动要求。
                            let cargo_exception = inf.kind == UnitKind::Supply;
                            let can_load =
                                u.actions_left > 0 && (inf.actions_left > 0 || cargo_exception);
                            let btn = ui.add_enabled(
                                can_load,
                                egui::Button::new(format!(
                                    "载入下方 {}",
                                    inf.name_with_label()
                                )),
                            );
                            if btn.clicked() {
                                match self.game.heli_board(u.pos) {
                                    Ok(()) => {
                                        self.log(format!(
                                            "{} 载入下方 {}（双方各消耗 1 次行动）",
                                            u.name_with_label(),
                                            inf.name_with_label()
                                        ));
                                    }
                                    Err(e) => self.log(format!("⚠ {}", e)),
                                }
                                self.after_action();
                            }
                            btn.on_hover_text(
                                "消耗直升机与货物各 1 次行动；正下方需有己方可载单位且双方均有行动次数",
                            );
                        } else {
                            ui.label(
                                egui::RichText::new("正下方没有可搭载的己方单位").weak(),
                            );
                        }
                    } else {
                        ui.label(egui::RichText::new("机舱载重已满").weak());
                    }
                } else if !u.passengers.is_empty() {
                    ui.label(egui::RichText::new("车上货物：").strong());
                    for p in &u.passengers {
                        ui.horizontal(|ui| {
                            ui.label(format!("  {} {}", p.label, p.kind.name()));
                            let btn = ui
                                .add_enabled(
                                    u.actions_left > 0,
                                    egui::Button::new("放下"),
                                )
                                .on_hover_text(
                                    "放下到紧邻载具的非岩石空格（不消耗行动；装车耗 1 次行动）",
                                )
                                .on_disabled_hover_text("载具行动次数不足");
                            if btn.clicked() {
                                if std::env::var_os("HEX_WARGAME_DEBUG").is_some() {
                                    eprintln!("[gui] pending disembark {}", p.label);
                                }
                                self.pending_disembark = Some(p.label);
                                self.log(format!(
                                    "点击紧邻 {} 的空格放下 {}（Esc 取消）",
                                    hex::hex_label(u.pos),
                                    p.name_with_label()
                                ));
                            }
                        });
                    }
                }
                // 可搭载的紧邻货物（仅地面载具；直升机从正下方载入）
                if !u.kind.is_air() {
                    let mut boardable: Vec<hex_wargame::unit::Unit> = Vec::new();
                    for n in u.pos.neighbors() {
                        if let Some(inf) = self.game.unit_at(n).cloned() {
                            if inf.team == me
                                && u.can_carry(inf.kind)
                                && u.used_weight() + inf.kind.cargo_weight()
                                    <= u.kind.capacity()
                            {
                                boardable.push(inf);
                            }
                        }
                    }
                    if !boardable.is_empty() {
                        ui.label(egui::RichText::new("可搭载（紧邻货物，或点击货物上车）：").strong());
                        for inf in &boardable {
                            let btn = ui
                                .add_enabled(
                                    u.actions_left > 0,
                                    egui::Button::new(format!("搭载 {}", inf.name_with_label())),
                                )
                                .on_hover_text("消耗载具 1 次行动")
                                .on_disabled_hover_text("载具行动次数不足");
                            if btn.clicked() {
                                match self.game.board(u.pos, inf.pos) {
                                    Ok(()) => {
                                        self.log(format!(
                                            "{} 搭载 {}",
                                            u.name_with_label(),
                                            inf.name_with_label()
                                        ));
                                    }
                                    Err(e) => self.log(format!("⚠ {}", e)),
                                }
                                self.after_action();
                            }
                        }
                    }
                }
                if self.pending_disembark.is_some() {
                    ui.colored_label(
                        egui::Color32::from_rgb(255, 200, 100),
                        format!("等待选择落点（点击空格放下 {}；再点一次取消）", self.pending_disembark.unwrap()),
                    );
                    if ui.button("取消放下").clicked() {
                        self.pending_disembark = None;
                    }
                }
                ui.separator();
            }
            let reach = self
                .game
                .map
                .reachable_hexes_ex(&self.game.units, &self.game.air_units, u.pos, u.kind.movement(), Some(&u));
            ui.label(format!("可移动范围（绿色格子）：{} 格", reach.len()));
            ui.add_space(6.0);
            // 撤退：单位位于本方出发区域（可部署区）内时可主动撤离战场，
            // 按 招募费用 × 当前HP/总HP 返还招募点数（含搭载单位）。
            if self.game.can_retreat(me, u.pos) {
                let refund = hex_wargame::game::GameState::retreat_refund(&u);
                ui.horizontal(|ui| {
                    let btn = ui.add_enabled(
                        true,
                        egui::Button::new(format!("🏳 撤退（返还 {} 点）", refund)),
                    );
                    if btn.clicked() {
                        match self.game.retreat_unit(me, u.pos) {
                            Ok(pts) => {
                                self.log(format!(
                                    "🏳 {} 从 {} 撤退，按血量返还 {} 点招募点",
                                    u.name_with_label(),
                                    hex::hex_label(u.pos),
                                    pts
                                ));
                                self.selected = None;
                                self.zero_hint = None;
                            }
                            Err(e) => self.log(format!("⚠ {}", e)),
                        }
                        self.after_action();
                    }
                    btn.on_hover_text(
                        "单位位于本方出发区域内时可主动撤离：单位立即消失（含车上搭载单位），\n按「招募费用 × 当前 HP / 总 HP」返还招募点数；撤退不算被歼灭。",
                    );
                });
            }
            ui.horizontal(|ui| {
                let spent = u.actions_left <= 0;
                let btn = ui.add_enabled(
                    !spent,
                    egui::Button::new(if spent {
                        "本回合行动已用完"
                    } else {
                        "结束该单位行动 (S)"
                    }),
                );
                if btn.clicked() {
                    self.pass_unit();
                }
                btn.on_hover_text("作废该单位剩余行动");
                if ui.button("取消选择 (Esc)").clicked() {
                    self.selected = None;
                    self.selected_is_air = true;
                    self.zero_hint = None;
                }
            });
        } else {
            // 敌方单位信息：显示威胁提示
            ui.label("⚠ 这是敌方单位，无法控制。\n只能被选中查看属性。");
            ui.add_space(4.0);
            ui.label(egui::RichText::new("能威胁到它的我方单位：").strong());
            let mut any = false;
            for mine in self.game.units_of(me) {
                // 视野规则：该敌人已被我方看到（可点击查看即已侦察），
                // 任何射程覆盖它的我方单位都可攻击（无需个人直线视线）
                if Hex::distance(mine.pos, u.pos) <= mine.eff_range()
                    && mine.can_target_unit(u.kind)
                    && mine.eff_attack() >= u.kind.armor()
                {
                    any = true;
                    ui.colored_label(
                        egui::Color32::from_rgb(140, 220, 160),
                        format!(
                            "  {} {}（距离 {}）",
                            mine.label,
                            mine.kind.name(),
                            Hex::distance(mine.pos, u.pos)
                        ),
                    );
                }
            }
            if !any {
                ui.label(egui::RichText::new("  暂无（射程内无打得穿它的单位）").weak());
            }
        }
    }

    fn bottom_log(&mut self, ui: &mut egui::Ui) {
        egui::Panel::bottom("log")
            .resizable(true)
            .exact_size(150.0) // 固定高度，避免随日志增长导致地图移动
            .show(ui, |ui| {
                ui.label(egui::RichText::new("战斗日志").strong().color(theme::ACCENT));
                egui::ScrollArea::vertical()
                    .stick_to_bottom(true)
                    .show(ui, |ui| {
                        for line in &self.log {
                            if !self.log_visible(line) {
                                continue;
                            }
                            ui.label(
                                egui::RichText::new(&line.text)
                                    .monospace()
                                    .color(log_color(&line.text)),
                            );
                        }
                    });
            });
    }

    fn help_window(&mut self, ctx: &egui::Context) {
        if !self.show_help {
            return;
        }
        egui::Window::new("规则与操作")
            .collapsible(false)
            .resizable(true)
            .default_size([460.0, 560.0])
            .show(ctx, |ui| {
                egui::ScrollArea::vertical().show(ui, |ui| {
                    egui::CollapsingHeader::new("① 基础规则")
                        .default_open(true)
                        .show(ui, |ui| {
                            ui.label(
                                "每回合每单位拥有若干行动次数，每次行动可选择移动或攻击。\n\n                                 - **部署（第 0 回合）**：双方各有 **100 招募点**，按费用招募单位\n\
                                   （可重复），放入己方出发区域（最左/最右 4 列）；\n\
                                   完成部署后开始第 1 回合。\n\
                                 - **弹药**：每次攻击消耗 1 发弹药（无论命中与否），耗尽则无法攻击；\n                                   各单位携弹量见下方属性表（按现实作战携行量设置）。\n                                 - **视野**：各单位视野见下方属性表（步兵最弱、车辆较强、直升机较远、**侦察无人机 12 最远**）；\n                                   我方视野**共享**——只要任一己方单位看得见某个敌人，所有射程能\n                                   覆盖它的己方单位都可以攻击它（无需攻击者本人有直线视线，\n                                   可以由侦察单位引导火力）；岩石与楼房遮挡视线，森林减弱视野\n                                   （视线每穿过 1 格森林，有效视野 -1）。榴弹炮是间瞄火力，\n                                   **无需视野**即可向射程内任意格子炮击。\n                                 - **战争迷雾**：双方预先了解战场地形（无深雾）；无视野的格子\n                                   覆盖半透明灰雾（地形仍隐约可见），其中的敌人显示「?」\n                                   最后已知位置；被击毁的单位**不会**留下幽灵标记（灰雾图标只保留 2 回合；幽灵\n                                   只表示「离开视野」而非「死亡」）。\n                                 - **迷雾开火警告（红色 !）**：任何单位在对方视野之外开火时\n                                   （无论命中与否），其开火位置会被对方标记——玩家可派兵\n                                   查探，AI 也会收到同样的警告并派单位朝警告点机动查探；\n                                   标记在敌人被发现/阵亡/2 回合后失效。\n                                 - **范围框线**：选中己方单位后，黄线=该单位自身的视野范围边界\n                                   （BFS 路程），红线=攻击范围边界（射程）。\n                                 - **榴弹炮**：不能自主移动（需卡车装载，占 2 点运力）；\n                                   射击前需先「架设」（消耗 1 次行动），架设后可持续射击；\n                                   间瞄火力无需视野、无需视线（抛物线弹道，楼房/岩石不挡）即可炮击；\n                                   射程 16，中心命中率 80%/周围 50%。\n                                 - **重机枪手**：每次攻击只耗 1 次行动，但每移动到一个位置后\n                                   需先「架设」（消耗 1 次行动）才能开火；架设状态跨回合保留，\n                                   移动/装车后需重新架设。**悍马-重机枪**每次攻击只耗 1 次行动且无需架设。\n                                 - **压制**：榴弹炮/自行迫击炮炮击后，**范围内所有敌军**（无论命中与否）\n                                   获得 1 回合压制——其**新回合行动次数 -1**（兵牌红色闪电标记）；\n                                   **护甲 ≥ 2 的单位免疫火炮压制**（仍可被正常击伤/击毁）。\n                                   重机枪（车载重机枪/重机枪手/悍马-重机枪）与机关炮攻击步兵或悍马也可压制。\n                                   重机枪可对空，但楼内（未登屋顶）的重机枪不能对空，只有屋顶重机枪能对空。\n                                   坦克/主战坦克在机枪射程内有软目标（护甲<2 的步兵）且主炮射程内无装甲目标时会自动切机枪（AI 同样如此；悍马除外，主炮对其 80% 殉爆）。\n                                 - **自行迫击炮**：无需架设即可开火，射程 8，中心 60%/周围 30%，\n                                   攻击力 1（打不穿装甲，专用于压制与反步兵），同样施加压制（护甲≥2免疫）；\n                                   与榴弹炮一样按 T 切换行动/射击模式（黄色格子炮击、悬停预览爆炸范围）。\n                                 - **隐蔽**：发现条件 = BFS 路程 ≤ 视野 ÷ 隐蔽值——步兵（隐蔽 2）需在\n                                   视野/2 内才能被发现（其它单位隐蔽 1 = 完整视野），与地形无关；\n                                   森林/楼房经 BFS 路程翻倍间接加剧隐蔽。\n                                 - **迷雾（两层灰）**：深灰=完全未侦察；浅灰=视野内但 > 视野/2 的\n                                   探测盲区（隐蔽 2 的步兵可能藏身）；内圈（≤ 视野/2）无雾。\n                                 - **对局日志**：顶栏「导出日志」把整局所有事件（含初始随机种子）\n                                   保存到 logs/ 目录，配合种子可完全复原对局，便于反馈与排查。\n                                 - **关卡**：部署面板可切换——开阔地遭遇战（双方各 100 点）；\n                                   村庄防守战（玩家 150 点进攻东边村庄，AI 240 点防守，\n                                   北面靠山、南西森林、两条林中小道通向西边出发地）。\n                                 - **可持续部署**：部署面板勾选开启（可设定双方每回合点数）。\n                                   开始后每回合在部署盈余上累计；对局中按 **D** 进入追加部署，\n                                   点击右侧单位再点击本方大本营区域放置（本回合不可行动）；\n                                   大本营中距敌军 ≤5 格的格子被占领不可部署。\n                                   **胜负**：摧毁敌方**指挥部**（开局随机设于敌方大本营，HP2，\n                                   星形兵牌；防空/反坦克导弹无法攻击它）即获胜——全灭不算数，\n                                   还可增援再战。追加部署只能放在指挥部周围 2 格内。\n                                   **AI**：逐个随机计划招募兵种（攒够点数才买）；歼灭点数 ≥\n                                   我方初始点数−10 时总攻搜索并摧毁指挥部；指挥部 8 格内\n                                   发现我军时转入全面防御（全力回防，优先于总攻）。\n                                 - 移动：一次行动最多移动「行动力」格（步兵行动力 1，每次移动只能动 1 格）。
                                 - **视图**：**鼠标滚轮**缩放地图（围绕指针位置），**按住右键拖动**平移地图；
                                   点击飞行单位（飞在陆军单位上方时）——点离空中兵牌近处选直升机、
                                   点离地面兵牌近处选陆军；单独在格上的飞行单位也可直接点选。\n                                 - 攻击：目标须在射程内且**已侦察**（视野共享）；投骰命中检定（随机数 < 命中率 即命中）；\n                                   命中 且 攻击力 >= 护甲 才造成 1 点伤害（血量即生命值），\n                                   否则攻击无效；**攻击力恰好等于护甲时，命中后 50% 概率被护甲抵挡（不掉血），\n                                   且先判主动防御、再判抵挡**。TOW射手攻击消耗 2 次行动，其余单位（含 Javelin射手/\n                                   重机枪手/悍马-重机枪）只耗 1 次。",
                            );
                        });
                    egui::CollapsingHeader::new("② 地形")
                        .default_open(true)
                        .show(ui, |ui| {
                            ui.label(
                                "- ▲ 岩石：不可通行，阻断移动与视线。\n                                 - ♣ 森林：进入消耗 2 点行动力（3 点行动力可走 2 格森林，\n                                   剩 1 点也能进入最后一格）；森林中地面单位被命中率 ×0.8。\n                                 - ▣ 楼房：仅步兵可进入；楼内步兵被命中率 ×0.6。\n                                 - ▬ 道路：车辆进入每格只消耗 0.5 行动力（非车辆仍 1 点/格；森林仍 2 点）；\n                                   不阻挡移动与视线。\n                                 - 直升机不受地形限制（可飞越一切，也无地形隐蔽）。",
                            );
                        });
                    egui::CollapsingHeader::new("③ 单位属性表")
                        .default_open(true)
                        .show(ui, |ui| {
                            use egui::Grid;
                            Grid::new("units")
                                .striped(true)
                                .min_col_width(58.0)
                                .show(ui, |ui| {
                                    for h in [
                                        "单位",
                                        "费用",
                                        "射程",
                                        "护甲",
                                        "攻击",
                                        "命中",
                                        "血",
                                        "行动",
                                        "移动",
                                        "视野",
                                        "弹药",
                                    ] {
                                        ui.label(egui::RichText::new(h).strong());
                                    }
                                    ui.end_row();
                                    let rows = [
                                        ("步枪手", "12", "2", "0", "1", "80%", "3", "3", "1", "4", "10"),
                                        ("TOW射手", "10", "9", "0", "4", "90%", "1", "2", "1", "4", "4"),
                                        ("Javelin射手", "10", "5", "0", "5", "90%", "1", "2", "1", "4", "4"),
                                        ("坦克", "24", "6", "3", "4", "90%", "2", "2", "3", "5", "42"),
                                        ("主战坦克", "32", "8", "4", "4", "100%", "2", "2", "3", "5", "42"),
                                        ("步兵战车", "12", "4", "2", "2", "80%", "2", "2", "3", "5", "30+2TOW"),
                                        ("卡车", "8", "0", "1", "0", "-", "1", "2", "4", "4", "0"),
                                        ("榴弹炮", "16", "16", "0", "2", "中心80%/周围50%", "1", "1", "0", "5", "24+4M864"),
                                        ("自行迫击炮", "10", "8", "2", "1", "中心60%/周围30%", "1", "2", "3", "5", "24"),
                                        ("武装直升机", "24", "6", "2", "4", "80%", "2", "2", "8", "9", "16"),
                                        ("运输直升机", "8", "0", "1", "0", "-", "1", "2", "10", "9", "0"),
                                        ("侦察无人机", "12", "4", "1", "4", "90%", "1", "2", "10", "12", "1"),
                                        ("特战小队", "18", "3", "0", "1", "80%", "2", "3", "1", "6", "10+4+1"),
                                        ("精锐步兵班组", "15", "2", "0", "1", "80%", "3", "3", "1", "4", "10+4M3E1"),
                                        ("防空步兵", "6", "8", "0", "2", "70%", "1", "2", "1", "4", "4"),
                                        ("M-SHORAD", "12", "4", "2", "2", "80%", "1", "2", "3", "5", "25+2弹"),
                                        ("防空导弹车", "14", "8", "1", "2", "70%", "1", "2", "3", "6", "8"),
                                        ("补给", "15", "0", "1", "0", "-", "1", "2", "0", "0", "5"),
                                    ];
                                    for (name, cost, rng, arm, atk, hit, hp, act, mov, vis, ammo) in rows {
                                        ui.label(name);
                                        ui.label(cost);
                                        ui.label(rng);
                                        ui.label(arm);
                                        ui.label(atk);
                                        ui.label(hit);
                                        ui.label(hp);
                                        ui.label(act);
                                        ui.label(mov);
                                        ui.label(vis);
                                        ui.label(ammo);
                                        ui.end_row();
                                    }
                                });
                            ui.label(
                                egui::RichText::new("※ 攻击力 ≥ 目标护甲才造成伤害：步兵/榴弹炮护甲 0、坦克护甲 3、主战坦克护甲 4。原攻击力 3 的武器现为 4，Javelin 武器为 5：步枪手（攻击 1）打不穿坦克；坦克与 TOW/Javelin射手（攻击 4/5）是击毁坦克的主力。防空单位只能打直升机。
※ 护甲抵挡：当攻击力**恰好等于**目标护甲时，命中后 50% 概率被护甲抵挡（命中但不掉血）。结算顺序为先主动防御、再护甲抵挡——即使逃过主动防御，仍可能被护甲挡下。\n※ 主战坦克：射程 8、命中 100%，拥有「主动防御」——每次被命中消耗 1 次抵消（同时攻击命中≥2发时随机抵消其中 1 发），共 8 次（主战坦克/装甲骑兵战车兵牌上以盾牌 ▲ 角标显示剩余次数）；AI 发现它时会先判断能否发动 ≥2 次袭击（含调兵），能则优先集火，不能则撤退/隐蔽。坦克炮不会被主动防御抵消。\n※ 坦克/主战坦克：按 M 切换车载重机枪（射程4/攻1/命中60%，弹药42，攻击步兵可造成压制）；主炮为坦克炮，攻击车辆命中时按目标殉爆概率造成 2 点伤害（主战坦克30%/一般坦克60%/步战·骑兵战车60%/其它护甲2 70%/护甲1 80%，步兵与空中单位不殉爆）。AI 会在机枪射程内有软目标（护甲<2）、且主炮射程内无装甲目标时自动切机枪压制。\n※ 重机枪手：攻击步兵基础 90% 概率造成压制（命中步兵 50% 概率造成 2 点伤害），与车载重机枪规则一致；重机枪可对空，但楼内需登屋顶才能对空。\n※ 悍马系列（悍马-重机枪/TOW/Javelin/Stinger）：血量2/护甲1/行动2/行动力4，武器由车内遥控操作；被机炮命中 40% 概率直接击毁，被坦克炮命中按护甲1殉爆 80%（不再直接击毁）；对步兵生效的压制规则对悍马同样生效。\n※ 悍马-重机枪：攻击属性同重机枪手但携弹 12 发（射程4/攻2/命中80%/攻击耗1行动/无需架设），可对空；悍马-TOW 同 TOW 射手但携 8 枚（射程9/攻4/命中90%/攻击耗2）；悍马-Javelin 同 Javelin 射手但携 8 枚（射程5/攻5/命中90%/攻击耗1）。\n※ M-SHORAD：按 M 切换——机枪模式（机关炮）射程4/命中80%/攻2（空/地都能打，25 发 23mm，攻击步兵可压制）；Stinger 导弹模式射程8/命中70%/攻2（只能打直升机，2 发）。\n※ 特战小队：三武器——步枪 / M3E1-HE 火箭筒（M 键：射程3 攻4，装甲/楼房命中100%，4 发）/ Stinger 防空导弹（A 键：射程8 攻2 只打直升机，1 发）；闪避×0.8（森林中×0.64），森林/楼房隐蔽值翻倍为 4。\n※ 精锐步兵班组：按 M 切 M3E1-HE 火箭筒（射程3 攻4，装甲/楼房命中100%，4 发）；步枪手按 M 切 M3E1-XM1176（射程3 攻3 命中100%，楼内目标强制击杀，4 发）；榴弹炮射击模式按 M 切 M864 子母弹（中心/周围100%，攻4，4 发）。\n※ Javelin/TOW 只能打车辆；步兵战车/装甲骑兵战车按 M 切换 TOW（分别 2/8 发，射程9/攻4/命中90%，只能打车辆）；防空 Stinger 射程 8；无人机/直升机视野可看穿楼房。\n※ 补给：15 费用，1 HP/1 甲，每回合 2 行动，行动力 0（不可主动移动/攻击），共携带 5 点弹药（最多补给 5 次）；仅卡车与重型运输直升机可载（占 2 点运力）。选中后按 S 进入补给模式，点击半径 2 格内友军补给——补给单位消耗 1 行动与 1 点弹药，被补给方消耗 1 行动并恢复全部弹药。
※ 大本营补给：任意己方棋子位于本方大本营据点（关键据点中心）半径 2 格内时，按 H 或点面板按钮即可消耗 1 行动补充全部弹药（无需补给单位）。")
                                    .weak(),
                            );
                        });
                    egui::CollapsingHeader::new("④ 搭载与直升机")
                        .default_open(false)
                        .show(ui, |ui| {
                            ui.label(
                                "- 步兵战车可搭载 1 名、卡车 3 名步兵；上车消耗载具 1 次行动、卸下不消耗；\n\
                                   上车须步兵紧邻载具，下车只能到紧邻空位；载具被击毁时车上步兵一同阵亡。\n\
                                  - **装载模式**：选中地面载具后按 **X** 进入（再按 X/Esc 退出）。\n\
                                   进入后点击紧邻（青绿高亮）的己方可搭载单位上车；该模式下**不能移动**。\n\
                                   未按 X 时点击步兵不会装载（只会选中该步兵），右侧面板的「搭载」按钮仍可直接装载。\n\
                                 - 运输直升机：从**正下方**载入/放下 1 名步兵（右侧面板按钮或按 B/D 相关按钮）：\n\
                                   载入需下方有己方步兵、双方均有行动次数（双方各耗 1 次行动）；\n\
                                   放下需下方无单位且非岩石（耗 1 次行动），**被放下的步兵本回合不能行动**。",
                            );
                        });
                    egui::CollapsingHeader::new("⑤ 榴弹炮双模式")
                        .default_open(false)
                        .show(ui, |ui| {
                            ui.label(
                                "默认**行动模式**（点击绿色格移动）；按 **T** 或面板按钮切到**开火模式**：\n\
                                 点击黄色格子炮击，波及中心+周围 6 格，每格独立判定（中心 70%/周围 40%），\n\
                                 范围内敌我双方都会被波及，注意别误伤友军！",
                            );
                        });
                    egui::CollapsingHeader::new("⑥ 操作与快捷键")
                        .default_open(true)
                        .show(ui, |ui| {
                            ui.label(
                                "- 左键：选中己方单位 / 移动 / 攻击；右键或 Esc：取消选择\n\
                                 - Tab / Shift+Tab：循环切单位\n\
                                 - X：地面载具装载模式（点击紧邻己方单位上车；此模式不能移动）；\n\
                                   选中运载直升机时按 X 直接装载正下方（同格）的己方单位\n\
                                 - S：选中补给单位时进入/退出补给模式（点击半径 2 格内友军补给）；\n\
                                   其余情况结束当前单位行动；Enter：结束回合；T：榴弹炮模式；F1/Esc：打开/关闭帮助\n\
                                 - H：在本方大本营据点半径 2 格内补给选中单位（消耗 1 行动，恢复全部弹药）\n\
                                 - R：直射测距器——先后点两格，查看距离 / 能否直射 / 命中率乘数\n\
                                 - F3：进入/退出试验放置棋子模式（需开局已开启试验模式）\n\
                                 - 鼠标滚轮缩放地图；按住右键拖动平移地图\n\
                                 - 绿色格子=可移动；红色=可攻击；灰色描边=射程内但打不到；\n\
                                   黄色（榴弹炮开火模式）=炮击目标，悬停可预览爆炸范围\n\
                                 - 「重新开始」「结束回合」需二次点击确认，防误触",
                            );
                        });
                    egui::CollapsingHeader::new("⑦ AI 提示")
                        .default_open(false)
                        .show(ui, |ui| {
                            ui.label(
                                "旧版 AI：每单位每回合至多攻击一次（优先射程内最近的、打得动的敌人），\n\
                                 其余行动用于推进；可用较近的单位吸引火力，掩护TOW/Javelin射手。\n\
                                 新版 AI（可切换）：按期望伤害/击杀概率、统一效用、量化威胁图决策，\n\
                                 会枚举「移动后射击」并优先利用掩体/规避威胁。\n\
                                 顶栏「🤖 AI：旧版/新版」按钮或开局部署面板可随时切换。",
                            );
                        });
                });
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    if ui.button("关闭").clicked() {
                        self.show_help = false;
                    }
                });
            });
    }

    fn game_over_window(&mut self, ctx: &egui::Context) {
        let Some(msg) = &self.game_over else {
            return;
        };
        let msg = msg.clone();
        egui::Window::new("对局结束")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .show(ctx, |ui| {
                ui.add_space(8.0);
                let col = if msg.contains('★') {
                    egui::Color32::from_rgb(140, 230, 150)
                } else if msg.contains('✗') {
                    egui::Color32::from_rgb(255, 120, 105)
                } else {
                    egui::Color32::from_rgb(230, 220, 180)
                };
                ui.label(egui::RichText::new(&msg).size(22.0).strong().color(col));
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if ui.button("再来一局").clicked() {
                        self.restart();
                    }
                    if ui.button("退出").clicked() {
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                });
            });
    }
}

/// 统一主题 visuals：面板/窗口/控件配色与圆角。
fn apply_theme(ctx: &egui::Context) {
    let mut v = egui::Visuals::dark();
    v.panel_fill = egui::Color32::from_rgb(29, 33, 30);
    v.window_fill = egui::Color32::from_rgb(35, 40, 36);
    v.extreme_bg_color = egui::Color32::from_rgb(18, 22, 20);
    v.faint_bg_color = egui::Color32::from_rgba_unmultiplied_const(255, 255, 255, 10);
    v.widgets.noninteractive.bg_fill = egui::Color32::from_rgb(40, 46, 42);
    v.widgets.noninteractive.fg_stroke =
        egui::Stroke::new(1.0, egui::Color32::from_rgb(205, 214, 205));
    v.widgets.noninteractive.corner_radius = egui::CornerRadius::same(5);
    v.widgets.inactive.bg_fill = egui::Color32::from_rgb(52, 60, 54);
    v.widgets.inactive.bg_stroke = egui::Stroke::new(1.0, egui::Color32::from_rgb(80, 92, 82));
    v.widgets.inactive.fg_stroke =
        egui::Stroke::new(1.0, egui::Color32::from_rgb(224, 232, 224));
    v.widgets.inactive.corner_radius = egui::CornerRadius::same(5);
    v.widgets.hovered.bg_fill = egui::Color32::from_rgb(66, 78, 68);
    v.widgets.hovered.bg_stroke = egui::Stroke::new(1.0, egui::Color32::from_rgb(112, 132, 112));
    v.widgets.active.bg_fill = egui::Color32::from_rgb(80, 96, 82);
    v.selection.bg_fill = egui::Color32::from_rgb(70, 110, 140);
    ctx.set_visuals(v);
    ctx.style_mut_of(ctx.theme(), |s| {
        s.spacing.item_spacing.y = 5.0;
    });
}

/// 为 egui 安装中文字体（从常见系统字体路径加载）。
fn install_cjk_fonts(ctx: &egui::Context) {
    let candidates = [
        // Linux
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
        "/usr/share/fonts/truetype/arphic/uming.ttc",
        "/usr/share/fonts/truetype/arphic/ukai.ttc",
        "/usr/share/fonts/wps-office/HYZYB5.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf",
        "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
        // Windows
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/msyh.ttf",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc",
        "C:/Windows/Fonts/Deng.ttf",
        // macOS
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
    ];
    for path in candidates {
        if let Ok(bytes) = std::fs::read(path) {
            let mut fonts = egui::FontDefinitions::default();
            let mut data = egui::FontData::from_owned(bytes);
            data.index = 0; // 取字体集合中的第一个字形
            fonts
                .font_data
                .insert("cjk".to_owned(), Arc::new(data));
            for family in [
                egui::FontFamily::Proportional,
                egui::FontFamily::Monospace,
            ] {
                fonts
                    .families
                    .get_mut(&family)
                    .unwrap()
                    .insert(0, "cjk".to_owned());
            }
            ctx.set_fonts(fonts);
            return;
        }
    }
    eprintln!("警告: 未找到系统中文字体，界面中文可能无法正常显示。");
}

/// 选中单位的高亮集合。
struct Highlights {
    reachable: Vec<Hex>,        // 可移动格（绿）
    attackable: Vec<Hex>,       // 可攻击格（红）
    blocked: Vec<Hex>,          // 射程内但打不到（灰）
    howitzer_targets: Vec<Hex>, // 榴弹炮可炮击点（黄）
    disembark_targets: Vec<Hex>, // 待放下时的合法落点（青）
    board_targets: Vec<Hex>,    // 装载模式：可点击上车的紧邻己方单位（青绿）
}
impl GuiApp {
    /// 全局键盘快捷键。
    fn handle_keys(&mut self, ui: &egui::Ui) {
        let game_over = self.game_over.is_some();
        // 帮助窗口打开时：按 Esc 或 F1 关闭，其他按键不再触发游戏操作。
        if self.show_help {
            if ui.input(|i| i.key_pressed(egui::Key::Escape))
                || ui.input(|i| i.key_pressed(egui::Key::F1))
            {
                self.show_help = false;
            }
            return;
        }
        // AI 回合（后台思考或播放其行动）期间屏蔽玩家快捷键。
        if self.ai_busy() {
            return;
        }
        // 试验模式：只能在开局部署阶段通过按钮开启；对局中 F3 仅用于进出放置棋子模式。
        if self.game.test_mode && ui.input(|i| i.key_pressed(egui::Key::F3)) {
            self.toggle_test_placing();
        }
        if self.game.test_placing {
            if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                self.toggle_test_placing();
            }
            return;
        }
        // 部署阶段：只支持 F1 帮助 与 Esc（取消待放置选择）
        if self.game.deploying {
            if ui.input(|i| i.key_pressed(egui::Key::F1)) {
                self.show_help = !self.show_help;
            }
            if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                self.pending_recruit = None;
            }
            return;
        }
        // 可持续部署：D 键进入/退出追加部署模式（sustain 模式下 D 不再用于选中 D 单位）
        // 多人模式下本地控制的阵营同样可以按 D 进入追加部署（纯观战时不可用）。
        if self.game.sustain
            && (!self.multiplayer || self.gui_control_team().is_some())
            && !self.simul_mode
            && ui.input(|i| i.key_pressed(egui::Key::D))
            && !game_over
        {
            self.toggle_sustain_deploy();
            return;
        }
        if self.game.sustain_deploying {
            if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                self.game.sustain_deploying = false;
                self.pending_recruit = None;
                self.log("退出追加部署".into());
            }
            return;
        }
        // 按 T 切换榴弹炮行动/开火模式
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::T)) && !game_over {
            self.toggle_howitzer_mode();
        }
        // 按 R 切换直射测距器模式：不可点选棋子，先后点两格查看距离/直射/命中率乘数
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::R)) && !game_over {
            self.ranger_mode = !self.ranger_mode;
            self.ranger_first = None;
            self.ranger_last = None;
            if self.ranger_mode {
                self.selected = None;
                self.selected_is_air = true;
                self.log("测距器开启：点击第一格作为起点（再按 R 或 Esc 退出）".into());
            } else {
                self.log("测距器关闭".into());
            }
        }
        if self.ranger_mode {
            if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                self.ranger_mode = false;
                self.ranger_first = None;
                self.ranger_last = None;
                self.log("测距器关闭".into());
            }
            return; // 测距模式下不响应其他快捷键
        }
        // X：选中有运载能力的直升机 → 装载正下方友军；否则进入/退出地面载具装载模式
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::X)) && !game_over {
            let air_carrier = self
                .selected
                .and_then(|h| self.game.unit_at(h))
                .map(|u| u.kind.is_air() && u.kind.capacity() > 0)
                .unwrap_or(false);
            if air_carrier {
                if let Some(sel) = self.selected {
                    match self.game.heli_board(sel) {
                        Ok(()) => {
                            let heli = self
                                .game
                                .air_units
                                .get(&sel)
                                .map(|h| h.name_with_label())
                                .unwrap_or_default();
                            let p = self
                                .game
                                .air_units
                                .get(&sel)
                                .and_then(|h| h.passengers.last())
                                .map(|p| p.name_with_label())
                                .unwrap_or_default();
                            self.log(format!("{} 载入正下方 {}", heli, p));
                        }
                        Err(e) => self.log(format!("⚠ {}", e)),
                    }
                    self.after_action();
                }
            } else {
                self.toggle_load_mode();
            }
        }
        // U：进入/退出同时攻击模式
        if ui.input(|i| i.key_pressed(egui::Key::U)) && !game_over {
            self.toggle_simul_mode();
        }
        if self.simul_mode {
            // C：确认同时攻击并统一结算
            if ui.input(|i| i.key_pressed(egui::Key::C)) && !game_over {
                self.confirm_simul_attack();
                return;
            }
            if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                self.toggle_simul_mode();
                return;
            }
        }

        // 按 M 切换副武器模式（同时攻击模式下禁用，避免改变已下达命令的武器快照）
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::M)) && !game_over {
            if let Some(sel) = self.selected {
                match self.game.toggle_missile_mode(sel) {
                    Ok(()) => {
                        self.log(format!(
                            "{}切换到{}",
                            self.game.unit_at(sel).map(|u| u.name_with_label()).unwrap_or_default(),
                            self.game.unit_at(sel).map(|u| u.mode_name()).unwrap_or("")
                        ));
                    }
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
            }
        }
        // 按 A 切换第三武器模式（同时攻击模式下禁用，避免改变已下达命令的武器快照）
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::A)) && !game_over {
            if let Some(sel) = self.selected {
                match self.game.toggle_aa_mode(sel) {
                    Ok(()) => {
                        self.log(format!(
                            "{}切换到{}",
                            self.game.unit_at(sel).map(|u| u.name_with_label()).unwrap_or_default(),
                            self.game.unit_at(sel).map(|u| u.mode_name()).unwrap_or("")
                        ));
                    }
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
            }
        }
        // Esc：分层取消 —— 先取消放下等待 → 再取消烟雾弹 → 再退出开火模式 → 再取消选择
        if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
            if self.pending_disembark.take().is_some() {
                self.log("已取消放下".into());
            } else if self.supply_mode {
                self.supply_mode = false;
                self.log("已退出补给模式".into());
            } else if self.load_mode {
                self.load_mode = false;
                self.log("已退出装载模式".into());
            } else if self.smoke_shot_pending {
                self.smoke_shot_pending = false;
                self.log("已取消烟雾弹发射".into());
            } else if self.howitzer_fire_mode {
                self.toggle_howitzer_mode();
            } else if self.selected.is_some() {
                self.selected = None;
                self.selected_is_air = true;
                self.zero_hint = None;
            }
        }
        // Enter：结束回合（同时攻击模式下先确认/退出，避免丢命令）
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::Enter)) && !game_over {
            if self.multiplayer {
                let active = self.game.phase;
                if self.gui_control_team() == Some(active) {
                    self.end_turn_for(active);
                }
            } else {
                self.end_player_turn();
            }
        }
        // S：选中补给单位时进入/退出补给模式；否则结束当前单位行动
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::S)) && !game_over {
            let is_supply = self
                .selected
                .and_then(|h| self.game.unit_at(h))
                .map(|u| u.kind == UnitKind::Supply)
                .unwrap_or(false);
            if is_supply {
                self.toggle_supply_mode();
            } else {
                self.pass_unit();
            }
        }
        // H：在己方大本营据点半径 2 格内补给选中单位（消耗 1 行动，恢复全部弹药）
        if !self.simul_mode && ui.input(|i| i.key_pressed(egui::Key::H)) && !game_over {
            if let Some(sel) = self.selected {
                let me = if self.multiplayer {
                    self.gui_control_team().unwrap_or(self.game.phase)
                } else {
                    Team::Player
                };
                match self.game.resupply_at_hq(me, sel) {
                    Ok(m) => self.log(format!("🏛 {}", m)),
                    Err(e) => self.log(format!("⚠ {}", e)),
                }
                self.after_action();
            }
        }
        // F1：帮助
        if ui.input(|i| i.key_pressed(egui::Key::F1)) {
            self.show_help = !self.show_help;
        }
        // Tab / Shift+Tab：循环选中还有行动的己方单位
        if !game_over && ui.input(|i| i.key_pressed(egui::Key::Tab)) {
            let reverse = ui.input(|i| i.modifiers.shift);
            let tab_team = if self.multiplayer {
                match self.gui_control_team() {
                    Some(t) => t,
                    None => return,
                }
            } else {
                Team::Player
            };
            let units: Vec<&hex_wargame::unit::Unit> = self
                .game
                .units_of(tab_team)
                .into_iter()
                .filter(|u| u.actions_left > 0)
                .collect();
            if !units.is_empty() {
                let idx = self
                    .selected
                    .and_then(|sel| {
                        units.iter().position(|u| u.pos == sel && u.actions_left > 0)
                    })
                    .unwrap_or(0);
                let next = if reverse {
                    (idx + units.len() - 1) % units.len()
                } else {
                    (idx + 1) % units.len()
                };
                let u = units[next];
                self.selected = Some(u.pos);
                self.selected_is_air = u.kind.is_air();
                self.load_mode = false;
                self.zero_hint = None;
            }
        }
    }

    /// 把当前界面设置应用到对局（部署阶段调用；修改设置后需重新开局）。
    fn apply_sustain_settings(&mut self) {
        self.game.sustain = self.sustain_mode;
        if self.sustain_mode {
            self.game.enable_sustain(self.sustain_pp, self.sustain_ap);
        } else {
            self.game.sustain_per_turn.clear();
        }
    }

    /// 进入/退出"追加部署"模式（对局中按 D 或点侧栏按钮）。
    fn toggle_sustain_deploy(&mut self) {
        if !self.game.sustain {
            self.log("⚠ 当前未启用可持续部署模式（部署阶段勾选开启）".into());
            return;
        }
        self.game.sustain_deploying = !self.game.sustain_deploying;
        self.pending_recruit = None;
        self.selected = None;
        if self.game.sustain_deploying {
            let first = self.game.recruit_zone_turn > 0
                && self.game.turn <= self.game.recruit_zone_turn;
            self.log(if first {
                "进入招募：点击右侧单位，再点击本方出发区域任意空格（本回合即可行动，按 D/Esc 退出）"
                    .to_string()
            } else {
                "进入追加部署：点击右侧单位，再点击己方大本营周围 2 格放置（本回合不可行动，按 D/Esc 退出）"
                    .to_string()
            });
        } else {
            self.log("退出追加部署".into());
        }
    }

    /// 从开局部署阶段立即进入试验模式。
    fn enter_test_mode(&mut self) {
        if !self.game.deploying {
            self.log("⚠ 试验模式只能在开局部署阶段进入".into());
            return;
        }
        self.game.enter_test_mode();
        self.pending_recruit = None;
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.simul_mode = false;
        self.simul_orders.clear();
        self.ranger_mode = false;
        self.ranger_first = None;
        self.ranger_last = None;
        self.howitzer_fire_mode = false;
        self.smoke_shot_pending = false;
        self.pending_disembark = None;
    }

    /// 进入/退出试验放置棋子模式。
    fn toggle_test_placing(&mut self) {
        if !self.game.test_mode {
            self.log("⚠ 请先在开局部署面板开启试验模式".into());
            return;
        }
        self.game.test_placing = !self.game.test_placing;
        self.pending_recruit = None;
        if self.game.test_placing {
            // 试验放置优先，退出其他可能冲突的界面状态
            self.game.sustain_deploying = false;
            self.simul_mode = false;
            self.simul_orders.clear();
            self.ranger_mode = false;
            self.ranger_first = None;
            self.ranger_last = None;
            self.howitzer_fire_mode = false;
            self.smoke_shot_pending = false;
            self.pending_disembark = None;
            self.selected = None;
            self.log("进入试验放置：选择阵营和单位，再点击地图空位放置（不扣点数；地面单位不可上岩石/水域，车辆不可进楼房；F3/Esc 退出）".into());
        } else {
            self.log("退出试验放置".into());
        }
    }

    /// 招募/部署面板的「初始搭载」编辑区：当所选兵种为运输单位时显示，
    /// 可在运力与兵种规则允许的范围内预先装入货物，一次性招募已装载的运输单位。
    fn cargo_panel(&mut self, ui: &mut egui::Ui, pts: i32) {
        let Some(kind) = self.pending_recruit else {
            return;
        };
        if kind.capacity() == 0 {
            return;
        }
        ui.separator();
        ui.label(egui::RichText::new("初始搭载（可选，按重量计费）").strong());
        let used: i32 = self.pending_cargo.iter().map(|k| k.cargo_weight()).sum();
        let choices: Vec<UnitKind> = UnitKind::all_recruitable()
            .iter()
            .copied()
            .filter(|c| c.can_be_cargo() && kind.can_load_cargo(*c))
            .collect();
        ui.horizontal(|ui| {
            ui.label("货物:");
            egui::ComboBox::from_id_salt("pending_cargo_kind")
                .selected_text(self.pending_cargo_kind.name())
                .width(130.0)
                .show_ui(ui, |ui| {
                    for c in &choices {
                        ui.selectable_value(&mut self.pending_cargo_kind, *c, c.name());
                    }
                });
            let can_add = kind.can_load_cargo(self.pending_cargo_kind)
                && used + self.pending_cargo_kind.cargo_weight() <= kind.capacity();
            if ui
                .add_enabled(can_add, egui::Button::new("添加"))
                .clicked()
            {
                self.pending_cargo.push(self.pending_cargo_kind);
            }
            if ui
                .add_enabled(!self.pending_cargo.is_empty(), egui::Button::new("清空"))
                .clicked()
            {
                self.pending_cargo.clear();
            }
        });
        if !self.pending_cargo.is_empty() {
            let names: Vec<&str> = self.pending_cargo.iter().map(|k| k.name()).collect();
            ui.label(format!(
                "已搭载：{}（{}/{} 重量）",
                names.join("、"),
                used,
                kind.capacity()
            ));
        }
        match kind.loaded_recruit_cost(&self.pending_cargo) {
            Ok(total) if total <= pts => {
                ui.colored_label(
                    egui::Color32::from_rgb(150, 210, 150),
                    format!("总费用 {} 点（含货物）", total),
                );
            }
            Ok(total) => {
                ui.colored_label(
                    egui::Color32::from_rgb(240, 200, 120),
                    format!("总费用 {} 点 · 点数不足", total),
                );
            }
            Err(e) => {
                ui.colored_label(egui::Color32::from_rgb(240, 140, 120), format!("⚠ {}", e));
            }
        }
    }

    /// 招募面板（对局中按 D 进入）：显示可用点数、当前招募区域与可招募单位。
    fn reinforce_panel(&mut self, ui: &mut egui::Ui) {
        let team = self.side_team();
        let pts = self
            .game
            .recruit_points
            .get(&team)
            .copied()
            .unwrap_or(0);
        let first_round = self.game.recruit_zone_turn > 0
            && self.game.turn <= self.game.recruit_zone_turn;
        ui.heading(egui::RichText::new(format!(
            "🛠 {} · {} · 剩余 {} 点",
            if first_round { "招募" } else { "追加部署" },
            mp::team_label(team),
            pts
        ))
        .color(theme::ACCENT));
        let hint = if first_round {
            format!(
                "第 {} 回合：点击单位后点击本方出发区域（{} 列）任意空格招募，本回合即可行动；第 {} 回合起改为在大本营周围 2 格内放置。",
                self.game.turn.max(1),
                mp::deploy_zone_label(&self.game, team),
                self.game.recruit_zone_turn + 1
            )
        } else {
            "点击单位招募，再点击己方大本营区域放置；本回合放置的单位下回合才可行动。大本营中距敌军 ≤5 格的格子不可部署。"
                .to_string()
        };
        ui.label(egui::RichText::new(hint).weak().size(12.0));
        if ui.button("✅ 完成招募/追加部署（D）").clicked() {
            self.game.sustain_deploying = false;
            self.pending_recruit = None;
        }
        ui.separator();
        let all = [
            UnitKind::Rifleman,
            UnitKind::Scout,
            UnitKind::Atgm,
            UnitKind::Javelin,
            UnitKind::SpecialForces,
            UnitKind::EliteInfantry,
            UnitKind::Tank,
            UnitKind::HeavyTank,
            UnitKind::Ifv,
            UnitKind::CavalryIfv,
            UnitKind::HumveeHmg,
            UnitKind::HumveeTow,
            UnitKind::HumveeJavelin,
            UnitKind::Truck,
            UnitKind::Howitzer,
            UnitKind::Mortar,
            UnitKind::AttackHeli,
            UnitKind::TransportHeli,
            UnitKind::HeavyTransportHeli,
            UnitKind::Drone,
            UnitKind::AaInfantry,
            UnitKind::HmgGunner,
            UnitKind::AaMgv,
            UnitKind::AaLauncher,
            UnitKind::Supply,
        ];
        for kind in all.iter() {
            let cost = kind.recruit_cost();
            let afford = cost <= pts;
            let selected = self.pending_recruit == Some(*kind);
            let txt = format!("{} · {} 点", kind.name(), cost);
            let btn = ui.add_enabled(
                afford,
                egui::Button::new(if selected {
                    format!("▶ {}（放置中）", txt)
                } else {
                    format!("  {}", txt)
                })
                .min_size(egui::vec2(ui.available_width(), 0.0)),
            );
            if btn.clicked() {
                if self.pending_recruit != Some(*kind) {
                    self.pending_cargo.clear();
                }
                self.pending_recruit = Some(*kind);
            }
            btn.on_hover_text(if afford {
                format!(
                    "射程{} 攻击{} 命中{}% 行动力{} 视野{} 弹药{}",
                    kind.range(),
                    kind.attack(),
                    kind.hit_rate(),
                    kind.movement(),
                    kind.vision(),
                    kind.max_ammo()
                )
            } else {
                "部署点数不足".into()
            });
        }
        self.cargo_panel(ui, pts);
    }

    /// 试验放置面板：免费选择要放置的兵种。
    fn test_place_panel(&mut self, ui: &mut egui::Ui) {
        ui.label(
            egui::RichText::new(format!(
                "当前放置阵营：{}；点击下方兵种后，再点击地图空位放置（免费）。",
                self.game.test_place_team.cn()
            ))
            .weak()
            .size(12.0),
        );
        ui.separator();
        let all = [
            UnitKind::Rifleman,
            UnitKind::Scout,
            UnitKind::Atgm,
            UnitKind::Javelin,
            UnitKind::SpecialForces,
            UnitKind::EliteInfantry,
            UnitKind::Tank,
            UnitKind::HeavyTank,
            UnitKind::Ifv,
            UnitKind::CavalryIfv,
            UnitKind::HumveeHmg,
            UnitKind::HumveeTow,
            UnitKind::HumveeJavelin,
            UnitKind::Truck,
            UnitKind::Howitzer,
            UnitKind::Mortar,
            UnitKind::AttackHeli,
            UnitKind::TransportHeli,
            UnitKind::HeavyTransportHeli,
            UnitKind::Drone,
            UnitKind::AaInfantry,
            UnitKind::HmgGunner,
            UnitKind::AaMgv,
            UnitKind::AaLauncher,
            UnitKind::Supply,
        ];
        for kind in all.iter() {
            let selected = self.pending_recruit == Some(*kind);
            let txt = format!("{} · 免费", kind.name());
            let btn = ui.add(
                egui::Button::new(if selected {
                    format!("▶ {}（放置中）", txt)
                } else {
                    format!("  {}", txt)
                })
                .min_size(egui::vec2(ui.available_width(), 0.0)),
            );
            if btn.clicked() {
                if self.pending_recruit != Some(*kind) {
                    self.pending_cargo.clear();
                }
                self.pending_recruit = Some(*kind);
            }
            btn.on_hover_text(format!(
                "射程{} 攻击{} 命中{}% 行动力{} 视野{} 弹药{}",
                kind.range(),
                kind.attack(),
                kind.hit_rate(),
                kind.movement(),
                kind.vision(),
                kind.max_ammo()
            ));
        }
    }

    fn toggle_simul_mode(&mut self) {
        if self.game.deploying || self.game_over.is_some() {
            return;
        }
        self.simul_mode = !self.simul_mode;
        if self.simul_mode {
            self.selected = None;
            self.selected_is_air = true;
            self.zero_hint = None;
            self.howitzer_fire_mode = false;
            self.smoke_shot_pending = false;
            self.pending_disembark = None;
            self.ranger_mode = false;
            self.ranger_first = None;
            self.ranger_last = None;
            self.log("⚔ 同时攻击模式：依次点击你的单位，再点击红色敌人下达攻击命令；按 C 或右侧按钮统一结算（榴弹炮/迫击炮可点击射程内格子作为炮击中心）".into());
        } else {
            self.simul_orders.clear();
            self.log("已退出同时攻击模式，已下达命令已清空".into());
        }
    }

    /// 在同时攻击模式下为当前选中单位下达/替换一条攻击命令。
    fn queue_simul_attack(&mut self, attacker_h: Hex, target_h: Hex, air_first: bool) {
        if attacker_h == target_h {
            self.log("⚠ 不能攻击自己所在格".into());
            return;
        }
        let Some(au) = self.selected_unit().cloned() else {
            self.log("⚠ 请先选择己方单位".into());
            return;
        };
        let order = SimulOrder {
            attacker: attacker_h,
            target: target_h,
            air_first,
            aa_mode: au.aa_mode,
            missile_mode: au.missile_mode,
        };
        match self.game.validate_simul_order(order) {
            Ok(()) => {
                if let Some(i) = self
                    .simul_orders
                    .iter()
                    .position(|o| o.attacker == attacker_h && o.air_first == air_first)
                {
                    let old = self.simul_orders[i];
                    self.simul_orders[i] = order;
                    self.log(format!(
                        "🔄 替换 {} 的攻击命令：{} → {}",
                        self.game.unit_at(attacker_h).map(|u| u.name_with_label()).unwrap_or_default(),
                        hex::hex_label(old.target),
                        hex::hex_label(target_h)
                    ));
                } else {
                    self.simul_orders.push(order);
                    self.log(format!(
                        "📋 已加入同时攻击：{} → {}",
                        self.game.unit_at(attacker_h).map(|u| u.name_with_label()).unwrap_or_default(),
                        hex::hex_label(target_h)
                    ));
                }
            }
            Err(e) => self.log(format!("⚠ {}", e)),
        }
    }

    /// 确认并结算所有已下达的同时攻击命令。
    fn confirm_simul_attack(&mut self) {
        if self.simul_orders.is_empty() {
            self.log("⚠ 还没有同时攻击命令：先点击你的单位，再点击敌方目标".into());
            return;
        }
        let orders = self.simul_orders.clone();
        match self.game.simultaneous_attack(&orders) {
            Ok(outcomes) => {
                for out in outcomes {
                    self.log(out.message);
                }
                self.simul_orders.clear();
                self.simul_mode = false;
                self.selected = None;
                self.selected_is_air = true;
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return;
                }
                self.after_action();
            }
            Err(e) => self.log(format!("⚠ 同时攻击结算失败：{}", e)),
        }
    }

    fn toggle_howitzer_mode(&mut self) {
        // 仅当前 GUI 可控的榴弹炮/自行迫击炮可切换射击模式
        let Some(me) = self.gui_control_team() else {
            return;
        };
        let sel_is_arty = self
            .selected
            .and_then(|sel| self.game.unit_at(sel))
            .map(|u| u.team == me && (u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar))
            .unwrap_or(false);
        if !sel_is_arty {
            self.log("⚠ 只有己方榴弹炮/自行迫击炮能切换射击模式".into());
            return;
        }
        self.howitzer_fire_mode = !self.howitzer_fire_mode;
        self.log(format!(
            "炮兵模式：{}（{}）",
            if self.howitzer_fire_mode {
                "射击模式"
            } else {
                "行动模式"
            },
            if self.howitzer_fire_mode {
                "点击射程内黄色格子炮击，悬停预览爆炸范围"
            } else {
                "点击绿色格子移动"
            }
        ));
    }
}

// eframe::App 实现（egui 0.36：App 提供根 Ui 与 ui() 方法）
impl eframe::App for GuiApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.time = ui.input(|i| i.time);
        // AI 回合异步：先看后台算完没有；算完则播放其行动，播完再交还玩家回合。
        self.poll_ai_thread();
        self.finalize_ai_turn();
        if self.multiplayer {
            self.process_net();
        }
        // 每帧重算「当前视角方」的视野，并记录它看到的敌方单位最后已知位置。
        // 单人模式视角方 = 蓝方；多人 `--view acting` = 当前行动方；
        // 只有 `--view spectator`（历史行为）才是全视野观战窗口。
        if self.multiplayer && self.view_mode == mp::ViewMode::Spectator {
            self.set_full_vision();
        } else {
            let viewer = self.view_team();
            let vis = self.game.vision(viewer);
            self.revealed = vis.terrain;
            self.visible_enemies = vis.enemy_units;
            self.dist_map = vis.dist;
            self.refresh_ghosts(viewer);
        }
        // 已阵亡的单位不保留幽灵标记（幽灵只表示「离开视野」而非「死亡」）
        for h in self.game.killed_hexes.drain(..) {
            for slot in self.ghosts.values_mut() {
                slot.remove(&h);
            }
        }
        // 幽灵（灰雾图标）只保留 2 回合
        let turn = self.game.turn;
        for slot in self.ghosts.values_mut() {
            slot.retain(|_, (_, t)| turn - *t < 2);
        }
        if self.multiplayer && self.view_mode == mp::ViewMode::Acting {
            self.sync_view_title(ui.ctx());
        }
        self.game.prune_fog_fire_marks();
        self.handle_keys(ui);
        self.top_panel(ui);
        self.bottom_log(ui);
        self.side_panel(ui);
        egui::CentralPanel::default().show(ui, |ui| {
            self.draw_map(ui);
        });
        self.help_window(ui.ctx());
        self.game_over_window(ui.ctx());
        if self.multiplayer {
            // 新战报事件同样需要推送（被击毁方要立刻收到自己的战损）
            if self.game.battle_seq != self.net_event_seq {
                self.net_dirty = true;
            }
            if self.net_dirty {
                self.broadcast_net_states();
            }
            self.auto_export_log();
            self.sync_spectator_state();
        }
        if self.game_over.is_some() {
            ui.ctx().request_repaint();
        }
    }
}

// ---------- GUI 交互逻辑测试（不依赖真实窗口，直接驱动 handle_click） ----------
#[cfg(test)]
mod tests {
    use super::*;
    use hex_wargame::game::GameState;
    use hex_wargame::hex;
    use hex_wargame::unit::{Team, Unit, UnitKind};

    fn test_app(game: GameState) -> GuiApp {
        GuiApp {
            game,
            selected: None,
            log: Vec::new(),
            log_hover: None,
            game_over: None,
            show_help: false,
            pending_disembark: None,
            load_mode: false,
            supply_mode: false,
            howitzer_fire_mode: false,
            confirm_action: None,
            last_error: None,
            zero_hint: None,
            selected_is_air: true,
            time: 0.0,
            revealed: BTreeSet::new(),
            visible_enemies: BTreeSet::new(),
            ghosts: HashMap::new(),
            pending_recruit: None,
            pending_cargo: Vec::new(),
            pending_cargo_kind: UnitKind::Rifleman,
            smoke_shot_pending: false,
            level: Level::OpenField,
            panel_expanded: true,
            zoom: 1.0,
            pan: egui::Vec2::ZERO,
            ranger_mode: false,
            ranger_first: None,
            ranger_last: None,
            simul_mode: false,
            simul_orders: Vec::new(),
            dist_map: HashMap::new(),
            sustain_mode: true, // 默认勾选持续部署
            sustain_pp: 10,
            sustain_ap: 20,
            custom_map: None,
            poses: HashMap::new(),
            move_anims: Vec::new(),
            fire_anims: Vec::new(),
            pending_deaths: Vec::new(),
            effects: Vec::new(),
            corpses: Vec::new(),
            wrecks: Vec::new(),
            smokers: Vec::new(),
            fx_clock: 0.0,
            map_origin: egui::pos2(0.0, 0.0),
            map_hs: 26.0,
            map_s: 1.0,
            fx_demo_pending: false,
            map_layer: None,
            multiplayer: false,
            local_control: mp::LocalControl::Blue,
            net: None,
            net_sessions: HashMap::new(),
            net_dirty: false,
            net_event_seq: 0,
            auto_log_done: false,
            state_file: None,
            state_sig: None,
            view_mode: mp::ViewMode::Spectator,
            last_title: None,
            ai_thread: None,
            ai_think_start: None,
            ai_think_elapsed: None,
            ai_playback: false,
        }
    }

    /// 战斗动画管线：攻击事件入队 → 离膛生成弹药 → 落地生成尸体/残骸 → 移动朝向。
    #[test]
    fn combat_animation_pipeline() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        let a = hex::axial_from_offset(8, 4);
        let b = hex::axial_from_offset(9, 4);
        let mut tank = Unit::new(UnitKind::Tank, Team::Player, a);
        tank.label = 'A';
        let mut rifle = Unit::new(UnitKind::Rifleman, Team::Ai, b);
        rifle.label = '1';
        g.units.insert(a, tank);
        g.units.insert(b, rifle);
        let mut app = test_app(g);
        app.map_origin = egui::pos2(200.0, 200.0);
        app.map_hs = 26.0;
        app.map_s = 1.0;
        app.time = 100.0;

        // 1) 攻击 → 事件记录 → 开火动画入队，炮塔转向目标
        app.game.attack(a, b).expect("坦克应能攻击相邻步枪手");
        assert!(
            app.game.ui_events.iter().any(|e| matches!(e, UiEvent::Fire(_))),
            "攻击应记录动画事件"
        );
        app.drain_ui_events();
        assert!(!app.fire_anims.is_empty(), "开火事件应生成开火动画");
        let pose = app.poses.get(&(Team::Player, 'A')).copied().unwrap();
        assert!(
            pose.turret.abs() < 0.01,
            "坦克炮塔应转向东侧目标，实际 {}",
            pose.turret
        );
        let launch = app.fire_anims[0].launch;
        // 2) 时间推进到离膛：生成炮口火光与弹药特效
        app.time = launch + 0.01;
        app.update_fx();
        assert!(!app.effects.is_empty(), "离膛后应生成弹药/火光特效");
        // 3) 时间推进到落地：特效正常结算（命中随机，不 panic 即可）
        app.time = launch + app.fire_anims[0].flight + 0.05;
        app.update_fx();
        // 清掉随机命中产生的残留，便于后续手工构造落地后果
        app.corpses.clear();
        app.wrecks.clear();
        app.smokers.clear();
        // 4) 手工落地后果：击毁载具 → 残骸
        let base = fx::Landing {
            pos: egui::pos2(0.0, 0.0),
            impact: None,
            smoke_shell: false,
            blast: Vec::new(),
            kills: Vec::new(),
        };
        let l = fx::Landing {
            impact: Some(fx::Impact {
                killed: true,
                blocked: false,
                target_kind: UnitKind::Tank,
                target_team: Team::Ai,
                target_label: '1',
                target_hex: b,
                target_hp_before: 1,
                dmg: 1,
            }),
            ..base.clone()
        };
        let mut sink = Vec::new();
        app.spawn_landing(&mut sink, l);
        assert_eq!(app.wrecks.len(), 1, "击毁载具应生成残骸");
        assert!(!sink.is_empty(), "击毁应伴随爆炸特效");
        // 5) 击毁满编步枪手 → 全体士兵（12 人）变灰尸体
        let l2 = fx::Landing {
            impact: Some(fx::Impact {
                killed: true,
                blocked: false,
                target_kind: UnitKind::Rifleman,
                target_team: Team::Ai,
                target_label: '2',
                target_hex: b,
                target_hp_before: 3,
                dmg: 3,
            }),
            ..base.clone()
        };
        app.spawn_landing(&mut sink, l2);
        assert_eq!(app.corpses.len(), 1, "击毁步兵应生成尸体");
        assert_eq!(app.corpses[0].slots.len(), 12, "满编步枪手 12 具尸体");
        // 6) 步兵受击未死（3→1）：部分士兵变灰
        let l3 = fx::Landing {
            impact: Some(fx::Impact {
                killed: false,
                blocked: false,
                target_kind: UnitKind::Rifleman,
                target_team: Team::Player,
                target_label: 'B',
                target_hex: a,
                target_hp_before: 3,
                dmg: 2,
            }),
            ..base.clone()
        };
        app.spawn_landing(&mut sink, l3);
        assert_eq!(app.corpses.len(), 2);
        assert_eq!(app.corpses[1].slots.len(), 8, "损失 2 HP = 8 名士兵阵亡");
        // 7) 移动事件 → 移动动画 + 车身朝向 = 路径倒数第二格 → 终点方向
        // （此前坦克已开过火：移动后车身转向南方 60°，炮塔保持最后一次开火方向）
        let south = hex::axial_from_offset(8, 5);
        app.game.ui_events.push(UiEvent::Move {
            team: Team::Player,
            label: 'A',
            kind: UnitKind::Tank,
            path: vec![a, south],
            air: false,
        });
        app.drain_ui_events();
        assert!(!app.move_anims.is_empty(), "移动事件应生成滑行动画");
        let pose = app.poses.get(&(Team::Player, 'A')).copied().unwrap();
        assert!(
            (pose.hull - std::f32::consts::FRAC_PI_3).abs() < 0.01,
            "向东南移动后车身应朝 60°，实际 {}",
            pose.hull
        );
        assert!(
            pose.turret.abs() < 0.01,
            "开火后移动，炮塔应保持最后一次开火方向（东），实际 {}",
            pose.turret
        );
    }

    /// 回合回放调度：严格串行（上一行动播完才播下一个）、迷雾中敌方移动
    /// 完全不播放、被击毁单位在击毁弹落地前保持显示（pending_deaths）。
    #[test]
    fn replay_sequential_and_fog_rules() {
        let mut g = GameState::new_seeded(5);
        g.begin_turn(Team::Player);
        // 敌方 E1：终点在玩家视野内（应播放）；E2：终点在迷雾中（不应播放）
        let vis_from = hex::axial_from_offset(7, 3);
        let vis_to = hex::axial_from_offset(7, 2);
        let mut e1 = Unit::new(UnitKind::Rifleman, Team::Ai, vis_from);
        e1.label = '1';
        g.units.insert(vis_from, e1);
        let fog_from = hex::axial_from_offset(20, 8);
        let mut e2 = Unit::new(UnitKind::Tank, Team::Ai, fog_from);
        e2.label = '2';
        g.units.insert(fog_from, e2);
        let mut app = test_app(g);
        app.time = 50.0;
        app.visible_enemies.insert(vis_to); // 终点可见（视野按终态计算）

        // 事件序：迷雾移动 → 视野内移动 → 击毁玩家单位的开火
        app.game.ui_events.push(UiEvent::Move {
            team: Team::Ai,
            label: '2',
            kind: UnitKind::Tank,
            path: vec![fog_from, hex::axial_from_offset(21, 8)],
            air: false,
        });
        app.game.ui_events.push(UiEvent::Move {
            team: Team::Ai,
            label: '1',
            kind: UnitKind::Rifleman,
            path: vec![vis_from, vis_to],
            air: false,
        });
        let target = hex::axial_from_offset(6, 3);
        app.game.ui_events.push(UiEvent::Fire(hex_wargame::game::UiFireEvent {
            team: Team::Ai,
            label: '1',
            kind: UnitKind::Rifleman,
            from: vis_to,
            target,
            target_team: Team::Player,
            target_label: 'A',
            target_kind: UnitKind::Rifleman,
            aa_mode: false,
            missile_mode: false,
            area: false,
            smoke_shell: false,
            blast: Vec::new(),
            hit: true,
            blocked: false,
            killed: true,
            target_hp_before: 3,
            dmg: 3,
            killed_units: vec![hex_wargame::game::KilledUnit {
                hex: target,
                team: Team::Player,
                kind: UnitKind::Rifleman,
                label: 'A',
                hp_before: 3,
            }],
        }));
        app.drain_ui_events();
        // 1) 迷雾中的敌方移动不生成滑行动画；视野内的正常生成
        assert_eq!(app.move_anims.len(), 1, "迷雾中的敌方移动不应播放");
        assert_eq!(app.move_anims[0].label, '1');
        // 2) 击毁目标 → 待毁棋子入队，保持显示到弹落地
        assert_eq!(app.pending_deaths.len(), 1, "击毁应有待毁棋子");
        assert_eq!(app.pending_deaths[0].hex, target);
        // 3) 严格串行：开火动画的开始 ≥ 移动动画的结束
        let mv_end = app.move_anims[0].end;
        assert!(
            !app.fire_anims.is_empty() && app.fire_anims[0].start >= mv_end - 1e-9,
            "开火应在移动动画结束后才开始"
        );
        let fa = &app.fire_anims[0];
        let land = fa.launch + fa.flight;
        assert!(
            (app.pending_deaths[0].land_at - land).abs() < 1e-9,
            "待毁棋子应在弹落地时消失"
        );
        // 4) 落地后待毁棋子清除（尸体/残骸由落地结算生成）
        app.time = land + 0.01;
        app.update_fx();
        assert!(app.pending_deaths.is_empty(), "弹落地后待毁棋子应消失");
    }

    /// 幽灵（灰雾图标）只保留 2 回合：目击后 1 回合内保留，第 3 回合消失。
    #[test]
    fn ghost_marks_expire_after_two_turns() {
        let mut g = GameState::new_seeded(5);
        g.begin_turn(Team::Player);
        let h = hex::axial_from_offset(7, 3);
        let mut e = Unit::new(UnitKind::Rifleman, Team::Ai, h);
        e.label = '1';
        g.units.insert(h, e);
        let mut app = test_app(g);
        app.game.turn = 3;
        app.visible_enemies.insert(h);
        // 模拟 ui() 的每帧刷新：视野内敌人刷新幽灵（带回合戳）并过期清理
        app.refresh_ghosts(Team::Player);
        assert!(
            app.ghosts
                .get(&Team::Player)
                .is_some_and(|m| m.contains_key(&h)),
            "目击当回合幽灵应存在"
        );
        // 幽灵按阵营分开保存：另一方的目击记录不受影响
        assert!(
            app.ghosts.get(&Team::Ai).map_or(true, |m| !m.contains_key(&h)),
            "另一方不应看到蓝方的目击记录"
        );
        // 2 回合后过期（敌人已离开视野，不再刷新目击回合戳）
        app.game.turn = 5;
        app.visible_enemies.clear();
        app.refresh_ghosts(Team::Player);
        assert!(
            app.ghosts
                .get(&Team::Player)
                .map_or(true, |m| !m.contains_key(&h)),
            "2 回合后幽灵应过期"
        );
    }

    /// 己方直升机飞在己方步兵上方（同格）：点击上层 → 选中直升机而非步兵
    #[test]
    fn click_air_upper_selects_heli() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        let h = hex::axial_from_offset(8, 4);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Player, h));
        g.air_units.insert(h, Unit::new(UnitKind::AttackHeli, Team::Player, h));
        let mut app = test_app(g);
        app.handle_click(h, true); // 点上层（直升机兵牌区域）
        assert_eq!(app.selected, Some(h));
        assert!(app.selected_is_air, "点上层应选中直升机");
        assert_eq!(
            app.selected_unit().map(|u| u.kind),
            Some(UnitKind::AttackHeli)
        );
    }

    /// 点击下层 → 选中地面步兵
    #[test]
    fn click_air_lower_selects_ground() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        let h = hex::axial_from_offset(8, 4);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Player, h));
        g.air_units.insert(h, Unit::new(UnitKind::AttackHeli, Team::Player, h));
        let mut app = test_app(g);
        app.handle_click(h, false); // 点下层（地面兵牌区域）
        assert_eq!(app.selected, Some(h));
        assert!(!app.selected_is_air, "点下层应选中地面单位");
        assert_eq!(
            app.selected_unit().map(|u| u.kind),
            Some(UnitKind::Rifleman)
        );
    }

    /// 飞行单位单独在格（无地面单位）：点击应能选中它（此前 unit_at 查不到会落空）
    #[test]
    fn click_single_air_selects_heli() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        let h = hex::axial_from_offset(8, 4);
        g.air_units.insert(h, Unit::new(UnitKind::AttackHeli, Team::Player, h));
        let mut app = test_app(g);
        app.handle_click(h, false);
        assert_eq!(app.selected, Some(h));
        assert!(app.selected_is_air, "单飞行单位格点击应选中直升机");
        assert_eq!(
            app.selected_unit().map(|u| u.kind),
            Some(UnitKind::AttackHeli)
        );
    }

    /// 直射测距器：输出距离、直射状态、命中率乘数
    #[test]
    fn ranger_info_distance_los_and_hit() {
        let mk = || {
            let mut g = GameState::new_seeded(3);
            g.begin_turn(Team::Player);
            g.map.obstacles.clear();
            g.map.forests.clear();
            g.map.buildings.clear();
            g
        };
        // 起点坦克（射程6 命中90%），目标步枪手在森林（×0.8 → 72%）
        let mut g1 = mk();
        let from = hex::axial_from_offset(3, 4);
        let to = hex::axial_from_offset(9, 4);
        g1.units.insert(from, Unit::new(UnitKind::Tank, Team::Player, from));
        g1.units.insert(to, Unit::new(UnitKind::Rifleman, Team::Ai, to));
        g1.map.add_forest(9, 4);
        let mut app = test_app(g1);
        app.show_range_info(from, to);
        let joined = app.log_text();
        assert!(joined.contains("距离 6 格"), "距离: {joined}");
        assert!(joined.contains("直射视线：✅"), "直射: {joined}");
        assert!(joined.contains("✅ 可开火"), "可开火: {joined}");
        assert!(joined.contains("直射视线：✅"), "直射: {joined}");
        assert!(joined.contains("森林×0.8"), "森林乘数: {joined}");
        assert!(joined.contains("72%"), "90×0.8=72: {joined}");
        assert!(joined.contains("✅ 能击穿护甲"), "坦克攻4 打穿步枪甲0: {joined}");
        // 中间烟雾阻断直射
        let g2 = mk();
        let mut a2 = test_app(g2);
        a2.game.units.insert(from, Unit::new(UnitKind::Tank, Team::Player, from));
        a2.game.units.insert(to, Unit::new(UnitKind::Rifleman, Team::Ai, to));
        a2.game.smoke.insert(hex::axial_from_offset(6, 4), 2);
        a2.show_range_info(from, to);
        let joined2 = a2.log_text();
        assert!(joined2.contains("直射视线：❌"), "烟雾阻断直射: {joined2}");
        assert!(
            joined2.contains("无法开火"),
            "LOS 被挡应提示无法开火: {joined2}"
        );
        // 目标在烟雾中：命中率再 ×0.6（72 → 43）
        let g3 = mk();
        let mut a3 = test_app(g3);
        a3.game.units.insert(from, Unit::new(UnitKind::Tank, Team::Player, from));
        a3.game.units.insert(to, Unit::new(UnitKind::Rifleman, Team::Ai, to));
        a3.game.map.add_forest(9, 4);
        a3.game.smoke.insert(to, 2);
        a3.show_range_info(from, to);
        let joined3 = a3.log_text();
        assert!(joined3.contains("烟雾×0.6"), "烟雾乘数: {joined3}");
        assert!(joined3.contains("43%"), "72×0.6=43: {joined3}");
        // 楼房阻隔（用户场景）：测距器提示射程覆盖但无法开火
        let g4 = mk();
        let mut a4 = test_app(g4);
        a4.game.units.insert(from, Unit::new(UnitKind::Tank, Team::Player, from));
        a4.game.units.insert(to, Unit::new(UnitKind::Rifleman, Team::Ai, to));
        a4.game.map.add_building(6, 4);
        a4.show_range_info(from, to);
        let j4 = a4.log_text();
        assert!(j4.contains("距离 6 格"), "距离: {j4}");
        assert!(j4.contains("直射视线：❌"), "楼房阻断直射: {j4}");
        assert!(
            j4.contains("无法开火（共享视野不可绕过）"),
            "楼房阻隔应提示无法开火: {j4}"
        );
    }

    /// 滚轮缩放：正向滚动放大，且鼠标下的地图点在缩放前后保持不动
    #[test]
    fn scroll_zoom_keeps_point_under_cursor() {
        let center = egui::pos2(600.0, 400.0);
        let (mw, mh) = (900.0, 600.0);
        let p = egui::pos2(480.0, 320.0);
        let (old_zoom, old_pan) = (1.0, egui::Vec2::new(40.0, -25.0));
        let (nz, np) = GuiApp::scroll_zoom(center, mw, mh, old_zoom, old_pan, p, 120.0);
        assert!(nz > 1.0, "正向滚动应放大: {nz}");
        // 缩放前鼠标相对地图原点的偏移（缩放前像素）
        let origin0_old = egui::pos2(center.x - mw / 2.0, center.y - mh / 2.0);
        let rel = p - origin0_old - old_pan;
        // 缩放后：原点 + 平移 + rel*k 应仍在鼠标下
        let k_real = nz / old_zoom;
        let origin0_new = egui::pos2(center.x - mw / 2.0 * k_real, center.y - mh / 2.0 * k_real);
        let back = origin0_new + np + rel * k_real;
        assert!(
            (back - p).length() < 0.01,
            "缩放后鼠标下地图点应保持: {back:?} vs {p:?}"
        );
        // 反向滚动缩小
        let (nz2, _) = GuiApp::scroll_zoom(center, mw, mh, nz, np, p, -200.0);
        assert!(nz2 < nz, "反向滚动应缩小: {nz2} < {nz}");
    }

    /// 敌方直升机飞在敌方步兵上方：点上层应选中敌方直升机（查看信息）
    #[test]
    fn click_enemy_air_upper_selects_heli() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        let h = hex::axial_from_offset(8, 4);
        g.units.insert(h, Unit::new(UnitKind::Rifleman, Team::Ai, h));
        g.air_units.insert(h, Unit::new(UnitKind::AttackHeli, Team::Ai, h));
        let mut app = test_app(g);
        app.visible_enemies.insert(h);
        app.handle_click(h, true);
        assert_eq!(app.selected, Some(h));
        assert!(app.selected_is_air, "点敌方上层应选中敌方直升机");
        assert_eq!(
            app.selected_unit().map(|u| u.kind),
            Some(UnitKind::AttackHeli)
        );
    }

    /// Bug 回归：陆军移动踏入最后一个敌方关键据点 → 立即结算（game_over 设置），
    /// 不再需要额外操作（如炮击空格）才触发。
    #[test]
    fn move_captures_last_keypoint_triggers_win() {
        let mut g = GameState::new_seeded(111);
        g.begin_turn(Team::Player);
        g.enable_sustain(10, 20);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        // 玩家 3 据点 + AI 3 据点
        let pc = hex::axial_from_offset(1, 2);
        let p2 = hex::axial_from_offset(1, 3);
        let p3 = hex::axial_from_offset(2, 2);
        let ac = hex::axial_from_offset(20, 2);
        let a2 = hex::axial_from_offset(20, 3);
        let a3 = hex::axial_from_offset(21, 2);
        for (h, c) in [(pc, true), (p2, false), (p3, false)] {
            g.keypoints.insert(
                h,
                hex_wargame::game::Keypoint {
                    owner: Team::Player,
                    controller: Team::Player,
                    center: c,
                },
            );
        }
        for (h, c) in [(ac, true), (a2, false), (a3, false)] {
            g.keypoints.insert(
                h,
                hex_wargame::game::Keypoint {
                    owner: Team::Ai,
                    controller: Team::Ai,
                    center: c,
                },
            );
        }
        // 玩家已控制 5 个（pc/p2/p3/ac/a3），a2 仍是 AI 控制
        for (h, _) in [(pc, true), (p2, false), (p3, false), (ac, true), (a3, false)] {
            g.keypoints.get_mut(&h).unwrap().controller = Team::Player;
        }
        // 玩家坦克在 a2 相邻格
        let start = hex::axial_from_offset(19, 3);
        g.units
            .insert(start, Unit::new(UnitKind::Tank, Team::Player, start));
        let mut app = test_app(g);
        // 选中坦克 → 点击 a2 移动（踏入占领最后据点）
        app.handle_click(start, false);
        app.handle_click(a2, false);
        assert!(
            app.game_over.is_some(),
            "移动占领最后一个关键据点应立即结算（实测 {:?}）",
            app.game_over
        );
    }

    /// 默认勾选持续部署（玩家 10 / AI 20）且开局即进入；
    /// 应用设置（改模式/点数）不重新部署已部署的单位。
    #[test]
    fn sustain_default_on_and_apply_keeps_deployment() {
        let mut app = test_app(GameState::new_deploy_level(1, Level::OpenField));
        app.apply_sustain_settings(); // 模拟 App::new 开局即应用设置
        // 默认勾选持续部署 + 点数 10/20，开局即进入
        assert!(app.sustain_mode, "默认勾选持续部署");
        assert_eq!(app.sustain_pp, 10, "默认玩家每回合点数 10");
        assert_eq!(app.sustain_ap, 20, "默认 AI 每回合点数 20");
        assert!(app.game.sustain, "开局即进入持续部署模式");
        assert_eq!(
            app.game.sustain_per_turn.get(&Team::Player).copied().unwrap_or(0),
            10
        );
        assert_eq!(
            app.game.sustain_per_turn.get(&Team::Ai).copied().unwrap_or(0),
            20
        );
        // 部署一个单位
        app.game.begin_turn(Team::Player);
        app.game.deploying = true;
        app.game.recruit_points.insert(Team::Player, 100);
        let pos = hex::axial_from_offset(1, 3);
        app.game
            .deploy_unit(Team::Player, UnitKind::Tank, pos)
            .unwrap();
        app.game.deploying = false;
        let n = app.game.units_of(Team::Player).len();
        assert!(n > 0, "已部署单位");
        // 应用设置（改点数）→ 不重新部署（单位保留）
        app.sustain_pp = 15;
        app.sustain_ap = 30;
        app.apply_sustain_settings();
        assert_eq!(
            app.game.units_of(Team::Player).len(),
            n,
            "应用设置不重新部署已部署单位"
        );
        assert_eq!(
            app.game.sustain_per_turn.get(&Team::Player).copied().unwrap_or(0),
            15,
            "点数更新生效"
        );
        assert_eq!(
            app.game.sustain_per_turn.get(&Team::Ai).copied().unwrap_or(0),
            30
        );
        // 关闭持续部署 → 应用设置后 game.sustain 关闭（单位仍保留）
        app.sustain_mode = false;
        app.apply_sustain_settings();
        assert!(!app.game.sustain, "关闭后退出持续部署模式");
        assert_eq!(app.game.units_of(Team::Player).len(), n, "关闭模式也不重部署");
    }

    /// 用户流程回归：加载小镇巷战（自定义地图）→ 勾选可持续部署 →
    /// 应用设置（restart）→ 进入战斗，全过程必须保持可持续部署模式
    /// 且地图不被重置成空地图。
    #[test]
    fn sustain_survives_custom_map_restart() {
        let cm = CustomMap::load(std::path::Path::new("maps/小镇巷战.json")).unwrap();
        let mut app = test_app(GameState::new_deploy_level(1, Level::OpenField));
        // 模拟 ComboBox 加载自定义地图
        app.level = Level::Custom;
        app.custom_map = Some(cm.clone());
        app.game = GameState::new_custom_deploy(7, cm.clone());
        app.apply_sustain_settings();
        // 勾选可持续部署并设置每回合点数
        app.sustain_mode = true;
        app.sustain_pp = 30;
        app.sustain_ap = 30;
        // 点"应用设置并重新部署"
        app.restart();
        assert!(app.game.sustain, "restart 后应保持可持续部署");
        assert_eq!(
            app.game.sustain_per_turn.get(&Team::Player).copied().unwrap_or(0),
            30,
            "每回合点数应保留"
        );
        assert_eq!(app.game.level, Level::Custom, "自定义地图应保留");
        assert_eq!(
            (app.game.map.cols, app.game.map.rows),
            (cm.cols, cm.rows),
            "地图尺寸应保留（不被重置成空地图）"
        );
        // 进入战斗
        app.game.finish_deploy().unwrap();
        assert!(app.game.sustain, "进入战斗后仍为可持续部署");
        assert!(
            app.game
                .keypoints
                .values()
                .any(|kp| kp.owner == Team::Player),
            "可持续部署应生成关键据点"
        );
    }

    /// 可持续部署：对局中按 D 进入追加部署，点击放置新单位（本回合不可行动）；
    /// 被敌军占领的大本营格不可放置。
    #[test]
    fn multiplayer_gui_can_control_red_hotseat() {
        let mut g = GameState::new_seeded_level(5, Level::OpenField);
        g.begin_turn(Team::Player);
        g.begin_turn(Team::Ai); // 进入红方阶段
        let red = g.units_of(Team::Ai)[0].clone();
        let reach = g
            .map
            .reachable_hexes(&g.units, red.pos, red.kind.movement(), Some(&red));
        let target = *reach.iter().find(|h| **h != red.pos).expect("红方应有可移动格");
        let mut app = test_app(g);
        app.multiplayer = true;
        app.local_control = mp::LocalControl::Both;
        app.handle_click(red.pos, false);
        assert_eq!(app.selected, Some(red.pos), "红方热座应能选中红方单位");
        app.handle_click(target, false);
        assert_eq!(app.selected, Some(target), "红方热座应能移动红方单位");
        assert_eq!(app.game.phase, Team::Ai);
    }

    #[test]
    fn sustain_deploy_via_click() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        g.enable_sustain(50, 50);
        g.keypoints.insert(
            hex::axial_from_offset(1, 2),
            hex_wargame::game::Keypoint {
                owner: Team::Player,
                controller: Team::Player,
                center: true,
            },
        );
        g.recruit_points.insert(Team::Player, 50);
        g.sustain_deploying = true;
        let mut app = test_app(g);
        let pos = hex::axial_from_offset(1, 3); // 距大本营中心 1 格（周围 2 格内）
        app.pending_recruit = Some(UnitKind::Rifleman);
        app.handle_click(pos, false);
        assert!(app.game.unit_at(pos).is_some(), "应放置增援单位");
        assert_eq!(app.game.unit_at(pos).unwrap().actions_left, 0, "增援单位本回合不可行动");
        // 超出指挥部 2 格不可放置
        app.pending_recruit = Some(UnitKind::Tank);
        let before = app.game.units_of(Team::Player).len();
        app.handle_click(hex::axial_from_offset(6, 2), false);
        assert_eq!(app.game.units_of(Team::Player).len(), before, "指挥部 2 格外不可放置");
        // 被占领格不可放置（敌方单位距目标格 ≤5）
        app.game.units.insert(
            hex::axial_from_offset(3, 3),
            Unit::new(UnitKind::Tank, Team::Ai, hex::axial_from_offset(3, 3)),
        );
        app.pending_recruit = Some(UnitKind::Rifleman);
        app.handle_click(hex::axial_from_offset(2, 3), false);
        assert_eq!(app.game.units_of(Team::Player).len(), before, "被占领格不可放置");
    }

    /// 导出的日志必须自包含：结构化战报、终局态势与双方最终快照都在，
    /// 复盘者无需再看别的文件即可重建对局。
    #[test]
    fn export_log_is_self_contained() {
        let mut g = GameState::new_seeded_level(21, Level::OpenField);
        g.begin_turn(Team::Player);
        let mut app = test_app(g);
        let path = app.export_log().expect("导出日志");
        let text = std::fs::read_to_string(&path).expect("读取日志");
        for needle in [
            "版本: 2",
            "── 事件记录 ──",
            "── 结构化战报 ──",
            "── 终局态势 ──",
            "── 对局结果 ──",
            "── 最终快照 · 蓝方视角 ──",
            "── 最终快照 · 红方视角 ──",
            "── 局势 ──",
            "我方:",
        ] {
            assert!(text.contains(needle), "日志缺少 {:?}", needle);
        }
        let _ = std::fs::remove_file(&path);
    }


    /// 多人模式对局结束时自动导出日志（无需点按钮），且只导出一次。
    #[test]
    fn auto_export_log_writes_once_on_game_over() {
        let mut g = GameState::new_seeded_level(22, Level::OpenField);
        g.begin_turn(Team::Player);
        let mut app = test_app(g);
        app.multiplayer = true;
        app.game_over = Some("★ 蓝方获胜！".to_string());
        app.auto_export_log();
        assert!(app.auto_log_done, "应标记已导出");
        let line = app
            .log
            .iter()
            .find(|l| l.text.contains("完整日志已自动导出"))
            .expect("应记录导出路径");
        let path = line.text.split(": ").last().unwrap().trim().to_string();
        let text = std::fs::read_to_string(&path).expect("日志文件应存在");
        assert!(text.contains("── 结构化战报 ──"), "自动导出的日志应含结构化战报");
        assert!(text.contains("★ 蓝方获胜！"), "日志应含对局结果");
        // 再次调用不应重复导出
        let before = app.log.len();
        app.auto_export_log();
        assert_eq!(app.log.len(), before, "不应重复导出");
        let _ = std::fs::remove_file(&path);
    }

    /// Bug 回归：选中己方步兵点击己方直升机所在格 → 步兵应移动过去（同格双层），
    /// 而不是把选择切换到直升机。
    #[test]
    fn ground_unit_moves_onto_friendly_heli_hex() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let start = hex::axial_from_offset(5, 5);
        let heli_pos = hex::axial_from_offset(5, 6);
        let mut inf = Unit::new(UnitKind::Rifleman, Team::Player, start);
        inf.label = 'A';
        g.units.insert(start, inf);
        let mut heli = Unit::new(UnitKind::TransportHeli, Team::Player, heli_pos);
        heli.label = 'H';
        g.air_units.insert(heli_pos, heli);
        let mut app = test_app(g);
        // 选中步兵
        app.handle_click(start, false);
        assert_eq!(app.selected, Some(start));
        // 点击直升机格 → 步兵移动过去，而不是选中直升机
        app.handle_click(heli_pos, false);
        assert!(!app.selected_is_air, "移动后仍应选中地面步兵");
        assert!(
            app.game.units.contains_key(&heli_pos),
            "步兵应移动到直升机同一格"
        );
        assert!(
            app.game.air_units.contains_key(&heli_pos),
            "直升机应仍在原格（不被覆盖）"
        );
        assert_eq!(
            app.game.units.get(&heli_pos).unwrap().kind,
            UnitKind::Rifleman
        );
        assert!(!app.game.units.contains_key(&start), "原格应空出");
    }

    /// 同层不重叠：选中己方直升机点击另一台己方直升机所在格，
    /// 只能改为选中对方，不能移动覆盖（否则会凭空损失一台直升机）。
    #[test]
    fn air_unit_does_not_stack_on_friendly_air() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let a = hex::axial_from_offset(5, 5);
        let b = hex::axial_from_offset(5, 6);
        let mut h1 = Unit::new(UnitKind::TransportHeli, Team::Player, a);
        h1.label = 'A';
        let mut h2 = Unit::new(UnitKind::TransportHeli, Team::Player, b);
        h2.label = 'B';
        g.air_units.insert(a, h1);
        g.air_units.insert(b, h2);
        let mut app = test_app(g);
        app.handle_click(a, false); // 选中直升机 A
        assert!(app.selected_is_air);
        app.handle_click(b, false); // 点击直升机 B 所在格
        assert_eq!(app.game.air_units.len(), 2, "两台直升机都应存在");
        assert_eq!(app.game.air_units.get(&a).unwrap().label, 'A');
        assert_eq!(app.game.air_units.get(&b).unwrap().label, 'B');
    }

    /// 特性：未按 X 时点击紧邻步兵不会装载（仅改为选中）；
    /// 按 X 进入装载模式后点击紧邻步兵才上车。
    #[test]
    fn click_board_requires_load_mode() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let ifv_pos = hex::axial_from_offset(5, 5);
        let inf_pos = hex::axial_from_offset(5, 6);
        let mut ifv = Unit::new(UnitKind::Ifv, Team::Player, ifv_pos);
        ifv.label = 'V';
        let mut inf = Unit::new(UnitKind::Rifleman, Team::Player, inf_pos);
        inf.label = 'I';
        g.units.insert(ifv_pos, ifv);
        g.units.insert(inf_pos, inf);
        let mut app = test_app(g);

        // 1) 普通模式点击紧邻步兵：不装载，改为选中步兵
        app.handle_click(ifv_pos, false);
        app.handle_click(inf_pos, false);
        assert_eq!(
            app.game.units.get(&ifv_pos).unwrap().passengers.len(),
            0,
            "未进入装载模式不应装载"
        );
        assert!(app.game.units.contains_key(&inf_pos), "步兵应仍在原地");
        assert!(!app.load_mode);
        assert_eq!(app.selected, Some(inf_pos), "普通模式点击步兵应改为选中它");

        // 2) 按 X 进入装载模式：点击紧邻步兵 → 上车
        app.handle_click(ifv_pos, false); // 重新选中 IFV
        app.toggle_load_mode();
        assert!(app.load_mode, "应进入装载模式");
        app.handle_click(inf_pos, false);
        assert_eq!(
            app.game.units.get(&ifv_pos).unwrap().passengers.len(),
            1,
            "装载模式下点击紧邻步兵应上车"
        );
        assert!(!app.game.units.contains_key(&inf_pos), "步兵应离开原地");
    }

    /// 特性：装载模式下点击可达空格不能移动。
    #[test]
    fn load_mode_blocks_movement() {
        let mut g = GameState::new_seeded(3);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.units.clear();
        g.air_units.clear();
        let ifv_pos = hex::axial_from_offset(5, 5);
        let dest = hex::axial_from_offset(6, 5);
        let mut ifv = Unit::new(UnitKind::Ifv, Team::Player, ifv_pos);
        ifv.label = 'V';
        g.units.insert(ifv_pos, ifv);
        let mut app = test_app(g);
        app.handle_click(ifv_pos, false);
        app.toggle_load_mode();
        assert!(app.load_mode);
        app.handle_click(dest, false); // 装载模式下点击可达空格
        assert!(
            app.game.units.contains_key(&ifv_pos),
            "装载模式下不应移动"
        );
        assert!(!app.game.units.contains_key(&dest), "目标格不应出现载具");
        assert_eq!(app.selected, Some(ifv_pos), "仍应选中载具");
        assert!(app.load_mode, "点击无效后仍处于装载模式");
    }

    /// 移动动画朝向：车头在起点就应指向第一段前进方向（而不是提前转向终点），
    /// 并在路径转弯节点附近平滑过渡到下一段方向。
    #[test]
    fn move_heading_follows_segments() {
        let app = test_app(GameState::new_seeded(1));
        // 先向东一段，再折向北一段
        let p = [
            hex::axial_from_offset(2, 4),
            hex::axial_from_offset(3, 4),
            hex::axial_from_offset(3, 3),
        ];
        let east = pieces::angle_between(app.hex_center_pos(p[0]), app.hex_center_pos(p[1]));
        let north = pieces::angle_between(app.hex_center_pos(p[1]), app.hex_center_pos(p[2]));
        // 起点朝向 = 第一段方向（不提前转为终点方向）
        let h_start = app.move_heading(&p, 0, 0.0);
        assert!(
            (h_start - east).abs() < 0.01,
            "起点车头应朝向前进方向，实际 {h_start} 期望 {east}"
        );
        assert!(
            (h_start - north).abs() > 0.3,
            "起点不应提前转向终点方向"
        );
        // 段末已转向下一段方向
        let h_end = app.move_heading(&p, 1, 1.0);
        assert!(
            (h_end - north).abs() < 0.01,
            "段末车头应对齐下一段方向，实际 {h_end} 期望 {north}"
        );
        // 节点前后朝向连续（无跳变）
        let before = app.move_heading(&p, 0, 0.999);
        let after = app.move_heading(&p, 1, 0.001);
        let mut d = (after - before) % std::f32::consts::TAU;
        if d > std::f32::consts::PI {
            d -= std::f32::consts::TAU;
        } else if d < -std::f32::consts::PI {
            d += std::f32::consts::TAU;
        }
        assert!(d.abs() < 0.05, "转弯节点处朝向应连续，跳变 {d}");
    }

    /// GUI 底部日志只显示玩家视野内的 AI 行动：迷雾中的移动不记录，
    /// 迷雾中的攻击只提示敌人位置与效果。
    #[test]
    fn gui_log_filters_invisible_ai_actions() {
        let mut g = GameState::new_seeded(5);
        g.begin_turn(Team::Player);
        let mut app = test_app(g);
        app.time = 10.0;
        let vis_from = hex::axial_from_offset(7, 3);
        let vis_to = hex::axial_from_offset(7, 2);
        let hidden_from = hex::axial_from_offset(20, 8);
        let hidden_to = hex::axial_from_offset(21, 8);
        app.visible_enemies.insert(vis_from);
        app.visible_enemies.insert(vis_to);
        // 可见移动
        app.game.ui_events.push(UiEvent::Move {
            team: Team::Ai,
            label: '1',
            kind: UnitKind::Rifleman,
            path: vec![vis_from, vis_to],
            air: false,
        });
        // 迷雾中的移动
        app.game.ui_events.push(UiEvent::Move {
            team: Team::Ai,
            label: '2',
            kind: UnitKind::Tank,
            path: vec![hidden_from, hidden_to],
            air: false,
        });
        // 迷雾中的攻击：攻击方不可见
        let target = hex::axial_from_offset(6, 3);
        app.game.ui_events.push(UiEvent::Fire(hex_wargame::game::UiFireEvent {
            team: Team::Ai,
            label: '3',
            kind: UnitKind::Rifleman,
            from: hidden_from,
            target,
            target_team: Team::Player,
            target_label: 'A',
            target_kind: UnitKind::Rifleman,
            aa_mode: false,
            missile_mode: false,
            area: false,
            smoke_shell: false,
            blast: Vec::new(),
            hit: true,
            blocked: false,
            killed: false,
            target_hp_before: 3,
            dmg: 1,
            killed_units: Vec::new(),
        }));
        // 可见攻击：攻击方在视野内
        app.game.ui_events.push(UiEvent::Fire(hex_wargame::game::UiFireEvent {
            team: Team::Ai,
            label: '1',
            kind: UnitKind::Rifleman,
            from: vis_to,
            target,
            target_team: Team::Player,
            target_label: 'A',
            target_kind: UnitKind::Rifleman,
            aa_mode: false,
            missile_mode: false,
            area: false,
            smoke_shell: false,
            blast: Vec::new(),
            hit: true,
            blocked: false,
            killed: false,
            target_hp_before: 3,
            dmg: 1,
            killed_units: Vec::new(),
        }));
        let before = app.log.len();
        app.drain_ui_events();
        let text = app.log[before..]
            .iter()
            .map(|l| l.text.clone())
            .collect::<Vec<_>>()
            .join("\n");
        assert!(
            text.contains(&hex::hex_label(vis_to)),
            "视野内移动应记录: {text}"
        );
        assert!(text.contains("攻击"), "可见攻击应记录: {text}");
        assert!(
            !text.contains(&hex::hex_label(hidden_to)),
            "迷雾中的移动不应记录: {text}"
        );
        assert!(
            text.contains("迷雾中的敌军"),
            "迷雾攻击应提示敌情: {text}"
        );
        assert!(
            text.contains(&hex::hex_label(hidden_from)),
            "迷雾攻击应给出敌人位置: {text}"
        );
        assert!(app.game.ui_events.is_empty(), "事件应已消费");
    }

    /// AI 回合状态标记：思考中 → 已思考 xx 秒 → 玩家回合消失。
    #[test]
    fn ai_status_marker_states() {
        let mut app = test_app(GameState::new_seeded(1));
        assert!(app.ai_status_marker().is_none(), "初始无标记");
        // 后台思考中
        app.ai_thread = Some(std::thread::spawn(|| (GameState::new(), Vec::new())));
        assert!(
            app.ai_status_marker().unwrap().contains("思考中"),
            "思考中标记"
        );
        // 算完播放行动：显示耗时
        app.ai_thread = None;
        app.ai_playback = true;
        app.ai_think_elapsed = Some(1.5);
        assert!(
            app.ai_status_marker().unwrap().contains("已思考 1.5 秒"),
            "已思考标记"
        );
        // 玩家回合开始：消失
        app.ai_playback = false;
        app.ai_think_elapsed = None;
        assert!(app.ai_status_marker().is_none(), "玩家回合应清除标记");
        assert!(!app.ai_busy(), "玩家回合不再忙碌");
    }

    /// 端到端：结束玩家回合后 AI 在后台计算（不阻塞），标记经历
    /// 思考中 → 已思考 → 消失，播完后回到玩家回合。
    #[test]
    fn ai_turn_runs_async_then_returns_control() {
        let mut g = GameState::new_seeded(5);
        g.begin_turn(Team::Player);
        g.map.obstacles.clear();
        g.map.forests.clear();
        g.map.buildings.clear();
        g.map.water.clear();
        g.units.clear();
        g.air_units.clear();
        let ph = hex::axial_from_offset(2, 6);
        let mut p = Unit::new(UnitKind::Rifleman, Team::Player, ph);
        p.label = 'A';
        g.units.insert(ph, p);
        let ah = hex::axial_from_offset(20, 6);
        let mut e = Unit::new(UnitKind::Rifleman, Team::Ai, ah);
        e.label = '1';
        g.units.insert(ah, e);
        let mut app = test_app(g);
        app.time = 0.0;

        app.end_player_turn();
        let event_log_before = app.game.event_log.len();
        assert!(app.ai_thread.is_some(), "AI 应在后台线程计算");
        assert!(
            app.ai_status_marker().unwrap().contains("思考中"),
            "思考期间应显示思考中"
        );
        // 等待后台算完（轮询，不阻塞读取结果）
        for _ in 0..5000 {
            app.time += 0.016;
            app.poll_ai_thread();
            if app.ai_thread.is_none() {
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
        assert!(app.ai_thread.is_none(), "AI 线程应算完");
        assert!(
            app.game.event_log.len() > event_log_before,
            "AI 全部行动应写入事件日志（导出/存档保留完整数据）"
        );
        assert!(app.ai_playback, "算完后应进入播放阶段");
        assert!(
            app.ai_status_marker().unwrap().contains("已思考"),
            "播放时应显示已思考耗时"
        );
        // 刷新玩家视野并播放 AI 行动事件
        let vis = app.game.vision(Team::Player);
        app.visible_enemies = vis.enemy_units;
        app.drain_ui_events();
        for _ in 0..200_000 {
            if !app.fx_active() {
                break;
            }
            app.time += 0.05;
            app.update_fx();
        }
        app.finalize_ai_turn();
        assert_eq!(app.game.phase, Team::Player, "播完后应回到玩家回合");
        assert!(app.ai_status_marker().is_none(), "标记应消失");
        assert!(!app.ai_busy(), "玩家应可再次操作");
    }

    fn run_ai_once(app: &mut GuiApp) {
        app.end_player_turn();
        for _ in 0..5000 {
            app.time += 0.016;
            app.poll_ai_thread();
            if app.ai_thread.is_none() {
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
        let vis = app.game.vision(Team::Player);
        app.visible_enemies = vis.enemy_units;
        app.drain_ui_events();
        for _ in 0..200_000 {
            if !app.fx_active() {
                break;
            }
            app.time += 0.05;
            app.update_fx();
        }
        app.finalize_ai_turn();
    }

    /// 临时复现：AI 火炮（迫击炮/榴弹炮）炮击后，玩家新回合行动次数应减少。
    #[test]
    fn repro_ai_artillery_suppresses_player_end_to_end() {
        for ver in [AiVersion::Legacy, AiVersion::V2] {
            for kind in [UnitKind::Mortar, UnitKind::Howitzer] {
                let mut g = GameState::new_seeded(7);
                g.ai_version = ver;
                g.begin_turn(Team::Player);
                g.map.obstacles.clear();
                g.map.forests.clear();
                g.map.buildings.clear();
                g.map.water.clear();
                g.units.clear();
                g.air_units.clear();
                let ph = hex::axial_from_offset(11, 6);
                let mut p = Unit::new(UnitKind::Rifleman, Team::Player, ph);
                p.label = 'A';
                p.hp = 20; // 加厚血量：本测试只验证“炮击是否造成压制”，避免观测期间被击毁
                g.units.insert(ph, p);
                let mh = hex::axial_from_offset(9, 6);
                let mut m = Unit::new(kind, Team::Ai, mh);
                m.label = '1';
                m.deployed = true;
                g.units.insert(mh, m);
                let mut app = test_app(g);
                app.time = 0.0;

                run_ai_once(&mut app);
                // 两回合观察（榴弹炮行动 1：架设/射击隔回合）
                let mut acts = Vec::new();
                for _ in 0..2 {
                    let p = app.game.unit_at(ph).expect("player alive");
                    acts.push(p.actions_left);
                    run_ai_once(&mut app);
                }
                let log = app.game.event_log.join("\n");
                eprintln!(
                    "VER {:?} KIND {:?}: actions per turn={:?}\nLOG:\n{}",
                    ver, kind, acts, log
                );
                assert!(
                    acts.iter().any(|a| *a < 3),
                    "VER {:?} KIND {:?}: AI 火炮应压制玩家使其行动 < 3，实际 {:?}",
                    ver,
                    kind,
                    acts
                );
            }
        }
    }

}
