//! 3D 前端（Web 版）的后端桥接层。
//!
//! 本模块**不修改任何既有游戏逻辑**：它只把 `hex_wargame` 库的规则引擎包起来，
//! 通过 WebSocket 向浏览器端的 Three.js 前端提供状态快照与动画事件，
//! 并接收前端的操作命令（等价于原 GUI 的鼠标点击 / 键盘操作）。
//!
//! 编译方式：只有 `src/bin/hex_wargame_web3d.rs` 通过 `#[path]` 引入本模块，
//! 因此其余可执行文件（`hex_wargame` / `_tui` / `_multiplayer` / `_editor` …）
//! 的依赖与行为完全不受影响。

pub mod host;
pub mod net;
pub mod snapshot;
pub mod staticdir;

pub use host::Host;

pub mod order_officer;
