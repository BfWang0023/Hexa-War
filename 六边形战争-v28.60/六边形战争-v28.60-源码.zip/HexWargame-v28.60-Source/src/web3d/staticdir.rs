//! 静态资源目录定位：让 `cargo run`、`target/release/xxx` 与拷贝到别处的可执行文件
//! 都能找到 `web3d/` 前端目录。

use std::path::{Path, PathBuf};

/// 依次尝试以下位置，返回第一个含有 `index.html` 的目录：
/// 1. 环境变量 `HEX_WARGAME_WEB3D_DIR`；
/// 2. 当前工作目录下的 `web3d/`；
/// 3. 可执行文件同级目录下的 `web3d/`；
/// 4. 可执行文件所在目录向上两级（`target/release/` → 仓库根）的 `web3d/`；
/// 5. 编译期仓库根目录（`CARGO_MANIFEST_DIR`）下的 `web3d/`。
pub fn resolve() -> PathBuf {
    let mut candidates: Vec<PathBuf> = Vec::new();
    if let Ok(dir) = std::env::var("HEX_WARGAME_WEB3D_DIR") {
        candidates.push(PathBuf::from(dir));
    }
    if let Ok(cwd) = std::env::current_dir() {
        candidates.push(cwd.join("web3d"));
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            candidates.push(dir.join("web3d"));
            if let Some(up2) = dir.parent().and_then(|p| p.parent()) {
                candidates.push(up2.join("web3d"));
            }
        }
    }
    candidates.push(Path::new(env!("CARGO_MANIFEST_DIR")).join("web3d"));
    for c in &candidates {
        if c.join("index.html").is_file() {
            return c.clone();
        }
    }
    candidates
        .into_iter()
        .next()
        .unwrap_or_else(|| PathBuf::from("web3d"))
}
