//! 3D 前端的网络层：不依赖任何第三方 crate 的 HTTP 静态文件服务 + WebSocket 服务。
//!
//! 设计目标：
//! - 只用 `std::net` / `std::thread`，不引入新依赖（原有可执行文件的依赖树完全不变）；
//! - 单进程内跑游戏主循环（见 `host.rs`），网络线程只做「收命令 / 广播快照」；
//! - 静态资源从 `web3d/` 目录读取（支持运行时改前端代码，刷新即可见）。

use std::collections::{BTreeMap, HashMap};
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc::{self, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::time::Duration;

/// 网络层 → 游戏主循环的消息。
#[derive(Debug)]
pub enum NetCommand {
    /// 某个客户端发来的一条 JSON 文本命令。
    Json { client: u64, text: String },
    /// 客户端断开。
    Closed { client: u64 },
}

/// 广播中心：保存所有在线客户端的发送端。
pub struct Hub {
    next_id: AtomicU64,
    clients: Mutex<HashMap<u64, Sender<String>>>,
}

impl Default for Hub {
    fn default() -> Self {
        Self::new()
    }
}

impl Hub {
    pub fn new() -> Self {
        Hub {
            next_id: AtomicU64::new(1),
            clients: Mutex::new(HashMap::new()),
        }
    }

    pub fn register(&self) -> (u64, Receiver<String>) {
        let id = self.next_id.fetch_add(1, Ordering::SeqCst);
        let (tx, rx) = mpsc::channel();
        self.clients.lock().unwrap().insert(id, tx);
        (id, rx)
    }

    pub fn unregister(&self, id: u64) {
        self.clients.lock().unwrap().remove(&id);
    }

    pub fn client_count(&self) -> usize {
        self.clients.lock().unwrap().len()
    }

    /// 向所有客户端广播一条文本消息（发送失败的客户端会被忽略，由连接线程清理）。
    pub fn broadcast(&self, text: &str) {
        let clients = self.clients.lock().unwrap();
        for tx in clients.values() {
            let _ = tx.send(text.to_string());
        }
    }

    /// 只向某个客户端发送（用于 `hello` 的初始化消息）。
    pub fn send_to(&self, id: u64, text: &str) {
        let clients = self.clients.lock().unwrap();
        if let Some(tx) = clients.get(&id) {
            let _ = tx.send(text.to_string());
        }
    }
}

/// 启动监听；返回实际绑定的地址（端口传 0 时由系统分配）。
pub fn start(hub: Arc<Hub>, cmd_tx: Sender<NetCommand>, addr: &str, static_dir: PathBuf, save_dir: Option<PathBuf>) -> std::io::Result<SocketAddr> {
    let listener = TcpListener::bind(addr)?;
    let local = listener.local_addr()?;
    let save_dir = save_dir.unwrap_or_else(default_save_dir);
    std::thread::Builder::new()
        .name("web3d-accept".into())
        .spawn(move || {
            for stream in listener.incoming() {
                match stream {
                    Ok(s) => {
                        let hub = Arc::clone(&hub);
                        let cmd_tx = cmd_tx.clone();
                        let dir = static_dir.clone();
                        let saves = save_dir.clone();
                        let _ = std::thread::Builder::new()
                            .name("web3d-conn".into())
                            .spawn(move || {
                                if let Err(e) = handle_conn(s, hub, cmd_tx, dir, saves) {
                                    if e.kind() != std::io::ErrorKind::BrokenPipe
                                        && e.kind() != std::io::ErrorKind::ConnectionReset
                                    {
                                        eprintln!("[web3d] 连接结束：{e}");
                                    }
                                }
                            });
                    }
                    Err(e) => eprintln!("[web3d] accept 失败：{e}"),
                }
            }
        })?;
    Ok(local)
}

fn handle_conn(
    stream: TcpStream,
    hub: Arc<Hub>,
    cmd_tx: Sender<NetCommand>,
    static_dir: PathBuf,
    save_dir: PathBuf,
) -> std::io::Result<()> {
    stream.set_nodelay(true).ok();
    let mut reader = BufReader::new(stream.try_clone()?);
    let mut request_line = String::new();
    if reader.read_line(&mut request_line)? == 0 {
        return Ok(());
    }
    let mut parts = request_line.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let path = parts.next().unwrap_or("/").to_string();
    let mut headers: HashMap<String, String> = HashMap::new();
    loop {
        let mut line = String::new();
        if reader.read_line(&mut line)? == 0 {
            break;
        }
        let line = line.trim_end_matches(['\r', '\n']);
        if line.is_empty() {
            break;
        }
        if let Some((k, v)) = line.split_once(':') {
            headers.insert(k.trim().to_ascii_lowercase(), v.trim().to_string());
        }
    }
    let upgrade = headers
        .get("upgrade")
        .map(|v| v.eq_ignore_ascii_case("websocket"))
        .unwrap_or(false);
    if upgrade {
        return serve_websocket(stream, reader, hub, cmd_tx, &headers);
    }
    if path.starts_with("/api/ancient/order-officer/") {
        return super::order_officer::serve(stream, reader, &method, path.split('?').next().unwrap_or(&path), &headers, &save_dir, &static_dir);
    }
    if path.starts_with("/api/ancient/saves") {
        return serve_saves(stream, reader, &method, &path, &headers, &save_dir);
    }
    if path.starts_with("/api/ancient/maps") {
        return serve_maps(
            stream,
            reader,
            &method,
            &path,
            &headers,
            &save_dir.join("maps"),
            &static_dir.join("ancient/bundled-maps"),
        );
    }
    let head_only = method.eq_ignore_ascii_case("HEAD");
    serve_static(stream, &path, &static_dir, head_only)
}

fn default_save_dir() -> PathBuf {
    if let Some(base) = std::env::var_os("APPDATA") {
        return PathBuf::from(base).join("HexWargame").join("AncientSaves");
    }
    if cfg!(target_os = "macos") {
        return PathBuf::from(std::env::var_os("HOME").unwrap_or_default())
            .join("Library/Application Support/HexWargame/AncientSaves");
    }
    if let Some(base) = std::env::var_os("XDG_DATA_HOME") {
        return PathBuf::from(base).join("hex-wargame/ancient-saves");
    }
    PathBuf::from(std::env::var_os("HOME").unwrap_or_default())
        .join(".local/share/hex-wargame/ancient-saves")
}

fn serve_saves(
    mut stream: TcpStream,
    mut reader: BufReader<TcpStream>,
    method: &str,
    path: &str,
    headers: &HashMap<String, String>,
    dir: &Path,
) -> std::io::Result<()> {
    if !stream.peer_addr()?.ip().is_loopback() {
        return write_simple(&mut stream, 403, "text/plain; charset=utf-8", b"local only");
    }
    if let Some(origin) = headers.get("origin") {
        let host = headers.get("host").map(String::as_str).unwrap_or("");
        if origin != &format!("http://{host}") {
            return write_simple(&mut stream, 403, "text/plain; charset=utf-8", b"bad origin");
        }
    }
    let path = path.split('?').next().unwrap_or(path);
    if path == "/api/ancient/saves" && method == "GET" {
        let slots: Vec<serde_json::Value> = (1..=8).map(|slot| {
            let file = dir.join(format!("slot-{slot}.json"));
            match std::fs::read_to_string(file).ok().and_then(|s| serde_json::from_str::<serde_json::Value>(&s).ok()) {
                Some(v) => serde_json::json!({"slot":slot,"scenarioId":v["scenarioId"],"scenarioName":v["scenarioName"],"turn":v["turn"],"savedAt":v["savedAt"],"playerTeam":v["playerTeam"],"battleMode":v["battleMode"]}),
                None => serde_json::json!({"slot":slot}),
            }
        }).collect();
        return write_simple(&mut stream, 200, "application/json; charset=utf-8", serde_json::to_string(&slots).unwrap().as_bytes());
    }
    let slot = path.strip_prefix("/api/ancient/saves/").and_then(|s| s.parse::<u8>().ok());
    let Some(slot @ 1..=8) = slot else {
        return write_simple(&mut stream, 404, "text/plain; charset=utf-8", b"slot not found");
    };
    let file = dir.join(format!("slot-{slot}.json"));
    match method {
        "GET" => match std::fs::read(&file) {
            Ok(body) => write_simple(&mut stream, 200, "application/json; charset=utf-8", &body),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => write_simple(&mut stream, 404, "text/plain; charset=utf-8", b"empty slot"),
            Err(e) => Err(e),
        },
        "PUT" => {
            let len = headers.get("content-length").and_then(|s| s.parse::<usize>().ok()).unwrap_or(0);
            if len == 0 || len > 16 * 1024 * 1024 {
                return write_simple(&mut stream, 413, "text/plain; charset=utf-8", b"invalid size");
            }
            let mut body = vec![0; len];
            reader.read_exact(&mut body)?;
            let value: serde_json::Value = match serde_json::from_slice::<serde_json::Value>(&body) {
                Ok(v) if v["format"] == "hex_wargame.ancient.save.v1" => v,
                _ => return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"invalid save"),
            };
            if !value["turn"].is_u64() || !value["scenarioName"].is_string() || !value["game"].is_object() {
                return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"invalid save");
            }
            std::fs::create_dir_all(dir)?;
            let temp = dir.join(format!("slot-{slot}.json.tmp"));
            std::fs::write(&temp, body)?;
            if let Err(e) = std::fs::rename(&temp, &file) {
                if e.kind() == std::io::ErrorKind::AlreadyExists {
                    std::fs::remove_file(&file)?;
                    std::fs::rename(&temp, &file)?;
                } else { return Err(e); }
            }
            write_simple(&mut stream, 200, "application/json; charset=utf-8", b"{\"ok\":true}")
        }
        _ => write_simple(&mut stream, 405, "text/plain; charset=utf-8", b"method not allowed"),
    }
}

fn serve_maps(
    mut stream: TcpStream,
    mut reader: BufReader<TcpStream>,
    method: &str,
    path: &str,
    headers: &HashMap<String, String>,
    dir: &Path,
    bundled_dir: &Path,
) -> std::io::Result<()> {
    if !stream.peer_addr()?.ip().is_loopback() {
        return write_simple(&mut stream, 403, "text/plain; charset=utf-8", b"local only");
    }
    if let Some(origin) = headers.get("origin") {
        let host = headers.get("host").map(String::as_str).unwrap_or("");
        if origin != &format!("http://{host}") {
            return write_simple(&mut stream, 403, "text/plain; charset=utf-8", b"bad origin");
        }
    }
    let path = path.split('?').next().unwrap_or(path);
    if path == "/api/ancient/maps" && method == "GET" {
        let mut maps = BTreeMap::<String, serde_json::Value>::new();
        // The installed maps provide a baseline; personal edits with the same ID win.
        for source in [bundled_dir, dir] {
            if let Ok(entries) = std::fs::read_dir(source) {
                for entry in entries.flatten() {
                    if entry.path().extension().and_then(|ext| ext.to_str()) != Some("json") { continue; }
                    let Ok(body) = std::fs::read(entry.path()) else { continue };
                    let Ok(map) = serde_json::from_slice::<serde_json::Value>(&body) else { continue };
                    let Some(id) = map["scenarioId"].as_str() else { continue };
                    if entry.path().file_stem().and_then(|stem| stem.to_str()) != Some(id) ||
                        !map["name"].is_string() { continue; }
                    maps.insert(id.to_string(), serde_json::json!({"scenarioId":id, "name":map["name"]}));
                }
            }
        }
        let records: Vec<_> = maps.into_values().collect();
        return write_simple(&mut stream, 200, "application/json; charset=utf-8", serde_json::to_string(&records).unwrap().as_bytes());
    }
    let Some(id) = path.strip_prefix("/api/ancient/maps/") else {
        return write_simple(&mut stream, 404, "text/plain; charset=utf-8", b"map not found");
    };
    if id.is_empty() || id.len() > 40 || !id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-') {
        return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"invalid map id");
    }
    let file = dir.join(format!("{id}.json"));
    match method {
        "GET" => {
            let body = match std::fs::read(&file) {
                Ok(body) => Ok(body),
                Err(e) if e.kind() == std::io::ErrorKind::NotFound =>
                    std::fs::read(bundled_dir.join(format!("{id}.json"))),
                Err(e) => Err(e),
            };
            match body {
                Ok(body) => write_simple(&mut stream, 200, "application/json; charset=utf-8", &body),
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => write_simple(&mut stream, 404, "text/plain; charset=utf-8", b"map not found"),
                Err(e) => Err(e),
            }
        }
        "PUT" => {
            let len = headers.get("content-length").and_then(|s| s.parse::<usize>().ok()).unwrap_or(0);
            if len == 0 || len > 16 * 1024 * 1024 {
                return write_simple(&mut stream, 413, "text/plain; charset=utf-8", b"invalid size");
            }
            let mut body = vec![0; len];
            reader.read_exact(&mut body)?;
            let value = match serde_json::from_slice::<serde_json::Value>(&body) {
                Ok(v) if v["format"] == "hex_wargame.ancient.v2" && v["scenarioId"] == id &&
                    v["name"].is_string() && v["terrain"].is_array() && v["units"].is_array() => v,
                _ => return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"invalid map"),
            };
            if value["name"].as_str().unwrap_or("").len() > 240 {
                return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"invalid map name");
            }
            std::fs::create_dir_all(dir)?;
            let temp = dir.join(format!("{id}.json.tmp"));
            std::fs::write(&temp, body)?;
            if let Err(e) = std::fs::rename(&temp, &file) {
                if e.kind() == std::io::ErrorKind::AlreadyExists {
                    std::fs::remove_file(&file)?;
                    std::fs::rename(&temp, &file)?;
                } else { return Err(e); }
            }
            write_simple(&mut stream, 200, "application/json; charset=utf-8", b"{\"ok\":true}")
        }
        "DELETE" => match std::fs::remove_file(&file) {
            Ok(()) => write_simple(&mut stream, 200, "application/json; charset=utf-8", b"{\"ok\":true}"),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound && bundled_dir.join(format!("{id}.json")).is_file() =>
                write_simple(&mut stream, 200, "application/json; charset=utf-8", b"{\"ok\":true}"),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => write_simple(&mut stream, 404, "text/plain; charset=utf-8", b"map not found"),
            Err(e) => Err(e),
        },
        _ => write_simple(&mut stream, 405, "text/plain; charset=utf-8", b"method not allowed"),
    }
}

// ---------------------------------------------------------------------------
// 静态文件
// ---------------------------------------------------------------------------

fn content_type(path: &Path) -> &'static str {
    match path.extension().and_then(|e| e.to_str()).unwrap_or("") {
        "html" | "htm" => "text/html; charset=utf-8",
        "js" | "mjs" => "text/javascript; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "json" => "application/json; charset=utf-8",
        "svg" => "image/svg+xml",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "webp" => "image/webp",
        "ico" => "image/x-icon",
        "woff2" => "font/woff2",
        "ttf" => "font/ttf",
        "wasm" => "application/wasm",
        "txt" | "md" => "text/plain; charset=utf-8",
        _ => "application/octet-stream",
    }
}

fn percent_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out: Vec<u8> = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            let hex = std::str::from_utf8(&bytes[i + 1..i + 3]).unwrap_or("");
            if let Ok(v) = u8::from_str_radix(hex, 16) {
                out.push(v);
                i += 3;
                continue;
            }
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).to_string()
}

fn serve_static(mut stream: TcpStream, raw_path: &str, dir: &Path, head_only: bool) -> std::io::Result<()> {
    let path = raw_path.split(['?', '#']).next().unwrap_or("/");
    let decoded = percent_decode(path);
    // 目录穿越防护：拒绝任何含 ".." 的路径。
    if decoded.contains("..") {
        return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"bad path");
    }
    let rel = decoded.trim_start_matches('/');
    let rel = if rel.is_empty() { "index.html" } else { rel };
    let mut file_path = dir.join(rel);
    if file_path.is_dir() {
        file_path = file_path.join("index.html");
    }
    match std::fs::read(&file_path) {
        Ok(bytes) => {
            let ct = content_type(&file_path);
            // 前端代码不缓存，vendor 目录长缓存：改前端代码刷新即生效。
            let cache = if rel.starts_with("vendor/") {
                "public, max-age=86400"
            } else {
                "no-cache, no-store, must-revalidate"
            };
            let header = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: {ct}\r\nContent-Length: {}\r\nCache-Control: {cache}\r\nConnection: close\r\n\r\n",
                bytes.len()
            );
            stream.write_all(header.as_bytes())?;
            if !head_only {
                stream.write_all(&bytes)?;
            }
            stream.flush()
        }
        Err(_) => {
            let body = format!("404 Not Found: {rel}");
            write_simple(&mut stream, 404, "text/plain; charset=utf-8", body.as_bytes())
        }
    }
}

fn write_simple(stream: &mut TcpStream, code: u16, ct: &str, body: &[u8]) -> std::io::Result<()> {
    let reason = if code == 200 { "OK" } else { "Not Found" };
    let header = format!(
        "HTTP/1.1 {code} {reason}\r\nContent-Type: {ct}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        body.len()
    );
    stream.write_all(header.as_bytes())?;
    stream.write_all(body)?;
    stream.flush()
}

// ---------------------------------------------------------------------------
// WebSocket
// ---------------------------------------------------------------------------

fn serve_websocket(
    mut stream: TcpStream,
    mut reader: BufReader<TcpStream>,
    hub: Arc<Hub>,
    cmd_tx: Sender<NetCommand>,
    headers: &HashMap<String, String>,
) -> std::io::Result<()> {
    let key = headers.get("sec-websocket-key").cloned().unwrap_or_default();
    if key.is_empty() {
        return write_simple(&mut stream, 400, "text/plain; charset=utf-8", b"missing key");
    }
    let accept = ws_accept_key(&key);
    let resp = format!(
        "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: {accept}\r\n\r\n"
    );
    let mut writer = stream.try_clone()?;
    writer.write_all(resp.as_bytes())?;
    writer.flush()?;

    let (id, rx) = hub.register();
    let alive = Arc::new(AtomicBool::new(true));
    // 写线程：把广播消息按 WebSocket 文本帧发出。
    let write_alive = Arc::clone(&alive);
    let read_alive = Arc::clone(&alive);
    let writer_thread = std::thread::Builder::new()
        .name("web3d-ws-write".into())
        .spawn(move || {
            while write_alive.load(Ordering::SeqCst) {
                match rx.recv_timeout(Duration::from_millis(500)) {
                    Ok(text) => {
                        if write_frame(&mut writer, 0x1, text.as_bytes()).is_err() {
                            break;
                        }
                    }
                    Err(mpsc::RecvTimeoutError::Timeout) => {
                        if write_frame(&mut writer, 0x9, b"ka").is_err() {
                            break;
                        }
                    }
                    Err(mpsc::RecvTimeoutError::Disconnected) => break,
                }
            }
            alive.store(false, Ordering::SeqCst);
        })?;

    // 读循环：客户端命令 → 游戏主循环。
    let result = loop {
        match read_frame(&mut reader) {
            Ok(Some((0x1, payload))) | Ok(Some((0x2, payload))) => {
                let text = String::from_utf8_lossy(&payload).to_string();
                if cmd_tx.send(NetCommand::Json { client: id, text }).is_err() {
                    break Ok(());
                }
            }
            Ok(Some((0x8, _))) | Ok(None) => break Ok(()),
            Ok(Some((0x9, payload))) => {
                // ping → pong 由写线程负责心跳；这里直接回显避免依赖顺序。
                let _ = payload;
            }
            Ok(Some(_)) => {}
            Err(e) => break Err(e),
        }
    };
    read_alive.store(false, Ordering::SeqCst);
    hub.unregister(id);
    let _ = cmd_tx.send(NetCommand::Closed { client: id });
    let _ = writer_thread.join();
    result
}

/// Sec-WebSocket-Accept = base64(sha1(key + GUID))
fn ws_accept_key(key: &str) -> String {
    let mut input = String::from(key);
    input.push_str("258EAFA5-E914-47DA-95CA-C5AB0DC85B11");
    base64_encode(&sha1(input.as_bytes()))
}

fn read_frame(reader: &mut BufReader<TcpStream>) -> std::io::Result<Option<(u8, Vec<u8>)>> {
    let mut head = [0u8; 2];
    match reader.read_exact(&mut head) {
        Ok(()) => {}
        Err(e) if e.kind() == std::io::ErrorKind::UnexpectedEof => return Ok(None),
        Err(e) => return Err(e),
    }
    let opcode = head[0] & 0x0f;
    let masked = head[1] & 0x80 != 0;
    let mut len = (head[1] & 0x7f) as u64;
    if len == 126 {
        let mut b = [0u8; 2];
        reader.read_exact(&mut b)?;
        len = u16::from_be_bytes(b) as u64;
    } else if len == 127 {
        let mut b = [0u8; 8];
        reader.read_exact(&mut b)?;
        len = u64::from_be_bytes(b);
    }
    if len > 32 * 1024 * 1024 {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "frame too large"));
    }
    let mut mask = [0u8; 4];
    if masked {
        reader.read_exact(&mut mask)?;
    }
    let mut payload = vec![0u8; len as usize];
    reader.read_exact(&mut payload)?;
    if masked {
        for (i, b) in payload.iter_mut().enumerate() {
            *b ^= mask[i % 4];
        }
    }
    Ok(Some((opcode, payload)))
}

fn write_frame(stream: &mut TcpStream, opcode: u8, payload: &[u8]) -> std::io::Result<()> {
    let mut header: Vec<u8> = Vec::with_capacity(10);
    header.push(0x80 | opcode);
    let len = payload.len();
    if len < 126 {
        header.push(len as u8);
    } else if len <= u16::MAX as usize {
        header.push(126);
        header.extend_from_slice(&(len as u16).to_be_bytes());
    } else {
        header.push(127);
        header.extend_from_slice(&(len as u64).to_be_bytes());
    }
    stream.write_all(&header)?;
    stream.write_all(payload)?;
    stream.flush()
}

// ---------------------------------------------------------------------------
// SHA-1 / Base64（避免引入依赖，仅用于 WebSocket 握手）
// ---------------------------------------------------------------------------

pub fn sha1(data: &[u8]) -> [u8; 20] {
    let mut h: [u32; 5] = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0];
    let ml = (data.len() as u64).wrapping_mul(8);
    let mut msg = data.to_vec();
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&ml.to_be_bytes());
    let mut w = [0u32; 80];
    for chunk in msg.chunks_exact(64) {
        for i in 0..16 {
            w[i] = u32::from_be_bytes([chunk[i * 4], chunk[i * 4 + 1], chunk[i * 4 + 2], chunk[i * 4 + 3]]);
        }
        for i in 16..80 {
            w[i] = (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]).rotate_left(1);
        }
        let (mut a, mut b, mut c, mut d, mut e) = (h[0], h[1], h[2], h[3], h[4]);
        for (i, wi) in w.iter().enumerate() {
            let (f, k) = match i {
                0..=19 => ((b & c) | ((!b) & d), 0x5A827999u32),
                20..=39 => (b ^ c ^ d, 0x6ED9EBA1),
                40..=59 => ((b & c) | (b & d) | (c & d), 0x8F1BBCDC),
                _ => (b ^ c ^ d, 0xCA62C1D6),
            };
            let temp = a
                .rotate_left(5)
                .wrapping_add(f)
                .wrapping_add(e)
                .wrapping_add(k)
                .wrapping_add(*wi);
            e = d;
            d = c;
            c = b.rotate_left(30);
            b = a;
            a = temp;
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
    }
    let mut out = [0u8; 20];
    for (i, v) in h.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&v.to_be_bytes());
    }
    out
}

pub fn base64_encode(data: &[u8]) -> String {
    const T: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity((data.len() + 2) / 3 * 4);
    for chunk in data.chunks(3) {
        let b = [chunk[0], *chunk.get(1).unwrap_or(&0), *chunk.get(2).unwrap_or(&0)];
        let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | b[2] as u32;
        out.push(T[(n >> 18) as usize & 63] as char);
        out.push(T[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 { T[(n >> 6) as usize & 63] as char } else { '=' });
        out.push(if chunk.len() > 2 { T[n as usize & 63] as char } else { '=' });
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rfc3174_sha1_vectors() {
        assert_eq!(
            base64_encode(&sha1(b"abc")),
            "qZk+NkcGgWq6PiVxeFDCbJzQ2J0="
        );
        assert_eq!(
            base64_encode(&sha1(b"")),
            "2jmj7l5rSw0yVb/vlWAYkK/YBwk="
        );
    }

    #[test]
    fn websocket_handshake_rfc6455_example() {
        // RFC 6455 §1.3 示例
        assert_eq!(ws_accept_key("dGhlIHNhbXBsZSBub25jZQ=="), "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=");
    }

    #[test]
    fn base64_padding() {
        assert_eq!(base64_encode(b"f"), "Zg==");
        assert_eq!(base64_encode(b"fo"), "Zm8=");
        assert_eq!(base64_encode(b"foo"), "Zm9v");
        assert_eq!(base64_encode(b"foob"), "Zm9vYg==");
        assert_eq!(base64_encode(b"fooba"), "Zm9vYmE=");
        assert_eq!(base64_encode(b"foobar"), "Zm9vYmFy");
    }
}
