//! Independent low-latency order translation gateway. No training or game-state access.
use serde_json::{json,Value};
use std::collections::HashMap;
use std::io::{BufReader,Read,Write};
use std::net::TcpStream;
use std::path::Path;
use std::process::{Command,Stdio};
use std::sync::atomic::{AtomicUsize,Ordering};
use std::time::Instant;
static ACTIVE:AtomicUsize=AtomicUsize::new(0);
struct Slot;
impl Drop for Slot {fn drop(&mut self){ACTIVE.fetch_sub(1,Ordering::SeqCst);}}
fn config(dir:&Path)->Value {let mut v=std::fs::read(dir.join("order-officer.json")).ok().and_then(|b|serde_json::from_slice::<Value>(&b).ok()).filter(Value::is_object).unwrap_or_else(||json!({}));
 for (key,env) in [("baseURL","AI_ORDER_OFFICER_API_BASE"),("model","AI_ORDER_OFFICER_MODEL"),("apiKey","AI_ORDER_OFFICER_API_KEY"),("keyFile","AI_ORDER_OFFICER_KEY_FILE")] {if let Ok(s)=std::env::var(env){if !s.is_empty(){v[key]=json!(s);}}}
 if v["baseURL"].is_null(){v["baseURL"]=json!("https://api.deepseek.com");}if v["model"].is_null(){v["model"]=json!("deepseek-flash");}if v["provider"].is_null(){v["provider"]=json!("deepseek");}if v["timeoutSeconds"].is_null(){v["timeoutSeconds"]=json!(15);}v
}
fn credential(v:&Value)->Option<String>{
 let raw=v["apiKey"].as_str().filter(|s|!s.trim().is_empty()).map(str::to_string).or_else(||v["keyFile"].as_str().and_then(|p|std::fs::read_to_string(p).ok())).or_else(||if ["https://api.deepseek.com","https://api.deepseek.com/","https://api.deepseek.com/v1"].contains(&v["baseURL"].as_str().unwrap_or("")){std::env::var("DEEPSEEK_API_KEY").ok()}else{None})?;
 let key=raw.trim().trim_matches(['\"','\'']).to_string();if key.is_empty()||key.len()>512||key.chars().any(char::is_whitespace){None}else{Some(key)}
}
fn valid_config(v:&Value)->Result<(),&'static str>{
 let url=v["baseURL"].as_str().ok_or("API地址无效")?;let provider=v["provider"].as_str().ok_or("请选择接口类型")?;let model=v["model"].as_str().ok_or("模型无效")?;
 if url.len()>240||url.contains(['\n','\r','\"','\\','?','#','@'])||!(url.starts_with("https://")||url.starts_with("http://127.0.0.1:")||url.starts_with("http://localhost:")){return Err("使用HTTPS接口地址，或本机测试地址");}
 if !["deepseek","compatible"].contains(&provider)||model.is_empty()||model.len()>80||model.contains(['\n','\r']){return Err("模型或接口类型无效");}
 if provider=="deepseek"&&!["deepseek-flash","deepseek-v4-flash","deepseek-v4-pro","deepseek-chat"].contains(&model){return Err("请选择支持非推理模式的DeepSeek模型");}
 if provider=="compatible"&&["reasoner","thinking","deepseek-r1"].iter().any(|s|model.to_lowercase().contains(s)){return Err("传令官需要非推理模型");}
 if !v["timeoutSeconds"].as_u64().is_some_and(|n|(3..=30).contains(&n)){return Err("超时应为3到30秒");}Ok(())
}
fn public_config(v:&Value)->Value {json!({"baseURL":v["baseURL"],"model":v["model"],"provider":v["provider"],"timeoutSeconds":v["timeoutSeconds"],"configured":credential(v).is_some(),"credentialSource":if v["keyFile"].is_string(){"本机凭证文件"}else{"本机密钥配置"}})}
fn reply(stream:&mut TcpStream,status:u16,value:Value)->std::io::Result<()>{let body=serde_json::to_vec(&value).unwrap();write!(stream,"HTTP/1.1 {status} OK\r\nContent-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",body.len())?;stream.write_all(&body)}
fn compact_context(raw:&Value)->Value {let mut out=json!({});for k in ["team","turn","selectedCount","forward","ownKinds","visibleEnemyKinds","landmarks","coordinates","contextBytes","unitRegistry"]{if let Some(v)=raw.get(k){out[k]=v.clone();}}if let Some(b)=raw.get("battlefield").filter(|v|v.is_object()){let mut view=json!({});for k in ["rules","v","map","selectedIds","own","enemy","groups","frames","fronts","cells","terrainLegend","actions","constraints","pending","knowledge","logistics","truncated"]{if let Some(v)=b.get(k){view[k]=v.clone();}}if view.to_string().len()<=12000{out["battlefield"]=view;}}out}
fn payload(config:&Value,input:&Value,prompt:&str)->Value {let mut body=json!({"model":config["model"],"messages":[{"role":"system","content":prompt},{"role":"user","content":json!({"command":input["text"],"context":compact_context(&input["context"])}).to_string()}],"stream":false,"temperature":0,"max_tokens":1200,"response_format":{"type":"json_object"}});
 if config["provider"]=="deepseek"&&config["model"]!="deepseek-chat"{body["thinking"]=json!({"type":"disabled"});}body
}
pub fn serve(mut stream:TcpStream,mut reader:BufReader<TcpStream>,method:&str,path:&str,headers:&HashMap<String,String>,dir:&Path,static_dir:&Path)->std::io::Result<()>{
 if !stream.peer_addr()?.ip().is_loopback(){return reply(&mut stream,403,json!({"error":"仅本机可用"}));}
 if let Some(origin)=headers.get("origin"){if origin!=&format!("http://{}",headers.get("host").map(String::as_str).unwrap_or("")){return reply(&mut stream,403,json!({"error":"拒绝跨站请求"}));}}
 let mut cfg=config(dir);if method=="GET"&&path=="/api/ancient/order-officer/config"{return reply(&mut stream,200,public_config(&cfg));}
 if !["POST","PUT"].contains(&method){return reply(&mut stream,405,json!({"error":"不支持该请求"}));}
 let len=headers.get("content-length").and_then(|s|s.parse::<usize>().ok()).unwrap_or(0);if len==0||len>16384{return reply(&mut stream,413,json!({"error":"请求过大"}));}reader.get_mut().set_read_timeout(Some(std::time::Duration::from_secs(5)))?;let mut bytes=vec![0;len];reader.read_exact(&mut bytes)?;let input:Value=match serde_json::from_slice(&bytes){Ok(v)=>v,Err(_)=>return reply(&mut stream,400,json!({"error":"请求格式无效"}))};
 if method=="PUT"&&path=="/api/ancient/order-officer/config" {
  if !input.is_object()||input.as_object().unwrap().keys().any(|k|!["baseURL","model","provider","timeoutSeconds","apiKey","keyFile"].contains(&k.as_str())){return reply(&mut stream,400,json!({"error":"配置字段无效"}));}
  for (k,v) in input.as_object().unwrap(){if k=="apiKey"&&v.as_str().unwrap_or("").is_empty(){continue;}cfg[k]=v.clone();}
  if let Err(e)=valid_config(&cfg){return reply(&mut stream,400,json!({"error":e}));}
  if cfg["apiKey"].as_str().is_some_and(|s|s.len()>512||s.contains(['\n','\r'])){return reply(&mut stream,400,json!({"error":"密钥格式无效"}));}
  std::fs::create_dir_all(dir)?;let path=dir.join("order-officer.json");let mut opts=std::fs::OpenOptions::new();opts.write(true).create(true).truncate(true);
  #[cfg(unix)] {use std::os::unix::fs::OpenOptionsExt;opts.mode(0o600);}
  let mut file=opts.open(&path)?;file.write_all(serde_json::to_string_pretty(&cfg).unwrap().as_bytes())?;
  #[cfg(unix)] {use std::os::unix::fs::PermissionsExt;std::fs::set_permissions(&path,std::fs::Permissions::from_mode(0o600))?;}
  return reply(&mut stream,200,public_config(&cfg));
 }
 if method!="POST"||path!="/api/ancient/order-officer/parse"{return reply(&mut stream,404,json!({"error":"接口不存在"}));}
 if input["text"].as_str().is_none_or(|s|s.is_empty()||s.chars().count()>500)||!input["context"].is_object(){return reply(&mut stream,400,json!({"error":"请输入不超过500字的命令"}));}
 if let Err(e)=valid_config(&cfg){return reply(&mut stream,400,json!({"error":e}));}let Some(key)=credential(&cfg)else{return reply(&mut stream,503,json!({"error":"尚未配置API密钥，请打开游戏设置"}));};
 if ACTIVE.fetch_add(1,Ordering::SeqCst)>=2{ACTIVE.fetch_sub(1,Ordering::SeqCst);return reply(&mut stream,429,json!({"error":"已有请求处理中；简单命令仍可本地执行"}));}let _slot=Slot;
 let prompt=std::fs::read_to_string(static_dir.join("ancient/order-officer-prompt.txt"))?;let body=payload(&cfg,&input,&prompt);let url=format!("{}/chat/completions",cfg["baseURL"].as_str().unwrap().trim_end_matches('/'));
 // Secrets and request data use stdin, never process arguments or a project file.
 let quote=|s:&str|serde_json::to_string(s).unwrap();let curl_config=format!("silent\nshow-error\nrequest = \"POST\"\nurl = {}\nheader = {}\nheader = \"Content-Type: application/json\"\ndata = {}\nmax-time = {}\nconnect-timeout = 5\nmax-filesize = 65536\nwrite-out = \"\\n%{{http_code}}\"\n",quote(&url),quote(&format!("Authorization: Bearer {key}")),quote(&body.to_string()),cfg["timeoutSeconds"].as_u64().unwrap());
 let start=Instant::now();let output=(||->std::io::Result<std::process::Output>{let mut child=Command::new("curl").args(["--config","-"]).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped()).spawn()?;child.stdin.take().unwrap().write_all(curl_config.as_bytes())?;child.wait_with_output()})();
 let output=match output{Ok(o)=>o,Err(_)=>return reply(&mut stream,502,json!({"error":"本机HTTP客户端不可用"}))};let elapsed=start.elapsed().as_secs_f64()*1000.;
 if !output.status.success(){return reply(&mut stream,504,json!({"error":"API请求超时或网络失败；未执行任何指令","apiMs":elapsed}));}
 let raw=String::from_utf8_lossy(&output.stdout);let (body,code)=raw.rsplit_once('\n').unwrap_or(("","0"));if code!="200"{return reply(&mut stream,502,json!({"error":format!("API返回HTTP {code}；请检查设置、余额或稍后重试"),"apiMs":elapsed}));}
 let response:Value=match serde_json::from_str(body){Ok(v)=>v,Err(_)=>return reply(&mut stream,502,json!({"error":"API返回了无效JSON","apiMs":elapsed}))};let content=response["choices"][0]["message"]["content"].as_str().unwrap_or("");
 let command:Value=match serde_json::from_str(content){Ok(v)=>v,Err(_)=>return reply(&mut stream,502,json!({"error":"模型未返回合法结构化命令；未执行任何动作","apiMs":elapsed}))};
 reply(&mut stream,200,json!({"command":command,"apiMs":elapsed,"model":cfg["model"],"usage":response["usage"],"reasoningCharacters":response["choices"][0]["message"]["reasoning_content"].as_str().unwrap_or("").chars().count()}))
}
#[cfg(test)] mod tests {use super::*;
 #[test] fn thinking_is_disabled_only_for_supported_model(){let c=json!({"provider":"deepseek","model":"deepseek-flash"});let p=payload(&c,&json!({"text":"前进","context":{}}),"json");assert_eq!(p["thinking"]["type"],"disabled");let p=payload(&json!({"provider":"compatible","model":"small-chat"}),&json!({"text":"前进","context":{}}),"json");assert!(p.get("thinking").is_none());assert!(p.get("reasoning_effort").is_none());}
 #[test] fn hidden_state_and_training_fields_do_not_enter_payload(){let v=compact_context(&json!({"turn":2,"ownKinds":{"archer":3},"hiddenEnemies":[1],"fullState":"secret","future":"bad","teacherHistory":[]}));assert_eq!(v,json!({"turn":2,"ownKinds":{"archer":3}}));}
 #[test] fn battlefield_context_is_whitelisted_and_bounded(){let v=compact_context(&json!({"battlefield":{"own":[{"id":"u1","ap":2}],"pending":[],"fullState":"secret","teacherHistory":[1]}}));assert_eq!(v["battlefield"],json!({"own":[{"id":"u1","ap":2}],"pending":[]}));let v=compact_context(&json!({"turn":3,"battlefield":{"own":[{"name":"x".repeat(12001)}]}}));assert!(v.get("battlefield").is_none());assert_eq!(v["turn"],3);}
 #[test] fn secret_is_never_returned_to_the_browser(){let p=public_config(&json!({"apiKey":"test-key","model":"deepseek-flash"}));assert_eq!(p["configured"],true);assert!(p.get("apiKey").is_none());assert!(!p.to_string().contains("test-key"));}
 #[test] fn bad_endpoints_and_reasoners_are_rejected(){for (url,model) in [("file:///etc/passwd","deepseek-flash"),("http://example.com","deepseek-flash"),("https://user:pass@example.com","deepseek-flash"),("https://api.deepseek.com","deepseek-reasoner")]{assert!(valid_config(&json!({"baseURL":url,"provider":"deepseek","model":model,"timeoutSeconds":15})).is_err());}}
}
