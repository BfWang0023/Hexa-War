//! 状态快照与事件的 JSON 序列化：把 `GameState` 转成 3D 前端需要的紧凑结构。
//!
//! 坐标一律使用 **0 基奇数列偏移坐标 `[col, row]`**（与既有 GUI 的 `hex.rs`
//! 约定一致，前端再自行换算为轴向/世界坐标）。

use hex_wargame::game::{BattleEventKind, GameState, UiEvent, UiFireEvent};
use hex_wargame::hex::{self, Hex};
use hex_wargame::unit::{Team, Unit, UnitKind};
use serde_json::{json, Value};

use super::host::Host;

/// 一格的坐标 → `[col, row]`。
pub fn hx(h: Hex) -> Value {
    let (c, r) = hex::offset_from_axial(h);
    json!([c, r])
}

fn team_str(t: Team) -> &'static str {
    match t {
        Team::Player => "blue",
        Team::Ai => "red",
    }
}

/// 地形位掩码：1=岩石 2=森林 4=楼房 8=水域 16=道路 32=桥梁。
pub const T_ROCK: u32 = 1;
pub const T_FOREST: u32 = 2;
pub const T_BUILDING: u32 = 4;
pub const T_WATER: u32 = 8;
pub const T_ROAD: u32 = 16;
pub const T_BRIDGE: u32 = 32;

/// 每格地形位掩码（按行输出十六进制字符串，**每格 2 个字符**）。
///
/// 注意：位掩码取值 0..=63，必须用两位十六进制；早期版本每格只写 1 个字符并用
/// `char::from_digit(m, 16)`，而它只支持 0..15——于是**道路(16)/桥梁(32) 以及任何
/// 叠加了它们的格子都会被编成 '0'**，表现为「道路格和普通平地一模一样」。
pub fn terrain_rows(game: &GameState) -> Vec<String> {
    let bridges = game.map.bridge_hexes();
    let mut rows = Vec::with_capacity(game.map.rows as usize);
    for row in 0..game.map.rows {
        let mut line = String::with_capacity(game.map.cols as usize);
        for col in 0..game.map.cols {
            let h = hex::axial_from_offset(col, row);
            let mut m = 0u32;
            if game.map.obstacles.contains(&h) {
                m |= T_ROCK;
            }
            if game.map.forests.contains(&h) {
                m |= T_FOREST;
            }
            if game.map.buildings.contains(&h) {
                m |= T_BUILDING;
            }
            if game.map.water.contains(&h) {
                m |= T_WATER;
            }
            if game.map.roads.contains(&h) {
                m |= T_ROAD;
            }
            if bridges.contains(&h) {
                m |= T_BRIDGE;
            }
            line.push_str(&format!("{:02x}", m));
        }
        rows.push(line);
    }
    rows
}

/// 全部兵种的静态属性表（只发一次；前端据此渲染图标、属性面板、招募面板）。
pub fn kinds_table() -> Value {
    let mut kinds: Vec<UnitKind> = UnitKind::all_recruitable().to_vec();
    kinds.push(UnitKind::Headquarters);
    let arr: Vec<Value> = kinds
        .iter()
        .map(|k| {
            let k = *k;
            let carries: Vec<&str> = kinds
                .iter()
                .filter(|c| k.can_load_cargo(**c))
                .map(|c| c.token())
                .collect();
            json!({
                "token": k.token(),
                "name": k.name(),
                "recruit": k.recruit_cost(),
                "hp": k.max_hp(),
                "move": k.movement(),
                "vision": k.vision(),
                "range": k.range(),
                "attack": k.attack(),
                "armor": k.armor(),
                "hit": k.hit_rate(),
                "actions": k.action_count(),
                "attackCost": k.attack_cost(),
                "ammo": k.max_ammo(),
                "missileAmmo": k.max_missile_ammo(),
                "aaAmmo": k.max_aa_ammo(),
                "capacity": k.capacity(),
                "weight": k.cargo_weight(),
                "value": k.value(),
                "conceal": k.concealment(),
                "needsDeploy": k.needs_deploy(),
                "air": k.is_air(),
                "vehicle": k.is_vehicle(),
                "infantry": k.is_infantry(),
                "foot": k.is_foot(),
                "aa": k.is_aa(),
                "canHitAir": k.can_hit_air(),
                "canHitGround": k.can_hit_ground(),
                "recruitable": k != UnitKind::Headquarters,
                "carries": carries,
                "dualWeapon": matches!(k, UnitKind::AaMgv | UnitKind::EliteInfantry
                    | UnitKind::SpecialForces | UnitKind::Rifleman | UnitKind::Howitzer
                    | UnitKind::Ifv | UnitKind::CavalryIfv | UnitKind::Tank | UnitKind::HeavyTank),
                "secondWeapon": k.max_missile_ammo() > 0,
                "thirdWeapon": k.max_aa_ammo() > 0,
            })
        })
        .collect();
    Value::Array(arr)
}

/// 单个单位的动态状态。
///
/// `own` = 是否本方单位：敌方单位**不发送弹药/模式等内部信息**
/// （与既有的「点击敌军只显示基本属性与血量」规则一致）。
pub fn unit_json(u: &Unit, own: bool, visible: bool, ghost: bool) -> Value {
    let mut v = json!({
        "team": team_str(u.team),
        "label": u.label.to_string(),
        "kind": u.kind.token(),
        "h": hx(u.pos),
        "hp": u.hp,
        "maxHp": u.kind.max_hp(),
        "air": u.kind.is_air(),
        "visible": visible,
        "ghost": ghost,
    });
    if ghost {
        return v;
    }
    let obj = v.as_object_mut().unwrap();
    obj.insert("actions".into(), json!(u.actions_left));
    obj.insert("maxActions".into(), json!(u.kind.action_count()));
    if own {
        obj.insert("ammo".into(), json!(u.ammo));
        obj.insert("maxAmmo".into(), json!(u.kind.max_ammo()));
        obj.insert("missileAmmo".into(), json!(u.missile_ammo));
        obj.insert("maxMissileAmmo".into(), json!(u.kind.max_missile_ammo()));
        obj.insert("aaAmmo".into(), json!(u.aa_ammo));
        obj.insert("maxAaAmmo".into(), json!(u.kind.max_aa_ammo()));
        obj.insert("missileMode".into(), json!(u.missile_mode));
        obj.insert("aaMode".into(), json!(u.aa_mode));
        obj.insert("modeName".into(), json!(u.mode_name()));
        obj.insert("deployed".into(), json!(u.deployed));
        obj.insert("rooftop".into(), json!(u.rooftop));
        obj.insert("flares".into(), json!(u.flares));
        obj.insert("adUses".into(), json!(u.ad_uses));
        obj.insert("suppressed".into(), json!(u.suppressed));
        obj.insert("suppression".into(), json!(u.suppression_stacks));
        obj.insert("effRange".into(), json!(u.eff_range()));
        obj.insert("effHit".into(), json!(u.eff_hit_rate()));
        obj.insert("effAttack".into(), json!(u.eff_attack()));
        obj.insert("weight".into(), json!(u.used_weight()));
        obj.insert("capacity".into(), json!(u.kind.capacity()));
    } else {
        obj.insert("rooftop".into(), json!(u.rooftop));
        obj.insert("suppressed".into(), json!(u.suppressed));
        obj.insert("suppression".into(), json!(u.suppression_stacks));
    }
    if !u.passengers.is_empty() {
        // 乘客：车上的步兵（基本属性 + 血量）
        let ps: Vec<Value> = u
            .passengers
            .iter()
            .map(|p| {
                json!({
                    "label": p.label.to_string(),
                    "kind": p.kind.token(),
                    "hp": p.hp,
                    "maxHp": p.kind.max_hp(),
                    "weight": p.kind.cargo_weight(),
                })
            })
            .collect();
        obj.insert("passengers".into(), Value::Array(ps));
    }
    v
}

/// 一条动画事件。
pub fn ui_event_json(ev: &UiEvent) -> Value {
    match ev {
        UiEvent::Move { team, label, kind, path, air } => json!({
            "k": "move",
            "team": team_str(*team),
            "label": label.to_string(),
            "kind": kind.token(),
            "air": *air,
            "path": path.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
        }),
        UiEvent::Fire(f) => fire_json(f),
    }
}

pub fn fire_json(f: &UiFireEvent) -> Value {
    json!({
        "k": "fire",
        "team": team_str(f.team),
        "label": f.label.to_string(),
        "kind": f.kind.token(),
        "from": hx(f.from),
        "target": hx(f.target),
        "targetTeam": team_str(f.target_team),
        "targetLabel": f.target_label.to_string(),
        "targetKind": f.target_kind.token(),
        "aa": f.aa_mode,
        "missile": f.missile_mode,
        "area": f.area,
        "smoke": f.smoke_shell,
        "blast": f.blast.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
        "hit": f.hit,
        "blocked": f.blocked,
        "killed": f.killed,
        "hpBefore": f.target_hp_before,
        "dmg": f.dmg,
        "killedUnits": f.killed_units.iter().map(|k| json!({
            "h": hx(k.hex),
            "team": team_str(k.team),
            "kind": k.kind.token(),
            "label": k.label.to_string(),
            "hpBefore": k.hp_before,
        })).collect::<Vec<_>>(),
    })
}

/// 结构化战报（击毁 / 据点易手 / 胜负）——前端用于弹出战报提示。
pub fn battle_event_json(game: &GameState, seq_from: u32) -> Vec<Value> {
    game.battle_events
        .iter()
        .filter(|e| e.seq >= seq_from)
        .map(|e| match &e.kind {
            BattleEventKind::Kill(k) => json!({
                "seq": e.seq, "turn": e.turn, "kind": "kill",
                "victimTeam": team_str(k.victim_team),
                "victimLabel": k.victim_label.to_string(),
                "victimKind": k.victim_kind.token(),
                "h": hx(k.victim_pos),
                "passenger": k.passenger,
                "cause": k.cause.cn(),
                "attackerTeam": k.attacker_team.map(team_str),
                "attackerLabel": k.attacker_label.map(|c| c.to_string()),
                "attackerKind": k.attacker_kind.map(|c| c.token()),
            }),
            BattleEventKind::Keypoint { hex, center, from, to, by_label, by_kind } => json!({
                "seq": e.seq, "turn": e.turn, "kind": "keypoint",
                "h": hx(*hex), "center": center,
                "from": team_str(*from), "to": team_str(*to),
                "byLabel": by_label.to_string(), "byKind": by_kind.token(),
            }),
            BattleEventKind::Victory { winner, reason } => json!({
                "seq": e.seq, "turn": e.turn, "kind": "victory",
                "winner": team_str(*winner), "reason": reason,
            }),
        })
        .collect()
}

/// 关卡列表（顶栏「加载地图」用）。
pub fn level_list() -> Value {
    json!([
        {"key": "open", "name": "开阔地遭遇战", "desc": "双方各 100 点，地图中部遭遇"},
        {"key": "village", "name": "村庄防守战", "desc": "玩家 150 点进攻靠山村庄，AI 300 点防守"},
    ])
}

/// 生成一份完整状态快照。
pub fn state_json(host: &Host) -> Value {
    let game = &host.game;
    let viewer = host.viewer;
    let me = viewer;

    // 视野：地形可见格 + 被发现敌军格（试验模式下敌人全可见，视野外标暗）。
    let vis = game.vision(me);
    let revealed: std::collections::BTreeSet<Hex> = vis.terrain.clone();
    let visible_enemies = vis.enemy_units.clone();

    let mut units: Vec<Value> = Vec::new();
    let mut push_unit = |u: &Unit, visible: bool| {
        units.push(unit_json(u, u.team == me, visible, false));
    };
    // 前端默认取消战争迷雾的视觉效果：**双方全部单位都下发**，
    // 是否被侦察到通过 `visible` 标记表达（右下角列表仍按它过滤，
    // 悬停探测面板也据此说明「该格敌人能否被发现」）。
    for u in game.units.values() {
        push_unit(u, u.team == me || visible_enemies.contains(&u.pos));
    }
    for u in game.air_units.values() {
        push_unit(u, u.team == me || visible_enemies.contains(&u.pos));
    }
    // 幽灵（最后已知敌方位置）：仅在非试验模式下显示
    if !game.test_mode {
        if let Some(ghosts) = game.ghosts.get(&me) {
            for (h, (kind, turn)) in ghosts {
                if visible_enemies.contains(h) || game.unit_at(*h).is_some() {
                    continue;
                }
                units.push(json!({
                    "team": team_str(me.opponent()),
                    "label": "?",
                    "kind": kind.token(),
                    "h": hx(*h),
                    "hp": 0,
                    "maxHp": kind.max_hp(),
                    "air": kind.is_air(),
                    "visible": false,
                    "ghost": true,
                    "turn": turn,
                }));
            }
        }
    }
    // 迷雾开火警告
    let alarms: Vec<Value> = game
        .fog_fire_marks
        .get(&me)
        .map(|m| m.keys().map(|h| hx(*h)).collect())
        .unwrap_or_default();

    let keypoints: Vec<Value> = game
        .keypoints
        .iter()
        .map(|(h, k)| {
            json!({
                "h": hx(*h),
                "owner": team_str(k.owner),
                "controller": team_str(k.controller),
                "center": k.center,
            })
        })
        .collect();

    let smoke: Vec<Value> = game
        .smoke
        .iter()
        .map(|(h, t)| json!({"h": hx(*h), "turns": t}))
        .collect();

    let deploy_cells: Vec<Value> = host
        .deploy_highlight_cells()
        .iter()
        .map(|h| hx(*h))
        .collect();

    let hl = host.highlights();
    let selected_unit = host
        .selected
        .and_then(|h| if host.selected_is_air { game.air_units.get(&h) } else { game.units.get(&h) });
    let selected = match host.selected {
        None => Value::Null,
        Some(h) => json!({
            "h": hx(h),
            "air": host.selected_is_air,
        }),
    };

    let notices: Vec<String> = game
        .notices
        .get(&me)
        .cloned()
        .unwrap_or_default();

    let mut state = json!({
        "seq": host.seq,
        "turn": game.turn,
        "phase": team_str(game.phase),
        "viewer": team_str(viewer),
        "deploying": game.deploying,
        "deployDone": {
            "blue": game.deploy_done.get(&Team::Player).copied().unwrap_or(false),
            "red": game.deploy_done.get(&Team::Ai).copied().unwrap_or(false),
        },
        "sustainDeploying": game.sustain_deploying,
        "recruitZoneTurn": game.recruit_zone_turn,
        "testMode": game.test_mode,
        "testPlacing": game.test_placing,
        "testPlaceTeam": team_str(game.test_place_team),
        // 对局是否结束：以宿主确认（finish_game / finish_draw）或规则明确判胜为准。
        // 不能直接用 game.game_over()——像「空中突袭滨海机场」这种玩家开局没有预置
        // 棋子、必须靠招募投入战斗的战役地图，在尚未招募时该谓词为真，会误报「开局即结束」。
        "over": host.game_over.is_some() || game.winner.is_some(),
        "ruleOver": game.game_over(),
        "winner": game.winner.map(team_str),
        "draw": game.is_draw(),
        "result": host.game_over.clone(),
        "points": {
            "blue": game.recruit_points.get(&Team::Player).copied().unwrap_or(0),
            "red": game.recruit_points.get(&Team::Ai).copied().unwrap_or(0),
        },
        "initialPoints": {
            "blue": game.initial_points.get(&Team::Player).copied().unwrap_or(0),
            "red": game.initial_points.get(&Team::Ai).copied().unwrap_or(0),
        },
        "sustain": {
            "on": game.sustain,
            "blue": game.sustain_per_turn.get(&Team::Player).copied().unwrap_or(0),
            "red": game.sustain_per_turn.get(&Team::Ai).copied().unwrap_or(0),
        },
        "level": {
            "key": match game.level {
                hex_wargame::game::Level::OpenField => "open",
                hex_wargame::game::Level::VillageDefense => "village",
                hex_wargame::game::Level::Custom => "custom",
            },
            "name": game.level.name(),
            "mapName": host.map_name.clone(),
        },
        "counts": {
            "blueAlive": game.alive_unit_count(Team::Player),
            "redAlive": game.alive_unit_count(Team::Ai),
            "blueLost": game.battle_events.iter().filter(|e| matches!(&e.kind,
                hex_wargame::game::BattleEventKind::Kill(k) if k.victim_team == Team::Player)).count(),
            "redLost": game.battle_events.iter().filter(|e| matches!(&e.kind,
                hex_wargame::game::BattleEventKind::Kill(k) if k.victim_team == Team::Ai)).count(),
        },
        "hq": {
            "blue": game.hq_pos(Team::Player).map(hx),
            "red": game.hq_pos(Team::Ai).map(hx),
        },
        "playerHq": game.hq_pos(me).map(hx),
        "keypoints": keypoints,
        "smoke": smoke,
        "alarms": alarms,
        "deployCells": deploy_cells,
        "units": units,
        "selected": selected,
        "highlights": {
            "reachable": hl.reachable.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "attackable": hl.attackable.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "blocked": hl.blocked.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "howitzer": hl.howitzer.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "disembark": hl.disembark.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "board": hl.board.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "supply": hl.supply.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
        },
        "modes": {
            "howitzerFire": host.howitzer_fire_mode,
            "simul": host.simul_mode,
            "load": host.load_mode,
            "supply": host.supply_mode,
            "smoke": host.smoke_shot_pending,
            "ranger": host.ranger_mode,
            "expanded": host.expanded,
            "logOpen": host.log_open,
            "helpOpen": host.help_open,
        },
        "simulOrders": host.simul_orders.iter().map(|o| json!({
            "attacker": hx(o.attacker),
            "target": hx(o.target),
            "air": o.air_first,
        })).collect::<Vec<_>>(),
        "pending": {
            "recruit": host.pending_recruit.map(|k| k.token()),
            "cargo": host.pending_cargo.iter().map(|k| k.token()).collect::<Vec<_>>(),
            "disembark": host.pending_disembark.map(|c| c.to_string()),
        },
        "notices": notices,
        "error": host.last_error,
        "busy": host.busy(),
        "aiThinking": host.ai_thinking(),
        "confirm": host.confirm_json(),
        "fog": {
            "revealed": revealed.iter().map(|h| hx(*h)).collect::<Vec<_>>(),
            "dims": host.fog_dims(),
        },
        "unitDetails": selected_unit.map(|u| host.unit_details(u)),
    });

    // 战报事件（增量）
    let be = battle_event_json(game, host.battle_seq_sent + 1);
    if let Some(obj) = state.as_object_mut() {
        obj.insert("battleEvents".into(), Value::Array(be));
        obj.insert(
            "ghosts".into(),
            Value::Array(
                host.ghost_list()
                    .into_iter()
                    .map(|(h, k, t)| json!({"h": hx(h), "kind": k.token(), "turn": t}))
                    .collect(),
            ),
        );
    }
    state
}
