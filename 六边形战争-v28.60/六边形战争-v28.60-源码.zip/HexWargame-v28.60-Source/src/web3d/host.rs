//! 游戏宿主：在 3D 前端进程内运行规则引擎（`hex_wargame` 库），
//! 把原 GUI 的鼠标/键盘操作翻译成 WebSocket JSON 命令，并把状态与动画事件推给浏览器。
//!
//! 本模块**逐条对应** `src/main.rs` 里 `GuiApp` 的交互逻辑（`handle_click` /
//! `try_move_selected` / `after_action` / `end_player_turn` / `drain_ui_events` 等），
//! 但完全去掉了 egui 依赖：动画由浏览器端播放，这里只产出「事件 + 新状态」。

use hex_wargame::ai_router;
use hex_wargame::game::{GameState, Level, SimulOrder, UiEvent, UiFireEvent};
use hex_wargame::hex::{self, Hex};
use hex_wargame::mapdef::CustomMap;
use hex_wargame::unit::{Team, Unit, UnitKind};
use serde_json::{json, Value};
use std::collections::{BTreeSet, HashMap};
use std::path::PathBuf;

use super::snapshot as snap;

/// 命令处理结果：是否需要向所有客户端广播新状态，或只回复当前客户端。
#[derive(Debug)]
pub enum Reply {
    /// 状态无变化（纯 UI 命令）。
    None,
    /// 状态有变化，广播一份完整更新。
    Broadcast,
    /// 只回复当前客户端（例如悬停探测结果），不广播。
    Direct(Value),
}

/// 一条战斗日志。
#[derive(Clone, Debug)]
pub struct LogLine {
    pub seq: u64,
    pub team: Option<Team>,
    pub text: String,
}

/// 高亮集合（与 `GuiApp::highlight_sets` 等价）。
#[derive(Default, Clone)]
pub struct Highlights {
    pub reachable: Vec<Hex>,
    pub attackable: Vec<Hex>,
    pub blocked: Vec<Hex>,
    pub howitzer: Vec<Hex>,
    pub disembark: Vec<Hex>,
    pub board: Vec<Hex>,
    pub supply: Vec<Hex>,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ConfirmKind {
    Restart,
    EndTurn,
}

/// 3D 前端的游戏宿主。
pub struct Host {
    pub game: GameState,
    pub viewer: Team,
    pub level: Level,
    pub custom_map: Option<CustomMap>,
    pub map_name: String,
    pub selected: Option<Hex>,
    pub selected_is_air: bool,
    pub zero_hint: Option<Hex>,
    pub pending_disembark: Option<char>,
    pub load_mode: bool,
    pub supply_mode: bool,
    pub howitzer_fire_mode: bool,
    pub smoke_shot_pending: bool,
    pub ranger_mode: bool,
    pub ranger_first: Option<Hex>,
    pub simul_mode: bool,
    pub simul_orders: Vec<SimulOrder>,
    pub pending_recruit: Option<UnitKind>,
    pub pending_cargo: Vec<UnitKind>,
    pub sustain_mode: bool,
    pub sustain_pp: i32,
    pub sustain_ap: i32,
    pub log: Vec<LogLine>,
    pub game_over: Option<String>,
    pub last_error: Option<String>,
    pub expanded: bool,
    pub log_open: bool,
    pub help_open: bool,
    pub seq: u64,
    pub battle_seq_sent: u32,
    pub log_sent: usize,
    pub visible_enemies: BTreeSet<Hex>,
    pub revealed: BTreeSet<Hex>,
    pub anim_estimate: f64,
    /// 本批次动画事件的整体加速系数（与 GUI 的 `scale` 一致，随 update 下发）。
    pub anim_scale: f64,
    /// 用户设置的动画速度倍率（1 = 原始节奏；只在 JS 侧设置，用于压缩播放窗口）。
    pub anim_speed: f64,
    /// 尚未下发给前端的动画事件。
    pub pending_events: Vec<Value>,
    /// 地图代次：每次换图/重开都会 +1，用来在 update 里增量下发地图数据
    /// （前端只在 init 时建地形，换图后必须重建整张地图）。
    pub map_generation: u64,
    published_generation: u64,
    pub preview: Option<Value>,
    confirm: Option<(std::time::Instant, ConfirmKind)>,
    ai_thread: Option<std::thread::JoinHandle<(GameState, Vec<String>)>>,
    ai_think_start: Option<std::time::Instant>,
    ai_think_elapsed: Option<f64>,
    ai_playback_until: Option<std::time::Instant>,
    log_seq: u64,
}

impl Host {
    // ------------------------------------------------------------------
    // 构造 / 重开
    // ------------------------------------------------------------------

    pub fn new(level: Level, custom: Option<CustomMap>, seed: Option<u64>) -> Self {
        let seed = seed.unwrap_or_else(rand::random);
        let game = match (&custom, level) {
            (Some(cm), _) => GameState::new_custom_deploy(seed, cm.clone()),
            (None, Level::VillageDefense) => GameState::new_deploy_level(seed, Level::VillageDefense),
            (None, _) => GameState::new_deploy(seed),
        };
        let map_name = custom
            .as_ref()
            .map(|c| c.name.clone())
            .unwrap_or_else(|| level.name().to_string());
        let sustain_mode = game.sustain;
        let sustain_pp = game.sustain_per_turn.get(&Team::Player).copied().unwrap_or(10);
        let sustain_ap = game.sustain_per_turn.get(&Team::Ai).copied().unwrap_or(20);
        let mut host = Host {
            game,
            viewer: Team::Player,
            level: if custom.is_some() { Level::Custom } else { level },
            custom_map: custom,
            map_name,
            selected: None,
            selected_is_air: true,
            zero_hint: None,
            pending_disembark: None,
            load_mode: false,
            supply_mode: false,
            howitzer_fire_mode: false,
            smoke_shot_pending: false,
            ranger_mode: false,
            ranger_first: None,
            simul_mode: false,
            simul_orders: Vec::new(),
            pending_recruit: None,
            pending_cargo: Vec::new(),
            sustain_mode,
            sustain_pp,
            sustain_ap,
            log: Vec::new(),
            game_over: None,
            last_error: None,
            expanded: true,
            log_open: false,
            help_open: false,
            seq: 0,
            battle_seq_sent: 0,
            log_sent: 0,
            visible_enemies: BTreeSet::new(),
            revealed: BTreeSet::new(),
            anim_estimate: 0.0,
            anim_scale: 1.0,
            anim_speed: 1.0,
            pending_events: Vec::new(),
            map_generation: 1,
            published_generation: 0,
            preview: None,
            confirm: None,
            ai_thread: None,
            ai_think_start: None,
            ai_think_elapsed: None,
            ai_playback_until: None,
            log_seq: 0,
        };
        host.push_log(
            None,
            "—— 第 0 回合 · 部署阶段 ——\n用招募点数挑选单位，点击己方出发区域放置。".into(),
        );
        host.refresh_vision();
        host
    }

    /// 重新开始（对应 `GuiApp::restart`，单机模式分支）。
    pub fn restart(&mut self) {
        let ai_version = self.game.ai_version;
        let ai_difficulty = self.game.ai_difficulty;
        self.game = if self.level == Level::Custom {
            match self.custom_map.clone() {
                Some(cm) => GameState::new_custom_deploy(rand::random(), cm),
                None => GameState::new_deploy_level(rand::random(), self.level),
            }
        } else {
            GameState::new_deploy_level(rand::random(), self.level)
        };
        self.game.ai_version = ai_version;
        self.game.ai_difficulty = ai_difficulty;
        self.sync_sustain_from_game();
        self.map_generation += 1;
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.pending_disembark = None;
        self.load_mode = false;
        self.supply_mode = false;
        self.howitzer_fire_mode = false;
        self.smoke_shot_pending = false;
        self.ranger_mode = false;
        self.ranger_first = None;
        self.simul_mode = false;
        self.simul_orders.clear();
        self.pending_recruit = None;
        self.pending_cargo.clear();
        self.game_over = None;
        self.last_error = None;
        self.confirm = None;
        self.log.clear();
        self.log_sent = 0;
        self.battle_seq_sent = 0;
        self.ai_thread = None;
        self.ai_think_start = None;
        self.ai_think_elapsed = None;
        self.ai_playback_until = None;
        self.bump();
        self.push_log(
            None,
            "—— 第 0 回合 · 部署阶段 ——\n用招募点数挑选单位，点击己方出发区域放置。".into(),
        );
        self.refresh_vision();
    }

    /// 开始一局新的对局（顶栏「加载地图 / 新对局」）。
    pub fn new_game(&mut self, level: Level, custom: Option<CustomMap>) {
        let ai_version = self.game.ai_version;
        let ai_difficulty = self.game.ai_difficulty;
        let sustain = self.sustain_mode;
        let (pp, ap) = (self.sustain_pp, self.sustain_ap);
        self.level = if custom.is_some() { Level::Custom } else { level };
        self.map_name = custom
            .as_ref()
            .map(|c| c.name.clone())
            .unwrap_or_else(|| self.level.name().to_string());
        self.custom_map = custom.clone();
        self.game = match (&custom, self.level) {
            (Some(cm), _) => GameState::new_custom_deploy(rand::random(), cm.clone()),
            (None, Level::VillageDefense) => {
                GameState::new_deploy_level(rand::random(), Level::VillageDefense)
            }
            (None, _) => GameState::new_deploy(rand::random()),
        };
        self.game.ai_version = ai_version;
        self.game.ai_difficulty = ai_difficulty;
        self.sustain_mode = sustain;
        self.sustain_pp = pp;
        self.sustain_ap = ap;
        self.sync_sustain_from_game();
        self.map_generation += 1;
        self.selected = None;
        self.selected_is_air = true;
        self.pending_recruit = None;
        self.pending_cargo.clear();
        self.game_over = None;
        self.last_error = None;
        self.confirm = None;
        self.log.clear();
        self.log_sent = 0;
        self.battle_seq_sent = 0;
        self.ai_thread = None;
        self.ai_playback_until = None;
        self.bump();
        self.push_log(
            None,
            format!(
                "—— 已加载：{} · 第 0 回合 · 部署阶段 ——",
                self.map_name
            ),
        );
        self.refresh_vision();
    }

    // ------------------------------------------------------------------
    // 基础工具
    // ------------------------------------------------------------------

    pub fn push_log(&mut self, team: Option<Team>, text: String) {
        if text.trim().is_empty() {
            return;
        }
        self.log_seq += 1;
        self.log.push(LogLine {
            seq: self.log_seq,
            team,
            text,
        });
        if self.log.len() > 4000 {
            let drop = self.log.len() - 4000;
            self.log.drain(0..drop);
            self.log_sent = self.log_sent.saturating_sub(drop);
        }
    }

    pub fn log(&mut self, text: String) {
        self.push_log(None, text);
    }

    pub fn error(&mut self, text: String) {
        self.last_error = Some(text.clone());
        self.push_log(None, format!("⚠ {}", text));
    }

    fn bump(&mut self) {
        self.seq += 1;
    }

    /// 刷新视野缓存 + 幽灵标记（对应 GUI 每帧的 `refresh_ghosts`）。
    pub fn refresh_vision(&mut self) {
        let vis = self.game.vision(self.viewer);
        self.revealed = vis.terrain;
        self.visible_enemies = vis.enemy_units;
        self.game.refresh_ghosts(self.viewer);
        // 观察者视野内若出现敌方单位，其幽灵标记应消失（由 refresh_ghosts 处理）
    }

    pub fn busy(&self) -> bool {
        self.ai_thread.is_some() || self.ai_thinking() || self.ai_playback_until.is_some()
    }

    pub fn ai_thinking(&self) -> bool {
        self.ai_thread.is_some()
    }

    pub fn ghost_list(&self) -> Vec<(Hex, UnitKind, i32)> {
        let mut out: Vec<(Hex, UnitKind, i32)> = self
            .game
            .ghosts
            .get(&self.viewer)
            .map(|m| m.iter().map(|(h, (k, t))| (*h, *k, *t)).collect())
            .unwrap_or_default();
        out.sort_by_key(|(h, _, _)| *h);
        out
    }

    pub fn confirm_json(&self) -> Value {
        match &self.confirm {
            Some((t, k)) => json!({
                "kind": match k { ConfirmKind::Restart => "restart", ConfirmKind::EndTurn => "endTurn" },
                "fresh": t.elapsed().as_secs_f64() < 2.5,
            }),
            None => Value::Null,
        }
    }

    fn fog_dims_internal(&self) -> Vec<(Hex, i32)> {
        // 分层迷雾：返回「暗雾」格（BFS 路程 > 视野/2 但 ≤ 视野）。
        let vis = self.game.vision(self.viewer);
        let mut out = Vec::new();
        for (h, (d, v)) in &vis.dist {
            if *v <= 0 {
                continue;
            }
            if *d > *v {
                continue; // 全黑格由 revealed 之外处理
            }
            if *d > v / 2 {
                out.push((*h, 1));
            }
        }
        out.sort_by_key(|(h, _)| *h);
        out
    }

    pub fn fog_dims(&self) -> Vec<Value> {
        self.fog_dims_internal()
            .into_iter()
            .map(|(h, l)| json!({"h": snap::hx(h), "l": l}))
            .collect()
    }

    /// 单位详情（控制面板用；敌方只给基本属性）。
    pub fn unit_details(&self, u: &Unit) -> Value {
        let me = self.viewer;
        let own = u.team == me;
        let pos = u.pos;
        let mut v = json!({
            "label": u.label.to_string(),
            "kind": u.kind.token(),
            "team": if own { "blue" } else { "red" },
            "own": own,
            "hp": u.hp,
            "maxHp": u.kind.max_hp(),
            "h": snap::hx(pos),
            "terrain": terrain_note(&self.game, pos),
            "inSupplyZone": own && self.game.in_supply_zone(me, pos),
            "inHqSupply": own && self.game.in_hq_supply_area(me, pos),
        });
        let obj = v.as_object_mut().unwrap();
        if own {
            let reach = self.game.map.reachable_hexes_ex(
                &self.game.units,
                &self.game.air_units,
                pos,
                u.kind.movement(),
                Some(u),
            );
            obj.insert("reachCount".into(), json!(reach.len()));
            // 撤退：位于本方出发区域内时可主动撤离，按血量比例返还招募点
            let can_retreat = self.game.can_retreat(me, pos);
            obj.insert("canRetreat".into(), json!(can_retreat));
            if can_retreat {
                obj.insert(
                    "retreatRefund".into(),
                    json!(hex_wargame::game::GameState::retreat_refund(u)),
                );
            }
            obj.insert("canDeployRooftop".into(), json!(
                u.kind.is_foot() && self.game.map.buildings.contains(&pos)
            ));
            obj.insert("targets".into(), self.target_list(u));
            // 可装载 / 可放下
            if u.kind.capacity() > 0 {
                obj.insert("canLoadMode".into(), json!(
                    !u.kind.is_air() && u.team == me && u.actions_left > 0 && u.has_space()
                ));
                obj.insert("canHeliBoard".into(), json!(
                    u.kind.is_air() && u.team == me && u.actions_left > 0 && u.has_space()
                ));
                obj.insert("boardable".into(), self.boardable_list(u));
                obj.insert("unloadable".into(), self.unloadable_list(u));
            }
        } else {
            obj.insert("threats".into(), self.threat_list(u));
        }
        v
    }

    /// 射程内可见敌人（选中己方单位时）。
    fn target_list(&self, u: &Unit) -> Value {
        let me = self.viewer;
        let mut out = Vec::new();
        for e in self.game.enemies_of(me) {
            if !self.visible_enemies.contains(&e.pos) && !self.game.test_mode {
                continue;
            }
            if Hex::distance(u.pos, e.pos) > u.eff_range() {
                continue;
            }
            let can_target = u.can_target_unit(e.kind);
            let damage = u.eff_attack() >= e.kind.armor();
            let los = u.kind == UnitKind::Howitzer
                || u.kind == UnitKind::Mortar
                || (u.kind.is_air() && e.kind.is_air())
                || self.game.map.has_los_ex(u.pos, e.pos, &self.game.smoke);
            out.push(json!({
                "h": snap::hx(e.pos),
                "label": e.label.to_string(),
                "kind": e.kind.token(),
                "dist": Hex::distance(u.pos, e.pos),
                "canTarget": can_target,
                "damage": damage,
                "los": los,
                "status": if !los { "视线受阻" } else if !can_target { "无法攻击此目标" } else if !damage { "护甲免疫" } else { "可攻击" },
            }));
        }
        Value::Array(out)
    }

    /// 能威胁到该敌方单位的我方单位（点击敌军时显示）。
    fn threat_list(&self, target: &Unit) -> Value {
        let me = self.viewer;
        let mut out = Vec::new();
        for mine in self.game.units_of(me) {
            if Hex::distance(mine.pos, target.pos) <= mine.eff_range()
                && mine.can_target_unit(target.kind)
                && mine.eff_attack() >= target.kind.armor()
            {
                out.push(json!({
                    "label": mine.label.to_string(),
                    "kind": mine.kind.token(),
                    "dist": Hex::distance(mine.pos, target.pos),
                    "h": snap::hx(mine.pos),
                }));
            }
        }
        Value::Array(out)
    }

    /// 选中载具时：可上车的货物列表（含**装不下的原因**，便于界面明确说明而不是
    /// 静默隐藏——玩家会误以为「还有运力却不能装载」）。
    fn boardable_list(&self, u: &Unit) -> Value {
        let me = self.viewer;
        let free = (u.kind.capacity() - u.used_weight()).max(0);
        let mut out = Vec::new();
        let mut consider = |inf: &Unit| {
            if inf.team != me || !u.can_carry(inf.kind) {
                return;
            }
            let weight = inf.kind.cargo_weight();
            let fits = weight <= free;
            let reason = if !fits {
                format!("需要 {} 点运力，仅剩 {}", weight, free)
            } else if u.actions_left < 1 {
                "载具本回合行动次数不足".to_string()
            } else if inf.actions_left < 1 && !(inf.kind == UnitKind::Supply
                && u.kind == UnitKind::HeavyTransportHeli)
            {
                format!("{} 本回合行动次数不足", inf.kind.name())
            } else {
                String::new()
            };
            out.push(json!({
                "label": inf.label.to_string(),
                "kind": inf.kind.token(),
                "kindName": inf.kind.name(),
                "h": snap::hx(inf.pos),
                "actions": inf.actions_left,
                "weight": weight,
                "free": free,
                "fits": fits && reason.is_empty(),
                "reason": reason,
            }));
        };
        if u.kind.is_air() {
            if let Some(inf) = self.game.units.get(&u.pos) {
                consider(inf);
            }
        } else {
            for n in u.pos.neighbors() {
                if let Some(inf) = self.game.unit_at(n) {
                    consider(inf);
                }
            }
        }
        Value::Array(out)
    }

    /// 可放下的货物。
    fn unloadable_list(&self, u: &Unit) -> Value {
        let mut out = Vec::new();
        for p in &u.passengers {
            let can_ground = u.actions_left > 0
                && u.passengers.iter().any(|q| q.label == p.label)
                && if u.kind.is_air() {
                    !self.game.map.obstacles.contains(&u.pos)
                        && !self.game.map.water.contains(&u.pos)
                        && !self.game.units.contains_key(&u.pos)
                } else {
                    u.pos
                        .neighbors()
                        .iter()
                        .any(|n| {
                            self.game.map.contains(*n)
                                && !self.game.map.obstacles.contains(n)
                                && !self.game.units.contains_key(n)
                        })
                };
            out.push(json!({
                "label": p.label.to_string(),
                "kind": p.kind.token(),
                "hp": p.hp,
                "canUnload": can_ground,
            }));
        }
        Value::Array(out)
    }

    // ------------------------------------------------------------------
    // 高亮集合
    // ------------------------------------------------------------------

    pub fn selected_unit(&self) -> Option<&Unit> {
        let h = self.selected?;
        if self.selected_is_air {
            self.game.air_units.get(&h).or_else(|| self.game.units.get(&h))
        } else {
            self.game.units.get(&h).or_else(|| self.game.air_units.get(&h))
        }
    }

    pub fn highlights(&self) -> Highlights {
        let mut hl = Highlights::default();
        let me = self.viewer;
        let Some(u) = self.selected_unit() else {
            return hl;
        };
        if u.team != me {
            return hl;
        }
        // 待放下落点
        if self.pending_disembark.is_some() && !u.kind.is_air() && u.kind.capacity() > 0 {
            for n in u.pos.neighbors() {
                if self.game.map.contains(n)
                    && !self.game.map.obstacles.contains(&n)
                    && !self.game.units.contains_key(&n)
                {
                    hl.disembark.push(n);
                }
            }
        }
        // 装载模式：紧邻可上车单位
        if self.load_mode && !u.kind.is_air() && u.kind.capacity() > 0 && u.has_space() {
            for n in u.pos.neighbors() {
                if let Some(g) = self.game.units.get(&n) {
                    if g.team == me && u.can_carry(g.kind) {
                        hl.board.push(n);
                    }
                }
            }
        }
        // 补给模式：半径 2 格内友军
        if self.supply_mode && u.kind == UnitKind::Supply {
            for h in self.game.supply_range_of(u.pos) {
                if let Some(t) = self.game.unit_at(h) {
                    if t.team == me && h != u.pos {
                        hl.supply.push(h);
                    }
                }
            }
        }
        let mut reach = if self.simul_mode || self.load_mode {
            Vec::new()
        } else if u.actions_left > 0
            && !((u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
                && self.howitzer_fire_mode)
        {
            self.game.map.reachable_hexes_ex(
                &self.game.units,
                &self.game.air_units,
                u.pos,
                u.kind.movement(),
                Some(u),
            )
        } else {
            Vec::new()
        };
        if u.kind.is_air() {
            reach.retain(|h| !self.game.air_units.contains_key(h));
        }
        hl.reachable = reach;
        // 炮兵：射程内任意格
        if (u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
            && (self.howitzer_fire_mode
                || (self.simul_mode && (u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)))
        {
            let mut targets = Vec::new();
            for row in 0..self.game.map.rows {
                for col in 0..self.game.map.cols {
                    let hx = hex::axial_from_offset(col, row);
                    if hx == u.pos {
                        continue;
                    }
                    if Hex::distance(u.pos, hx) <= u.kind.range() {
                        targets.push(hx);
                    }
                }
            }
            if self.howitzer_fire_mode {
                hl.howitzer = targets;
            } else {
                hl.howitzer = targets;
            }
            return hl;
        }
        // 普通单位：射程内可攻击敌人
        let can_act = u.actions_left >= u.kind.attack_cost();
        for e in self.game.enemies_of(me) {
            if !self.visible_enemies.contains(&e.pos) && !self.game.test_mode {
                continue;
            }
            if Hex::distance(u.pos, e.pos) > u.eff_range() || !can_act {
                continue;
            }
            let air_to_air = u.kind.is_air() && e.kind.is_air();
            let los_ok = u.kind == UnitKind::Howitzer
                || u.kind == UnitKind::Mortar
                || air_to_air
                || self.game.map.has_los_ex(u.pos, e.pos, &self.game.smoke);
            if !los_ok {
                hl.blocked.push(e.pos);
                continue;
            }
            if u.can_target_unit(e.kind) && u.eff_attack() >= e.kind.armor() {
                hl.attackable.push(e.pos);
            } else {
                hl.blocked.push(e.pos);
            }
        }
        hl
    }

    /// 部署 / 招募阶段的可放置格（与 `deploy_cells` 一致）。
    pub fn deploy_highlight_cells(&self) -> Vec<Hex> {
        let me = self.viewer;
        if self.game.test_mode && self.game.test_placing {
            // 试验放置：全部空格
            let mut out = Vec::new();
            for row in 0..self.game.map.rows {
                for col in 0..self.game.map.cols {
                    let h = hex::axial_from_offset(col, row);
                    let occupied = self.game.units.contains_key(&h) || self.game.air_units.contains_key(&h);
                    if !occupied && !self.game.map.obstacles.contains(&h) && !self.game.map.water.contains(&h) {
                        out.push(h);
                    }
                }
            }
            return out;
        }
        if self.game.deploying {
            return self.game.deploy_cells(me);
        }
        if self.game.sustain_deploying {
            if self.game.recruit_zone_turn > 0 && self.game.turn <= self.game.recruit_zone_turn {
                return self.game.deploy_cells(me);
            }
            let mut out: Vec<Hex> = self
                .game
                .supply_zone_hexes(me)
                .into_iter()
                .filter(|h| {
                    !self.game.units.contains_key(h)
                        && !self.game.air_units.contains_key(h)
                        && !self.game.map.obstacles.contains(h)
                        && !self.game.map.water.contains(h)
                })
                .collect();
            out.sort();
            return out;
        }
        Vec::new()
    }

    // ------------------------------------------------------------------
    // 命令入口
    // ------------------------------------------------------------------

    /// 处理一条客户端命令（JSON 文本），返回是否有状态变化。
    pub fn handle_json(&mut self, text: &str) -> Reply {
        let cmd: Value = match serde_json::from_str(text) {
            Ok(v) => v,
            Err(e) => {
                self.error(format!("命令解析失败：{e}"));
                return Reply::None;
            }
        };
        let t = cmd.get("t").and_then(|v| v.as_str()).unwrap_or("");
        match t {
            "click" => {
                let h = parse_hex(&cmd["h"]);
                let upper = cmd.get("upper").and_then(|v| v.as_bool()).unwrap_or(false);
                let right = cmd.get("button").and_then(|v| v.as_str()) == Some("right");
                if let Some(h) = h {
                    if right {
                        self.cancel_selection();
                    } else {
                        self.handle_click(h, upper);
                    }
                    return Reply::Broadcast;
                }
                Reply::None
            }
            "probe" => {
                // 悬停探测：该格中隐蔽值 0.5/1/2/4 的敌方单位分别能否被我方发现
                let h = parse_hex(&cmd["h"]);
                let data = match h {
                    Some(h) => self.probe_detection(h),
                    None => Value::Null,
                };
                Reply::Direct(json!({ "t": "probe", "data": data }))
            }
            "preview" => {
                // 悬停预览：测距/命中率信息（不改变状态）
                let h = parse_hex(&cmd["h"]);
                self.preview = h.map(|h| self.hover_info(h));
                Reply::None
            }
            "selectUnit" => {
                let team = parse_team(&cmd["team"]);
                let label = cmd
                    .get("label")
                    .and_then(|v| v.as_str())
                    .and_then(|s| s.chars().next());
                if let (Some(team), Some(label)) = (team, label) {
                    if let Some((pos, air)) = self
                        .find_unit(team, label)
                        .map(|u| (u.pos, u.kind.is_air()))
                    {
                        self.selected = Some(pos);
                        self.selected_is_air = air;
                        self.zero_hint = None;
                        return Reply::Broadcast;
                    }
                }
                Reply::None
            }
            "focusUnit" => {
                let team = parse_team(&cmd["team"]);
                let label = cmd
                    .get("label")
                    .and_then(|v| v.as_str())
                    .and_then(|s| s.chars().next());
                if let (Some(team), Some(label)) = (team, label) {
                    if let Some((pos, air)) = self
                        .find_unit(team, label)
                        .map(|u| (u.pos, u.kind.is_air()))
                    {
                        self.selected = Some(pos);
                        self.selected_is_air = air;
                        self.zero_hint = None;
                        return Reply::Broadcast;
                    }
                }
                Reply::None
            }
            "recruitKind" => {
                let kind = parse_kind(&cmd["kind"]);
                match kind {
                    Some(k) => {
                        if self.pending_recruit != Some(k) {
                            self.pending_cargo.clear();
                        }
                        self.pending_recruit = Some(k);
                        self.bump();
                        Reply::Broadcast
                    }
                    None => Reply::None,
                }
            }
            "cargo" => {
                let op = cmd.get("op").and_then(|v| v.as_str()).unwrap_or("add");
                match op {
                    "clear" => self.pending_cargo.clear(),
                    "add" => {
                        if let (Some(kind), Some(c)) =
                            (self.pending_recruit, parse_kind(&cmd["kind"]))
                        {
                            let used: i32 = self.pending_cargo.iter().map(|k| k.cargo_weight()).sum();
                            if kind.can_load_cargo(c) && used + c.cargo_weight() <= kind.capacity() {
                                self.pending_cargo.push(c);
                            } else {
                                self.error(format!("{} 无法搭载 {}", kind.name(), c.name()));
                            }
                        }
                    }
                    "pop" => {
                        self.pending_cargo.pop();
                    }
                    _ => {}
                }
                self.bump();
                Reply::Broadcast
            }
            "testTeam" => {
                if let Some(team) = parse_team(&cmd["team"]) {
                    self.game.test_place_team = team;
                    self.bump();
                    Reply::Broadcast
                } else {
                    Reply::None
                }
            }
            "sustain" => {
                // 部署阶段的可持续部署设置
                if let Some(on) = cmd.get("on").and_then(|v| v.as_bool()) {
                    self.sustain_mode = on;
                }
                if let Some(pp) = cmd.get("pp").and_then(|v| v.as_i64()) {
                    self.sustain_pp = pp.clamp(0, 200) as i32;
                }
                if let Some(ap) = cmd.get("ap").and_then(|v| v.as_i64()) {
                    self.sustain_ap = ap.clamp(0, 200) as i32;
                }
                if cmd.get("apply").and_then(|v| v.as_bool()).unwrap_or(false) {
                    self.apply_sustain_settings();
                    self.log(if self.sustain_mode {
                        format!(
                            "已开启可持续部署：每回合 +{}（玩家）/ +{}（AI）点数",
                            self.sustain_pp, self.sustain_ap
                        )
                    } else {
                        "已关闭可持续部署（规则与普通对局完全一致）".into()
                    });
                }
                self.bump();
                Reply::Broadcast
            }
            "ai" => {
                if let Some(v) = cmd.get("version").and_then(|v| v.as_str()) {
                    self.game.ai_version = if v == "v2" {
                        hex_wargame::game::AiVersion::V2
                    } else {
                        hex_wargame::game::AiVersion::Legacy
                    };
                    self.log(format!("🤖 已切换为{} AI", self.game.ai_version.name()));
                }
                if let Some(d) = cmd.get("difficulty").and_then(|v| v.as_str()) {
                    let all = hex_wargame::game::AiDifficulty::all();
                    if let Some(found) = all
                        .iter()
                        .find(|x| format!("{:?}", x).to_ascii_lowercase() == d.to_ascii_lowercase())
                    {
                        self.game.ai_difficulty = *found;
                        self.log(format!("🎯 AI 难度：{}", found.name()));
                    }
                }
                self.bump();
                Reply::Broadcast
            }
            "ui" => {
                if let Some(v) = cmd.get("expanded").and_then(|v| v.as_bool()) {
                    self.expanded = v;
                }
                if let Some(v) = cmd.get("logOpen").and_then(|v| v.as_bool()) {
                    self.log_open = v;
                }
                if let Some(v) = cmd.get("helpOpen").and_then(|v| v.as_bool()) {
                    self.help_open = v;
                }
                Reply::None
            }
            "sync" => Reply::Broadcast,
            "cmd" => {
                let name = cmd.get("name").and_then(|v| v.as_str()).unwrap_or("");
                self.handle_named(name, &cmd);
                Reply::Broadcast
            }
            _ => Reply::None,
        }
    }

    fn handle_named(&mut self, name: &str, cmd: &Value) {
        let h = parse_hex(&cmd["h"]);
        let label = cmd
            .get("label")
            .and_then(|v| v.as_str())
            .and_then(|s| s.chars().next());
        let force = cmd.get("force").and_then(|v| v.as_bool()).unwrap_or(false);
        match name {
            "endTurn" => self.end_player_turn(force),
            "restart" => {
                if force {
                    self.restart();
                } else {
                    self.request_restart();
                }
            }
            "passUnit" => self.pass_unit(),
            "cancelSelection" => self.cancel_selection(),
            "toggleHowitzer" => self.toggle_howitzer_mode(),
            "toggleSimul" => self.toggle_simul_mode(),
            "confirmSimul" => self.confirm_simul_attack(),
            "toggleLoad" => self.toggle_load_mode(),
            "toggleSupply" => self.toggle_supply_mode(),
            "toggleSmoke" => self.toggle_smoke(),
            "toggleTestPlacing" => self.toggle_test_placing(),
            "clearRecruit" => {
                self.pending_recruit = None;
                self.pending_cargo.clear();
            }
            "enterTestMode" => {
                self.enter_test_mode();
                self.log("🧪 已进入试验模式：大本营已清空，可自由放置棋子并开始行动。".into());
            }
            "toggleSustainDeploy" => self.toggle_sustain_deploy(),
            // 动画速度倍率（1×/1.5×/2×/3×）：只影响播放节奏与输入屏蔽窗口，不改规则
            "animSpeed" => {
                let mult = cmd.get("mult").and_then(|v| v.as_f64()).unwrap_or(1.0);
                self.anim_speed = mult.clamp(1.0, 4.0);
                // 正在播放的窗口按同样倍率收缩
                if let Some(t) = self.ai_playback_until {
                    let left = t.saturating_duration_since(std::time::Instant::now());
                    let scaled = left.div_f64(self.anim_speed);
                    self.ai_playback_until = Some(std::time::Instant::now() + scaled);
                }
            }
            // 「跳过动画」：不再等待播放窗口，前端自己把棋子吸附到最终位置
            "fastForward" => {
                let had = self.ai_playback_until.take().is_some();
                self.anim_estimate = 0.0;
                if had {
                    self.anim_scale = 4.0;
                    self.log("⏩ 已跳过动画播放".into());
                }
            }
            "randomDeploy" => {
                for msg in ai_router::ai_deploy(&mut self.game, Team::Player) {
                    self.log(msg);
                }
                self.pending_recruit = None;
            }
            "finishDeploy" => match self.game.finish_deploy() {
                Ok(ai_log) => {
                    self.log("—— 部署完成 · 战斗开始 ——".into());
                    self.log("【AI 部署】".into());
                    for m in ai_log {
                        self.log(m);
                    }
                    self.log(format!("—— 第 {} 回合 · 你的行动 ——", self.game.turn));
                    self.pending_recruit = None;
                }
                Err(e) => self.error(e),
            },
            "undeploy" => {
                if let Some(h) = h {
                    match self.game.undeploy_unit(Team::Player, h) {
                        Ok(c) => self.log(format!("撤销部署（返还 {} 点）", c)),
                        Err(e) => self.error(e),
                    }
                }
            }
            "toggleAmmo" => {
                if let Some(sel) = self.selected {
                    let which = cmd.get("which").and_then(|v| v.as_str()).unwrap_or("missile");
                    let res = if which == "aa" {
                        self.game.toggle_aa_mode(sel)
                    } else {
                        self.game.toggle_missile_mode(sel)
                    };
                    match res {
                        Ok(()) => {
                            let (nm, mode) = self
                                .game
                                .unit_at(sel)
                                .map(|u| (u.name_with_label(), u.mode_name().to_string()))
                                .unwrap_or_default();
                            self.log(format!("{}切换到{}", nm, mode));
                        }
                        Err(e) => self.error(e),
                    }
                }
            }
            "retreat" => {
                if let Some(sel) = self.selected {
                    let me = self.viewer;
                    match self.game.retreat_unit(me, sel) {
                        Ok(pts) => {
                            self.log(format!("🏳 已撤退，按血量返还 {} 点招募点", pts));
                            self.selected = None;
                        }
                        Err(e) => self.error(e),
                    }
                    self.after_action();
                }
            }
            "entrench" => {
                if let Some(sel) = self.selected {
                    let name = self
                        .game
                        .unit_at(sel)
                        .map(|u| u.name_with_label())
                        .unwrap_or_default();
                    match self.game.deploy(sel) {
                        Ok(()) => self.log(format!("{} 完成架设", name)),
                        Err(e) => self.error(e),
                    }
                    self.after_action();
                }
            }
            "toggleRooftop" => {
                if let Some(sel) = self.selected {
                    let (name, now_roof) = if let Some(mu) = self.game.unit_at_mut(sel) {
                        if mu.actions_left >= 1 {
                            mu.rooftop = !mu.rooftop;
                            mu.actions_left -= 1;
                            (mu.name_with_label(), mu.rooftop)
                        } else {
                            (String::new(), false)
                        }
                    } else {
                        (String::new(), false)
                    };
                    if !name.is_empty() {
                        self.log(format!(
                            "{} {}（消耗 1 行动）",
                            name,
                            if now_roof {
                                "登上屋顶（视野/攻击无视遮挡，失去楼房闪避）"
                            } else {
                                "进入屋中（恢复楼房闪避）"
                            }
                        ));
                        self.after_action();
                    }
                }
            }
            "hqResupply" => {
                if let Some(sel) = self.selected {
                    let me = self.viewer;
                    match self.game.resupply_at_hq(me, sel) {
                        Ok(m) => self.log(format!("🏛 {}", m)),
                        Err(e) => self.error(e),
                    }
                    self.after_action();
                }
            }
            "heliBoard" => {
                if let Some(sel) = self.selected {
                    let name = self
                        .game
                        .air_units
                        .get(&sel)
                        .map(|h| h.name_with_label())
                        .unwrap_or_default();
                    match self.game.heli_board(sel) {
                        Ok(()) => {
                            let p = self
                                .game
                                .air_units
                                .get(&sel)
                                .and_then(|h| h.passengers.last())
                                .map(|p| p.name_with_label())
                                .unwrap_or_default();
                            self.log(format!("{} 载入正下方 {}", name, p));
                        }
                        Err(e) => self.error(e),
                    }
                    self.after_action();
                }
            }
            "heliUnload" => {
                if let (Some(sel), Some(label)) = (self.selected, label) {
                    match self.game.heli_unload_label(sel, label) {
                        Ok(()) => self.log(format!(
                            "{} 放下 {} 到正下方（步兵本回合不能行动）",
                            self.game
                                .air_units
                                .get(&sel)
                                .map(|u| u.name_with_label())
                                .unwrap_or_default(),
                            label
                        )),
                        Err(e) => self.error(e),
                    }
                    self.after_action();
                }
            }
            "board" => {
                if let (Some(sel), Some(ch)) = (self.selected, h) {
                    let veh = self
                        .game
                        .unit_at(sel)
                        .map(|u| u.name_with_label())
                        .unwrap_or_default();
                    let cargo = self
                        .game
                        .unit_at(ch)
                        .map(|u| u.name_with_label())
                        .unwrap_or_default();
                    match self.game.board(sel, ch) {
                        Ok(()) => {
                            self.log(format!("{} 搭载 {}", veh, cargo));
                            // 还有空位就留在装载模式
                            self.load_mode = self
                                .game
                                .unit_at(sel)
                                .map(|u| u.has_space())
                                .unwrap_or(false);
                        }
                        Err(e) => self.error(e),
                    }
                    self.after_action();
                }
            }
            "disembarkPending" => {
                if let (Some(sel), Some(label)) = (self.selected, label) {
                    self.pending_disembark = Some(label);
                    self.load_mode = false;
                    self.log(format!(
                        "点击紧邻 {} 的空格放下 {}（Esc 取消）",
                        hex::hex_label(sel),
                        label
                    ));
                }
            }
            "cancelDisembark" => {
                self.pending_disembark = None;
            }
            "exportLog" => match self.export_log() {
                Ok(p) => self.log(format!("✅ 对局日志已导出: {}", p)),
                Err(e) => self.error(format!("导出日志失败: {}", e)),
            },
            "save" => match self.save_game() {
                Ok(p) => self.log(format!("已保存对局到 {}", p)),
                Err(e) => self.error(format!("保存失败: {}", e)),
            },
            "loadSave" => {
                if let Some(file) = cmd.get("file").and_then(|v| v.as_str()) {
                    match self.load_game(&PathBuf::from(file)) {
                        Ok(()) => self.log(format!("已从 {} 加载对局并继续", file)),
                        Err(e) => self.error(format!("读档失败: {}", e)),
                    }
                }
            }
            "ranger" => {
                self.ranger_mode = !self.ranger_mode;
                self.ranger_first = None;
                if self.ranger_mode {
                    self.selected = None;
                    self.selected_is_air = true;
                    self.log("测距器开启：点击第一格作为起点（再按 R 或 Esc 退出）".into());
                } else {
                    self.log("测距器关闭".into());
                }
            }
            "cycleUnit" => self.cycle_unit(cmd.get("reverse").and_then(|v| v.as_bool()).unwrap_or(false)),
            "cancelLayer" => self.cancel_layer(),
            "newGame" => {
                let key = cmd.get("level").and_then(|v| v.as_str()).unwrap_or("open");
                let custom = if key == "custom" {
                    cmd.get("file")
                        .and_then(|v| v.as_str())
                        .and_then(|f| CustomMap::load(&PathBuf::from(f)).ok())
                } else {
                    None
                };
                let level = match key {
                    "village" => Level::VillageDefense,
                    "custom" => Level::Custom,
                    _ => Level::OpenField,
                };
                if key == "custom" && custom.is_none() {
                    self.error("自定义地图加载失败".into());
                    return;
                }
                self.new_game(level, custom);
            }
            "focusHex" => {
                if let Some(h) = h {
                    self.preview = Some(json!({"focus": snap::hx(h)}));
                }
            }
            "ping" => {}
            _ => {}
        }
    }

    fn find_unit(&self, team: Team, label: char) -> Option<&Unit> {
        self.game
            .units
            .values()
            .chain(self.game.air_units.values())
            .find(|u| u.team == team && u.label == label)
    }

    fn cancel_selection(&mut self) {
        self.selected = None;
        self.selected_is_air = true;
        self.load_mode = false;
        self.zero_hint = None;
    }

    /// Esc 分层取消（与 GUI 一致）。
    pub fn cancel_layer(&mut self) {
        if self.pending_disembark.take().is_some() {
            self.log("已取消放下".into());
        } else if self.supply_mode {
            self.supply_mode = false;
            self.log("已退出补给模式".into());
        } else if self.load_mode {
            self.load_mode = false;
            self.log("已退出装载模式".into());
        } else if self.smoke_shot_pending {
            self.smoke_shot_pending = false;
            self.log("已取消烟雾弹发射".into());
        } else if self.howitzer_fire_mode {
            self.toggle_howitzer_mode();
        } else if self.selected.is_some() {
            self.cancel_selection();
        }
    }

    fn cycle_unit(&mut self, reverse: bool) {
        let units: Vec<&Unit> = self
            .game
            .units_of(self.viewer)
            .into_iter()
            .filter(|u| u.actions_left > 0)
            .collect();
        if units.is_empty() {
            return;
        }
        let idx = self
            .selected
            .and_then(|sel| units.iter().position(|u| u.pos == sel && u.actions_left > 0))
            .unwrap_or(0);
        let next = if reverse {
            (idx + units.len() - 1) % units.len()
        } else {
            (idx + 1) % units.len()
        };
        let u = units[next];
        self.selected = Some(u.pos);
        self.selected_is_air = u.kind.is_air();
        self.load_mode = false;
        self.zero_hint = None;
    }

    // ------------------------------------------------------------------
    // 点击（对应 GuiApp::handle_click）
    // ------------------------------------------------------------------

    pub fn handle_click(&mut self, h: Hex, click_upper: bool) {
        if self.busy() || self.game_over.is_some() {
            return;
        }
        let me = self.viewer;

        // 试验放置子模式
        if self.game.test_mode && self.game.test_placing {
            if let Some(kind) = self.pending_recruit {
                match self.game.test_place_unit(self.game.test_place_team, kind, h) {
                    Ok(label) => self.log(format!(
                        "🧪 试验放置 {} {} {} @{}",
                        self.game.test_place_team.cn(),
                        label,
                        kind.name(),
                        hex::hex_label(h)
                    )),
                    Err(e) => self.error(e),
                }
            }
            return;
        }

        // 部署阶段
        if self.game.deploying {
            if let Some(kind) = self.pending_recruit {
                if let Some(u) = self.game.unit_at(h).cloned() {
                    if u.team == me {
                        match self.game.undeploy_unit(me, h) {
                            Ok(cost) => {
                                self.log(format!("撤销部署 {}（返还 {} 点）", u.name_with_label(), cost))
                            }
                            Err(e) => self.error(e),
                        }
                    } else {
                        self.error("不能操作对方单位".into());
                    }
                    return;
                }
                let cargo = self.pending_cargo.clone();
                match self.game.deploy_unit_with_cargo(me, kind, h, &cargo) {
                    Ok(label) => self.log(format!(
                        "部署 {} {}{}",
                        label,
                        kind.name(),
                        if cargo.is_empty() {
                            String::new()
                        } else {
                            format!("（载 {}）", cargo.len())
                        }
                    )),
                    Err(e) => self.error(e),
                }
            } else if let Some(u) = self.game.unit_at(h).cloned() {
                if u.team == me {
                    match self.game.undeploy_unit(me, h) {
                        Ok(cost) => {
                            self.log(format!("撤销部署 {}（返还 {} 点）", u.name_with_label(), cost))
                        }
                        Err(e) => self.error(e),
                    }
                }
            }
            return;
        }

        // 招募 / 追加部署
        if self.game.sustain_deploying {
            if let Some(kind) = self.pending_recruit {
                let cargo = self.pending_cargo.clone();
                let first = self.game.recruit_zone_turn > 0
                    && self.game.turn <= self.game.recruit_zone_turn;
                let placed = if self.game.recruit_zone_turn > 0 {
                    self.game.recruit_unit_with_cargo(me, kind, h, &cargo)
                } else {
                    self.game.reinforce_unit_with_cargo(me, kind, h, &cargo)
                };
                match placed {
                    Ok(label) => self.log(format!(
                        "🛠 {} {} {}{}（{}）",
                        if first { "招募" } else { "增援部署" },
                        label,
                        kind.name(),
                        if cargo.is_empty() {
                            String::new()
                        } else {
                            format!("（载 {}）", cargo.len())
                        },
                        if first {
                            "本回合即可行动"
                        } else {
                            "本回合不可行动"
                        }
                    )),
                    Err(e) => self.error(e),
                }
            }
            return;
        }

        // 补给模式
        if self.supply_mode {
            let valid = self
                .selected
                .and_then(|s| self.game.unit_at(s))
                .map(|u| u.team == me && u.kind == UnitKind::Supply && u.actions_left >= 1)
                .unwrap_or(false);
            if !valid {
                self.supply_mode = false;
            } else if let Some(src) = self.selected {
                match self.game.resupply_from(src, h) {
                    Ok(m) => self.log(format!("📦 {}", m)),
                    Err(e) => self.error(e),
                }
                let still = self
                    .game
                    .unit_at(src)
                    .map(|u| u.actions_left >= 1 && u.ammo >= 1)
                    .unwrap_or(false);
                self.supply_mode = still;
                self.after_action();
                return;
            }
        }

        // 同时攻击模式
        if self.simul_mode {
            if let Some(sel) = self.selected {
                if let Some(au) = self.selected_unit().cloned() {
                    if au.team == me {
                        let is_area = au.kind == UnitKind::Howitzer || au.kind == UnitKind::Mortar;
                        let mine_here = self
                            .game
                            .units
                            .get(&h)
                            .map(|u| u.team == me)
                            .unwrap_or(false)
                            || self
                                .game
                                .air_units
                                .get(&h)
                                .map(|u| u.team == me)
                                .unwrap_or(false);
                        let enemy_here = self
                            .game
                            .units
                            .get(&h)
                            .map(|u| u.team != me)
                            .unwrap_or(false)
                            || self
                                .game
                                .air_units
                                .get(&h)
                                .map(|u| u.team != me)
                                .unwrap_or(false);
                        if is_area && !mine_here {
                            self.queue_simul_attack(sel, h, self.selected_is_air);
                            return;
                        }
                        if enemy_here {
                            self.queue_simul_attack(sel, h, self.selected_is_air);
                            return;
                        }
                    }
                }
            }
            let mine_ground = self
                .game
                .units
                .get(&h)
                .filter(|u| u.team == me)
                .cloned();
            let mine_air = self
                .game
                .air_units
                .get(&h)
                .filter(|u| u.team == me)
                .cloned();
            if mine_ground.is_some() || mine_air.is_some() {
                let has_ground = mine_ground.is_some();
                let has_air = mine_air.is_some();
                self.selected = Some(h);
                self.selected_is_air = if has_air && has_ground {
                    click_upper
                } else {
                    has_air
                };
                self.zero_hint = None;
                return;
            }
            self.cancel_selection();
            return;
        }

        // 待放下
        if let Some(label) = self.pending_disembark {
            if let Some(sel) = self.selected {
                match self.game.disembark(sel, label, h) {
                    Ok(()) => {
                        self.log(format!("{} 下车到 {}", label, hex::hex_label(h)));
                        self.pending_disembark = None;
                    }
                    Err(e) => self.error(format!("{}（等待中，可点合法空格或按 Esc 取消）", e)),
                }
            } else {
                self.pending_disembark = None;
            }
            return;
        }

        // 未选中时点击敌方单位：仅查看
        if self.selected.is_none() {
            let e_ground = self.game.units.get(&h).filter(|e| {
                e.team != me && (self.visible_enemies.contains(&h) || self.game.test_mode)
            });
            let e_air = self.game.air_units.get(&h).filter(|e| {
                e.team != me && (self.visible_enemies.contains(&h) || self.game.test_mode)
            });
            if e_ground.is_some() || e_air.is_some() {
                self.selected = Some(h);
                self.selected_is_air = match (e_ground.is_some(), e_air.is_some()) {
                    (true, true) => click_upper,
                    (true, false) => false,
                    (false, true) => true,
                    (false, false) => false,
                };
                self.zero_hint = None;
                return;
            }
        }

        // 烟雾弹待发射
        if self.smoke_shot_pending {
            let can_smoke = self
                .selected
                .and_then(|sel| self.game.unit_at(sel))
                .map(|u| u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
                .unwrap_or(false);
            if can_smoke {
                if let Some(sel) = self.selected {
                    let range = self
                        .game
                        .unit_at(sel)
                        .map(|u| u.kind.range())
                        .unwrap_or(0);
                    self.smoke_shot_pending = false;
                    if Hex::distance(sel, h) <= range {
                        let is_mortar = self
                            .game
                            .unit_at(sel)
                            .map(|u| u.kind == UnitKind::Mortar)
                            .unwrap_or(false);
                        match self.game.smoke_shot(sel, h) {
                            Ok(_cells) => self.log(format!(
                                "发射烟雾弹 @{}（半径{}，持续2回合）",
                                hex::hex_label(h),
                                if is_mortar { 1 } else { 2 }
                            )),
                            Err(e) => self.error(e),
                        }
                        self.after_action();
                    } else {
                        self.error("超出射程，无法发射烟雾弹".into());
                    }
                }
            }
            self.smoke_shot_pending = false;
            return;
        }

        // 炮兵开火模式
        if self.howitzer_fire_mode {
            if let Some(sel) = self.selected {
                if self.try_howitzer_fire(sel, h) {
                    return;
                }
            }
        }

        // 已选中单位：该格有敌人 → 攻击
        if let Some(sel) = self.selected {
            if let Some(au) = self.selected_unit().cloned() {
                if au.team == me && au.kind != UnitKind::Howitzer {
                    let enemy_here = self
                        .game
                        .units
                        .get(&h)
                        .map(|u| u.team != me)
                        .unwrap_or(false)
                        || self
                            .game
                            .air_units
                            .get(&h)
                            .map(|u| u.team != me)
                            .unwrap_or(false);
                    if enemy_here {
                        let result = if self.selected_is_air {
                            self.game.attack_air(sel, h)
                        } else {
                            self.game.attack(sel, h)
                        };
                        match result {
                            Ok(out) => {
                                self.log(out.message);
                                if let Some(w) = self.current_winner() {
                                    self.finish_game(w);
                                    return;
                                }
                            }
                            Err(e) => self.error(e),
                        }
                        self.after_action();
                        return;
                    }
                }
            }
        }

        // 装载模式
        if self.load_mode {
            self.handle_load_mode_click(h);
            return;
        }

        // 点自己的单位
        let mine_ground = self
            .game
            .units
            .get(&h)
            .filter(|u| u.team == me)
            .cloned();
        let mine_air = self
            .game
            .air_units
            .get(&h)
            .filter(|u| u.team == me)
            .cloned();
        if mine_ground.is_some() || mine_air.is_some() {
            let can_move_here = if let Some(sel) = self.selected {
                self.selected_unit()
                    .filter(|su| su.team == me && su.actions_left > 0 && sel != h)
                    .map(|su| {
                        let same_layer_occupied = if su.kind.is_air() {
                            self.game.air_units.contains_key(&h)
                        } else {
                            self.game.units.contains_key(&h)
                        };
                        !same_layer_occupied
                            && self
                                .game
                                .map
                                .reachable_hexes_ex(
                                    &self.game.units,
                                    &self.game.air_units,
                                    su.pos,
                                    su.kind.movement(),
                                    Some(su),
                                )
                                .contains(&h)
                    })
                    .unwrap_or(false)
            } else {
                false
            };
            if can_move_here {
                self.try_move_selected(h);
                return;
            }
            let has_ground = mine_ground.is_some();
            let has_air = mine_air.is_some();
            self.selected = Some(h);
            self.selected_is_air = if has_air && has_ground {
                click_upper
            } else {
                has_air
            };
            self.zero_hint = None;
            return;
        }

        // 已选中单位时的操作
        if let Some(sel) = self.selected {
            if let Some(au) = self.selected_unit().cloned() {
                if au.team != me {
                    return;
                }
                if au.kind == UnitKind::Howitzer {
                    let has_enemy = self
                        .game
                        .units
                        .get(&h)
                        .map(|u| u.team != me)
                        .unwrap_or(false)
                        || self
                            .game
                            .air_units
                            .get(&h)
                            .map(|u| u.team != me)
                            .unwrap_or(false);
                    if has_enemy && au.actions_left > 0 && au.ammo > 0 {
                        self.error("榴弹炮当前是行动模式，不能炮击：按 T 切到开火模式后点击黄色格子".into());
                        return;
                    }
                } else if let Some(tu) = self.game.unit_at(h).cloned() {
                    if tu.team != me {
                        let result = if self.selected_is_air {
                            self.game.attack_air(sel, h)
                        } else {
                            self.game.attack(sel, h)
                        };
                        match result {
                            Ok(out) => {
                                self.log(out.message);
                                if let Some(w) = self.current_winner() {
                                    self.finish_game(w);
                                    return;
                                }
                            }
                            Err(e) => self.error(e),
                        }
                        self.after_action();
                        return;
                    }
                }
                if au.actions_left > 0 && self.try_move_selected(h) {
                    return;
                }
                if au.actions_left <= 0 {
                    if self.zero_hint != Some(sel) {
                        self.zero_hint = Some(sel);
                        self.error(format!(
                            "{} 本回合行动已用完（按 S 结束或再点一次取消选择）",
                            au.name_with_label()
                        ));
                        return;
                    }
                }
            }
            self.cancel_selection();
        }
    }

    fn handle_load_mode_click(&mut self, h: Hex) {
        let me = self.viewer;
        let Some(sel) = self.selected else {
            self.load_mode = false;
            return;
        };
        let Some(su) = self.selected_unit().cloned() else {
            self.load_mode = false;
            return;
        };
        if su.team != me || su.kind.capacity() == 0 || su.kind.is_air() {
            self.load_mode = false;
            return;
        }
        if !su.has_space() {
            self.load_mode = false;
            self.log(format!("{} 已满载，退出装载模式", su.name_with_label()));
            return;
        }
        if h != sel {
            if let Some(g) = self.game.units.get(&h).cloned() {
                if g.team == me && Hex::distance(sel, h) == 1 {
                    if su.can_carry(g.kind) {
                        match self.game.board(sel, h) {
                            Ok(()) => {
                                self.log(format!(
                                    "{} 搭载 {}",
                                    su.name_with_label(),
                                    g.name_with_label()
                                ));
                                self.load_mode = self
                                    .game
                                    .unit_at(sel)
                                    .map(|u| u.has_space())
                                    .unwrap_or(false);
                                self.after_action();
                            }
                            Err(e) => self.error(e),
                        }
                    } else {
                        self.error(format!(
                            "{} 不能搭载 {}",
                            su.name_with_label(),
                            g.name_with_label()
                        ));
                    }
                    return;
                }
            }
        }
        self.error("装载模式：请点击紧邻的己方可搭载单位上车（X/Esc 退出；此模式不能移动）".into());
    }

    pub fn toggle_load_mode(&mut self) {
        if self.load_mode {
            self.load_mode = false;
            self.log("已退出装载模式".into());
            return;
        }
        if self.selected.is_none() {
            self.error("请先选中一个可搭载的载具，再按 X 进入装载模式".into());
            return;
        }
        let Some(u) = self.selected_unit().cloned() else {
            return;
        };
        let me = self.viewer;
        if u.team != me {
            self.error("只能对己方载具使用装载模式".into());
            return;
        }
        if u.kind.is_air() || u.kind.capacity() == 0 {
            self.error(format!(
                "{} 不能搭载地面部队，无法进入装载模式",
                u.name_with_label()
            ));
            return;
        }
        if !u.has_space() {
            self.error(format!("{} 已满载", u.name_with_label()));
            return;
        }
        if u.actions_left < 1 {
            self.error(format!("{} 本回合行动次数不足", u.name_with_label()));
            return;
        }
        self.load_mode = true;
        self.pending_disembark = None;
        self.zero_hint = None;
        self.log(format!(
            "🚚 {} 装载模式：点击紧邻高亮的己方单位上车（X/Esc 退出；此模式不能移动）",
            u.name_with_label()
        ));
    }

    pub fn toggle_supply_mode(&mut self) {
        if self.supply_mode {
            self.supply_mode = false;
            self.log("已退出补给模式".into());
            return;
        }
        let Some(sel) = self.selected else {
            self.error("请先选中一个己方补给单位".into());
            return;
        };
        let me = self.viewer;
        match self.game.unit_at(sel) {
            Some(u) if u.team == me && u.kind == UnitKind::Supply => {
                if u.actions_left < 1 {
                    self.error("补给单位本回合行动次数不足".into());
                    return;
                }
                self.supply_mode = true;
                self.load_mode = false;
                self.pending_disembark = None;
                self.smoke_shot_pending = false;
                self.zero_hint = None;
                self.log("📦 补给模式：点击半径 2 格内的友军单位补给（补给单位与被补给方各消耗 1 行动；S/Esc 退出）".into());
            }
            _ => self.error("请先选中一个己方补给单位，再按 S 进入补给模式".into()),
        }
    }

    fn toggle_smoke(&mut self) {
        let is_arty = self
            .selected
            .and_then(|sel| self.game.unit_at(sel))
            .map(|u| u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
            .unwrap_or(false);
        if !is_arty {
            self.error("只有己方榴弹炮/自行迫击炮能发射烟雾弹".into());
            return;
        }
        self.smoke_shot_pending = !self.smoke_shot_pending;
        if self.smoke_shot_pending {
            self.log("烟雾弹待发射：点击射程内格子施放（Esc 取消）".into());
        }
    }

    fn try_move_selected(&mut self, h: Hex) -> bool {
        if self.selected.is_none() {
            return false;
        }
        let Some(au) = self.selected_unit().cloned() else {
            return false;
        };
        if au.actions_left < 1 {
            return false;
        }
        let reach = self.game.map.reachable_hexes(
            &self.game.units,
            au.pos,
            au.kind.movement(),
            Some(&au),
        );
        if !reach.contains(&h) {
            return false;
        }
        let path = self.game.map.plan_move(
            &self.game.units,
            &self.game.air_units,
            au.pos,
            h,
            au.kind.movement(),
            Some(au.clone()),
            false,
        );
        match self.game.move_unit(au.pos, &path, au.kind.is_air()) {
            Ok(new_pos) => {
                self.log(format!(
                    "{} 移动到 {} (行动剩余 {})",
                    au.name_with_label(),
                    hex::hex_label(new_pos),
                    au.actions_left - 1
                ));
                self.selected = Some(new_pos);
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return true;
                }
            }
            Err(e) => self.error(e),
        }
        self.after_action();
        true
    }

    fn try_howitzer_fire(&mut self, sel: Hex, h: Hex) -> bool {
        let Some(au) = self.selected_unit().cloned() else {
            return false;
        };
        let me = self.viewer;
        if au.team != me {
            return false;
        }
        if (au.kind != UnitKind::Howitzer && au.kind != UnitKind::Mortar) || h == sel {
            return false;
        }
        if Hex::distance(sel, h) > au.kind.range() {
            self.error("超出射程，无法炮击".into());
            return true;
        }
        match self.game.attack(sel, h) {
            Ok(out) => {
                self.log(out.message);
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return true;
                }
            }
            Err(e) => self.error(e),
        }
        self.after_action();
        true
    }

    pub fn toggle_howitzer_mode(&mut self) {
        let me = self.viewer;
        let sel_is_arty = self
            .selected
            .and_then(|sel| self.game.unit_at(sel))
            .map(|u| {
                u.team == me && (u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar)
            })
            .unwrap_or(false);
        if !sel_is_arty {
            self.error("只有己方榴弹炮/自行迫击炮能切换射击模式".into());
            return;
        }
        self.howitzer_fire_mode = !self.howitzer_fire_mode;
        self.log(format!(
            "炮兵模式：{}（{}）",
            if self.howitzer_fire_mode { "射击模式" } else { "行动模式" },
            if self.howitzer_fire_mode {
                "点击射程内黄色格子炮击"
            } else {
                "点击绿色格子移动"
            }
        ));
    }

    pub fn toggle_simul_mode(&mut self) {
        if self.game.deploying || self.game_over.is_some() {
            return;
        }
        self.simul_mode = !self.simul_mode;
        if self.simul_mode {
            self.selected = None;
            self.selected_is_air = true;
            self.zero_hint = None;
            self.howitzer_fire_mode = false;
            self.smoke_shot_pending = false;
            self.pending_disembark = None;
            self.ranger_mode = false;
            self.ranger_first = None;
            self.log("⚔ 同时攻击模式：依次点击你的单位，再点击红色敌人下达攻击命令；按 C 统一结算（榴弹炮/迫击炮可点击射程内格子作为炮击中心）".into());
        } else {
            self.simul_orders.clear();
            self.log("已退出同时攻击模式，已下达命令已清空".into());
        }
    }

    fn queue_simul_attack(&mut self, attacker_h: Hex, target_h: Hex, air_first: bool) {
        if attacker_h == target_h {
            self.error("不能攻击自己所在格".into());
            return;
        }
        let Some(au) = self.selected_unit().cloned() else {
            self.error("请先选择己方单位".into());
            return;
        };
        let order = SimulOrder {
            attacker: attacker_h,
            target: target_h,
            air_first,
            aa_mode: au.aa_mode,
            missile_mode: au.missile_mode,
        };
        match self.game.validate_simul_order(order) {
            Ok(()) => {
                if let Some(i) = self
                    .simul_orders
                    .iter()
                    .position(|o| o.attacker == attacker_h && o.air_first == air_first)
                {
                    let old = self.simul_orders[i];
                    self.simul_orders[i] = order;
                    self.log(format!(
                        "🔄 替换 {} 的攻击命令：{} → {}",
                        self.game
                            .unit_at(attacker_h)
                            .map(|u| u.name_with_label())
                            .unwrap_or_default(),
                        hex::hex_label(old.target),
                        hex::hex_label(target_h)
                    ));
                } else {
                    self.simul_orders.push(order);
                    self.log(format!(
                        "📋 已加入同时攻击：{} → {}",
                        self.game
                            .unit_at(attacker_h)
                            .map(|u| u.name_with_label())
                            .unwrap_or_default(),
                        hex::hex_label(target_h)
                    ));
                }
            }
            Err(e) => self.error(e),
        }
    }

    pub fn confirm_simul_attack(&mut self) {
        if self.simul_orders.is_empty() {
            self.error("还没有同时攻击命令：先点击你的单位，再点击敌方目标".into());
            return;
        }
        let orders = self.simul_orders.clone();
        match self.game.simultaneous_attack(&orders) {
            Ok(outcomes) => {
                for out in outcomes {
                    self.log(out.message);
                }
                self.simul_orders.clear();
                self.simul_mode = false;
                self.cancel_selection();
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return;
                }
                self.after_action();
            }
            Err(e) => self.error(format!("同时攻击结算失败：{}", e)),
        }
    }

    pub fn pass_unit(&mut self) {
        if let Some(sel) = self.selected {
            let me = self.viewer;
            let mine = self
                .game
                .units
                .get(&sel)
                .map(|u| u.team == me)
                .unwrap_or(false)
                || self
                    .game
                    .air_units
                    .get(&sel)
                    .map(|u| u.team == me)
                    .unwrap_or(false);
            let info = if !mine {
                None
            } else if self.selected_is_air && self.game.air_units.contains_key(&sel) {
                self.game.air_units.get_mut(&sel).map(|u| {
                    let name = u.name_with_label();
                    let left = u.actions_left;
                    u.actions_left = 0;
                    (name, left)
                })
            } else {
                self.game.unit_at_mut(sel).map(|u| {
                    let name = u.name_with_label();
                    let left = u.actions_left;
                    u.actions_left = 0;
                    (name, left)
                })
            };
            if let Some((name, left)) = info {
                self.log(format!("{} 结束本回合行动 (剩余 {} 次行动作废)", name, left));
            }
            self.cancel_selection();
            self.after_action();
        }
    }

    /// 顶栏「结束回合」（带二次确认，与 GUI 一致）。
    pub fn end_player_turn(&mut self, skip_confirm: bool) {
        if self.game_over.is_some() || self.busy() {
            return;
        }
        let remaining = self
            .game
            .units_of(Team::Player)
            .iter()
            .filter(|u| u.actions_left > 0)
            .count();
        if !skip_confirm {
            let confirmed = matches!(self.confirm, Some((t, ConfirmKind::EndTurn)) if t.elapsed().as_secs_f64() < 2.5);
            if remaining > 0 && !confirmed {
                self.confirm = Some((std::time::Instant::now(), ConfirmKind::EndTurn));
                self.log(format!(
                    "还有 {} 个单位未行动，再点一次「结束回合」确认",
                    remaining
                ));
                return;
            }
        }
        self.confirm = None;
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.load_mode = false;
        self.game.begin_turn(Team::Ai);
        self.drain_ui_events();
        if self.game.test_mode {
            self.log("🧪 试验模式：敌方本回合不行动。".into());
            if let Some(w) = self.current_winner() {
                self.finish_game(w);
                return;
            }
            if self.game.is_draw() {
                self.game_over = Some("▬ 平局：双方都无法造成有效杀伤（僵局）。".into());
                return;
            }
            self.game.begin_turn(Team::Player);
            self.log(format!("—— 第 {} 回合 · 你的行动 ——", self.game.turn));
            return;
        }
        self.log(format!("—— 第 {} 回合 · AI 行动 ——", self.game.turn));
        let mut state = self.game.clone();
        state.ui_events.clear();
        self.ai_think_start = Some(std::time::Instant::now());
        self.ai_think_elapsed = None;
        self.ai_playback_until = None;
        self.ai_thread = Some(std::thread::spawn(move || {
            let msgs = ai_router::take_turn(&mut state, Team::Ai);
            (state, msgs)
        }));
    }

    /// 顶栏「重新开始」（带二次确认）。
    pub fn request_restart(&mut self) {
        let confirmed =
            matches!(self.confirm, Some((t, ConfirmKind::Restart)) if t.elapsed().as_secs_f64() < 2.5);
        if confirmed {
            self.confirm = None;
            self.restart();
        } else {
            self.confirm = Some((std::time::Instant::now(), ConfirmKind::Restart));
            self.log("再点一次「重新开始」确认".into());
        }
    }

    pub fn after_action(&mut self) {
        if self.game_over.is_some() {
            return;
        }
        if self
            .game
            .units_of(Team::Player)
            .iter()
            .all(|u| u.actions_left == 0)
        {
            if self.game.sustain && !self.game.team_alive(Team::Player) {
                self.log("⚠ 你已全军覆没！按 D 追加部署增援（大本营未被占领前还可再战）".into());
                return;
            }
            self.log("所有单位行动完毕，自动结束回合。".into());
            self.end_player_turn(true);
        }
    }

    fn current_winner(&self) -> Option<Team> {
        if self.game.winner.is_some() {
            return self.game.winner;
        }
        if !self.game.game_over() {
            return None;
        }
        if !self.game.team_alive(Team::Player) {
            Some(Team::Ai)
        } else if !self.game.team_alive(Team::Ai) {
            Some(Team::Player)
        } else {
            None
        }
    }

    fn finish_game(&mut self, winner: Team) {
        let msg = if self.game.sustain || !self.game.keypoints.is_empty() {
            let total = self.game.keypoints.values().filter(|k| !k.center).count();
            match winner {
                Team::Player => format!("★ 胜利！达成胜利条件（关键据点 {} 个）", total),
                Team::Ai => "✗ 失败！敌方达成了胜利条件。".to_string(),
            }
        } else {
            match winner {
                Team::Player => "★ 胜利！你消灭了所有敌军！".to_string(),
                Team::Ai => "✗ 失败！你的部队全军覆没。".to_string(),
            }
        };
        self.game_over = Some(msg.clone());
        self.selected = None;
        self.load_mode = false;
        self.push_log(None, msg);
    }

    pub fn enter_test_mode(&mut self) {
        if !self.game.deploying {
            self.error("试验模式只能在开局部署阶段进入".into());
            return;
        }
        self.game.enter_test_mode();
        self.pending_recruit = None;
        self.pending_cargo.clear();
        self.selected = None;
        self.selected_is_air = true;
        self.zero_hint = None;
        self.simul_mode = false;
        self.simul_orders.clear();
        self.ranger_mode = false;
        self.ranger_first = None;
        self.howitzer_fire_mode = false;
        self.smoke_shot_pending = false;
        self.pending_disembark = None;
    }

    pub fn toggle_test_placing(&mut self) {
        if !self.game.test_mode {
            self.error("请先在开局部署面板开启试验模式".into());
            return;
        }
        self.game.test_placing = !self.game.test_placing;
        self.pending_recruit = None;
        if self.game.test_placing {
            self.game.sustain_deploying = false;
            self.simul_mode = false;
            self.simul_orders.clear();
            self.ranger_mode = false;
            self.ranger_first = None;
            self.howitzer_fire_mode = false;
            self.smoke_shot_pending = false;
            self.pending_disembark = None;
            self.selected = None;
            self.log("进入试验放置：选择阵营和单位，再点击地图空位放置（不扣点数；地面单位不可上岩石/水域，车辆不可进楼房；F3/Esc 退出）".into());
        } else {
            self.log("退出试验放置".into());
        }
    }

    pub fn toggle_sustain_deploy(&mut self) {
        if !self.game.sustain {
            self.error("当前未启用可持续部署模式（部署阶段勾选开启）".into());
            return;
        }
        self.game.sustain_deploying = !self.game.sustain_deploying;
        self.pending_recruit = None;
        self.selected = None;
        if self.game.sustain_deploying {
            let first = self.game.recruit_zone_turn > 0
                && self.game.turn <= self.game.recruit_zone_turn;
            self.log(if first {
                "进入招募：点击右侧单位，再点击本方出发区域任意空格（本回合即可行动，按 D/Esc 退出）"
                    .to_string()
            } else {
                "进入追加部署：点击右侧单位，再点击己方大本营周围 2 格放置（本回合不可行动，按 D/Esc 退出）"
                    .to_string()
            });
        } else {
            self.log("退出追加部署".into());
        }
    }


    /// 换图/重开之后同步可持续部署设置。
    ///
    /// 战役地图（如「空中突袭滨海机场」）自带 `sustain` 与每回合收入，且玩家开局
    /// 没有任何预置棋子——必须靠招募投入战斗。若在这里用「部署面板的勾选状态」把它
    /// 覆盖成关闭，玩家就会 0 单位，规则上立即判负（这正是加载该地图后直接显示
    /// 对局结束的原因）。因此：地图自带可持续部署时一律沿用地图设置。
    fn sync_sustain_from_game(&mut self) {
        if self.game.sustain {
            self.sustain_mode = true;
            let p = self.game.sustain_per_turn.get(&Team::Player).copied();
            let a = self.game.sustain_per_turn.get(&Team::Ai).copied();
            if let Some(p) = p {
                self.sustain_pp = p;
            }
            if let Some(a) = a {
                self.sustain_ap = a;
            }
        } else {
            self.apply_sustain_settings();
        }
    }

    pub fn apply_sustain_settings(&mut self) {
        self.game.sustain = self.sustain_mode;
        if self.sustain_mode {
            self.game.enable_sustain(self.sustain_pp, self.sustain_ap);
        } else {
            self.game.sustain_per_turn.clear();
        }
    }

    // ------------------------------------------------------------------
    // AI 回合
    // ------------------------------------------------------------------

    /// 轮询 AI 线程；算完则接管新局面（含其动画事件）。
    pub fn poll_ai(&mut self) {
        let Some(handle) = self.ai_thread.take() else {
            return;
        };
        if !handle.is_finished() {
            self.ai_thread = Some(handle);
            return;
        }
        match handle.join() {
            Ok((state, msgs)) => {
                let elapsed = self
                    .ai_think_start
                    .take()
                    .map(|t0| t0.elapsed().as_secs_f64())
                    .unwrap_or(0.0);
                self.game = state;
                self.game.event_log.extend(msgs);
                self.ai_think_elapsed = Some(elapsed);
                self.refresh_vision();
                // 收集 AI 行动事件（含迷雾过滤），交给前端播放
                let events = self.drain_ui_events();
                // 估算播放时长（与 GUI 的 fx_clock 同步策略一致），用于 busy 标记
                let dur = estimate_duration(&events);
                self.anim_estimate = dur;
                // 加速播放时，输入屏蔽窗口同步缩短（否则动画放完了还点不动）
                let wait = dur / self.anim_speed.clamp(1.0, 4.0) + 0.4;
                self.ai_playback_until =
                    Some(std::time::Instant::now() + std::time::Duration::from_secs_f64(wait));
                self.bump();
                // 播放结束后交接（这里立即结算局面：胜负 / 平局 / 回到玩家回合）
                if let Some(w) = self.current_winner() {
                    self.finish_game(w);
                    return;
                }
                if self.game.is_draw() {
                    self.game_over = Some("▬ 平局：双方都无法造成有效杀伤（僵局）。".into());
                    return;
                }
                self.game.begin_turn(Team::Player);
                self.log(format!("—— 第 {} 回合 · 你的行动 ——", self.game.turn));
            }
            Err(_) => {
                self.ai_think_start = None;
                self.ai_think_elapsed = None;
                self.ai_playback_until = None;
                self.error("AI 回合计算异常终止".into());
            }
        }
    }

    /// AI 播放窗口结束（前端动画播完后解除输入屏蔽）。
    pub fn tick(&mut self) {
        if let Some(t) = self.ai_playback_until {
            if std::time::Instant::now() >= t {
                self.ai_playback_until = None;
                self.ai_think_elapsed = None;
                self.anim_estimate = 0.0;
            }
        }
    }

    /// 取走本回合产生的动画事件（含迷雾过滤），追加到待下发队列。
    ///
    /// 节奏与 `GuiApp::drain_ui_events` 一致：整批事件先算总时长 `raw`，
    /// 再按 `scale = clamp(28/raw, 0.45, 1.0)` 压缩（严格串行，只是单步更快）。
    /// 迷雾中不可见的敌方移动不下发动画，但仍占一个很短的档期（skip 事件），
    /// 保证后续事件的相对节奏与 GUI 相同。
    pub fn drain_ui_events(&mut self) -> Vec<Value> {
        if self.game.ui_events.is_empty() {
            return Vec::new();
        }
        let events = std::mem::take(&mut self.game.ui_events);
        let vis = self.visible_enemies.clone();
        let viewer = self.viewer;

        // 第一遍：过滤 + 记录迷雾日志，同时估算原始时长
        struct Item {
            json: Option<Value>,
            raw: f64,
        }
        let mut items: Vec<Item> = Vec::with_capacity(events.len());
        for ev in events {
            match &ev {
                UiEvent::Move { team, label, kind, path, .. } => {
                    let seen = *team == viewer || path.last().is_some_and(|h| vis.contains(h));
                    if *team != viewer {
                        let end_seen = path.last().is_some_and(|h| vis.contains(h));
                        let start_seen = path.first().is_some_and(|h| vis.contains(h));
                        self.log_ai_move(*kind, *label, path, end_seen, start_seen);
                    }
                    if seen && path.len() >= 2 {
                        let len = path.len() as f64;
                        items.push(Item {
                            json: Some(snap::ui_event_json(&ev)),
                            raw: 0.16 * (len - 1.0).max(1.0) + 0.1,
                        });
                    } else {
                        items.push(Item {
                            json: Some(json!({"k": "skip", "dur": if seen { 0.02 } else { 0.05 }})),
                            raw: 0.05,
                        });
                    }
                }
                UiEvent::Fire(f) => {
                    if f.team != viewer {
                        let attacker_visible = vis.contains(&f.from);
                        self.log_ai_fire(f, attacker_visible);
                    }
                    let prof = weapon_profile(f.kind, f.aa_mode, f.missile_mode, f.area);
                    items.push(Item {
                        json: Some(snap::fire_json(f)),
                        raw: prof.aim + prof.flight + if f.killed { 1.5 } else { 0.35 },
                    });
                }
            }
        }
        let raw: f64 = items.iter().map(|i| i.raw).sum();
        // 用户设置的「动画速度」直接乘在整批事件的节奏上（1× 即与旧版完全一致）
        let speed = self.anim_speed.clamp(1.0, 4.0);
        let scale = (28.0 / raw).clamp(0.45, 1.0) * speed;
        self.anim_scale = scale;
        let mut out = Vec::with_capacity(items.len());
        for it in items {
            if let Some(v) = it.json {
                out.push(v);
            }
        }
        self.pending_events.extend(out.iter().cloned());
        out
    }

    /// 地图静态数据（换图时随 update 下发，前端据此重建地形）。
    pub fn map_payload(&self) -> Value {
        json!({
            "cols": self.game.map.cols,
            "rows": self.game.map.rows,
            "terrain": snap::terrain_rows(&self.game),
            "seed": self.game.seed,
            "level": {
                "key": match self.game.level {
                    Level::OpenField => "open",
                    Level::VillageDefense => "village",
                    Level::Custom => "custom",
                },
                "name": self.game.level.name(),
                "mapName": self.map_name.clone(),
            },
            "kinds": snap::kinds_table(),
        })
    }

    /// 生成一条完整的更新消息（状态 + 动画事件 + 增量日志 + 战报）。
    ///
    /// 先 drain 一次 UI 事件：玩家的移动/攻击同样会产生动画事件，
    /// 必须在这里统一收口，避免遗漏（AI 回合的事件在 `poll_ai` 里已经 drain 过）。
    pub fn take_update(&mut self) -> Value {
        self.drain_ui_events();
        let state = snap::state_json(self);
        let events = std::mem::take(&mut self.pending_events);
        // 增量日志
        let new_logs: Vec<Value> = self.log[self.log_sent.min(self.log.len())..]
            .iter()
            .map(|l| {
                json!({
                    "seq": l.seq,
                    "team": l.team.map(|t| if t == Team::Player { "blue" } else { "red" }),
                    "text": l.text,
                })
            })
            .collect();
        self.log_sent = self.log.len();
        // 战报事件（增量）
        let battle = snap::battle_event_json(&self.game, self.battle_seq_sent + 1);
        if let Some(last) = battle.last() {
            if let Some(seq) = last.get("seq").and_then(|v| v.as_u64()) {
                self.battle_seq_sent = seq as u32;
            }
        }
        // 换图后随本帧下发地图数据（前端重建地形/缩略图）
        let map_changed = self.map_generation != self.published_generation;
        if map_changed {
            self.published_generation = self.map_generation;
        }
        let map = if map_changed { self.map_payload() } else { Value::Null };
        self.bump();
        json!({
            "t": "update",
            "seq": self.seq,
            "map": map,
            "state": state,
            "events": events,
            "eventScale": self.anim_scale,
            "log": new_logs,
            "battleEvents": battle,
            "busy": self.busy(),
            "error": self.last_error,
        })
    }

    /// 初始消息（含地图、兵种表、关卡列表等静态数据 + 全量日志）。
    pub fn hello(&mut self) -> Value {
        self.published_generation = self.map_generation;
        let all_logs: Vec<Value> = self
            .log
            .iter()
            .map(|l| {
                json!({
                    "seq": l.seq,
                    "team": l.team.map(|t| if t == Team::Player { "blue" } else { "red" }),
                    "text": l.text,
                })
            })
            .collect();
        let maps: Vec<Value> = CustomMap::scan_all()
            .into_iter()
            .map(|(name, path)| json!({"name": name, "file": path.display().to_string()}))
            .collect();
        let saves: Vec<Value> = scan_saves()
            .into_iter()
            .map(|(name, path)| json!({"name": name, "file": path.display().to_string()}))
            .collect();
        json!({
            "t": "init",
            "proto": 1,
            "cols": self.game.map.cols,
            "rows": self.game.map.rows,
            "terrain": snap::terrain_rows(&self.game),
            "kinds": snap::kinds_table(),
            "levels": snap::level_list(),
            "maps": maps,
            "saves": saves,
            "seed": self.game.seed,
            "aiVersion": if self.game.ai_version == hex_wargame::game::AiVersion::V2 { "v2" } else { "legacy" },
            "aiDifficulty": format!("{:?}", self.game.ai_difficulty).to_ascii_lowercase(),
            "log": all_logs,
            "state": snap::state_json(self),
        })
    }

    fn log_ai_move(
        &mut self,
        kind: UnitKind,
        label: char,
        path: &[Hex],
        end_seen: bool,
        start_seen: bool,
    ) {
        if !end_seen || path.is_empty() {
            return;
        }
        let name = format!("{}{}", kind.name(), label);
        let end = *path.last().unwrap();
        if start_seen {
            self.log(format!(
                "🔴 敌军 {} 移动 {} → {}",
                name,
                hex::hex_label(path[0]),
                hex::hex_label(end)
            ));
        } else {
            self.log(format!("🔍 发现敌军 {} 于 {}", name, hex::hex_label(end)));
        }
    }

    fn log_ai_fire(&mut self, f: &UiFireEvent, attacker_visible: bool) {
        let name = format!("{}{}", f.kind.name(), f.label);
        let effect = if f.killed {
            "击毁目标".to_string()
        } else if f.hit && f.blocked {
            "命中但被护甲挡下".to_string()
        } else if f.hit {
            format!("命中 -{}", f.dmg)
        } else {
            "未命中".to_string()
        };
        if attacker_visible {
            self.log(format!(
                "🔴 敌军 {} 攻击 {}：{}",
                name,
                hex::hex_label(f.target),
                effect
            ));
        } else {
            self.log(format!(
                "⚠ 迷雾中的敌军从 {} 向 {} 开火：{}",
                hex::hex_label(f.from),
                hex::hex_label(f.target),
                effect
            ));
        }
    }

    /// 悬停信息（测距器 / 命中率预览）。
    pub fn hover_info(&self, h: Hex) -> Value {
        let mut info = json!({ "h": snap::hx(h), "terrain": terrain_note(&self.game, h) });
        let obj = info.as_object_mut().unwrap();
        if let Some(sel) = self.selected {
            let d = Hex::distance(sel, h);
            obj.insert("dist".into(), json!(d));
            obj.insert("los".into(), json!(self.game.map.has_los_ex(sel, h, &self.game.smoke)));
            obj.insert("label".into(), json!(hex::hex_label(h)));
            if let Some(au) = self.selected_unit() {
                if au.team == self.viewer {
                    let in_range = d <= au.eff_range();
                    obj.insert("inRange".into(), json!(in_range));
                    obj.insert("effRange".into(), json!(au.eff_range()));
                    obj.insert("effHit".into(), json!(au.eff_hit_rate()));
                    obj.insert("effAttack".into(), json!(au.eff_attack()));
                    if let Some(tu) = self.game.unit_at(h) {
                        if tu.team != self.viewer {
                            let (rate, note) =
                                self.game.direct_hit_rate(au, tu, h, false, false);
                            obj.insert("hitRate".into(), json!(rate));
                            obj.insert("hitNote".into(), json!(note));
                            obj.insert("targetKind".into(), json!(tu.kind.token()));
                            obj.insert("targetLabel".into(), json!(tu.label.to_string()));
                            obj.insert("targetHp".into(), json!(tu.hp));
                            obj.insert("pierce".into(), json!(au.eff_attack() >= tu.kind.armor()));
                            obj.insert("canTarget".into(), json!(au.can_target_unit(tu.kind)));
                        }
                    }
                }
            }
        }
        if let Some(kp) = self.game.keypoints.get(&h) {
            obj.insert(
                "keypoint".into(),
                json!({
                    "center": kp.center,
                    "owner": if kp.owner == Team::Player { "blue" } else { "red" },
                    "controller": if kp.controller == Team::Player { "blue" } else { "red" },
                }),
            );
        }
        if let Some(t) = self.game.smoke.get(&h) {
            obj.insert("smoke".into(), json!(t));
        }
        info
    }


    // ------------------------------------------------------------------
    // 悬停探测：该格中隐蔽值 0.5 / 1 / 2 / 4 的敌方单位分别能否被发现
    // ------------------------------------------------------------------

    /// 单个我方单位到目标格的**加权 BFS 路程**（与 `GameState::vision` 内的 BFS
    /// 规则逐条一致：森林 2 步（屋顶步兵无视）、岩石/楼房/烟雾可见但不穿透，
    /// 空中单位与屋顶步兵可看穿楼房；搜索范围 vision×2）。
    fn unit_bfs_dist(&self, u: &Unit, target: Hex) -> Option<i32> {
        let v = u.kind.vision();
        if v <= 0 {
            return None;
        }
        let mut dist: HashMap<Hex, i32> = HashMap::new();
        let mut queue: std::collections::VecDeque<Hex> = std::collections::VecDeque::new();
        dist.insert(u.pos, 0);
        queue.push_back(u.pos);
        while let Some(h) = queue.pop_front() {
            let d = dist[&h];
            if d >= v * 2 {
                continue;
            }
            for n in h.neighbors() {
                if !self.game.map.contains(n) {
                    continue;
                }
                let step = if self.game.map.forests.contains(&n) && !u.rooftop {
                    2
                } else {
                    1
                };
                let nd = d + step;
                if nd > v * 2 || dist.get(&n).copied().unwrap_or(i32::MAX) <= nd {
                    continue;
                }
                dist.insert(n, nd);
                if !self.game.map.obstacles.contains(&n)
                    && (u.kind.is_air() || u.rooftop || !self.game.map.buildings.contains(&n))
                    && !self.game.smoke.contains_key(&n)
                {
                    queue.push_back(n);
                }
            }
        }
        dist.get(&target).copied()
    }

    /// 目标格上某隐蔽值所需的「发现距离」（与后端判定式一致，整数除法）。
    fn need_for(v: i32, conceal_x2: i32, air: bool) -> i32 {
        if air {
            v * 2
        } else {
            v / conceal_x2.max(1)
        }
    }

    /// 悬停探测结果（供前端显示「这个格子里的敌人能不能被发现」）。
    ///
    /// 注意：本探测**只读取地形、烟雾与我方单位**，不访问格子上的任何棋子信息
    /// —— 否则把鼠标放在未探明的格子上就会泄露敌人情报。
    pub fn probe_detection(&self, h: Hex) -> Value {
        let me = self.viewer;
        let smoke_mult = if self.game.smoke.contains_key(&h) { 2 } else { 1 };
        // 隐蔽值档位：0.5（空中）/ 1（车辆）/ 2（步兵）/ 4（林中或楼内的特战小队）
        const CLASSES: [(f32, i32, bool, &str); 4] = [
            (0.5, 1, true, "空中单位（直升机 / 无人机）"),
            (1.0, 1, false, "车辆（坦克 / 悍马 / 火炮…）"),
            (2.0, 2, false, "步兵（步枪手 / 反坦克 / 防空兵…）"),
            (4.0, 4, false, "林中或楼内的特战小队"),
        ];
        let mut classes = Vec::new();
        for (label_v, conceal, air, name) in CLASSES {
            let effective = conceal * if air { 1 } else { smoke_mult };
            let mut detectors: Vec<Value> = Vec::new();
            for u in self
                .game
                .units
                .values()
                .chain(self.game.air_units.values())
                .filter(|u| u.team == me)
            {
                let v = u.kind.vision();
                if v <= 0 {
                    continue;
                }
                let Some(d) = self.unit_bfs_dist(u, h) else {
                    continue;
                };
                let need = Self::need_for(v, effective, air);
                if d <= need {
                    detectors.push(json!({
                        "label": u.label.to_string(),
                        "kind": u.kind.token(),
                        "kindName": u.kind.name(),
                        "dist": d,
                        "need": need,
                        "vision": v,
                    }));
                }
            }
            detectors.sort_by_key(|d| d.get("dist").and_then(|v| v.as_i64()).unwrap_or(0));
            classes.push(json!({
                "conceal": label_v,
                "name": name,
                "smokeDoubled": !air && smoke_mult > 1,
                "effectiveConceal": if air { 0.5 } else { (effective as f32) / 1.0 },
                "detected": !detectors.is_empty(),
                "detectors": detectors,
            }));
        }
        json!({
            "h": snap::hx(h),
            "label": hex::hex_label(h),
            "terrain": terrain_note(&self.game, h),
            "smoke": self.game.smoke.get(&h).copied(),
            "smokeDoubles": smoke_mult > 1,
            "keypoint": self.game.keypoints.get(&h).map(|k| json!({
                "center": k.center,
                "controller": if k.controller == me { "blue" } else { "red" },
            })),
            "classes": classes,
            "viewerUnits": self.game.units_of(me).len(),
        })
    }

    // ------------------------------------------------------------------
    // 日志导出 / 存档
    // ------------------------------------------------------------------

    pub fn export_log(&mut self) -> Result<String, String> {
        use std::time::{SystemTime, UNIX_EPOCH};
        std::fs::create_dir_all("logs").map_err(|e| e.to_string())?;
        let secs = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let fname = format!("wargame3d_seed{}_{}.log", self.game.seed, secs);
        let path = format!("logs/{}", fname);
        let mut text = String::new();
        text.push_str("════════ 六边形战争 · 3D 前端 对局日志 ════════\n");
        text.push_str("版本: 3d-1\n");
        text.push_str(&format!(
            "初始种子: {}（用此种子 + 下列事件可完全复原本局）\n",
            self.game.seed
        ));
        text.push_str(&format!(
            "地图: {}x{}  关卡: {}  模式: {}\n\n",
            self.game.map.cols,
            self.game.map.rows,
            self.map_name,
            if self.game.deploying {
                "部署阶段"
            } else if self.game.test_mode {
                "对局中 · 试验模式"
            } else {
                "对局中"
            }
        ));
        text.push_str("── 事件记录 ──\n");
        if self.game.event_log.is_empty() {
            text.push_str("（暂无事件）\n");
        } else {
            for line in &self.game.event_log {
                text.push_str(line);
                text.push('\n');
            }
        }
        text.push_str("\n── 结构化战报 ──\n");
        if self.game.battle_events.is_empty() {
            text.push_str("（暂无战报事件）\n");
        } else {
            for ev in &self.game.battle_events {
                text.push_str(&format!("{}\n", battle_event_text(ev)));
            }
        }
        text.push_str("\n── 终局态势 ──\n");
        for team in [Team::Player, Team::Ai] {
            let alive = self.game.units_of(team);
            let lost = self
                .game
                .battle_events
                .iter()
                .filter(|e| {
                    matches!(&e.kind, hex_wargame::game::BattleEventKind::Kill(k) if k.victim_team == team)
                })
                .count();
            let units: Vec<String> = alive
                .iter()
                .map(|u| format!("{}({})@{}", u.label, u.kind.name(), hex::hex_label(u.pos)))
                .collect();
            text.push_str(&format!(
                "{}: 存活 {} 个 · 损失 {} 个 · 被歼灭点数 {} · 部队: {}\n",
                if team == Team::Player { "蓝方" } else { "红方" },
                alive.len(),
                lost,
                self.game.killed_value.get(&team).copied().unwrap_or(0),
                if units.is_empty() {
                    "（无）".to_string()
                } else {
                    units.join(" ")
                }
            ));
        }
        if !self.game.keypoints.is_empty() {
            let list: Vec<String> = self
                .game
                .keypoints
                .iter()
                .map(|(h, kp)| {
                    format!(
                        "{}{}={}",
                        hex::hex_label(*h),
                        if kp.center { "★" } else { "⚑" },
                        if kp.controller == Team::Player { "蓝方" } else { "红方" }
                    )
                })
                .collect();
            text.push_str(&format!("关键据点: {}\n", list.join(" ")));
        }
        text.push_str("\n── 对局结果 ──\n");
        text.push_str(match &self.game_over {
            Some(msg) => msg.as_str(),
            None => {
                if self.game.winner == Some(Team::Player) {
                    "蓝方胜利"
                } else if self.game.winner == Some(Team::Ai) {
                    "红方胜利"
                } else {
                    "对局进行中"
                }
            }
        });
        text.push('\n');
        // 双方最终文本态势图（供复盘直接阅读）
        text.push_str("\n── 最终态势 · 蓝方视角 ──\n");
        text.push_str(&render_ascii(&self.game, Team::Player));
        text.push_str("\n── 最终态势 · 红方视角 ──\n");
        text.push_str(&render_ascii(&self.game, Team::Ai));
        std::fs::write(&path, text).map_err(|e| e.to_string())?;
        Ok(path)
    }

    fn save_game(&mut self) -> Result<String, String> {
        std::fs::create_dir_all("saves").map_err(|e| e.to_string())?;
        use std::time::{SystemTime, UNIX_EPOCH};
        let secs = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let path = PathBuf::from(format!("saves/wargame3d_{}.json", secs));
        self.game.save_to_file(&path)?;
        Ok(path.display().to_string())
    }

    fn load_game(&mut self, path: &std::path::Path) -> Result<(), String> {
        let game = GameState::load_from_file(path)?;
        self.game = game;
        self.map_generation += 1;
        self.game_over = None;
        self.selected = None;
        self.pending_recruit = None;
        self.simul_mode = false;
        self.simul_orders.clear();
        self.howitzer_fire_mode = false;
        self.ai_thread = None;
        self.ai_playback_until = None;
        self.refresh_vision();
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// 辅助函数
// ---------------------------------------------------------------------------

/// 武器发射时序（与 `src/fx.rs::weapon_profile` 完全一致：瞄准时长、飞行时长）。
pub struct WeaponProfile {
    pub aim: f64,
    pub flight: f64,
}

/// 依兵种与武器模式决定弹道时序（秒）。
pub fn weapon_profile(kind: UnitKind, aa_mode: bool, missile_mode: bool, area: bool) -> WeaponProfile {
    let p = |aim: f64, flight: f64| WeaponProfile { aim, flight };
    if area {
        return match kind {
            UnitKind::Mortar => p(0.25, 0.62),
            _ => p(0.3, 0.78),
        };
    }
    if aa_mode {
        return p(0.4, 0.42);
    }
    if missile_mode {
        return match kind {
            UnitKind::EliteInfantry | UnitKind::SpecialForces => p(0.5, 0.4),
            UnitKind::Rifleman => p(0.5, 0.4),
            UnitKind::Ifv | UnitKind::CavalryIfv => p(0.35, 0.55),
            UnitKind::AaMgv => p(0.4, 0.42),
            UnitKind::Tank | UnitKind::HeavyTank => p(0.06, 0.16),
            UnitKind::Howitzer => p(0.3, 0.78),
            _ => p(0.3, 0.45),
        };
    }
    match kind {
        UnitKind::Tank | UnitKind::HeavyTank => p(0.1, 0.2),
        UnitKind::Scout => p(0.12, 0.22),
        UnitKind::Ifv | UnitKind::CavalryIfv | UnitKind::AaMgv => p(0.08, 0.15),
        UnitKind::Atgm => p(0.35, 0.55),
        UnitKind::Javelin => p(0.45, 0.72),
        UnitKind::AaInfantry | UnitKind::AaLauncher => p(0.4, 0.42),
        UnitKind::HmgGunner => p(0.08, 0.14),
        UnitKind::AttackHeli | UnitKind::Drone => p(0.22, 0.48),
        _ => p(0.05, 0.12),
    }
}

/// 存档列表（saves/*.json，按文件名排序）。
pub fn scan_saves() -> Vec<(String, PathBuf)> {
    let mut out = Vec::new();
    if let Ok(rd) = std::fs::read_dir("saves") {
        let mut files: Vec<PathBuf> = rd
            .filter_map(|e| e.ok().map(|e| e.path()))
            .filter(|p| p.extension().map(|x| x == "json").unwrap_or(false))
            .collect();
        files.sort();
        for p in files {
            let name = p
                .file_stem()
                .map(|s| s.to_string_lossy().to_string())
                .unwrap_or_default();
            out.push((name, p));
        }
    }
    out
}

fn parse_hex(v: &Value) -> Option<Hex> {
    let arr = v.as_array()?;
    if arr.len() != 2 {
        return None;
    }
    let col = arr[0].as_i64()? as i32;
    let row = arr[1].as_i64()? as i32;
    Some(hex::axial_from_offset(col, row))
}

fn parse_team(v: &Value) -> Option<Team> {
    match v.as_str()? {
        "blue" | "player" | "Player" => Some(Team::Player),
        "red" | "ai" | "Ai" => Some(Team::Ai),
        _ => None,
    }
}

fn parse_kind(v: &Value) -> Option<UnitKind> {
    let s = v.as_str()?;
    UnitKind::all_recruitable()
        .iter()
        .copied()
        .chain(std::iter::once(UnitKind::Headquarters))
        .find(|k| k.token() == s)
}

/// 地形提示文本（对应 `selected_panel` 中的地形说明）。
pub fn terrain_note(game: &GameState, h: Hex) -> Vec<String> {
    let mut out = Vec::new();
    if game.map.forests.contains(&h) {
        out.push("森林".into());
    }
    if game.map.buildings.contains(&h) {
        out.push("楼房".into());
    }
    if game.map.water.contains(&h) {
        out.push("水域".into());
    }
    if game.map.roads.contains(&h) {
        out.push("道路".into());
    }
    if game.map.obstacles.contains(&h) {
        out.push("岩石".into());
    }
    if game.smoke.contains_key(&h) {
        out.push("烟雾".into());
    }
    out
}

/// 估算事件队列的播放时长（与 `GuiApp::drain_ui_events` 的节奏一致）。
pub fn estimate_duration(events: &[Value]) -> f64 {
    let mut total = 0.0;
    for ev in events {
        match ev.get("k").and_then(|v| v.as_str()) {
            Some("move") => {
                let n = ev
                    .get("path")
                    .and_then(|p| p.as_array())
                    .map(|a| a.len())
                    .unwrap_or(1);
                total += 0.16 * (n as f64 - 1.0).max(1.0) + 0.16;
            }
            Some("fire") => {
                let area = ev.get("area").and_then(|v| v.as_bool()).unwrap_or(false);
                let killed = ev.get("killed").and_then(|v| v.as_bool()).unwrap_or(false);
                let aim = if area { 0.3 } else { 0.25 };
                let flight = if area { 0.7 } else { 0.4 };
                total += aim + flight + if killed { 1.5 } else { 0.35 };
            }
            _ => {}
        }
    }
    total.min(40.0) + 0.3
}

fn battle_event_text(ev: &hex_wargame::game::BattleEvent) -> String {
    use hex_wargame::game::BattleEventKind;
    match &ev.kind {
        BattleEventKind::Kill(k) => format!(
            "#{} 第{}回合 击毁 {} {}({}) @{} ← {}（{}）{}",
            ev.seq,
            ev.turn,
            if k.victim_team == Team::Player { "蓝方" } else { "红方" },
            k.victim_label,
            k.victim_kind.name(),
            hex::hex_label(k.victim_pos),
            match (k.attacker_label, k.attacker_kind) {
                (Some(l), Some(kd)) => format!(
                    "{} {}({})",
                    if k.attacker_team == Some(Team::Player) { "蓝方" } else { "红方" },
                    l,
                    kd.name()
                ),
                _ => "未知来源".to_string(),
            },
            k.cause.cn(),
            if k.passenger { "，随载具阵亡" } else { "" }
        ),
        BattleEventKind::Keypoint { hex, center, from, to, by_label, by_kind } => format!(
            "#{} 第{}回合 据点易手 {} → {}：{} 的 {}({}) 占领 {} {}",
            ev.seq,
            ev.turn,
            if *from == Team::Player { "蓝方" } else { "红方" },
            if *to == Team::Player { "蓝方" } else { "红方" },
            if *to == Team::Player { "蓝方" } else { "红方" },
            by_label,
            by_kind.name(),
            hex::hex_label(*hex),
            if *center { "（大本营中心）" } else { "" }
        ),
        BattleEventKind::Victory { winner, reason } => format!(
            "#{} 第{}回合 胜负判定: {}获胜（{}）",
            ev.seq,
            ev.turn,
            if *winner == Team::Player { "蓝方" } else { "红方" },
            reason
        ),
    }
}

/// 无依赖的文本态势图（导出日志用；不复用 mp.rs 以免拖入整个终端渲染模块）。
pub fn render_ascii(game: &GameState, team: Team) -> String {
    let mut out = String::new();
    out.push_str(&format!(
        "第 {} 回合 · {}方视角\n",
        game.turn.max(1),
        if team == Team::Player { "蓝" } else { "红" }
    ));
    let vis = game.vision(team);
    for row in 0..game.map.rows {
        let mut line = String::new();
        for col in 0..game.map.cols {
            let h = hex::axial_from_offset(col, row);
            let revealed = vis.terrain.contains(&h);
            let ch = if let Some(u) = game.units.get(&h) {
                if u.team == team || vis.enemy_units.contains(&h) {
                    u.label
                } else {
                    '·'
                }
            } else if let Some(u) = game.air_units.get(&h) {
                if u.team == team || vis.enemy_units.contains(&h) {
                    u.label
                } else {
                    '·'
                }
            } else if !revealed {
                ' '
            } else if game.map.obstacles.contains(&h) {
                '▲'
            } else if game.map.water.contains(&h) {
                '≈'
            } else if game.map.buildings.contains(&h) {
                '▣'
            } else if game.map.forests.contains(&h) {
                '♣'
            } else {
                '·'
            };
            line.push(ch);
            line.push(' ');
        }
        out.push_str(&line);
        out.push('\n');
    }
    out
}

/// 让 `HashMap` 在不引入 use 的情况下可用（保持与其他模块一致的类型推断）。
#[allow(dead_code)]
type _Unused = HashMap<Hex, i32>;

#[cfg(test)]
mod cargo_tests {
    //! 重型运输直升机装载规则验证：确认「有运力却装不下」只是**运力或行动次数**不足
    //! （步兵运力 = 血量；重直每回合 2 次行动，飞过来 + 装一件就用完了），
    //! 而不是规则缺陷。
    use hex_wargame::game::GameState;
    use hex_wargame::hex::{axial_from_offset, Hex};
    use hex_wargame::unit::{Team, UnitKind};

    /// 找一片连续的平地格（避免岩石/水域/楼房干扰测试）。
    fn plain_run(g: &GameState, n: usize) -> Vec<Hex> {
        for row in 1..g.map.rows - 1 {
            let mut run = Vec::new();
            for col in 1..g.map.cols - 1 {
                // 行尾即断开，保证 run 内的格子两两相邻（同一行连续列）
                let h = axial_from_offset(col, row);
                let ok = !g.map.obstacles.contains(&h)
                    && !g.map.water.contains(&h)
                    && !g.map.buildings.contains(&h);
                if ok {
                    run.push(h);
                    if run.len() == n {
                        return run;
                    }
                } else {
                    run.clear();
                }
            }
            run.clear();   // 不跨行拼接
        }
        panic!("地图上找不到足够的平地格");
    }

    fn setup() -> GameState {
        let mut g = GameState::new_seeded(7);
        g.units.clear();
        g.air_units.clear();
        g.enter_test_mode();
        g
    }

    #[test]
    fn heavy_transport_load_requires_weight_and_actions() {
        let mut g = setup();
        let spots = plain_run(&g, 6);
        let a = spots[1];      // 装载格（直升机悬停处）
        let start = spots[5];  // 直升机起飞格
        let cargo_spot = spots[0]; // 货物待命格（与 a 相邻）
        let far = spots[2];        // 另一个相邻格
        g.test_place_unit(Team::Player, UnitKind::HumveeHmg, a).unwrap();
        g.test_place_unit(Team::Player, UnitKind::HeavyTransportHeli, start).unwrap();
        // 直升机沿直线飞过来（4 格）
        g.move_unit(start, &[spots[5], spots[4], spots[3], spots[2], a], true).unwrap();

        // ① 装入悍马（6/8）
        g.heli_board(a).expect("应能装载悍马");
        assert_eq!(g.air_units.get(&a).unwrap().used_weight(), 6);

        // ② 同一回合再装：行动次数已用尽（飞过来 1 次 + 装悍马 1 次 = 2 次）
        g.test_place_unit(Team::Player, UnitKind::AaInfantry, cargo_spot).unwrap();
        g.move_unit(cargo_spot, &[cargo_spot, a], false).unwrap();
        let err = g.heli_board(a).unwrap_err();
        assert!(err.contains("行动次数不足"), "应提示行动不足: {err}");

        // ③ 新回合：剩 2 点运力，1 运力的防空兵应能装载
        g.begin_turn(Team::Player);
        g.begin_turn(Team::Player);
        g.heli_board(a).expect("剩 2 点运力应能装载 1 运力的单位");
        assert_eq!(g.air_units.get(&a).unwrap().used_weight(), 7);
        assert_eq!(g.air_units.get(&a).unwrap().passengers.len(), 2);

        // ④ 再装 3 运力的步枪手：只剩 1 点运力 → 必须被拒绝
        g.test_place_unit(Team::Player, UnitKind::Rifleman, far).unwrap();
        g.move_unit(far, &[far, a], false).unwrap();
        g.begin_turn(Team::Player);
        g.begin_turn(Team::Player);
        let err = g.heli_board(a).unwrap_err();
        assert!(err.contains("载重不足"), "应提示载重不足: {err}");
        assert_eq!(g.air_units.get(&a).unwrap().passengers.len(), 2);
    }

    #[test]
    fn heavy_transport_fills_to_capacity_exactly() {
        let mut g = setup();
        let spots = plain_run(&g, 6);
        let a = spots[1];
        let start = spots[5];
        let cargo_spot = spots[0];
        g.test_place_unit(Team::Player, UnitKind::HeavyTransportHeli, start).unwrap();
        g.move_unit(start, &[spots[5], spots[4], spots[3], spots[2], a], true).unwrap();
        // 步兵运力 = 血量：3 + 3 + 2 = 8，刚好装满重直（容量 8）
        for kind in [UnitKind::Rifleman, UnitKind::EliteInfantry, UnitKind::SpecialForces] {
            g.test_place_unit(Team::Player, kind, cargo_spot).unwrap();
            g.move_unit(cargo_spot, &[cargo_spot, a], false).unwrap();
            g.begin_turn(Team::Player);
            g.begin_turn(Team::Player);
            g.heli_board(a).unwrap_or_else(|e| panic!("{kind:?} 应能装载: {e}"));
        }
        let heli = g.air_units.get(&a).unwrap();
        assert_eq!(heli.used_weight(), 8);
        assert_eq!(heli.passengers.len(), 3);
        assert!(!heli.has_space(), "装满后应无剩余运力");
    }
}

#[cfg(test)]
mod map_load_tests {
    //! 自定义地图加载自检：确认楼房/道路等地形确实进入了 GameMap
    //! （前端地形位掩码 ≥16 的取值必须用十六进制字符编码，否则会被写成 '0'）。
    use hex_wargame::game::GameState;
    use hex_wargame::hex::axial_from_offset;
    use hex_wargame::mapdef::CustomMap;
    use std::path::PathBuf;

    #[test]
    fn campaign_map_keeps_all_terrain() {
        let path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("maps/战役示例.json");
        if !path.is_file() {
            return;
        }
        let cm = CustomMap::load(&path).expect("地图应能加载");
        let g = GameState::new_custom_deploy(7, cm.clone());
        let h_b = axial_from_offset(9, 5); // buildings[0]
        let h_r = axial_from_offset(2, 6); // roads[0]
        assert!(g.map.buildings.contains(&h_b), "楼房应进入 GameMap");
        assert!(g.map.roads.contains(&h_r), "道路应进入 GameMap");
        // 位掩码编码：道路 = 16 必须编码为十六进制字符 '1'*16 -> g? 这里直接验证 terrain_rows 不丢位
        let rows = super::snap::terrain_rows(&g);
        let row_data = super::snap::terrain_rows(&g);
        let rows = row_data;
        let cell = |row: usize, col: usize| -> u32 {
            let line = &rows[row];
            u32::from_str_radix(line.get(col * 2..col * 2 + 2).unwrap_or("00"), 16).unwrap_or(0)
        };
        assert_eq!(cell(5, 9) & 4, 4, "楼房位不能丢失: {:?}", rows[5]);
        assert_eq!(cell(6, 2) & 16, 16, "道路位不能丢失: {:?}", rows[6]);
        assert_eq!(cell(6, 9) & 8, 8, "水域位不能丢失: {:?}", rows[6]);
    }
}
