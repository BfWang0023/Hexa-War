//! 单位定义：全部棋子及属性、搭载（运输）能力、双武器模式、主动防御、压制。

use crate::hex::Hex;

/// 阵营。
#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Debug, serde::Serialize, serde::Deserialize)]
pub enum Team {
    Player,
    Ai,
}

impl Team {
    /// 中文阵营名（用于日志）。
    pub fn cn(self) -> &'static str {
        match self {
            Team::Player => "玩家",
            Team::Ai => "AI",
        }
    }

    pub fn opponent(self) -> Team {
        match self {
            Team::Player => Team::Ai,
            Team::Ai => Team::Player,
        }
    }
}

/// 全部兵种。
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug, serde::Serialize, serde::Deserialize)]
pub enum UnitKind {
    Rifleman,      // 步枪手（主武器步枪 + M3E1-XM1176 副武器）
    Scout,         // 侦察战车（高机动/高视野，AI 优先前出侦察）
    Atgm,          // TOW 射手（反坦克导弹，只能打车辆，攻击耗 2 行动）
    Javelin,       // Javelin 射手（反坦克导弹，只能打车辆，攻击耗 1 行动）
    SpecialForces, // 特战小队（步枪 + M3E1 火箭筒 + Stinger 防空导弹，闪避高、楼房隐蔽翻倍）
    EliteInfantry, // 精锐步兵班组（步枪 + M3E1-HE 火箭筒，按 M 切换）
    Tank,          // 坦克
    HeavyTank,     // 主战坦克（主动防御）
    Ifv,           // 步兵战车（可搭载 1 名步兵，另携 2 枚 TOW 反坦克导弹）
    CavalryIfv,    // 装甲骑兵战车（Ifv 底盘 + 8 发 TOW 反坦克导弹 + 主动防御；
                   // 只能搭载血量 1 的步兵：TOW 射手/Javelin/防空导弹手）
    HumveeHmg,     // 悍马-重机枪（悍马底盘 + 遥控重机枪，可对空；对步兵有压制；攻击耗 1 行动，无需架设）
    HumveeTow,     // 悍马-TOW（悍马底盘 + TOW 反坦克导弹，只能打车辆）
    HumveeJavelin, // 悍马-Javelin（悍马底盘 + Javelin 反坦克导弹，只能打车辆）
    Truck,         // 卡车（可搭载 3 名步兵，不能攻击）
    Howitzer,      // 榴弹炮（范围攻击+压制，需先「架设」；M864 子母弹副武器）
    Mortar,        // 自行迫击炮（范围攻击+压制，无需架设）
    AttackHeli,    // 武装直升机（空中单位）
    TransportHeli, // 运输直升机（空中单位，可搭载 1 名步兵）
    HeavyTransportHeli, // 重型运输直升机（血量 2、可搭载 2 名步兵、3 发诱饵弹）
    Drone,         // 侦察无人机（空中单位，视野极远，携带 1 枚反坦克导弹）
    AaInfantry,    // Stinger射手（便携 Stinger，只能攻击直升机）
    HmgGunner,     // 重机枪手（对步兵 50% 概率造成 2 点伤害并压制；可对空；
                   // 攻击耗 1 行动，但必须先「架设」——移动后需重新架设）
    AaMgv,         // M-SHORAD 高射机枪战车（空/地都能打，可切换 Stinger 导弹模式）
    AaLauncher,    // 悍马-Stinger（悍马底盘 + 遥控四联 Stinger，只能攻击直升机）
    Headquarters,  // 指挥部（可持续部署模式）：HP2 不可行动，摧毁即胜
    Supply,        // 补给：行动力 0（不可主动移动/攻击）；每回合 2 行动，消耗 1 行动
                   // 为半径 2 格内友军补给（受补给方也须有行动并消耗 1 行动）；
                   // 卡车/重型运输直升机可载运（占 2 点运力）
}

impl UnitKind {
    pub fn name(self) -> &'static str {
        match self {
            UnitKind::Rifleman => "步枪手",
            UnitKind::Scout => "侦察战车",
            UnitKind::Atgm => "TOW射手",
            UnitKind::Javelin => "Javelin射手",
            UnitKind::SpecialForces => "特战小队",
            UnitKind::EliteInfantry => "精锐步兵班组",
            UnitKind::Tank => "坦克",
            UnitKind::HeavyTank => "主战坦克",
            UnitKind::Ifv => "步兵战车",
            UnitKind::CavalryIfv => "装甲骑兵战车",
            UnitKind::HumveeHmg => "悍马-重机枪",
            UnitKind::HumveeTow => "悍马-TOW",
            UnitKind::HumveeJavelin => "悍马-Javelin",
            UnitKind::Truck => "卡车",
            UnitKind::Howitzer => "榴弹炮",
            UnitKind::Mortar => "自行迫击炮",
            UnitKind::AttackHeli => "武装直升机",
            UnitKind::TransportHeli => "运输直升机",
            UnitKind::HeavyTransportHeli => "重型运输直升机",
            UnitKind::Drone => "侦察无人机",
            UnitKind::AaInfantry => "Stinger射手",
            UnitKind::HmgGunner => "重机枪手",
            UnitKind::AaMgv => "M-SHORAD",
            UnitKind::AaLauncher => "悍马-Stinger",
            UnitKind::Headquarters => "指挥部",
            UnitKind::Supply => "补给",
        }
    }

    /// 全部可招募兵种（部署/追加部署面板顺序；不含指挥部——它由开局自动生成）。
    pub fn all_recruitable() -> &'static [UnitKind] {
        &[
            UnitKind::Rifleman,
            UnitKind::Scout,
            UnitKind::Atgm,
            UnitKind::Javelin,
            UnitKind::SpecialForces,
            UnitKind::EliteInfantry,
            UnitKind::Tank,
            UnitKind::HeavyTank,
            UnitKind::Ifv,
            UnitKind::CavalryIfv,
            UnitKind::HumveeHmg,
            UnitKind::HumveeTow,
            UnitKind::HumveeJavelin,
            UnitKind::Truck,
            UnitKind::Howitzer,
            UnitKind::Mortar,
            UnitKind::AttackHeli,
            UnitKind::TransportHeli,
            UnitKind::HeavyTransportHeli,
            UnitKind::Drone,
            UnitKind::AaInfantry,
            UnitKind::HmgGunner,
            UnitKind::AaMgv,
            UnitKind::AaLauncher,
            UnitKind::Supply,
        ]
    }

    /// 终端命令里使用的 ASCII 代号（与中文名 name() 二选一即可）。
    pub fn token(self) -> &'static str {
        match self {
            UnitKind::Rifleman => "rifleman",
            UnitKind::Scout => "scout",
            UnitKind::Atgm => "atgm",
            UnitKind::Javelin => "javelin",
            UnitKind::SpecialForces => "special_forces",
            UnitKind::EliteInfantry => "elite_infantry",
            UnitKind::Tank => "tank",
            UnitKind::HeavyTank => "heavy_tank",
            UnitKind::Ifv => "ifv",
            UnitKind::CavalryIfv => "cavalry_ifv",
            UnitKind::HumveeHmg => "humvee_hmg",
            UnitKind::HumveeTow => "humvee_tow",
            UnitKind::HumveeJavelin => "humvee_javelin",
            UnitKind::Truck => "truck",
            UnitKind::Howitzer => "howitzer",
            UnitKind::Mortar => "mortar",
            UnitKind::AttackHeli => "attack_heli",
            UnitKind::TransportHeli => "transport_heli",
            UnitKind::HeavyTransportHeli => "heavy_transport_heli",
            UnitKind::Drone => "drone",
            UnitKind::AaInfantry => "aa_infantry",
            UnitKind::HmgGunner => "hmg_gunner",
            UnitKind::AaMgv => "aa_mgv",
            UnitKind::AaLauncher => "aa_launcher",
            UnitKind::Headquarters => "headquarters",
            UnitKind::Supply => "supply",
        }
    }

    /// 解析兵种文本：接受中文名（如「坦克」）或 ASCII 代号（如 tank，大小写不敏感）。
    pub fn from_token(text: &str) -> Option<UnitKind> {
        let raw = text.trim();
        if raw.is_empty() {
            return None;
        }
        let lower = raw.to_ascii_lowercase();
        Self::all_recruitable()
            .iter()
            .copied()
            .chain(std::iter::once(UnitKind::Headquarters))
            .find(|kind| kind.name() == raw || kind.token() == lower)
    }

    /// 射程（双武器单位此处为主武器射程）
    pub fn range(self) -> i32 {
        match self {
            UnitKind::Rifleman => 2,
            UnitKind::Scout => 4,
            UnitKind::Atgm => 9, // TOW 反坦克导弹（射程 9）
            UnitKind::Javelin => 5, // Javelin（射程 5）
            UnitKind::SpecialForces => 3, // 步枪（M3E1 射程 3；Stinger 射程 8）
            UnitKind::EliteInfantry => 2, // 主武器射程 2（M3E1 射程 3 另计）
            UnitKind::HmgGunner => 4,
            UnitKind::Tank => 6,
            UnitKind::HeavyTank => 8,
            UnitKind::Ifv | UnitKind::CavalryIfv => 4,
            UnitKind::HumveeHmg => 4,      // 车载重机枪（同重机枪手）
            UnitKind::HumveeTow => 9,      // TOW 反坦克导弹（同 TOW 射手，射程 9）
            UnitKind::HumveeJavelin => 5,  // Javelin 反坦克导弹（同 Javelin 射手，射程 5）
            UnitKind::Truck => 0,    // 卡车不能攻击
            UnitKind::Howitzer => 16,
            UnitKind::Mortar => 8,
            UnitKind::AttackHeli => 6,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 0, // 不能攻击
            UnitKind::Drone => 4,
            UnitKind::AaInfantry => 8, // Stinger 防空导弹
            UnitKind::AaMgv => 4, // 机枪模式（导弹模式 8）
            UnitKind::AaLauncher => 8, // Stinger 防空导弹
            UnitKind::Headquarters => 0, // 指挥部不攻击
            UnitKind::Supply => 0,    // 补给不攻击
        }
    }

    /// 护甲
    pub fn armor(self) -> i32 {
        match self {
            // 步兵单位护甲 0（软目标）；榴弹炮同为 0。
            UnitKind::Rifleman => 0,
            UnitKind::HmgGunner => 0,
            UnitKind::Atgm => 0,
            UnitKind::Javelin => 0,
            UnitKind::SpecialForces => 0,
            UnitKind::EliteInfantry => 0,
            UnitKind::AaInfantry => 0,
            UnitKind::Howitzer => 0,
            UnitKind::Scout => 2,
            UnitKind::Tank => 3,
            UnitKind::HeavyTank => 4, // 主战坦克护甲 4
            UnitKind::Ifv | UnitKind::CavalryIfv => 2,
            UnitKind::Truck => 1,
            UnitKind::Mortar => 2,
            UnitKind::AttackHeli => 2,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 1,
            UnitKind::Drone => 1,
            UnitKind::AaMgv => 2,
            // 悍马系列：统一护甲 1
            UnitKind::HumveeHmg
            | UnitKind::HumveeTow
            | UnitKind::HumveeJavelin
            | UnitKind::AaLauncher => 1,
            UnitKind::Headquarters => 1, // 指挥部（非步兵，护甲 1）
            UnitKind::Supply => 1,    // 1 点护甲
        }
    }

    /// 坦克炮命中**车辆**时的「殉爆」概率（%），按目标防护递减：
    /// - 主战坦克（护甲 4）：**30**
    /// - 一般坦克（护甲 3）：**60**
    /// - 步战车 / 装甲骑兵战车（护甲 2）：**60**
    /// - 其它护甲 2 车辆：**70**
    /// - 护甲 1 车辆：**80**
    ///
    /// 步兵/空中单位（非车辆）返回 0，即不会被坦克炮殉爆。
    /// 殉爆效果为本次攻击造成 2 点伤害（取代普通 1 点）。
    pub fn cook_off_chance(self) -> u32 {
        if !self.is_vehicle() {
            return 0; // 步兵、空中单位不殉爆
        }
        match self {
            UnitKind::HeavyTank => 30, // 主战坦克（护甲 4）
            UnitKind::Tank => 60,      // 一般坦克（护甲 3）
            UnitKind::Ifv | UnitKind::CavalryIfv => 60, // 步战车/装甲骑兵战车（护甲 2）
            _ if self.armor() == 2 => 70, // 其它护甲 2 车辆
            _ if self.armor() == 1 => 80, // 护甲 1 车辆
            _ => 0, // 护甲 0（榴弹炮）等不殉爆
        }
    }

    /// 攻击力（双武器单位此处为主武器攻击力）。
    /// 原攻击力 3 的武器统一提升为 4；Javelin 武器特别提升为 5。
    pub fn attack(self) -> i32 {
        match self {
            UnitKind::Rifleman => 1,
            UnitKind::Scout => 2,
            UnitKind::Atgm => 4,     // TOW（原 3）
            UnitKind::Javelin => 5,  // Javelin 特别提升
            UnitKind::SpecialForces => 1, // 步枪（M3E1 攻 4；Stinger 攻 2）
            UnitKind::EliteInfantry => 1, // 步枪（M3E1 攻 4）
            UnitKind::HmgGunner => 2, // 重机枪
            UnitKind::Tank => 4,      // 坦克炮（原 3）
            UnitKind::HeavyTank => 4, // 主战坦克主炮（原 3）
            UnitKind::Ifv | UnitKind::CavalryIfv => 2,
            UnitKind::HumveeHmg => 2,      // 重机枪（同重机枪手）
            UnitKind::HumveeTow => 4,      // TOW 反坦克导弹（原 3）
            UnitKind::HumveeJavelin => 5,  // Javelin 反坦克导弹（特别提升）
            UnitKind::Truck => 0, // 卡车不能攻击
            UnitKind::Howitzer => 2, // 常规弹（M864 攻 4）
            UnitKind::Mortar => 1,
            UnitKind::AttackHeli => 4, // 反坦克导弹/火箭（原 3）
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 0, // 不能攻击
            UnitKind::Drone => 4, // 反坦克导弹（原 3）
            UnitKind::AaInfantry => 2,
            UnitKind::AaMgv => 2,
            UnitKind::AaLauncher => 2,
            UnitKind::Headquarters => 0, // 指挥部不攻击
            UnitKind::Supply => 0,    // 补给不攻击
        }
    }

    /// 命中率（百分比）。榴弹炮/自行迫击炮此处为中心命中率，周围 6 格另计。
    pub fn hit_rate(self) -> u32 {
        match self {
            UnitKind::Rifleman => 80,
            UnitKind::Scout => 80,
            UnitKind::Atgm => 90,
            UnitKind::Javelin => 90,
            UnitKind::SpecialForces => 80, // 步枪（M3E1 装甲/楼房 100%；Stinger 70%）
            UnitKind::EliteInfantry => 80, // 步枪（M3E1 装甲/楼房 100%）
            UnitKind::Tank => 90,
            UnitKind::HeavyTank => 100,
            UnitKind::Ifv | UnitKind::CavalryIfv => 80,
            UnitKind::Truck => 0,
            UnitKind::Howitzer => 80, // 中心命中率（周围 50%）；M864 均为 100%
            UnitKind::Mortar => 60, // 中心命中率（周围 30%）
            UnitKind::AttackHeli => 80,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 0,
            UnitKind::Drone => 90,
            UnitKind::AaInfantry => 70,
            UnitKind::HmgGunner => 80, // 重机枪
            UnitKind::AaMgv => 80,
            UnitKind::AaLauncher => 70, // Stinger
            UnitKind::HumveeHmg => 80,      // 重机枪（同重机枪手）
            UnitKind::HumveeTow => 90,      // TOW（同 TOW 射手）
            UnitKind::HumveeJavelin => 90,  // Javelin（同 Javelin 射手）
            UnitKind::Headquarters => 0,
            UnitKind::Supply => 0,
        }
    }

    /// 血量上限
    pub fn max_hp(self) -> i32 {
        match self {
            UnitKind::Rifleman => 3,
            UnitKind::EliteInfantry => 3,
            UnitKind::SpecialForces => 2,
            UnitKind::Ifv | UnitKind::CavalryIfv => 2,
            // 悍马系列：统一血量 2
            UnitKind::HumveeHmg
            | UnitKind::HumveeTow
            | UnitKind::HumveeJavelin
            | UnitKind::AaLauncher => 2,
            UnitKind::AttackHeli => 2,
            UnitKind::Tank => 2,
            UnitKind::HeavyTank => 2,
            UnitKind::Headquarters => 2, // 指挥部 HP 2
            UnitKind::HeavyTransportHeli => 2, // 重型运输直升机血量 2
            UnitKind::HmgGunner => 1,
            _ => 1,
        }
    }

    /// 行动次数（每回合）
    pub fn action_count(self) -> i32 {
        match self {
            UnitKind::Rifleman => 3,
            UnitKind::Scout => 3,
            UnitKind::SpecialForces => 3,
            UnitKind::EliteInfantry => 3,
            UnitKind::Atgm => 2,
            UnitKind::Javelin => 2,
            UnitKind::Tank => 2,
            UnitKind::HeavyTank => 2,
            UnitKind::Ifv | UnitKind::CavalryIfv => 2,
            UnitKind::Truck => 2,
            UnitKind::Howitzer => 1, // 每回合 1 次行动：架设或射击
            UnitKind::Mortar => 2,
            UnitKind::AttackHeli => 2,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 2,
            UnitKind::Drone => 2,
            UnitKind::AaInfantry => 2,
            UnitKind::HmgGunner => 2,
            UnitKind::AaMgv => 2,
            UnitKind::AaLauncher => 2,
            // 悍马系列：统一行动次数 2
            UnitKind::HumveeHmg | UnitKind::HumveeTow | UnitKind::HumveeJavelin => 2,
            UnitKind::Headquarters => 0, // 指挥部不攻击
            UnitKind::Supply => 2,    // 补给：每回合可补给 2 次
        }
    }

    /// 行动力（一次移动最多走过的格子数）。步兵行动力 1（每次移动只能动 1 格）。
    pub fn movement(self) -> i32 {
        match self {
            UnitKind::Rifleman => 1,
            UnitKind::Scout => 3,
            UnitKind::Atgm => 1,
            UnitKind::Javelin => 1,
            UnitKind::SpecialForces => 1,
            UnitKind::EliteInfantry => 1,
            UnitKind::Tank => 3,
            UnitKind::HeavyTank => 3,
            UnitKind::Ifv | UnitKind::CavalryIfv => 3,
            UnitKind::Truck => 4,
            // 悍马系列：统一行动力 4
            UnitKind::HumveeHmg
            | UnitKind::HumveeTow
            | UnitKind::HumveeJavelin
            | UnitKind::AaLauncher => 4,
            UnitKind::Howitzer => 0, // 榴弹炮不能自主移动，需卡车装载
            UnitKind::Mortar => 3,
            UnitKind::AttackHeli => 8,   // 直升机飞得快，且可越过岩石
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 10,
            UnitKind::Drone => 10, // 侦察无人机行动力 10
            UnitKind::AaInfantry => 1,
            UnitKind::HmgGunner => 1,
            UnitKind::AaMgv => 3,
            UnitKind::Headquarters => 0, // 指挥部不可移动
            UnitKind::Supply => 0,    // 补给不可主动移动
        }
    }

    /// 攻击消耗的行动次数（仅 TOW 射手/悍马-TOW 攻击消耗 2 次，其余均耗 1 次）。
    /// 重机枪手/悍马-重机枪每次攻击也只耗 1 次；重机枪手另有「架设」前置。
    pub fn attack_cost(self) -> i32 {
        match self {
            UnitKind::Atgm | UnitKind::HumveeTow => 2, // TOW 射手/悍马-TOW：重型导弹装填慢
            _ => 1, // 其余（含 Javelin 射手/悍马-Javelin/重机枪手/悍马-重机枪）耗 1 行动
        }
    }

    /// 开火前是否必须先「架设」：榴弹炮需架设后才能炮击/放烟，
    /// 重机枪手需架设后才能开火（移动/装车后需重新架设）。
    pub fn needs_deploy(self) -> bool {
        matches!(self, UnitKind::Howitzer | UnitKind::HmgGunner)
    }

    /// 副武器（M 键）弹药上限：与 `Unit::new` 的初始化保持一致。
    /// 文本快照据此显示 `副弹x/y`，让消费者能判断该单位还能不能开副武器。
    pub fn max_missile_ammo(self) -> i32 {
        match self {
            UnitKind::Ifv => 2,                                    // TOW
            UnitKind::CavalryIfv => 8,                             // TOW
            UnitKind::AaMgv => 2,                                  // Stinger
            UnitKind::EliteInfantry | UnitKind::SpecialForces => 4, // M3E1
            UnitKind::Rifleman => 4,                               // M3E1-XM1176
            UnitKind::Howitzer => 4,                               // M864 子母弹
            UnitKind::Tank | UnitKind::HeavyTank => 42,            // 车载重机枪
            _ => 0,
        }
    }

    /// 第三武器（A 键）弹药上限：仅特战小队的 Stinger。
    pub fn max_aa_ammo(self) -> i32 {
        if self == UnitKind::SpecialForces {
            1
        } else {
            0
        }
    }

    /// 携带弹药数（主武器；每次攻击消耗 1 发）。
    /// 补给单位此处为其可提供的补给点数（5 点，最多补给 5 次）。
    pub fn max_ammo(self) -> i32 {
        match self {
            UnitKind::Rifleman => 10,
            UnitKind::Scout => 6,
            UnitKind::Atgm => 4,
            UnitKind::Javelin => 4,
            UnitKind::SpecialForces => 10, // 步枪弹（M3E1 弹 4、Stinger 1 发另计）
            UnitKind::EliteInfantry => 10, // 步枪弹（M3E1 弹 4 另计）
            UnitKind::Tank => 42,
            UnitKind::HeavyTank => 42,
            UnitKind::Ifv => 30,
            UnitKind::CavalryIfv => 30,
            UnitKind::Truck => 0,
            UnitKind::Howitzer => 24, // 常规弹（M864 子母弹 4 另计）
            UnitKind::Mortar => 24,
            UnitKind::AttackHeli => 16,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 0,
            UnitKind::Drone => 1,
            UnitKind::AaInfantry => 4, // Stinger
            UnitKind::HmgGunner => 8, // 重机枪 8 发
            UnitKind::AaMgv => 25,
            UnitKind::AaLauncher => 8, // Stinger
            UnitKind::HumveeHmg => 12,     // 重机枪（弹药增至 12）
            UnitKind::HumveeTow | UnitKind::HumveeJavelin => 8, // 反坦克导弹（增至 8）
            UnitKind::Headquarters => 0, // 指挥部无武器
            UnitKind::Supply => 5,    // 补给：携带 5 点弹药（最多为 5 个单位补给）
        }
    }

    /// 是否能够发动攻击（卡车攻击力为 0，不能攻击）
    pub fn can_attack(self) -> bool {
        self.attack() > 0
    }

    /// 隐蔽级别：步兵 2，其它单位 1。
    /// 隐蔽 2 的单位被发现需 视野/2；特战小队进入森林/楼房隐蔽值翻倍为 4。
    pub fn concealment(self) -> i32 {
        if self.is_foot() {
            2
        } else {
            1
        }
    }

    /// 部署阶段的招募费用。
    pub fn recruit_cost(self) -> i32 {
        match self {
            UnitKind::Rifleman => 12,
            UnitKind::AaInfantry => 6,
            UnitKind::HmgGunner => 8,
            UnitKind::Truck => 8,
            UnitKind::Atgm | UnitKind::TransportHeli => 8,
            UnitKind::HeavyTransportHeli => 20,
            UnitKind::Mortar => 10,
            UnitKind::Ifv | UnitKind::AaMgv | UnitKind::Drone | UnitKind::HumveeHmg => 12,
            UnitKind::CavalryIfv | UnitKind::HumveeJavelin => 20,
            UnitKind::Javelin => 10,
            UnitKind::Scout => 10,
            UnitKind::HumveeTow => 14,
            UnitKind::SpecialForces => 18,
            UnitKind::Howitzer | UnitKind::AaLauncher => 16,
            UnitKind::AttackHeli => 24,
            UnitKind::EliteInfantry => 15,
            UnitKind::Tank => 24,
            UnitKind::HeavyTank => 32,
            UnitKind::Headquarters => 0, // 不可招募（开局自动生成）
            UnitKind::Supply => 15,   // 补给
        }
    }

    /// 视野（侦察距离，格）：该单位能“看到”多远的格子。
    /// 我方所有单位视野共享；榴弹炮/迫击炮（间瞄火力）无需视野即可炮击。
    pub fn vision(self) -> i32 {
        match self {
            UnitKind::Rifleman
            | UnitKind::Atgm
            | UnitKind::Javelin
            | UnitKind::AaInfantry
            | UnitKind::EliteInfantry
            | UnitKind::HmgGunner => 4, // 普通步兵视野 4
            UnitKind::SpecialForces => 6, // 特战小队视野 6（精锐侦察兵）
            UnitKind::Scout => 8, // 侦察战车视野远
            UnitKind::Truck => 4,
            UnitKind::Tank | UnitKind::HeavyTank | UnitKind::Ifv | UnitKind::CavalryIfv | UnitKind::AaMgv | UnitKind::Howitzer | UnitKind::Mortar => 5,
            // 悍马-重机枪/TOW/Javelin：视野同其搭载武器的步兵小组（4）
            UnitKind::HumveeHmg | UnitKind::HumveeTow | UnitKind::HumveeJavelin => 4,
            UnitKind::AaLauncher => 6,
            UnitKind::AttackHeli | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 9,
            UnitKind::Drone => 12, // 侦察无人机视野最远
            UnitKind::Headquarters => 0, // 指挥部无视野（不可行动）
            UnitKind::Supply => 0,    // 补给无视野
        }
    }

    /// AI 眼中的单位价值（用于选择行动顺序）
    pub fn value(self) -> i32 {
        match self {
            UnitKind::Rifleman => 2,
            UnitKind::Headquarters => 5, // 指挥部：摧毁即胜
            UnitKind::Scout => 5, // 侦察战车先动（前出开眼）
            UnitKind::Atgm => 3,
            UnitKind::Javelin => 4,
            UnitKind::SpecialForces => 6,
            UnitKind::EliteInfantry => 6,
            UnitKind::Tank => 5,
            UnitKind::HeavyTank => 6,
            UnitKind::Ifv | UnitKind::CavalryIfv => 4,
            UnitKind::HumveeHmg => 4,
            UnitKind::HumveeTow => 4,
            UnitKind::HumveeJavelin => 5,
            UnitKind::Truck => 3, // 在步兵散开前先行动以便搭载
            UnitKind::Howitzer => 7,
            UnitKind::Mortar => 5,
            UnitKind::AttackHeli => 8,
            UnitKind::TransportHeli | UnitKind::HeavyTransportHeli => 3,
            UnitKind::Drone => 4,
            UnitKind::AaInfantry => 2,
            UnitKind::HmgGunner => 8,
            UnitKind::AaMgv => 4,
            UnitKind::AaLauncher => 5,
            UnitKind::Supply => 3, // 补给资产
        }
    }

    /// 攻击方能否对目标造成伤害：攻击力 >= 目标护甲
    pub fn can_damage(self, target: UnitKind) -> bool {
        self.attack() >= target.armor()
    }

    /// 间瞄火力（榴弹炮/自行迫击炮）的爆炸压制能否作用于目标。
    /// 护甲 ≥ 2 的单位对炮弹破片免疫，不会被火炮压制（仍可被正常击伤/击毁）。
    pub fn artillery_suppresses(self, target: UnitKind) -> bool {
        if matches!(self, UnitKind::Howitzer | UnitKind::Mortar) {
            target.armor() < 2
        } else {
            true
        }
    }

    /// 载重能力（单位：重量点）。只有以下运输单位有载重，其余为 0：
    /// - 卡车 9（不可运载悍马系列/侦察战车/自行迫击炮）；
    /// - 重型运输直升机 8；
    /// - 步兵战车 3（不可运载补给）；
    /// - 运输直升机 3（不可运载补给）；
    /// - 装甲骑兵战车 1。
    pub fn capacity(self) -> i32 {
        match self {
            UnitKind::CavalryIfv => 1,
            UnitKind::Ifv | UnitKind::TransportHeli => 3,
            UnitKind::HeavyTransportHeli => 8,
            UnitKind::Truck => 9,
            _ => 0,
        }
    }

    /// 该兵种作为「货物」时的重量（单位：重量点）。
    /// - 步兵：每 1 HP 对应 1 重量；
    /// - 补给 3、榴弹炮 5、悍马系列 6、侦察战车 7、自行迫击炮 8；
    /// - 其余单位不可被运载，返回 0。
    pub fn cargo_weight(self) -> i32 {
        if self.is_infantry() {
            return self.max_hp();
        }
        match self {
            UnitKind::Supply => 3,
            UnitKind::Howitzer => 5,
            UnitKind::HumveeHmg
            | UnitKind::HumveeTow
            | UnitKind::HumveeJavelin
            | UnitKind::AaLauncher => 6,
            UnitKind::Scout => 7,
            UnitKind::Mortar => 8,
            _ => 0,
        }
    }

    /// 是否是可被运输的货物兵种（步兵 / 榴弹炮 / 补给 / 悍马系列 / 侦察战车 / 自行迫击炮）。
    pub fn can_be_cargo(self) -> bool {
        self.is_infantry()
            || self.is_humvee()
            || matches!(
                self,
                UnitKind::Supply | UnitKind::Howitzer | UnitKind::Scout | UnitKind::Mortar
            )
    }

    /// 本兵种作为运输载具时，能否搭载该货物（**只判兵种类别，不含重量判定**）。
    /// 重量是否装得下另由 `capacity()` 与 `cargo_weight()` 校验：
    /// - 卡车：步兵、榴弹炮、补给（不可载悍马/侦察战车/迫击炮）；
    /// - 步兵战车：步兵、榴弹炮（不可载补给；榴弹炮 5 > 3 实际装不下）；
    /// - 装甲骑兵战车：仅步兵（载重 1，实际只装得下 1 重量的步兵）；
    /// - 运输直升机：除补给外的全部可运载货物（受载重 3 限制）；
    /// - 重型运输直升机：全部可运载货物。
    pub fn can_load_cargo(self, cargo: UnitKind) -> bool {
        if !cargo.can_be_cargo() {
            return false;
        }
        match self {
            UnitKind::Ifv => cargo.is_infantry() || cargo == UnitKind::Howitzer,
            UnitKind::CavalryIfv => cargo.is_infantry(),
            UnitKind::Truck => {
                cargo.is_infantry() || matches!(cargo, UnitKind::Howitzer | UnitKind::Supply)
            }
            UnitKind::TransportHeli => cargo != UnitKind::Supply,
            UnitKind::HeavyTransportHeli => true,
            _ => false,
        }
    }

    /// 校验「运输单位 + 初始搭载 cargo」是否合法（兵种类别 + 载重），
    /// 合法则返回**总招募费用**（载具费用 + 各货物费用之和）。
    /// 招募（初始部署 / 首回合招募 / 追加部署）时用于一次性购入已装载的运输单位。
    pub fn loaded_recruit_cost(self, cargo: &[UnitKind]) -> Result<i32, String> {
        if cargo.is_empty() {
            return Ok(self.recruit_cost());
        }
        if self.capacity() == 0 {
            return Err(format!("{} 不是运输单位，不能携带初始搭载", self.name()));
        }
        let mut used = 0i32;
        for c in cargo {
            if !self.can_load_cargo(*c) {
                return Err(format!("{} 不能搭载 {}", self.name(), c.name()));
            }
            used += c.cargo_weight();
        }
        if used > self.capacity() {
            return Err(format!(
                "{} 初始搭载超出载重（{} > {}）",
                self.name(),
                used,
                self.capacity()
            ));
        }
        Ok(self.recruit_cost() + cargo.iter().map(|c| c.recruit_cost()).sum::<i32>())
    }

    /// 是否为可被搭载的步兵（含防空导弹手）
    pub fn is_infantry(self) -> bool {
        matches!(
            self,
            UnitKind::Rifleman | UnitKind::Atgm | UnitKind::Javelin | UnitKind::SpecialForces | UnitKind::EliteInfantry | UnitKind::AaInfantry
        )
    }

    /// 是否为步兵单位（含防空步兵）：唯一能进入楼房的单位类别。
    /// 指挥部视作步兵判定（隐蔽 2、楼内 ×0.6、XM1176 强制击杀），
    /// 但不可被装载（不进 is_infantry）。
    pub fn is_foot(self) -> bool {
        matches!(
            self,
            UnitKind::Rifleman
                | UnitKind::Atgm
                | UnitKind::Javelin
                | UnitKind::SpecialForces
                | UnitKind::EliteInfantry
                | UnitKind::AaInfantry
                | UnitKind::HmgGunner
                | UnitKind::Headquarters
        )
    }

    /// 是否为空中单位（直升机/无人机：可越过岩石、普通陆战单位打不到）
    pub fn is_air(self) -> bool {
        matches!(
            self,
            UnitKind::AttackHeli | UnitKind::TransportHeli | UnitKind::HeavyTransportHeli | UnitKind::Drone
        )
    }

    /// 是否为车辆单位（地面非步兵：坦克/步战/卡车/火炮/防空车等）
    pub fn is_vehicle(self) -> bool {
        !self.is_foot() && !self.is_air()
    }

    /// 是否为悍马系列（统一血量 2/护甲 1/行动 2/行动力 4；
    /// 被机炮命中时 40% 直接击毁，被坦克炮命中时按殉爆 80% 造成 2 点伤害；适用对步兵的压制规则）。
    pub fn is_humvee(self) -> bool {
        matches!(
            self,
            UnitKind::HumveeHmg
                | UnitKind::HumveeTow
                | UnitKind::HumveeJavelin
                | UnitKind::AaLauncher
        )
    }

    /// 是否装备 TOW 反坦克导弹副武器（步兵战车 / 装甲骑兵战车；按 M 切换）。
    /// TOW 模式只能攻击地面车辆，不能打步兵与空中单位。
    pub fn has_tow(self) -> bool {
        matches!(self, UnitKind::Ifv | UnitKind::CavalryIfv)
    }

    /// 承受直射压制的目标类别：步兵与悍马系列都适用。
    pub fn is_direct_suppressible(self) -> bool {
        self.is_foot() || self.is_humvee()
    }

    /// 是否为防空单位（能攻击直升机）
    pub fn is_aa(self) -> bool {
        matches!(self, UnitKind::AaInfantry | UnitKind::AaMgv | UnitKind::AaLauncher)
    }

    /// 能否攻击空中单位（直升机）。
    /// 重机枪（重机枪手/悍马-重机枪）可对空；但楼内（未登屋顶）的重机枪受位置限制，
    /// 该位置限制在 `GameState` 的攻击校验中处理。
    pub fn can_hit_air(self) -> bool {
        matches!(
            self,
            UnitKind::AttackHeli
                | UnitKind::AaInfantry
                | UnitKind::AaMgv
                | UnitKind::AaLauncher
                | UnitKind::HmgGunner
                | UnitKind::HumveeHmg
        )
    }

    /// 能否攻击地面单位（防空导弹手/发射车只能打直升机，运输直升机不能攻击）
    pub fn can_hit_ground(self) -> bool {
        matches!(
            self,
            UnitKind::AttackHeli
                | UnitKind::Drone
                | UnitKind::AaMgv
                | UnitKind::Rifleman
                | UnitKind::Scout
                | UnitKind::Atgm
                | UnitKind::Javelin
                | UnitKind::SpecialForces
                | UnitKind::EliteInfantry
                | UnitKind::HmgGunner
                | UnitKind::Tank
                | UnitKind::HeavyTank
                | UnitKind::Ifv
                | UnitKind::CavalryIfv
                | UnitKind::HumveeHmg
                | UnitKind::HumveeTow
                | UnitKind::HumveeJavelin
                | UnitKind::Howitzer
                | UnitKind::Mortar
        )
    }

    /// 能否对目标发动攻击（含空中/地面目标类型限制，不含位置等战场状态）。
    /// Javelin/TOW 反坦克导弹只能攻击车辆单位（不能打步兵）。
    pub fn can_target(self, target: UnitKind) -> bool {
        if target.is_air() {
            self.can_hit_air()
        } else if matches!(
            self,
            UnitKind::Atgm | UnitKind::Javelin | UnitKind::HumveeTow | UnitKind::HumveeJavelin
        ) {
            target.is_vehicle()
        } else {
            self.can_hit_ground()
        }
    }
}

/// 战场上的一个单位。
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct Unit {
    pub kind: UnitKind,
    pub team: Team,
    pub pos: Hex,
    pub hp: i32,
    pub actions_left: i32,
    /// 剩余弹药（主武器；每攻击 1 次消耗 1 发；耗尽则无法攻击）
    pub ammo: i32,
    pub label: char, // 玩家: A/B/C..., AI: 1/2/3...
    /// 搭载的步兵（仅步兵战车/卡车使用；搭载时其 pos 随载具）
    pub passengers: Vec<Unit>,
    /// 架设状态：榴弹炮与重机枪手需先「架设」（消耗 1 次行动）才能开火；
    /// 架设状态跨回合保留，移动/装车（离开当前位置）后需重新架设。
    /// （历史字段名为 `aimed`，旧存档通过别名兼容读入。）
    #[serde(default, alias = "aimed")]
    pub deployed: bool,
    /// 主动防御（主战坦克/装甲骑兵战车）：剩余免疫次数（共 8 次）；
    /// 单次攻击命中消耗 1 次抵消；同时攻击命中 1 发抵消 1 发、命中 ≥2 发随机抵消其中 1 发。
    /// 取消“回合首次命中”限制，同回合多次遇袭只要还有次数就继续触发。
    pub ad_uses: i32,
    /// 压制状态：是否被压制（用于旧版兼容显示）。
    pub suppressed: bool,
    /// 压制层数：可叠加，新回合行动次数 -压制层数（最低 0）；持续 1 回合后清空。
    #[serde(default)]
    pub suppression_stacks: i32,
    /// 诱饵弹（武装/运输直升机）：前 2 次被攻击时命中率 ×20%，每次被攻击消耗 1 发
    pub flares: i32,
    /// 副武器弹药：
    /// - M-SHORAD：Stinger 防空导弹 2 发
    /// - 精锐/特战：M3E1-HE 火箭筒弹 4 发
    /// - 步枪手：M3E1-XM1176 弹 4 发
    /// - 榴弹炮：M864 双用途子母弹 4 发
    /// - 步兵战车/装甲骑兵战车：TOW 反坦克导弹 2 / 8 发
    pub missile_ammo: i32,
    /// 副武器模式 1（M 键）：M-SHORAD 导弹 / 精锐&特战 M3E1 / 步枪手 XM1176 / 榴弹炮 M864
    pub missile_mode: bool,
    /// 第三武器弹药（特战 Stinger 防空导弹 1 发）
    pub aa_ammo: i32,
    /// 第三武器模式（A 键）：特战 Stinger 防空导弹
    pub aa_mode: bool,
    /// 步兵登屋顶状态：建筑内步兵可在【屋中/屋顶】间切换。
    /// 屋顶：放弃楼房闪避（命中率不 ×0.6）与隐蔽加成，视野无视森林/楼房遮挡，
    /// 且攻击不受任何 LOS 因素遮挡。
    pub rooftop: bool,
}

impl Unit {
    pub fn new(kind: UnitKind, team: Team, pos: Hex) -> Self {
        Unit {
            kind,
            team,
            pos,
            hp: kind.max_hp(),
            actions_left: kind.action_count(),
            ammo: kind.max_ammo(),
            label: '?',
            passengers: Vec::new(),
            deployed: false,
            ad_uses: if matches!(kind, UnitKind::HeavyTank | UnitKind::CavalryIfv) {
                8
            } else {
                0
            },
            suppressed: false,
            suppression_stacks: 0,
            flares: if matches!(kind, UnitKind::AttackHeli | UnitKind::TransportHeli) {
                2
            } else if kind == UnitKind::HeavyTransportHeli {
                3 // 重型运输直升机 3 发诱饵弹
            } else {
                0
            },
            missile_ammo: match kind {
                UnitKind::Ifv => 2,        // TOW 反坦克导弹
                UnitKind::CavalryIfv => 8, // TOW 反坦克导弹
                UnitKind::AaMgv => 2, // Stinger
                UnitKind::EliteInfantry | UnitKind::SpecialForces => 4, // M3E1
                UnitKind::Rifleman => 4,  // M3E1-XM1176
                UnitKind::Howitzer => 4,  // M864 子母弹
                UnitKind::Tank | UnitKind::HeavyTank => 42, // 车载重机枪弹药量与主炮弹药相同
                _ => 0,
            },
            missile_mode: false,
            aa_ammo: if kind == UnitKind::SpecialForces { 1 } else { 0 }, // Stinger
            aa_mode: false,
            rooftop: false,
        }
    }

    pub fn is_alive(&self) -> bool {
        self.hp > 0
    }

    /// 带标签的显示名，如 "A(坦克)"
    pub fn name_with_label(&self) -> String {
        format!("{}({})", self.label, self.kind.name())
    }

    /// 该单位作为货物占用的重量（步兵=HP、补给 3、榴弹炮 5、悍马 6、侦察战车 7、迫击炮 8）。
    pub fn occupies_weight(&self) -> i32 {
        self.kind.cargo_weight()
    }

    /// 已占用载重（全部搭载货物的重量之和）
    pub fn used_weight(&self) -> i32 {
        self.passengers.iter().map(|p| p.occupies_weight()).sum()
    }

    /// 是否还能搭载（按剩余载重计算）
    pub fn has_space(&self) -> bool {
        self.kind.capacity() > 0 && self.used_weight() < self.kind.capacity()
    }

    /// 是否能搭载目标单位：兵种类别允许，且该单位单独一件的重量不超过载重上限。
    /// 实际装载时的总载重由 `board` / `heli_board` 再行校验。
    pub fn can_carry(&self, other: UnitKind) -> bool {
        self.kind.can_load_cargo(other) && other.cargo_weight() <= self.kind.capacity()
    }

    /// 当前激活的武器是否防空导弹（Stinger）。
    pub fn is_stinger_mode(&self) -> bool {
        self.aa_mode || (self.missile_mode && self.kind == UnitKind::AaMgv)
    }

    /// 是否为“装甲车辆直射武器”（不含榴弹炮/迫击炮/防空导弹发射车/反坦克导弹/Stinger）。
    /// 包括坦克炮、机关炮和车载重机枪。
    pub fn is_direct_fire_vehicle_gun(&self) -> bool {
        if self.kind.is_air() || self.kind.is_foot() {
            return false;
        }
        if matches!(
            self.kind,
            UnitKind::Howitzer | UnitKind::Mortar | UnitKind::Truck | UnitKind::AaLauncher
        ) {
            return false;
        }
        if self.is_stinger_mode() {
            return false; // M-SHORAD 的 Stinger 导弹模式不算机关炮
        }
        if self.missile_mode && self.kind.has_tow() {
            return false; // 步兵战车/装甲骑兵战车的 TOW 反坦克导弹例外
        }
        true
    }

    /// 当前是否为重机枪：装甲车辆直射武器且攻击力为 1；
    /// 另外重机枪手与悍马-重机枪固定为重机枪（攻 2 但按重机枪规则判定）。
    pub fn is_heavy_mg_mode(&self) -> bool {
        if matches!(self.kind, UnitKind::HmgGunner | UnitKind::HumveeHmg) {
            return true;
        }
        self.is_direct_fire_vehicle_gun() && self.eff_attack() == 1
    }

    /// 当前是否为机关炮：装甲车辆直射武器且攻击力为 2。
    /// 悍马-重机枪虽攻击力 2，但按重机枪而非机关炮判定。
    pub fn is_autocannon_mode(&self) -> bool {
        if matches!(self.kind, UnitKind::HmgGunner | UnitKind::HumveeHmg) {
            return false;
        }
        self.is_direct_fire_vehicle_gun() && self.eff_attack() == 2
    }

    /// 当前是否为坦克炮：仅坦克/主战坦克的主炮（攻 4）。
    /// 不能再按攻击力数值判定——ATGM/防空导弹等其它高攻武器不属于坦克炮。
    pub fn is_tank_gun_mode(&self) -> bool {
        self.is_direct_fire_vehicle_gun()
            && matches!(self.kind, UnitKind::Tank | UnitKind::HeavyTank)
            && !self.missile_mode // 车载重机枪副武器不算坦克炮
    }

    /// 是否为“可直射压制步兵/悍马”的武器：重机枪（含重机枪手/悍马-重机枪）与机关炮。
    pub fn is_suppressing_weapon(&self) -> bool {
        self.is_heavy_mg_mode() || self.is_autocannon_mode()
    }

    /// 直射压制的基准概率（%）：重机枪 90，机关炮 100。
    pub fn suppression_base(&self) -> u32 {
        if self.is_heavy_mg_mode() {
            90
        } else {
            100
        }
    }

    /// 机炮命中悍马系列时的“直接击毁”概率（%）：**仅机炮 40**，其余（含坦克炮）0。
    /// 注：坦克炮不再直接击毁悍马，改为按目标殉爆概率（护甲 1 车辆 **80%**）造成 2 点伤害。
    pub fn humvee_instant_kill_chance(&self, target: UnitKind) -> u32 {
        if !target.is_humvee() {
            return 0;
        }
        if self.is_autocannon_mode() {
            40
        } else {
            0
        }
    }

    /// 当前模式的有效射程。
    pub fn eff_range(&self) -> i32 {
        if self.is_stinger_mode() {
            8 // Stinger 防空导弹
        } else if self.missile_mode {
            match self.kind {
                UnitKind::EliteInfantry | UnitKind::SpecialForces => 3, // M3E1-HE
                UnitKind::Rifleman => 3, // M3E1-XM1176
                UnitKind::Howitzer => 16, // M864 同榴弹炮射程
                UnitKind::Ifv | UnitKind::CavalryIfv => 9, // TOW 反坦克导弹（射程参照 TOW 射手，射程 9）
                UnitKind::Tank | UnitKind::HeavyTank => 4, // 车载重机枪
                _ => self.kind.range(),
            }
        } else {
            self.kind.range()
        }
    }

    /// 当前模式的有效命中率（M3E1 为基准值，装甲/楼房在攻击结算中动态提升）。
    pub fn eff_hit_rate(&self) -> u32 {
        if self.is_stinger_mode() {
            70 // Stinger
        } else if self.missile_mode {
            match self.kind {
                UnitKind::EliteInfantry | UnitKind::SpecialForces => 80, // M3E1 基准
                UnitKind::Rifleman => 100, // M3E1-XM1176
                UnitKind::Howitzer => 100, // M864
                UnitKind::Ifv | UnitKind::CavalryIfv => 90, // TOW 反坦克导弹（命中率参照 TOW 射手）
                UnitKind::Tank | UnitKind::HeavyTank => 60, // 车载重机枪
                _ => self.kind.hit_rate(),
            }
        } else {
            self.kind.hit_rate()
        }
    }

    /// 当前模式的有效攻击力。
    pub fn eff_attack(&self) -> i32 {
        if self.is_stinger_mode() {
            2 // Stinger
        } else if self.missile_mode {
            match self.kind {
                UnitKind::EliteInfantry | UnitKind::SpecialForces => 4, // M3E1（原 3）
                UnitKind::Rifleman => 3, // M3E1-XM1176（火箭筒攻击力 3）
                UnitKind::Howitzer => 4, // M864（原 3）
                UnitKind::Ifv | UnitKind::CavalryIfv => 4, // TOW 反坦克导弹（原 3）
                UnitKind::Tank | UnitKind::HeavyTank => 1, // 车载重机枪
                _ => self.kind.attack(),
            }
        } else {
            self.kind.attack()
        }
    }

    /// 能否攻击目标类型（按当前模式）。
    pub fn can_target_unit(&self, target: UnitKind) -> bool {
        if self.is_stinger_mode() {
            target.is_air() // Stinger 只能打直升机
        } else if self.missile_mode && self.kind.has_tow() {
            target.is_vehicle() && !target.is_air() // TOW 只能打地面车辆
        } else if self.is_heavy_mg_mode() {
            // 重机枪可对空；对地仍按兵种限制（如反坦克导弹不在此分支）
            if target.is_air() {
                true
            } else {
                self.kind.can_hit_ground()
            }
        } else {
            self.kind.can_target(target)
        }
    }

    /// 当前模式使用的弹药。
    pub fn ammo_shown(&self) -> i32 {
        if self.aa_mode {
            self.aa_ammo
        } else if self.missile_mode {
            self.missile_ammo
        } else {
            self.ammo
        }
    }

    /// 是否拥有副武器（可切换）。
    pub fn is_dual_weapon(&self) -> bool {
        matches!(
            self.kind,
            UnitKind::AaMgv | UnitKind::EliteInfantry | UnitKind::SpecialForces | UnitKind::Rifleman | UnitKind::Howitzer | UnitKind::Ifv | UnitKind::CavalryIfv | UnitKind::Tank | UnitKind::HeavyTank
        )
    }

    /// 是否拥有第三武器（特战 Stinger）。
    pub fn has_tertiary(&self) -> bool {
        self.kind == UnitKind::SpecialForces
    }

    /// 当前武器模式的中文名（界面显示）。
    pub fn mode_name(&self) -> &'static str {
        if self.aa_mode {
            "Stinger防空"
        } else if self.missile_mode {
            match self.kind {
                UnitKind::AaMgv => "Stinger导弹",
                UnitKind::EliteInfantry | UnitKind::SpecialForces => "M3E1火箭筒",
                UnitKind::Rifleman => "M3E1-XM1176",
                UnitKind::Howitzer => "M864子母弹",
                UnitKind::Ifv | UnitKind::CavalryIfv => "TOW导弹",
                UnitKind::Tank | UnitKind::HeavyTank => "重机枪",
                _ => "副武器",
            }
        } else {
            match self.kind {
                UnitKind::AaMgv => "机枪",
                _ => "主武器",
            }
        }
    }
}
