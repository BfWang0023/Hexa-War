//! 简易 AI：每单位每回合至多攻击一次（优先射程内最近的、打得动的敌人），
//! 其余行动用于朝最近的敌人机动。这种简单的"先射击后机动"模式有明确的
//! 弱点：玩家可以用较近的单位吸引火力，掩护TOW/Javelin射手逼近并击毁坦克。
//!
//! 新增单位的 AI：
//! - 榴弹炮：在射程内寻找"爆炸范围内敌方期望伤害最大"的点开炮，否则推进。
//! - 步兵战车/卡车：有空位就顺路搭载紧邻的己方步兵；接近敌人时放下步兵；
//!   战车可开火，卡车不能。

use std::collections::HashSet;

use crate::game::{AiStyle, CompanyPlan, GameState, Level, PlatoonOrder, PlatoonPlan, PlatoonRole, PlatoonType, SimulOrder};
use crate::hex::{self, Hex};
use crate::unit::{Team, Unit, UnitKind};

/// 为 team 行动一回合，返回行动日志（供 GUI / 终端显示）。
pub fn take_turn(game: &mut GameState, team: Team) -> Vec<String> {
    let mut log = Vec::new();
    run_ai_turn(game, team, &mut log);
    log
}

/// AI 一回合的实现，行动消息追加到 `log`。
pub fn run_ai_turn(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    // 试验模式：敌方棋子不进行任何行动（玩家仍可正常操作己方棋子）。
    if game.test_mode && team == Team::Ai {
        return;
    }
    // 防空感知：记录本回合当前防空单位数；下回合若更少 → 判定"己方防空被击毁"
    game.aa_count_last
        .insert(team, count_aa(game, team));
    // 补给：补给单位在规划行动前，先为范围内主武器弹药耗尽的友军补给
    // （在规划行动之前执行，避免空弹单位整回合无所作为）。
    let supply_log = game.auto_resupply(team);
    log.extend(supply_log);
    // 先清理迷雾开火警告（阵亡/被发现/过期的标记移除），确保基于最新状态决策
    game.prune_fog_fire_marks();
    // 填充本回合视野缓存（AI 决策里的 is_unit_visible 转为 O(1) 查表）
    game.vis_cache
        .insert(team, (game.turn, game.vision(team).enemy_units));
    // 本队 AI 行动规则配置（参数化智能；默认 = 训练出的最优配置）
    let cfg = game.ai_configs.get(&team).copied().unwrap_or_default();
    // AI 步兵登屋顶：防空导弹手/Javelin/TOW 在建筑内且有可见敌军 → 上屋顶
    //（更好射击角度：视野/攻击无视遮挡）
    ai_rooftop_opt(game, team, log);
    // 连排指挥官框架：连指挥官每回合重算各排目标与指令
    if cfg.style == AiStyle::Company {
        company_update(game, team);
    }
    // 可持续部署：AI 每回合先用累计点数在本方大本营区域追加部署
    if game.sustain {
        game.sustain_deploying = true;
        let before = log.len();
        ai_reinforce_turn(game, team, log);
        game.sustain_deploying = false;
        if log.len() > before {
            log.push(format!("—— {} 回合增援完成 ——", team.cn()));
        }
    }
    // 敌方大本营中心（关键据点中心）：关键据点在地图上始终可见，直接记录（供总攻/空降）
    if game.sustain {
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .find(|(_, kp)| kp.owner == team.opponent() && kp.center)
        {
            game.hq_seen.insert(team, Some(*h));
        }
    }
    // 全面防御判定：己方指挥部周围 8 格内发现可见敌军 → 全力回防指挥部；
    // 8 格内无可见敌军则解除（每回合重新评估，不持久）。
    let defend = game.defense_triggered(team);
    if defend {
        log.push("[AI] 🛡 敌军逼近指挥部（8 格内），转入全面防御！".into());
    }
    // 全力进攻判定：已歼灭点数 ≥ 敌军初始部署点数 P - 10 → 放弃防守/侦察，
    // 全部单位搜索并摧毁敌方指挥部。防御（己方被威胁）优先于总攻。
    let assault = !defend && game.sustain_assault_ready(team);
    if assault {
        log.push(format!(
            "[AI] ⚔ 敌军主力已被歼灭（{} 点），发起总攻！",
            game.killed_value.get(&team.opponent()).copied().unwrap_or(0)
        ));
    }
    // 村庄防守关：本回合可调去"阻击敌袭方向"的兵力名额（保留核心防守力量的前提下
    // 抽调一部分机动单位；名额 = 可调动单位的一半，最多 3 个）
    let mut intercept_budget = 0;
    if game.level == Level::VillageDefense && team == Team::Ai {
        let reactable = game
            .units_of(team)
            .iter()
            .filter(|u| is_reactable(game, u))
            .count() as i32;
        if reactable > 0 {
            // 留守兵力分母由配置控制：0=全员出击，N=可调动兵力 ÷ (N+1)
            intercept_budget = if cfg.village_hold == 0 {
                reactable
            } else {
                (reactable / (cfg.village_hold + 1)).clamp(1, 3)
            };
        }
    }
    // 主动防御目标集火/规避计划：发现可见且仍带主动防御的主战坦克/装甲骑兵战车时，
    // 估算全队袭击次数；若能组织 ≥阈值 次同时攻击则优先齐射（一次齐射只消耗 1 次主动防御），
    // 否则 <2 次时撤退/隐蔽规避。
    let heavy_plan: HeavyPlan = {
        let mut plan = None;
        for e in game.enemies_of(team) {
            if matches!(e.kind, UnitKind::HeavyTank | UnitKind::CavalryIfv)
                && e.ad_uses > 0
                && game.is_unit_visible(team, e.pos)
            {
                let hits = count_potential_attackers(game, team, e.pos);
                plan = Some((e.pos, hits));
                break;
            }
        }
        plan
    };
    // AI 也会使用同时攻击：若已有足够单位在射程内，先对主动防御目标打一波齐射。
    // 返回已参与齐射的单位标签，主循环中这些单位不再单独攻击。
    let volleyed = try_ai_simultaneous_volley(
        game,
        team,
        cfg.focus_attacks,
        log,
    );
    if game.game_over() {
        return;
    }
/// 特殊武器自动切换：M3E1 火箭筒（打装甲车辆）、Stinger 防空导弹（打直升机）、
/// M3E1-XM1176（楼内步兵强制击杀）、M-SHORAD 防空导弹、榴弹炮 M864 子母弹（打主战）。
/// 返回是否发生切换（切换后调用方需重新读取单位状态）。
fn auto_switch_weapons(game: &mut GameState, team: Team, pos: Hex) -> Result<bool, String> {
    let u = game.unit_at(pos).ok_or("单位不存在")?.clone();
    if !u.is_dual_weapon() && !u.has_tertiary() {
        return Ok(false);
    }
    let es = game.enemies_of(team);
    let vis = |h: Hex| game.is_unit_visible(team, h);
    let heli_in = |r: i32| {
        es.iter()
            .any(|e| e.kind.is_air() && vis(e.pos) && Hex::distance(u.pos, e.pos) <= r)
    };
    let veh_in = |r: i32| {
        es.iter().any(|e| {
            !e.kind.is_air()
                && e.kind.is_vehicle()
                && e.kind.armor() >= 2
                && vis(e.pos)
                && Hex::distance(u.pos, e.pos) <= r
        })
    };
    let inf_in_building = |r: i32| {
        es.iter().any(|e| {
            e.kind.is_foot()
                && vis(e.pos)
                && Hex::distance(u.pos, e.pos) <= r
                && game.map.buildings.contains(&e.pos)
        })
    };
    let heavy_in = |r: i32| {
        es.iter()
            .any(|e| vis(e.pos) && Hex::distance(u.pos, e.pos) <= r && e.kind.armor() >= 3)
    };
    // 软目标：护甲 < 2 的非空中单位（机枪可有效打击并压制步兵）。
    // 悍马系列除外——坦克炮对其有 80% 殉爆（2 点伤害），保留主炮更优。
    let soft_in = |r: i32| {
        es.iter().any(|e| {
            !e.kind.is_air()
                && e.kind.armor() < 2
                && !e.kind.is_humvee()
                && vis(e.pos)
                && Hex::distance(u.pos, e.pos) <= r
        })
    };
    let (want_aa, want_missile): (Option<bool>, Option<bool>) = match u.kind {
        UnitKind::SpecialForces => {
            // 优先级：Stinger(直升机) > M3E1(装甲) > 步枪
            if heli_in(8) && u.aa_ammo > 0 {
                (Some(true), None)
            } else if veh_in(3) && u.missile_ammo > 0 {
                (Some(false), Some(true))
            } else {
                (Some(false), Some(false))
            }
        }
        UnitKind::EliteInfantry => {
            if veh_in(3) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Rifleman => {
            // XM1176：楼内步兵强制击杀（射程 3 内）
            if inf_in_building(3) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::AaMgv => {
            if heli_in(8) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Howitzer => {
            // M864 子母弹：射程内有可见装甲≥3（主战坦克）→ 切子母弹，否则省弹用常规弹
            if heavy_in(16) && u.missile_ammo > 0 {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        UnitKind::Tank | UnitKind::HeavyTank => {
            // 车载重机枪（射程 4）压制软目标：机枪射程内有软目标、且主炮射程内
            // 没有装甲目标（护甲 ≥ 2）时切机枪；否则保留坦克炮优先反装甲。
            let mg_range = {
                let mut mg = u.clone();
                mg.missile_mode = true;
                mg.eff_range()
            };
            if u.missile_ammo > 0 && soft_in(mg_range) && !veh_in(u.kind.range()) {
                (None, Some(true))
            } else {
                (None, Some(false))
            }
        }
        _ => (None, None),
    };
    let u = game.unit_at(pos).ok_or("单位不存在")?.clone();
    let mut switched = false;
    if let Some(w) = want_aa {
        if u.aa_mode != w {
            game.toggle_aa_mode(pos)?;
            switched = true;
        }
    }
    if let Some(w) = want_missile {
        if u.missile_mode != w {
            game.toggle_missile_mode(pos)?;
            switched = true;
        }
    }
    Ok(switched)
}

    // 侦察单位：优先由侦察能力强的单位担任（空中单位优先、其次高视野非防空单位），
    // 最多 2 个前出侦察。所有关卡（含村庄防守关）都前出侦察，为全队（含火炮）开眼。
    // 用 label 标识（空中与地面单位可同格，Hex 位置会误判）。
    let mut recon_units: HashSet<char> = HashSet::new();
    {
        let mut cand: Vec<(i32, char)> = game
            .units_of(team)
            .iter()
            .filter(|u| u.kind.is_air() || (u.kind.vision() >= 6 && !u.kind.is_aa()))
            .map(|u| (u.kind.vision(), u.label))
            .collect();
        cand.sort_by(|a, b| b.0.cmp(&a.0));
        for (_, lb) in cand.iter().take(cfg.recon_units.max(1) as usize) {
            recon_units.insert(*lb);
        }
    }
    // 求援点列表：本回合"呼叫援军"的位置（远处单位响应）
    let mut reinforcements: Vec<Hex> = Vec::new();
    // 行动顺序：单位价值从高到低（榴弹炮/坦克先动）
    let mut order: Vec<(i32, Hex)> = game
        .units_of(team)
        .into_iter()
        .map(|u| (u.kind.value(), u.pos))
        .collect();
    order.sort_by(|a, b| b.0.cmp(&a.0));

    for (_, mut pos) in order {
        let mut attacked = volleyed.contains(
            &game.unit_at(pos).map(|u| u.label).unwrap_or('?'),
        );
        loop {
            let u = match game.unit_at(pos) {
                Some(u) => u.clone(),
                None => break,
            };
            if u.actions_left <= 0 {
                break;
            }
            // 游击猎手：攻击后利用剩余行动"打了就跑"（撤入隐蔽/远离威胁）
            if attacked && cfg.style == AiStyle::Harasser {
                let foes = game.enemies_of(team);
                let threat = foes
                    .iter()
                    .filter(|e| game.is_unit_visible(team, e.pos))
                    .min_by_key(|e| Hex::distance(u.pos, e.pos));
                if let Some(t) = threat {
                    match ai_retreat(game, &u, t.pos, log) {
                        Some(np) => {
                            log.push(format!(
                                "[AI] {} 打了就跑 → {}",
                                u.name_with_label(),
                                hex::hex_label(np)
                            ));
                            pos = np;
                            continue;
                        }
                        None => break,
                    }
                }
                break;
            }
            // 特殊武器自动切换：M3E1 火箭筒（打装甲）、Stinger（打直升机）、
            // XM1176（楼内步兵强制击杀）、M-SHORAD 导弹、榴弹炮 M864 子母弹
            match auto_switch_weapons(game, team, pos) {
                Ok(true) => continue, // 切换后重新读取最新状态
                Ok(false) => {}
                Err(e) => log.push(format!("[AI] 模式切换失败: {}", e)),
            }

            match u.kind {
                UnitKind::Howitzer | UnitKind::Mortar => {
                    // 0. 榴弹炮需先架设；自行迫击炮无需架设直接开火
                    if u.kind == UnitKind::Howitzer && !u.deployed {
                        match game.deploy(u.pos) {
                            Ok(()) => log.push(format!("[AI] {} 完成架设", u.name_with_label())),
                            Err(e) => log.push(format!("[AI] 异常: {}", e)),
                        }
                        break; // 行动耗尽
                    }
                    // 1. 找最佳炮击点（弹药耗尽则不再炮击）
                    if !attacked && u.actions_left >= u.kind.attack_cost() && u.ammo > 0 {
                        if let Some(center) = choose_artillery_target(game, &u) {
                            match game.attack(u.pos, center) {
                                Ok(outcome) => {
                                    attacked = true;
                                    log.push(format!("[AI] {}", outcome.message));
                                    if outcome.killed && game.game_over() {
                                        return;
                                    }
                                    continue;
                                }
                                Err(e) => {
                                    log.push(format!("[AI] 异常: {}", e));
                                    break;
                                }
                            }
                        }
                    }
                    // 2. 行动力 0，不能自主移动
                    break;
                }
                UnitKind::Ifv | UnitKind::Truck | UnitKind::TransportHeli => {
                    // —— 连排指挥官：榴弹炮排卡车守炮（跟随榴弹炮、威胁时转移） ——
                    if cfg.style == AiStyle::Company && u.kind == UnitKind::Truck {
                        let carrying_how =
                            u.passengers.iter().any(|p| p.kind == UnitKind::Howitzer);
                        let how_pos: Option<Hex> = {
                            game.units_of(team)
                                .into_iter()
                                .find(|x| {
                                    x.kind == UnitKind::Howitzer
                                        && Hex::distance(u.pos, x.pos) <= 6
                                })
                                .map(|x| x.pos)
                        };
                        let threat_dist = game
                            .enemies_of(team)
                            .iter()
                            .filter(|e| game.is_unit_visible(team, e.pos))
                            .map(|e| Hex::distance(u.pos, e.pos))
                            .min()
                            .unwrap_or(i32::MAX);
                        if carrying_how {
                            // 转运中：到安全距离卸下
                            if threat_dist > 7 {
                                if let Some(p) = u
                                    .passengers
                                    .iter()
                                    .find(|p| p.kind == UnitKind::Howitzer)
                                    .cloned()
                                {
                                    if let Some(dest) = choose_unload_hex(game, &u) {
                                        if let Ok(()) = game.disembark(u.pos, p.label, dest) {
                                            log.push(format!(
                                                "[AI] {} 卸下 {} 到 {}（后方炮位）",
                                                u.name_with_label(),
                                                p.name_with_label(),
                                                hex::hex_label(dest)
                                            ));
                                            break;
                                        }
                                    }
                                }
                            } else {
                                match ai_retreat(game, &u, game.enemies_of(team).iter().min_by_key(|e| Hex::distance(u.pos, e.pos)).map(|e| e.pos).unwrap_or(u.pos), log) {
                                    Some(np) => {
                                        pos = np;
                                        continue;
                                    }
                                    None => break,
                                }
                            }
                        } else {
                            // 守炮：榴弹炮被威胁 → 装载转移；否则待在榴弹炮旁
                            let danger = threat_dist <= 6
                                && how_pos.map(|h| Hex::distance(u.pos, h) <= 2).unwrap_or(false);
                            if danger {
                                if let Some(hpos) = how_pos {
                                    if u.pos == hpos || u.pos.neighbors().contains(&hpos) {
                                        if let Ok(()) = game.board(u.pos, hpos) {
                                            log.push(format!(
                                                "[AI] {} 装载榴弹炮（威胁转移）",
                                                u.name_with_label()
                                            ));
                                            continue;
                                        }
                                    }
                                }
                            }
                            if let Some(goal) = how_pos {
                                // 到榴弹炮旁 1 格守炮
                                if Hex::distance(u.pos, goal) <= 2 {
                                    break; // 已就位守炮
                                }
                                if Hex::distance(u.pos, goal) <= 2 {
                                    break; // 已就位守炮
                                }
                                let path = game.map.plan_move(
                                    &game.units,
                                    &game.air_units,
                                    u.pos,
                                    goal,
                                    u.kind.movement(),
                                    Some(u.clone()),
                                    true,
                                );
                                if path.len() > 1 {
                                    match game.move_unit(u.pos, &path, u.kind.is_air()) {
                                        Ok(np) => {
                                            log.push(format!(
                                                "[AI] {} 守炮 → {}",
                                                u.name_with_label(),
                                                hex::hex_label(np)
                                            ));
                                            pos = np;
                                            continue;
                                        }
                                        Err(_) => break,
                                    }
                                }
                                break;
                            }
                            break;
                        }
                    }
                    // 0. 卡车：装载/转运榴弹炮（把炮兵运到后方安全位置后卸下）
                    if u.kind == UnitKind::Truck {
                        let carrying_how = u.passengers.iter().any(|p| p.kind == UnitKind::Howitzer);
                        if !carrying_how && u.has_space() {
                            // 装载身边己方榴弹炮（同格或邻格）
                            let how_h = u
                                .pos
                                .neighbors()
                                .iter()
                                .copied()
                                .chain(std::iter::once(u.pos))
                                .find(|h| {
                                    game.units
                                        .get(h)
                                        .map(|x| x.team == u.team && x.kind == UnitKind::Howitzer)
                                        .unwrap_or(false)
                                });
                            if let Some(hh) = how_h {
                                if let Ok(()) = game.board(u.pos, hh) {
                                    log.push(format!(
                                        "[AI] {} 装载榴弹炮（转运后方）",
                                        u.name_with_label()
                                    ));
                                    continue;
                                }
                            }
                        }
                        if carrying_how {
                            let threat = game
                                .enemies_of(team)
                                .iter()
                                .min_by_key(|e| Hex::distance(u.pos, e.pos))
                                .map(|e| e.pos);
                            let safe = threat
                                .map(|t| Hex::distance(u.pos, t) > 7)
                                .unwrap_or(true);
                            if safe {
                                // 到安全位置：卸下榴弹炮（让它炮击）
                                if let Some(p) = u
                                    .passengers
                                    .iter()
                                    .find(|p| p.kind == UnitKind::Howitzer)
                                    .cloned()
                                {
                                    if let Some(dest) = choose_unload_hex(game, &u) {
                                        if let Ok(()) = game.disembark(u.pos, p.label, dest) {
                                            log.push(format!(
                                                "[AI] {} 卸下 {} 到 {}（后方炮位）",
                                                u.name_with_label(),
                                                p.name_with_label(),
                                                hex::hex_label(dest)
                                            ));
                                            break; // 卸下后本回合结束（防重复装-卸循环）
                                        }
                                    }
                                }
                            } else if let Some(t) = threat {
                                // 敌人还在附近：继续向后方撤退转运
                                match ai_retreat(game, &u, t, log) {
                                    Some(np) => {
                                        pos = np;
                                        continue;
                                    }
                                    None => {}
                                }
                            }
                        }
                    }
                    // 1. 顺路搭载己方步兵（离敌人较远时）：
                    //    直升机从正下方载入，地面载具搭载紧邻步兵
                    if u.has_space() && nearest_enemy_dist(game, &u) > 5 {
                        if u.kind.is_air() {
                            if let Some(inf) = game.units.get(&u.pos).cloned() {
                                if inf.team == u.team
                                    && inf.kind.is_infantry()
                                    && inf.actions_left > 0
                                {
                                    match game.heli_board(u.pos) {
                                        Ok(()) => {
                                            log.push(format!(
                                                "[AI] {} 载入下方 {}",
                                                u.name_with_label(),
                                                inf.name_with_label()
                                            ));
                                            continue;
                                        }
                                        Err(_) => {}
                                    }
                                }
                            }
                        } else if let Some(inf) = adjacent_own_infantry(game, &u) {
                            match game.board(u.pos, inf.pos) {
                                Ok(()) => {
                                    log.push(format!(
                                        "[AI] {} 搭载 {}",
                                        u.name_with_label(),
                                        inf.name_with_label()
                                    ));
                                    continue;
                                }
                                Err(_) => {}
                            }
                        }
                    }
                    // 2. 攻击（步兵战车；卡车不能攻击；弹药耗尽则不攻击）
                    if !attacked
                        && u.kind.can_attack()
                        && u.actions_left >= u.kind.attack_cost()
                        && u.ammo > 0
                    {
                        if let Some(target) = choose_target(game, &u, heavy_plan) {
                            match game.attack(u.pos, target) {
                                Ok(outcome) => {
                                    attacked = true;
                                    log.push(format!("[AI] {}", outcome.message));
                                    if outcome.killed && game.game_over() {
                                        return;
                                    }
                                    continue;
                                }
                                Err(e) => {
                                    log.push(format!("[AI] {}", e));
                                    attacked = true;
                                }
                            }
                        }
                    }
                    // 3. 接近敌人时放下步兵（直升机放到正下方）
                    if !u.passengers.is_empty() && nearest_enemy_dist(game, &u) <= 5 {
                        if u.kind.is_air() {
                            match game.heli_unload(u.pos) {
                                Ok(()) => {
                                    log.push(format!(
                                        "[AI] {} 放下步兵到正下方 {}",
                                        u.name_with_label(),
                                        hex::hex_label(u.pos)
                                    ));
                                    continue;
                                }
                                Err(_) => {}
                            }
                        } else if let Some(p) = u.passengers.first().cloned() {
                            let dest = if cfg.style == AiStyle::Company {
                                company_unload_hex(game, &u) // 优先森林/建筑
                            } else {
                                choose_unload_hex(game, &u)
                            };
                            if let Some(dest) = dest {
                                match game.disembark(u.pos, p.label, dest) {
                                    Ok(()) => {
                                        log.push(format!(
                                            "[AI] {} 放下 {} 到 {}",
                                            u.name_with_label(),
                                            p.name_with_label(),
                                            hex::hex_label(dest)
                                        ));
                                        continue;
                                    }
                                    Err(_) => {}
                                }
                            }
                        }
                    }
                    // 4. 机动（三策略：被威胁且打不到 → 撤退；有求援点 → 增援；否则正常机动）
                    let vis_c: Vec<Hex> = game
                        .enemies_of(team)
                        .iter()
                        .filter(|e| game.is_unit_visible(team, e.pos))
                        .map(|e| e.pos)
                        .collect();
                    if !vis_c.is_empty() {
                        let danger_c = vis_c.iter().any(|hp| {
                            game.unit_at(*hp)
                                .map(|e| {
                                    Hex::distance(u.pos, *hp) <= e.kind.range()
                                        && e.kind.can_damage(u.kind)
                                })
                                .unwrap_or(false)
                        });
                        let engage_c = vis_c.iter().any(|hp| {
                            game.unit_at(*hp)
                                .map(|e| {
                                    Hex::distance(u.pos, *hp) <= u.eff_range()
                                        && u.can_target_unit(e.kind)
                                        && u.eff_attack() >= e.kind.armor()
                                })
                                .unwrap_or(false)
                        });
                        let threat_n = vis_c.len() as i32;
                        if danger_c && !engage_c && threat_n >= cfg.retreat_threats {
                            if assault || defend {
                                // 总攻/防御：不撤退，按模式推进
                                match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                                    Some(new_pos) => pos = new_pos,
                                    None => break,
                                }
                            } else {
                                let threat = vis_c
                                    .iter()
                                    .min_by_key(|hp| Hex::distance(u.pos, **hp))
                                    .copied()
                                    .unwrap_or(u.pos);
                                match ai_retreat(game, &u, threat, log) {
                                    Some(_) | None => break,
                                }
                            }
                        } else if !engage_c {
                            if assault || defend {
                                // 总攻/防御：打不到也继续推进
                                match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                                    Some(new_pos) => pos = new_pos,
                                    None => break,
                                }
                            } else {
                                // 呼叫援军：看得见但打不到 → 标记求援点，本单位保守（不危险则原地）
                                for hp in &vis_c {
                                    if !reinforcements.contains(hp) {
                                        reinforcements.push(*hp);
                                    }
                                }
                                log.push(format!(
                                    "[AI] {} 呼叫援军 @{}",
                                    u.name_with_label(),
                                    hex::hex_label(vis_c[0])
                                ));
                                break;
                            }
                        } else {
                            match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                                Some(new_pos) => pos = new_pos,
                                None => break,
                            }
                        }
                    } else if let Some(np) = ai_reinforce(game, &u, &reinforcements, log) {
                        pos = np;
                    } else {
                        match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                            Some(new_pos) => pos = new_pos,
                            None => break,
                        }
                    }
                }
                _ => {
                    // —— 需要架设的重机枪手：发现射程内可打目标时先架设（架设后再开火） ——
                    if u.kind.needs_deploy()
                        && u.kind != UnitKind::Howitzer
                        && !u.deployed
                        && u.actions_left >= 1
                        && u.ammo > 0
                        && choose_target(game, &u, heavy_plan).is_some()
                    {
                        match game.deploy(u.pos) {
                            Ok(()) => log.push(format!("[AI] {} 完成架设", u.name_with_label())),
                            Err(e) => log.push(format!("[AI] 异常: {}", e)),
                        }
                        continue;
                    }
                    // —— 连排指挥官框架：排指挥官按阵型行动 ——
                    if cfg.style == AiStyle::Company {
                        if company_unit_turn(game, team, pos, &mut attacked, heavy_plan, log)
                            .is_some()
                        {
                            break; // 排指挥官已完成本单位攻击+机动
                        }
                        // 未分组单位（连直属）→ 走通用逻辑
                    }
                    // —— 三策略决策：侦察前出 / 就地攻击 / 撤退 / 呼叫援军 ——
                    // 侦察单位：前出开眼（敌人贴脸 ≤2 时自卫反击）
                    if recon_units.contains(&u.label) && !assault && !defend {
                        if !attacked && u.actions_left >= u.kind.attack_cost() && u.ammo > 0 {
                            let close = game.enemies_of(team).iter().any(|e| {
                                game.is_unit_visible(team, e.pos) && Hex::distance(u.pos, e.pos) <= 2
                            });
                            if close {
                                if let Some(target) = choose_target(game, &u, heavy_plan) {
                                    match game.attack(u.pos, target) {
                                        Ok(outcome) => {
                                            attacked = true;
                                            log.push(format!("[AI] {}", outcome.message));
                                            if outcome.killed && game.game_over() {
                                                return;
                                            }
                                        }
                                        Err(e) => {
                                            log.push(format!("[AI] {}", e));
                                            attacked = true;
                                        }
                                    }
                                }
                            }
                        }
                        match ai_recon_move(game, &u, team, log) {
                            Some(np) => pos = np,
                            None => break,
                        }
                        continue; // 侦察单位前出后结束本回合行动
                    }
                    // 战斗评估
                    let vis: Vec<Hex> = game
                        .enemies_of(team)
                        .iter()
                        .filter(|e| game.is_unit_visible(team, e.pos))
                        .map(|e| e.pos)
                        .collect();
                    if !vis.is_empty() {
                        let danger = vis.iter().any(|hp| {
                            if let Some(e) = game.unit_at(*hp) {
                                Hex::distance(u.pos, *hp) <= e.kind.range()
                                    && e.kind.can_damage(u.kind)
                            } else {
                                false
                            }
                        });
                        let can_engage = vis.iter().any(|hp| {
                            if let Some(e) = game.unit_at(*hp) {
                                Hex::distance(u.pos, *hp) <= u.eff_range()
                                    && u.can_target_unit(e.kind)
                                    && u.eff_attack() >= e.kind.armor()
                            } else {
                                false
                            }
                        });
                        let allies_near = game
                            .units_of(team)
                            .iter()
                            .filter(|a| Hex::distance(a.pos, u.pos) <= 8)
                            .count();
                        let outnumbered = vis.len() as i32 > allies_near as i32;
                        let retreat_now = danger
                            && !can_engage
                            && vis.len() as i32 >= cfg.retreat_threats;
                        if can_engage && !(danger && outnumbered) {
                            // (1) 就地攻击：射程内可见目标且局部不吃亏 → 攻击，然后按局势机动
                            if !attacked && u.actions_left >= u.kind.attack_cost() && u.ammo > 0 {
                                if let Some(target) = choose_target(game, &u, heavy_plan) {
                                    match game.attack(u.pos, target) {
                                        Ok(outcome) => {
                                            attacked = true;
                                            log.push(format!("[AI] {}", outcome.message));
                                            if outcome.killed && game.game_over() {
                                                return;
                                            }
                                        }
                                        Err(e) => {
                                            log.push(format!("[AI] {}", e));
                                            attacked = true;
                                        }
                                    }
                                }
                            }
                            match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                                Some(np) => pos = np,
                                None => break,
                            }
                        } else if retreat_now {
                            if assault || defend {
                                // 总攻/防御：不撤退，按模式推进
                                match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                                    Some(np) => pos = np,
                                    None => break,
                                }
                            } else {
                                // (2) 撤退：被打但打不到（威胁数达标）→ 远离威胁/撤入隐蔽
                                let threat = vis
                                    .iter()
                                    .min_by_key(|hp| Hex::distance(u.pos, **hp))
                                    .copied()
                                    .unwrap_or(u.pos);
                                log.push(format!(
                                    "[AI] {} 判断不敌，撤退（{}）",
                                    u.name_with_label(),
                                    hex::hex_label(threat)
                                ));
                                match ai_retreat(game, &u, threat, log) {
                                    Some(_) | None => break, // 撤退后本回合脱离接触
                                }
                            }
                        } else {
                            if assault || defend {
                                // 总攻/防御：打不到也继续推进
                                match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                                    Some(np) => pos = np,
                                    None => break,
                                }
                            } else {
                                // (3) 呼叫援军：敌人可见但打不到/打不动 → 标记求援点，本单位保守
                                for hp in &vis {
                                    if !reinforcements.contains(hp) {
                                        reinforcements.push(*hp);
                                    }
                                }
                                log.push(format!(
                                    "[AI] {} 呼叫援军 @{}",
                                    u.name_with_label(),
                                    hex::hex_label(
                                        vis.iter().min_by_key(|hp| Hex::distance(u.pos, **hp)).copied().unwrap()
                                    )
                                ));
                                if danger && vis.len() as i32 >= cfg.retreat_threats {
                                    let threat = vis
                                        .iter()
                                        .min_by_key(|hp| Hex::distance(u.pos, **hp))
                                        .copied()
                                        .unwrap_or(u.pos);
                                    match ai_retreat(game, &u, threat, log) {
                                        Some(np) => pos = np,
                                        None => break,
                                    }
                                } else {
                                    // 不危险：原地/就近隐蔽
                                    break;
                                }
                            }
                        }
                    } else if let Some(np) = ai_reinforce(game, &u, &reinforcements, log) {
                        // 响应其他单位呼叫的援军
                        pos = np;
                    } else {
                        // 无可见敌人且无求援：正常机动
                        match ai_move_for(game, Team::Ai, pos, log, &mut intercept_budget, heavy_plan) {
                            Some(np) => pos = np,
                            None => break,
                        }
                    }
                }
            }
        }
    }
}

// ========== 连排指挥官框架：连指挥官（目标/指令分配） ==========

/// 连指挥官：每回合重算各排的目标与指令。
/// - 战斗排：目标 = 排中心附近最近可见敌军；无 → 沿敌方方向推进；
///   排内"被打且打不到"单位多且威胁大 → 整排撤退；己方指挥部被威胁 → 回防；
///   总攻（敌方主力被歼）→ 直扑敌方指挥部。
/// - 榴弹炮排：固定后方炮位（Hold），由排内卡车护卫。
fn company_update(game: &mut GameState, team: Team) {
    let Some(mut plan) = game.company.get(&team).cloned() else {
        return;
    };
    let cfg = game.ai_configs.get(&team).copied().unwrap_or_default();
    let hq = game.hq_pos(team);
    let assault = game.sustain_assault_ready(team);
    let defend = game.defense_triggered(team);
    // 敌方参考点（玩家在西、AI 在东）：用于计算"向敌方推进"的方向
    let enemy_ref = match team {
        Team::Player => hex::axial_from_offset(game.map.cols - 1, game.map.rows / 2),
        Team::Ai => hex::axial_from_offset(0, game.map.rows / 2),
    };
    // —— 桥梁战术（循环外先算）：桥面/桥头 3 格内有可见敌军 → 连队派
    //    最近的战斗排夺桥/守桥/增援（其余排保持原任务） ——
    let bridge_threat: Option<Hex> = game
        .map
        .bridge_hexes()
        .into_iter()
        .find(|b| {
            game.enemies_of(team).iter().any(|e| {
                game.is_unit_visible(team, e.pos) && Hex::distance(e.pos, *b) <= 3
            })
        });
    let bridge_owner: Option<usize> = match bridge_threat {
        Some(bt) => plan
            .platoons
            .iter()
            .filter(|q| q.role == PlatoonRole::Combat)
            .min_by_key(|q| {
                let cq = platoon_center(game, team, q);
                Hex::distance(cq, bt)
            })
            .map(|q| q.id),
        None => None,
    };
    // —— 分桥渡河：未过河的战斗排按行匹配分配到不同的桥（多路过河，
    //    避免全部挤向同一座桥；桥面/桥头有敌时优先夺桥） ——
    let all_bridges = game.map.bridge_hexes();
    let mut bridge_used: Vec<Hex> = Vec::new();
    if let (Some(bt), Some(_)) = (bridge_threat, bridge_owner) {
        bridge_used.push(bt);
    }
    if !all_bridges.is_empty() {
        for q in &mut plan.platoons {
            if q.role != PlatoonRole::Combat {
                continue;
            }
            if matches!(
                q.ptype,
                PlatoonType::AirDefense | PlatoonType::AirDefenseInfantry | PlatoonType::Heli
            ) {
                continue;
            }
            if bridge_owner == Some(q.id) {
                continue; // 该排已负责夺桥
            }
            let cq = platoon_center(game, team, q);
            if cq == Hex::ZERO {
                continue;
            }
            let (cc, cr) = hex::offset_from_axial(cq);
            let pick = all_bridges
                .iter()
                .filter(|b| !bridge_used.contains(b))
                .min_by_key(|b| {
                    let (_, br) = hex::offset_from_axial(**b);
                    (br - cr).abs() * 2 + Hex::distance(cq, **b)
                })
                .copied();
            if let Some(bp) = pick {
                let (nbc, _) = hex::offset_from_axial(bp);
                // 仍在自己一侧（未过河）且桥在敌方方向 → 目标 = 该桥（过河点）
                let still_own_side = match team {
                    Team::Player => cc <= nbc,
                    Team::Ai => cc >= nbc,
                };
                let toward_enemy = match team {
                    Team::Player => bp.q > cq.q,
                    Team::Ai => bp.q < cq.q,
                };
                if still_own_side && toward_enemy && Hex::distance(cq, bp) > 3 {
                    q.target = bp;
                    q.order = PlatoonOrder::Advance;
                    bridge_used.push(bp);
                }
            }
        }
    }
    for p in &mut plan.platoons {
        // 夺桥/守桥：最近的战斗排接管桥
        if let (Some(bt), Some(oid)) = (bridge_threat, bridge_owner) {
            if oid == p.id {
                p.target = bt;
                p.order = PlatoonOrder::Advance;
                continue;
            }
        }
        let alive: Vec<Unit> = p
            .members
            .iter()
            .filter_map(|l| company_unit_by_label(game, team, *l))
            .collect();
        if alive.is_empty() {
            continue;
        }
        let center = {
            let mut q = 0i64;
            let mut r = 0i64;
            for u in &alive {
                q += u.pos.q as i64;
                r += u.pos.r as i64;
            }
            Hex::new((q / alive.len() as i64) as i32, (r / alive.len() as i64) as i32)
        };
        match p.role {
            PlatoonRole::Artillery => {
                // 榴弹炮排：守后方炮位（己方出发区纵深），不随战线推进
                let Some(hq) = hq else {
                    continue;
                };
                let dir = dir_toward(hq, enemy_ref);
                p.target = hex_off(hq, dir, -3); // HQ 向敌方 3 格处作炮位
                if !game.map.contains(p.target) {
                    p.target = hq;
                }
                p.order = PlatoonOrder::Hold;
            }
            PlatoonRole::Combat => {
                // 防空排/防空步兵排：他排发现空中单位 → 连队派其前往支援
                if matches!(
                    p.ptype,
                    PlatoonType::AirDefense | PlatoonType::AirDefenseInfantry
                ) {
                    let air = game
                        .enemies_of(team)
                        .into_iter()
                        .find(|e| e.kind.is_air() && game.is_unit_visible(team, e.pos))
                        .map(|e| e.pos);
                    if let Some(ap) = air {
                        p.target = ap;
                        p.order = PlatoonOrder::Advance;
                        continue;
                    }
                }
                // 直升机排：连队下令空降点 = 敌方指挥部（已知时）或最深的可见敌军
                if p.ptype == PlatoonType::Heli {
                    let drop = game
                        .hq_seen
                        .get(&team)
                        .copied()
                        .flatten()
                        .or_else(|| {
                            game.enemies_of(team)
                                .into_iter()
                                .filter(|e| game.is_unit_visible(team, e.pos))
                                .max_by_key(|e| Hex::distance(center, e.pos))
                                .map(|e| e.pos)
                        })
                        .unwrap_or(center);
                    p.target = drop;
                    p.order = PlatoonOrder::Advance;
                    continue;
                }
                if defend {
                    // 回防：到指挥部前方 2 格据守（不深缩回出发点）
                    let Some(hq) = hq else {
                        continue;
                    };
                    let dir = dir_toward(hq, enemy_ref);
                    let mut rt = hex_off(hq, dir, 2);
                    if !game.map.contains(rt) {
                        rt = hq;
                    }
                    p.target = rt;
                    p.order = PlatoonOrder::Advance;
                    continue;
                }
                if assault {
                    p.target = assault_target(game, &alive[0]).unwrap_or(center);
                    p.order = PlatoonOrder::Advance;
                    continue;
                }
                // 排中心 12 格内的可见敌军
                let vis: Vec<Unit> = game
                    .enemies_of(team)
                    .into_iter()
                    .filter(|e| {
                        game.is_unit_visible(team, e.pos) && Hex::distance(e.pos, center) <= 12
                    })
                    .cloned()
                    .collect();
                if !vis.is_empty() {
                    let nearest = vis
                        .iter()
                        .min_by_key(|e| Hex::distance(e.pos, center))
                        .unwrap()
                        .clone();
                    // 撤退判定：排内"被打且打不到"的单位数
                    let beaten = alive
                        .iter()
                        .filter(|u| {
                            let threatened = vis.iter().any(|e| {
                                Hex::distance(e.pos, u.pos) <= e.kind.range()
                                    && e.kind.can_damage(u.kind)
                            });
                            let can_hit = vis.iter().any(|e| {
                                Hex::distance(e.pos, u.pos) <= u.eff_range()
                                    && u.can_target_unit(e.kind)
                                    && u.eff_attack() >= e.kind.armor()
                            });
                            threatened && !can_hit
                        })
                        .count();
                    if beaten >= cfg.platoon_retreat.max(1) as usize
                        && vis.len() as i32 >= cfg.retreat_threats.max(1)
                    {
                        // 撤退到威胁点后方 4 格（退回己方一侧，但不出战场纵深）
                        let dir = dir_toward(nearest.pos, center);
                        let mut rt = hex_off(nearest.pos, dir, -4);
                        if !game.map.contains(rt) {
                            rt = center;
                        }
                        p.target = rt;
                        p.order = PlatoonOrder::Retreat;
                    } else {
                        // 边打边推进：移动目标优先敌方未占领关键据点（占领即胜利），
                        // 射程内敌人由攻击阶段处理
                        let kpt = game
                            .keypoints
                            .iter()
                            .filter(|(_, kp)| kp.controller == team.opponent())
                            .min_by_key(|(h, _)| Hex::distance(center, **h))
                            .map(|(h, _)| *h);
                        p.target = kpt.unwrap_or(nearest.pos);
                        p.order = PlatoonOrder::Advance;
                    }
                    continue;
                }
                // 无可见敌军 → 占领敌方关键据点：最近的本方未占领敌方据点；
                // 无据点（非 sustain）则沿敌方方向推进
                let kp_target = game
                    .keypoints
                    .iter()
                    .filter(|(_, kp)| kp.controller == team.opponent())
                    .min_by_key(|(h, _)| Hex::distance(center, **h))
                    .map(|(h, _)| *h);
                if let Some(kpt) = kp_target {
                    p.target = kpt;
                    p.order = PlatoonOrder::Advance;
                    continue;
                }
                // 无可见敌军 → 沿敌方方向推进 3 格（进攻性：不限深，直抵敌出发区前）
                let dir = dir_toward(center, enemy_ref);
                let mut t = hex_off(center, dir, 3);
                // 不越过敌方出发区（防止单位扎进敌基地送死；进攻目标是摧毁敌方指挥部）
                let (tcol, _) = hex::offset_from_axial(t);
                let enemy_zone_front = match team {
                    Team::Player => game.deploy_zone(Team::Ai).iter().copied().min().unwrap_or(24),
                    Team::Ai => game.deploy_zone(Team::Player).iter().copied().max().unwrap_or(3),
                };
                if (team == Team::Player && tcol > enemy_zone_front)
                    || (team == Team::Ai && tcol < enemy_zone_front)
                {
                    t = hex_off(center, dir, 1);
                }
                if !game.map.contains(t) {
                    t = center;
                }
                p.target = t;
                p.order = PlatoonOrder::Advance;
            }
        }
    }
    game.company.insert(team, plan);
}

// ========== 连排指挥官框架：排指挥官（单位级阵型行动） ==========

/// 排指挥官：指挥排内一个单位按连指挥官指令与阵型行动。
/// 阵型：侦察前出（目标前 2 格）、步兵居中（目标）、装甲靠后（目标后 2 格）。
/// 流程：先攻击（能打就打），再按阵型位机动；排指令 Retreat → 全员撤向指挥部；
/// Hold → 原地驻守。
fn company_unit_turn(
    game: &mut GameState,
    team: Team,
    pos: Hex,
    attacked: &mut bool,
    heavy: HeavyPlan,
    log: &mut Vec<String>,
) -> Option<Hex> {
    let u = game.unit_at(pos)?.clone();
    let plan = game.company.get(&team)?.clone();
    let p = plan
        .platoons
        .iter()
        .find(|p| p.members.contains(&u.label))?
        .clone();
    let cfg = game.ai_configs.get(&team).copied().unwrap_or_default();
    let hq = game.hq_pos(team);

    // —— 攻击：有可见目标且能打 → 先开火 ——
    if !*attacked && u.kind.can_attack() && u.actions_left >= u.kind.attack_cost() && u.ammo > 0 {
        if let Some(target) = choose_target(game, &u, heavy) {
            match game.attack(u.pos, target) {
                Ok(outcome) => {
                    *attacked = true;
                    log.push(format!("[AI] {}", outcome.message));
                    if outcome.killed && game.game_over() {
                        return None;
                    }
                }
                Err(e) => {
                    log.push(format!("[AI] {}", e));
                    *attacked = true;
                }
            }
        }
    }
    let u = game.unit_at(pos)?.clone();
    if u.actions_left <= 0 {
        return Some(pos);
    }
    let vis: Vec<Unit> = game
        .enemies_of(team)
        .into_iter()
        .filter(|e| game.is_unit_visible(team, e.pos))
        .cloned()
        .collect();
    // —— 排型特化：装甲骑兵排抵达/遇敌/受攻击 → 卸下搭载步兵（Javelin/防空手） ——
    if p.ptype == PlatoonType::Cavalry && u.kind == UnitKind::CavalryIfv && !u.passengers.is_empty()
    {
        let near_target = Hex::distance(u.pos, p.target) <= 2;
        let near_enemy = vis.iter().any(|e| Hex::distance(e.pos, u.pos) <= 4);
        let shot_at = !u.passengers.is_empty()
            && vis.iter().any(|e| {
                Hex::distance(e.pos, u.pos) <= e.kind.range() && e.kind.can_damage(u.kind)
            });
        if near_target || near_enemy || shot_at {
            if let Some(dest) = company_unload_hex(game, &u) {
                if let Some(pass) = u.passengers.first().cloned() {
                    if let Ok(()) = game.disembark(u.pos, pass.label, dest) {
                        log.push(format!(
                            "[AI] {} 卸下 {} → {}（进入战斗）",
                            u.name_with_label(),
                            pass.name_with_label(),
                            hex::hex_label(dest)
                        ));
                        return Some(pos);
                    }
                }
            }
        }
    }
    // —— 排型特化：直升机排运直到空降点 → 空降特战小队 ——
    if p.ptype == PlatoonType::Heli
        && u.kind == UnitKind::TransportHeli
        && !u.passengers.is_empty()
    {
        if Hex::distance(u.pos, p.target) <= 3 {
            if let Ok(()) = game.heli_unload(u.pos) {
                log.push(format!(
                    "[AI] {} 空降特战小队 → {}（空降点）",
                    u.name_with_label(),
                    hex::hex_label(u.pos)
                ));
                return Some(pos);
            }
        }
    }
    match p.order {
        PlatoonOrder::Retreat => {
            // 整排撤退：向己方指挥部撤（有威胁则先避威胁）
            let threat = vis
                .iter()
                .min_by_key(|e| Hex::distance(e.pos, u.pos))
                .map(|e| e.pos);
            if let Some(t) = threat {
                if let Some(np) = ai_retreat(game, &u, t, log) {
                    return Some(np);
                }
            }
            let Some(hq) = hq else {
                return None;
            };
            let path = game.map.plan_move(
                &game.units,
                &game.air_units,
                u.pos,
                hq,
                u.kind.movement(),
                Some(u.clone()),
                true,
            );
            if path.len() > 1 {
                match game.move_unit(u.pos, &path, u.kind.is_air()) {
                    Ok(np) => {
                        log.push(format!(
                            "[AI] {} 随排撤退 → {}",
                            u.name_with_label(),
                            hex::hex_label(np)
                        ));
                        return Some(np);
                    }
                    Err(_) => return None,
                }
            }
            None
        }
        PlatoonOrder::Hold => {
            // 驻守：原地待命（榴弹炮排/已就位排）
            Some(pos)
        }
        PlatoonOrder::Advance => {
            // 阵型位：front（前 2 格）/ back（后 2 格）
            let dir = dir_toward(u.pos, p.target);
            let front = hex_off(p.target, dir, 2);
            let back = hex_off(p.target, dir, -1);
            let nearest = vis
                .iter()
                .min_by_key(|e| Hex::distance(e.pos, u.pos))
                .map(|e| e.pos);
            let role = company_unit_role(u.kind);
            // 排型特化阵型位
            let goal = match p.ptype {
                PlatoonType::AirDefense => {
                    // 防空排：无人机居中（target），M-SHORAD 在支援点后 1 格
                    if u.kind == UnitKind::Drone {
                        p.target
                    } else {
                        back
                    }
                }
                PlatoonType::Heli => match u.kind {
                    UnitKind::TransportHeli => p.target, // 运直到空降点
                    UnitKind::Drone => hex_off(p.target, dir, 1), // 无人机居前不前出太远
                    _ => front, // 武直前出火力
                },
                PlatoonType::Cavalry => {
                    if u.kind == UnitKind::CavalryIfv {
                        back // 战车靠后 TOW 支援
                    } else {
                        front
                    }
                }
                PlatoonType::Tank => {
                    if u.kind == UnitKind::Scout {
                        front // 侦察最前
                    } else {
                        back // 主战坦克靠后输出
                    }
                }
                _ => match role {
                CompanyRole::Recon => {
                    // 侦察前出到 front；遇敌近（≤ recon_retreat）→ 退回步兵线
                    if let Some(ep) = nearest {
                        if Hex::distance(ep, u.pos) <= cfg.recon_retreat.max(1) {
                            back
                        } else {
                            front
                        }
                    } else {
                        front
                    }
                }
                CompanyRole::Armor => back,
                CompanyRole::Infantry => p.target,
            }
            };
            if Hex::distance(u.pos, goal) <= 1 {
                return Some(pos);
            }
            // 目标回退链：阵型位 → 排目标 → 朝排目标方向 1 格（尽量靠近战线；
            // 楼房格等不可进入时逐步回退，不退回通用逻辑导致原地呼叫援军）
            let mut fallbacks = vec![goal, p.target];
            let (gcol, grow) = hex::offset_from_axial(goal);
            let near = hex::axial_from_offset(gcol, grow + 1);
            if game.map.contains(near) {
                fallbacks.push(near);
            }
            let near2 = hex::axial_from_offset(gcol, (grow + 1).min(game.map.rows - 1));
            if game.map.contains(near2) {
                fallbacks.push(near2);
            }
            let mut tried = Vec::new();
            for g in fallbacks {
                if tried.contains(&g) {
                    continue;
                }
                tried.push(g);
                let path = game.map.plan_move(
                    &game.units,
                    &game.air_units,
                    u.pos,
                    g,
                    u.kind.movement(),
                    Some(u.clone()),
                    true,
                );
                if path.len() > 1 {
                    match game.move_unit(u.pos, &path, u.kind.is_air()) {
                        Ok(np) => {
                            log.push(format!(
                                "[AI] {} → {}（排阵型）",
                                u.name_with_label(),
                                hex::hex_label(np)
                            ));
                            return Some(np);
                        }
                        Err(_) => {}
                    }
                }
            }
            // 全走不到：步兵就近进隐蔽；其他单位原地待命（不触发通用逻辑）
            if role == CompanyRole::Infantry {
                if let Some(cv) = nearest_cover(game, &u, cfg.cover_search.min(u.kind.movement())) {
                    let path = game.map.plan_move(
                        &game.units,
                        &game.air_units,
                        u.pos,
                        cv,
                        u.kind.movement(),
                        Some(u.clone()),
                        true,
                    );
                    if path.len() > 1 {
                        match game.move_unit(u.pos, &path, u.kind.is_air()) {
                            Ok(np) => {
                                log.push(format!(
                                    "[AI] {} 进入隐蔽 {}",
                                    u.name_with_label(),
                                    hex::hex_label(np)
                                ));
                                return Some(np);
                            }
                            Err(_) => {}
                        }
                    }
                }
            }
            Some(pos)
        }
    }
}

/// 按关卡选择移动策略：村庄防守关的 AI 采用"驻守村庄"移动，
/// 其余关卡沿用"朝敌人机动"。
fn ai_move_for(
    game: &mut GameState,
    team: Team,
    pos: Hex,
    log: &mut Vec<String>,
    intercept_budget: &mut i32,
    heavy: HeavyPlan,
) -> Option<Hex> {
    if game.defense_triggered(team) {
        // 全面防御：放弃村庄驻守/其他策略，全力回防指挥部
        ai_move(game, pos, log, heavy)
    } else if game.sustain_assault_ready(team) {
        // 总攻：放弃村庄驻守/防守策略，全力向敌军大本营推进
        ai_move(game, pos, log, heavy)
    } else if game.level == Level::VillageDefense && team == Team::Ai {
        ai_defend_move(game, pos, log, intercept_budget, heavy)
    } else {
        ai_move(game, pos, log, heavy)
    }
}

/// 村庄防守移动：
/// ① 有敌袭方向时，在保留核心防守力量（榴弹炮/防空/进楼步兵/已驻守单位）的
///    前提下，抽调部分机动单位前往威胁方向的前沿阻击位置；
/// ② 无威胁或不可调动单位 → 前往村庄防御位置（步兵进楼房、车辆守村庄空地、
///    直升机守村庄上空），已就位则原地驻守；附近有迷雾开火警告点则就近查探。
fn ai_defend_move(
    game: &mut GameState,
    pos: Hex,
    log: &mut Vec<String>,
    intercept_budget: &mut i32,
    _heavy: HeavyPlan,
) -> Option<Hex> {
    let u = game.unit_at(pos)?.clone();
    // ① 敌袭方向反应：调集可调动兵力前往威胁方向阻击
    let threats = threat_hexes(game, Team::Ai);
    if !threats.is_empty() && *intercept_budget > 0 && is_reactable(game, &u) {
        if let Some(spot) = intercept_spot(game, &u, &threats) {
            if spot != u.pos {
                let path = game.map.plan_move(
                    &game.units,
                    &game.air_units,
                    u.pos,
                    spot,
                    u.kind.movement(),
                    Some(u.clone()),
                    true,
                );
                if path.len() > 1 {
                    match game.move_unit(u.pos, &path, u.kind.is_air()) {
                        Ok(new_pos) => {
                            *intercept_budget -= 1;
                            log.push(format!(
                                "[AI] {} 调往敌袭方向阻击 → {}（威胁源 {}）",
                                u.name_with_label(),
                                hex::hex_label(new_pos),
                                hex::hex_label(threats[0])
                            ));
                            return Some(new_pos);
                        }
                        Err(e) => log.push(format!("[AI] 移动失败: {}", e)),
                    }
                }
            }
        }
    }
    // ② 核心驻守 / 常规防守位置
    if at_defense_spot(game, &u) {
        // 已驻守：机动单位（车辆/直升机/未进楼步兵）若附近有"从迷雾中开火"的
        // 敌军位置，就近查探（守住村庄的同时对威胁作出反应）；进楼步兵坚守楼房不查探。
        let in_building = u.kind.is_foot() && game.map.buildings.contains(&u.pos);
        if !in_building {
            if let Some(w) = nearest_fog_fire(game, &u) {
                if Hex::distance(u.pos, w) <= 6 {
                // 查探目标限制在村庄西缘（col ≥ 19）：fog-fire 点在村外时
                // 站到村庄边缘同行的观察位（视野 3 足以看清村外开火点）
                let (wc, wr) = hex::offset_from_axial(w);
                let spot = if wc < 19 {
                    hex::axial_from_offset(19, wr.clamp(0, game.map.rows - 1))
                } else {
                    w
                };
                let path = game.map.plan_move(
                    &game.units,
                    &game.air_units,
                    u.pos,
                    spot,
                    u.kind.movement(),
                    Some(u.clone()),
                    true,
                );
                    if path.len() > 1 {
                        match game.move_unit(u.pos, &path, u.kind.is_air()) {
                            Ok(new_pos) => {
                                log.push(format!(
                                    "[AI] {} 查探迷雾开火点 {}",
                                    u.name_with_label(),
                                    hex::hex_label(new_pos)
                                ));
                                return Some(new_pos);
                            }
                            Err(e) => log.push(format!("[AI] 移动失败: {}", e)),
                        }
                    }
                }
            }
        }
        return None; // 已驻守且无威胁，原地不动
    }
    let Some(target) = nearest_defense_spot(game, &u) else {
        return None;
    };
    let path = game.map.plan_move(
        &game.units,
        &game.air_units,
        u.pos,
        target,
        u.kind.movement(),
        Some(u.clone()),
        false,
    );
    if path.len() <= 1 {
        return None;
    }
    match game.move_unit(u.pos, &path, u.kind.is_air()) {
        Ok(new_pos) => {
            log.push(format!(
                "[AI] {} 进入防守位置 {}",
                u.name_with_label(),
                hex::hex_label(new_pos)
            ));
            Some(new_pos)
        }
        Err(e) => {
            log.push(format!("[AI] 移动失败: {}", e));
            None
        }
    }
}

/// 威胁感知：所有"可见的敌方单位"+"迷雾开火警告点"（AI 判断敌袭方向的依据）。
fn threat_hexes(game: &GameState, team: Team) -> Vec<Hex> {
    let mut v: Vec<Hex> = Vec::new();
    for e in game.enemies_of(team) {
        if game.is_unit_visible(team, e.pos) {
            v.push(e.pos);
        }
    }
    if let Some(m) = game.fog_fire_marks.get(&team) {
        v.extend(m.keys().copied());
    }
    v
}

/// 是否可调去阻击（核心防守力量不可调动）：
/// 榴弹炮守后方、防空单位守村、已进楼步兵守楼；其余单位（未进楼步兵、车辆、直升机）可调动。
fn is_reactable(game: &GameState, u: &Unit) -> bool {
    match u.kind {
        UnitKind::Howitzer => false,
        UnitKind::AaInfantry | UnitKind::AaMgv | UnitKind::AaLauncher => false,
        _ => !(u.kind.is_foot() && game.map.buildings.contains(&u.pos)),
    }
}

/// 威胁方向的阻击位置：村庄西缘（col 19-21）中、威胁重心行带（±3）内的空位。
/// 步兵→西缘楼房，车辆/榴弹炮→西缘空地，直升机→西缘任意格；越靠西（col 小）越优先。
fn intercept_spot(game: &GameState, u: &Unit, threats: &[Hex]) -> Option<Hex> {
    let rows: Vec<i32> = threats
        .iter()
        .map(|h| hex::offset_from_axial(*h).1)
        .collect();
    let avg = rows.iter().sum::<i32>() / rows.len().max(1) as i32;
    let lo = (avg - 3).clamp(0, game.map.rows - 1);
    let hi = (avg + 3).clamp(0, game.map.rows - 1);
    // 已在前沿带内且靠西 → 视为已在阻击位置，不再移动
    let (ucol, urow) = hex::offset_from_axial(u.pos);
    if (19..=21).contains(&ucol) && (lo..=hi).contains(&urow) {
        return Some(u.pos);
    }
    let mut best: Option<(i32, i32, Hex)> = None; // (col, 距离, hex)
    for col in 19..=21 {
        for row in lo..=hi {
            let h = hex::axial_from_offset(col, row);
            if h == u.pos || game.unit_at(h).is_some() {
                continue;
            }
            if u.kind.is_air() {
                // 直升机：西缘任意格
            } else if u.kind.is_foot() {
                if !game.map.buildings.contains(&h) {
                    continue;
                }
            } else {
                if game.map.buildings.contains(&h) || game.map.obstacles.contains(&h) {
                    continue;
                }
            }
            let d = Hex::distance(u.pos, h);
            if best.map_or(true, |(bc, bd, _)| col < bc || (col == bc && d < bd)) {
                best = Some((col, d, h));
            }
        }
    }
    best.map(|(_, _, h)| h)
}

/// 侦察单位前出：朝最近的可见敌人（或敌方半场中心）推进，为全队开眼。
fn ai_recon_move(
    game: &mut GameState,
    u: &Unit,
    team: Team,
    log: &mut Vec<String>,
) -> Option<Hex> {
    let target = {
        let es = game.enemies_of(team);
        let vis = es
            .iter()
            .filter(|e| game.is_unit_visible(team, e.pos))
            .min_by_key(|e| Hex::distance(u.pos, e.pos));
        match vis {
            Some(e) => e.pos,
            None => {
                // 占领目标：最近的本方未占领敌方关键据点（sustain 模式）
                if game.sustain {
                    if let Some(kpt) = game
                        .keypoints
                        .iter()
                        .filter(|(_, kp)| kp.controller == team.opponent())
                        .min_by_key(|(h, _)| Hex::distance(u.pos, **h))
                        .map(|(h, _)| *h)
                    {
                        kpt
                    } else {
                        // 敌方起点区域中心（前出方向）
                        let zone = game.deploy_zone(team.opponent());
                        let mid = zone.get(zone.len() / 2).copied().unwrap_or(0);
                        hex::axial_from_offset(mid, game.map.rows / 2)
                    }
                } else {
                    // 敌方起点区域中心（前出方向）
                    let zone = game.deploy_zone(team.opponent());
                    let mid = zone.get(zone.len() / 2).copied().unwrap_or(0);
                    hex::axial_from_offset(mid, game.map.rows / 2)
                }
            }
        }
    };
    let path = game.map.plan_move(
        &game.units,
        &game.air_units,
        u.pos,
        target,
        u.kind.movement(),
        Some(u.clone()),
        true,
    );
    if path.len() <= 1 {
        return None;
    }
    // 前出距离由配置控制：到达"距目标 ≤ recon_forward 格"处即停止（不再贴脸）
    let cfg = game.ai_configs.get(&team).copied().unwrap_or_default();
    let stop_at = path
        .iter()
        .find(|h| Hex::distance(**h, target) <= cfg.recon_forward)
        .copied();
    let dest = stop_at.unwrap_or(*path.last().unwrap());
    if dest == u.pos {
        return None;
    }
    // 只走到 dest（若 plan 路径更长则截断）
    let mut sub = path.clone();
    sub.truncate(sub.iter().position(|h| *h == dest).map(|i| i + 1).unwrap_or(sub.len()));
    match game.move_unit(u.pos, &sub, u.kind.is_air()) {
        Ok(np) => {
            log.push(format!(
                "[AI] {} 前出侦察 → {}",
                u.name_with_label(),
                hex::hex_label(np)
            ));
            Some(np)
        }
        Err(e) => {
            log.push(format!("[AI] 移动失败: {}", e));
            None
        }
    }
}

/// 撤退：远离威胁点，优先撤入隐蔽地形（森林/楼房/烟雾）。
fn ai_retreat(
    game: &mut GameState,
    u: &Unit,
    threat: Hex,
    log: &mut Vec<String>,
) -> Option<Hex> {
    let mut best: Option<(i32, Hex)> = None;
    for col in 0..game.map.cols {
        for row in 0..game.map.rows {
            let h = hex::axial_from_offset(col, row);
            if h == u.pos || game.unit_at(h).is_some() {
                continue;
            }
            if Hex::distance(u.pos, h) > u.kind.movement() {
                continue;
            }
            let d = Hex::distance(h, threat);
            let cover = game.map.forests.contains(&h)
                || (u.kind.is_foot() && game.map.buildings.contains(&h))
                || game.smoke.contains_key(&h);
            let score = d * 2 + if cover { 8 } else { 0 };
            if best.map_or(true, |(bs, _)| score > bs) {
                best = Some((score, h));
            }
        }
    }
    if let Some((_, h)) = best {
        let path = game.map.plan_move(
            &game.units,
            &game.air_units,
            u.pos,
            h,
            u.kind.movement(),
            Some(u.clone()),
            true,
        );
        if path.len() > 1 {
            if let Ok(np) = game.move_unit(u.pos, &path, u.kind.is_air()) {
                log.push(format!(
                    "[AI] {} 撤退 → {}（远离威胁）",
                    u.name_with_label(),
                    hex::hex_label(np)
                ));
                return Some(np);
            }
        }
    }
    None
}

/// 响应求援：附近（≤16）存在求援点时，朝最近的求援点移动（呼叫援军策略的响应方）。
fn ai_reinforce(
    game: &mut GameState,
    u: &Unit,
    reinforcements: &[Hex],
    log: &mut Vec<String>,
) -> Option<Hex> {
    let target = reinforcements
        .iter()
        .min_by_key(|h| Hex::distance(u.pos, **h))
        .copied()?;
    if Hex::distance(u.pos, target) > 16 {
        return None; // 太远，不响应
    }
    let path = game.map.plan_move(
        &game.units,
        &game.air_units,
        u.pos,
        target,
        u.kind.movement(),
        Some(u.clone()),
        true,
    );
    if path.len() <= 1 {
        return None;
    }
    match game.move_unit(u.pos, &path, u.kind.is_air()) {
        Ok(np) => {
            log.push(format!(
                "[AI] {} 增援 → {}",
                u.name_with_label(),
                hex::hex_label(np)
            ));
            Some(np)
        }
        Err(e) => {
            log.push(format!("[AI] 移动失败: {}", e));
            None
        }
    }
}

/// 距离 u 最近的迷雾开火警告点（对方视角）。
fn nearest_fog_fire(game: &GameState, u: &Unit) -> Option<Hex> {
    game.fog_fire_marks
        .get(&u.team)
        .and_then(|marks| marks.keys().copied().min_by_key(|h| Hex::distance(u.pos, *h)))
}

/// 是否已处于村庄防御位置。
fn at_defense_spot(game: &GameState, u: &Unit) -> bool {
    let (col, _) = hex::offset_from_axial(u.pos);
    if col < 19 {
        return false; // 不在村庄区域
    }
    if u.kind.is_air() {
        return true; // 直升机守村庄上空
    }
    if u.kind.is_foot() {
        return game.map.buildings.contains(&u.pos); // 步兵进楼房
    }
    // 车辆/榴弹炮：村庄内空地（非楼房、非岩石）
    !game.map.buildings.contains(&u.pos) && !game.map.obstacles.contains(&u.pos)
}

/// 最近的村庄防御位置：步兵→空楼房；车辆/榴弹炮→村庄空地；直升机→村庄上空任意格。
fn nearest_defense_spot(game: &GameState, u: &Unit) -> Option<Hex> {
    let mut best: Option<(i32, Hex)> = None;
    for col in 19..game.map.cols {
        for row in 0..game.map.rows {
            let h = hex::axial_from_offset(col, row);
            if game.unit_at(h).is_some() {
                continue;
            }
            if u.kind.is_air() {
                // 直升机：村庄上空任意格（含岩石/楼房上方）
            } else if u.kind.is_foot() {
                // 步兵：优先空楼房；无空楼时森林兜底（score 中楼房加分）
                if !game.map.buildings.contains(&h) && !game.map.forests.contains(&h) {
                    continue;
                }
            } else {
                if game.map.buildings.contains(&h) || game.map.obstacles.contains(&h) {
                    continue;
                }
            }
            let d = Hex::distance(u.pos, h);
            let score = d - if u.kind.is_foot() && game.map.buildings.contains(&h) {
                10 // 楼房优先（离得远一点也选楼）
            } else {
                0
            };
            if best.map_or(true, |(bd, _)| score < bd) {
                best = Some((score, h));
            }
        }
    }
    best.map(|(_, h)| h)
}

/// 与最近敌人的距离（无敌人时返回一个大数）。
fn nearest_enemy_dist(game: &GameState, u: &Unit) -> i32 {
    game.enemies_of(u.team)
        .iter()
        .map(|e| Hex::distance(u.pos, e.pos))
        .min()
        .unwrap_or(i32::MAX)
}

/// 找到紧邻载具的己方可搭载单位（步兵或榴弹炮，未上车）。
fn adjacent_own_infantry(game: &GameState, u: &Unit) -> Option<Unit> {
    for n in u.pos.neighbors() {
        if let Some(inf) = game.unit_at(n) {
            if inf.team == u.team && u.can_carry(inf.kind) {
                return Some(inf.clone());
            }
        }
    }
    None
}

/// 为放下步兵选择一个落点（优先朝向敌人一侧）。
/// 空中载具（运输直升机）只能下到正下方（自身所在格，须非岩石且为空）。
fn choose_unload_hex(game: &GameState, u: &Unit) -> Option<Hex> {
    if u.kind.is_air() {
        if !game.map.obstacles.contains(&u.pos) && !game.map.is_blocked(u.pos, &game.units) {
            return Some(u.pos);
        }
        return None;
    }
    let mut best: Option<(i32, Hex)> = None;
    for n in u.pos.neighbors() {
        if !game.map.contains(n) || game.map.is_blocked(n, &game.units) {
            continue;
        }
        if game.map.water.contains(&n) {
            continue; // 不能卸下到水域
        }
        let dist = game
            .enemies_of(u.team)
            .iter()
            .map(|e| Hex::distance(n, e.pos))
            .min()
            .unwrap_or(i32::MAX);
        if best.map_or(true, |(bd, _)| dist < bd) {
            best = Some((dist, n));
        }
    }
    best.map(|(_, h)| h)
}

/// 选择攻击目标：射程内最近的"可杀伤"敌人（距离相同时优先高价值、
/// 以及能威胁到自己的），且必须视线畅通。
/// 主战坦克集火计划：Some((位置, 预计袭击数))——AI 对可见且主动防御
/// 尚未触发的主战坦克，估算全队（含移动后）能发起的袭击次数。
type HeavyPlan = Option<(Hex, i32)>;

/// 估算 team 全队对 target 能发起的袭击次数（含"移动后够到射程"的单位）。
fn count_potential_attackers(game: &GameState, team: Team, target: Hex) -> i32 {
    let mut n = 0;
    for u in game.units_of(team) {
        if !u.kind.can_attack() || u.actions_left < u.kind.attack_cost() || u.ammo_shown() <= 0 {
            continue;
        }
        let Some(t) = game.unit_at(target) else {
            continue;
        };
        if !u.can_target_unit(t.kind) || u.eff_attack() < t.kind.armor() {
            continue;
        }
        let d = Hex::distance(u.pos, target);
        if d <= u.eff_range() {
            n += 1;
        } else if u.kind.movement() > 0 && d - u.kind.movement() <= u.eff_range() {
            n += 1; // 移动后可够到（估算）
        }
    }
    n
}

/// 让 AI 对仍带主动防御的高价值目标发动一次同时攻击齐射。
/// 返回参与了齐射的单位标签，主循环对这些单位标记“已攻击”，避免重复开火。
fn try_ai_simultaneous_volley(
    game: &mut GameState,
    team: Team,
    focus: i32,
    log: &mut Vec<String>,
) -> HashSet<char> {
    let mut done = HashSet::new();
    let Some(target) = game.enemies_of(team).into_iter().find(|e| {
        matches!(e.kind, UnitKind::HeavyTank | UnitKind::CavalryIfv)
            && e.ad_uses > 0
            && game.is_unit_visible(team, e.pos)
    }) else {
        return done;
    };
    let target = target.clone();
    let mut orders: Vec<SimulOrder> = Vec::new();
    for u in game.units_of(team) {
        if !u.kind.can_attack() || u.actions_left < u.kind.attack_cost() {
            continue;
        }
        if u.kind == UnitKind::Howitzer || u.kind == UnitKind::Mortar {
            // 范围攻击：只纳入能打穿目标护甲且已满足架设/射程/弹药校验的（如 M864 榴弹炮）
            if u.eff_attack() < target.kind.armor() {
                continue;
            }
        } else if !u.can_target_unit(target.kind) || u.eff_attack() < target.kind.armor() {
            continue;
        }
        let order = SimulOrder {
            attacker: u.pos,
            target: target.pos,
            air_first: u.kind.is_air(),
            aa_mode: u.aa_mode,
            missile_mode: u.missile_mode,
        };
        if game.validate_simul_order(order).is_ok() {
            orders.push(order);
        }
    }
    if orders.len() < focus.max(2) as usize {
        return done;
    }
    match game.simultaneous_attack(&orders) {
        Ok(outcomes) => {
            for o in outcomes {
                log.push(format!("[AI] {}", o.message));
            }
            for o in &orders {
                if let Some(u) = game.unit_at(o.attacker) {
                    done.insert(u.label);
                }
            }
        }
        Err(e) => log.push(format!("[AI] 同时攻击失败: {}", e)),
    }
    done
}

fn choose_target(game: &GameState, u: &Unit, heavy: HeavyPlan) -> Option<Hex> {
    // 集火主动防御目标：AI 已优先用同时攻击齐射消耗 1 次主动防御并造成伤害；
    // 这里的 heavy_plan 仍用于单发集火决策（若尚未齐射/齐射后仍有余力）。
    let focus = game
        .ai_configs
        .get(&u.team)
        .map(|c| c.focus_attacks)
        .unwrap_or(2);
    if let Some((hpos, hits)) = heavy {
        if hits >= focus && u.can_target_unit(UnitKind::HeavyTank) {
            if let Some(e) = game.unit_at(hpos) {
                if e.team != u.team && Hex::distance(u.pos, hpos) <= u.eff_range() {
                    return Some(hpos);
                }
            }
        }
    }
    let mut best: Option<((i32, i32, i32, i32), Hex)> = None;
    for e in game.enemies_of(u.team) {
        let d = Hex::distance(u.pos, e.pos);
        if d > u.eff_range() {
            continue;
        }
        if u.eff_attack() < e.kind.armor() {
            continue; // 打不穿护甲，不打
        }
        if !game.is_unit_visible(u.team, e.pos) {
            continue; // 未侦察到（视野共享；含隐蔽判定；榴弹炮除外，它无需视野）
        }
        // 直射武器要求直射视线通畅（间瞄火力榴弹炮/迫击炮无此要求；
        // 空中单位互相攻击不受地形 LOS 限制）
        let air_to_air = u.kind.is_air() && e.kind.is_air();
        if u.kind != UnitKind::Howitzer
            && u.kind != UnitKind::Mortar
            && !air_to_air
            && !game.map.has_los_ex(u.pos, e.pos, &game.smoke)
        {
            continue; // 岩石/楼房/烟雾阻隔直射视线
        }
        if !u.can_target_unit(e.kind) {
            continue; // 目标类型不符（M-SHORAD 导弹模式只能打直升机等）
        }
        let threat = if Hex::distance(e.pos, u.pos) <= e.kind.range() && e.kind.can_damage(u.kind) {
            1
        } else {
            0
        };
        // 目标偏好按风格：Blitzer 高价值优先；Harasser 低护甲（软柿子）优先；
        // Balanced/Defender 就近优先
        let cfg = game.ai_configs.get(&u.team).copied().unwrap_or_default();
        let key = match cfg.style {
            AiStyle::Blitzer => (0, -(e.kind.value() as i32), -threat, d),
            AiStyle::Harasser => (0, e.kind.armor(), -threat, d),
            _ => (d, 0, -threat, -(e.kind.value() as i32)),
        };
        if best.map_or(true, |(k, _)| key < k) {
            best = Some((key, e.pos));
        }
    }
    best.map(|(_, h)| h)
}

/// 选择榴弹炮的炮击中心：在射程内、有视线的点中，
/// 使"范围内敌方期望伤害 - 友军期望伤害"最大。
fn choose_artillery_target(game: &GameState, u: &Unit) -> Option<Hex> {
    let mut best: Option<(f64, Hex)> = None;
    // 桥梁火力压制：桥面/桥头 2 格内的炮击点加权（封锁渡河通道）
    let bridges = game.map.bridge_hexes();
    // BFS 遍历射程内所有格
    let mut frontier = vec![u.pos];
    let mut seen = vec![u.pos];
    while let Some(h) = frontier.pop() {
        for n in h.neighbors() {
            if !game.map.contains(n) || seen.contains(&n) {
                continue;
            }
            seen.push(n);
            if Hex::distance(u.pos, n) <= u.kind.range() {
                frontier.push(n);
                // 间瞄火力：不需要直线视线（榴弹炮可越过岩石/楼房炮击）
                let mut score = blast_score(game, u, n);
                // 桥面/桥头火力压制：命中渡河点的期望得分 ×1.8（封锁桥梁）
                if score > 0.0
                    && bridges
                        .iter()
                        .any(|b| Hex::distance(*b, n) <= 2)
                {
                    score *= 1.8;
                }
                if score > 0.0 && best.map_or(true, |(bs, _)| score > bs) {
                    best = Some((score, n));
                }
            }
        }
    }
    best.map(|(_, h)| h)
}

/// 以 center 为中心开炮的期望得分：敌方命中概率之和减去友军命中概率之和。
/// 只统计我方视野内（已侦察到）的单位：榴弹炮虽然无需视野也能开炮，
/// 但智能的炮兵只会向"看得见/曾侦察到"的敌军阵地轰击。
fn blast_score(game: &GameState, u: &Unit, center: Hex) -> f64 {
    let mut score = 0.0f64;
    let mut cells = vec![center];
    for n in center.neighbors() {
        if game.map.contains(n) {
            cells.push(n);
        }
    }
    for h in cells {
        if let Some(occ) = game.unit_at(h) {
            if occ.kind.is_air() {
                continue; // 间瞄火力打不到空中单位：直升机/无人机不计入炮击收益
            }
            if occ.team != u.team && !game.is_unit_visible(u.team, h) {
                continue; // 看不见的敌人不算（含隐蔽）
            }
            // 命中率按兵种（配置参数）：榴弹炮常规 center/edge、M864 100/100、迫击炮 center/center-30
            let cfg = game.ai_configs.get(&u.team).copied().unwrap_or_default();
            let (crate_rate, rrate) = match (u.kind, u.missile_mode) {
                (UnitKind::Mortar, _) => (
                    cfg.mortar_hit_center as f64 / 100.0,
                    (cfg.mortar_hit_center - 30).max(20) as f64 / 100.0,
                ),
                (UnitKind::Howitzer, true) => (1.0, 1.0),
                _ => (
                    cfg.arty_hit_center as f64 / 100.0,
                    cfg.arty_hit_edge as f64 / 100.0,
                ),
            };
            let rate = if h == center { crate_rate } else { rrate };
            if occ.team == u.team {
                score -= rate;
            } else if u.kind.can_damage(occ.kind) {
                score += rate;
            }
        }
    }
    score
}

/// 选择移动目标：最近的敌人（优先"能攻击到"的：类型匹配+可杀伤+有视线，
/// 防空单位会因此去追直升机）。
fn choose_move_target(game: &GameState, u: &Unit, heavy: HeavyPlan) -> Option<Hex> {
    let enemies = game.enemies_of(u.team);
    let base = enemies.iter().copied().min_by_key(|e| {
        let d = Hex::distance(u.pos, e.pos);
        let tgt = if u.can_target_unit(e.kind) && u.eff_attack() >= e.kind.armor() {
            0
        } else {
            1
        };
        (d, tgt, -(e.kind.value() as i32))
    });
    // 主战坦克对策（集火阈值由配置控制）：
    let focus = game
        .ai_configs
        .get(&u.team)
        .map(|c| c.focus_attacks)
        .unwrap_or(2);
    if let Some((hpos, hits)) = heavy {
        if hits >= focus {
            // 能集火：朝主战坦克接近（够射程后由 choose_target 开火）
            if u.can_target_unit(UnitKind::HeavyTank) && Hex::distance(u.pos, hpos) > u.eff_range() {
                return Some(hpos);
            }
        } else if Hex::distance(u.pos, hpos) <= 11 {
            // 无法对抗（袭击次数不足）：撤退或撤入隐蔽地形
            if let Some(ev) = evade_target(game, u, hpos) {
                return Some(ev);
            }
        }
    }
    // 迷雾开火警告反应：若没有可及敌人，或最近的敌人都比警告点远很多，
    // 派单位朝最近的"从迷雾中开火的敌军位置"机动查探（到达附近即可能发现敌人）。
    if let Some(marks) = game.fog_fire_marks.get(&u.team) {
        let warn = marks.keys().min_by_key(|h| Hex::distance(u.pos, **h)).copied();
        if let Some(w) = warn {
            let d_w = Hex::distance(u.pos, w);
            let d_e = base.map(|e| Hex::distance(u.pos, e.pos)).unwrap_or(i32::MAX);
            if d_e > d_w && d_w <= 14 {
                return Some(w);
            }
        }
    }
    // 关键据点任务（可持续部署）：① 己方据点被敌方控制 → 优先夺回；
    // ② 否则占领最近的敌方控制据点（移动途中射程内敌人由攻击阶段处理）。
    // 据点任务优先于追击远处敌人（新胜利条件：控制全部 6 个关键据点）。
    if game.sustain {
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.owner == u.team && kp.controller != u.team)
            .min_by_key(|(h, _)| Hex::distance(u.pos, **h))
        {
            return Some(*h); // 夺回被占的己方据点
        }
        if let Some((h, _)) = game
            .keypoints
            .iter()
            .filter(|(_, kp)| kp.controller == u.team.opponent())
            .min_by_key(|(h, _)| Hex::distance(u.pos, **h))
        {
            return Some(*h); // 占领敌方据点
        }
    }
    base.map(|e| e.pos)
}

/// 撤入隐蔽地形（森林/楼房[步兵]/烟雾），且尽可能远离主战坦克。
fn evade_target(game: &GameState, u: &Unit, heavy: Hex) -> Option<Hex> {
    let mut best: Option<(i32, Hex)> = None; // (离主战坦克距离, 位置)
    for col in 0..game.map.cols {
        for row in 0..game.map.rows {
            let h = hex::axial_from_offset(col, row);
            if h == u.pos || game.unit_at(h).is_some() {
                continue;
            }
            if u.kind.is_air() {
                continue; // 直升机不隐蔽，保持机动
            }
            let conceal = game.map.forests.contains(&h)
                || (u.kind.is_foot() && game.map.buildings.contains(&h))
                || game.smoke.contains_key(&h);
            if !conceal {
                continue;
            }
            if Hex::distance(u.pos, h) > u.kind.movement() {
                continue;
            }
            let d = Hex::distance(h, heavy);
            if best.map_or(true, |(bd, _)| d > bd) {
                best = Some((d, h));
            }
        }
    }
    best.map(|(_, h)| h)
}

/// 移动一次（一次行动，最多走"行动力"格），返回新位置。
/// 单位当前是否处于隐蔽地形（森林；步兵含楼房）。
fn at_cover(game: &GameState, u: &Unit) -> bool {
    if game.map.forests.contains(&u.pos) {
        return true;
    }
    u.kind.is_foot() && game.map.buildings.contains(&u.pos)
}

/// 最近隐蔽格：森林（步兵可进楼房），且不比当前位置更远离最近敌人（容差 2）。
fn nearest_cover(game: &GameState, u: &Unit, max_dist: i32) -> Option<Hex> {
    let (c0, r0) = hex::offset_from_axial(u.pos);
    let cur = nearest_enemy_hex(game, u);
    let cur_d = cur.map(|h| Hex::distance(u.pos, h));
    let mut best: Option<(i32, Hex)> = None;
    for dc in -max_dist..=max_dist {
        for dr in -max_dist..=max_dist {
            let cc = c0 + dc;
            let rr = r0 + dr;
            if cc < 0 || rr < 0 || cc >= game.map.cols || rr >= game.map.rows {
                continue;
            }
            let h = hex::axial_from_offset(cc, rr);
            let d = Hex::distance(u.pos, h);
            if d < 1 || d > max_dist {
                continue;
            }
            if game.unit_at(h).is_some() {
                continue;
            }
            let cover = if u.kind.is_foot() {
                game.map.buildings.contains(&h) || game.map.forests.contains(&h)
            } else {
                game.map.forests.contains(&h)
            };
            if !cover {
                continue;
            }
            // 不背离敌人（无敌人时不限制）
            if let (Some(eh), Some(cd)) = (cur, cur_d) {
                if Hex::distance(h, eh) > cd + 2 {
                    continue;
                }
            }
            if best.map_or(true, |(bd, _)| d < bd) {
                best = Some((d, h));
            }
        }
    }
    best.map(|(_, h)| h)
}

/// 最近敌人位置（AI 已知的所有敌人，含不可见——用于机动判断）。
fn nearest_enemy_hex(game: &GameState, u: &Unit) -> Option<Hex> {
    game.enemies_of(u.team)
        .iter()
        .min_by_key(|e| Hex::distance(u.pos, e.pos))
        .map(|e| e.pos)
}

/// 总攻目标：敌方当前控制的关键据点（优先最近；大本营不计入胜负）。
fn assault_target(game: &GameState, u: &Unit) -> Option<Hex> {
    let opp = u.team.opponent();
    game.keypoints
        .iter()
        .filter(|(_, kp)| !kp.center && kp.controller == opp)
        .min_by_key(|(h, _)| Hex::distance(u.pos, **h))
        .map(|(h, _)| *h)
}

fn ai_move(
    game: &mut GameState,
    pos: Hex,
    log: &mut Vec<String>,
    heavy: HeavyPlan,
) -> Option<Hex> {
    let u = game.unit_at(pos)?.clone();
    // 全面防御：敌军逼近己方指挥部（8 格内可见）→ 全力回防指挥部。
    // 已在本单位射程内可守的位置则原地待命。
    if game.defense_triggered(u.team) {
        let Some(hq) = game.hq_pos(u.team) else {
            return None;
        };
        if Hex::distance(u.pos, hq) <= u.eff_range() || Hex::distance(u.pos, hq) <= 2 {
            return None; // 已在可防守范围，原地据守
        }
        let target = hq;
        let path = game.map.plan_move(
            &game.units,
            &game.air_units,
            u.pos,
            target,
            u.kind.movement(),
            Some(u.clone()),
            true,
        );
        if path.len() <= 1 {
            return None;
        }
        match game.move_unit(u.pos, &path, u.kind.is_air()) {
            Ok(new_pos) => {
                log.push(format!(
                    "[AI] {} → {}（回防指挥部）",
                    u.name_with_label(),
                    hex::hex_label(new_pos)
                ));
                return Some(new_pos);
            }
            Err(e) => {
                log.push(format!("[AI] 移动失败: {}", e));
                return None;
            }
        }
    }
    // 总攻：敌军接近全歼 → 直接朝敌方指挥部推进（途中遇敌由攻击阶段处理）
    if game.sustain_assault_ready(u.team) {
        let target = assault_target(game, &u)?;
        let path = game.map.plan_move(
            &game.units,
            &game.air_units,
            u.pos,
            target,
            u.kind.movement(),
            Some(u.clone()),
            true,
        );
        if path.len() <= 1 {
            return None;
        }
        match game.move_unit(u.pos, &path, u.kind.is_air()) {
            Ok(new_pos) => {
                log.push(format!(
                    "[AI] {} → {}（总攻推进）",
                    u.name_with_label(),
                    hex::hex_label(new_pos)
                ));
                return Some(new_pos);
            }
            Err(e) => {
                log.push(format!("[AI] 移动失败: {}", e));
                return None;
            }
        }
    } else if u.kind.is_foot()
        && !at_cover(game, &u)
        && game
            .ai_configs
            .get(&u.team)
            .map(|c| c.style != AiStyle::Blitzer)
            .unwrap_or(true)
    {
        // 闪电突击不优先躲隐蔽，直接推进
        let cfg = game.ai_configs.get(&u.team).copied().unwrap_or_default();
        let cover_max = cfg.cover_search.min(u.kind.movement());
        if let Some(cover) = nearest_cover(game, &u, cover_max) {
            let path = game.map.plan_move(
                &game.units,
                &game.air_units,
                u.pos,
                cover,
                u.kind.movement(),
                Some(u.clone()),
                true,
            );
            if path.len() > 1 {
                match game.move_unit(u.pos, &path, u.kind.is_air()) {
                    Ok(np) => {
                        log.push(format!(
                            "[AI] {} 进入隐蔽地形 {}",
                            u.name_with_label(),
                            hex::hex_label(np)
                        ));
                        return Some(np);
                    }
                    Err(e) => log.push(format!("[AI] 移动失败: {}", e)),
                }
            }
        }
    }
    let target = choose_move_target(game, &u, heavy)?;
    let path = game.map.plan_move(
        &game.units,
        &game.air_units,
        u.pos,
        target,
        u.kind.movement(),
        Some(u.clone()),
        true, // AI 尽量避火
    );
    if path.len() <= 1 {
        return None; // 无路可走
    }
    match game.move_unit(u.pos, &path, u.kind.is_air()) {
        Ok(new_pos) => {
            log.push(format!(
                "[AI] {} → {}",
                u.name_with_label(),
                hex::hex_label(new_pos)
            ));
            Some(new_pos)
        }
        Err(e) => {
            log.push(format!("[AI] 移动失败: {}", e));
            None
        }
    }
}

/// AI 部署：用招募点数选兵并放入己方出发区域（右侧 4 列）。
/// 原则：① 保证核心阵容（坦克/防空/步兵各至少 1，能力全面）；
/// ② 其余点数按权重随机补充（坦克/武直/榴弹炮较贵、步兵廉价）——
///    不同对局阵容不同，但整体维持在 6-12 个单位。
/// AI 选购清单：用当前剩余点数按权重挑选要部署的单位（含核心必选与卡车补购）。
/// 初始部署与可持续部署共用。
fn ai_buy_list(game: &mut GameState, team: Team, max_total: usize) -> Vec<UnitKind> {
    let mut deployed: Vec<UnitKind> = Vec::new();
    // ① 核心必选（按价值优先，点数不够则跳过）
    for kind in [
        UnitKind::Tank,
        UnitKind::AaLauncher,
        UnitKind::Rifleman,
        UnitKind::AttackHeli,
    ] {
        if game.recruit_points.get(&team).copied().unwrap_or(0) >= kind.recruit_cost()
            && !deployed.contains(&kind)
        {
            deployed.push(kind);
        }
    }
    // ② 加权随机补充
    let weights = [
        (UnitKind::Tank, 20),
        (UnitKind::HeavyTank, 6),
        (UnitKind::AttackHeli, 13),
        (UnitKind::Howitzer, 10),
        (UnitKind::Mortar, 8),
        (UnitKind::Ifv, 10),
        (UnitKind::HumveeHmg, 7),
        (UnitKind::HumveeTow, 6),
        (UnitKind::HumveeJavelin, 5),
        (UnitKind::AaLauncher, 8),
        (UnitKind::Atgm, 9),
        (UnitKind::Javelin, 5),
        (UnitKind::SpecialForces, 4),
        (UnitKind::EliteInfantry, 3),
        (UnitKind::Rifleman, 9),
        (UnitKind::Scout, 12), // 侦察战车：AI 优先部署用于前出侦察
        (UnitKind::AaMgv, 8),
        (UnitKind::AaInfantry, 6),
        (UnitKind::HmgGunner, 6),
        (UnitKind::Drone, 5),
    ];
    loop {
        let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
        // 同类型数量上限：昂贵单位最多 3，廉价可多
        let max_count = |k: UnitKind| match k {
            UnitKind::Tank | UnitKind::HeavyTank | UnitKind::AttackHeli | UnitKind::Howitzer => 3,
            _ => 4,
        };
        // 只从"买得起且未达上限"的类型中加权选取（避免空转）
        let pool: Vec<(UnitKind, i32)> = weights
            .iter()
            .copied()
            .filter(|(k, _)| {
                let cnt = deployed.iter().filter(|d| **d == *k).count();
                cnt < max_count(*k) && pts >= k.recruit_cost()
            })
            .collect();
        if pool.is_empty() {
            break;
        }
        let total: i32 = pool.iter().map(|(_, w)| w).sum();
        let mut r: i32 = {
            use rand::Rng;
            game.rng.gen_range(0..total)
        };
        let mut pick = pool[0].0;
        for (k, w) in &pool {
            r -= w;
            if r < 0 {
                pick = *k;
                break;
            }
        }
        deployed.push(pick);
    }
    // 纯运输单位按需招募：部署了榴弹炮 → 补 1 辆卡车运它；否则不买卡车/运输直升机
    let has_howitzer = deployed.contains(&UnitKind::Howitzer);
    let has_truck = deployed.contains(&UnitKind::Truck);
    let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
    if has_howitzer
        && !has_truck
        && pts >= UnitKind::Truck.recruit_cost()
        && deployed.len() < max_total
    {
        deployed.push(UnitKind::Truck);
    }
    deployed
}

/// 连排指挥官增援：按缺员排补兵（战斗排缺装甲→补坦克、缺侦察→补侦察车、
/// 缺步兵→补步兵；榴弹炮排缺榴弹炮/卡车→补齐），都齐则补防空。
/// 放置到指挥部旁并加入对应排成员。
fn ai_company_reinforce(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    let plan = match game.company.get(&team).cloned() {
        Some(p) => p,
        None => return,
    };
    // 按排型找缺员的排与要补的兵种（count = 该兵种现存数量）
    let count_of = |game: &GameState, p: &PlatoonPlan, k: UnitKind| -> usize {
        p.members
            .iter()
            .filter(|l| {
                game.units_of(team)
                    .iter()
                    .any(|u| u.label == **l && u.kind == k)
            })
            .count()
    };
    let mut pick: Option<(usize, UnitKind)> = None;
    // 防空倾向：防空排优先补兵（防空单位被击毁时快速补位）
    let aa_up = aa_trigger(game, team);
    let mut platoons_iter: Vec<&PlatoonPlan> = plan.platoons.iter().collect();
    if aa_up {
        platoons_iter.sort_by_key(|p| {
            if matches!(
                p.ptype,
                PlatoonType::AirDefense | PlatoonType::AirDefenseInfantry
            ) {
                0
            } else {
                1
            }
        });
    }
    for p in platoons_iter {
        let want = match p.ptype {
            PlatoonType::Tank => {
                if count_of(game, p, UnitKind::HeavyTank) < 2 {
                    Some(UnitKind::HeavyTank)
                } else if count_of(game, p, UnitKind::HeavyTank) + count_of(game, p, UnitKind::Tank)
                    < 3
                {
                    Some(UnitKind::Tank) // 排扩容：补第 3 辆装甲
                } else if count_of(game, p, UnitKind::Scout) < 1 {
                    Some(UnitKind::Scout)
                } else {
                    None
                }
            }
            PlatoonType::Cavalry => {
                if count_of(game, p, UnitKind::CavalryIfv) < 2 {
                    Some(UnitKind::CavalryIfv)
                } else if count_of(game, p, UnitKind::CavalryIfv) < 3 {
                    Some(UnitKind::CavalryIfv) // 排扩容：补第 3 辆战车
                } else if count_of(game, p, UnitKind::Scout) < 1 {
                    Some(UnitKind::Scout)
                } else {
                    None
                }
            }
            PlatoonType::Motorized => {
                if count_of(game, p, UnitKind::Truck) < 1 {
                    Some(UnitKind::Truck)
                } else if count_of(game, p, UnitKind::Tank) < 1 {
                    Some(UnitKind::Tank)
                } else if count_of(game, p, UnitKind::Scout) < 1 {
                    Some(UnitKind::Scout)
                } else {
                    None
                }
            }
            PlatoonType::Mechanized => {
                if count_of(game, p, UnitKind::Ifv) < 2 {
                    Some(UnitKind::Ifv)
                } else if count_of(game, p, UnitKind::Tank) < 2 {
                    Some(UnitKind::Tank)
                } else if count_of(game, p, UnitKind::Scout) < 1 {
                    Some(UnitKind::Scout)
                } else {
                    None
                }
            }
            PlatoonType::AirDefense => {
                if count_of(game, p, UnitKind::AaMgv) < 3 {
                    Some(UnitKind::AaMgv)
                } else if count_of(game, p, UnitKind::Drone) < 1 {
                    Some(UnitKind::Drone)
                } else {
                    None
                }
            }
            PlatoonType::AirDefenseInfantry => {
                // 防空步兵排：卡车 + 3 防空导弹手 + 1 M-SHORAD
                if count_of(game, p, UnitKind::Truck) < 1 {
                    Some(UnitKind::Truck)
                } else if count_of(game, p, UnitKind::AaInfantry) < 3 {
                    Some(UnitKind::AaInfantry)
                } else if count_of(game, p, UnitKind::AaMgv) < 1 {
                    Some(UnitKind::AaMgv)
                } else {
                    None
                }
            }
            PlatoonType::Heli => {
                if count_of(game, p, UnitKind::AttackHeli) < 2 {
                    Some(UnitKind::AttackHeli)
                } else if count_of(game, p, UnitKind::TransportHeli) < 1 {
                    Some(UnitKind::TransportHeli)
                } else if count_of(game, p, UnitKind::Drone) < 1 {
                    Some(UnitKind::Drone)
                } else {
                    None
                }
            }
            PlatoonType::Artillery => {
                if count_of(game, p, UnitKind::Howitzer) < 2 {
                    Some(UnitKind::Howitzer)
                } else if count_of(game, p, UnitKind::Truck) < 2 {
                    Some(UnitKind::Truck)
                } else {
                    None
                }
            }
        };
        if let Some(w) = want {
            pick = Some((p.id, w));
            break;
        }
    }
    let (pid, kind) = match pick {
        Some(pk) => pk,
        None => {
            // 所有排齐员 → 给战斗排扩容（补装甲主力），无战斗排则补步兵
            match plan.platoons.iter().find(|p| p.role == PlatoonRole::Combat) {
                Some(p) => (p.id, UnitKind::Tank),
                None => (usize::MAX, UnitKind::Rifleman),
            }
        }
    };
    let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
    if pts < kind.recruit_cost() {
        log.push(format!(
            "[AI] 待招募 {} 还需攒 {} 点（当前 {}）",
            kind.name(),
            kind.recruit_cost() - pts,
            pts
        ));
        return;
    }
    // 放置：指挥部周围 2 格内随机空位
    let Some(hq) = game.hq_pos(team) else {
        return;
    };
    let mut candidates: Vec<Hex> = Vec::new();
    let (hc, hr) = hex::offset_from_axial(hq);
    for dc in -2..=2 {
        for dr in -2..=2 {
            let cc = hc + dc;
            let rr = hr + dr;
            if cc < 0 || rr < 0 || cc >= game.map.cols || rr >= game.map.rows {
                continue;
            }
            let hx = hex::axial_from_offset(cc, rr);
            if Hex::distance(hq, hx) > 2 {
                continue;
            }
            if game.unit_at(hx).is_some() || game.zone_occupied(team, hx) {
                continue;
            }
            if !kind.is_air() {
                if game.map.obstacles.contains(&hx) {
                    continue;
                }
                if game.map.buildings.contains(&hx) && !kind.is_foot() {
                    continue;
                }
            }
            candidates.push(hx);
        }
    }
    if candidates.is_empty() {
        log.push("[AI] 指挥部周围无空位，暂缓招募".into());
        return;
    }
    // 放置优化：优先放在最靠近前线（对应排目标 / 桥 / 敌方向）的空位，
    // 缩短增援单位奔赴前线的路程
    let front_anchor: Option<Hex> = {
        let plan = game.company.get(&team).cloned();
        plan.and_then(|p| {
            p.platoons
                .iter()
                .find(|q| q.id == pid)
                .map(|q| q.target)
                .or_else(|| {
                    game.enemies_of(team)
                        .iter()
                        .filter(|e| game.is_unit_visible(team, e.pos))
                        .map(|e| e.pos)
                        .min_by_key(|h| {
                            candidates
                                .iter()
                                .map(|c| Hex::distance(*c, *h))
                                .min()
                                .unwrap_or(i32::MAX)
                        })
                })
        })
    };
    let pos = match front_anchor {
        Some(anchor) => {
            let mut sorted = candidates.clone();
            sorted.sort_by_key(|h| Hex::distance(*h, anchor));
            sorted[0]
        }
        None => {
            use rand::Rng;
            let idx = game.rng.gen_range(0..candidates.len());
            candidates[idx]
        }
    };
    if let Ok(label) = game.reinforce_unit(team, kind, pos) {
        log.push(format!(
            "[AI增援] {} {} → {}（指挥部旁）",
            label,
            kind.name(),
            hex::hex_label(pos)
        ));
        // 加入对应排
        if let Some(mut plan) = game.company.get(&team).cloned() {
            if let Some(p) = plan.platoons.iter_mut().find(|p| p.id == pid) {
                p.members.push(label);
            }
            game.company.insert(team, plan);
        }
    }
}



/// AI 可持续部署：用当前累计点数在本方大本营区域追加部署（受占领规则限制）。
pub(crate) fn ai_reinforce_turn(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    // 连排指挥官框架：按缺员排补兵
    if game
        .ai_configs
        .get(&team)
        .map(|c| c.style == AiStyle::Company)
        .unwrap_or(false)
    {
        ai_company_reinforce(game, team, log);
        return;
    }
    // 待招募计划：没有计划 → 随机产生下一个兵种；有计划但点数不足 → 攒点等待
    let next = game.ai_recruit_plan.get(&team).copied().flatten();
    let kind = match next {
        Some(k) => k,
        None => {
            let k = ai_pick_recruit_kind(game, team);
            game.ai_recruit_plan.insert(team, Some(k));
            log.push(format!(
                "[AI] 计划招募 {}（{} 点）",
                k.name(),
                k.recruit_cost()
            ));
            k
        }
    };
    let pts = game.recruit_points.get(&team).copied().unwrap_or(0);
    if pts < kind.recruit_cost() {
        log.push(format!(
            "[AI] 待招募 {} 还需攒 {} 点（当前 {}）",
            kind.name(),
            kind.recruit_cost() - pts,
            pts
        ));
        return;
    }
    // 放置：指挥部周围 2 格内随机找未被占领空位
    let Some(hq) = game.hq_pos(team) else {
        return;
    };
    let mut candidates: Vec<Hex> = Vec::new();
    let (hc, hr) = hex::offset_from_axial(hq);
    for dc in -2..=2 {
        for dr in -2..=2 {
            let cc = hc + dc;
            let rr = hr + dr;
            if cc < 0 || rr < 0 || cc >= game.map.cols || rr >= game.map.rows {
                continue;
            }
            let hx = hex::axial_from_offset(cc, rr);
            if Hex::distance(hq, hx) > 2 {
                continue;
            }
            if game.unit_at(hx).is_some() || game.zone_occupied(team, hx) {
                continue;
            }
            if !kind.is_air() {
                if game.map.obstacles.contains(&hx) {
                    continue;
                }
                if game.map.buildings.contains(&hx) && !kind.is_foot() {
                    continue;
                }
            }
            candidates.push(hx);
        }
    }
    if candidates.is_empty() {
        log.push("[AI] 指挥部周围无空位，暂缓招募".into());
        return;
    }
    let pos = {
        use rand::Rng;
        let idx = game.rng.gen_range(0..candidates.len());
        candidates[idx]
    };
    if let Ok(label) = game.reinforce_unit(team, kind, pos) {
        log.push(format!(
            "[AI增援] {} {} → {}（指挥部旁）",
            label,
            kind.name(),
            hex::hex_label(pos)
        ));
        // 买完一个 → 计划清空，下回合随机产生下一个兵种
        game.ai_recruit_plan.insert(team, None);
    }
}

/// 随机产生 AI 下一个要招募的兵种（加权随机，与初始部署权重一致）。
fn ai_pick_recruit_kind(game: &mut GameState, _team: Team) -> UnitKind {
    // 增援偏好按风格：Defender 重装纵深、Blitzer 快攻、Harasser 骚扰
    let aa_up = aa_trigger(game, _team);
    let mut weights: Vec<(UnitKind, i32)> = match game
        .ai_configs
        .get(&_team)
        .map(|c| c.style)
        .unwrap_or(AiStyle::Balanced)
    {
        AiStyle::Defender => [
            (UnitKind::HmgGunner, 4),
            (UnitKind::Tank, 26),
            (UnitKind::HeavyTank, 12),
            (UnitKind::Howitzer, 16),
            (UnitKind::AaLauncher, 10),
            (UnitKind::Rifleman, 8),
            (UnitKind::Atgm, 8),
            (UnitKind::Mortar, 6),
            (UnitKind::AaInfantry, 6),
            (UnitKind::Ifv, 6),
            (UnitKind::AttackHeli, 4),
            (UnitKind::Scout, 3),
            (UnitKind::Drone, 3),
            (UnitKind::Javelin, 2),
            (UnitKind::SpecialForces, 2),
            (UnitKind::EliteInfantry, 2),
            (UnitKind::AaMgv, 2),
        ],
        AiStyle::Blitzer => [
            (UnitKind::HmgGunner, 4),
            (UnitKind::AttackHeli, 22),
            (UnitKind::Scout, 18),
            (UnitKind::Tank, 18),
            (UnitKind::Ifv, 12),
            (UnitKind::Rifleman, 10),
            (UnitKind::SpecialForces, 6),
            (UnitKind::Drone, 8),
            (UnitKind::AaInfantry, 5),
            (UnitKind::Atgm, 5),
            (UnitKind::HeavyTank, 4),
            (UnitKind::Mortar, 3),
            (UnitKind::Howitzer, 3),
            (UnitKind::Javelin, 2),
            (UnitKind::EliteInfantry, 2),
            (UnitKind::AaMgv, 2),
            (UnitKind::AaLauncher, 2),
        ],
        AiStyle::Harasser => [
            (UnitKind::HmgGunner, 4),
            (UnitKind::Mortar, 22),
            (UnitKind::Howitzer, 14),
            (UnitKind::Rifleman, 14),
            (UnitKind::Atgm, 12),
            (UnitKind::Javelin, 8),
            (UnitKind::Scout, 10),
            (UnitKind::Drone, 8),
            (UnitKind::Tank, 8),
            (UnitKind::AaInfantry, 6),
            (UnitKind::SpecialForces, 6),
            (UnitKind::AttackHeli, 6),
            (UnitKind::Ifv, 5),
            (UnitKind::AaMgv, 3),
            (UnitKind::EliteInfantry, 3),
            (UnitKind::HeavyTank, 2),
            (UnitKind::AaLauncher, 2),
        ],
        AiStyle::Company => [
            (UnitKind::HmgGunner, 4),
            (UnitKind::Tank, 20),
            (UnitKind::HeavyTank, 6),
            (UnitKind::AttackHeli, 13),
            (UnitKind::Howitzer, 10),
            (UnitKind::Mortar, 8),
            (UnitKind::Ifv, 10),
            (UnitKind::AaLauncher, 8),
            (UnitKind::Atgm, 9),
            (UnitKind::Javelin, 5),
            (UnitKind::SpecialForces, 4),
            (UnitKind::EliteInfantry, 3),
            (UnitKind::Rifleman, 9),
            (UnitKind::Scout, 12),
            (UnitKind::AaMgv, 8),
            (UnitKind::AaInfantry, 6),
            (UnitKind::Drone, 5),
        ],
        AiStyle::Balanced => [
            (UnitKind::HmgGunner, 4),
            (UnitKind::Tank, 20),
            (UnitKind::HeavyTank, 6),
            (UnitKind::AttackHeli, 13),
            (UnitKind::Howitzer, 10),
            (UnitKind::Mortar, 8),
            (UnitKind::Ifv, 10),
            (UnitKind::AaLauncher, 8),
            (UnitKind::Atgm, 9),
            (UnitKind::Javelin, 5),
            (UnitKind::SpecialForces, 4),
            (UnitKind::EliteInfantry, 3),
            (UnitKind::Rifleman, 9),
            (UnitKind::Scout, 12),
            (UnitKind::AaMgv, 8),
            (UnitKind::AaInfantry, 6),
            (UnitKind::Drone, 5),
        ],
    }
    .to_vec();
    // 防空倾向：场上存在敌方空中单位 / 己方防空被击毁 → 防空单位权重大幅提升
    if aa_up {
        for (k, w) in weights.iter_mut() {
            if matches!(
                *k,
                UnitKind::AaLauncher | UnitKind::AaMgv | UnitKind::AaInfantry | UnitKind::Drone
            ) {
                *w = *w * 5 / 2;
            }
        }
    }
    let total: i32 = weights.iter().map(|(_, w)| w).sum();
    let mut r: i32 = {
        use rand::Rng;
        game.rng.gen_range(0..total)
    };
    for (k, w) in &weights {
        r -= w;
        if r < 0 {
            return *k;
        }
    }
    weights[0].0
}

/// 连排指挥官部署：按排编组购买与放置。
/// 顺序：① 战斗排（侦察×recon_per + 装甲×armor_per + 步兵，每排预算 platoon_points）
/// ② 榴弹炮排（榴弹炮×2 + 卡车×2，共 arty_platoons 个）
/// ③ 连直属（剩余点数补防空/步兵）。
/// 同排成员集中放置在出发区排中心附近（≤2 格），建立 CompanyPlan。
fn ai_company_deploy(game: &mut GameState, team: Team) -> Vec<String> {
    let mut log = Vec::new();
    let cfg = game.ai_configs.get(&team).copied().unwrap_or_default();
    let mut plan = CompanyPlan { platoons: Vec::new() };
    let mut platoon_id = 0usize;
    // 放置辅助：出发区内距中心 ≤2 的空位
    let zone = game.deploy_zone(team);
    let place = |game: &mut GameState,
                     kind: UnitKind,
                     center: Hex|
     -> Option<(char, Hex)> {
        let mut cand: Vec<Hex> = Vec::new();
        let (cc, cr) = hex::offset_from_axial(center);
        for dc in -2..=2 {
            for dr in -2..=2 {
                let cx = cc + dc;
                let ry = cr + dr;
                if !zone.contains(&cx) || cx < 0 || ry < 0 {
                    continue;
                }
                if cx >= game.map.cols || ry >= game.map.rows {
                    continue;
                }
                let hx = hex::axial_from_offset(cx, ry);
                if game.unit_at(hx).is_some() {
                    continue;
                }
                if !kind.is_air() {
                    if game.map.obstacles.contains(&hx) {
                        continue;
                    }
                    if game.map.buildings.contains(&hx) && !kind.is_foot() {
                        continue;
                    }
                }
                cand.push(hx);
            }
        }
        if cand.is_empty() {
            return None;
        }
        let pos = {
            use rand::Rng;
            let idx = game.rng.gen_range(0..cand.len());
            cand[idx]
        };
        match game.deploy_unit(team, kind, pos) {
            Ok(label) => Some((label, pos)),
            Err(_) => None,
        }
    };
    // 随机排中心（出发区内）
    let random_center = |game: &mut GameState| {
        use rand::Rng;
        let col = zone[game.rng.gen_range(0..zone.len())];
        let row = game.rng.gen_range(0..game.map.rows);
        hex::axial_from_offset(col, row)
    };
    // 排型 → (角色, 构成列表)：每个元素 = (单位, 预装步兵)。预装步兵部署在载具
    // 紧邻格并立即上车（随载具出动）。
    let blueprint = |ptype: PlatoonType| -> (PlatoonRole, Vec<(UnitKind, Vec<UnitKind>)>) {
        match ptype {
            PlatoonType::Tank => (
                PlatoonRole::Combat,
                vec![
                    (UnitKind::HeavyTank, vec![]),
                    (UnitKind::HeavyTank, vec![]),
                    (UnitKind::Scout, vec![]),
                ],
            ),
            PlatoonType::Cavalry => (
                PlatoonRole::Combat,
                vec![
                    (UnitKind::CavalryIfv, vec![UnitKind::Javelin]),
                    (UnitKind::CavalryIfv, vec![UnitKind::AaInfantry]),
                    (UnitKind::Scout, vec![]),
                ],
            ),
            PlatoonType::Motorized => (
                PlatoonRole::Combat,
                vec![
                    // 卡车装上全部步兵后出发（2 步枪手 + 1 精锐步兵）
                    (
                        UnitKind::Truck,
                        vec![
                            UnitKind::Rifleman,
                            UnitKind::Rifleman,
                            UnitKind::EliteInfantry,
                        ],
                    ),
                    (UnitKind::Scout, vec![]),
                    (UnitKind::Tank, vec![]),
                ],
            ),
            PlatoonType::Mechanized => (
                PlatoonRole::Combat,
                vec![
                    (UnitKind::Ifv, vec![UnitKind::Rifleman]),
                    (UnitKind::Ifv, vec![UnitKind::EliteInfantry]),
                    (UnitKind::Tank, vec![]),
                    (UnitKind::Tank, vec![]),
                    (UnitKind::Scout, vec![]),
                ],
            ),
            PlatoonType::AirDefense => (
                PlatoonRole::Combat,
                vec![
                    (UnitKind::AaMgv, vec![]),
                    (UnitKind::AaMgv, vec![]),
                    (UnitKind::AaMgv, vec![]),
                    (UnitKind::Drone, vec![]),
                ],
            ),
            PlatoonType::AirDefenseInfantry => (
                PlatoonRole::Combat,
                vec![
                    // 1 辆卡车搭载 3 队防空导弹手 + 1 辆 M-SHORAD（廉价防空）
                    (
                        UnitKind::Truck,
                        vec![
                            UnitKind::AaInfantry,
                            UnitKind::AaInfantry,
                            UnitKind::AaInfantry,
                        ],
                    ),
                    (UnitKind::AaMgv, vec![]),
                ],
            ),
            PlatoonType::Heli => (
                PlatoonRole::Combat,
                vec![
                    (UnitKind::AttackHeli, vec![]),
                    (UnitKind::AttackHeli, vec![]),
                    (UnitKind::TransportHeli, vec![UnitKind::SpecialForces]),
                    (UnitKind::Drone, vec![]),
                ],
            ),
            PlatoonType::Artillery => (
                PlatoonRole::Artillery,
                vec![
                    (UnitKind::Howitzer, vec![]),
                    (UnitKind::Howitzer, vec![]),
                    (UnitKind::Truck, vec![]),
                    (UnitKind::Truck, vec![]),
                ],
            ),
        }
    };
    let blueprint_cost = |ptype: PlatoonType| -> i32 {
        blueprint(ptype)
            .1
            .iter()
            .map(|(k, p)| k.recruit_cost() + p.iter().map(|x| x.recruit_cost()).sum::<i32>())
            .sum()
    };
    // 排型优先级（按连队构成模式）：
    // 预算足够则按序建（每种 1 个）；预算不足的排型跳过；排数受 platoon_count 上限
    let priority: Vec<PlatoonType> = match cfg.platoon_pattern {
        // 1 重装猛推：坦克/机械化为主
        1 => vec![
            PlatoonType::Tank,
            PlatoonType::Mechanized,
            PlatoonType::Tank,
            PlatoonType::Cavalry,
            PlatoonType::AirDefense,
            PlatoonType::AirDefenseInfantry,
            PlatoonType::Artillery,
        ],
        // 2 火炮压制：榴弹炮排优先（桥面/纵深火力压制）
        2 => vec![
            PlatoonType::Artillery,
            PlatoonType::Artillery,
            PlatoonType::Tank,
            PlatoonType::Cavalry,
            PlatoonType::AirDefense,
            PlatoonType::AirDefenseInfantry,
            PlatoonType::Motorized,
        ],
        // 3 机动打击：装甲骑兵/摩托化/直升机快攻
        3 => vec![
            PlatoonType::Cavalry,
            PlatoonType::Motorized,
            PlatoonType::Heli,
            PlatoonType::AirDefense,
            PlatoonType::AirDefenseInfantry,
            PlatoonType::Tank,
            PlatoonType::Mechanized,
        ],
        // 4 机械化强攻：机械化步兵排为主（步坦协同推进）
        4 => vec![
            PlatoonType::Mechanized,
            PlatoonType::Mechanized,
            PlatoonType::Tank,
            PlatoonType::Cavalry,
            PlatoonType::AirDefense,
            PlatoonType::AirDefenseInfantry,
            PlatoonType::Artillery,
        ],
        // 5 防空压制：防空排 + 装甲骑兵（针对武直/空中威胁）
        5 => vec![
            PlatoonType::AirDefense,
            PlatoonType::AirDefenseInfantry,
            PlatoonType::Cavalry,
            PlatoonType::Tank,
            PlatoonType::Motorized,
            PlatoonType::Artillery,
        ],
        // 0 默认均衡
        _ => vec![
            PlatoonType::Tank,
            PlatoonType::Cavalry,
            PlatoonType::AirDefense,
            PlatoonType::AirDefenseInfantry,
            PlatoonType::Motorized,
            PlatoonType::Heli,
            PlatoonType::Mechanized,
            PlatoonType::Artillery,
        ],
    };
    // 防空倾向：场上存在敌方空中单位 / 己方防空被击毁 → 防空排（防空步兵排）
    // 前置优先建立（至多 2 个防空排）
    let aa_up = aa_trigger(game, team);
    let mut priority = priority;
    if aa_up {
        let mut aa_types: Vec<PlatoonType> =
            vec![PlatoonType::AirDefense, PlatoonType::AirDefenseInfantry]
                .into_iter()
                .filter(|p| !priority.contains(p))
                .collect();
        aa_types.append(&mut priority);
        priority = aa_types;
    }
    let mut budget = game.recruit_points.get(&team).copied().unwrap_or(0);
    let max_platoons = cfg.platoon_count.max(2) as usize;
    let mut built = 0usize;
    for ptype in &priority {
        if built >= max_platoons {
            break;
        }
        let cost = blueprint_cost(*ptype);
        if budget < cost {
            continue;
        }
        let (role, units) = blueprint(*ptype);
        let center = random_center(game);
        let mut members: Vec<char> = Vec::new();
        let mut ok = true;
        for (k, passengers) in &units {
            let (label, pos) = match place(game, *k, center) {
                Some(x) => x,
                None => {
                    ok = false;
                    break;
                }
            };
            budget -= k.recruit_cost();
            members.push(label);
            // 预装步兵：部署到载具紧邻格并上车（多乘客逐个装）
            for inf_kind in passengers {
                let inf_pos = {
                    let mut cand: Vec<Hex> = Vec::new();
                    for n in pos.neighbors() {
                        if game.unit_at(n).is_some()
                            || !zone.contains(&hex::offset_from_axial(n).0)
                            || !game.map.contains(n)
                        {
                            continue;
                        }
                        cand.push(n);
                    }
                    if cand.is_empty() {
                        None
                    } else {
                        use rand::Rng;
                        Some(cand[game.rng.gen_range(0..cand.len())])
                    }
                };
                if let Some(ip) = inf_pos {
                    if let Ok(ilabel) = game.deploy_unit(team, *inf_kind, ip) {
                        budget -= inf_kind.recruit_cost();
                        members.push(ilabel);
                        let _ = game.board(pos, ip);
                    }
                }
            }
        }
        if !ok || members.is_empty() {
            break;
        }
        let names: Vec<String> = members
            .iter()
            .map(|l| {
                game.units_of(team)
                    .iter()
                    .find(|u| u.label == *l)
                    .map(|u| u.kind.name().to_string())
                    .unwrap_or_else(|| "?".into())
            })
            .collect();
        plan.platoons.push(PlatoonPlan {
            id: platoon_id,
            role,
            ptype: *ptype,
            members,
            target: center,
            order: PlatoonOrder::Advance,
        });
        platoon_id += 1;
        built += 1;
        log.push(format!(
            "[AI部署] {}（{} 点）：{}",
            ptype_name(*ptype),
            cost,
            names.join("+")
        ));
    }
    // 连直属：剩余点数补防空/反坦克/步兵
    let mut extras: Vec<UnitKind> = Vec::new();
    for k in [
        UnitKind::AaLauncher,
        UnitKind::Rifleman,
        UnitKind::Atgm,
        UnitKind::Javelin,
        UnitKind::Rifleman,
    ] {
        if budget >= k.recruit_cost() {
            extras.push(k);
            budget -= k.recruit_cost();
        }
    }
    for k in &extras {
        let center = random_center(game);
        let _ = place(game, *k, center);
    }
    game.company.insert(team, plan);
    log
}

/// 卸载目标格：优先附近 2 格内的森林/建筑（步兵占位隐蔽），否则任意可进入邻格。
fn company_unload_hex(game: &GameState, u: &Unit) -> Option<Hex> {
    let mut fallback: Option<Hex> = None;
    for n in u.pos.neighbors() {
        if !game.map.contains(n) || game.map.is_blocked(n, &game.units) {
            continue;
        }
        if game.map.obstacles.contains(&n) || game.map.water.contains(&n) {
            continue;
        }
        let foot = u
            .passengers
            .first()
            .map(|p| p.kind.is_foot())
            .unwrap_or(true);
        if game.map.buildings.contains(&n) && !foot {
            continue;
        }
        if game.map.forests.contains(&n) || game.map.buildings.contains(&n) {
            return Some(n); // 优先森林/建筑
        }
        if fallback.is_none() {
            fallback = Some(n);
        }
    }
    fallback
}

/// 敌方当前存在**未被击落**的空中单位（任何位置）→ 防空倾向。
fn enemy_air_present(game: &GameState, team: Team) -> bool {
    game.enemies_of(team).iter().any(|e| e.kind.is_air())
}

/// 己方防空单位数量（防空导弹发射车/M-SHORAD/防空导弹手）。
fn count_aa(game: &GameState, team: Team) -> i32 {
    game.units_of(team)
        .iter()
        .filter(|u| {
            matches!(
                u.kind,
                UnitKind::AaLauncher | UnitKind::AaMgv | UnitKind::AaInfantry
            )
        })
        .count() as i32
}

/// 己方最近有防空单位被击毁（本回合数量 < 上回合末）→ 防空倾向。
fn aa_lost(game: &GameState, team: Team) -> bool {
    match game.aa_count_last.get(&team) {
        Some(prev) => count_aa(game, team) < *prev,
        None => false,
    }
}

/// 防空倾向：场上存在敌方空中单位 **或** 己方防空被击毁 → AI 更倾向出防空单位。
fn aa_trigger(game: &GameState, team: Team) -> bool {
    enemy_air_present(game, team) || aa_lost(game, team)
}

/// AI 步兵登屋顶：防空导弹手 / Javelin 射手 / TOW 射手在**建筑内**且场上存在
/// **可见敌军**（有射击/侦察需求）时，自动登上屋顶——换取更好射击角度：
/// 视野无视森林/楼房遮挡、攻击不受任何 LOS 因素遮挡（代价：失去楼房闪避）。
fn ai_rooftop_opt(game: &mut GameState, team: Team, log: &mut Vec<String>) {
    let has_visible_enemy = game
        .enemies_of(team)
        .iter()
        .any(|e| game.is_unit_visible(team, e.pos));
    if !has_visible_enemy {
        return;
    }
    for h in game.units.keys().copied().collect::<Vec<Hex>>() {
        let Some(u) = game.unit_at(h) else {
            continue;
        };
        if u.team != team || u.rooftop {
            continue;
        }
        if !matches!(
            u.kind,
            UnitKind::AaInfantry | UnitKind::Atgm | UnitKind::Javelin
        ) {
            continue;
        }
        if !game.map.buildings.contains(&h) {
            continue;
        }
        // 登屋顶消耗 1 行动力（与玩家规则一致）；行动不足则不上
        if u.actions_left < 1 {
            continue;
        }
        let mu = game.unit_at_mut(h).unwrap();
        mu.rooftop = true;
        mu.actions_left -= 1;
        log.push(format!(
            "[AI] {} 登上屋顶（更好射击角度，耗 1 行动）",
            mu.name_with_label()
        ));
    }
}

/// 排型中文名（部署日志用）。
fn ptype_name(t: PlatoonType) -> &'static str {
    match t {
        PlatoonType::Cavalry => "装甲骑兵排",
        PlatoonType::Tank => "坦克排",
        PlatoonType::Motorized => "摩托化步兵排",
        PlatoonType::Mechanized => "机械化步兵排",
        PlatoonType::AirDefense => "防空排",
        PlatoonType::AirDefenseInfantry => "防空步兵排",
        PlatoonType::Heli => "直升机排",
        PlatoonType::Artillery => "榴弹炮排",
    }
}



pub fn ai_deploy(game: &mut GameState, team: Team) -> Vec<String> {
    // 连排指挥官框架：按排编组部署
    if game
        .ai_configs
        .get(&team)
        .map(|c| c.style == AiStyle::Company)
        .unwrap_or(false)
    {
        return ai_company_deploy(game, team);
    }
    let mut log = Vec::new();
    let deployed: Vec<(UnitKind, Hex)> = ai_buy_list(game, team, 14)
        .into_iter()
        .map(|k| (k, Hex::ZERO))
        .collect();

    // ③ 放置：出发区域内随机找空位（按关卡区域；战役地图为逐格部署区；
    //    避开岩石；车辆不进楼房；直升机随意）
    for (kind, _) in &deployed {
        let mut candidates: Vec<Hex> = Vec::new();
        for hx in game.deploy_cells(team) {
            if game.unit_at(hx).is_some() {
                continue;
            }
            if !kind.is_air() {
                if game.map.obstacles.contains(&hx) {
                    continue;
                }
                if game.map.buildings.contains(&hx) && !kind.is_foot() {
                    continue;
                }
            }
            candidates.push(hx);
        }
        if candidates.is_empty() {
            continue;
        }
        let pos = {
            use rand::Rng;
            let idx = game.rng.gen_range(0..candidates.len());
            candidates[idx]
        };
        if let Ok(label) = game.deploy_unit(team, *kind, pos) {
            log.push(format!(
                "[AI部署] {} {} → {}",
                label,
                kind.name(),
                hex::hex_label(pos)
            ));
        }
    }
    log
}

// ========== 连排指挥官框架：工具 ==========

/// 排存活成员的平均位置（空排返回 Hex::ZERO）。
fn platoon_center(game: &GameState, team: Team, p: &PlatoonPlan) -> Hex {
    let all = game.units_of(team);
    let alive: Vec<&crate::unit::Unit> = p
        .members
        .iter()
        .filter_map(|l| all.iter().copied().find(|u| u.label == *l))
        .collect();
    if alive.is_empty() {
        return Hex::ZERO;
    }
    let q: i64 = alive.iter().map(|u| u.pos.q as i64).sum();
    let r: i64 = alive.iter().map(|u| u.pos.r as i64).sum();
    Hex::new((q / alive.len() as i64) as i32, (r / alive.len() as i64) as i32)
}

/// 从 `from` 指向 `to` 的近似六边形方向（6 轴向之一）。
fn dir_toward(from: Hex, to: Hex) -> Hex {
    let (dc, dr) = (to.q - from.q, to.r - from.r);
    Hex::ZERO
        .neighbors()
        .iter()
        .max_by_key(|d| d.q * dc + d.r * dr)
        .copied()
        .unwrap_or(Hex::new(1, 0))
}

/// 按标签查本单位（units + air_units 合并）。
fn company_unit_by_label(game: &GameState, team: Team, label: char) -> Option<Unit> {
    game.units_of(team)
        .into_iter()
        .find(|u| u.label == label)
        .cloned()
}

/// 排成员在阵型中的角色。
#[derive(Clone, Copy, PartialEq, Eq)]
enum CompanyRole {
    Recon, // 侦察前出（视野远/高速）
    Armor, // 装甲靠后输出
    Infantry, // 步兵居中接敌
}
/// 从 h 沿方向 d 偏移 n 格。
fn hex_off(h: Hex, d: Hex, n: i32) -> Hex {
    Hex::new(h.q + d.q * n, h.r + d.r * n)
}

fn company_unit_role(k: UnitKind) -> CompanyRole {
    match k {
        UnitKind::Scout | UnitKind::Drone | UnitKind::AttackHeli | UnitKind::TransportHeli => {
            CompanyRole::Recon
        }
        UnitKind::Tank | UnitKind::HeavyTank | UnitKind::Ifv | UnitKind::AaMgv
        | UnitKind::AaLauncher => CompanyRole::Armor,
        _ => CompanyRole::Infantry,
    }
}


