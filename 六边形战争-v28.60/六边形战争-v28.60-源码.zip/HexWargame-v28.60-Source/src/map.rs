//! 六边形地图：地形（障碍）、可达性、移动路径规划与视线（LOS）。

use crate::hex::{self, Hex};
use crate::unit::Unit;
use std::collections::{BTreeMap, BTreeSet, HashSet, VecDeque};

#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GameMap {
    pub cols: i32,
    pub rows: i32,
    pub obstacles: BTreeSet<Hex>,
    /// 森林：进入消耗 2 点行动力（剩余 1 点可向上取整进入最后一格），
    /// 内部的地面单位被命中率降至 80%。
    pub forests: BTreeSet<Hex>,
    /// 楼房：仅步兵可进入，内部步兵被命中率降至 60%。
    pub buildings: BTreeSet<Hex>,
    /// 水域：陆军单位不可进入（卡车也不能卸下单位到水域）；空中单位可进入，
    /// 但运输直升机不能在水域上方卸下步兵；水域不阻挡射击视野。
    pub water: BTreeSet<Hex>,
    /// 道路：车辆进入只消耗 0.5 行动力（非车辆仍为 1）；不阻挡移动/视线，
    /// 可与其它地形叠加（森林仍按 2 计算）。旧存档无该字段时默认空。
    #[serde(default)]
    pub roads: BTreeSet<Hex>,
}

impl GameMap {
    pub fn new(cols: i32, rows: i32) -> Self {
        GameMap {
            cols,
            rows,
            obstacles: BTreeSet::new(),
            forests: BTreeSet::new(),
            buildings: BTreeSet::new(),
            water: BTreeSet::new(),
            roads: BTreeSet::new(),
        }
    }

    /// 以偏移坐标添加一个障碍（岩石）。
    pub fn add_obstacle(&mut self, col: i32, row: i32) {
        self.obstacles.insert(hex::axial_from_offset(col, row));
    }

    /// 以偏移坐标添加一片森林。
    pub fn add_forest(&mut self, col: i32, row: i32) {
        self.forests.insert(hex::axial_from_offset(col, row));
    }

    /// 以偏移坐标添加一栋楼房。
    pub fn add_building(&mut self, col: i32, row: i32) {
        self.buildings.insert(hex::axial_from_offset(col, row));
    }

    /// 以偏移坐标添加一格水域。
    pub fn add_water(&mut self, col: i32, row: i32) {
        self.water.insert(hex::axial_from_offset(col, row));
    }

    /// 以偏移坐标添加一格道路。
    pub fn add_road(&mut self, col: i32, row: i32) {
        self.roads.insert(hex::axial_from_offset(col, row));
    }

    /// 进入 h 格的行动力成本（整数行动点，仅用于兼容/显示）：森林 2，其余 1。
    /// 道路对车辆的 0.5 成本见 move_cost_half。
    pub fn move_cost(&self, h: Hex) -> i32 {
        if self.forests.contains(&h) {
            2
        } else {
            1
        }
    }

    /// 进入 h 格的半行动点成本（2 半 = 1 点行动力）：
    /// - 森林：4（=2 行动力）
    /// - 道路且 mover 为车辆：1（=0.5 行动力）
    /// - 其余：2（=1 行动力）
    pub fn move_cost_half(&self, h: Hex, vehicle: bool) -> i32 {
        if self.forests.contains(&h) {
            4
        } else if vehicle && self.roads.contains(&h) {
            1
        } else {
            2
        }
    }

    /// 单位能否进入 h 格：直升机不受地形限制（可越过岩石/森林/楼房）；
    /// 楼房只有步兵可进入；岩石与单位始终不可通行。
    ///
    /// 该兼容入口不含空中层占用信息（等同空 air_units）。需要精确判断空中
    /// 单位能否通行时请用 can_step_into_ex。
    pub fn can_step_into(
        &self,
        h: Hex,
        units: &BTreeMap<Hex, Unit>,
        mover: Option<&Unit>,
    ) -> bool {
        self.can_step_into_ex(h, units, &BTreeMap::new(), mover)
    }

    /// 与 can_step_into 同义，但额外接收空中层占用 air_units。
    ///
    /// 空中单位的真实通行规则（与 GameState::move_unit 完全一致）：
    /// - 地形不限（可飞越岩石/森林/楼房/水域）；
    /// - 同层不重叠：不能进入已有空中单位的格；
    /// - 可飞越己方地面单位，但不能飞入敌方地面单位所在格
    ///   （否则规划出的路径会被 move_unit 判为"被阻挡"）。
    pub fn can_step_into_ex(
        &self,
        h: Hex,
        units: &BTreeMap<Hex, Unit>,
        air_units: &BTreeMap<Hex, Unit>,
        mover: Option<&Unit>,
    ) -> bool {
        if !self.contains(h) {
            return false;
        }
        if let Some(m) = mover {
            if m.kind.is_air() {
                // 空中层：不能与其它空中单位同格
                if air_units.contains_key(&h) {
                    return false;
                }
                // 可飞越己方地面单位；敌方地面单位所在格不可进入
                if let Some(occ) = units.get(&h) {
                    if occ.team != m.team {
                        return false;
                    }
                }
                return true; // 其余地形对空中单位不限
            }
            if self.water.contains(&h) {
                return false; // 水域：陆军单位不可进入
            }
            if self.buildings.contains(&h) && !m.kind.is_foot() {
                return false; // 楼房：只有步兵（含防空步兵）能进入
            }
        }
        !self.obstacles.contains(&h) && !units.contains_key(&h)
    }

    /// 桥梁识别：返回"桥面格"——河流（水域带）被陆地断开/压缩的**渡河通道**。
    ///
    /// 两种判据：
    /// ① **横向桥**（河床陆地行）：某行无水域、上下行有水域，且上下行水域段的
    ///    投影并集较窄（宽 ≤ 4 格，排除宽阔河床/河岸）→ 该行投影内的陆地格。
    /// ② **斜向桥链**（河流拐弯处的对角陆地通道）：陆地格 6 邻内水域 ≥ 2 个，
    ///    且存在另一个"6 邻水域 ≥ 2"的陆地邻格（成链；孤立的半岛/河岸突出
    ///    无邻链 → 排除）。链即桥面。
    ///
    /// 按 6 邻连通分组即为独立桥梁的座数。用于连排指挥官框架的
    /// 桥梁进攻/防守/增援/火力压制战术。
    pub fn bridge_hexes(&self) -> Vec<Hex> {
        let mut bridges: BTreeSet<Hex> = BTreeSet::new();
        let land = |h: Hex| -> bool {
            self.contains(h) && !self.water.contains(&h) && !self.obstacles.contains(&h)
        };
        let row_water_cols = |r: i32| -> Vec<i32> {
            (0..self.cols)
                .filter(|c| self.water.contains(&hex::axial_from_offset(*c, r)))
                .collect()
        };
        // —— ① 横向桥：无水域行 + 上下行有水域 + 投影并集窄（宽 ≤ 4） ——
        for r in 0..self.rows {
            if !row_water_cols(r).is_empty() {
                continue;
            }
            let up = if r > 0 { row_water_cols(r - 1) } else { Vec::new() };
            let down = if r + 1 < self.rows {
                row_water_cols(r + 1)
            } else {
                Vec::new()
            };
            if up.is_empty() && down.is_empty() {
                continue;
            }
            let mut union: Vec<i32> = up;
            union.extend(down);
            union.sort_unstable();
            union.dedup();
            let (cmin, cmax) = (*union.first().unwrap(), *union.last().unwrap());
            if cmax - cmin <= 4 {
                for c in cmin..=cmax {
                    let h = hex::axial_from_offset(c, r);
                    if land(h) {
                        bridges.insert(h);
                    }
                }
            }
        }
        // —— ② 斜向桥链（河流拐弯处的对角陆地通道） ——
        // 桥面格 = 陆地格被水域**对立两侧**夹住（北+南 或 东+西 邻水，河在此
        // 断开/压缩）；或 L 形贴水但邻接这样的"对立贴水"格（链端）。
        // 河岸凸角（水域在同一侧）与孤立半岛（无对立贴水邻格）被排除。
        let water_at = |h: Hex| -> bool { self.water.contains(&h) };
        let opposite = |h: Hex| -> bool {
            land(h)
                && ((water_at(hex::axial_from_offset(hex::offset_from_axial(h).0, hex::offset_from_axial(h).1 - 1))
                    && water_at(hex::axial_from_offset(hex::offset_from_axial(h).0, hex::offset_from_axial(h).1 + 1)))
                    || (water_at(hex::axial_from_offset(hex::offset_from_axial(h).0 + 1, hex::offset_from_axial(h).1))
                        && water_at(hex::axial_from_offset(hex::offset_from_axial(h).0 - 1, hex::offset_from_axial(h).1))))
        };
        let water_neighbors = |h: Hex| -> usize {
            h.neighbors()
                .iter()
                .filter(|n| self.water.contains(n))
                .count()
        };
        let mut opp_set: BTreeSet<Hex> = BTreeSet::new();
        for c in 0..self.cols {
            for r in 0..self.rows {
                let h = hex::axial_from_offset(c, r);
                if land(h) && opposite(h) && !bridges.contains(&h) {
                    opp_set.insert(h);
                }
            }
        }
        // 成组：对立贴水格必须互为 6 邻（孤立河中陆地/半岛不算桥）
        let mut chain: BTreeSet<Hex> = BTreeSet::new();
        for &h in &opp_set {
            if h.neighbors().iter().any(|n| opp_set.contains(n)) {
                chain.insert(h);
            }
        }
        // 组外扩 1 层：链端（L 形贴水的陆地邻格，如河流拐弯的端点）
        let mut extra: BTreeSet<Hex> = BTreeSet::new();
        for &h in &chain {
            for n in h.neighbors() {
                if land(n) && water_neighbors(n) >= 1 && !chain.contains(&n) {
                    extra.insert(n);
                }
            }
        }
        for h in chain.into_iter().chain(extra) {
            bridges.insert(h);
        }
        bridges.into_iter().collect()
    }

    pub fn contains(&self, h: Hex) -> bool {
        let (c, r) = hex::offset_from_axial(h);
        c >= 0 && c < self.cols && r >= 0 && r < self.rows
    }

    /// 该格是否不可通过：有岩石或站有单位。
    pub fn is_blocked(&self, h: Hex, units: &BTreeMap<Hex, Unit>) -> bool {
        self.obstacles.contains(&h) || units.contains_key(&h)
    }

    /// 两个格子之间是否存在视线：两格中心连线不得穿过任何岩石/楼房/烟雾**内部**。
    /// 仅擦过边或顶点不算阻挡。
    /// 端点所在遮挡格不阻挡（如直升机停在岩石上方时，防空仍可射击；
    /// 攻击者/目标在楼房内、烟雾中也能互相攻击）。
    pub fn has_los(&self, from: Hex, to: Hex) -> bool {
        self.has_los_ex(from, to, &BTreeMap::new())
    }

    /// 带烟雾的视线检查（烟雾与楼房一样：穿过其内部即阻断直射，
    /// 但端点格——攻击者/目标所在格——不阻挡）。
    pub fn has_los_ex(
        &self,
        from: Hex,
        to: Hex,
        smoke: &BTreeMap<Hex, i32>,
    ) -> bool {
        let blockers = self.blocker_set(smoke);
        self.has_los_with_blockers(from, to, &blockers)
    }

    /// 预计算遮挡物集合（岩石+楼房+烟雾）。AI 每回合只需构建一次，
    /// 之后用 has_los_with_blockers 复用，避免逐次分配 HashSet。
    pub fn blocker_set(&self, smoke: &BTreeMap<Hex, i32>) -> HashSet<Hex> {
        self.obstacles
            .iter()
            .copied()
            .chain(self.buildings.iter().copied())
            .chain(smoke.keys().copied())
            .collect()
    }

    /// 使用预计算遮挡物集合的视线检查（语义与 has_los_ex 完全一致）。
    pub fn has_los_with_blockers(
        &self,
        from: Hex,
        to: Hex,
        blockers: &HashSet<Hex>,
    ) -> bool {
        if from == to {
            return true;
        }
        let a = hex_center_xy(from);
        let b = hex_center_xy(to);
        // ① 穿越任意遮挡格**内部** → 禁止
        for o in blockers {
            if *o == from || *o == to {
                continue;
            }
            if segment_crosses_hex_int(a, b, hex_center_xy(*o)) {
                return false;
            }
        }
        // ② 堵住"遮挡缝隙"：线段沿两个**互相接触**的遮挡物（岩石/楼房/烟雾）
        //    公共边穿过（不穿任何一格内部，但被夹在中间）→ 同样禁止开火。
        for o in blockers {
            if *o == from || *o == to {
                continue;
            }
            let oc = hex_center_xy(*o);
            for n in o.neighbors() {
                if !blockers.contains(&n) || n == from || n == to {
                    continue;
                }
                let (e1, e2) = Self::shared_edge_offset(*o, n);
                let p1 = (oc.0 + e1.0, oc.1 + e1.1);
                let p2 = (oc.0 + e2.0, oc.1 + e2.1);
                if segs_intersect(a, b, p1, p2) {
                    return false;
                }
            }
        }
        true
    }

    /// 相邻遮挡格（六边形邻居）之间的公共边端点（相对 o 中心的缩放坐标偏移）。
    /// 方向按轴向邻居 (dq, dr)。
    fn shared_edge_offset(o: Hex, n: Hex) -> (Pt, Pt) {
        let (dq, dr) = (n.q - o.q, n.r - o.r);
        match (dq, dr) {
            (1, 0) => ((1, 1), (1, -1)),
            (0, 1) => ((0, 2), (1, 1)),
            (-1, 1) => ((-1, 1), (0, 2)),
            (-1, 0) => ((-1, 1), (-1, -1)),
            (0, -1) => ((0, -2), (1, -1)),
            (1, -1) => ((1, -1), (0, -2)),
            _ => unreachable!("非相邻格: {:?} -> {:?}", o, n),
        }
    }

    /// 森林对视野的减弱：线段（含两端点所在格）穿过的森林格数，每格使
    /// 有效视野距离 -1。即：站在森林里、看森林里的目标、或视线穿过森林，
    /// 都会削弱侦察距离。
    pub fn forest_penalty(&self, from: Hex, to: Hex) -> i32 {
        if from == to {
            return if self.forests.contains(&from) { 1 } else { 0 };
        }
        let a = hex_center_xy(from);
        let b = hex_center_xy(to);
        self.forests
            .iter()
            .filter(|f| segment_crosses_hex_int(a, b, hex_center_xy(**f)))
            .count() as i32
    }

    /// 危险度：h 格会被多少个"能杀伤 mover"的敌方单位火力覆盖。
    fn danger_at(
        &self,
        units: &BTreeMap<Hex, Unit>,
        air_units: &BTreeMap<Hex, Unit>,
        h: Hex,
        mover: &Unit,
    ) -> f32 {
        let mut d = 0.0;
        for u in units.values().chain(air_units.values()) {
            if u.team == mover.team {
                continue;
            }
            if Hex::distance(u.pos, h) <= u.kind.range() && u.kind.can_damage(mover.kind) {
                d += 1.0;
            }
        }
        d
    }

    /// 从 start 出发、最多 budget 点行动力内能到达的全部格子（不含起点）。
    /// 森林每格消耗 2 点行动力；剩余 1 点时可向上取整进入最后一格（进入后止步）。
    /// `mover = Some(单位)` 时按该单位类型判断楼房限制；直升机不受地形限制。
    pub fn reachable_hexes(
        &self,
        units: &BTreeMap<Hex, Unit>,
        start: Hex,
        budget: i32,
        mover: Option<&Unit>,
    ) -> Vec<Hex> {
        self.reachable_hexes_ex(units, &BTreeMap::new(), start, budget, mover)
    }

    /// 与 reachable_hexes 同义，但额外接收空中层占用 air_units，
    /// 使空中单位的可达范围与 move_unit 的真实规则一致（不被误判为可进入
    /// 已有空中单位/敌方地面单位所在格）。
    pub fn reachable_hexes_ex(
        &self,
        units: &BTreeMap<Hex, Unit>,
        air_units: &BTreeMap<Hex, Unit>,
        start: Hex,
        budget: i32,
        mover: Option<&Unit>,
    ) -> Vec<Hex> {
        let air = mover.map(|m| m.kind.is_air()).unwrap_or(false);
        let vehicle = mover.map(|m| m.kind.is_vehicle()).unwrap_or(false);
        // 行动力以半点为内部单位（2 半 = 1 点），以支持道路 0.5 成本。
        let budget_half = budget.saturating_mul(2);
        // best[h] = 到达 h 时的最大剩余行动力（半点；-1 = 未到达）
        let mut best: BTreeMap<Hex, i32> = BTreeMap::new();
        let mut queue: VecDeque<(Hex, i32)> = VecDeque::new();
        best.insert(start, budget_half);
        queue.push_back((start, budget_half));
        while let Some((h, rem)) = queue.pop_front() {
            if rem <= 0 {
                continue;
            }
            for n in h.neighbors() {
                if !self.can_step_into_ex(n, units, air_units, mover) {
                    continue;
                }
                let cost = if air { 2 } else { self.move_cost_half(n, vehicle) };
                let mut new_rem = rem - cost;
                if new_rem < 0 {
                    // 向上取整：剩任意余量（含 0.5 点）也能进入最后一格（进入后即止步）
                    if rem >= 1 {
                        new_rem = 0;
                    } else {
                        continue;
                    }
                }
                if new_rem > best.get(&n).copied().unwrap_or(-1) {
                    best.insert(n, new_rem);
                    queue.push_back((n, new_rem));
                }
            }
        }
        best.keys().filter(|h| **h != start).copied().collect()
    }

    /// 规划从 start 向 target 的移动，最多消耗 budget 点行动力。
    /// 返回路径，path[0] == start。目标不可达（或行动力不够）时尽可能接近目标。
    ///
    /// `avoid_threats = true`（AI 使用）时，在同样接近目标的前提下
    /// 会优先选择更安全的路线（避开敌方火力覆盖）。
    pub fn plan_move(
        &self,
        units: &BTreeMap<Hex, Unit>,
        air_units: &BTreeMap<Hex, Unit>,
        start: Hex,
        target: Hex,
        budget: i32,
        mover: Option<Unit>,
        avoid_threats: bool,
    ) -> Vec<Hex> {
        let air = mover.as_ref().map(|m| m.kind.is_air()).unwrap_or(false);
        let vehicle = mover.as_ref().map(|m| m.kind.is_vehicle()).unwrap_or(false);
        // 行动力以半点为内部单位（2 半 = 1 点），以支持道路 0.5 成本。
        let budget_half = budget.saturating_mul(2);
        // best[h] = 到达 h 时的最大剩余行动力（半点；-1 = 未到达）
        let mut best: BTreeMap<Hex, i32> = BTreeMap::new();
        let mut prev: BTreeMap<Hex, Hex> = BTreeMap::new();
        let mut danger: BTreeMap<Hex, f32> = BTreeMap::new();
        let mut queue: VecDeque<Hex> = VecDeque::new();
        best.insert(start, budget_half);
        danger.insert(start, 0.0);
        queue.push_back(start);
        while let Some(h) = queue.pop_front() {
            let rem = best[&h];
            if rem <= 0 {
                continue;
            }
            for n in h.neighbors() {
                if !self.can_step_into_ex(n, units, air_units, mover.as_ref()) {
                    continue;
                }
                let cost = if air { 2 } else { self.move_cost_half(n, vehicle) };
                let mut new_rem = rem - cost;
                if new_rem < 0 {
                    if rem >= 1 {
                        new_rem = 0;
                    } else {
                        continue;
                    }
                }
                if new_rem <= best.get(&n).copied().unwrap_or(-1) {
                    continue;
                }
                let extra = if avoid_threats {
                    mover
                        .as_ref()
                        .map(|m| self.danger_at(units, air_units, n, m))
                        .unwrap_or(0.0)
                } else {
                    0.0
                };
                best.insert(n, new_rem);
                prev.insert(n, h);
                danger.insert(n, danger[&h] + extra);
                queue.push_back(n);
            }
        }

        // 最优终点：优先离目标更近（权重 100 主导），其次路径总危险度更小，
        // 再次剩余行动力更多（便于移动后攻击）。
        let mut best_end = start;
        let mut best_score = f32::INFINITY;
        for (h, rem) in &best {
            let score = Hex::distance(*h, target) as f32 * 100.0
                + danger[h]
                - (*rem as f32) * 0.5;
            if score < best_score {
                best_score = score;
                best_end = *h;
            }
        }

        // 重建路径
        let mut path = vec![best_end];
        while let Some(&p) = prev.get(path.last().unwrap()) {
            path.push(p);
        }
        path.reverse();
        path
    }
}

// ---------------------------------------------------------------------------
// 视线（Line of Sight）几何计算（精确整数算术）
// ---------------------------------------------------------------------------
//
// 采用缩放坐标系：点用 (√3·X, Y) 表示，X、Y 均为整数（真实坐标的 2 倍）。
// 六边形中心与顶点都落在这个整数格点上，叉积 = √3·(整数)，符号完全精确，
// 因此"恰好擦过边/顶点"的切线情形可以零误差判定。

type Pt = (i64, i64);

/// 六边形中心（缩放坐标）。
fn hex_center_xy(h: Hex) -> Pt {
    let (col, row) = hex::offset_from_axial(h);
    (2 * col as i64 + (row % 2) as i64, 3 * row as i64)
}

/// 顶点相对中心的偏移（缩放坐标）：(2cosθ, 2sinθ)，θ = 30°,90°,...,330°。
const VERTEX_OFFSETS: [Pt; 6] = [(1, 1), (0, 2), (-1, 1), (-1, -1), (0, -2), (1, -1)];

/// 叉积（√3·整数，符号即真实叉积符号）。
fn cross_int(u: Pt, v: Pt) -> i64 {
    u.0 * v.1 - u.1 * v.0
}

/// 有理数 t（分母 > 0），用于线段参数区间。
type Frac = (i64, i64);

fn frac_less(a: Frac, b: Frac) -> bool {
    a.0 * b.1 < b.0 * a.1
}

/// 线段 p1-p2 与 q1-q2 是否相交（含共线重叠；坐标均为缩放坐标整数）。
fn segs_intersect(p1: Pt, p2: Pt, q1: Pt, q2: Pt) -> bool {
    let d1 = (p2.0 - p1.0, p2.1 - p1.1);
    let d2 = (q2.0 - q1.0, q2.1 - q1.1);
    let r = cross_int(d1, d2);
    let qp = (q1.0 - p1.0, q1.1 - p1.1);
    if r != 0 {
        // 不平行：t = cross(qp,d2)/r, u = cross(qp,d1)/r，均需在 [0,1]
        let t_num = cross_int(qp, d2);
        let u_num = cross_int(qp, d1);
        let in_unit = |num: i64, den: i64| -> bool {
            if den > 0 {
                num >= 0 && num <= den
            } else {
                num <= 0 && num >= den
            }
        };
        in_unit(t_num, r) && in_unit(u_num, r)
    } else {
        // 平行：不共线则不相交
        if cross_int(qp, d1) != 0 {
            return false;
        }
        // 共线：x 与 y 区间均重叠即线段重叠
        let x_overlap = p1.0.min(p2.0) <= q1.0.max(q2.0) && q1.0.min(q2.0) <= p1.0.max(p2.0);
        let y_overlap = p1.1.min(p2.1) <= q1.1.max(q2.1) && q1.1.min(q2.1) <= p1.1.max(p2.1);
        x_overlap && y_overlap
    }
}

/// 线段 a→b 是否穿过以 c 为中心的六边形**内部**。
/// 仅擦过六边形的边或顶点（切线情形）不算穿过。
///
/// 原理：六边形内部是 6 条有向边内侧（cross > 0）的交集；
/// 对线段 P(t) = a + t·d（t∈[0,1]），每条边给出一个关于 t 的线性约束，
/// 求满足全部约束的 t 区间。区间长度 > 0（存在线段内部的点在六边形内部）
/// 才算穿过；区间退化为单点（恰好擦边/擦顶点）则不阻挡。
fn segment_crosses_hex_int(a: Pt, b: Pt, c: Pt) -> bool {
    let d = (b.0 - a.0, b.1 - a.1);
    let mut t_lo: Frac = (0, 1);
    let mut t_hi: Frac = (1, 1);
    for i in 0..6 {
        let v1 = (c.0 + VERTEX_OFFSETS[i].0, c.1 + VERTEX_OFFSETS[i].1);
        let v2 = (c.0 + VERTEX_OFFSETS[(i + 1) % 6].0, c.1 + VERTEX_OFFSETS[(i + 1) % 6].1);
        let e = (v2.0 - v1.0, v2.1 - v1.1);
        let c0 = cross_int(e, (a.0 - v1.0, a.1 - v1.1)); // t=0 时的有向距离
        let c1 = cross_int(e, d);                       // 沿线段方向的变化率
        if c1 > 0 {
            // 约束 t > -c0/c1
            let bound = (-c0, c1);
            if frac_less(t_lo, bound) {
                t_lo = bound;
            }
        } else if c1 < 0 {
            // 约束 t < -c0/c1 = c0/(-c1)
            let bound = (c0, -c1);
            if frac_less(bound, t_hi) {
                t_hi = bound;
            }
        } else if c0 <= 0 {
            // 与边平行且不在内侧（含共线擦边）：不可能穿过
            return false;
        }
        if !frac_less(t_lo, t_hi) {
            return false;
        }
    }
    frac_less(t_lo, t_hi)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::unit::{Team, UnitKind};

    /// 桥头堡之战地图：应识别出 **3 座桥**（用户标注 s4-u4 / u13-w13 / s22-u25），
    /// 真包含标注格（每座多 ≤1 格），且不得有第 4 座桥。
    #[test]
    fn test_bridge_hexes_bridgehead_map() {
        let cm = crate::mapdef::CustomMap::load(std::path::Path::new("maps/桥头堡之战.json"))
            .expect("加载桥头堡之战");
        let mut m = GameMap::new(cm.cols, cm.rows);
        for (c, r) in &cm.water {
            m.add_water(*c, *r);
        }
        for (c, r) in &cm.forests {
            m.add_forest(*c, *r);
        }
        for (c, r) in &cm.buildings {
            m.add_building(*c, *r);
        }
        let b = m.bridge_hexes();
        let bset: BTreeSet<Hex> = b.iter().copied().collect();
        // 真包含用户标注的三座桥
        for (c, r) in [
            (18, 3), // 桥1 s4
            (19, 3),
            (20, 3), // 桥1 u4
            (20, 12), // 桥2 u13
            (21, 12),
            (22, 12), // 桥2 w13
            (18, 21), // 桥3 s22
            (19, 22), // 桥3 t23
            (19, 23),
            (20, 24), // 桥3 u25
        ] {
            assert!(
                bset.contains(&hex::axial_from_offset(c, r)),
                "桥面格 ({},{}) 应被识别",
                c,
                r
            );
        }
        // 分组计数 = 3 座桥
        let mut groups = 0usize;
        let mut seen: BTreeSet<Hex> = BTreeSet::new();
        for &h in &bset {
            if seen.contains(&h) {
                continue;
            }
            groups += 1;
            let mut q: VecDeque<Hex> = VecDeque::new();
            seen.insert(h);
            q.push_back(h);
            while let Some(x) = q.pop_front() {
                for n in x.neighbors() {
                    if bset.contains(&n) && !seen.contains(&n) {
                        seen.insert(n);
                        q.push_back(n);
                    }
                }
            }
        }
        assert_eq!(groups, 3, "桥头堡之战应有 3 座桥，实际 {}", groups);
    }

    /// 桥梁识别：无水域地图无桥；纵向水域带留桥面 → 桥面与两岸桥头被识别，
    /// 不与水域相邻的内陆格不被识别。
    #[test]
    fn test_bridge_hexes_identification() {
        let m = GameMap::new(20, 10);
        assert!(m.bridge_hexes().is_empty(), "无水域地图无桥");
        // 简单桥：col 8..12 的 row 4/6 水域（row 5 留作桥面）
        let mut m2 = GameMap::new(20, 10);
        for c in 8..12 {
            for r in 0..10 {
                if r != 5 {
                    m2.add_water(c, r);
                }
            }
        }
        let b = m2.bridge_hexes();
        assert!(b.contains(&hex::axial_from_offset(8, 5)), "桥面西端应识别");
        assert!(b.contains(&hex::axial_from_offset(11, 5)), "桥面东端应识别");
        assert!(
            !b.contains(&hex::axial_from_offset(7, 4)),
            "河岸格（仅一侧邻水域）不算桥面"
        );
        assert!(
            !b.contains(&hex::axial_from_offset(3, 3)),
            "不与水域相邻的内陆格不识别"
        );
        // 桥面连通：从西岸陆地可达桥面东端
        let mut land: BTreeSet<Hex> = BTreeSet::new();
        for c in 0..20 {
            for r in 0..10 {
                let h = hex::axial_from_offset(c, r);
                if !m2.water.contains(&h) {
                    land.insert(h);
                }
            }
        }
        assert!(land.contains(&hex::axial_from_offset(11, 5)), "桥面应连通");
    }

    #[test]
    fn test_segs_intersect_cases() {
        // 相交
        assert!(segs_intersect((0, 0), (4, 4), (0, 4), (4, 0)));
        // 共线重叠（缝隙场景核心）
        assert!(segs_intersect((0, 2), (0, 8), (0, 4), (0, 6)));
        // 共线但不相接
        assert!(!segs_intersect((0, 2), (0, 4), (0, 6), (0, 8)));
        // 平行不共线
        assert!(!segs_intersect((0, 0), (2, 0), (0, 1), (2, 1)));
        // 只接触端点
        assert!(segs_intersect((0, 0), (2, 2), (2, 2), (4, 4)));
    }

    #[test]
    fn test_los_blocked_by_adjacent_building_gap() {
        // 两栋相邻楼房 (3,3)/(4,3)：从 (4,2) 到 (4,4) 的连线恰好沿两楼
        // 公共边（建筑缝隙）穿过——不穿任何一栋内部，但被两楼夹住 → 禁止。
        let mut map = GameMap::new(20, 10);
        map.add_building(3, 3);
        map.add_building(4, 3);
        let from = hex::axial_from_offset(4, 2);
        let to = hex::axial_from_offset(4, 4);
        assert!(
            !map.has_los(from, to),
            "沿两相邻楼房公共边的连线应被禁止（堵缝隙）"
        );
        // 单栋楼房：沿其一边擦过仍不阻挡（原规则保留）
        let mut map2 = GameMap::new(20, 10);
        map2.add_building(4, 3);
        assert!(
            map2.has_los(from, to),
            "单栋楼房擦边不应阻挡"
        );
    }

    #[test]
    fn test_gap_blocked_for_rock_and_smoke() {
        // 岩石缝隙：两相邻岩石 (3,3)/(4,3)，(4,2)→(4,4) 沿公共边 → 禁止
        let mut m1 = GameMap::new(20, 10);
        m1.add_obstacle(3, 3);
        m1.add_obstacle(4, 3);
        assert!(!m1.has_los(from_gap(), to_gap()), "岩石缝隙应禁止");

        // 烟雾缝隙：两相邻烟雾格，(4,2)→(4,4) 沿公共边 → 禁止
        let m2 = GameMap::new(20, 10);
        let mut smoke: BTreeMap<Hex, i32> = BTreeMap::new();
        smoke.insert(hex::axial_from_offset(3, 3), 2);
        smoke.insert(hex::axial_from_offset(4, 3), 2);
        assert!(
            !m2.has_los_ex(from_gap(), to_gap(), &smoke),
            "烟雾缝隙应禁止"
        );

        // 跨类型缝隙：岩石 (3,3) + 楼房 (4,3) 相邻 → 同样禁止
        let mut m3 = GameMap::new(20, 10);
        m3.add_obstacle(3, 3);
        m3.add_building(4, 3);
        assert!(!m3.has_los(from_gap(), to_gap()), "岩石+楼房缝隙应禁止");

        // 对照：单格岩石擦边不挡（原规则）
        let mut m4 = GameMap::new(20, 10);
        m4.add_obstacle(4, 3);
        assert!(m4.has_los(from_gap(), to_gap()), "单格岩石擦边不应阻挡");
    }

    fn from_gap() -> hex::Hex {
        hex::axial_from_offset(4, 2)
    }

    fn to_gap() -> hex::Hex {
        hex::axial_from_offset(4, 4)
    }

    #[test]
    fn test_segment_crosses_hex_cases() {
        let c = (0i64, 0i64);
        // 缩放坐标 = 真实坐标 ×2；原点六边形顶点: (1,1),(0,2),(-1,1),(-1,-1),(0,-2),(1,-1)
        // 穿过中心 → 阻挡
        assert!(segment_crosses_hex_int((-2, 0), (2, 0), c));
        // 穿过上部两个顶点（Y=1 水平线，经过内部）→ 阻挡
        assert!(segment_crosses_hex_int((-2, 1), (2, 1), c));
        // 与边 (1,1)-(0,2) 共线：沿边擦过 → 不阻挡
        assert!(!segment_crosses_hex_int((0, 2), (2, 0), c));
        // 与底边 (1,-1)-(0,-2) 共线：沿边擦过 → 不阻挡
        assert!(!segment_crosses_hex_int((0, -2), (2, 0), c));
        // 只擦过顶点 (1,1)（从该点水平向右离开）→ 不阻挡
        assert!(!segment_crosses_hex_int((1, 1), (3, 1), c));
        // 穿过顶点 (1,1) 并进入内部 → 阻挡
        assert!(segment_crosses_hex_int((2, 2), (0, 0), c));
        // 水平线 Y=2 只碰到顶部顶点 (0,2) → 不阻挡
        assert!(!segment_crosses_hex_int((-2, 2), (2, 2), c));
        // 完全在外部 → 不阻挡
        assert!(!segment_crosses_hex_int((5, 5), (6, 6), c));
    }

    #[test]
    fn test_los_on_map() {
        // 岩石 (3,4)：缩放坐标中心 (6,12)
        let mut map = GameMap::new(15, 9);
        map.add_obstacle(3, 4);
        // 同一行，连线穿过岩石中心 → 阻挡
        assert!(!map.has_los(
            hex::axial_from_offset(1, 4),
            hex::axial_from_offset(5, 4)
        ));
        // 同一行但岩石不在这两点之间 → 畅通
        assert!(map.has_los(
            hex::axial_from_offset(1, 4),
            hex::axial_from_offset(2, 4)
        ));
        // 连线恰好擦过岩石的边（与 (3,4) 的底边共线）→ 擦边不阻挡，畅通
        assert!(map.has_los(
            hex::axial_from_offset(2, 4),
            hex::axial_from_offset(3, 3)
        ));
        // 从 (1,2) 到 (5,6) 的连线恰好穿过 (3,4) 的中心 → 阻挡
        assert!(!map.has_los(
            hex::axial_from_offset(1, 2),
            hex::axial_from_offset(5, 6)
        ));
        // 在岩石上方一行（y=4.5，岩石中心 y=6，距离 1.5 > 内切半径 0.866）→ 畅通
        assert!(map.has_los(
            hex::axial_from_offset(1, 3),
            hex::axial_from_offset(5, 3)
        ));
        // 斜线绕开岩石（距中心 > 0.866）→ 畅通
        assert!(map.has_los(
            hex::axial_from_offset(1, 4),
            hex::axial_from_offset(5, 2)
        ));

        // 连续岩石完全挡死一条直线
        let mut wall = GameMap::new(15, 9);
        wall.add_obstacle(4, 4);
        wall.add_obstacle(5, 4);
        wall.add_obstacle(6, 4);
        assert!(!wall.has_los(
            hex::axial_from_offset(2, 4),
            hex::axial_from_offset(8, 4)
        ));
        // 岩石在线路之外（上下各一块），视线从中间穿过 → 畅通
        let mut gap = GameMap::new(15, 9);
        gap.add_obstacle(3, 3); // 线上方（y=4.5，距 y=6 的直线 1.5 > 内切半径 0.866）
        gap.add_obstacle(5, 5); // 线下方（y=7.5）
        assert!(gap.has_los(
            hex::axial_from_offset(2, 4),
            hex::axial_from_offset(8, 4)
        ));
        // 相邻格永远畅通
        let mut adj = GameMap::new(15, 9);
        adj.add_obstacle(3, 4);
        assert!(adj.has_los(
            hex::axial_from_offset(2, 4),
            hex::axial_from_offset(2, 3)
        ));
    }

    #[test]
    fn test_forest_move_cost() {
        let mut map = GameMap::new(15, 9);
        for (c, r) in [(2, 3), (3, 3), (4, 3)] {
            map.add_forest(c, r);
        }
        let units: BTreeMap<Hex, Unit> = BTreeMap::new();
        let start = hex::axial_from_offset(1, 3);
        // 2 点行动力：只能进 1 格森林
        let r2 = map.reachable_hexes(&units, start, 2, None);
        assert!(r2.contains(&hex::axial_from_offset(2, 3)));
        assert!(!r2.contains(&hex::axial_from_offset(3, 3)));
        // 3 点行动力（向上取整）：可走 2 格森林
        let r3 = map.reachable_hexes(&units, start, 3, None);
        assert!(r3.contains(&hex::axial_from_offset(2, 3)));
        assert!(r3.contains(&hex::axial_from_offset(3, 3)));
        assert!(!r3.contains(&hex::axial_from_offset(4, 3)));
        // 4 点行动力：沿森林直行仍最多 2 格（第 3 格需绕平地，
        // 最后一格森林可向上取整进入，此处不再断言直行限制）
        // 5 点行动力：可走 3 格森林
        let r5 = map.reachable_hexes(&units, start, 5, None);
        assert!(r5.contains(&hex::axial_from_offset(4, 3)));
        // 普通地形不受影响：1 点行动力/格
        assert!(r3.contains(&hex::axial_from_offset(1, 4)));
        assert!(r3.contains(&hex::axial_from_offset(1, 2)));
    }

    #[test]
    fn test_road_vehicle_half_cost() {
        let mut map = GameMap::new(20, 6);
        // 一条水平道路 row 2, col 1..=8
        for c in 1..=8 {
            map.add_road(c, 2);
        }
        let start = hex::axial_from_offset(0, 2);
        let units: BTreeMap<Hex, Unit> = BTreeMap::new();
        // 车辆：行动力 3 → 沿道路可走 6 格（每格 0.5）
        let tank = Unit::new(UnitKind::Tank, Team::Player, start);
        let reach = map.reachable_hexes(&units, start, tank.kind.movement(), Some(&tank));
        assert!(reach.contains(&hex::axial_from_offset(6, 2)), "车辆沿道路可走 6 格");
        assert!(!reach.contains(&hex::axial_from_offset(7, 2)), "车辆沿道路最多 6 格");
        // 半行动点成本
        assert_eq!(map.move_cost_half(hex::axial_from_offset(1, 2), true), 1);
        assert_eq!(map.move_cost_half(hex::axial_from_offset(1, 2), false), 2);
        assert_eq!(map.move_cost_half(hex::axial_from_offset(1, 3), true), 2);
        // 非车辆（步枪手行动力 1）在道路上仍只走 1 格
        let inf = Unit::new(UnitKind::Rifleman, Team::Player, start);
        let r2 = map.reachable_hexes(&units, start, inf.kind.movement(), Some(&inf));
        assert!(r2.contains(&hex::axial_from_offset(1, 2)));
        assert!(!r2.contains(&hex::axial_from_offset(2, 2)), "步兵道路仍 1 格/行动力");
        // 森林成本仍为 2（半行动点 4），车辆道路叠加森林也不打折
        let mut m2 = GameMap::new(20, 6);
        m2.add_road(2, 2);
        m2.add_forest(2, 2);
        assert_eq!(m2.move_cost_half(hex::axial_from_offset(2, 2), true), 4);
    }

    #[test]
    fn test_building_infantry_only() {
        let mut map = GameMap::new(15, 9);
        map.add_building(3, 3);
        let units: BTreeMap<Hex, Unit> = BTreeMap::new();
        let start = hex::axial_from_offset(2, 3);
        // 坦克（车辆）不能进入楼房
        let tank = Unit::new(UnitKind::Tank, Team::Player, start);
        let r = map.reachable_hexes(&units, start, 3, Some(&tank));
        assert!(!r.contains(&hex::axial_from_offset(3, 3)));
        // 步枪兵（步兵）可以进入楼房
        let inf = Unit::new(UnitKind::Rifleman, Team::Player, start);
        let r2 = map.reachable_hexes(&units, start, 3, Some(&inf));
        assert!(r2.contains(&hex::axial_from_offset(3, 3)));
        // 防空步兵也算步兵，可进入楼房
        let aa = Unit::new(UnitKind::AaInfantry, Team::Player, start);
        let r3 = map.reachable_hexes(&units, start, 3, Some(&aa));
        assert!(r3.contains(&hex::axial_from_offset(3, 3)));
        // 直升机不受楼房限制
        let heli = Unit::new(UnitKind::AttackHeli, Team::Player, start);
        let r4 = map.reachable_hexes(&units, start, 8, Some(&heli));
        assert!(r4.contains(&hex::axial_from_offset(3, 3)));
        // 森林 + 楼房组合：车辆不能进楼房但可进森林
        map.add_forest(2, 4);
        let r5 = map.reachable_hexes(&units, start, 3, Some(&tank));
        assert!(r5.contains(&hex::axial_from_offset(2, 4)));
    }

    /// 空中单位规划路径必须避开：已有空中单位所在格、敌方地面单位所在格；
    /// 但可以飞越己方地面单位。否则 move_unit 会把这些格判为"被阻挡"，
    /// 即使行动力足够绕行。
    #[test]
    fn test_air_path_avoids_occupied_hexes() {
        let map = GameMap::new(15, 9);
        let start = hex::axial_from_offset(0, 4);
        let heli = Unit::new(UnitKind::TransportHeli, Team::Player, start);
        let mut air: BTreeMap<Hex, Unit> = BTreeMap::new();
        air.insert(start, heli.clone());

        // 正东 (1,4) 有一架己方空中单位：路径不得穿过它
        let air_blk = hex::axial_from_offset(1, 4);
        air.insert(air_blk, Unit::new(UnitKind::AttackHeli, Team::Player, air_blk));
        let target = hex::axial_from_offset(3, 4);
        let path = map.plan_move(&BTreeMap::new(), &air, start, target, 8, Some(heli.clone()), false);
        assert!(
            !path.contains(&air_blk),
            "空中路径不应穿过已有空中单位所在格：{:?}",
            path
        );

        // 敌方地面单位所在格同样不可飞入
        let empty_air = BTreeMap::new();
        let mut units: BTreeMap<Hex, Unit> = BTreeMap::new();
        let enemy_hex = hex::axial_from_offset(1, 4);
        units.insert(enemy_hex, Unit::new(UnitKind::Rifleman, Team::Ai, enemy_hex));
        let path2 = map.plan_move(&units, &empty_air, start, target, 8, Some(heli.clone()), false);
        assert!(
            !path2.contains(&enemy_hex),
            "空中路径不应飞入敌方地面单位所在格：{:?}",
            path2
        );

        // 己方地面单位可以飞越
        let mut units3: BTreeMap<Hex, Unit> = BTreeMap::new();
        let friend_hex = hex::axial_from_offset(1, 4);
        units3.insert(friend_hex, Unit::new(UnitKind::Rifleman, Team::Player, friend_hex));
        let path3 = map.plan_move(&units3, &empty_air, start, target, 8, Some(heli), false);
        assert!(
            path3.contains(&friend_hex),
            "空中路径应可飞越己方地面单位：{:?}",
            path3
        );
    }
}
