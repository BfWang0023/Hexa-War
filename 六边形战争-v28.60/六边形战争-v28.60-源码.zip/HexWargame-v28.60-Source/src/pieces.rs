//! 俯视风格棋子绘制：士兵班组 / 装甲车辆 / 直升机 / 无人机。
//!
//! 美术实现按兵种拆分在项目根 `assets/` 目录（每种棋子一个文件），本模块用
//! 标准模块机制（`#[path] mod`，编译期静态加载）把它们挂进编译单元，并负责：
//!
//! 1. 声明 `assets/` 下的美术模块（见下方 `#[path]` 列表）；
//! 2. 原样再导出旧版 `pieces::` 公开 API，界面代码（main.rs / fx.rs）无需改动；
//! 3. 把调用按兵种分发到对应美术模块（`draw_unit_body` 及各类别入口）。
//!
//! `assets/` 目录约定（详见 assets/README.md）：
//! - `common.rs`   绘制基础件：画笔 `Px`、坐标变换、阵营配色 `Palette`；
//! - `infantry.rs` 步兵共用件：单兵 / 班组队列 / 武器小组 / 类型小图标；
//! - `parts.rs`    载具与飞行器共用部件：履带、负重轮、炮管、旋翼；
//! - `<兵种>.rs`   各兵种美术（如 `tank.rs` = M60、`attack_heli.rs` = AH-64）；
//! - `render_golden.rs` 渲染回归基准测试（保证改动前后画面可对照）。
//!
//! 风格目标（参考俯视步兵与俯视坦克示意图）：
//! - 笔画简单而清晰：扁平填色 + 少量深色描边，一眼可辨兵种；
//! - 车辆 = 车身与炮塔分层绘制（车身随移动路径转向，炮塔随最后一次开火转向）；
//! - 步兵 = 班组队列：4 人菱形小组，人数 = HP×4（步枪手/精锐 3 组、特战 2 组、
//!   其余 2 人）；每组背负火箭筒（特战一组 2 具 + 一组 1 具 1 毒刺），发射 1 弹
//!   消失 1 具，损 HP 整组消失、未发射的筒具转移到幸存小组；
//! - 形象参考 2026 美军现役装备（M1A2、布莱德利、M551、M-SHORAD、AH-64、UH-60、
//!   CH-47、复仇者、M777A2、M1129 等）。
//!
//! 所有“局部坐标”均以 +x 为前方（屏幕向右），由调用方传入朝向角统一旋转；
//! 长度单位为“基准像素”（s=1），绘制时统一乘 `Px.s`。

use eframe::egui::{Align2, Color32, Pos2, Stroke};
use crate::unit::{Unit, UnitKind};

// ---------- assets/ 美术模块（每种棋子一个文件） ----------

#[path = "../assets/common.rs"]
pub mod common;
#[path = "../assets/infantry.rs"]
pub mod infantry;
#[path = "../assets/parts.rs"]
pub mod parts;

#[path = "../assets/rifleman.rs"]
pub mod rifleman;
#[path = "../assets/special_forces.rs"]
pub mod special_forces;
#[path = "../assets/elite_infantry.rs"]
pub mod elite_infantry;
#[path = "../assets/atgm.rs"]
pub mod atgm;
#[path = "../assets/javelin.rs"]
pub mod javelin;
#[path = "../assets/aa_infantry.rs"]
pub mod aa_infantry;
#[path = "../assets/hmg_gunner.rs"]
pub mod hmg_gunner;
#[path = "../assets/headquarters.rs"]
pub mod headquarters;
#[path = "../assets/tank.rs"]
pub mod tank;
#[path = "../assets/heavy_tank.rs"]
pub mod heavy_tank;
#[path = "../assets/ifv.rs"]
pub mod ifv;
#[path = "../assets/cavalry_ifv.rs"]
pub mod cavalry_ifv;
#[path = "../assets/scout.rs"]
pub mod scout;
#[path = "../assets/truck.rs"]
pub mod truck;
#[path = "../assets/howitzer.rs"]
pub mod howitzer;
#[path = "../assets/mortar.rs"]
pub mod mortar;
#[path = "../assets/aa_mgv.rs"]
pub mod aa_mgv;
#[path = "../assets/humvee.rs"]
pub mod humvee;
#[path = "../assets/aa_launcher.rs"]
pub mod aa_launcher;
#[path = "../assets/attack_heli.rs"]
pub mod attack_heli;
#[path = "../assets/transport_heli.rs"]
pub mod transport_heli;
#[path = "../assets/heavy_transport_heli.rs"]
pub mod heavy_transport_heli;
#[path = "../assets/drone.rs"]
pub mod drone;

#[cfg(test)]
#[path = "../assets/render_golden.rs"]
mod render_golden_tests;

// ---------- 公开 API（与拆分前一致，供 main.rs / fx.rs 使用） ----------

// 保留拆分前的全部 pieces:: 公开 API。部分常量/类型在本二进制 crate 内
// 不再被直接引用（由 assets/ 各模块自行使用），故显式允许未使用告警。
#[allow(unused_imports)]
pub use self::common::{
    angle_between, palette, xform, Palette, Px, OLIVE, OLIVE_DARK, STAR_WHITE, WRECK,
};
#[allow(unused_imports)]
pub use self::headquarters::draw as draw_hq;
#[allow(unused_imports)]
pub use self::infantry::{draw_soldier, draw_squad, soldier_slots, soldiers_alive, BackWeapon};

/// 装甲车辆（俯视，车身 + 炮塔分层）：按兵种分发到 assets/ 下对应模块。
pub fn draw_vehicle(px: &Px, c: Pos2, u: &Unit, hull: f32, turret: f32, dim: bool) {
    match u.kind {
        UnitKind::Tank => tank::draw(px, c, u, hull, turret, dim),
        UnitKind::HeavyTank => heavy_tank::draw(px, c, u, hull, turret, dim),
        UnitKind::Ifv => ifv::draw(px, c, u, hull, turret, dim),
        UnitKind::CavalryIfv => cavalry_ifv::draw(px, c, u, hull, turret, dim),
        UnitKind::Scout => scout::draw(px, c, u, hull, turret, dim),
        UnitKind::AaMgv => aa_mgv::draw(px, c, u, hull, turret, dim),
        UnitKind::AaLauncher => aa_launcher::draw(px, c, u, hull, turret, dim),
        UnitKind::HumveeHmg => humvee::draw_hmg(px, c, u, hull, turret, dim),
        UnitKind::HumveeTow => humvee::draw_tow(px, c, u, hull, turret, dim),
        UnitKind::HumveeJavelin => humvee::draw_javelin(px, c, u, hull, turret, dim),
        UnitKind::Truck => truck::draw(px, c, u, hull, turret, dim),
        UnitKind::Howitzer => howitzer::draw(px, c, u, hull, turret, dim),
        UnitKind::Mortar => mortar::draw(px, c, u, hull, turret, dim),
        _ => {}
    }
}

/// 直升机 / 无人机（俯视）：按兵种分发到 assets/ 下对应模块。
pub fn draw_air(px: &Px, c: Pos2, u: &Unit, facing: f32, time: f64, dim: bool) {
    match u.kind {
        UnitKind::AttackHeli => attack_heli::draw(px, c, u, facing, time, dim),
        UnitKind::TransportHeli => transport_heli::draw(px, c, u, facing, time, dim),
        UnitKind::HeavyTransportHeli => heavy_transport_heli::draw(px, c, u, facing, time, dim),
        UnitKind::Drone => drone::draw(px, c, u, facing, time, dim),
        _ => {}
    }
}

/// 2 人武器小组：TOW / Javelin / 防空导弹手 / 重机枪手，按兵种分发。
pub fn draw_weapon_team(px: &Px, c: Pos2, u: &Unit, facing: f32, dim: bool, firing: bool) {
    match u.kind {
        UnitKind::Atgm => atgm::draw(px, c, u, facing, dim, firing),
        UnitKind::Javelin => javelin::draw(px, c, u, facing, dim, firing),
        UnitKind::AaInfantry => aa_infantry::draw(px, c, u, facing, dim, firing),
        _ => hmg_gunner::draw(px, c, u, facing, dim, firing),
    }
}

/// 补给：木质补给箱（俯视，无朝向），带加固条、阵营色带与补给符号。
fn draw_supply(px: &Px, c: Pos2, u: &Unit, dim: bool) {
    let pal = palette(u.team, dim);
    let s = px.s;
    // 箱体
    px.poly(
        vec![
            Pos2::new(c.x - 11.0 * s, c.y - 8.5 * s),
            Pos2::new(c.x + 11.0 * s, c.y - 8.5 * s),
            Pos2::new(c.x + 11.0 * s, c.y + 8.5 * s),
            Pos2::new(c.x - 11.0 * s, c.y + 8.5 * s),
        ],
        Color32::from_rgb(126, 96, 58),
        Stroke::new(1.4, Color32::from_rgb(62, 44, 24)),
    );
    // 顶面高光
    px.poly(
        vec![
            Pos2::new(c.x - 8.0 * s, c.y - 6.0 * s),
            Pos2::new(c.x + 8.0 * s, c.y - 6.0 * s),
            Pos2::new(c.x + 8.0 * s, c.y - 1.5 * s),
            Pos2::new(c.x - 8.0 * s, c.y - 1.5 * s),
        ],
        Color32::from_rgb(156, 122, 76),
        Stroke::NONE,
    );
    // 两条加固条
    for dx in [-6.0f32, 6.0] {
        px.line(
            Pos2::new(c.x + dx * s, c.y - 8.5 * s),
            Pos2::new(c.x + dx * s, c.y + 8.5 * s),
            1.6,
            Color32::from_rgb(70, 50, 28),
        );
    }
    // 阵营色带
    px.line(
        Pos2::new(c.x - 11.0 * s, c.y + 6.5 * s),
        Pos2::new(c.x + 11.0 * s, c.y + 6.5 * s),
        2.4,
        pal.fill,
    );
    // 弹药符号
    px.text(
        c,
        Align2::CENTER_CENTER,
        "弹",
        11.0,
        Color32::from_rgb(240, 228, 184),
    );
}

/// 统一入口：按兵种绘制棋子本体（不含血条/角标/选中框）。
pub fn draw_unit_body(
    px: &Px,
    c: Pos2,
    u: &Unit,
    hull: f32,
    turret: f32,
    fire: Option<(f32, f32, Option<BackWeapon>)>,
    time: f64,
    dim: bool,
) {
    if u.kind == UnitKind::Headquarters {
        draw_hq(px, c, u, dim);
    } else if u.kind == UnitKind::Supply {
        draw_supply(px, c, u, dim);
    } else if u.kind.is_air() {
        draw_air(px, c, u, hull, time, dim);
    } else if u.kind.is_vehicle() {
        draw_vehicle(px, c, u, hull, turret, dim);
    } else {
        match u.kind {
            UnitKind::Rifleman => rifleman::draw(px, c, u, hull, dim, fire),
            UnitKind::EliteInfantry => elite_infantry::draw(px, c, u, hull, dim, fire),
            UnitKind::SpecialForces => special_forces::draw(px, c, u, hull, dim, fire),
            _ => draw_weapon_team(px, c, u, hull, dim, fire.is_some()),
        }
    }
}
