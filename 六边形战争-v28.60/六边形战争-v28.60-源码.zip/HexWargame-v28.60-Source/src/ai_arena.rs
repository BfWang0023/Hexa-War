//! AI 自对弈天梯与 Elo 评估（Phase 5）。
//!
//! 在无头环境下让两套 AI 配置（版本 + 难度）对战，跑小规模循环赛并计算 Elo，
//! 用于验证"新版是否真的更强"以及后续调参。二进制入口见 src/bin/ai_ladder.rs。

use rand::Rng;
use rand::SeedableRng;

use crate::game::{AiDifficulty, AiVersion, GameState, Level};
use crate::unit::Team;

/// 一套可对战的 AI 配置。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Profile {
    pub name: &'static str,
    pub version: AiVersion,
    pub difficulty: AiDifficulty,
}

/// 天梯参赛配置。
pub fn profiles() -> Vec<Profile> {
    vec![
        Profile {
            name: "旧版",
            version: AiVersion::Legacy,
            difficulty: AiDifficulty::Regular,
        },
        Profile {
            name: "新版-新兵",
            version: AiVersion::V2,
            difficulty: AiDifficulty::Recruit,
        },
        Profile {
            name: "新版-常规",
            version: AiVersion::V2,
            difficulty: AiDifficulty::Regular,
        },
        Profile {
            name: "新版-老兵",
            version: AiVersion::V2,
            difficulty: AiDifficulty::Veteran,
        },
        Profile {
            name: "新版-精英",
            version: AiVersion::V2,
            difficulty: AiDifficulty::Elite,
        },
    ]
}

/// 一场无头对战：Player 侧用 a、AI 侧用 b。返回胜方（存活点数裁决，仍平返回 None）。
pub fn battle(seed: u64, a: Profile, b: Profile, max_turns: i32) -> Option<Team> {
    let mut g = GameState::new_sustain_multiplayer(seed, Level::OpenField);
    // 开启持续部署：设定双方每回合点数与初始点数，并生成关键据点（大本营）。
    g.start_sustain_multiplayer(15, 15, 200, 200);
    let mut log = Vec::new();
    for _ in 0..max_turns.max(1) {
        if g.game_over() {
            break;
        }
        g.begin_turn(Team::Player);
        g.ai_version = a.version;
        g.ai_difficulty = a.difficulty;
        crate::ai_router::run_ai_turn(&mut g, Team::Player, &mut log);
        if g.game_over() {
            break;
        }
        g.begin_turn(Team::Ai);
        g.ai_version = b.version;
        g.ai_difficulty = b.difficulty;
        crate::ai_router::run_ai_turn(&mut g, Team::Ai, &mut log);
        log.clear();
    }
    if let Some(w) = g.winner {
        return Some(w);
    }
    let value = |t: Team| -> i32 {
        g.units_of(t)
            .iter()
            .map(|u| u.kind.recruit_cost())
            .sum()
    };
    let pv = value(Team::Player);
    let av = value(Team::Ai);
    if pv != av {
        return Some(if pv > av { Team::Player } else { Team::Ai });
    }
    None
}

/// 循环赛 + Elo 更新，返回每个配置的最终 Elo。
/// 每个配置对在每轮各打一局（不同随机种子），双方默认对称。
pub fn elo_ladder(rounds: u32, max_turns: i32) -> Vec<(Profile, f64)> {
    let ps = profiles();
    let n = ps.len();
    let mut rating = vec![1500.0f64; n];
    let mut rng = rand::rngs::StdRng::seed_from_u64(0x5EED_1234);
    for _ in 0..rounds.max(1) {
        for i in 0..n {
            for j in (i + 1)..n {
                let seed = rng.gen::<u64>();
                let winner = battle(seed, ps[i], ps[j], max_turns);
                let (si, sj) = match winner {
                    Some(Team::Player) => (1.0, 0.0),
                    Some(Team::Ai) => (0.0, 1.0),
                    None => (0.5, 0.5),
                };
                let (ri, rj) = (rating[i], rating[j]);
                let ei = 1.0 / (1.0 + 10f64.powf((rj - ri) / 400.0));
                let k = 32.0;
                rating[i] = ri + k * (si - ei);
                rating[j] = rj + k * (sj - (1.0 - ei));
            }
        }
    }
    ps.into_iter().zip(rating).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 天梯对战应能跑完并给出胜者（或平局），不 panic。
    #[test]
    fn battle_smoke() {
        let ps = profiles();
        let w = battle(2024, ps[3], ps[1], 3);
        assert!(w.is_some() || w.is_none());
    }
}
