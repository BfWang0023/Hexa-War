//! 战斗动画系统：朝向姿态 / 移动滑行动画 / 弹道特效 / 爆炸 / 烟雾 / 尸体与残骸。
//!
//! 事件来源：GameState::ui_events（玩家与 AI 的所有移动/开火都会记录）。
//! AI 回合瞬时结算，GUI 按事件顺序错峰播放（fx_clock 依次排队）。

use eframe::egui::{self, Color32, Pos2, Vec2};
use hex_wargame::game::UiFireEvent;
use hex_wargame::hex::Hex;
use hex_wargame::unit::{Team, UnitKind};

use hex_wargame::pieces::{self, Px};

// ---------- 朝向姿态 ----------

/// 单位朝向（仅视图状态）：车身/班组朝向 + 炮塔朝向。
#[derive(Clone, Copy, Debug)]
pub struct Pose {
    pub hull: f32,
    pub turret: f32,
    /// 本次移动后是否开过火（决定移动后炮塔是否回正）
    pub fired: bool,
}

impl Pose {
    /// 默认朝向：玩家朝东、AI 朝西（正对敌方）。
    pub fn default_for(team: Team) -> Self {
        let hull = match team {
            Team::Player => 0.0,
            Team::Ai => std::f32::consts::PI,
        };
        Pose { hull, turret: hull, fired: false }
    }
}

// ---------- 移动动画 ----------

/// 移动滑行动画：动画期间终点格上的“真身”由本动画代画（路径插值位置）。
pub struct MoveAnim {
    pub team: Team,
    pub label: char,
    pub path: Vec<Hex>,
    pub start: f64,
    pub end: f64,
}

impl MoveAnim {
    pub fn active(&self, now: f64) -> bool {
        now >= self.start && now < self.end
    }
    pub fn done(&self, now: f64) -> bool {
        now >= self.end
    }
    /// 返回 (当前段索引, 段内进度 0..1)。路径不足 2 格时返回 (0, 1)。
    pub fn progress(&self, now: f64) -> (usize, f32) {
        let n = self.path.len().saturating_sub(1).max(1);
        let t = (((now - self.start) / (self.end - self.start).max(1e-6)).clamp(0.0, 1.0)) as f32;
        let raw = t * n as f32;
        let seg = (raw as usize).min(n - 1);
        let frac = raw - seg as f32;
        (seg, frac)
    }
}

// ---------- 弹道特效 ----------

/// 弹药落点后果（命中结算的动画信息）。
#[derive(Clone, Copy, Debug)]
pub struct Impact {
    pub killed: bool,
    pub blocked: bool,
    pub target_kind: UnitKind,
    pub target_team: Team,
    pub target_label: char,
    pub target_hex: Hex,
    pub target_hp_before: i32,
    pub dmg: i32,
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum ProjKind {    /// 步枪/机枪金色曳光
    Tracer,
    /// 机关炮曳光（粗）
    Autocannon,
    /// 坦克炮弹（高速亮点）
    Shell,
    /// 火箭筒火箭
    Rocket,
    /// TOW 导弹（长尾焰）
    Tow,
    /// Javelin（高抛弹道）
    Javelin,
    /// Stinger 防空导弹
    Stinger,
    /// Hellfire（武装直升机/无人机）
    Hellfire,
}

/// 弹药落点信息（Arc 附带爆炸格中心列表）。
#[derive(Clone)]
pub struct Landing {
    pub pos: Pos2,
    pub impact: Option<Impact>,
    pub smoke_shell: bool,
    /// Arc 落地时的爆炸格中心列表（调用方据此生成爆炸特效）
    pub blast: Vec<Pos2>,
    /// 被本次攻击击毁的单位（范围炮击波及等）：调用方据此生成尸体/残骸
    pub kills: Vec<Impact>,
}

pub enum Effect {
    /// 金色曳光线（快速移动的枪弹）
    Tracer { from: Pos2, to: Pos2, t0: f64, dur: f64, kind: ProjKind },
    /// 炮口火光
    Flash { pos: Pos2, ang: f32, t0: f64, scale: f32 },
    /// 导弹/火箭：直线或贝塞尔弹道 + 尾焰；impact=Some 时命中结算，None 时飞过目标淡出（未命中）
    Missile { from: Pos2, to: Pos2, ctrl: Option<Pos2>, t0: f64, dur: f64, kind: ProjKind, impact: Option<Impact>, consumed: bool },
    /// 炮弹抛物线（榴弹炮/迫击炮/烟雾弹）：落地后在 blast 各点爆炸
    Arc { from: Pos2, to: Pos2, t0: f64, dur: f64, height: f32, smoke_shell: bool, blast: Vec<Pos2>, kills: Vec<Impact>, consumed: bool },
    /// 爆炸（击毁/炮击落点）
    Explosion { pos: Pos2, t0: f64, big: bool },
    /// 装甲弹开火花（命中但被挡下）
    Spark { pos: Pos2, t0: f64 },
    /// 烟团（车辆冒烟 / 爆炸余烟 / 烟雾弹白烟）
    Puff { pos: Pos2, t0: f64, big: bool, white: bool, seed: f32 },
}

const GOLD: Color32 = Color32::from_rgb(255, 214, 92);
const TRAIL: Color32 = Color32::from_rgb(255, 190, 80);

fn ease(t: f32) -> f32 {
    t.clamp(0.0, 1.0)
}

fn bezier(a: Pos2, c: Pos2, b: Pos2, t: f32) -> Pos2 {
    let u = 1.0 - t;
    Pos2::new(
        u * u * a.x + 2.0 * u * t * c.x + t * t * b.x,
        u * u * a.y + 2.0 * u * t * c.y + t * t * b.y,
    )
}

impl Effect {
    pub fn done(&self, now: f64) -> bool {
        match self {
            Effect::Tracer { t0, dur, .. } => now >= t0 + dur,
            Effect::Flash { t0, .. } => now >= t0 + 0.1,
            Effect::Missile { t0, dur, impact, .. } => {
                now >= t0 + if impact.is_some() { *dur } else { *dur * 1.45 }
            }
            Effect::Arc { t0, dur, .. } => now >= t0 + *dur + 0.05,
            Effect::Explosion { t0, big, .. } => now >= t0 + if *big { 1.5 } else { 0.9 },
            Effect::Spark { t0, .. } => now >= t0 + 0.3,
            Effect::Puff { t0, big, .. } => now >= t0 + if *big { 2.0 } else { 1.4 },
        }
    }

    /// 弹药落地：返回落点信息（只返回一次）。炮击落地附带爆炸格中心列表。
    pub fn take_landing(&mut self, now: f64) -> Option<Landing> {
        match self {
            Effect::Missile { to, t0, dur, impact, consumed, .. } => {
                if !*consumed && impact.is_some() && now >= *t0 + *dur {
                    *consumed = true;
                    Some(Landing {
                        pos: *to,
                        impact: impact.clone(),
                        smoke_shell: false,
                        blast: Vec::new(),
                        kills: Vec::new(),
                    })
                } else {
                    None
                }
            }
            Effect::Arc { to, t0, dur, smoke_shell, blast, kills, consumed, .. } => {
                if !*consumed && now >= *t0 + *dur {
                    *consumed = true;
                    Some(Landing {
                        pos: *to,
                        impact: None,
                        smoke_shell: *smoke_shell,
                        blast: blast.clone(),
                        kills: kills.clone(),
                    })
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    pub fn draw(&self, p: &egui::Painter, s: f32, now: f64) {
        let px = Px::new(p, s);
        match self {
            Effect::Tracer { from, to, t0, dur, kind } => {
                let q = ease(((now - t0) / *dur) as f32);
                let head = Pos2::new(
                    from.x + (to.x - from.x) * q,
                    from.y + (to.y - from.y) * q,
                );
                let tail_q = (q - 0.3).max(0.0);
                let tail = Pos2::new(
                    from.x + (to.x - from.x) * tail_q,
                    from.y + (to.y - from.y) * tail_q,
                );
                let (w, col, hot) = match kind {
                    ProjKind::Autocannon => (2.4, GOLD, Color32::from_rgb(255, 240, 180)),
                    _ => (1.5, GOLD, Color32::from_rgb(255, 244, 200)),
                };
                px.line(tail, head, w, col);
                px.circle(head, if *kind == ProjKind::Autocannon { 1.7 } else { 1.1 }, hot);
            }
            Effect::Flash { pos, ang, t0, scale } => {
                let age = ((now - t0) / 0.1).clamp(0.0, 1.0) as f32;
                let a = ((1.0 - age) * 255.0) as u8;
                let px = Px { a, ..px };
                let r = 5.0 * scale * (0.6 + 0.4 * (1.0 - age));
                px.circle(*pos, r * 0.55, Color32::from_rgb(255, 236, 160));
                for da in [-0.5, 0.0, 0.5] {
                    let dir = ang + da;
                    let tip = Pos2::new(
                        pos.x + (r * 1.7) * dir.cos() * s,
                        pos.y + (r * 1.7) * dir.sin() * s,
                    );
                    px.line(*pos, tip, 1.6 * scale, TRAIL);
                }
            }
            Effect::Missile { from, to, ctrl, t0, dur, kind, impact, .. } => {
                let miss = impact.is_none();
                let span = if miss { *dur * 1.45 } else { *dur };
                let raw = (((now - t0) / span).clamp(0.0, 1.3)) as f32;
                let q = raw.min(1.0);
                let pos = match ctrl {
                    Some(c) => bezier(*from, *c, *to, q),
                    None => Pos2::new(from.x + (to.x - from.x) * q, from.y + (to.y - from.y) * q),
                };
                let prev_q = (q - 0.06).max(0.0);
                let prev = match ctrl {
                    Some(c) => bezier(*from, *c, *to, prev_q),
                    None => Pos2::new(from.x + (to.x - from.x) * prev_q, from.y + (to.y - from.y) * prev_q),
                };
                // 未命中：越过目标后淡出
                let a = if miss && raw > 1.0 {
                    ((1.3 - raw) / 0.3 * 255.0) as u8
                } else {
                    255u8
                };
                let px = Px { a, ..px };
                // 尾焰轨迹（沿途光点）
                for k in 1..=4 {
                    let tq = (q - 0.045 * k as f32).max(0.0);
                    let tp = match ctrl {
                        Some(c) => bezier(*from, *c, *to, tq),
                        None => Pos2::new(from.x + (to.x - from.x) * tq, from.y + (to.y - from.y) * tq),
                    };
                    let fade = (1.0 - k as f32 / 5.0) * 160.0;
                    px.circle(tp, 1.5, Color32::from_rgba_unmultiplied(255, 200, 120, fade as u8));
                }
                // 弹体
                let ang = pieces::angle_between(prev, pos);
                let (len, col) = match kind {
                    ProjKind::Rocket => (2.6, OLIVE_PROJ),
                    ProjKind::Tow => (3.0, Color32::from_rgb(220, 220, 200)),
                    ProjKind::Javelin => (3.0, OLIVE_PROJ),
                    ProjKind::Stinger => (2.4, Color32::from_rgb(230, 230, 210)),
                    _ => (2.6, Color32::from_rgb(210, 210, 190)),
                };
                let tip = Pos2::new(pos.x + len * ang.cos() * s, pos.y + len * ang.sin() * s);
                let back = Pos2::new(pos.x - len * ang.cos() * s, pos.y - len * ang.sin() * s);
                px.line(back, tip, 2.0, col);
                // 尾部火焰
                px.circle(back, 1.6, Color32::from_rgb(255, 170, 70));
                px.circle(back, 0.8, Color32::from_rgb(255, 240, 190));
            }
            Effect::Arc { from, to, t0, dur, height, smoke_shell, .. } => {
                let q = ease(((now - t0) / *dur) as f32);
                let pos = Pos2::new(
                    from.x + (to.x - from.x) * q,
                    from.y + (to.y - from.y) * q - height * (std::f32::consts::PI * q).sin() * s,
                );
                let col = if *smoke_shell {
                    Color32::from_rgb(225, 225, 218)
                } else {
                    Color32::from_rgb(60, 60, 58)
                };
                // 弹道阴影线（辅助判读落点）
                px.ring(*to, 3.0, 1.0, Color32::from_rgba_unmultiplied(255, 255, 255, 70));
                px.circle(pos, if *smoke_shell { 1.8 } else { 1.5 }, col);
            }
            Effect::Explosion { pos, t0, big } => {
                let life = if *big { 1.5 } else { 0.9 };
                let age = (((now - t0) / life).clamp(0.0, 1.0)) as f32;
                let k = if *big { 1.55 } else { 1.0 };
                // 闪光
                if age < 0.18 {
                    let fa = (1.0 - age / 0.18) * 255.0;
                    px.circle(*pos, 10.0 * k * (0.5 + age * 3.0), Color32::from_rgba_unmultiplied(255, 244, 200, fa as u8));
                }
                // 火球
                if age < 0.55 {
                    let fq = age / 0.55;
                    let r = (4.0 + 13.0 * fq) * k;
                    let col = if fq < 0.5 {
                        Color32::from_rgba_unmultiplied(255, 150 + (60.0 * fq * 2.0) as u8, 50, ((1.0 - fq) * 235.0) as u8)
                    } else {
                        Color32::from_rgba_unmultiplied(190, 90, 40, ((1.0 - fq) * 235.0) as u8)
                    };
                    px.circle(*pos, r, col);
                }
                // 烟环
                if age > 0.2 {
                    let sq = (age - 0.2) / 0.8;
                    for i in 0..5 {
                        let ang = i as f32 * 1.256 + 0.5;
                        let d = (4.0 + 14.0 * sq) * k;
                        let pp = Pos2::new(pos.x + d * ang.cos() * s, pos.y + d * ang.sin() * s);
                        let pa = ((1.0 - sq) * 140.0) as u8;
                        px.circle(pp, (2.5 + 5.0 * sq) * k, Color32::from_rgba_unmultiplied(110, 108, 104, pa));
                    }
                }
            }
            Effect::Spark { pos, t0 } => {
                let age = (((now - t0) / 0.3).clamp(0.0, 1.0)) as f32;
                let a = ((1.0 - age) * 230.0) as u8;
                let px = Px { a, ..px };
                for i in 0..5 {
                    let ang = i as f32 * 1.256 + 0.3;
                    let r1 = (1.5 + 3.0 * age) * s;
                    let r2 = (4.0 + 5.0 * age) * s;
                    px.line(
                        Pos2::new(pos.x + r1 * ang.cos(), pos.y + r1 * ang.sin()),
                        Pos2::new(pos.x + r2 * ang.cos(), pos.y + r2 * ang.sin()),
                        1.1,
                        Color32::from_rgb(230, 230, 220),
                    );
                }
                px.circle(*pos, 1.6, Color32::from_rgb(255, 250, 220));
            }
            Effect::Puff { pos, t0, big, white, seed } => {
                let life = if *big { 2.0 } else { 1.4 };
                let age = (((now - t0) / life).clamp(0.0, 1.0)) as f32;
                let k = if *big { 1.5 } else { 1.0 };
                let drift = Vec2::new((*seed * 6.0 - 3.0) * s, (-5.0 - *seed * 4.0) * s);
                let pp = Pos2::new(pos.x + drift.x * age, pos.y + drift.y * age);
                let r = (2.5 + 7.0 * age) * k;
                let (col, edge) = if *white {
                    (Color32::from_rgba_unmultiplied(228, 228, 222, ((1.0 - age) * 190.0) as u8),
                     Color32::from_rgba_unmultiplied(245, 245, 240, ((1.0 - age) * 120.0) as u8))
                } else {
                    (Color32::from_rgba_unmultiplied(120, 118, 114, ((1.0 - age) * 160.0) as u8),
                     Color32::from_rgba_unmultiplied(90, 90, 88, ((1.0 - age) * 100.0) as u8))
                };
                px.circle(pp, r, col);
                px.circle(pp, r * 0.55, edge);
            }
        }
    }
}

const OLIVE_PROJ: Color32 = Color32::from_rgb(180, 190, 130);

// ---------- 尸体 / 残骸 / 冒烟 ----------

/// 步兵阵亡：士兵图标变灰，2 秒后淡出消失。
pub struct Corpses {
    pub hex: Hex,
    pub t0: f64,
    pub facing: f32,
    /// 阵亡士兵的局部槽位（相对格中心）
    pub slots: Vec<(f32, f32)>,
}

impl Corpses {
    const LIFE: f64 = 2.4;
    pub fn done(&self, now: f64) -> bool {
        now >= self.t0 + Self::LIFE
    }
    pub fn draw(&self, p: &egui::Painter, c: Pos2, s: f32, now: f64) {
        let age = now - self.t0;
        let a = if age > Self::LIFE - 0.4 {
            (((Self::LIFE - age) / 0.4) * 255.0) as u8
        } else {
            255
        };
        let px = Px { a, ..Px::new(p, s) };
        for &(lx, ly) in &self.slots {
            let sc = pieces::xform(c, self.facing, (lx, ly), s);
            // draw_soldier 对 dead=true 使用固定灰色，palette 仅占位
            let pal = pieces::palette(Team::Ai, false);
            pieces::draw_soldier(&px, sc, &pal, self.facing, &[], true, -1.0, pieces::infantry::HelmetMark::None);
        }
    }
}

/// 载具残骸：爆炸后变灰，停留片刻再淡出消失。
pub struct Wreck {
    pub hex: Hex,
    pub kind: UnitKind,
    pub team: Team,
    pub t0: f64,
    pub hull: f32,
    pub turret: f32,
}

impl Wreck {
    const DELAY: f64 = 0.35; // 爆炸先播
    const LIFE: f64 = 3.0;
    pub fn done(&self, now: f64) -> bool {
        now >= self.t0 + Self::LIFE
    }
    pub fn draw(&self, p: &egui::Painter, c: Pos2, s: f32, now: f64) {
        let age = now - self.t0;
        if age < Self::DELAY {
            return;
        }
        let fade_age = age - Self::DELAY;
        let a = if fade_age > Self::LIFE - Self::DELAY - 0.7 {
            (((Self::LIFE - fade_age) / 0.7) * 210.0) as u8
        } else {
            (fade_age * 600.0).min(210.0) as u8
        };
        let px = Px { a, ..Px::new(p, s) };
        // 构造一个灰化单位供绘制（hp=0 → draw_vehicle 用残骸灰配色）
        let u = hex_wargame::unit::Unit::new(self.kind, self.team, self.hex);
        pieces::draw_vehicle(&px, c, &u, self.hull, self.turret, false);
    }
}

/// 被击中未击毁的载具：持续冒烟。
pub struct Smoker {
    pub pos: Pos2,
    pub until: f64,
    pub next_puff: f64,
}

// ---------- 武器时序 ----------

/// 武器发射时序：瞄准/上肩时长、飞行时长、弹种、抛物线高度。
pub struct WeaponProfile {
    pub aim: f64,
    pub flight: f64,
    pub kind: ProjKind,
    /// 部分抛物线高度（Javelin/迫击炮/榴弹炮）
    pub arc: Option<f32>,
}

/// 依兵种与武器模式决定弹道表现。
pub fn weapon_profile(kind: UnitKind, aa_mode: bool, missile_mode: bool, area: bool) -> WeaponProfile {
    let p = |aim: f64, flight: f64, kind: ProjKind, arc: Option<f32>| WeaponProfile { aim, flight, kind, arc };
    if area {
        return match kind {
            UnitKind::Mortar => p(0.25, 0.62, ProjKind::Shell, Some(66.0)),
            _ => p(0.3, 0.78, ProjKind::Shell, Some(52.0)),
        };
    }
    if aa_mode {
        return p(0.4, 0.42, ProjKind::Stinger, None); // Stinger
    }
    if missile_mode {
        return match kind {
            UnitKind::EliteInfantry | UnitKind::SpecialForces => p(0.5, 0.4, ProjKind::Rocket, None), // M3E1：上肩发射
            UnitKind::Rifleman => p(0.5, 0.4, ProjKind::Rocket, None), // M3E1-XM1176
            UnitKind::Ifv | UnitKind::CavalryIfv => p(0.35, 0.55, ProjKind::Tow, None), // TOW
            UnitKind::AaMgv => p(0.4, 0.42, ProjKind::Stinger, None),  // M-SHORAD Stinger
            UnitKind::Tank | UnitKind::HeavyTank => p(0.06, 0.16, ProjKind::Tracer, None), // 车载重机枪
            UnitKind::Howitzer => p(0.3, 0.78, ProjKind::Shell, Some(52.0)), // M864
            _ => p(0.3, 0.45, ProjKind::Rocket, None),
        };
    }
    match kind {
        UnitKind::Tank | UnitKind::HeavyTank => p(0.1, 0.2, ProjKind::Shell, None), // 120mm 坦克炮
        UnitKind::Scout => p(0.12, 0.22, ProjKind::Shell, None), // M551 152mm
        UnitKind::Ifv | UnitKind::CavalryIfv | UnitKind::AaMgv => {
            p(0.08, 0.15, ProjKind::Autocannon, None) // 25mm/30mm 机关炮
        }
        UnitKind::Atgm => p(0.35, 0.55, ProjKind::Tow, None),
        UnitKind::Javelin => p(0.45, 0.72, ProjKind::Javelin, Some(34.0)), // 高抛顶攻
        UnitKind::AaInfantry | UnitKind::AaLauncher => p(0.4, 0.42, ProjKind::Stinger, None),
        UnitKind::HmgGunner => p(0.08, 0.14, ProjKind::Tracer, None),
        UnitKind::AttackHeli | UnitKind::Drone => p(0.22, 0.48, ProjKind::Hellfire, None),
        // 步枪
        _ => p(0.05, 0.12, ProjKind::Tracer, None),
    }
}

/// 依事件推导攻击所用武器（供步兵上肩动画判断背负类型）。
pub fn fire_back_weapon(ev: &UiFireEvent) -> Option<pieces::BackWeapon> {
    if ev.aa_mode {
        return Some(pieces::BackWeapon::Aa);
    }
    if ev.missile_mode {
        return match ev.kind {
            UnitKind::Rifleman => Some(pieces::BackWeapon::Rocket), // M3E1-XM1176
            UnitKind::EliteInfantry | UnitKind::SpecialForces => {
                Some(pieces::BackWeapon::RocketHe) // M3E1-HE
            }
            _ => None,
        };
    }
    None
}
