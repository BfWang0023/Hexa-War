#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
OUTPUT=${1:-"$ROOT/dist"}
# Build/sign outside Finder-managed output folders to avoid metadata races.
STAGING=$(mktemp -d "${TMPDIR:-/tmp}/ancient-app.XXXXXX")
trap 'rm -rf "$STAGING"' EXIT HUP INT TERM
APP="$STAGING/古代战役.app"

cd "$ROOT"
cargo build --release --bin hex_wargame_web3d
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
swiftc -O -framework AppKit -framework WebKit \
  desktop/macos/AncientWargame.swift -o "$APP/Contents/MacOS/AncientWargame"
cp -X "${CARGO_TARGET_DIR:-$ROOT/target}/release/hex_wargame_web3d" "$APP/Contents/Resources/hex_wargame_web3d"
cp -RX web3d "$APP/Contents/Resources/web3d"
cp -X desktop/macos/cover.png "$APP/Contents/Resources/cover.png"
ICONSET="$APP/Contents/Resources/AppIcon.iconset"
mkdir -p "$ICONSET"
for SIZE in 16 32 128 256 512; do
  sips -z "$SIZE" "$SIZE" desktop/macos/cover.png --out "$ICONSET/icon_${SIZE}x${SIZE}.png" >/dev/null
  DOUBLE=$((SIZE * 2))
  sips -z "$DOUBLE" "$DOUBLE" desktop/macos/cover.png --out "$ICONSET/icon_${SIZE}x${SIZE}@2x.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"
rm -rf "$ICONSET"
find "$APP" -name '.DS_Store' -delete
xattr -cr "$APP"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>古代战役</string>
  <key>CFBundleDisplayName</key><string>古代战役</string>
  <key>CFBundleIdentifier</key><string>local.hexwargame.ancient</string>
  <key>CFBundleExecutable</key><string>AncientWargame</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSAppTransportSecurity</key><dict>
    <key>NSAllowsLocalNetworking</key><true/>
  </dict>
</dict></plist>
PLIST
# Finder may attach icon metadata while the bundle is being assembled.
# Remove it before signing, as codesign rejects this attribute.
xattr -d com.apple.FinderInfo "$APP" 2>/dev/null || true
codesign --force --deep --sign - "$APP"
xattr -d com.apple.FinderInfo "$APP" 2>/dev/null || true
codesign --verify --deep --strict "$APP"
mkdir -p "$OUTPUT"
ditto -c -k --norsrc --noextattr --keepParent "$APP" "$OUTPUT/古代战役-v02-macOS.zip"
rm -rf "$OUTPUT/古代战役.app"
cp -RX "$APP" "$OUTPUT/古代战役.app"
xattr -d com.apple.FinderInfo "$OUTPUT/古代战役.app" 2>/dev/null || true
if ! codesign --verify --deep --strict "$OUTPUT/古代战役.app"; then
  # Finder may set a root icon attribute just after the copy completes.
  xattr -d com.apple.FinderInfo "$OUTPUT/古代战役.app" 2>/dev/null || true
  codesign --verify --deep --strict "$OUTPUT/古代战役.app"
fi
echo "$OUTPUT/古代战役.app"
