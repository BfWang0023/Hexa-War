import AppKit
import WebKit

final class GameApp: NSObject, NSApplicationDelegate, NSWindowDelegate, WKNavigationDelegate, WKUIDelegate {
    private var window: NSWindow!
    private var webView: WKWebView!
    private var server: Process?
    private var port = 0
    private var launchAttempts = 0
    private let maxAttempts = 8

    func applicationDidFinishLaunching(_ notification: Notification) {
        let menu = NSMenu()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "退出古代战役", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        let appItem = NSMenuItem()
        appItem.submenu = appMenu
        menu.addItem(appItem)
        NSApp.mainMenu = menu

        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.setValue(false, forKey: "drawsBackground")

        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 1440, height: 900),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "古代战役 · 六边形战争"
        window.minSize = NSSize(width: 980, height: 680)
        window.contentView = webView
        window.delegate = self
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        showMessage("正在启动古代战役…")
        startServer()
    }

    private func showMessage(_ message: String) {
        webView.loadHTMLString("""
        <!doctype html><meta charset="utf-8"><style>
        body{margin:0;background:#121b24;color:#e9dfc9;font:22px -apple-system,BlinkMacSystemFont,sans-serif;
        min-height:100vh;display:grid;place-items:center;text-align:center}p{max-width:680px;line-height:1.6}
        </style><p>\(message)</p>
        """, baseURL: nil)
    }

    private func startServer() {
        launchAttempts += 1
        guard launchAttempts <= maxAttempts else {
            showMessage("游戏服务无法启动。请重新打开应用；如问题持续，请查看应用包中的运行说明。")
            return
        }
        let resources = Bundle.main.resourceURL!
        let executable = resources.appendingPathComponent("hex_wargame_web3d")
        let staticDirectory = resources.appendingPathComponent("web3d")
        guard FileManager.default.isExecutableFile(atPath: executable.path),
              FileManager.default.fileExists(atPath: staticDirectory.appendingPathComponent("ancient/index.html").path) else {
            showMessage("应用资源不完整，请重新解压整个安装包。")
            return
        }

        port = Int.random(in: 20000...60000)
        let process = Process()
        process.executableURL = executable
        process.arguments = ["--host", "127.0.0.1", "--port", String(port), "--static", staticDirectory.path]
        process.currentDirectoryURL = resources
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
            server = process
            checkServer(remaining: 80)
        } catch {
            showMessage("游戏服务启动失败：\(error.localizedDescription)")
        }
    }

    private func checkServer(remaining: Int) {
        guard let process = server else { return }
        if !process.isRunning {
            server = nil
            startServer()
            return
        }
        guard remaining > 0 else {
            process.terminate()
            server = nil
            showMessage("游戏服务启动超时，请重新打开应用。")
            return
        }
        let url = URL(string: "http://127.0.0.1:\(port)/ancient/")!
        var request = URLRequest(url: url)
        request.timeoutInterval = 1
        URLSession.shared.dataTask(with: request) { [weak self] _, response, _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                    self.webView.load(URLRequest(url: url))
                } else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                        self.checkServer(remaining: remaining - 1)
                    }
                }
            }
        }.resume()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        showMessage("战场页面载入失败：\(error.localizedDescription)")
    }

    // WKWebView does not present JavaScript dialogs without a UI delegate.
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert()
        alert.messageText = "六边形战争"
        alert.informativeText = message
        alert.addButton(withTitle: "确认")
        alert.addButton(withTitle: "取消")
        alert.beginSheetModal(for: window) { response in completionHandler(response == .alertFirstButtonReturn) }
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = NSAlert()
        alert.messageText = "六边形战争"
        alert.informativeText = message
        alert.addButton(withTitle: "确定")
        alert.beginSheetModal(for: window) { _ in completionHandler() }
    }

    func windowWillClose(_ notification: Notification) {
        NSApp.terminate(nil)
    }

    func applicationWillTerminate(_ notification: Notification) {
        if let process = server, process.isRunning { process.terminate() }
    }
}

let app = NSApplication.shared
let delegate = GameApp()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
