# 六边形战争 3D · 跨平台源码包

本包包含原版 3D 战场与古代战役剧本。压缩包不含任何平台的可执行文件；接收者可以在自己的电脑上编译。

## macOS 桌面版

Apple Silicon Mac 可使用另附的 `古代战役.app`：解压后双击即可进入古代战役列表，不需要安装 Rust、启动终端或另开浏览器。应用会在本机启动规则服务，关闭窗口时自动停止。此包由临时签名构建，未进行 Apple 开发者公证；若从互联网下载后被系统拦截，可在 Finder 中右键应用并选择「打开」。

页面顶部的「电脑指挥」可在休闲、标准、精锐三档之间切换，随存档保存。页面顶部的「存档」提供 8 个独立位置，保存后可读取战役、阵营、回合、部队和视野。macOS 桌面版存档位于 `~/Library/Application Support/HexWargame/AncientSaves/`，升级应用不会删除它们。命令行运行时可用 `--save-dir <目录>` 指定存档位置；Windows 默认使用 `%APPDATA%\HexWargame\AncientSaves`，Linux 默认使用用户数据目录。

本版随安装包附带用户修订的 34 份战役地图和兵种布置，位于 `web3d/ancient/bundled-maps/`，在 macOS、Windows、Linux 上都会显示为这些战役的默认地图。游戏优先读取个人数据目录 `maps/` 中同名的再次编辑版；更新或覆盖安装不会覆盖个人地图和八格存档。编辑器的「恢复原版」会撤销个人再次编辑版，恢复到安装包随附的修订地图。详情见 `docs/用户修订战役地图.md`。

如需从源码重新制作桌面版，在 macOS 安装 Xcode Command Line Tools 与 Rust/Cargo 后运行 `sh desktop/macos/build.sh`。生成的应用在 `dist/古代战役.app`。Intel Mac 请在 Intel Mac 上运行相同脚本。Windows 和 Linux 可按下文的通用步骤部署 3D 版本。

## 1. 安装 Rust

从 Rust 官方页面安装 stable 工具链：<https://rust-lang.org/tools/install/>。Windows 用户按页面提示安装 rustup；如安装程序要求，补装 Visual Studio C++ Build Tools。macOS 或 Linux 用户按官方页面的命令安装。安装后在新终端运行 `rustc --version` 和 `cargo --version` 检查。首次编译会联网下载 Cargo 依赖。

## 2. 编译游戏

解压后，在含有 `Cargo.toml` 的本目录运行：

```sh
cargo build --release --bin hex_wargame_web3d
```

编译好的程序位于 `target/release/`。macOS/Linux 文件名是 `hex_wargame_web3d`，Windows 文件名是 `hex_wargame_web3d.exe`。

## 3. 运行 3D 游戏

仍在本目录运行：

```sh
cargo run --release --bin hex_wargame_web3d -- --open
```

程序会启动本地服务并打开浏览器。原版 3D 战场地址是 <http://127.0.0.1:8800/>；古代战役地址是 <http://127.0.0.1:8800/ancient/>。全部 71 场古代战役按时间从早到晚排列，名称统一为“战役名称（时间）”，包含 35 场中国先秦战役、新增 14 场秦末楚汉及两汉战役，以及叙拉古、彼得那等原有剧本。需要在支持 WebGL2 的现代浏览器中打开。关闭运行程序的终端或按 Ctrl+C 即可停止服务。如果 8800 端口已被占用，在上述命令最后加 `--port 8801`，再使用对应端口访问。

如果希望运行仓库原有的桌面 GUI 版本，可另外执行 `cargo run --release --bin hex_wargame`。这与浏览器 3D 版本是两个入口。

## 4. 可选验证

若本机另装有 Node.js，可运行古代战役规则测试：

```sh
node --test web3d/ancient/*.test.mjs
```

源码包保留 `src/`、`web3d/`、`maps/`、`assets/` 和 `Cargo.lock`。运行时请让 `web3d/` 与程序所在的项目目录保持原样；若单独移动可执行文件，须用 `--static` 指定 `web3d/` 的完整路径。更多游戏说明见 `README.md`。
