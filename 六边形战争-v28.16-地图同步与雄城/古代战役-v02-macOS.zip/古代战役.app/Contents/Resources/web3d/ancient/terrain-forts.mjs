// Batched defensive works. Levels affect appearance only; rule heights stay fixed.
import * as THREE from '../vendor/three/three.module.js';
import { offsetToWorld } from '../js/core/hex.js';
import { neighbors, FORT_HP } from './engine.mjs';
import { noise } from './terrain-surface.mjs';

import { wallNeighbors } from './terrain-adjacency.mjs';

export const wallHeight = level => [0, 2.8, 4.2, 5.6][level] || 0;

export function createTerrainForts(m, forts, height, allForts = forts) {
  const group = new THREE.Group();
  const sides = [], tops = [], timber = [], damage = [], rubble = [], flags = [];
  const byCell = new Map(allForts.filter(u => u.hp > 0).map(u => [`${u.c},${u.r}`, u]));
  function add(list, u, x, y, z, sx, sy, sz, angle = 0, tilt = 0) {
    list.push({ u, p: [x, y, z], s: [sx, sy, sz], angle, tilt });
  }
  for (const u of forts) {
    const p = offsetToWorld(u.c, u.r), base = height(m, u.c, u.r);
    const h = wallHeight(u.level), ratio = Math.max(0, u.hp / FORT_HP[u.level]);
    if (ratio <= 0) {
      for (let i = 0; i < 6; i++)
        add(rubble, u, p.x + (noise(u.c, u.r, i) - .5) * 6, base + .15,
          p.z + (noise(u.r, u.c, i + 8) - .5) * 4,
          .5 + noise(i, u.c), .3, .65, noise(i, u.r) * 6);
      continue;
    }
    if(u.gate){
      const connected=wallNeighbors(m,u,byCell).map(n=>n.wall);
      const q=connected.length?offsetToWorld(connected[0].c,connected[0].r):{x:p.x+1,z:p.z},a=-Math.atan2(q.z-p.z,q.x-p.x);
      const gateH=h+1.5+u.level*.25;
      for(const side of [-1,1]){const x=p.x+Math.cos(a)*side*2,z=p.z-Math.sin(a)*side*2;add(sides,u,x,base+gateH/2,z,1.5,gateH,3.2,a);add(tops,u,x,base+gateH+.1,z,1.85,.28,3.5,a);}
      add(sides,u,p.x,base+gateH-.45,p.z,5.3,.9,3.1,a);
      add(timber,u,p.x-1.1,base+gateH+1.25,p.z,.12,2.5,.12);
      add(flags,u,p.x-.1,base+gateH+1.9,p.z,1.9,1.1,.07,a);
      add(tops,u,p.x,base+h,p.z,5.3,.55,2.8,a);
      add(timber,u,p.x,base+h*.4,p.z,3,h*.8,.3,a);
      // The gate owns its half of each wall connection. Meet the neighboring
      // wall at the shared midpoint, with a slight overlap to prevent seams.
      for(const v of connected){const q=offsetToWorld(v.c,v.r),dx=q.x-p.x,dz=q.z-p.z,d=Math.hypot(dx,dz),start=Math.min(1.7,d/4),end=d/2+.12,angle=-Math.atan2(dz,dx),len=end-start;
        const top0=base+h,top1=(top0+height(m,v.c,v.r)+wallHeight(v.level))/2;
        const dh=top1-top0,tilt=Math.atan2(dh,len),x=p.x+dx/d*(start+end)/2,z=p.z+dz/d*(start+end)/2;
        add(sides,u,x,base+h/2+dh/2,z,Math.hypot(len,dh)+.12,h,2.7,angle,tilt);
        add(tops,u,x,top0+.06+dh/2,z,Math.hypot(len,dh)+.16,.14,2.85,angle,tilt);
      }
      continue;
    }
    const simple = u.level === 1, grand = u.level === 3;
    const width = grand ? 3.25 : 2.7, nodeWidth = grand ? 3.8 : 3.2;
    const foundation = simple ? h*.58 : h;
    const connected = wallNeighbors(m,u,byCell).map(p=>p.wall);
    add(sides, u, p.x, base + foundation / 2, p.z, nodeWidth, foundation, nodeWidth);
    // The central walkway remains at the existing unit anchor for all three levels.
    add(simple ? timber : tops, u, p.x, base + h + .04, p.z, nodeWidth + .15, .12, nodeWidth + .15);
    const arms = connected.length ? connected.map(v => {
      const q = offsetToWorld(v.c, v.r);
      return { dx: (q.x - p.x) / 2, dz: (q.z - p.z) / 2,
        dh: (height(m, v.c, v.r) + wallHeight(v.level) - base - h) / 2 };
    }) : [{ dx: 4.8, dz: 0, dh: 0 }, { dx: -4.8, dz: 0, dh: 0 }];

    for (const { dx, dz, dh } of arms) {
      const len = Math.hypot(dx, dz), angle = -Math.atan2(dz, dx), tilt = Math.atan2(dh, len);
      add(sides, u, p.x + dx / 2, base + foundation / 2 + dh / 2, p.z + dz / 2,
        len + .12, foundation, width, angle, tilt);
      add(simple ? timber : tops, u, p.x + dx / 2, base + h + .06 + dh / 2, p.z + dz / 2,
        len + .16, .14, width + .15, angle, tilt);
      if (simple) {
        // Low stone footings, timber rail panels and upright stakes distinguish level one.
        for (const side of [-1, 1]) {
          const sx = Math.sin(angle) * side * 1.18, sz = Math.cos(angle) * side * 1.18;
          add(timber, u, p.x + dx / 2 + sx, base + h*.52 + dh / 2, p.z + dz / 2 + sz,
            len, .28, .2, angle, tilt);
          for (let j = 1; j <= 4; j++) {
            if (ratio < .75 && noise(u.c, u.r, j + side * 9) > ratio) continue;
            const f = j / 4.4;
            add(timber, u, p.x + dx * f + sx, base + h*.6 + dh * f, p.z + dz * f + sz,
              .26, h*.75, .26, angle);
          }
        }
      } else {
        for (let j = 1; j <= 3; j++) {
          if (ratio < .75 && noise(u.c, u.r, j + Math.round(angle * 10)) > ratio) continue;
          const f = j / 3.5;
          for (const side of [-1, 1])
            add(tops, u, p.x + dx * f + Math.sin(angle) * side * (width / 2 - .12),
              base + h + .35 + dh * f, p.z + dz * f + Math.cos(angle) * side * (width / 2 - .12),
              .65, .6, .43, angle);
        }
      }
    }
    if (grand) {
      // Offset the tower from the cell center so a garrison can still stand on the walkway.
      const angle = -Math.atan2(arms[0].dz, arms[0].dx);
      const x = p.x + Math.sin(angle) * 3.55, z = p.z + Math.cos(angle) * 3.55;
      const towerH = h + (ratio < .5 ? .75 : 1.5);
      add(sides, u, x, base + towerH / 2, z, 2.4, towerH, 2.4, angle);
      add(tops, u, x, base + towerH + .06, z, 2.7, .18, 2.7, angle);
      for (const sx of [-.96, .96]) for (const sz of [-.96, .96]) {
        if (ratio < .5 && sx === sz) continue;
        add(tops, u, x + Math.cos(angle) * sx + Math.sin(angle) * sz, base + towerH + .4,
          z - Math.sin(angle) * sx + Math.cos(angle) * sz, .52, .62, .52, angle);
      }
      add(damage, u, x, base + towerH * .72, z - 1.21, .17, .7, .025);
      add(damage, u, x + 1.21, base + towerH * .72, z, .025, .7, .17);
    }
    if (ratio < .85) {
      add(damage, u, p.x + .8, base + foundation * .5, p.z - nodeWidth / 2 - .01,
        .13, foundation * .72, .025, 0, .2);
      for (let i = 0; i < 3; i++)
        add(rubble, u, p.x - 2.0 + i * .6, base + .12, p.z + 2.1, .5, .24, .4, i * .6);
    }
  }
  function batch(name, items, color) {
    if (!items.length) return;
    const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshStandardMaterial({ color, roughness: 1 }), items.length);
    const o = new THREE.Object3D();
    items.forEach(({ u, p, s, angle, tilt }, i) => {
      o.position.set(...p); o.scale.set(...s); o.rotation.set(0, angle, 0); o.rotateZ(tilt);
      o.updateMatrix(); mesh.setMatrixAt(i, o.matrix);
      const ratio = Math.max(0, u.hp / FORT_HP[u.level]);
      const tint = new THREE.Color(name==='gate-flags'?(u.team==='egypt'?0x37b7e8:0xe65943):(u.team === 'egypt' ? 0xd3c3a5 : 0xc3b49a));
      tint.multiplyScalar(.72 + .28 * ratio); mesh.setColorAt(i, tint);
    });
    mesh.name = name; mesh.userData.unitIds = items.map(x => x.u.id);
    mesh.instanceMatrix.needsUpdate = true; mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh);
  }
  batch('gate-flags',flags,0xffffff);
  batch('wall-masonry', sides, 0x9a8c75);
  batch('wall-coping', tops, 0xdbceac);
  batch('wall-timber', timber, 0x89633c);
  batch('wall-cracks', damage, 0x413f35);
  batch('wall-rubble', rubble, 0x95886f);
  return group;
}
